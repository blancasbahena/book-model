package com.srm.fungandrui.lineamientos.dto;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class DetalleBO implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 3779672666245944102L;
	private String grdOoriginal;
	private String grdAprobado;
	private String nuevoEtd;
}
