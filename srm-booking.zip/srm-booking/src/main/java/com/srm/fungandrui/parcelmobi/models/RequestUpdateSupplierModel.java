package com.srm.fungandrui.parcelmobi.models;


import java.io.Serializable;
import java.util.Date;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RequestUpdateSupplierModel implements Serializable {

	private static final long serialVersionUID = 1L;
    private Date dateUpdateSupplier;
    private String bookingUpdateSupplier;
    private Date dateEtdFinalUpdateSupplier;
    private int carrierUpdateSupplier;
    private String folio;
    private String proveedor;
    private int etdFina;
    private int naviera;
    private String booking;
    private String planner;
}
