package com.srm.fungandrui.imports.service.impl;

import java.lang.reflect.Type;

import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;

import org.springframework.stereotype.Service;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.reflect.TypeToken;
import com.srm.pli.utils.ImportsTokenClient;
import com.srm.pli.utils.PropertiesDb;
import com.srm.pli.ws.vo.ResponseImportsVO;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.truper.utils.string.UtilsString;

import lombok.extern.slf4j.Slf4j;


@Slf4j
@Service
public class ImportsServiceClient {
	private static String baseUri = PropertiesDb.getInstance().getString("srm.imports.baseUri");
	private static String version = PropertiesDb.getInstance().getString("srm.imports.version");

	private Client client;
	private WebResource webResource;
	private Gson gson = new Gson();


	public void setClient(String endPoint) {
		client = Client.create();
		String uri;
		uri = UtilsString.append(baseUri,version, endPoint);
		webResource = client.resource(uri);
		log.debug("EndPoint: {}", webResource.getURI());
	}

	public ImportsServiceClient() {
	}

	public ResponseImportsVO getRequest(Object formData, String method) throws RuntimeException {
		ResponseImportsVO responseObject = null;
		String output = null;
		ClientResponse response = null;
		
		
		
		try {
			if(method.equalsIgnoreCase("POST")) {
				response =  webResource.type(MediaType.APPLICATION_JSON_TYPE).accept(MediaType.APPLICATION_JSON_TYPE).header(HttpHeaders.AUTHORIZATION, "Bearer " + ImportsTokenClient.getInstance().ObjectToken.getData().get("token").toString()).post(ClientResponse.class, formData.toString());	
			}else if(method.equalsIgnoreCase("PUT")) {
				response = webResource.type(MediaType.APPLICATION_JSON_TYPE).accept(MediaType.APPLICATION_JSON_TYPE).header(HttpHeaders.AUTHORIZATION, "Bearer " + ImportsTokenClient.getInstance().ObjectToken.getData().get("token").toString()).put(ClientResponse.class, formData.toString());					
			}else if(method.equalsIgnoreCase("GET")) {
				response = webResource.type(MediaType.APPLICATION_JSON_TYPE).accept(MediaType.APPLICATION_JSON_TYPE).header(HttpHeaders.AUTHORIZATION, "Bearer " + ImportsTokenClient.getInstance().ObjectToken.getData().get("token").toString()).get(ClientResponse.class);	
			}else if(method.equalsIgnoreCase("DELETE")) {
				response = webResource.type(MediaType.APPLICATION_JSON_TYPE).accept(MediaType.APPLICATION_JSON_TYPE).header(HttpHeaders.AUTHORIZATION, "Bearer " + ImportsTokenClient.getInstance().ObjectToken.getData().get("token").toString()).delete(ClientResponse.class, formData.toString());	
			}else if (method.equalsIgnoreCase("PARAM")) {
				response = webResource.type(MediaType.MULTIPART_FORM_DATA).header(HttpHeaders.AUTHORIZATION, "Bearer " + ImportsTokenClient.getInstance().ObjectToken.getData().get("token").toString()).post(ClientResponse.class, formData);
			}
			if (response.getStatus() == 200) {
				output = response.getEntity(String.class);
				JsonObject obj = (JsonObject) new JsonParser().parse(output);
				Type type = new TypeToken<ResponseImportsVO>() {
				}.getType();
				responseObject = gson.fromJson(obj, type);
			} else { // esto se tiene que cambiar para cachar de meejor manera el error
				log.info("Failed : HTTP error code : " + response.getStatus());
				output = response.getEntity(String.class);
				JsonObject obj = (JsonObject) new JsonParser().parse(output);
				Type type = new TypeToken<ResponseImportsVO>() {
				}.getType();
				responseObject = gson.fromJson(obj, type);
			}
		} catch (Exception e) {
			log.error("Error  ImportsServiceClient , getRequest {}", e);
			throw e;
		}

		return responseObject;
	}


}
