package com.srm.fungandrui.facturacion.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.srm.app.constantes.Mensajes;
import com.srm.fungandrui.facturacion.dao.PeticionRabbit;
import com.srm.fungandrui.facturacion.dto.FacturacionFilter;
import com.srm.fungandrui.facturacion.models.BeanFacturacion;
import com.srm.fungandrui.facturacion.models.Facturacion;
import com.srm.fungandrui.facturacion.service.RabbitService;
import com.srm.fungandrui.sc.model.BeanSession;
import com.srm.fungandrui.sc.model.ResponseVO;
import com.srm.fungandrui.sc.utils.SessionUtil;
import com.srm.pli.enums.HistoryLogAction;
import com.srm.pli.services.HistoryLogServices;
import com.truper.businessEntity.UserBean;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
@CrossOrigin(origins = "*")
@RequestMapping("/queu-facturacion")
public class QueueFacturacionController {

	@Autowired
	RabbitService rabbitServices;
	HistoryLogServices historylog = HistoryLogServices.getInstance();
	
	@RequestMapping(value = "/testFacturacion", method = RequestMethod.POST)
	public ResponseEntity<ResponseVO> TestPeticion(HttpServletRequest request, @RequestBody PeticionRabbit peticion){
		ResponseVO response = new ResponseVO();
		log.info("[ POST /testFacturacion] - Inicia ");
		PeticionRabbit pr = rabbitServices.testFacturacion(peticion);
		response.createSuccess("pr",pr);
		log.info("[ POST /testFacturacion] - Termina ");
		return ResponseEntity.ok(response);
	}
	
	@RequestMapping(value = "/testFR-Facturacion", method = RequestMethod.POST)
	public ResponseEntity<ResponseVO> TestFRPeticion(HttpServletRequest request, @RequestBody PeticionRabbit peticion){
		ResponseVO response = new ResponseVO();
		log.info("[ POST /testFR-Facturacion] - Inicia ");
		PeticionRabbit pr = rabbitServices.testFRFacturacion(peticion);
		response.createSuccess("pr",pr);
		log.info("[ POST /testFR-Facturacion] - Termina ");
		return ResponseEntity.ok(response);
	}
	
	@RequestMapping(value = "/test/BloqueoPo/{folio}", method = RequestMethod.GET)
	public ResponseEntity<ResponseVO> TestFRPeticion(HttpServletRequest request, @PathVariable String folio){
		ResponseVO response = new ResponseVO();
		log.info("[ GET /test/BloqueoPo/{"+folio+"}] - Inicia ");
		response = rabbitServices.bloqueoPOs(folio);
		log.info("[ GET /test/BloqueoPo/{"+folio+"}] - Termina ");
		return ResponseEntity.ok(response);
	}
	
	
	@RequestMapping(value = "/solicita", method = RequestMethod.POST)
	public ResponseEntity<ResponseVO> solicitaFactura(HttpServletRequest request, @RequestBody BeanFacturacion factura){
		ResponseVO response = new ResponseVO();
		log.info("[ POST /solicita] - Inicia ");
		HttpSession sesion = request.getSession(false);
		UserBean usuario = (UserBean) sesion.getAttribute("usuario");
		if( usuario != null ) {
			Integer idUser = usuario.getIdUser();
			String userName = usuario.getUserName();
			response = rabbitServices.solicitaFacturacion(factura,idUser,userName);
		}else {
			response =  response.createError("error", "Usuario no valido");
		}
		
		log.info("[ POST /solicita] - Termina ");
		return ResponseEntity.ok(response);
	}
	
	@RequestMapping(value = "/entregaSIFE", method = RequestMethod.POST)
	public ResponseEntity<ResponseVO> entregaSIFE(HttpServletRequest request, @RequestBody Facturacion factura){
		ResponseVO response = new ResponseVO();
		log.info("[ POST /entregaSIFE] - Inicia ");
		HttpSession sesion = request.getSession(false);
		UserBean usuario = (UserBean) sesion.getAttribute("usuario");
		response = rabbitServices.entregaSIFE(factura,sesion);
		log.info("[ POST /entregaSIFE] - Termina ");
		return ResponseEntity.ok(response);
	}	
	
	
	@RequestMapping(value = "/cancela", method = RequestMethod.POST)
	public ResponseEntity<ResponseVO> cancelaFactura(HttpServletRequest request, @RequestBody FacturacionFilter factura){
		ResponseVO response = new ResponseVO();
		HttpSession session = null;
		BeanSession beanSession = null;
		
		beanSession = SessionUtil.validaSesion(session);
		String userName = beanSession.getUser().getUserName();
		Integer userProfile = beanSession.getUser().getUserProfile();
		
		log.info("[ POST /cancela] - Inicia ");
		response = rabbitServices.cancelaFacturacion(factura.getInvoiceNumber(),userName,userProfile);
		log.info("[ POST /cancela] - Termina ");
		return ResponseEntity.ok(response);
	}
	
	@RequestMapping(value = "/manual/{noFactura}", method = RequestMethod.GET)
	public ResponseEntity<ResponseVO> facturacionManual(HttpServletRequest request, @PathVariable String noFactura){
		ResponseVO response = new ResponseVO();
		log.info("[ POST /manual/{noFactura}] - Inicia ");
		response = rabbitServices.facturacionManual(noFactura);
		log.info("[ POST /manual/{noFactura}] - Termina ");
		return ResponseEntity.ok(response);
		
	}
	
	@RequestMapping(value = "/sar/{idSar}/tipoPago/{tPago}", method = RequestMethod.GET)
	public ResponseEntity<ResponseVO> solicitaFacturaPorTipoPago(HttpServletRequest request, @PathVariable String idSar, @PathVariable String tPago){
		ResponseVO response = new ResponseVO();
		log.info("[ POST /sar/{idSar}/tipoPago/{tPago} - Inicia "); 
		response = rabbitServices.facturacionPorTipoDePago(idSar, tPago);
		log.info("[ POST /sar/{idSar}/tipoPago/{tPago} - Termina ");
		return ResponseEntity.ok(response);
	}
	
	@RequestMapping(value = "/refacturacion", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseVO> refacturacion(HttpServletRequest request, @RequestBody BeanFacturacion datos){
		ResponseVO response = new ResponseVO();
		log.info("[ POST /refacturacion - Inicia ");
		HttpSession session = null;
		BeanSession beanSession;
		session = request.getSession(false);
		beanSession = SessionUtil.validaSesion(session);
		String userName = beanSession.getUser().getUserName();
		response = rabbitServices.refacturacion(datos,beanSession.getUser().getIdUser());
		
		
		if(response.getTipoMensaje().equals(Mensajes.TIPO_EXITO.getMensaje())){
			historylog.registraAccion (datos.getFolio(),userName , HistoryLogAction.STATUS_REFACTURACION, "RECHAZADOS FACTURACION :Cambio de status de Refacturacion");
		}
		
		log.info("[ POST /refacturacion - Termina ");
		return ResponseEntity.ok(response);
	}
}
