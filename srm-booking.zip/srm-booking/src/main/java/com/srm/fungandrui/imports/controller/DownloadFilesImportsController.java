package com.srm.fungandrui.imports.controller;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;

import javax.xml.bind.DatatypeConverter;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.srm.fungandrui.imports.service.ImportacionesService;
import com.srm.pli.enums.Mensajes;
import com.srm.pli.ws.vo.ResponseImportsVO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
@RequestMapping("/imports")
public class DownloadFilesImportsController {

	@Autowired
	ImportacionesService importacionesService;

	private final static String FILE_NAME = "filename.xlsx"; 
	
	private final static String FILE_TYPE = "file";

	@GetMapping(value = "/sharepoint/download")
	public ResponseEntity<Resource> getFileTop() {
		log.info("Entro a /imports ::: [/sharepoint/download]");
		ResponseImportsVO resp = null;
		try {
			resp = importacionesService.downloadFileTopReglas();
			String dataString = resp.getData().get(FILE_TYPE).toString();
			byte[] result = DatatypeConverter.parseBase64Binary(dataString);
			//byte[] result = Base64.getDecoder().decode(resp.getData().get(FILE_TYPE).toString());
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			InputStream targetStream = new ByteArrayInputStream(result);
			byte[] byteChunk = new byte[4096];
			int n;
			Resource resource;
			while ((n = targetStream.read(byteChunk)) > 0) {
				baos.write(byteChunk, 0, n);
			};

			FileOutputStream fos = null;
			File file = new File(FILE_NAME);
			try {
				fos = new FileOutputStream(file);


				baos.writeTo(fos);
			} catch (IOException ioe) {
				log.error(ioe.getMessage());
			} finally {
				fos.close();
			}

			Path path = Paths.get(file.getAbsolutePath());
			resource = new UrlResource(path.toUri());

			return ResponseEntity.ok().contentType(MediaType.parseMediaType("application/octet-stream"))
					.header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + resource.getFilename() + "\"")
					.body(resource);
		} catch (Exception e) {
			resp.setTipoMensaje(Mensajes.TIPO_ERROR.getMensaje());
			resp.setMensaje(Mensajes.MSG_ERROR.getMensaje());
			Map<String, Object> data = new HashMap<String, Object>();
			data.put("error", ExceptionUtils.getStackTrace(e));
			return null;
		}
	}

	

}
