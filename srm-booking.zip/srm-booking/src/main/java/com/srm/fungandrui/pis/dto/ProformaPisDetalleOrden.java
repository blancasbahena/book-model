package com.srm.fungandrui.pis.dto;

import lombok.Data;

@Data
public class ProformaPisDetalleOrden {
	
	private String numeroOrden;
	private String posicion;
	private Double poTotalQuantity;
	private String material;
	private String descripcion;
	private Integer masterCart;
	private Double volumenCart;
	private Double volumenMaster;
	private Double pesoCart;
	private Double pesoMaster;
	private Double volumenCalculado;
	private Double pesoCalculado;
	private String shippingDate;
	private String moneda;
	private String cliente;
	private String marcaComercial;
	private String claveProducto; 
	private Double precioUnitario;
	private String unidadMedida;
	private String condicionPago;
	private Boolean isFoc;
	private Boolean isOtherItem;
	private String centro;
	private String planeador;
	private String shippingPort;
	private String contenedor;
	private String company;
	
	public ProformaPisDetalleOrden(String numeroOrden, String posicion, Double poTotalQuantity, String material,
			String descripcion, Integer masterCart, Double volumenCart, Double volumenMaster, Double pesoCart,
			Double pesoMaster, String shippingDate, String moneda, String cliente,
			String marcaComercial, String claveProducto, Double precioUnitario, String unidadMedida, String condicionPago,
			String centro, String planeador, String shippingPort, String contenedor, String company) {
		super();
		this.numeroOrden = numeroOrden;
		this.posicion = posicion;
		this.poTotalQuantity = poTotalQuantity;
		this.material = material;
		this.descripcion = descripcion;
		this.masterCart = masterCart;
		this.volumenCart = volumenCart;
		this.volumenMaster = volumenMaster;
		this.pesoCart = pesoCart;
		this.pesoMaster = pesoMaster;
		this.shippingDate = shippingDate;
		this.moneda= moneda;
		this.cliente= cliente;
		this.marcaComercial= marcaComercial;
		this.claveProducto= claveProducto;
		this.precioUnitario = precioUnitario;
		this.unidadMedida = unidadMedida;
		this.condicionPago = condicionPago;
		this.centro = centro;
		this.planeador = planeador;
		this.shippingPort = shippingPort;
		this.contenedor = contenedor;
		this.company = company;
	}

}
