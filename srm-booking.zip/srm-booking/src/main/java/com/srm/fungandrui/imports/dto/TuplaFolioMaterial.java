package com.srm.fungandrui.imports.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TuplaFolioMaterial {

	private String folio;
	private Integer material;
	 
}
