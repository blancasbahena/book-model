package com.srm.fungandrui.facturacion.models;

import lombok.Data;
import lombok.ToString;
@ToString
@Data
public class ItemFactura {
	
	private String ebelp;
	private String ebeln;
	private Double menge;
	private String msj;

}
