package com.srm.fungandrui.itemsdirectos.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.srm.fungandrui.itemsdirectos.dto.Items;
import com.srm.fungandrui.itemsdirectos.dto.ItemsDirectosDTO;
import com.srm.fungandrui.itemsdirectos.dto.ItemsSeleccionados;
import com.srm.fungandrui.itemsdirectos.service.ItemsDirectosService;
import com.srm.pli.bo.SarDetalleBO;
import com.srm.pli.dao.SAR_CDI_DAO;
import com.srm.pli.dao.SarDetailDao;
import com.srm.pli.utils.FuncionesComunesPLI;

@Service
public class ItemsDirectosServiceImpl implements ItemsDirectosService {
	
	

	@Override
	public void marcarProyeccionBOItemsDirectos(ItemsDirectosDTO itemsDirectosDTO) {
		
		for(Items obj : itemsDirectosDTO.getListaItems()) {
			if(obj.getIsCheck() != null) {
				SarDetailDao.getInstance().marcarProyeccionBOItemsDirectos(true, obj.getPo(), obj.getPosicion(), itemsDirectosDTO.getFolio());
			} else {
				SarDetailDao.getInstance().marcarProyeccionBOItemsDirectos(false, obj.getPo(), obj.getPosicion(), itemsDirectosDTO.getFolio());
			}
		}
		
		SAR_CDI_DAO.actualizaComentarioItemsDirectos(itemsDirectosDTO.getComentario(), itemsDirectosDTO.getFolio());
		
		FuncionesComunesPLI.reiniciaMapaDetalle();
		
	}

	@Override
	public void borrarProyeccionBOItemsDirectos(Integer folio) {
		
		SarDetailDao.getInstance().borrarProyeccionBOItemsDirectos(folio);
		SAR_CDI_DAO.borrarComentarioItemsDirectos(folio);
		
		FuncionesComunesPLI.reiniciaMapaDetalle();
		
	}

	@Override
	public HashMap<String, ItemsSeleccionados> obtenerItemsSeleccionados(Integer folio) {
		
		HashMap<String, ItemsSeleccionados> listaItems = new HashMap<String, ItemsSeleccionados>();
		List<ItemsSeleccionados> response = SarDetailDao.obtenerItemsSeleccionados(folio);
		
		for(ItemsSeleccionados obj : response) {
			listaItems.put(obj.getFolio() + "|" + obj.getPo() + "|" + obj.getPosicion() , obj);
		}
		
		return listaItems;
		
	}

}
