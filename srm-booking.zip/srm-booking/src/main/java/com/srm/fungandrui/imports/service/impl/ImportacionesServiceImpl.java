package com.srm.fungandrui.imports.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.srm.fungandrui.imports.service.ImportacionesService;
import com.srm.pli.ws.vo.ResponseImportsVO;


@Service
public class ImportacionesServiceImpl implements ImportacionesService {
	
	
	@Autowired
	ImportsServiceClient tsc;
	
	
	@Override
	public ResponseImportsVO downloadFileTopReglas() throws Exception {
		tsc.setClient("sharepoint/download");
		ResponseImportsVO output = this.tsc.getRequest("","get");
		return output;
	}

}
