package com.srm.fungandrui.pis.service.impl;

import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.mail.internet.InternetAddress;

import org.springframework.stereotype.Service;

import com.google.gson.Gson;
import com.srm.fungandrui.pis.dto.FullProformaInvoiceDTO;
import com.srm.fungandrui.pis.dto.ProformaDetalleDTO;
import com.srm.fungandrui.pis.dto.ProformaPdfDTO;
import com.srm.fungandrui.pis.service.EnvioCorreoPISService;
import com.srm.pli.utils.CorreoUtils;
import com.srm.pli.utils.FuncionesComunesPLI;
import com.srm.pli.utils.PropertiesDb;
import com.truper.businessEntity.ImportacionesProveedoresBean;
import com.truper.businessEntity.PlaneadorBean;
import com.truper.businessEntity.ProductoBean;
import com.truper.businessEntity.ProductoCentro;
import com.truper.businessEntity.UnidadNegocio;
import com.truper.publish.Publisher;

import lombok.extern.log4j.Log4j2;
import com.srm.fungandrui.pis.dto.FileSignedDTO;
@Log4j2
@Service
public class EnvioCorreoPISServiceImpl implements EnvioCorreoPISService {

	private final boolean DURABLE = true;
	private final boolean EXCLUSIVE = false;
	private final boolean AUTO_DELETE = false;

	@Override
	public void enviarCorreoPIS(List<FileSignedDTO> objetoPdf, ProformaPdfDTO pdfDTO, FullProformaInvoiceDTO dto,String fileName)
			throws ParseException {
		InternetAddress[] destinatarios = obtenerMailsTO(dto);
		String[] toMail = getArrayStringsFromAddress(destinatarios);
		String HOST = PropertiesDb.getInstance().getString("rabbit.ws.pis.host");
		Integer PORT = PropertiesDb.getInstance().getInteger("rabbit.ws.pis.port");
		String PASS = PropertiesDb.getInstance().getString("rabbit.ws.pis.pwd");
		String USER = PropertiesDb.getInstance().getString("rabbit.ws.pis.user");
		String VIRTUAL_SERVICE = PropertiesDb.getInstance().getString("rabbit.ws.pis.virtualService");
		String EXCHANGE_NAME = PropertiesDb.getInstance().getString("rabbit.ws.pis.exchangeName");
		String ROUTING_KEY_FR_PIS = PropertiesDb.getInstance().getString("rabbit.ws.routingKey-fr-pis");
		String QUEUE_FR_PIS = PropertiesDb.getInstance().getString("rabbit.ws.queue-fr-pis");
		String MAIL_SENDER_PIS = PropertiesDb.getInstance().getString("mail.sender.pis");
		String MAIL_TEMPLATE_SIN_PRECIOS = PropertiesDb.getInstance().getString("mail.template.pis.sinprecios");
		String MAIL_TEMPLATE_CON_PRECIOS = PropertiesDb.getInstance().getString("mail.template.pis.conprecios");
		String MAIL_TEMPLATE_SIN_DIFERENCIA = PropertiesDb.getInstance().getString("mail.template.pis.sindiferencia");
		String DEBUG = PropertiesDb.getInstance().getString("mail.debug.pis");
		String MAIL_DEBUG = PropertiesDb.getInstance().getString("mail.debug.correos.pis");
		String MAIL_SUBJECT = PropertiesDb.getInstance().getString("mail.subject.pis");
		String[] MAIL_CONTROL_DOCUMENTAL = PropertiesDb.getInstance().getString("mail.correo.control.documental").trim().split(";");
		String[] MAIL_PROFORMA_LOGISTICA = PropertiesDb.getInstance().getString("mail.correo.proforma.logistica").trim().split(";");
		String[] toDebug = MAIL_DEBUG.trim().split(";");
		String gsonM = "";
		List<String> to = new ArrayList<>();
		List<String> cc = new ArrayList<>();
		List<String> correosDebug = new ArrayList<>();
		 /**
		  *  se obtienen los datos de planeador del mapa de planeadores y se agregan a la lista de distibucion,
		  *  se valida que el objeto no este vacio y que el correo no este duplicado en el arrglo de cc o correosDebug 
		  */
		String planeador = "";
		try {
			for (ProformaDetalleDTO detalle : dto.getProformaDetalleLst()) {
				planeador = detalle.getPlaneador();
				PlaneadorBean plannerObj = FuncionesComunesPLI.planners.get(detalle.getPlaneador());
				if(plannerObj != null) {
					for (String correo : plannerObj.getCorreos()) {
						if (!cc.contains(correo)) {
							cc.add(correo);
							correosDebug.add(correo);
						}
					}
					if (!cc.contains(plannerObj.getCorreoGerente())) {
						cc.add(plannerObj.getCorreoGerente());
						correosDebug.add(plannerObj.getCorreoGerente());
					}
				}
			}					
		}catch(Exception e){
			log.error("No se puede anexar correos de confrimador y gerente: {} , error ::: {}", planeador , e);	
		}
		if (DEBUG.equals("true")) {
			to.addAll(Arrays.asList(toDebug));
			cc = new ArrayList<>();
			correosDebug.addAll(Arrays.asList(MAIL_CONTROL_DOCUMENTAL));
			correosDebug.addAll(Arrays.asList(MAIL_PROFORMA_LOGISTICA));
			correosDebug.addAll(Arrays.asList(toMail));
		} else {
			to.addAll(Arrays.asList(MAIL_CONTROL_DOCUMENTAL));
			to.addAll(Arrays.asList(MAIL_PROFORMA_LOGISTICA));
			to.addAll(Arrays.asList(toMail));
			correosDebug.addAll(Arrays.asList(toDebug));
		}

		ImportacionesProveedoresBean proveedor = FuncionesComunesPLI.getProveedor(dto.getProformaInvoice().getProveedor());		
		Map<String, Object> params = new HashMap<>();
		Map<String, Object> data = new HashMap<>();
		data.put("supplier", proveedor.getNombreProveedor());
		data.put("po", dto.getProformaInvoice().getNoOrden().trim());
		List<PIS> listPIS = new ArrayList<PIS>();
		boolean modificaShipping = false;
		boolean modificaCantidad = false;
		boolean modificaPrecio = false;

		DecimalFormat df = new DecimalFormat("#,###.00");
		DecimalFormat dfdecimals = new DecimalFormat("#,###.0000");
		DecimalFormat dfc = new DecimalFormat("#,###");
		DateFormat fromFormate = new SimpleDateFormat("yyyyMMdd");
		DateFormat toFormate = new SimpleDateFormat("dd/MM/yyyy");

		for (ProformaDetalleDTO obj : dto.getProformaDetalleLst()) {
			if (obj.isFlgModShipping()) {
				modificaShipping = true;
			}
			if (obj.isFlgModCantidad()) {
				modificaCantidad = true;
			}
			if (obj.isFlgModPrice()) {
				modificaPrecio = true;
			}

			PIS pis = new PIS();
			pis.setPosition(obj.getPosicion().toString());

			pis.setQuantity(dfc.format(obj.getCantidadOriginal()));
			pis.setQuantityEnviado(dfc.format(obj.getCantidadEnviada()));

			Date d = fromFormate.parse(obj.getShippingDate().toString());
			Date d1 = fromFormate.parse(obj.getShippingDateEnviado().toString());

			pis.setShippingDate(toFormate.format(d));
			pis.setShippingDateEnviado(toFormate.format(d1));

			pis.setTotalAmount(df.format(obj.getMontoOriginal().doubleValue()));
			pis.setTotalAmountEnviado(df.format(obj.getMontoEnviado().doubleValue()));

			pis.setUnitPrice(dfdecimals.format(obj.getPrecioUnitarioOriginal().doubleValue()));
			pis.setUnitPriceEnviado(dfdecimals.format(obj.getPrecioUnitarioEnviado().doubleValue()));

			pis.setWeight(df.format(obj.getPesoOriginal()));
			pis.setWeightEnviado(df.format(obj.getPesoEnviado()));

			pis.setVolume(df.format(obj.getVolumenOriginal()));
			pis.setVolumeEnviado(df.format(obj.getVolumenEnviado()));

			listPIS.add(pis);
		}

		Map<String, Object> data1 = new HashMap<>();

		data1.put("modificaShipping", modificaShipping);
		data1.put("modificaCantidad", modificaCantidad);
		data1.put("modificaPrecio", modificaPrecio);

		data1.put("pis", listPIS);

		params.put("data", data);
		params.put("debug", DEBUG);
		params.put("debugTO", correosDebug);
		params.put("debugCC", "");
		params.put("data1", data1);
 
		List<AtachFiles> files = new ArrayList<>(); 
		for(FileSignedDTO dtoelemento:objetoPdf) {
			AtachFiles atachFiles2 = new AtachFiles();
			atachFiles2.setNombre(dtoelemento.getName());
			atachFiles2.setFile(dtoelemento.getFile()); 
			files.add(atachFiles2); 
		}	

		EnvioCorreoDTO envioCorreoDTO = new EnvioCorreoDTO();
		envioCorreoDTO.setTo(to);
		envioCorreoDTO.setCc(cc);
		envioCorreoDTO.setSubject(MAIL_SUBJECT + " " + dto.getProformaInvoice().getNoOrden().trim());

		if (!modificaShipping && !modificaCantidad && !modificaPrecio) {
			envioCorreoDTO.setTemplate(MAIL_TEMPLATE_SIN_DIFERENCIA);
		} else if (modificaPrecio) {
			envioCorreoDTO.setTemplate(MAIL_TEMPLATE_CON_PRECIOS);
		} else {
			envioCorreoDTO.setTemplate(MAIL_TEMPLATE_SIN_PRECIOS);
		}

		envioCorreoDTO.setSender(MAIL_SENDER_PIS);
		envioCorreoDTO.setParams(params);
		envioCorreoDTO.setFiles(files);

		Gson gson = new Gson();
		gsonM = gson.toJson(envioCorreoDTO);
		Publisher.publish(HOST, PORT, USER, PASS, VIRTUAL_SERVICE, QUEUE_FR_PIS, EXCHANGE_NAME, ROUTING_KEY_FR_PIS,
				null, gsonM, DURABLE, EXCLUSIVE, AUTO_DELETE);

	}

	private InternetAddress[] obtenerMailsTO(FullProformaInvoiceDTO dto) {

		ImportacionesProveedoresBean supplier = FuncionesComunesPLI
				.getProveedor(dto.getProformaInvoice().getProveedor());
		Map<String, ImportacionesProveedoresBean> suppliersData = new HashMap<String, ImportacionesProveedoresBean>();

		Map<String, UnidadNegocio> unidades = FuncionesComunesPLI.mapaUnidadesNeg;
		Map<String, String> unidadesNeg = FuncionesComunesPLI.mapaCelulasUnidadNegocio;
		Map<String, UnidadNegocio> uNegData = new HashMap<String, UnidadNegocio>();
		Set<String> MAIL = new HashSet<String>();

		if (supplier != null) {
			suppliersData.put(supplier.getClaveProveedor(), supplier);
		}

		for (ProformaDetalleDTO detalle : dto.getProformaDetalleLst()) {

			if (detalle.getCentro() != null && !"".equals(detalle.getCentro())) {
				ProductoBean p = FuncionesComunesPLI.productos.get(detalle.getItem() + "");
				if (p != null && p.getProductoCentro() != null) {
					Map<String, ProductoCentro> mapaProdCentro = p.getProductoCentro();
					String centro = p.isMateriaPrima() ? detalle.getCentro() : "P5";
					ProductoCentro prodCentro = mapaProdCentro.get(centro);
					String cellCode = "";
					if (prodCentro != null) {
						cellCode = prodCentro.getCellCode();
						String nombreUnidad = unidadesNeg != null ? unidadesNeg.get(cellCode) : null;
						if (nombreUnidad == null) {
							continue;
						}
						UnidadNegocio unidadNeg = unidades.get(nombreUnidad);
						uNegData.put(String.valueOf(unidadNeg.getId()), unidadNeg);
					}
				}
			}

		}

		Map<String, InternetAddress[]> mapaDestinatarios = new HashMap<String, InternetAddress[]>();
		StringBuilder stringMails = new StringBuilder();

		stringMails = new StringBuilder();
		Map<String, ImportacionesProveedoresBean> mapaProveedores = suppliersData;
		if (mapaProveedores != null) {
			for (Map.Entry<String, ImportacionesProveedoresBean> tmp : mapaProveedores.entrySet()) {
				stringMails.append(tmp.getValue().getEmail()).append(";");
			}
		}

		if (stringMails != null && stringMails.length() > 0) {
			mapaDestinatarios.put("proveedores", CorreoUtils.getInstance()
					.getAddress(CorreoUtils.getInstance().getArrayCorreos(stringMails.toString())));
			
			MAIL.addAll(CorreoUtils.getInstance().getListStringsFromAddress(mapaDestinatarios.get("proveedores")));
		}

		/*--------------------------------------------- UNIDAD DE NEGOCIO -------------------------------------------------------*/
		stringMails = new StringBuilder();
		Map<String, UnidadNegocio> buData = uNegData;
		if (buData != null) {
			for (Map.Entry<String, UnidadNegocio> tmp : buData.entrySet()) {
				stringMails.append(tmp.getValue().getMailContacto()).append(";");
			}
		}

		if (stringMails != null && stringMails.length() > 0) {
			mapaDestinatarios.put("bu", CorreoUtils.getInstance()
					.getAddress(CorreoUtils.getInstance().getArrayCorreos(stringMails.toString())));
			
			MAIL.addAll(CorreoUtils.getInstance().getListStringsFromAddress(mapaDestinatarios.get("bu")));
		}

		return CorreoUtils.getInstance().getAddress(MAIL.toArray(new String[0]));

	}

	private String[] getArrayStringsFromAddress(InternetAddress[] to) {
		StringBuilder toString = new StringBuilder();

		for (InternetAddress item : to) {
			toString.append(item.getAddress());
			toString.append(";");
		}
		return toString.toString().split(";");
	}

}
