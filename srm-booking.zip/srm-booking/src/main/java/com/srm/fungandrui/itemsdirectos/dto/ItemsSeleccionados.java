package com.srm.fungandrui.itemsdirectos.dto;

import java.io.Serializable;

import lombok.Data;

@Data
public class ItemsSeleccionados implements Serializable {

	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -9201330759060686168L;
	private Integer folio;
	private String po;
	private Integer posicion;
	private boolean eliminarProyeccion;

}
