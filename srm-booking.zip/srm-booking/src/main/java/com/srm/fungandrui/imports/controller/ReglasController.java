package com.srm.fungandrui.imports.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.ws.rs.core.Context;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.google.gson.JsonObject;
import com.srm.fungandrui.imports.service.ImportsReglasService;
import com.srm.pli.enums.Mensajes;
import com.srm.pli.ws.vo.ResponseImportsVO;
import com.truper.businessEntity.UserBean;
import com.truper.infra.businessEntities.Usuario;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
@RequestMapping("/imports/reglas")
public class ReglasController {

	@Autowired
	ImportsReglasService importsReglasService;

	@PostMapping("/productos/existeEnReglas")
	public ResponseEntity<ResponseImportsVO> getExisteProductoEnReglas(@RequestBody JsonObject codigos) {
		log.info("[/productos/]::Entrando al REST Existe en reglas post:");
		ResponseImportsVO response = null;
		try {

			response = importsReglasService.getExistsInReglas(codigos);
			return ResponseEntity.ok(response);
		} catch (Exception e) {
			response.setTipoMensaje(Mensajes.TIPO_ERROR.getMensaje());
			response.setMensaje(Mensajes.MSG_ERROR.getMensaje());
			Map<String, Object> data = new HashMap<String, Object>();
			data.put("error", ExceptionUtils.getStackTrace(e));
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
		}
	}

	@PostMapping("/obtenReglasProductos")
	public ResponseEntity<ResponseImportsVO> getReglasProductos(@RequestBody JsonObject codigos, HttpServletRequest request) {
		log.info("[/productos/]::Entrando al REST Existe en reglas post:");
		UserBean usuario = null;
		HttpSession session = request.getSession(false);
		if (session != null) {
			 usuario = (UserBean) session.getAttribute("usuario");
		}
		
		if( usuario.isVeTruper() ) {
			ResponseImportsVO response = null;
			try {
				
				response = importsReglasService.getReglasTruperProductos(codigos);
				return ResponseEntity.ok(response);
			} catch (Exception e) {
				response.setTipoMensaje(Mensajes.TIPO_ERROR.getMensaje());
				response.setMensaje(Mensajes.MSG_ERROR.getMensaje());
				Map<String, Object> data = new HashMap<String, Object>();
				data.put("error", ExceptionUtils.getStackTrace(e));
				return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
			}
		}else {
			ResponseImportsVO response = null;
			try {
				response = importsReglasService.getReglasComercioProductos(codigos);
				return ResponseEntity.ok(response);
			} catch (Exception e) {
				response.setTipoMensaje(Mensajes.TIPO_ERROR.getMensaje());
				response.setMensaje(Mensajes.MSG_ERROR.getMensaje());
				Map<String, Object> data = new HashMap<String, Object>();
				data.put("error", ExceptionUtils.getStackTrace(e));
				return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
			}
		}

		/*
		ResponseImportsVO response = null;
		try {
			response = importsReglasService.getReglasProductos(codigos);
			return ResponseEntity.ok(response);
		} catch (Exception e) {
			response.setTipoMensaje(Mensajes.TIPO_ERROR.getMensaje());
			response.setMensaje(Mensajes.MSG_ERROR.getMensaje());
			Map<String, Object> data = new HashMap<String, Object>();
			data.put("error", ExceptionUtils.getStackTrace(e));
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
		}
		*/
	}

	@GetMapping("/delete/producto/{producto}")
	public ResponseEntity<ResponseImportsVO> deleteRegla(@PathVariable String producto) {
		log.info("Entro a /imports/reglas ::: [/producto/{producto}]");
		ResponseImportsVO response = null;
		try {
			response = importsReglasService.deleteRegla(producto);
			log.info("Entro a /imports/reglas ::: [/producto/{producto}]");
			return ResponseEntity.ok(response);
		} catch (Exception e) {
			response.setTipoMensaje(Mensajes.TIPO_ERROR.getMensaje());
			response.setMensaje(Mensajes.MSG_ERROR.getMensaje());
			Map<String, Object> data = new HashMap<String, Object>();
			data.put("error", ExceptionUtils.getStackTrace(e));
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
		}

	}

	@GetMapping("/producto/{id}")
	public ResponseEntity<ResponseImportsVO> gteReglasByVersion(@PathVariable String id) {
		log.info("[/producto/{id}]::Entrando al REST reglas get:");
		ResponseImportsVO sr = null;
		try {
			sr = importsReglasService.getReglasProducto(new Long(id));
			return ResponseEntity.ok(sr);
		} catch (Exception ex) {
			sr = new ResponseImportsVO(Mensajes.TIPO_ERROR.getMensaje(), Mensajes.MSG_ERROR.getMensaje(), "error",
					ex.getMessage());
			return ResponseEntity.status(HttpStatus.FORBIDDEN).body(sr);
		}
	}

}
