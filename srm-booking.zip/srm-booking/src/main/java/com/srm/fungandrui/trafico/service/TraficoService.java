package com.srm.fungandrui.trafico.service;

import com.srm.fungandrui.facturacion.models.Facturacion;
import com.srm.fungandrui.trafico.models.TraficoConsolVO;
import com.truper.trafico.ConsolidacionFolioDto;

public interface TraficoService {
	
	public TraficoConsolVO validaConsolidadosAceptados(String proveedor, String booking) throws Exception;
	public ConsolidacionFolioDto validaEnviadoATrafico(Facturacion factura, String status) throws ClassNotFoundException, Exception;
	public ConsolidacionFolioDto enviadoATrafico(Facturacion factura) throws ClassNotFoundException, Exception;

}
