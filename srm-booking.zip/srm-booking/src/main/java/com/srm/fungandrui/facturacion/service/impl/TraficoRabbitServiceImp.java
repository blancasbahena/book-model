package com.srm.fungandrui.facturacion.service.impl;

import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.gson.Gson;
import com.rabbitmq.client.AMQP;
import com.srm.fungandrui.facturacion.service.TraficoRabbitService;
import com.srm.fungandrui.sc.model.ResponseVO;
import com.srm.fungandrui.trafico.dao.TraficoDao;
import com.srm.pli.utils.PropertiesDb;
import com.truper.publish.Publisher;
import com.truper.trafico.ConsolidacionFolioDto;

import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
@Log4j2
@Service()
@RequiredArgsConstructor
public class TraficoRabbitServiceImp implements TraficoRabbitService {

	private final String HOST = PropertiesDb.getInstance().getString("rabbit.ws.host");
	private final Integer PORT = PropertiesDb.getInstance().getInteger("rabbit.ws.port");
	private final String PASS = PropertiesDb.getInstance().getString("rabbit.ws.pwd");
	private final String USER = PropertiesDb.getInstance().getString("rabbit.ws.user");

	private final String VIRTUAL_SERVICE = PropertiesDb.getInstance().getString("rabbit.ws.virtualService");
	private final String EXCHANGE_NAME = PropertiesDb.getInstance().getString("rabbit.ws.exchangeName");

	private final String QUEUE_SEND_TRAFICO = PropertiesDb.getInstance().getString("spring.rabbitmq.queueFungRuiTrafico");
	private final String ROUTING_KEY_SEND_TRAFICO = PropertiesDb.getInstance()
			.getString("spring.rabbitmq.routingkeyFungRuiTrafico");

	private final boolean DURABLE = true;
	private final boolean EXCLUSIVE = false;
	private final boolean AUTO_DELETE = false;

	@Autowired
	private TraficoDao traficoDao;

	@Override
	public ResponseVO envioTrafico(ConsolidacionFolioDto noFactura) {

		String gsonM = "";
		Gson gson = new Gson();
		gsonM = gson.toJson(noFactura);
		log.info(gsonM);
		Publisher.publish(HOST, PORT, USER, PASS, VIRTUAL_SERVICE, QUEUE_SEND_TRAFICO, EXCHANGE_NAME,
				ROUTING_KEY_SEND_TRAFICO, new AMQP.BasicProperties.Builder().contentType("text/plain").build(), gsonM,
				DURABLE, EXCLUSIVE, AUTO_DELETE);
		return null;
	}

	@Override
	public void procesaAceptacionTrafico(Integer sar) {

		try {
			traficoDao.actualizaEstatusAceptacion(sar);
		} catch (ClassNotFoundException | SQLException e) {
			log.error(e.getMessage());
		}

	}

	@Override
	public void procesaRechazoTrafico(Integer sar, Integer id,String observacionesTrafico) {
		try {
			traficoDao.actualizaEstatusRechazo(sar, id,observacionesTrafico);
		} catch (ClassNotFoundException | SQLException e) {
			log.error(e.getMessage());
		}

	}

}
