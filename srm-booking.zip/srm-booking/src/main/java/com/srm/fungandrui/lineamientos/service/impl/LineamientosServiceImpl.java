package com.srm.fungandrui.lineamientos.service.impl;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.srm.fungandrui.lineamientos.dao.LineamientosDao;
import com.srm.fungandrui.lineamientos.dto.GrdLineamientosAccionesDto;
import com.srm.fungandrui.lineamientos.dto.SarLineamientosDto;
import com.srm.fungandrui.lineamientos.service.LineamientosService;
import com.srm.pli.bo.SarBO;
import com.srm.pli.bo.SarDetalleBO;
import com.srm.pli.helper.FormatSARDetalle;
import com.srm.pli.utils.DateUtils;
import com.srm.pli.utils.FuncionesComunesPLI;
import com.srm.pli.utils.ProductoUtils;
import com.truper.businessEntity.ProductoBean;

import lombok.extern.log4j.Log4j2;

@Service
@Log4j2

public class LineamientosServiceImpl implements LineamientosService{
	
	@Autowired
	private LineamientosDao lineamientosDao;

	@Override
	public List<SarLineamientosDto> getSars(Integer estatus)throws SQLException, ClassNotFoundException {
		log.info("Get sar :");
		return lineamientosDao.getSars(estatus);
	}

	@Override
	public Integer actualizarSar(GrdLineamientosAccionesDto dto) throws SQLException, ClassNotFoundException {
		return lineamientosDao.actualizarSar(dto);
	}

	@Override
	public Boolean validacionIdaBO(Integer folio, Integer fechaGrd,boolean verLogsLineacionIDA) throws SQLException, ClassNotFoundException {
		SarBO sar = new SarBO();	
		Date goodsReadyDate=null;
		Integer etdPlanner;
		Integer etdReal;
		Integer etdModificada;
		Integer etdProveedor;
		String safetyStockMinimo = null;
		sar.setFolio(folio);
		List<SarDetalleBO> lstDet = null;
		Integer idaMenor =0;
		Integer nuevoIda;
		BigDecimal ventaDiaria = null;
		BigDecimal precioSinIva=null;
		try {
			lstDet = FuncionesComunesPLI.getDetalleSAR(sar) == null? new ArrayList<SarDetalleBO>(): FuncionesComunesPLI.getDetalleSAR(sar);
		} catch (Exception e) {
			log.error(e.getMessage());
		}
		SarBO sarSeach = new SarBO();
		sarSeach.setFolio(folio);
		SarBO sarResult = null;
		sarResult = FuncionesComunesPLI.dameSARByFolio(sarSeach);
		if(verLogsLineacionIDA)
			log.info("*************************************LOGS DE LINEAMIENTOS SAR  : {} ",folio);
		List<FormatSARDetalle> lstFormat = new ArrayList<>();
		ProductoBean p = null;
		for (SarDetalleBO det : lstDet) {
			FormatSARDetalle formatDet = new FormatSARDetalle(det, sarResult.dameETDDelSAR());
			p = ProductoUtils.getInstance().getProducto(det.getMaterial().toString());
			lstFormat.add(formatDet);	
		}
		if (!lstFormat.isEmpty()) {
			idaMenor=  lstFormat.get(0).getIda();
			safetyStockMinimo= lstFormat.get(0).getDaysSafetyStock();
			ventaDiaria  = p.getVentaMrp();
			precioSinIva= p.getPrecioDistSinIvaMenos20();
		}
		goodsReadyDate = sarResult.getGoodsReadyDate();
		etdPlanner = sarResult.getEtdPlanner();
		etdReal = sarResult.getEtdReal();
		etdModificada = sarResult.getEtdModificada();
		etdProveedor= sarResult.getEtdProveedor();
		if(verLogsLineacionIDA) {
			log.info("*************************************goodsReadyDate : {} ",goodsReadyDate);
			log.info("*************************************etdPlanner     : {} ",etdPlanner);
			log.info("*************************************etdReal        : {} ",etdReal); 
			log.info("*************************************etdModificada  : {} ",etdModificada);
			log.info("*************************************etdProveedor   : {} ",etdProveedor);
		}
		Integer nuevaFechaEmbarque = fechaGrd;
		Integer goodReadyInt = DateUtils.getInstance().parseDateToInt(goodsReadyDate);
		Boolean fechaGRDMayor = false;
		if(verLogsLineacionIDA) {
			log.info("*************************************goodReadyInt : {} ",goodReadyInt);
			log.info("*************************************fechaGrd     : {} ",fechaGrd);
			log.info("*************************************nuevaFechaEm : {} ",nuevaFechaEmbarque);
		}
		if(goodReadyInt >= fechaGrd) {
			return false;
		}
		
		if (goodReadyInt>nuevaFechaEmbarque) {
			fechaGRDMayor=true;
		}
		Integer totalDiasTranscurridos=0;
		if(fechaGRDMayor) {
			totalDiasTranscurridos = goodReadyInt- nuevaFechaEmbarque;
		}else {
			totalDiasTranscurridos= nuevaFechaEmbarque- goodReadyInt;
		}
		for (FormatSARDetalle det : lstFormat) {
			if (det.getIda() < idaMenor) {
                idaMenor= det.getIda();
                safetyStockMinimo= det.getDaysSafetyStock();
                
            }
		}
		if(verLogsLineacionIDA) {
			log.info("*************************************idaMenor     : {} ",idaMenor);
			log.info("*************************************totalDiasTran: {} ",totalDiasTranscurridos);
		}
		if (idaMenor == 0) {
			nuevoIda = totalDiasTranscurridos;
		} else {
			if (fechaGRDMayor) {
				nuevoIda = idaMenor - totalDiasTranscurridos;
			} else {
				nuevoIda = totalDiasTranscurridos + idaMenor;
			}
		}
		if(verLogsLineacionIDA)
			log.info("*************************************nuevoIda     : {} ",nuevoIda);	
		Integer safetyStockMinimoInt=0;
		if (!safetyStockMinimo.equals("N.D")) {
			safetyStockMinimoInt =Integer.parseInt(safetyStockMinimo);
		}
		if(verLogsLineacionIDA) {
			log.info("*************************************safetyStockMinimoInt  : {} ",safetyStockMinimoInt);
			log.info("*************************************safetyStockMinimo     : {} ",safetyStockMinimo);
		}
		BigDecimal totalVentaPronosticada = null;
		BigDecimal totalVenta= null;
		BigDecimal nuevoIdaBigDecimal =null;
		Boolean isIdamenor=false;
		if (nuevoIda<0) {
			if (ventaDiaria!=null ) {	
				isIdamenor=true;
				nuevoIdaBigDecimal = new BigDecimal(nuevoIda);
				totalVentaPronosticada = nuevoIdaBigDecimal.multiply(ventaDiaria);
				totalVenta = totalVentaPronosticada.multiply(precioSinIva);
			} 
		}
		if(nuevoIdaBigDecimal==null && totalVenta==null) {
			nuevoIdaBigDecimal= new BigDecimal(0);
			totalVenta= new BigDecimal(0);
		}
		if(verLogsLineacionIDA) {
			log.info("*************************************ventaDiaria           : {} ",ventaDiaria);
			log.info("*************************************nuevoIda              : {} ",nuevoIda);
			log.info("*************************************isIdamenor            : {} ",isIdamenor);
			log.info("*************************************nuevoIdaBigDecimal    : {} ",nuevoIdaBigDecimal);
			log.info("*************************************totalVentaPronosticada: {} ",totalVentaPronosticada);
			log.info("*************************************totalVenta            : {} ",totalVenta);
		}
		
		if (nuevoIda< safetyStockMinimoInt ||( isIdamenor && (isIdamenor&& nuevoIdaBigDecimal.compareTo(totalVenta)<0) )) {
			return true;
		}
		return false;
		
	}

}
