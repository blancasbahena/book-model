package com.srm.fungandrui.facturacion.dto;

import java.io.Serializable;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class RechazadosFacturacionFilter implements Serializable {


	/**
	 * 
	 */
	private static final long serialVersionUID = 4992923205112345873L;
	private String folio;
	private String po;
	private String blNumber;
	private String booking;
	private String container;
	private String supplier;
	private String carrier;
	private String analyst;
	private String invoiceNumber;
	private String priority;
	private String etaFrom;
	private String etaTo;
	private String pod;

}
