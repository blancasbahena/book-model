package com.srm.fungandrui.sc.model;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import com.srm.pli.enums.Mensajes;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ResponseVO implements Serializable {

	private static final long serialVersionUID = 1L;
	private String tipoMensaje;
	private String mensaje;
	private Map<String, Object> responseObject = new HashMap<>();
	
	public void resetResponseObject()
	{
		responseObject.clear();
	}
	
	public ResponseVO createWarning()
	{		
		ResponseVO responseVO = new ResponseVO()
		{
			private static final long serialVersionUID = 1L;
		};
		
		responseVO.setTipoMensaje(Mensajes.TIPO_WARNING.getMensaje());
		responseVO.setMensaje(Mensajes.MSG_WARNING.getMensaje());
		return responseVO;
	}
	
	public ResponseVO createWarning(String mensaje)
	{
		ResponseVO responseVO = new ResponseVO()
		{
			private static final long serialVersionUID = 1L;
		};
		
		responseVO.setTipoMensaje(Mensajes.TIPO_WARNING.getMensaje());
		responseVO.setMensaje(mensaje);		
		return responseVO;
	}
	
	public ResponseVO createWarning(String key, Object valor)
	{	
		ResponseVO responseVO = new ResponseVO()
		{
			private static final long serialVersionUID = 1L;
			
			@Override
			public ResponseVO createWarning()
			{
				return super.createWarning();
			}
		};

		responseObject.put(key, valor);
		responseVO.setResponseObject(responseObject);
		responseVO.setTipoMensaje(responseVO.createWarning().getTipoMensaje());
		responseVO.setMensaje(responseVO.createWarning().getMensaje());
		return responseVO;
	}
	
	public ResponseVO createWarning(String key, Object valor, boolean reset)
	{			
		ResponseVO responseVO = new ResponseVO()
		{
			private static final long serialVersionUID = 1L;
			
			@Override
			public ResponseVO createWarning()
			{
				return super.createWarning();
			}
		};

		if(reset)
			resetResponseObject();
		
		responseObject.put(key, valor);
		responseVO.setResponseObject(responseObject);
		responseVO.setTipoMensaje(responseVO.createWarning().getTipoMensaje());
		responseVO.setMensaje(responseVO.createWarning().getMensaje());
		return responseVO;
	}
	
	public ResponseVO createError()
	{		
		ResponseVO responseVO = new ResponseVO()
		{
			private static final long serialVersionUID = 1L;
		};
		
		responseVO.setTipoMensaje(Mensajes.TIPO_ERROR.getMensaje());
		responseVO.setMensaje(Mensajes.MSG_ERROR.getMensaje());
		return responseVO;
	}	
	
	public ResponseVO createError(String error)
	{
		ResponseVO responseVO = new ResponseVO()
		{
			private static final long serialVersionUID = 1L;
		};
		
		responseVO.setTipoMensaje(Mensajes.TIPO_ERROR.getMensaje());
		responseVO.setMensaje(error);		
		return responseVO;		
	}
	
	public ResponseVO createError(String key, Object valor)
	{
		ResponseVO responseVO = new ResponseVO()
		{
			private static final long serialVersionUID = 1L;
			
			@Override
			public ResponseVO createError()
			{
				return super.createError();
			}
		};

		responseObject.put(key, valor);
		responseVO.setResponseObject(responseObject);
		responseVO.setTipoMensaje(responseVO.createError().getTipoMensaje());
		responseVO.setMensaje(responseVO.createError().getMensaje());
		return responseVO;
	}
	
	public ResponseVO createError(String key, Object valor, boolean reset)
	{
		ResponseVO responseVO = new ResponseVO()
		{
			private static final long serialVersionUID = 1L;
			
			@Override
			public ResponseVO createError()
			{
				return super.createError();
			}
		};
		
		if(reset)
			resetResponseObject();

		responseObject.put(key, valor);
		responseVO.setResponseObject(responseObject);
		responseVO.setTipoMensaje(responseVO.createError().getTipoMensaje());
		responseVO.setMensaje(responseVO.createError().getMensaje());
		return responseVO;
	}
	
	public ResponseVO createSuccess()
	{		
		ResponseVO responseVO = new ResponseVO()
		{
			private static final long serialVersionUID = 1L;
		};
		
		responseVO.setTipoMensaje(Mensajes.TIPO_EXITO.getMensaje());
		responseVO.setMensaje(Mensajes.MSG_EXITO.getMensaje());
		return responseVO;
	}
	
	public ResponseVO createSuccess(String mensaje)
	{
		ResponseVO responseVO = new ResponseVO()
		{
			private static final long serialVersionUID = 1L;
		};
		
		responseVO.setTipoMensaje(Mensajes.TIPO_EXITO.getMensaje());
		responseVO.setMensaje(mensaje);		
		return responseVO;
	}
	
	public ResponseVO createSuccess(String key, Object valor)
	{
		ResponseVO responseVO = new ResponseVO()
		{
			private static final long serialVersionUID = 1L;
			
			@Override
			public ResponseVO createSuccess()
			{
				return super.createSuccess();
			}
		};

		responseObject.put(key, valor);
		responseVO.setResponseObject(responseObject);
		responseVO.setTipoMensaje(responseVO.createSuccess().getTipoMensaje());
		responseVO.setMensaje(responseVO.createSuccess().getMensaje());
		return responseVO;
	}
	
	public ResponseVO createSuccess(String key, Object valor, boolean reset)
	{
		ResponseVO responseVO = new ResponseVO()
		{
			private static final long serialVersionUID = 1L;
			
			@Override
			public ResponseVO createSuccess()
			{
				return super.createSuccess();
			}
		};
		
		if(reset)
			resetResponseObject();

		responseObject.put(key, valor);
		responseVO.setResponseObject(responseObject);
		responseVO.setTipoMensaje(responseVO.createSuccess().getTipoMensaje());
		responseVO.setMensaje(responseVO.createSuccess().getMensaje());
		return responseVO;
	}
}
