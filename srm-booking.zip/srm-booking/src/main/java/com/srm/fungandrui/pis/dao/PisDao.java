package com.srm.fungandrui.pis.dao;

import java.sql.SQLException;
import java.util.List;

import com.srm.fungandrui.pis.dto.PeticionCambioEstatusDTO;
import com.srm.fungandrui.pis.dto.ProformaDetalleDTO;
import com.srm.fungandrui.pis.dto.ProformaDetalleHistoricoDTO;
import com.srm.fungandrui.pis.dto.ProformaInvoiceDTO;
import com.srm.fungandrui.pis.dto.ProformaInvoiceHistoricoDTO;
import com.srm.fungandrui.pis.dto.SumaMontosPIDTO;

public interface PisDao {

	ProformaInvoiceDTO creaProforma(ProformaInvoiceDTO dto)  throws SQLException, ClassNotFoundException;
	void creaProformaDetalle(ProformaDetalleDTO dto) throws ClassNotFoundException, SQLException;
	void creaHistoricoProforma(ProformaInvoiceHistoricoDTO dto) throws SQLException,ClassNotFoundException;
	void creaHistoricoProformaDetalle(ProformaDetalleHistoricoDTO dto) throws ClassNotFoundException, SQLException;
	Integer actualizarProforma(ProformaInvoiceDTO dto) throws SQLException,ClassNotFoundException;
	Integer actualizarSendProforma(ProformaInvoiceDTO dto) throws SQLException,ClassNotFoundException;
	void actualizarProformaDetalle(ProformaDetalleDTO dto) throws ClassNotFoundException, SQLException;
	void actualizarHistoricoProforma(ProformaInvoiceHistoricoDTO dto) throws SQLException,ClassNotFoundException;
	void actualizarHistoricoProformaDetalle(ProformaDetalleHistoricoDTO dto) throws ClassNotFoundException, SQLException;
	void editaProformaNumber(ProformaInvoiceDTO dto) throws ClassNotFoundException, SQLException;
	SumaMontosPIDTO obtenerMontosCantidadesModificadas(String po) throws ClassNotFoundException, SQLException;
	public ProformaInvoiceDTO getProforma(Integer idProforma) throws ClassNotFoundException, SQLException;
	public List<ProformaInvoiceDTO> getProformaByStatus(Integer idStatus) throws ClassNotFoundException, SQLException;
	public int actualizarEstatusDetalle(PeticionCambioEstatusDTO dto) throws SQLException, ClassNotFoundException;
	public int actualizarImagen(String ipPi,long idImagen,String user) throws SQLException, ClassNotFoundException;
	public int cambiaEstatusProforma(int ipPi,int status,String user) throws SQLException, ClassNotFoundException;
	public int cambiaEstatusProformas(int status,String user,int reject) throws SQLException, ClassNotFoundException;
	public List<ProformaDetalleDTO> getProformaDetalle(Integer idProforma) throws ClassNotFoundException, SQLException;
	public List<ProformaInvoiceDTO> getProformaByPOAndEstatus(String PO, Integer idStatus) throws ClassNotFoundException, SQLException;
	public List<ProformaInvoiceDTO> getProformaByPLanerAndEstatus(String planer, Integer idStatus) throws ClassNotFoundException, SQLException;
	public List<ProformaInvoiceDTO> getProformaByProveedorAndEstatus(String proveedor, Integer idStatus) throws ClassNotFoundException, SQLException;
	public int actualizarDetalleXLS(List<String> renglon) throws SQLException, ClassNotFoundException;
}
