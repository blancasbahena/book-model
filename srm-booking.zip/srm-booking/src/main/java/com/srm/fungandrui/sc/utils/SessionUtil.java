package com.srm.fungandrui.sc.utils;

import javax.servlet.http.HttpSession;

import org.springframework.web.servlet.ModelAndView;

import com.srm.fungandrui.sc.model.BeanSession;
import com.truper.businessEntity.UserBean;

public class SessionUtil {

	public static BeanSession validaSesion(HttpSession sesion) {
		BeanSession beanSession = new BeanSession();
		if (sesion != null ) {
			UserBean usuario = (UserBean) sesion.getAttribute("usuario");
			if (usuario != null) {
				beanSession.setUser(usuario);
				return beanSession;
			}
		}
		
		beanSession.setMav(new ModelAndView("../index"));
		return beanSession;
	}
	

}
