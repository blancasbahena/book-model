package com.srm.fungandrui.facturacion.reportes;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

import com.srm.fungandrui.facturacion.models.FacturacionReporte;

import lombok.extern.slf4j.Slf4j;
@Slf4j
public class ReporteFacturacion {
	
	List<FacturacionReporte> reporte= null;
	
	public ReporteFacturacion(List<	FacturacionReporte> reporte) {
		super();
		this.reporte = reporte;
	}

	public File generarReporteExcel(List<FacturacionReporte> lista, String nombreArchivo) throws IOException{
		log.info(this.getClass().getName() + "Inicio: Generar reporte Excel");
		Workbook workbook = new HSSFWorkbook();
		CellStyle cellStyle = workbook.createCellStyle();
//		cellStyle.setFillForegroundColor(IndexedColors.AQUA.getIndex());
//		cellStyle.setFillPattern((short) 1);
		crearReporteFacturaciones(lista, cellStyle, workbook, nombreArchivo);
		
	
		
		File file = new File(nombreArchivo);
		file.createNewFile();
		FileOutputStream fileOut = new FileOutputStream(file);
		
		workbook.write(fileOut);
		workbook.close();
		fileOut.close();
		log.info(this.getClass().getName() + "Fin: Se termino de generar el reporte Excel");
		return file;
	}
	
	public  void crearReporteFacturaciones(List<FacturacionReporte> lista, CellStyle cellStyle, Workbook workbook, String nombreHoja){
		String[] headersTitulos = 
				new String [] {
						"Man/Auto","Aprobacion SDI",
						"Turno","#Factura Proveedor",
						"No Factura PM","Monto USD",
						"Fecha Emision","Facturista",
						"STATUS","Incidencias Factura",
						"Comentarios Contabilidad",
						"Proveedor","ETA","Analista SDI",
						"Booking No.","Folio","BL No.",
						"POD","Shipment Type","Priority"};
		Sheet sheet = workbook.createSheet("Reporte Facturacion");
		
		int init = 0;
	
		Row row = sheet.createRow(init);
		
		for(int i = 0; i < headersTitulos.length;i++){
			Cell cellHeaders = row.createCell(i);
			sheet.autoSizeColumn(init);	
			cellHeaders.setCellValue(headersTitulos[i]);
			cellHeaders.setCellStyle(getHeaderStyle(workbook));
		}
		
		init = 1;
		for(int i = 0;i < lista.size(); i++)
		{
			row = sheet.createRow(init);
			
			
			String automatico =lista.get(i).getAutomatico() ? "Manual" : "Automatico";
			String  fechaHoraAprobacionSDI  = lista.get(i).getFechaHoraAprobacionSDI();
			String  turno = lista.get(i).getAmpm();
			String  nombreProveedor = lista.get(i).getNombreProveedor();
			String  noFacturaPM = lista.get(i).getNoFacturaPM(); 
			String  montoUSD = lista.get(i).getMontoUSD();
			String  fechaEmision = lista.get(i).getFechaEmision();
			String  facturista = lista.get(i).getFacturista();
			String  status = lista.get(i).getFacturista();
			String incidenciasEnFacturas = lista.get(i).getIncidenciasEnFacturas();
			String comentarios = lista.get(i).getComentarios();
			String facturaProvedor = lista.get(i).getFacturaProvedor();
			String eta = lista.get(i).getEta();
			String analyst = lista.get(i).getAnalyst() == null || lista.get(i).getAnalyst().equals("null") ? "  ----  " :lista.get(i).getAnalyst();
			String booking = lista.get(i).getBooking();
			String sar = lista.get(i).getSar();
			String blNumber = lista.get(i).getBlNumber();
			String pod = lista.get(i).getPod();
			String shipmentType = lista.get(i).getShipmentType();
			String priority = lista.get(i).getPriority();
			
		
			Cell cell1 = row.createCell(0);
			Cell cell2 = row.createCell(1);
			Cell cell3 = row.createCell(2);
			Cell cell4 = row.createCell(3);
			Cell cell5 = row.createCell(4);
			Cell cell6 = row.createCell(5);
			Cell cell7 = row.createCell(6);
			Cell cell8 = row.createCell(7);
			Cell cell9 = row.createCell(8);
			Cell cell10 = row.createCell(9);
			Cell cell11 = row.createCell(10);
			Cell cell12 = row.createCell(11);
			Cell cell13 = row.createCell(12);
			Cell cell14 = row.createCell(13);
			Cell cell15 = row.createCell(14);
			Cell cell16 = row.createCell(15);
			Cell cell17 = row.createCell(16);
			Cell cell18 = row.createCell(17);
			Cell cell19 = row.createCell(18);
			Cell cell20 = row.createCell(19);
			Cell cell21 = row.createCell(20);
			
			sheet.autoSizeColumn(init);
			cell1.setCellValue(automatico); 			
			cell2.setCellValue(fechaHoraAprobacionSDI);
			cell3.setCellValue(turno);
			cell4.setCellValue(nombreProveedor);
			cell5.setCellValue(noFacturaPM);
			cell6.setCellValue(montoUSD);
			cell7.setCellValue(fechaEmision);
			cell8.setCellValue(facturista);
			cell9.setCellValue(status);
			cell10.setCellValue(incidenciasEnFacturas);
			cell11.setCellValue(comentarios);
			cell12.setCellValue(facturaProvedor);
			cell13.setCellValue(eta);
			cell14.setCellValue(analyst);
			cell15.setCellValue(facturaProvedor);
			cell16.setCellValue(eta);
			cell17.setCellValue(booking);
			cell18.setCellValue(sar);
			cell19.setCellValue(blNumber);
			cell20.setCellValue(pod);
			cell21.setCellValue(shipmentType);
			init++;
			
		}
	}
	
	private  CellStyle getHeaderStyle(Workbook workbook)
	{
		CellStyle style = workbook.createCellStyle();
		HSSFFont font = (HSSFFont) workbook.createFont();
		font.setColor(HSSFColor.WHITE.index);
		font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
		style.setFillForegroundColor(HSSFColor.BLACK.index);
		style.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
		style.setFont(font);
		style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
		return style;
	}


		
	
}
