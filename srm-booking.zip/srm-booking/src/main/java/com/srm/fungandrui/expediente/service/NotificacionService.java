package com.srm.fungandrui.expediente.service;
import com.truper.expediente.NotificationDTO;
import java.util.List;
public interface NotificacionService {
	public List<NotificationDTO> getNotifications(String usuario);
	public boolean delete(Long id);
}
