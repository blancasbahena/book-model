package com.srm.fungandrui.pis.repository;

import java.util.List;

import com.srm.fungandrui.pis.dto.ProformaInvoiceDTO;

public interface ProformaInvoiceDao {
	public List<ProformaInvoiceDTO> getAll(Integer id);

	public List<ProformaInvoiceDTO> getAllInvoiceNumber();
}
