package com.srm.fungandrui.pis.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;

import org.springframework.stereotype.Repository;

import com.srm.fungandrui.pis.dto.ProformaInvoiceDTO;
import com.srm.fungandrui.pis.util.Querys;
import com.srm.pli.dao.DAOUtils;
import com.srm.pli.db.ConexionDB;

import lombok.extern.log4j.Log4j2;

@Log4j2
@Repository
public class ProformaInvoiceDAOImpl implements ProformaInvoiceDAO {

	@Override
	public List<ProformaInvoiceDTO> dateProformasCreadas(String proveedor) throws ServletException{
		List<ProformaInvoiceDTO> posCreadas = new ArrayList<>();
		Connection con = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		DAOUtils utils = new DAOUtils();
		
				
		try {
			con = ConexionDB.dameConexion();
			pst = con.prepareStatement(Querys.DATE_PROFORMAS_CREADAS);
			int cont = 1;
			
			utils.inicializaQuery(Querys.DATE_PROFORMAS_CREADAS);
			utils.ajustaParametro(cont, pst, proveedor, String.class);
			
			rs = pst.executeQuery();
			
			while(rs.next()) {
				ProformaInvoiceDTO numeroPo = new ProformaInvoiceDTO();
				numeroPo.setNoOrden(rs.getString("noOrden"));
				numeroPo.setIdPi(rs.getInt("idPi"));
				log.info("La orden de compra {} ya tiene proforma ",numeroPo);
				posCreadas.add(numeroPo);
			}
			rs.close();
			pst.close();
			
		}catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
				throw new ServletException(ex);
			}
			log.error(e.getMessage(), e);
			throw new ServletException(e);
		} catch (Exception e) {
			e.printStackTrace();
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
				throw new ServletException(ex);
			}
			log.error(e.getMessage(), e);
			throw new ServletException(e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
				throw new ServletException(sqlEx2);
			}
		}
		
		return posCreadas;
	}
	@Override
	public void actualizaPosiciones1to2(int idPi) throws ClassNotFoundException, SQLException {
		Connection conn = ConexionDB.dameConexion() ;
		try {
			PreparedStatement stmt = conn.prepareStatement(Querys.ELIMINA_POS_ENVIADAS);

			stmt.setInt(1, idPi);
			stmt.executeUpdate();
		}catch (SQLException e) {
			log.error("Error al actualizas pos de Proforma Invoice Detalle de 1 a 2 en BD... {} {}", e.getMessage(), e);
			ConexionDB.devolver(conn);
		}catch (Exception e) {
			log.error("Error en BD... {} {}", e.getMessage(), e);
			ConexionDB.devolver(conn);
		}finally {
			ConexionDB.devolver(conn);
		}
	}
}
