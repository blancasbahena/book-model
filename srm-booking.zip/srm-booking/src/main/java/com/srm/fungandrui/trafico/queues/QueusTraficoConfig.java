package com.srm.fungandrui.trafico.queues;

import java.io.IOException;
import java.nio.charset.StandardCharsets;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.google.gson.Gson;
import com.rabbitmq.client.AMQP;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.DefaultConsumer;
import com.rabbitmq.client.Envelope;
import com.srm.fungandrui.facturacion.service.TraficoRabbitService;
import com.srm.pli.utils.PropertiesDb;
import com.truper.subscribe.Subscriber;
import com.truper.trafico.DocumentosAutorizadoDTO;
import com.truper.trafico.DocumentosRechazoDTO;

import lombok.extern.log4j.Log4j2;

@Configuration
@Log4j2
public class QueusTraficoConfig {

	private final String HOST = PropertiesDb.getInstance().getString("rabbit.ws.host");
	private final Integer PORT = PropertiesDb.getInstance().getInteger("rabbit.ws.port");
	private final String PASS = PropertiesDb.getInstance().getString("rabbit.ws.pwd");
	private final String USER = PropertiesDb.getInstance().getString("rabbit.ws.user");

	private final String VIRTUAL_SERVICE = PropertiesDb.getInstance().getString("rabbit.ws.virtualService");
	private final String EXCHANGE_NAME = PropertiesDb.getInstance().getString("rabbit.ws.exchangeName");
	
	
	private final String QUEUE_FUNG_RUI_AUTORIZO=PropertiesDb.getInstance().getString("spring.rabbitmq.queueTraficoFungRuiAutorizo");
	private final String ROUTING_KEY_FUNG_RUI_AUTORIZO = PropertiesDb.getInstance().getString("spring.rabbitmq.routingkeyTraficoFungRuiAutorizo");
	
	private final String QUEUE_FUNG_RUI_RECHAZO =PropertiesDb.getInstance().getString("spring.rabbitmq.queueTraficoFungRuiRechazo");
	private final String ROUTING_KEY_FUNG_RUI_RECHAZO = PropertiesDb.getInstance().getString("spring.rabbitmq.routingkeyTraficoFungRuiRechazo");

	private final boolean AUTO_DELETE = false;
	private final boolean DURABLE = true;
	private final boolean EXCLUSIVE = true;
	private final String TYPE = "direct";
	@Autowired
	private TraficoRabbitService traficoRabbitService;

	@Bean
	public String getFungRuiExito() {

		try {
			final Channel channel = Subscriber.createQueue(HOST, PORT, USER, PASS, VIRTUAL_SERVICE, EXCHANGE_NAME, TYPE,
					DURABLE, !EXCLUSIVE, AUTO_DELETE, QUEUE_FUNG_RUI_AUTORIZO, ROUTING_KEY_FUNG_RUI_AUTORIZO, null);

			boolean autoAck = false;

			channel.basicConsume(QUEUE_FUNG_RUI_AUTORIZO, autoAck, "FR-Queue-Consumer", new DefaultConsumer(channel) {
				@Override
				public void handleDelivery(String consumerTag, Envelope sobre, AMQP.BasicProperties properties,
						byte[] body) {
					long deliveryTag = sobre.getDeliveryTag();
					try {
						
						log.info("*** Iniciando proceso de autorizacion ");
						String json =  new String(body, StandardCharsets.UTF_8);
                        log.info("*** INICIO PETICION  {} ",json);
                        DocumentosAutorizadoDTO dto =new Gson().fromJson(json, DocumentosAutorizadoDTO.class);
                        log.info("*** INICIO PETICION  {} ",dto);
                        
                        if (dto.getSar()==null) {
							throw new Exception("Sar invalido");
						}
                        traficoRabbitService.procesaAceptacionTrafico(dto.getSar());
                        channel.basicAck(deliveryTag, false);
					} catch (ClassCastException e) {
						try {
							channel.basicAck(deliveryTag, false);
						} catch (IOException e1) {
							e1.printStackTrace();
							log.error(e1.getMessage(), e1);
						}
						e.printStackTrace();
						log.error(e.getMessage(), e);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
						log.error(e.getMessage(), e);
					} catch (Exception e1) {
						try {
							channel.basicAck(deliveryTag, false);
						} catch (IOException e) {
							log.error(e1.getMessage(), e1);
							e.printStackTrace();
						}
						log.error(e1.getMessage(), e1);
						e1.printStackTrace();
					}
					
				}
			});

		} catch (IOException e) {
			log.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return "OK";

	}
	
	@Bean
	public String getFungRuiRechazo() {

		try {
			final Channel channel = Subscriber.createQueue(HOST, PORT, USER, PASS, VIRTUAL_SERVICE, EXCHANGE_NAME, TYPE,
					DURABLE, !EXCLUSIVE, AUTO_DELETE, QUEUE_FUNG_RUI_RECHAZO, ROUTING_KEY_FUNG_RUI_RECHAZO, null);

			boolean autoAck = false;

			channel.basicConsume(QUEUE_FUNG_RUI_RECHAZO, autoAck, "FR-Queue-Consumer", new DefaultConsumer(channel) {
				@Override
				public void handleDelivery(String consumerTag, Envelope sobre, AMQP.BasicProperties properties,
						byte[] body) {
					long deliveryTag = sobre.getDeliveryTag();
					try {
						log.info("*** Iniciando proceso de rechazo ");
						String json =  new String(body, StandardCharsets.UTF_8);
                        log.info("*** INICIO PETICION  {} ",json);
                        DocumentosRechazoDTO  dto =new Gson().fromJson(json, DocumentosRechazoDTO.class);
                        
                        log.info("*** Objeto serializado  {} ",dto);
                        
                        
                        if (dto.getSar()==null || dto.getIdOrigenDocumento()==null) {
							throw new Exception("Sar invalido || origen documento invalido");
						}
                        traficoRabbitService.procesaRechazoTrafico(dto.getSar(), dto.getIdOrigenDocumento(), dto.getDescripcionIncidencia() + ": " + dto.getComentarioTrafico());
                        channel.basicAck(deliveryTag, false);

					} catch (ClassCastException e) {
						try {
							channel.basicAck(deliveryTag, false);
						} catch (IOException e1) {
							e1.printStackTrace();
							log.error(e1.getMessage(), e1);
						}
						e.printStackTrace();
						log.error(e.getMessage(), e);
					} catch (IOException e1) {
						e1.printStackTrace();
						log.error(e1.getMessage(), e1);
					} catch (Exception e1) {
						try {
							channel.basicAck(deliveryTag, false);
						} catch (IOException e) {
							log.error(e1.getMessage(), e1);
							e.printStackTrace();
						}
						log.error(e1.getMessage(), e1);
						e1.printStackTrace();
					}  
				}
			});

		} catch (IOException e) {
			log.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return "OK";

	}

}
