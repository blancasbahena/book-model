package com.srm.fungandrui.expediente.service;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

@Configuration
public class ConfigurationREstTemplate {
	@Bean
	public RestTemplate restTemplate() {
	    return new RestTemplate();
	}
}
