package com.srm.fungandrui.sc.service;

import java.util.List;

import javax.servlet.ServletException;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.srm.pli.bo.BeanTSR;
import com.srm.pli.dao.TroubleShootingDAO;
import com.srm.pli.services.CorreosTSRService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class TSREnvioMailsServiceImpl implements TSREnvioMailsService {
	
	@Override
	@Transactional
	public void enviarCorreosTSRPendientes() {
		try {
			List<BeanTSR> listaPendientes = TroubleShootingDAO.dameTSRPendientesMas24Hrs();
			if(listaPendientes != null) {
				CorreosTSRService.getInstance().enviaReportesAutomaticosTSRPendientes(listaPendientes);
			}
			
		} catch (ServletException e) {
			log.error("No fue posible enviar correos TSR pendientes");
		}
	}

}
