package com.srm.fungandrui.revocacion.entities;

import java.util.List;

import lombok.Data;
@Data
public class RequestRevocacionConfirmacionDto {
	 private List<RevocacionConfirmacion> data;
}
