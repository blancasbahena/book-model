package com.srm.fungandrui.pis.repository;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.srm.fungandrui.pis.dto.CatalogoPIDTO;
import com.srm.fungandrui.pis.util.Querys;
import com.srm.pli.db.ConexionDB;

import lombok.extern.slf4j.Slf4j;
@Slf4j
@Repository
public class CatalogoPIDaoImpl implements CatalogoPIDao{
	@Override
	public List<CatalogoPIDTO> getAll() {
		List<CatalogoPIDTO> cts = new ArrayList<CatalogoPIDTO>();
		Connection conn = null;
		try {
			conn = ConexionDB.dameConexion();
			try (PreparedStatement pstmt = conn.prepareStatement(Querys.SQL_CATALOGO_QUERY)) {
				ResultSet rs = pstmt.executeQuery();
				while (rs.next()) {
					CatalogoPIDTO ct = new CatalogoPIDTO(
							rs.getInt("idEstatus"),
							rs.getString("estatus"),
							rs.getBoolean("activo"));
					cts.add(ct);
				}
			} catch (SQLException eSQL) {
				log.error(getClass().getName() + eSQL.toString());
			}
		} catch (Exception e) {
			log.error(getClass().getName() + e.toString());
		} finally {
			ConexionDB.devolver(conn);
		}
		return cts;
	}
	public CatalogoPIDTO findById(Integer id) {
		CatalogoPIDTO ct = null;
		Connection conn = null;
		try {
			conn = ConexionDB.dameConexion();
			try (PreparedStatement pstmt = conn.prepareStatement(Querys.SQL_CATALOGO_BY_ID +  id)) {
				ResultSet rs = pstmt.executeQuery();
				if (rs.next()) {
					ct = new CatalogoPIDTO(
							rs.getInt("idEstatus"),
							rs.getString("estatus"),
							rs.getBoolean("activo"));
				}
			} catch (SQLException eSQL) {
				eSQL.printStackTrace();
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			ConexionDB.devolver(conn);
		}
		return ct;
	}
}
