package com.srm.fungandrui.lineamientos.dto;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import lombok.Data;

@Data
public class EnvioCorreoBODTO implements Serializable{ 
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -644743036749298755L;
	private List<String> to;
	private List<String> cc;
	private List<String> bcc;
	private String subject;
	private String template;
	private String sender;
	private Map<String, Object> params; 

}
