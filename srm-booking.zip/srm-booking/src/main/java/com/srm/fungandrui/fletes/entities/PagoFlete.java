package com.srm.fungandrui.fletes.entities;

import lombok.Data;

@Data

public class PagoFlete {
	

	
	
	private String claveNaviera;
	private String acreedor;
	private String contenedorCaja;
	private String bl;
	private String facturaProveedorLogistico;
	private String fechaFactura;
	private String tipoContenedor;
	private String puertoEmbarque;
	
	private String puertoDescarga;
	private  Double importe;
	private String moneda;
	private String tipoFactura;
	private String folio;
	private String cortePuerto;
	private String estatusPagoFlete;
	
	private int index;
	private String descripcion;

}
