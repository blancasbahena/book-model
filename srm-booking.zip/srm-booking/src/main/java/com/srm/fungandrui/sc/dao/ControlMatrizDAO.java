package com.srm.fungandrui.sc.dao;

import java.util.List;

import com.srm.fungandrui.sc.model.ProveedorVO;
import com.truper.businessEntity.UserBean;

public interface ControlMatrizDAO {
	
	public List<String> getPObloqueadas(String proveedor );
	List<String> getAllPO();
	List<String> getPOsBYFolioSar(String folioSAR);
	int getDaysEtdBySupplier(int proveedor);
	boolean saveDaysEtdBySupplierBatch(List<String> suppliersByDaysEtd, UserBean user);
}
