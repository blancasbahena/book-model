package com.srm.fungandrui.facturacion.utils;

import com.srm.fungandrui.facturacion.models.Facturacion;
import com.srm.pli.utils.MailUtils;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class SendEmail {

	public static void sendEmail(String listdestinatarios, String subject) throws Exception {

		String[] splitDestinatarios = listdestinatarios.split(";");
		StringBuilder body = new StringBuilder();
		body.append("<html>");
		body.append("<head>");
		body.append("</head>");
		body.append("<body>");
		body.append("<table width=\"700\" align=\"center\" border=\"0\">");
		body.append("<tr>");
		body.append("<td> Dia de envio </td>");
		body.append("<td> Turno de Entrega </td>");
		body.append("<td> No Factura(Proveedor Extrajenro) </td>");
		body.append("<td> Nùmero de Proveedor </td>");
		body.append("<td> Nombre del proveedor </td>");
		body.append("<td> Error </td>");
		body.append("</tr>");
		body.append("</table>");

		try {
			MailUtils.enviaCorreo(splitDestinatarios, null, subject, "system@fung-rui.hk", body.toString(), null);

		} catch (Exception e) {
			log.info("Error al enviar correo {}", e.getMessage());
		}
	}

	public static void sendEmailSolicitudCancelacion(String listdestinatarios, String subject, Facturacion filtro)
			throws Exception {
		String plantillaCancelacion = PlantillasEmailFacturacion.SOLICITUD_CANCELACION;
		String[] splitDestinatarios = listdestinatarios.split(";");
//		StringBuilder body = new StringBuilder();		
//		body.append("<!DOCTYPE HTML>");
//		body.append("<html>");
//		body.append("    <head>");
//		body.append("		<title> Invoices canceled</title>");
//		body.append("		<style>");
//		body.append("		td.cabeceracss {background-color: #3b8c86;}");
//		body.append("		td.bodycss {background-color: #white;} ");
//		body.append("		thead.cabecera tr td {");
//		body.append("			font-family: monospace;");
//		body.append("			font-size: 10px;");
//		body.append("			font-weight: bold;");
//		body.append("			color: white;");
//		body.append("			padding: 3px 10px;");
//		body.append("			border-top-left-radius: 20px;");
//		body.append("			border-bottom-right-radius: 20px;");
//		body.append("			padding: 6px;}");
//		body.append("		tbody.cuerpo tr td {");
//		body.append("			color: 3b8c86; ");
//		body.append("			padding: 2px;}");
//		body.append("		td {border-style: white;");
//		body.append("		 border-width: 1px;}");
//		body.append("		</style>");
//		body.append("	</head>");
//		body.append("	<body>");
//		body.append("		<table> ");
//		body.append("			<thead class='cabecera'>");
//		body.append("				<tr>");
//		body.append("					<td class='cabeceracss'>Shipping day </th>");
//		body.append("					<td class='cabeceracss'>Delivery Shift</th>");
//		body.append("					<td class='cabeceracss'>No Invoice (Foreign Provider)</th>");
//		body.append("					<td class='cabeceracss'>Provider Number</th>");
//		body.append("					<td class='cabeceracss'>Provider's name</th>");
//		body.append("					<td class='cabeceracss'>Error</th>");
//		body.append("				</tr>");
//		body.append("			</thead>");
//		body.append("		<tbody class='cuerpo'>");
//		body.append("			<tr>");
////		body.append("				<td class='bodycss'>-SHIPPINGDAY-</td>");
////		body.append("				<td class='bodycss'>-DELIVERYSHIFT-</td>");
//		body.append("				<td class='bodycss'>-NOINVOICE-</td>");
//		body.append("				<td class='bodycss'>-PROVIDERNUMBER-</td>");
//		body.append("				<td class='bodycss'>-PROVIDERNAME-</td>");
//		body.append("				<td class='bodycss'>-COMMENT-</td>");
//		body.append("			</tr>");
//		body.append("			</tbody>");
//		body.append("		</table>");
//		body.append("	</body>");
//		body.append("</html>");

		try {
			log.info("Inicia remplazo de parametros en SOLICITUD DE CANCELACION");
			String noInvoice = filtro.getInvoiceNumber();
			String providerName = filtro.getNombreProveedor();
			String comment = filtro.getComentarios();
			String providerNumber = filtro.getFacturaProvedor();
//			<td class='bodycss'>-NOINVOICE-</td>")
//			.append("				<td class='bodycss'>-PROVIDERNUMBER-</td>")
//			.append("				<td class='bodycss'>-PROVIDERNAME-</td>")
//			.append("				<td class='bodycss'>-COMMENT-</td>")
			plantillaCancelacion = plantillaCancelacion.replaceAll("-NOINVOICE-", noInvoice);
			plantillaCancelacion = plantillaCancelacion.replaceAll("-PROVIDERNAME-", providerName);
			plantillaCancelacion = plantillaCancelacion.replaceAll("-PROVIDERNAME-", providerNumber);
			plantillaCancelacion = plantillaCancelacion.replaceAll("-COMMENT-", comment);

			MailUtils.enviaCorreo(splitDestinatarios, null, subject, "system@fung-rui.hk",
					plantillaCancelacion.toString(), null);

		} catch (Exception e) {
			log.info("Error al enviar correo {}", e.getMessage());
		}
	}

	public static void sendEmailSolicitudCorreccion(String listdestinatarios, String subject, Facturacion filtro,
			String mensaje) throws Exception {

		String[] splitDestinatarios = listdestinatarios.split(";");
		StringBuilder body = new StringBuilder();
		body.append("<html>");
		body.append("<head>");
		body.append("</head>");
		body.append("<body>");
		body.append("<table width=\"700\" align=\"center\" border=\"0\">");
		body.append("<tr>");
		body.append("<td> ");
		body.append(mensaje);
		body.append(" </td>");
		body.append("</tr>");
		body.append("<tr>");
		body.append("<td> Cooments :: ");
		body.append(filtro.getComentarios());
		body.append(" </td>");
		body.append("</tr>");
		body.append("</table>");
		body.append("</body>");
		body.append("</html>");

		try {
			MailUtils.enviaCorreo(splitDestinatarios, null, subject, "system@fung-rui.hk", body.toString(), null);

		} catch (Exception e) {
			log.info("Error al enviar correo {}", e.getMessage());
		}
	}

	public static boolean sentEmailErrorBloqueoPo(String listaDestinatarios, String subject, String plantilla) {
		boolean resultado = false;
		String[] splitDestinatarios = listaDestinatarios.split(";");

		try {
			MailUtils.enviaCorreo(splitDestinatarios, null, subject, "system@fung-rui.hk", plantilla, null);
		} catch (Exception e) {
			log.info("Error al enviar correo {}", e.getMessage());
		}
		return resultado;
	}
}
