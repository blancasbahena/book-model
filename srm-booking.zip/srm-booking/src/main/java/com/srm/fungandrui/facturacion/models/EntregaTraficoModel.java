package com.srm.fungandrui.facturacion.models;

import java.io.Serializable;

import lombok.Data;

@Data
public class EntregaTraficoModel implements Serializable{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private long visible;
	private long id;
	private boolean consolidado;
	private boolean  fechaAprobadoSDI;
	private String booking;
	private String folio;
	private String BL;
	private String contenedor;
	private String proveedor;
	private String etd;
	private String eta;
	private String condicionpago;
	private String pod;
	private String puertoSalida;
	private String transporte;
	private String shipment_type;
	private String analista;
	private String carrier;
	private String prioridad;
	private String facturaPm;
	private int number;
	private boolean procesadoSIFE;
	private boolean  entregadoTrafico;
	private String observaciones_trafico;
	private String analista_trafico;
	private String customs_agent;
	private String condicionpago_desc;
	private boolean urgente;
	private String obs_reject_incidencia;
	
	
	private double total ,subtotal ,subtotalfocs , subtotalothers; 
	private String facturaProveedor;
	private Integer factura_status;
	private int idStatus;
	private String para_envio_a_trafico;
	private String tAnalist;
	private String analistaAsignado;
	private String comentarioEmbarque;
	private int idEstatusCuarentaYtres;
	private int idEsatusDieciNueve;
	
	private Boolean esSpecialties;
}
