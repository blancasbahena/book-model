package com.srm.fungandrui.fletes.entities;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class FiltersPagoFletes implements Serializable{/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String folio;
	private String contenedor;
	private String fechaInicial;
	private String fechaFinal;
	private String status;
	private String paginaAccion;
	private String paginaActual;

	
}
