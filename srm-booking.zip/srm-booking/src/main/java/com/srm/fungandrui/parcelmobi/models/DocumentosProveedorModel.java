package com.srm.fungandrui.parcelmobi.models;


import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DocumentosProveedorModel implements Serializable {

	private static final long serialVersionUID = 1L;
    private String tipoDocumento;
    private String rutaArchivo;
    private String nombreFactura;
    private String condicionPago;
    private boolean facturaOtros;
    private int id;
}
