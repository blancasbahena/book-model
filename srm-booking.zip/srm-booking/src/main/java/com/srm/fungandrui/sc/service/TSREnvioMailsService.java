package com.srm.fungandrui.sc.service;

public interface TSREnvioMailsService {
	void enviarCorreosTSRPendientes();
}
