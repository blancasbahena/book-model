package com.srm.fungandrui.pis.service;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;

import com.srm.fungandrui.pis.dto.ProformaInvoiceDTO;
import com.srm.fungandrui.pis.dto.ProformaPdfDTO;
import com.srm.fungandrui.pis.dto.RequestWsPos;

public interface ProformaInvoiceService {

	List<Map<String, Object>> obtenerPOs(RequestWsPos pos);
	List<ProformaInvoiceDTO> obtenerListadoPos(String proveedor) throws ServletException ;
	String generarProformaPdf(ProformaPdfDTO proformaPdf);
	String generarProformaPdfClone(String prove,String arch,String fileName);
	void actualizaPosiciones1to2(int idPi) throws ServletException, ClassNotFoundException, SQLException ;
	
}
