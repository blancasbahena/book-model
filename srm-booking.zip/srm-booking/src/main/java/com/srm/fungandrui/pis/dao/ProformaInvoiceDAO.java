package com.srm.fungandrui.pis.dao;

import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;

import com.srm.fungandrui.pis.dto.ProformaInvoiceDTO;

public interface ProformaInvoiceDAO {

	public List<ProformaInvoiceDTO> dateProformasCreadas(String proveedor) throws ServletException;
	void actualizaPosiciones1to2(int idPi) throws ClassNotFoundException, SQLException ;
		
}
