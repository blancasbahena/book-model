package com.srm.fungandrui.cdi.queries;

public class CdiSarQuery {

	public static final String PENDING_UPDATESUPPLIER_ByBOOKING = new StringBuilder("SELECT ")
			.append(" dateUpdateSupplier , bookingUpdateSupplier , dateETDFinalUpdateSupplier, carrierUpdateSupplier ")
			.append(" ,folio , proveedor , etdFinal , naviera , booking , usuarioApruebaPlanning ")
			.append(" FROM cdiSar ")
			.append(" WHERE bookingUpdateSupplier is not null ")
			.toString();

	public static final String SAR_BY_PROVEEDOR_AND_FOLIO= new StringBuilder("SELECT ")
			.append(" proveedor,folio,aprobadoProveedor ,contenedor contenedorProveedor, BL sealNumber ,fechaConfirmacionFinal ")
			.append(" FROM cdiSar ")
			.append(" where proveedor = PROVEEDOR and folio  = FOLIO ")
			.toString();

}
