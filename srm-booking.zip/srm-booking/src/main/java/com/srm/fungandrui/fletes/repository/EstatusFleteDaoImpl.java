package com.srm.fungandrui.fletes.repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.srm.fungandrui.fletes.entities.EstatusFlete;
import com.srm.fungandrui.fletes.queries.QueriesFletes;
import com.srm.pli.db.ConexionDB;

import lombok.extern.slf4j.Slf4j;
@Slf4j
@Repository
public class EstatusFleteDaoImpl implements EstatusFleteDao {
	

	@Override
	public List<EstatusFlete> getAll() {
		List<EstatusFlete> bloqueos = new ArrayList<EstatusFlete>();
		Connection conn = null;
		try {
			conn = ConexionDB.dameConexion();
			try (PreparedStatement pstmt = conn.prepareStatement(QueriesFletes.SQL_ESTATUS)) {

				ResultSet rs = pstmt.executeQuery();
				while (rs.next()) {
					EstatusFlete pago = rowMapper(rs);
					bloqueos.add(pago);
				}
			} catch (SQLException eSQL) {
				log.error(getClass().getName() + eSQL.toString());
			}
		} catch (Exception e) {
			log.error(getClass().getName() + e.toString());
		} finally {
			ConexionDB.devolver(conn);
		}
		return bloqueos;
	}

	private EstatusFlete rowMapper(ResultSet rs) throws SQLException {
		EstatusFlete estatus = new EstatusFlete();
		estatus.setId(rs.getLong("id"));
		estatus.setNombre(rs.getString("nombre") != null ? rs.getString("nombre") : "-");
		return estatus;
	}

}
