package com.srm.fungandrui.imports.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.srm.pli.bo.SarDetalleBO;
import com.srm.pli.dao.SAR_CDI_DAO;
import com.srm.pli.enums.Mensajes;
import com.srm.pli.ws.vo.ResponseImportsVO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
@RequestMapping("/detalles")
public class DetallesSarControl {

	
	@GetMapping(value = "/obtenSar/{sars}")
	public ResponseEntity<ResponseImportsVO> getDetallesSar(@PathVariable String sars) {
		log.info("[/detalleSar/]::Entrando al REST obten detalle sar GET:");
		ResponseImportsVO response = null;
		try {
			
			ArrayList<SarDetalleBO> listDetalle = SAR_CDI_DAO.dameDatosDetalles(sars);
			
			response = new ResponseImportsVO(Mensajes.TIPO_EXITO.getMensaje(), Mensajes.MSG_EXITO.getMensaje(), "detalleSar",
					listDetalle);
			return ResponseEntity.ok(response);
		} catch (Exception e) {
			response.setTipoMensaje(Mensajes.TIPO_ERROR.getMensaje());
			response.setMensaje(Mensajes.MSG_ERROR.getMensaje());
			Map<String, Object> data = new HashMap<String, Object>();
			data.put("error", ExceptionUtils.getStackTrace(e));
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
		}
	}
}
