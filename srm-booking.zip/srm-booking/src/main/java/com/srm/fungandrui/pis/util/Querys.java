package com.srm.fungandrui.pis.util;

public class Querys {
	public static final String SQL_CATALOGO_QUERY = new StringBuilder( "SELECT   ")
			.append(" idEstatus , ")
			.append(" estatus  , ")
			.append(" activo ")
			.append(" from cdiCatalogoPiEstatus ")
			.toString();
	public static final String SQL_CATALOGO_BY_ID = new StringBuilder( "SELECT   ")
			.append(" idEstatus , ")
			.append(" estatus  , ")
			.append(" activo ")
			.append(" from cdiCatalogoPiEstatus ")
			.append(" where idEstatus = ")
			.toString();
	public static final String SQL_PROFORMA_INVOICE = new StringBuilder( "SELECT   ")
			.append(" idPi , ")
			.append(" proveedor  ,")
			.append(" noOrden , ")
			.append(" proformaNumber  ,")
			.append(" proformaDate , ")
			.append(" condicionPago  ,")
			.append(" shippingPort , ")
			.append(" shippingDate  ,")
			.append(" fullContainer , ")
			.append(" posModificadas,")
			.append(" idEstatus  ,")
			.append(" userRechaza  ,")
			.append(" comentariosRechaza  ,")
			.append(" fechaRechaza  ,")
			.append(" precioModificado  ,")
			.append(" ShippingModificado  ,")
			.append(" CantidadModificada ,")
			.append(" contenedor ")
			.append(" from cdiProformaInvoice ")
			.append(" where idPi =  ")
			.toString();
	public static final String SQL_PROFORMA_ALL_NUMBER_INVOICE = new StringBuilder( "SELECT   ")
			.append(" idPi , ")
			.append(" proformaNumber,proveedor  ")
			.append(" from cdiProformaInvoice ")
	//		.append(" where idPi =  ")
			.toString();
	
	public static final String CREA_PROFORMA = new StringBuilder("INSERT INTO cdiProformaInvoice ")
	     .append("	( proveedor, noOrden, proformaNumber, proformaDate, condicionPago, ")
	     .append(" shippingDate, fullContainer, idEstatus, posModificadas,CantidadModificada,precioModificado, ")
	     .append(" ShippingModificado, shippingPort, contenedor)   ")
	     .append("	VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)  ").toString();
	

	public static final String CREA_PROFORMA_DETALLE = new StringBuilder("INSERT INTO cdiProformaDetalle ")
	      .append("	(noOrden, posicion, idPI, brand, item, code, description, shippingDate, cantidadOriginal, unidadeMedida, ")
	      .append("		precioUnitarioOriginal, cantidadEnviada, montoOriginal, montoEnviado, pesoOriginal,    ")
	      .append("		pesoEnviado, volumenOriginal, volumenEnviado, isFoc, precioUnitarioEnviado, cliente, ")
	      .append(" isOtherItem, currency, shippingDateEnviado, centro, planeador,almacen, esPedidoDirecto)   ")
	      .append("	VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)  ").toString();
	
	public static final String CREA_HISTORICO_PROFORMA = new StringBuilder("INSERT INTO cdiHistProformaInvoice ")
		.append("	( proveedor, noOrden, proformaNumber, proformaDate, condicionPago, ")
		.append("		shippingPort, shippingDate, fullContainer, idEstatus, posModificadas)   ")
		.append("	VALUES (?,?,?,?,?,?,?,?,?,?)  ").toString();
	
	public static final String CREA_HISTORICO_PROFORMA_DETALLE = new StringBuilder("INSERT INTO cdiHistProformaDetalle ")
		.append("	(noOrden, posicion, idPI, brand, item, code, description, shippingDate, cantidadOriginal, unidadeMedida, ")
		.append("		precioUnitario, cantidadEnviada, montoOriginal, montoEnviado, pesoOriginal,    ")
		.append("		pesoEnviado, volumenOriginal, volumenEnviado, isFoc)   ")
		.append("	VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)  ").toString();
	
	public static final String ACTUALIZAR_PROFORMA = new StringBuilder("UPDATE cdiProformaInvoice SET ")
		.append("	proformaNumber=?, fullContainer=?, posModificadas=?  ")
		.append("WHERE idPi=? ").toString();
	
	public static final String ACTUALIZAR_SEND_PROFORMA = new StringBuilder("UPDATE cdiProformaInvoice SET ")
		.append("	proformaNumber=?, fullContainer=?, posModificadas=?, idEstatus=?  ")
		.append("WHERE idPi=? ").toString();
	
	public static final String ACTUALIZAR_PROFORMA_DETALLE = new StringBuilder("UPDATE cdiProformaDetalle SET ")
		.append("	cantidadEnviada=?, montoEnviado=?, pesoEnviado=?, volumenEnviado=?, precioUnitarioEnviado=?, shippingDateEnviado=?  ")
		.append("	where noOrden=? and posicion=? and idPI=?").toString();
	
	public static final String ACTUALIZAR_HISTORICO_PROFORMA = new StringBuilder("UPDATE cdiHistProformaInvoice SET ")
		.append("	proveedor=?, noOrden=?, proformaNumber=?, proformaDate=?, condicionPago=?, ")
		.append("		shippingPort=?, shippingDate=?, fullContainer=?, idEstatus=?, posModificadas=?  ")
		.append("WHERE idPi=? ").toString();
	
	public static final String ACTUALIZAR_HISTORICO_PROFORMA_DETALLE = new StringBuilder("UPDATE cdiHistProformaDetalle SET ")
		.append("	brand=?, item=?, code=?, description=?, shippingDate=?, cantidadOriginal=?, unidadeMedida=?, ")
		.append("		precioUnitarioOriginal=?, cantidadEnviada=?, montoOriginal=?, montoEnviado=?, pesoOriginal=?,    ")
		.append("		pesoEnviado=?, volumenOriginal=?, volumenEnviado=?, isFoc=?  ")
		.append("	where noOrden=? and posicion=? and idPI=?").toString();
	
	public static final String EDITA_PROFORMA_NUMBER = new StringBuilder("UPDATE cdiProformaInvoice SET proformaNumber=?")
		.append("WHERE idPi=?  and noOrden=?").toString();
	
	public static final String OBTENER_MONTOS_CANTIDADES_MODIFICADAS = new StringBuilder(" SELECT sum(cantidadEnviada) totalCantidadEnviada, sum(montoEnviado)  totalMontoEnviado  ")
			.append("  from cdiProformaDetalle where noOrden = ?").toString();
	
	public static final String GET_PROFORMABY_STATUS = new StringBuilder(" SELECT "+
			" idPi, proveedor, noOrden, proformaNumber, proformaDate, condicionPago, " + 
			" shippingPort, shippingDate, fullContainer, idEstatus, userRechaza, " + 
			" comentariosRechaza, fechaRechaza, precioModificado, ShippingModificado, " + 
			" CantidadModificada, posModificadas, contenedor " + 
			" FROM  cdiProformaInvoice where idEstatus =  ?").toString();
	public static final String GET_PROFORMA = new StringBuilder(" SELECT "+
			" idPi, proveedor, noOrden, proformaNumber, proformaDate, condicionPago, " + 
			" shippingPort, shippingDate, fullContainer, idEstatus, userRechaza, " + 
			" comentariosRechaza, fechaRechaza, precioModificado, ShippingModificado, " + 
			" CantidadModificada, posModificadas, contenedor " + 
			" FROM  cdiProformaInvoice where idPi =  ?").toString();
	public static final String GET_PROFORMA_DETALLE = new StringBuilder(" SELECT "+
			  " noOrden, posicion, idPI, brand, item, code, "
			+ " description, shippingDate, cantidadOriginal, "
			+ " unidadeMedida, precioUnitarioOriginal, "
			+ " cantidadEnviada, montoOriginal, montoEnviado, "
			+ " pesoOriginal, pesoEnviado, volumenOriginal, "
			+ " volumenEnviado, isFoc, precioUnitarioEnviado, "
			+ " shippingDateEnviado, cliente, isOtherItem, "
			+ " currency, centro, planeador, idEstatusChange,"
			+"  matriz ,validaciones  ,almacen,esPedidoDirecto  " + 
			  " FROM  cdiProformaDetalle where idPi =  ?").toString();
	
	public static final String OBTENER_ID_PROFORMA = new StringBuilder("  SELECT idPI  ")
		.append("  from cdiProformaInvoice")
		.append("  where proveedor = ? ")
		.append("  and   noOrden = ? ")
		.append("  and   proformaNumber = ? ").toString();
	
	public static final String DATE_PROFORMAS_CREADAS = new StringBuilder("SELECT noOrden, idPi FROM cdiProformaInvoice WHERE proveedor = ? ").toString();


	public static final String SQL_PROFORMA_DETALLE = new StringBuilder( "SELECT   ")
			.append(" noOrden , ")
			.append(" posicion  ,")
			.append(" idPI , ")
			.append(" brand  ,")
			.append(" item , ")
			.append(" code  ,")
			.append(" description , ")
			.append(" shippingDate  ,")
			.append(" cantidadOriginal , ")
			.append(" unidadeMedida  ,")
			.append(" precioUnitarioOriginal  ,")
			.append(" cantidadEnviada , ")
			.append(" montoOriginal  ,")
			.append(" montoEnviado , ")
			.append(" volumenOriginal  ,")
			.append(" volumenEnviado , ")
			.append(" pesoOriginal  ,")
			.append(" pesoEnviado , ")
			.append(" isFoc  ,")
			.append(" precioUnitarioEnviado , ")
			.append(" shippingDateEnviado , ")
			.append(" cliente , ")
			.append(" isOtherItem, ")
			.append(" currency, ")
			.append(" centro, ")
			.append(" planeador, ")
			.append(" idEstatusChange, ")
			.append(" userChange, ")
			.append(" fechaChange ")
			.append(" from cdiProformaDetalle ")
			.append(" where idPi =  ")
			.toString();

	public static final String CAMBIA_ESTATUS= new StringBuilder("   ")
			.append("  update cdiProformaDetalle  ")
			.append(" set userChange=?   ")
			.append(" ,fechaChange  = getDate()    ")
			.append(" ,idEstatusChange=? ") 
			.append(" where noOrden=?    ")
			.append(" and posicion=?     ")
			.append(" and idPi =?        ").toString();
	
	public static final String ACEPTA_IMG= new StringBuilder("   ")
			.append("  update cdiProformaInvoice  ")
			.append("  set idUnico=? ")
			.append(" ,usuarioAut =? ") 
			.append("  where idPi =? ").toString();
	public static final String ELIMINA_POS_ENVIADAS= new StringBuilder("   ")
			.append("  update cdiProformaDetalle  ")
			.append("  set userChange='system' ")
			.append(" ,fechaChange  = getDate()    ")
			.append(" ,idEstatusChange=2 ")  
			.append("  where idEstatusChange =1 and idPi =? ").toString();
	
	public static final String CAMBIA_ESTATUS_PROFORMA= new StringBuilder("   ")
			.append("  update cdiProformaInvoice  ")
			.append("  set idEstatus =? ") 
			.append("  where idPi =? ").toString();
	public static final String REJECT_ESTATUS_PROFORMA= new StringBuilder("   ")
			.append("  update cdiProformaInvoice  ")
			.append("  set idEstatus =? ") 
			.append("  where idEstatus =? ").toString();
	
	public static final String GET_PROFORMABY_STATUS_PO = new StringBuilder(" SELECT "+
			" idPi, proveedor, noOrden, proformaNumber, proformaDate, condicionPago, " + 
			" shippingPort, shippingDate, fullContainer, idEstatus, userRechaza, " + 
			" comentariosRechaza, fechaRechaza, precioModificado, ShippingModificado, " + 
			" CantidadModificada, posModificadas, contenedor " + 
			" FROM  cdiProformaInvoice where idEstatus =  ? and noOrden=?").toString();
	
	public static final String GET_PROFORMABY_STATUS_PROVEEDOR = new StringBuilder(" SELECT "+
			" idPi, proveedor, noOrden, proformaNumber, proformaDate, condicionPago, " + 
			" shippingPort, shippingDate, fullContainer, idEstatus, userRechaza, " + 
			" comentariosRechaza, fechaRechaza, precioModificado, ShippingModificado, " + 
			" CantidadModificada, posModificadas, contenedor " + 
			" FROM  cdiProformaInvoice where idEstatus =  ?  and proveedor=?").toString();
	
	public static final String GET_PROFORMABY_STATUS_PLANER = new StringBuilder(" SELECT  distinct d.planeador , " + 
			"	  i.idPi, proveedor, i.noOrden, i.proformaNumber, i.proformaDate, i.condicionPago,   " + 
			"	  i.shippingPort, i.shippingDate, i.fullContainer, i.idEstatus, i.userRechaza,  " + 
			"	  i.comentariosRechaza, i.fechaRechaza, i.precioModificado, i.ShippingModificado,   " + 
			"	  i.CantidadModificada, i.posModificadas, i.contenedor  " + 
			"	  FROM  cdiProformaInvoice i inner join cdiProformaDetalle d on i.idPi = d.idPI and i.noOrden = d.noOrden  " + 
			"	 where idEstatus =  ? and d.planeador = ?").toString();
	public static final String CAMBIA_MATRIZ= new StringBuilder("   ")
			.append("  update cdiProformaDetalle  ")
			.append(" set matriz=?   ")
			.append(" ,validaciones  =?    ") 
			.append(" where noOrden=?    ")
			.append(" and item=?     ").toString();
}
