package com.srm.fungandrui.pis.repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.srm.fungandrui.pis.dto.CatalogoPIDTO;
import com.srm.fungandrui.pis.dto.ProformaInvoiceDTO;
import com.srm.fungandrui.pis.util.Querys;
import com.srm.pli.db.ConexionDB;

@Repository
public class ProformaInvoiceDaoImpl implements ProformaInvoiceDao{
	
	@Autowired
	private CatalogoPIDao catalogoDAO;
	
	@Override
	public List<ProformaInvoiceDTO> getAllInvoiceNumber() {
		List<ProformaInvoiceDTO> prfs = new ArrayList<ProformaInvoiceDTO>();
		Connection conn = null;
		try {
			conn = ConexionDB.dameConexion();
			String  query = new StringBuilder(Querys.SQL_PROFORMA_ALL_NUMBER_INVOICE ).toString();
			try (PreparedStatement pstmt = conn.prepareStatement(query)) {
				ResultSet rs = pstmt.executeQuery();
				while(rs.next()) { 
					ProformaInvoiceDTO dto= new ProformaInvoiceDTO();
					dto.setIdPi(rs.getInt("idPi"));
					dto.setProformaNumber(rs.getString("proformaNumber"));
					dto.setProveedor(rs.getString("proveedor"));
					prfs.add(dto);
				}
			} catch (SQLException eSQL) {
				eSQL.printStackTrace();
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			ConexionDB.devolver(conn);
		}
		return prfs;
	}
	@Override
	public List<ProformaInvoiceDTO> getAll(Integer id) {
		List<ProformaInvoiceDTO> prfs = new ArrayList<ProformaInvoiceDTO>();
		Connection conn = null;
		try {
			conn = ConexionDB.dameConexion();
			String  query = new StringBuilder(Querys.SQL_PROFORMA_INVOICE )
					.append(id.toString()).toString();
			try (PreparedStatement pstmt = conn.prepareStatement(query)) {
				ResultSet rs = pstmt.executeQuery();
				if (rs.next()) {
					int idEstatus  = rs.getInt("idEstatus");
					CatalogoPIDTO catalogo=catalogoDAO.findById(idEstatus);
					if(catalogo!=null) {
						ProformaInvoiceDTO ct = new ProformaInvoiceDTO(
								rs.getInt("idPi"),
								rs.getString("proveedor"),
								rs.getString("noOrden"),
								rs.getString("proformaNumber"),
								rs.getInt("proformaDate"),
								rs.getString("condicionPago"),
								rs.getString("shippingPort"),
								rs.getInt("shippingDate"),
								rs.getBoolean("fullContainer"),
								rs.getBoolean("posModificadas"),
								catalogo,
								rs.getString("userRechaza"),
								rs.getString("comentariosRechaza"),
								rs.getDate("fechaRechaza"),
								rs.getBoolean("precioModificado"),
								rs.getBoolean("ShippingModificado"),
								rs.getBoolean("CantidadModificada"),"", rs.getString("contenedor"));
						prfs.add(ct);
					}
				}
			} catch (SQLException eSQL) {
				eSQL.printStackTrace();
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			ConexionDB.devolver(conn);
		}
		return prfs;
	}
}
