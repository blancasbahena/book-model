package com.srm.fungandrui.lineamientos.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@ToString

public class GrdLineamientosAccionesDto {
	private String  accion;
	private Integer idEstatus;
	private String comentarios;
	private Integer folio;
	private Integer approvalGRDlineacion;
	private Integer statusAnterior;
	private Integer statusActual;


}
