package com.srm.fungandrui.revocacion.entities;

import java.util.List;

import lombok.Data;

@Data
public class ResponseRenovacionConfirmacionDto {
	
	private List<RenovacionConfirmacionDto> data;

}
