package com.srm.fungandrui.fletes.service;

import java.util.List;

import com.srm.fungandrui.fletes.entities.EstatusFlete;
import com.srm.fungandrui.fletes.entities.FiltersPagoFletes;
import com.srm.fungandrui.fletes.entities.PagoFlete;

public interface PagoFeleteService {
	void addPagoFlete(PagoFlete pagoFlete);
	List<PagoFlete> getList();
	List<PagoFlete> getListByStatus(String status);
	List<PagoFlete> getListByContenedor(String contenedor);
	List<PagoFlete> getListByFolio(String folio);
	List<PagoFlete> getListByFecha(String fecha);
	List<PagoFlete> getListByFilters(FiltersPagoFletes filtros);
	
	List<EstatusFlete> getAllEstatus();
}
