package com.srm.fungandrui.pis.service.impl;

import java.util.List;

import lombok.Data;
@Data
public class RequestRevocacionConfirmacionDto {
	 private List<RevocacionConfirmacion> data;
}
