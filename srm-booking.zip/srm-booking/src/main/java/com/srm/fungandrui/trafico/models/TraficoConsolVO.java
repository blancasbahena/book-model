package com.srm.fungandrui.trafico.models;

import java.util.List;

import com.truper.trafico.ConsolidacionFolioDto;

import lombok.Data;

@Data
public class TraficoConsolVO {

	private String status;
	private List<Integer> folios;
	private ConsolidacionFolioDto consolidado;;
}
