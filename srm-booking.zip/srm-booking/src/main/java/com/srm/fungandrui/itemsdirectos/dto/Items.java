package com.srm.fungandrui.itemsdirectos.dto;

import java.io.Serializable;

import lombok.Data;

@Data
public class Items implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -394631126974933302L;
	
	private String po;
	private Integer posicion;
	private String isCheck;

}
