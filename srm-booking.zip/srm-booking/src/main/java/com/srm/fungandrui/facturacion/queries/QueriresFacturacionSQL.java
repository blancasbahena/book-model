package com.srm.fungandrui.facturacion.queries;

public class QueriresFacturacionSQL {
	public static final String SQL_LISTA_FACTURACION = new StringBuilder
			( "SELECT DISTINCT facs.id AS STATUS_ID, f.id, ")
			.append("f.automatico as proceso_automatico_o_manual , ")
			.append("f.fecha_hora_aprobacion as fecha_SDI , ")
			.append("f.numero_factura_pm as no_factura_pm , ")
			.append("f.am_pm as am_pm , ")
			.append("f.monto_usd as monto_usd , ")
			.append("f.factura_fecha_emision as fecha_emision , ")
			.append("f.facturista as facturista ,  ")
			.append("facs.descripcion as status_facturacion , ")
			.append("ins.descripcion as type_insidencia , ")
			.append("f.comentarios_incidencias as comentarios , ")
			.append("f.supplier_code as supplier, ")
			.append("s.eta as eta , ")
			.append("s.booking as number_booking , ")
			.append("s.folio as folio , ")
			.append("s.BL as BL_Number , ")
			.append("f.pod as POD , ")
			.append("f.shipment_type as Shipment_Type , ")
			.append("f.priority as priority,")
		    //.append("csdi.analista AS Analista_SDI, ")
			.append("(SELECT realName from cdiUsers  where userName = csdi.analista) AS Analista_SDI, ")
			.append("s.contenedor as contenedor,  ")
			//.append("(select TOP(1) nombre from cdi_facturas where id = dsdi.id) AS factura_proveedor, ")
			.append(" cf.nombre as factura_proveedor,")
			.append("(SELECT nombre from cdiPuertosOrigen where clave = s.puertoDescarga) as nombre_puerto_descarga, ")
			.append("users.realName as nombreFacturista ")
			.append("from facturacion as f ")
			.append("left join cdiSar as s on f.sar = s.folio ")
			.append("left join cat_incidencias as ins on f.incidencia = ins.id ")
			.append("left join cat_areas as catarea on f.area_responsable_solucion = catarea.id ")
			.append("left join cdiControlSDI as csdi on csdi.proveedor = s.proveedor and csdi.booking = s.booking ")
			.append("left join cdiDocumentosSDI as dsdi on s.booking = dsdi.booking ")
			.append("left join cat_factura_status as facs on f.factura_status = facs.id ")
			.append("left join cdiUsers AS  users ON f.facturista = users.id ")
			.append("LEFT join cdi_facturas cf ON cf.id = dsdi.id and f.condicionPago = cf.condicionPago ")
			.append("WHERE 1=1 and f.esSpecialties !=1 ")
			.append(" AND dsdi.versionSDI = (SELECT max(cds.versionSDI) FROM cdiDocumentosSDI cds where s.booking = cds.booking) ")
			.append(" AND cf.versionDocumento = ( SELECT max(cf1.versionDocumento) FROM cdi_facturas cf1 where dsdi.id = cf1.id ) ")
			.toString();
	
	
	public static final String SQL_LISTA_FACTURACION_REPORTE = new StringBuilder
			( "SELECT IFA.id_incidencia,CI.descripcion, CASE WHEN SUM(tiempo_solucion ) IS NULL THEN 0 ELSE SUM(tiempo_solucion )   ")
			.append("END  AS tiempo_solucion  ")
			.append("FROM incidencias_facturacion AS IFA ")
			.append("INNER JOIN cat_incidencias AS CI ON CI.id = IFA.id_incidencia ")
			.append(" WHERE id_incidencia IS NOT NULL AND IFA.tiempo_solucion <> 0 " )
			.append("group by IFA.id_incidencia,CI.descripcion ")
			.toString();
	
	public static final String SQL_REVOCACION_CONTROL_SDI= new StringBuilder ("UPDATE cdiControlSDI SET aprobado = null, fechaAprobadoSDI = null where booking = ? ")
			.toString();
	
	public static final String SQL_REVOCACION_FACTURACION= new StringBuilder ("update facturacion set procesadoSIFE = 0,estatus_diecinueve = null,estatus_cuarenta_tres = 0 where id =? ")
			.toString();
	

}
