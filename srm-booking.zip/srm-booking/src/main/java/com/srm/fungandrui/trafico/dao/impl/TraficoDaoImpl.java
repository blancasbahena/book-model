package com.srm.fungandrui.trafico.dao.impl;

import static com.srm.fungandrui.trafico.queries.ConsolidadosSQL.ALL_SELECT;
import static com.srm.fungandrui.trafico.queries.ConsolidadosSQL.ALL_SELECT_DOCUMENTS;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.stereotype.Service;

import com.srm.fungandrui.facturacion.models.CatStatusFactura;
import com.srm.fungandrui.facturacion.models.Facturacion;
import com.srm.fungandrui.imports.dto.TuplaFolioMaterial;
import com.srm.fungandrui.imports.service.impl.ImportsServiceClient;
import com.srm.fungandrui.trafico.dao.TraficoDao;
import com.srm.fungandrui.trafico.models.TraficoConsolVO;
import com.srm.pli.dao.SAR_CDI_DAO;
import com.srm.pli.dao.SarDetailDao;
import com.srm.pli.db.ConexionDB;
import com.srm.pli.ws.vo.ResponseImportsVO;
import com.truper.trafico.ConsolidacionFolioDetalleDTO;
import com.truper.trafico.ConsolidacionFolioDto;

import lombok.extern.log4j.Log4j2;

@Log4j2
@Service
public class TraficoDaoImpl implements TraficoDao {

	@Override
	public ConsolidacionFolioDto validaEnviadoATrafico(Facturacion factura, String status) throws Exception {
		Connection con = null;
		ConsolidacionFolioDto sarVO = new ConsolidacionFolioDto();
		List<ConsolidacionFolioDetalleDTO> folioDetalle = new ArrayList<ConsolidacionFolioDetalleDTO>();
		//sarVO.setTotal(0);
		try {
			con = ConexionDB.dameConexion();
			ResultSet rs = null;
			PreparedStatement pst = null;
			String query = ALL_SELECT_DOCUMENTS.toString().replaceAll(Pattern.quote("$$STATUS$$"), status);
			pst = con.prepareStatement(query);
			pst.setString(1, factura.getContainer());
			pst.setString(2, factura.getContainer());
			pst.setInt(3, factura.getId().intValue());

			rs = pst.executeQuery();
			while (rs.next()) {
//				sarVO.setContenedor(rs.getString("contenedor"));
//				sarVO.setNaviera(rs.getInt("clave"));
//				sarVO.setFechaEta(rs.getString("eta"));
//				sarVO.setPuerto(rs.getString("clave"));
//				sarVO.setProveedorBean(FuncionesComunesPLI.getProveedor(rs.getString("proveedor")));
//				sarVO.setBooking(rs.getString("booking"));
//				sarVO.setFolio(rs.getString("sar"));
//				sarVO.setPrioridad(rs.getInt("prioridad"));
//				sarVO.setDispatchMode(rs.getInt("shipment_type"));
//				sarVO.setBlNumber(rs.getString("BL"));
//				sarVO.setTotal(rs.getString("total") == null ? 0 : rs.getInt("total"));
//				sarVO.setObservaciones(rs.getString("observaciones_trafico"));
//				ConsolidacionFolioDetalleDTO fd = new ConsolidacionFolioDetalleDTO();
//				fd.setBooking(sarVO.getBooking());
//				fd.setProveedor(rs.getString("proveedor"));
//				folioDetalle.add(fd);

			}
			rs.close();
			pst.close();

			ConexionDB.devuelveConexion(con);

		} catch (SQLException sqlE) {
			try {
				log.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(con);
				throw sqlE;
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
				throw sqlEx2;
			}
		}
		return sarVO;
	}

	@Override
	public ConsolidacionFolioDto enviadoATrafico(Facturacion factura) throws ClassNotFoundException, Exception {
		Connection con = null;
		ConsolidacionFolioDto sarVO = new ConsolidacionFolioDto();
		List<ConsolidacionFolioDetalleDTO> folioDetalle = new ArrayList<ConsolidacionFolioDetalleDTO>();
		//sarVO.setTotal(0);
		try {
			con = ConexionDB.dameConexion();
			ResultSet rs = null;
			PreparedStatement pst = null;
			String query = ALL_SELECT.toString();
			pst = con.prepareStatement(query);
			pst.setString(1, factura.getContainer());
			pst.setInt(2, factura.getId().intValue());

			rs = pst.executeQuery();
			while (rs.next()) {
//				sarVO.setContenedor(rs.getString("contenedor"));
//				sarVO.setNaviera(rs.getInt("clave"));
//				sarVO.setFechaEta(rs.getString("eta"));
//				sarVO.setPuerto(rs.getString("clave"));
//				sarVO.setProveedorBean(FuncionesComunesPLI.getProveedor(rs.getString("proveedor")));
//				sarVO.setBooking(rs.getString("booking"));
//				sarVO.setFolio(rs.getString("sar"));
//				sarVO.setPrioridad(rs.getInt("prioridad"));
//				sarVO.setDispatchMode(rs.getInt("shipment_type"));
//				sarVO.setBlNumber(rs.getString("BL"));
//				sarVO.setObservaciones(rs.getString("observaciones_trafico"));
//				ConsolidacionFolioDetalleDTO fd = new ConsolidacionFolioDetalleDTO();
//				fd.setBooking(sarVO.getBooking());
//				fd.setProveedor(rs.getString("proveedor"));
//				folioDetalle.add(fd);

			}
			rs.close();
			pst.close();

			ConexionDB.devuelveConexion(con);

		} catch (SQLException sqlE) {
			try {
				log.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(con);
				throw sqlE;
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
				throw sqlEx2;
			}
		}
		return sarVO;
	}

	@Override
	public TraficoConsolVO validaConsolidadosAceptados(String proveedor, String booking) throws Exception {
		// valida consolidados liberados
		TraficoConsolVO traficoConsol = null;
		List<Integer> folios = new ArrayList<Integer>();
		List<ConsolidacionFolioDetalleDTO> foliosDetalle = new ArrayList<ConsolidacionFolioDetalleDTO>();
		try {
			traficoConsol = SAR_CDI_DAO.validaConsolidadosAceptados(proveedor, booking);
			if (traficoConsol.getConsolidado().getResult().equalsIgnoreCase("consolidado")) {
				// se revifica que el folio consolidado tenga los documentos necesarios para el
				// envio a trafico y se hace uan consulta de os folios consolidado
				foliosDetalle = SAR_CDI_DAO.getFoliosConsolidados(traficoConsol.getConsolidado().getFolioConsolidado());
				for (ConsolidacionFolioDetalleDTO consolidacionFolioDetalleDto : foliosDetalle) {
					folios.add(consolidacionFolioDetalleDto.getSar());
				}
				traficoConsol.setStatus(SAR_CDI_DAO.validaFolioTrafico(folios.stream().mapToInt(Integer::intValue).toArray()).toString());
				traficoConsol.setFolios(folios);
			} else {
				// verifica si esta completo el expedinte
				ConsolidacionFolioDetalleDTO detalle = new ConsolidacionFolioDetalleDTO();
				folios.add(Integer.parseInt(traficoConsol.getConsolidado().getFolio()));
				traficoConsol.setFolios(folios);
				traficoConsol.setStatus(SAR_CDI_DAO.validaFolioTrafico(folios.stream().mapToInt(Integer::intValue).toArray()).toString());
				detalle.setProveedor(traficoConsol.getConsolidado().getProveedorBean().getClaveProveedor());
				detalle.setBooking(traficoConsol.getConsolidado().getBooking());
				detalle.setIdOrigenDocumento(traficoConsol.getConsolidado().getIdOrigenDocumento());
				foliosDetalle.add(detalle);

			}
			traficoConsol.getConsolidado().setConsolidacionFolioDetalleDto(foliosDetalle);
			
			// se verifica que este listo para envio a trafico, y se manda a ejecutar el llamado a rewquisitos de importacion para cuota compensatoria
			
			
			Set<String>  foliosString = new HashSet<String>();
			
			folios.stream().forEach(row->{
				foliosString.add(row.toString());
			});
			
			ImportsServiceClient importsServiceClient = new ImportsServiceClient();
			if(traficoConsol.getStatus().equals("true")) {

				Set<TuplaFolioMaterial> itemProduct = SarDetailDao.getInstance().getMaterialbyFolio(foliosString);
				
				Map<String, List<Integer>> sarForProducc = new HashMap<>();

                for (TuplaFolioMaterial tuplaFolioMaterial : itemProduct) {
                    if (sarForProducc.containsKey(tuplaFolioMaterial.getFolio())) {
                        sarForProducc.get(tuplaFolioMaterial.getFolio())
                                     .add(tuplaFolioMaterial.getMaterial());
                    } else {
                        sarForProducc.put(tuplaFolioMaterial.getFolio(), new ArrayList<Integer>());
                        sarForProducc.get(tuplaFolioMaterial.getFolio())
                         .add(tuplaFolioMaterial.getMaterial());
                    }
                }

                JSONArray listProduct =  new JSONArray();
                for (TuplaFolioMaterial obj : itemProduct) {
                    listProduct.put(obj.getMaterial());
                }

                importsServiceClient.setClient("reglas/actuales/cuotac");
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("productos", listProduct);
                String rquest = jsonObject.toString();
                ResponseImportsVO output = importsServiceClient.getRequest(rquest, "POST");

                Map<String, Object> rpoductValidate = output.getData();

                List<Map<String, Object>> result  = (List<Map<String, Object>>) rpoductValidate.get("productos");
                for (int i = 0; i < result.size(); i++) {
                	Boolean isCoutaCompensatoria= (Boolean) result.get(i).get("haveCuotaC");
                	if (isCoutaCompensatoria) {
                		traficoConsol.getConsolidado().setCuotaCompensatoria(1);
					}else {
						traficoConsol.getConsolidado().setCuotaCompensatoria(0);
					}
        			
        		}
       
			}
			
			
		} catch (Exception e) {
			log.error(e.getMessage());
			throw e;
		}
		return traficoConsol;

	}
	
	
	private String setcuotaC(String key, String material, List<Map<String, Object>> result ) {
		String haveCuotaC = "false";
		for (int i = 0; i < result.size(); i++) {
			if (result.get(i).get("claveProducto").equals(material)) {
				haveCuotaC = result.get(i).get("haveCuotaC").toString();
				break;
			}
		}
		return haveCuotaC;
	}

	@Override
	public TraficoConsolVO validaEnviaTrafico(String proveedor, String booking) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int actualizaEstatusAceptacion(Integer sar) throws ClassNotFoundException, SQLException {
		Connection conn = ConexionDB.dameConexion() ;
		int resultado;
		StringBuilder query = new StringBuilder();
		query.append("UPDATE FACTURACION ");
		query.append("SET factura_status = ? ,");
		query.append("para_envio_a_trafico= 1 ");
		query.append("WHERE sar = ?  ");

		PreparedStatement stmt = conn.prepareStatement(query.toString());
		stmt.setInt(1, CatStatusFactura.ENTREGADO_TRAFICO.getId());
		stmt.setInt(2, sar);
		resultado = stmt.executeUpdate();
		return resultado;
	}

	@Override
	public int actualizaEstatusRechazo(Integer sar, Integer id,String observacionesTrafico) throws ClassNotFoundException, SQLException{
		Connection conn = ConexionDB.dameConexion() ;
		int resultado;
		StringBuilder query = new StringBuilder();
		query.append("UPDATE FACTURACION ");
		query.append("SET factura_status = ?, ");
		query.append("para_envio_a_trafico= 0 ,");
		query.append("observaciones_trafico= ? ");
		query.append("WHERE sar = ?  ");
		query.append("and id = ?  ");

		PreparedStatement stmt = conn.prepareStatement(query.toString());
		stmt.setInt(1, CatStatusFactura.RECHAZADO_TRAFICO.getId());
		stmt.setString(2, observacionesTrafico);
		stmt.setInt(3, sar);
		stmt.setInt(4, id);
		resultado = stmt.executeUpdate();
		return resultado;
		
	}

}
