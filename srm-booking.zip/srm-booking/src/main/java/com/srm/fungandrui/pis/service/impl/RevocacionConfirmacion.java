package com.srm.fungandrui.pis.service.impl;

import lombok.Data;

@Data
public class RevocacionConfirmacion {
	private String ebeln;
	private String ebelp;
	private String nivelpo;
	private String nivelgm;
	private String userName;

}
