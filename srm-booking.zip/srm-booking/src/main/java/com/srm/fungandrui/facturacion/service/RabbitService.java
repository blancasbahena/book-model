package com.srm.fungandrui.facturacion.service;

import javax.servlet.http.HttpSession;

import com.srm.fungandrui.facturacion.dao.PeticionRabbit;
import com.srm.fungandrui.facturacion.models.BeanFacturacion;
import com.srm.fungandrui.facturacion.models.Facturacion;
import com.srm.fungandrui.sc.model.ResponseVO;
import com.truper.expediente.ExpedientePerfilDTO;

public interface RabbitService {
	
	public ResponseVO solicitaFacturacion(BeanFacturacion factura,Integer idUser,String userName);
	
	public ResponseVO entregaSIFE(Facturacion factura,HttpSession sesion);

	public ResponseVO cancelaFacturacion(String sar,String username,Integer userProfile);
	
	public ResponseVO facturacionManual(String noFactura);
	
	public ResponseVO facturacionPorTipoDePago(String sar,String condicionPAgo);
	
	public ResponseVO refacturacion(BeanFacturacion datos,Integer userId);
	
	public ResponseVO bloqueoPOs(String folio);
	
	void envioDTOAExpediente(ExpedientePerfilDTO dto);
	
	/**
	 * Servicios de prueba
	 */
	
	public PeticionRabbit testFacturacion(PeticionRabbit peticion);
	
	public PeticionRabbit testFRFacturacion(PeticionRabbit peticion);
	
}
