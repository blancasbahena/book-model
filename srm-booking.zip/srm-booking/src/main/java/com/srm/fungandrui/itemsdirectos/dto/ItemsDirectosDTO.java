package com.srm.fungandrui.itemsdirectos.dto;

import java.io.Serializable;
import java.util.List;

import lombok.Data;

@Data
public class ItemsDirectosDTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -8107136428951336510L;
	
	private Integer folio;
	
	private String comentario;
	
	private List<Items> listaItems;

}
