package com.srm.fungandrui.sc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.srm.pli.bo.RevisionIDAVistaBean;
import com.srm.pli.bo.SarBO;
import com.srm.pli.bo.SarConsolBO;
import com.srm.pli.db.ConexionDB;
import com.srm.pli.utils.FuncionesComunesPLI;
import com.truper.businessEntity.ProductoBean;

import lombok.extern.slf4j.Slf4j;;

@Slf4j
@Repository
public class SarDAOImpl implements SarDAO {

	ProductoBean prod = new ProductoBean();
	String nameTable;
	String SQL;

	@Override
	public ArrayList<SarConsolBO> listHighVolSarConsolBO(ArrayList<SarConsolBO> listaConsol) {
		String SQL = " select distinct  det.material from  cdiSAR sar  "
				+ "   inner join cdiSARDetalle det  on sar.folio = det.folio "
				+ "				 	 where sar.folioConsolidado in (?) ";

		ArrayList<SarConsolBO> listNotHighVol = new ArrayList<SarConsolBO>();
		Connection conn = null;
		int cont=0;	
		try {
			conn = ConexionDB.dameConexion();
			try (PreparedStatement pstmt = conn.prepareStatement(SQL)) {
				for (SarConsolBO sar : listaConsol) {
					 if(!listNotHighVol.contains(sar)) {
				cont++;
				
					pstmt.setInt(1, sar.getFolio());
					ResultSet rs = pstmt.executeQuery();
					while (rs.next()) {
						prod = FuncionesComunesPLI.productos.get(rs.getString("material")); // consultar po
						if (prod != null && prod.isHighVolumeProduct()) {
							listNotHighVol.add(sar);
						}
					}
				}}
				listaConsol = listNotHighVol;
			} catch (SQLException eSQL) {
				log.error(getClass().getName() + eSQL.toString());
				ConexionDB.renovar(conn);
			}
		} catch (Exception e) {
			log.error(getClass().getName() + e.toString());
		} finally {
			ConexionDB.devolver(conn);
		}
		return listaConsol;
	}

	@Override
	public List<SarBO> listHighVolSarBO(List<SarBO> listaSARs, String consulta) {

		String SQL = "select distinct det.material from cdiSAR sar  "
				+ " inner join cdiSARDetalle det on  sar.folio = det.folio " + " where sar.folio in (  ?  )";

		if (consulta.equalsIgnoreCase("cdiSAREnRevision"))
			SQL = "select distinct det.material from cdiSAREnRevision sar  "
					+ " inner join cdiSARDetalle det on  sar.folio = det.folio " + " where sar.folio in (  ?  )";

		List<SarBO> listNotHighVol = new ArrayList<SarBO>();
		Connection conn = null;
		try {
			int count=0;
			conn = ConexionDB.dameConexion();
			try (PreparedStatement pstmt = conn.prepareStatement(SQL)) {
				for (SarBO sar : listaSARs) {
					if (!listNotHighVol.contains(sar)) {
						pstmt.setInt(1, sar.getFolio());
						ResultSet rs = pstmt.executeQuery();
						while (rs.next()) {
							count++;
							prod = FuncionesComunesPLI.productos.get(rs.getString("material")); 
							if (prod != null && !prod.isHighVolumeProduct()) {
								listNotHighVol.add(sar);
							}
						}
					}
				}
				listaSARs.removeAll(listNotHighVol);
			} catch (SQLException eSQL) {
				log.error(getClass().getName() + eSQL.toString());
				ConexionDB.renovar(conn);
			}
		} catch (Exception e) {
			log.error(getClass().getName() + e.toString());
		} finally {
			ConexionDB.devolver(conn);
		}
		return listaSARs;
	}

	@Override
	public ArrayList<RevisionIDAVistaBean> listHighVolSarBOIDA(ArrayList<RevisionIDAVistaBean> listaSARsIDA) {
		String SQL = "select distinct det.material from CDISAR_IDA_REVISION sar  "
				+ " inner join cdiSARDetalle det on  sar.folio = det.folio " + " where sar.folio in (  ?  )";
		ArrayList<RevisionIDAVistaBean> listNotHighVol = new ArrayList<RevisionIDAVistaBean>();
		Connection conn = null;
		try {
			conn = ConexionDB.dameConexion();
			try (PreparedStatement pstmt = conn.prepareStatement(SQL)) {
				for (RevisionIDAVistaBean sar : listaSARsIDA) {
					pstmt.setInt(1, sar.getFolio());
					ResultSet rs = pstmt.executeQuery();
					while (rs.next()) {
						prod = FuncionesComunesPLI.productos.get(rs.getString("material")); // consultar material
						if (prod != null && !prod.isHighVolumeProduct() && !listNotHighVol.contains(sar)) {
							listNotHighVol.add(sar);
						}
					}
				}
				listaSARsIDA.removeAll(listNotHighVol);
			} catch (SQLException eSQL) {
				log.error(getClass().getName() + eSQL.toString());
				ConexionDB.renovar(conn);
			}
		} catch (Exception e) {
			log.error(getClass().getName() + e.toString());
		} finally {
			ConexionDB.devolver(conn);
		}
		return listaSARsIDA;
	}

}
