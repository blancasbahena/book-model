package com.srm.fungandrui.expediente.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

import com.srm.fungandrui.facturacion.models.SharepointFile;
import com.srm.fungandrui.facturacion.service.RabbitService;
import com.srm.fungandrui.facturacion.service.impl.RabbitServicesImpl;
import com.srm.pli.bo.FileUploadBO;
import com.srm.pli.enums.Mensajes;
import com.srm.pli.rest.ProveedoresServices;
import com.srm.pli.utils.PropertiesDb;
import com.truper.expediente.AnexosDTO;
import com.truper.expediente.CatTipoDocumentoDTO;
import com.truper.expediente.DocumentoDTO;
import com.truper.expediente.ExpedienteDTO;
import com.truper.expediente.ExpedientePerfilDTO;
import com.truper.expediente.PerfilUsuarioDTO;
import com.truper.expediente.RequestAuth;
import com.truper.expediente.StandarResponse;

import lombok.extern.log4j.Log4j2;
import lombok.extern.slf4j.Slf4j;

@Service
@Log4j2
public class ExpedienteServiceImp implements ExpedienteService {
	@Autowired
	private RestTemplate restTemplate = new RestTemplate();
	@Autowired
	private RabbitService rabbitServices = new RabbitServicesImpl();
	private String pathOrigen = PropertiesDb.getInstance().getString("srm.truper.expediente.folder");
	private final String usrExpe = PropertiesDb.getInstance().getString("api.expediente.user");
	private final String passExpe = PropertiesDb.getInstance().getString("api.expediente.pass");
	private static final String POS_FIJO_ID_UNICO="_@_";
	private final String PROPERTY_URL = "srm.truper.expediente";
	private String urlAuthenticated;
	private String urlPerfil;
	private String urlgetDocument;
	private String urlDeleteDocument;
	private String urlEnviaAnexos;
	private String urlgetIdDocumento;
	private String urlValidaArchivoContendor;
	private String urlgetDeleteDoc;
	private static final Integer ERROR=-1;
	private static final Integer EXISTE=1;
	private static final Integer NO_EXISTE=0;
	private String urlDeleteDocumentAll;
	public void inicializaUrl() {
		String url = PropertiesDb.getInstance().getString(PROPERTY_URL);
		urlAuthenticated = url + "/auth/";
		urlPerfil = url + "/document/idPerfil";
		urlgetDocument = url + "/file/dowloadFile/";
		urlDeleteDocument = url + "/document/delete/";
		urlgetIdDocumento = url + "/document";
		urlgetDeleteDoc = url + "/file/delete";
		urlEnviaAnexos = url + "/anexos";
		urlValidaArchivoContendor = url + "/file/validate/document"; 
		urlDeleteDocumentAll = url + "/file/delete/";
	}
	@Override
	public JSONArray dameExpedientes(List<ExpedientePerfilDTO> listaExpedientes, String posFijo) {
		inicializaUrl();
		JSONArray expedientes = new JSONArray();
		AnexosDTO dtoAnexos =null;
		boolean existeanexos=false;
		try {
			for (ExpedientePerfilDTO exp : listaExpedientes) {
				if(!existeanexos && exp.getAnexos()!=null && exp.getAnexos().getComentarios()!=null) {
					existeanexos=true;
					dtoAnexos = exp.getAnexos();
				}
			}
			for (ExpedientePerfilDTO exp : listaExpedientes) {
				JSONObject expediente = new JSONObject();
				expediente.put("tipo", exp.getId().getIdTipoDocumento().getId());
				expediente.put("descripcion", exp.getId().getIdTipoDocumento().getDescripcion());
				expediente.put("cargar", exp.getCargar());
				if(existeanexos) {
					expediente.put("comentario", dtoAnexos.getComentarios());
					expediente.put("comentarioFlg",true);
				}
				else {
					expediente.put("comentarioFlg",false);
				}	
				JSONArray documentos = new JSONArray();
				if (exp.getDocumentos() != null) {
					for (DocumentoDTO doc : exp.getDocumentos()) {
						JSONObject documento = new JSONObject();
						documento.put("edit", exp.getEditar());
						documento.put("delete", exp.getBorrar());
						documento.put("archivo", doc.getNombreDocumento().replaceAll(doc.getIdUnico() + posFijo, ""));
						documento.put("fecha", doc.getFechaCarga());
						documento.put("id", doc.getId());

						if (doc.getConditions() != null) {
							documento.put("conditions", doc.getConditions());
						} else {
							documento.put("conditions", "");
						}
						documento.put("tipo", doc.getTypeFile());
						documento.put("path", doc.getPathDocumento());
						documentos.put(documento);

					}
					if (!exp.getDocumentos().isEmpty()) {
						expediente.put("documentos", documentos);
					}
				}
				expedientes.put(expediente);
			}
		} catch (Exception ef) {
			log.error("Problemas en " + ef.getMessage());
		}
		return expedientes;
	}

	@Override
	public JSONArray dameExpedientes(String lbcontenedor, String idsTiposDeDocumentosAFiltrar, Integer profile,
			String posFijo,String factura) {
		JSONArray expedientes = new JSONArray();
		inicializaUrl();
		try {
			List<ExpedientePerfilDTO> listaExpedientes = geAllExpedientes(profile, lbcontenedor,
					idsTiposDeDocumentosAFiltrar,factura);
			expedientes = dameExpedientes(listaExpedientes, posFijo);
		} catch (Exception ef) {
			log.error("Problemas en " + ef.getMessage());
		}
		return expedientes;
	}

	@Override
	public JSONArray dameExpedientesEntregaSife(String lbcontenedor, String idsTiposDeDocumentosAFiltrar,
			Integer profile, String posFijo,String invoice,  String condPago) {
	
		JSONArray expedientes = new JSONArray();
		inicializaUrl();
		try {
			List<ExpedientePerfilDTO> listaExpedientes = geAllExpedientes(profile, lbcontenedor,
					idsTiposDeDocumentosAFiltrar,invoice);
			expedientes = dameExpedientesParaSIFE(listaExpedientes, posFijo, condPago);
		} catch (Exception ef) {
			log.error("Problemas en " + ef.getMessage());
		}
		return expedientes;
	}

	private JSONArray dameExpedientesParaSIFE(List<ExpedientePerfilDTO> listaExpedientes, String posFijo, String condPago) {
		JSONArray expedientes = new JSONArray();
		inicializaUrl();
		try {
			for (ExpedientePerfilDTO exp : listaExpedientes) {
				JSONObject expediente = new JSONObject();
				expediente.put("tipo", exp.getId().getIdTipoDocumento().getId());
				expediente.put("descripcion", exp.getId().getIdTipoDocumento().getDescripcion());
				expediente.put("cargar", exp.getCargar());
				JSONArray documentos = new JSONArray();
				if (exp.getDocumentos() != null) {
					for (DocumentoDTO doc : exp.getDocumentos()) {
						JSONObject documento = new JSONObject()	;
						documento.put("edit", exp.getEditar());
						documento.put("delete", exp.getBorrar());
						documento.put("archivo", doc.getNombreDocumento());
						documento.put("fecha", doc.getFechaCarga());
						documento.put("id", doc.getId());
						documento.put("tipo", doc.getTypeFile());
						documento.put("condicionPago",doc.getConditions());
						String invoice= doc.getNumeroFactura()==null? "":
                            (doc.getNumeroFactura().trim().equals("")? "": ("/"+doc.getNumeroFactura()));
						documento.put("path", doc.getPathDocumento()+invoice);
						// valida que sea de tipo factura de proveedor si no es agrega los documentos de lo contario pregunta por la condicion de pago para agregar el que debe ser
						if(doc.getIdTipoDocumento().getId() != 2) {
							documentos.put(documento);							
						}else {
							if(doc.getConditions().contains(condPago)) {
								documentos.put(documento);
							}
						}

					}
					if (!exp.getDocumentos().isEmpty()) {
						expediente.put("documentos", documentos);
					}
				}
				expedientes.put(expediente);
			}
		} catch (Exception ef) {
			log.error("Problemas en " + ef.getMessage());
		}
			
		return expedientes;
	}

	@Override
	public List<ExpedientePerfilDTO> geAllExpedientes(String lbcontenedor, String idsTiposDeDocumentosAFiltrar,
			Integer profile,String factura) {
		inicializaUrl();
		return geAllExpedientes(profile, lbcontenedor, idsTiposDeDocumentosAFiltrar,factura);
	}

	@Override
	public List<ExpedientePerfilDTO> geAllExpedientes(Integer idPerfil, String blContenedor,
			String idsTiposDocumentos,String factura) {
		inicializaUrl();
		List<ExpedientePerfilDTO> response = new ArrayList<ExpedientePerfilDTO>();
		try {
			ResponseEntity<StandarResponse<String>> responseAuthen = authenticated(usrExpe, passExpe,
					urlAuthenticated);
			if (responseAuthen.getStatusCode() == HttpStatus.OK) {
				ResponseEntity<List<ExpedientePerfilDTO>> responsePerfil = findExpedienteByPerfil(
						responseAuthen.getBody(), new Long(idPerfil), urlPerfil, blContenedor, idsTiposDocumentos,factura);
				if (responsePerfil.getStatusCode() == HttpStatus.OK) {
					response = responsePerfil.getBody();
				}
			}
		} catch (Exception ef) {
			log.error("Problemas en " + ef.getMessage());
		}
		return response;
	}

	@Override
	public String getDocumento(Long idDocument, String blContenedor, String div) {
		inicializaUrl();
		String response = "Error. File not found";
		try {
			ResponseEntity<StandarResponse<String>> responseAuthen = authenticated(usrExpe, passExpe,
					urlAuthenticated);
			if (responseAuthen.getStatusCode() == HttpStatus.OK) {
				ResponseEntity<StandarResponse<String>> responseDocument = findDocumentById(responseAuthen.getBody(),
						urlgetDocument, idDocument, blContenedor, div);
				if (responseDocument.getStatusCode() == HttpStatus.OK) {
					if (!responseDocument.getBody().getTipoMensaje().equals(Mensajes.TIPO_ERROR.getMensaje())) {
						response = responseDocument.getBody().getData();
					} else {
						response = "Error." + responseDocument.getBody().getSub();
					}
				}
			}
		} catch (Exception ef) {
			log.error("Problemas en " + ef.getMessage());
		}
		return response;
	}

	@Override
	public String getDocumentoByIdUnico(String container, Integer tipo, String lastUrl, String soloNombreArchivo) {
		inicializaUrl();
		String response = "Error. File not found";
		try {
			ResponseEntity<StandarResponse<String>> responseAuthen = authenticated(usrExpe, passExpe,
					urlAuthenticated);
			if (responseAuthen.getStatusCode() == HttpStatus.OK) {
				ResponseEntity<StandarResponse<String>> responseDocument = findDocumentByIdUnico(
						responseAuthen.getBody(), urlgetIdDocumento, container, tipo, soloNombreArchivo, lastUrl);
				if (responseDocument.getStatusCode() == HttpStatus.OK) {
					response = responseDocument.getBody().getData();
				} else {
					response = "Error." + responseDocument.getBody().getSub();
				}
			}
		} catch (Exception ef) {
			log.error("Problemas en " + ef.getMessage());
		}
		return response;
	}

	@Override
	public DocumentoDTO getDocumentoById(String container, Integer tipo, String lastUrl, String soloNombreArchivo) {
		inicializaUrl();
		try {
			ResponseEntity<StandarResponse<String>> responseAuthen = authenticated(usrExpe, passExpe,
					urlAuthenticated);
			if (responseAuthen.getStatusCode() == HttpStatus.OK) {
				ResponseEntity<StandarResponse<DocumentoDTO>> responseDocument = findDocumentById(
						responseAuthen.getBody(), urlgetIdDocumento, container, tipo, soloNombreArchivo, lastUrl);
				if (responseDocument.getStatusCode() == HttpStatus.OK) {
					return responseDocument.getBody().getData();
				}
			}
		} catch (Exception ef) {
			log.error("Problemas en " + ef.getMessage());
		}
		return null;
	}

	@Override
	public Integer enviaPeticionRabbit(Integer profile, String lbcontenedor, String tipo, FileUploadBO fileUpload,
			String userName, String path, boolean esNuevo, Long id, boolean esNecesarioBorrarArchivo,
			String conditions,String factura,AnexosDTO anexos) {
		inicializaUrl();
		try {
			ResponseEntity<StandarResponse<String>> responseAuth = authenticated(usrExpe, passExpe, urlAuthenticated);
			ResponseEntity<Integer> existe= validaArchivoContendor(responseAuth.getBody(),fileUpload.getIdUnico(),getNombreArchivoSinPrefijo(fileUpload.getFileName()),lbcontenedor);
			if(existe.getStatusCode() ==  HttpStatus.OK) {
				if(existe.getBody().equals(NO_EXISTE)) {
					ExpedientePerfilDTO expediente = ExpedientePerfilDTO.builder()
							.anexos(anexos)
							.nuevo(esNuevo)
							.id(new ExpedienteDTO(profile.longValue(), new Long(tipo)))
							.documentos(Arrays.asList(DocumentoDTO.builder()
							.blContenedor(lbcontenedor).id(id)
							.nombreDocumento(fileUpload.getFileName())
							.descripcion("new file").cargadoPor(userName)
							.modificadoPor(userName).conditions(conditions)
							.idTipoDocumento(new CatTipoDocumentoDTO(new Long(tipo), "", "", ""))
							.numeroFactura(factura)
							.borrarDeDirectorio(true)
							.typeFile(fileUpload.getContentType())
							.size(fileUpload.getSizeFileInBytes())
							.idUnico(fileUpload.getIdUnico())
							.pathOrigenDocumento(pathOrigen).pathDocumento(path).build()))
							.build();
					log.info("Se manda peticion :: {}",expediente.toString());
					rabbitServices.envioDTOAExpediente(expediente);
				}
				log.info("Revisamos Si [{}]&&[{}] existe encolado, idUnico [{}] de la IP  :: {} ==>  {} ",
						fileUpload.getFileName(),lbcontenedor ,fileUpload.getIdUnico(),getIp(),existe.getBody().equals(NO_EXISTE)?"NO_EXISTE":(existe.getBody().equals(EXISTE)?"EXISTE":"ERROR"));
				return existe.getBody();
			}
			log.info("Revisamos Si [{}]&&[{}] existe encolado, idUnico [{}] de la IP  :: {} ==>  {} ",fileUpload.getFileName(),lbcontenedor ,fileUpload.getIdUnico(),getIp(),"ERROR");
			return ERROR;
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		log.info("Revisamos Si [{}]&&[{}] existe encolado, idUnico [{}] de la IP  :: {} ==>  {} ",fileUpload.getFileName(),lbcontenedor ,fileUpload.getIdUnico(),getIp(),"ERROR");
		return ERROR;
	}
	@Override
	public Boolean enviaAnexos(AnexosDTO anexos) {
		inicializaUrl();
		try {
			ResponseEntity<StandarResponse<String>> responseAuth = authenticated(usrExpe, passExpe, urlAuthenticated);
			if (responseAuth.getStatusCode() == HttpStatus.OK) {
				HttpHeaders headers = new HttpHeaders();
				headers.setContentType(MediaType.APPLICATION_JSON);
				headers.set("Authorization", "Bearer " + (String) responseAuth.getBody().getData());
				headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));				
				HttpEntity<AnexosDTO> request = new HttpEntity<>(anexos , headers);
				ResponseEntity<StandarResponse<Boolean>> respuesta =restTemplate.exchange(urlEnviaAnexos, HttpMethod.POST, request,
						new ParameterizedTypeReference<StandarResponse<Boolean>>() {});
				if (respuesta.getStatusCode() == HttpStatus.OK) {
					return respuesta.getBody().getData();
				}
			}
		} catch (Exception ef) {
			log.error("Problemas en " + ef.getMessage());
		}
		return false;
	}
	@Override
	public void seBorraRabbit(String contenedor, List<Long> ids, String nombre) {
		inicializaUrl();
		try {
			ResponseEntity<StandarResponse<String>> responseAuth = authenticated(usrExpe, passExpe, urlAuthenticated);
			if (responseAuth.getStatusCode() == HttpStatus.OK) {
				HttpHeaders headers = new HttpHeaders();
				headers.setContentType(MediaType.APPLICATION_JSON);
				headers.set("Authorization", "Bearer " + (String) responseAuth.getBody().getData());
				headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
				
				UriComponents builder = getUriBorrarDocs(contenedor,nombre,ids);
				
				HttpEntity<Boolean> request = new HttpEntity<Boolean>(headers);
				ResponseEntity<StandarResponse<Boolean>> respuesta = restTemplate.exchange(
						builder.toUriString(), HttpMethod.DELETE, request,
						new ParameterizedTypeReference<StandarResponse<Boolean>>() {
						});
			}
		} catch (Exception ef) {
			log.error("Problemas en " + ef.getMessage());
		}
	}
	@Override
	public Boolean seBorroEnBaseDatos(Long id, String usuario) {
		inicializaUrl();
		try {
			ResponseEntity<StandarResponse<String>> responseAuth = authenticated(usrExpe, passExpe, urlAuthenticated);
			if (responseAuth.getStatusCode() == HttpStatus.OK) {
				HttpHeaders headers = new HttpHeaders();
				headers.setContentType(MediaType.APPLICATION_JSON);
				headers.set("Authorization", "Bearer " + (String) responseAuth.getBody().getData());
				headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
				HttpEntity<String> request = new HttpEntity<String>(headers);
				ResponseEntity<StandarResponse<Boolean>> respuesta = restTemplate.exchange(
						urlDeleteDocument + id + "/" + usuario, HttpMethod.DELETE, request,
						new ParameterizedTypeReference<StandarResponse<Boolean>>() {
						});
				if (respuesta.getStatusCode() == HttpStatus.OK) {
					return true;
				}
			}
		} catch (Exception ef) {
			log.error("Problemas en " + ef.getMessage());
		}
		return false;
	}

	@SuppressWarnings("unused")
	private ResponseEntity<StandarResponse<String>> authenticated(final String user, final String pass,
			final String url) {
		inicializaUrl();
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
		HttpEntity<RequestAuth> request = new HttpEntity<>(new RequestAuth(user, pass), headers);
		return restTemplate.exchange(url, HttpMethod.POST, request,
				new ParameterizedTypeReference<StandarResponse<String>>() {
				});

	}

	@SuppressWarnings("unused")
	private ResponseEntity<List<ExpedientePerfilDTO>> findExpedienteByPerfil(final StandarResponse<?> responseAuth,
			final Long id, final String urlPerfil, final String blContenedor, String idsTiposDocumentos,String factura) {
		HttpHeaders headers = new HttpHeaders();
		UriComponents builder = getUriComponents(id, idsTiposDocumentos, blContenedor,factura);
		List<ExpedientePerfilDTO> lista = new ArrayList<ExpedientePerfilDTO>();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.set("Authorization", "Bearer " + (String) responseAuth.getData());
		headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
		HttpEntity<String> request = new HttpEntity<String>(headers);
		ResponseEntity<StandarResponse<List<ExpedientePerfilDTO>>> respuesta = restTemplate.exchange(
				builder.toUriString(), HttpMethod.GET, request,
				new ParameterizedTypeReference<StandarResponse<List<ExpedientePerfilDTO>>>() {
				});
		if (respuesta.getStatusCode() == HttpStatus.OK) {
			lista = respuesta.getBody().getData();
		}
		return ResponseEntity.status(HttpStatus.OK).body(lista);
	}
	private UriComponents getUriBorrarDocs(String contenedor, String nombre, List<Long>  ids) {

		if (nombre != null) 
		{
			return UriComponentsBuilder.fromHttpUrl(urlgetDeleteDoc+"/"+contenedor).queryParam("nombre", nombre).queryParam("ids", ids).build();
		}
		return UriComponentsBuilder.fromHttpUrl(urlgetDeleteDoc+"/"+contenedor).queryParam("ids", ids).build();
	}
	private UriComponents getUriComponents(Long id, String idsTiposDocumentos, String blContenedor,String factura) {

		if (idsTiposDocumentos != null && (!idsTiposDocumentos.isEmpty())) {
			return UriComponentsBuilder.fromHttpUrl(urlPerfil).queryParam("id", id.toString())
					.queryParam("ids", idsTiposDocumentos).queryParam("blContenedor", blContenedor).queryParam("factura", factura).build();
		}
		return UriComponentsBuilder.fromHttpUrl(urlPerfil).queryParam("factura", factura).queryParam("id", id.toString())
				.queryParam("blContenedor", blContenedor).build();
	}

	@SuppressWarnings("unused")
	private ResponseEntity<StandarResponse<String>> findDocumentById(final StandarResponse<?> responseAuth,
			final String urlDocument, final Long id, final String blContenedor, String div) {

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.set("Authorization", "Bearer " + (String) responseAuth.getData());
		headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
		HttpEntity<String> request = new HttpEntity<String>(headers);
		return restTemplate.exchange(urlDocument + id + "/" + blContenedor + "/" + div, HttpMethod.POST, request,
				new ParameterizedTypeReference<StandarResponse<String>>() {
				});
	}

	@SuppressWarnings("unused")
	private ResponseEntity<Integer> guardarEnBaseDatos(final StandarResponse<?> responseAuth,
			ExpedientePerfilDTO expediente, final String url) {

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.set("Authorization", "Bearer " + (String) responseAuth.getData());
		headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
		HttpEntity<ExpedientePerfilDTO> request = new HttpEntity<>(expediente, headers);
		return restTemplate.exchange(url, HttpMethod.POST, request, new ParameterizedTypeReference<Integer>() {
		});
	}

	@SuppressWarnings("unused")
	private ResponseEntity<StandarResponse<String>> findDocumentByIdUnico(final StandarResponse<?> responseAuth,
			final String urlDocument, final String container, final Integer tipo, final String soloNombre,
			final String lastUrl) {

		HttpHeaders headers = new HttpHeaders();
		UriComponents builder = UriComponentsBuilder
				.fromHttpUrl(urlDocument + "/" + container + "/" + tipo + "/" + lastUrl)
				.queryParam("soloNombre", soloNombre).build();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.set("Authorization", "Bearer " + (String) responseAuth.getData());
		headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
		HttpEntity<String> request = new HttpEntity<String>(headers);
		return restTemplate.exchange(builder.toUriString(), HttpMethod.GET, request,
				new ParameterizedTypeReference<StandarResponse<String>>() {
				});
	}

	@SuppressWarnings("unused")
	private ResponseEntity<StandarResponse<DocumentoDTO>> findDocumentById(final StandarResponse<?> responseAuth,
			final String urlDocument, final String container, final Integer tipo, final String soloNombre,
			final String lastUrl) {
		HttpHeaders headers = new HttpHeaders();
		UriComponents builder = UriComponentsBuilder
				.fromHttpUrl(urlDocument + "/" + container + "/" + tipo + "/" + lastUrl)
				.queryParam("soloNombre", soloNombre).build();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.set("Authorization", "Bearer " + (String) responseAuth.getData());
		headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
		HttpEntity<String> request = new HttpEntity<String>(headers);
		return restTemplate.exchange(builder.toUriString(), HttpMethod.GET, request,
				new ParameterizedTypeReference<StandarResponse<DocumentoDTO>>() {
				});
	}

	public String copyReturnPath(String path, String fileName, String pathTMP, Long idUnico, String posfijo) {
		File origen = new File(path + File.separator + fileName);
		File destino = new File(pathTMP + File.separator + idUnico + posfijo + fileName);
		try {
			InputStream in = new FileInputStream(origen);
			OutputStream out = new FileOutputStream(destino);
			byte[] buf = new byte[1024];
			int len;
			while ((len = in.read(buf)) > 0) {
				out.write(buf, 0, len);
			}
			in.close();
			out.close();
			return destino.getParent();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	public boolean copy(File origen, File destino) {

		try {
			InputStream in = new FileInputStream(origen);
			OutputStream out = new FileOutputStream(destino);
			byte[] buf = new byte[1024];
			int len;
			while ((len = in.read(buf)) > 0) {
				out.write(buf, 0, len);
			}
			in.close();
			out.close();
			return true;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return false;
	}

	@Override
	public ExpedientePerfilDTO getExpediente(String contenedor, String idsTiposAfiltrar, Integer tipoDocumento,
			List<String> nombreArchivos) {
		ExpedientePerfilDTO dto = new ExpedientePerfilDTO();
		PerfilUsuarioDTO perfil = PerfilUsuarioDTO.builder().id(1l).descripcion("").build();
		CatTipoDocumentoDTO tipo = new CatTipoDocumentoDTO(new Long(tipoDocumento), "", "", "");
		if (nombreArchivos != null) {
			List<DocumentoDTO> listaDocs = new ArrayList<DocumentoDTO>();
			for (int i = 0; i < nombreArchivos.size(); i++) {
				DocumentoDTO doc = getDocumentoById(contenedor, tipoDocumento, "documento", nombreArchivos.get(i));
				if (doc != null) {
					listaDocs.add(doc);
				}
			}
			dto = ExpedientePerfilDTO.builder().nuevo(true).id(new ExpedienteDTO(perfil, tipo)).documentos(listaDocs)
					.build();
		}
		return dto;
	}

	private ResponseEntity<Integer> validaArchivoContendor(final StandarResponse<?> responseAuth,
			final Long idUnico, final String nombreArchivo, final String blcontenedor) {

		HttpHeaders headers = new HttpHeaders();
		UriComponents builder = UriComponentsBuilder.fromHttpUrl(urlValidaArchivoContendor)
				.queryParam("idUnico", idUnico)
				.queryParam("ip", getIp())
				.queryParam("nombreArchivo", nombreArchivo)
				.queryParam("blcontenedor", blcontenedor).build();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.set("Authorization", "Bearer " + (String) responseAuth.getData());
		headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
		HttpEntity<String> request = new HttpEntity<String>(headers);
		return restTemplate.exchange(builder.toUriString(), HttpMethod.GET, request,
				new ParameterizedTypeReference<Integer>() {
				});
	}
	private String getNombreArchivoSinPrefijo(String nombre) {
		int posision = nombre.indexOf(POS_FIJO_ID_UNICO);
		if(posision>0) {
			return nombre.substring(posision+POS_FIJO_ID_UNICO.length(),nombre.length());
		}
		return nombre;
	}
	private String getIp() {
		String IP_local = "";
		try {
			InetAddress direccion = InetAddress.getLocalHost();
			IP_local = direccion.getHostAddress();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return IP_local;
	}
	

	@Override
	public Boolean seBorroEnBaseDatosAll(String blContenedor,Long id) {
		inicializaUrl();
		try {
			ResponseEntity<StandarResponse<String>> responseAuth = authenticated(usrExpe, passExpe, urlAuthenticated);
			if (responseAuth.getStatusCode() == HttpStatus.OK) {
				HttpHeaders headers = new HttpHeaders();
				headers.setContentType(MediaType.APPLICATION_JSON);
				headers.set("Authorization", "Bearer " + (String) responseAuth.getBody().getData());
				headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
				HttpEntity<String> request = new HttpEntity<String>(headers);
				ResponseEntity<StandarResponse<Boolean>> respuesta = restTemplate.exchange(
						urlDeleteDocumentAll + blContenedor + "/" + id, HttpMethod.DELETE, request,
						new ParameterizedTypeReference<StandarResponse<Boolean>>() {
						});
				if (respuesta.getStatusCode() == HttpStatus.OK) {
					return true;
				}
			}
		} catch (Exception ef) {
			log.error("Problemas en " + ef.getMessage());
		}
		return false;
	}	

}
