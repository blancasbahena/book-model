package com.srm.fungandrui.sc.model;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class FiltroEntregaTrafico implements Serializable {
	private static final long serialVersionUID = -1882848389879432129L;

	private String tipoBusqueda;
	private String folio;
	private String po;
	private String blNumber;
	private String booking;
	private String contenedor;
	private String proveedor;
	private String carrier;
	private String analyst;
	private String invoiceNumber;
	private String priority;
	private String etaFrom;
	private String etaTo;
	private String pod;
	private String fechaInicial;
	private String fechaFinal;
	private String paginaAccion;
	private String paginaActual;
	
	
	

}
