package com.srm.fungandrui.pis.controller;
import org.springframework.web.bind.annotation.RequestBody;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.srm.app.constantes.Mensajes;
import com.srm.fungandrui.pis.dto.ProformaDetalleDTO;
import com.srm.fungandrui.pis.dto.ProformaInvoiceDTO;
import com.srm.fungandrui.pis.repository.ProformaDetalleDao;
import com.srm.fungandrui.pis.repository.ProformaInvoiceDao;
import com.srm.fungandrui.pis.service.PisService;
import com.srm.fungandrui.sc.model.BeanSession;
import com.srm.fungandrui.sc.model.ResponseVO;
import com.srm.fungandrui.sc.utils.SessionUtil;
import com.srm.pli.bo.BeanContactoDocumentos;
import com.srm.pli.utils.FuncionesComunesPLI;
import com.srm.pli.utils.GeneraDocumentos;
import com.srm.pli.utils.uploadFile.UploadUtils;
import com.truper.businessEntity.ImportacionesProveedoresBean;

import lombok.extern.log4j.Log4j2;
import com.srm.fungandrui.pis.dao.PisDao;
import com.srm.fungandrui.pis.dto.PeticionCambioEstatusDTO;
@Log4j2
@Controller
@RequestMapping("/entregaProforma")
public class EntregaProforma {

	@Autowired
	HttpServletRequest request; 
	
	@Autowired
	private PisService pisService;
	
	@Autowired
	private ProformaDetalleDao detalle;
	
	@Autowired
	private ProformaInvoiceDao invoice;
	
	@Autowired
	private PisDao pisDao;
	
	public static final Logger LOGGER = LogManager.getRootLogger();
	public static UploadUtils properties = null; 
	
	public void init() throws ServletException {
		FuncionesComunesPLI.cargaPropertiesCDI(false);
		FuncionesComunesPLI.cargaPlanners(false);
		FuncionesComunesPLI.cargaMapaActionsSARHistoryLog(false);
		FuncionesComunesPLI.cargaPaisesDestinoCDI(false);
		FuncionesComunesPLI.getProveedores(false); 
		properties = UploadUtils.getInstance();
	} 
	
	@RequestMapping(value = "/validaNumberInvoice", method = {  RequestMethod.POST })
	public ResponseEntity<ResponseVO> validaInvoice(@RequestParam String  invoiceNumber,
			@RequestParam Integer idPi,@RequestParam String proveedor)  {
		ResponseVO response = new ResponseVO();
		boolean respuesta=false;
		Map<String, Object> data = new HashMap<String, Object>();
		response.setTipoMensaje(Mensajes.TIPO_EXITO.getMensaje());
		response.setMensaje(Mensajes.MSG_EXITO.getMensaje());
		List<ProformaInvoiceDTO> pfms= invoice.getAllInvoiceNumber();
		try {
			if(pfms !=null && !pfms.isEmpty() && proveedor!=null && invoiceNumber!=null ) {
				List<ProformaInvoiceDTO> pfmsFiltradas=pfms.stream()
						.filter(o-> o.getProveedor().trim().equals(proveedor.trim())).collect(Collectors.toList());
				if(pfmsFiltradas !=null && !pfmsFiltradas.isEmpty()) {
					Optional<ProformaInvoiceDTO> optNumber = pfmsFiltradas.stream()
							.filter(o-> o.getProveedor().trim().equals(proveedor.trim()))
							.filter(o-> o.getProformaNumber().trim().equals(invoiceNumber.trim())).findAny();
					Optional<ProformaInvoiceDTO> optIdPis  = pfmsFiltradas.stream()
							.filter(o-> o.getProveedor().trim().equals(proveedor.trim()))
							.filter(o-> o.getIdPi().intValue()== idPi.intValue())
							.filter(o-> o.getProformaNumber().trim().equals(invoiceNumber.trim())).findAny();
					if(optNumber!=null) {
						if(optNumber.isPresent()) {
							respuesta =  true;
							if(optIdPis!=null) {
								if(optIdPis.isPresent()) {
									if(optIdPis.get().getProformaNumber().equals(invoiceNumber)) {
										respuesta =  false;
									}
								}
							}
						}
					}
				}
			}
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		data.put("respuesta",new Boolean(respuesta));
		response.setResponseObject(data); 
		return ResponseEntity.status(HttpStatus.OK).body(response);
	}
	@RequestMapping(value = "/detalle", method = {  RequestMethod.POST })
	public ResponseEntity<ResponseVO> leerDetalle(@RequestParam Integer  numeroOrden)  {
		ResponseVO response = new ResponseVO();
		HttpSession session = null;
		BeanSession beanSession; 
		Map<String, Object> data = new HashMap<String, Object>();
		session = request.getSession(false);
		beanSession = SessionUtil.validaSesion(session);   
		List<ProformaInvoiceDTO> listInvoice=invoice.getAll( numeroOrden); 
		if(listInvoice!=null && listInvoice.size()>0) {
			ProformaInvoiceDTO dto = listInvoice.get(0);
		
			ImportacionesProveedoresBean  imBeanProv 	= FuncionesComunesPLI.getProveedor(dto.getProveedor());
			String  inco = (imBeanProv.getIncotetm_cve() != null ? imBeanProv.getIncotetm_cve() : "" );
			inco+= ", ";
			inco+= (imBeanProv.getIncotetm_def() != null ? imBeanProv.getIncotetm_def() : "" );
			inco+= ", ";
			inco+= (imBeanProv.getPais() != null ? imBeanProv.getPais() : "" );
		
			listInvoice.get(0).setIncoterm(inco);
			String condPagoDesc="-|-";
			try {
				if(dto.getCondicionPago()!=null && !dto.getCondicionPago().equals("")) {
					condPagoDesc = dto.getCondicionPago() +"|"+ 
							FuncionesComunesPLI.dameMapaCondicionPago(false).get(dto.getCondicionPago());
				}
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			listInvoice.get(0).setCondicionPago(condPagoDesc);
			data.put("invoice",listInvoice.get(0));
			List<ProformaDetalleDTO> listDetalle=detalle.getAll(numeroOrden); 
			
			String company = "";
			ImportacionesProveedoresBean consignee = new ImportacionesProveedoresBean();
			GeneraDocumentos generaDocumentos = new GeneraDocumentos();
			BeanContactoDocumentos documentos = new BeanContactoDocumentos();

			try {
				if(consignee != null) {
					consignee = FuncionesComunesPLI.getProveedor(listDetalle.get(0).getCliente());
				}
				
				documentos = generaDocumentos.generaContactosDocumentos(imBeanProv, consignee);
				company = documentos.getNombre_shipper();
			} catch (Exception e) {
				log.error("Ocurrio un error al intentar obtener la empresa {} : ", e.getMessage());
			}
		
			data.put("company", company);	
			data.put("detalles",listDetalle);
		} 
		response.setTipoMensaje(Mensajes.TIPO_EXITO.getMensaje());
		response.setMensaje(Mensajes.MSG_EXITO.getMensaje());
		response.setResponseObject(data);  
		return ResponseEntity.status(HttpStatus.OK).body(response);
	}
	public Locale validateSession() throws Exception {
		HttpSession session = null;
		BeanSession beanSession;
		session = request.getSession(false);
		beanSession = SessionUtil.validaSesion(session);
		if (beanSession == null)
			throw new Exception("session invalida");
		
		Locale currentLocale = session.getAttribute("javax.servlet.jsp.jstl.fmt.locale.session") == null
				? new Locale("en", "US")
				: (Locale) session.getAttribute("javax.servlet.jsp.jstl.fmt.locale.session");
		
		return currentLocale;
	}

	@RequestMapping(value = "/cambiaEstatusDetalle", method = {  RequestMethod.POST })
	public ResponseEntity<ResponseVO> cambiaEstatusDetalle(@RequestBody PeticionCambioEstatusDTO dto)  {
		log.info("Se cambia estatus  /cambiaEstatusDetalle");
		ResponseVO response = new ResponseVO();
		boolean respuesta=false;
		Map<String, Object> data = new HashMap<String, Object>();
		response.setTipoMensaje(Mensajes.TIPO_EXITO.getMensaje());
		response.setMensaje(Mensajes.MSG_EXITO.getMensaje());
		int resultado =0;
		try {
			resultado = pisDao.actualizarEstatusDetalle(dto);
		} catch (Exception e) {
			log.error("Problemas con detalle x posicion ",e);
		}
		log.info("Se cambia estatus  /cambiaEstatusDetalle  respuesta: {} ",resultado);
		if(resultado>0)
			respuesta =true;
		data.put("respuesta",new Boolean(respuesta));
		response.setResponseObject(data); 
		log.info("Termina cambia estatus  /cambiaEstatusDetalle");
		return ResponseEntity.status(HttpStatus.OK).body(response);
	}
	@RequestMapping(value = "/actualizaImagenProveedor", method = {  RequestMethod.POST })
	public ResponseEntity<ResponseVO> cambiaEstatusDetalle(@RequestParam String ipPi,@RequestParam Long idImagen,@RequestParam String user)  {
		ResponseVO response = new ResponseVO();
		boolean respuesta=false;
		Map<String, Object> data = new HashMap<String, Object>();
		response.setTipoMensaje(Mensajes.TIPO_EXITO.getMensaje());
		response.setMensaje(Mensajes.MSG_EXITO.getMensaje());
		try {
			int resultado = pisDao.actualizarImagen(ipPi,idImagen,user);
		} catch (Exception e) {
			log.error("Problemas con Actualizar id imagen ",e);
		}
		data.put("respuesta",new Boolean(respuesta));
		response.setResponseObject(data); 
		return ResponseEntity.status(HttpStatus.OK).body(response);
	}
	@RequestMapping(value = "/cambiaEstatusProforma", method = {  RequestMethod.POST })
	public ResponseEntity<ResponseVO> cambiaEstatusDetalle(@RequestParam String user,@RequestParam Integer status,@RequestParam Integer idPi)  {
		log.info("Se cambia estatus  /cambiaEstatusProforma");
		ResponseVO response = new ResponseVO();
		boolean respuesta=false;
		Map<String, Object> data = new HashMap<String, Object>();
		response.setTipoMensaje(Mensajes.TIPO_EXITO.getMensaje());
		response.setMensaje(Mensajes.MSG_EXITO.getMensaje());
		int resultado =0;
		try {
			resultado = pisDao.cambiaEstatusProforma(idPi,status,user);
			//ProformaInvoiceDTO proformaInvoice =  pisDao.getProforma(idPi);
			//pisDao.creaHistoricoProforma(pisService.convertObject(proformaInvoice));
		} catch (Exception e) {
			log.error("Problemas con detalle x posicion ",e);
		}
		log.info("Se cambia estatus  /cambiaEstatusProforma  respuesta: {} ",resultado);
		if(resultado>0)
			respuesta =true;
		data.put("respuesta",new Boolean(respuesta));
		response.setResponseObject(data); 
		log.info("Termina cambia estatus  /cambiaEstatusDetalle");
		return ResponseEntity.status(HttpStatus.OK).body(response);
	}
	@RequestMapping(value = "/cambiaEstatusProformas", method = {  RequestMethod.POST })
	public ResponseEntity<ResponseVO> cambiaEstatusProformas(@RequestParam Integer status,@RequestParam String user,@RequestParam Integer reject)  {
		log.info("Se cambia estatus  /cambiaEstatusProformas {} ",status);
		ResponseVO response = new ResponseVO();
		boolean respuesta=false;
		Map<String, Object> data = new HashMap<String, Object>();
		response.setTipoMensaje(Mensajes.TIPO_EXITO.getMensaje());
		response.setMensaje(Mensajes.MSG_EXITO.getMensaje());
		int resultado =0;
		try {
			resultado = pisDao.cambiaEstatusProformas(status,user,reject);
		} catch (Exception e) {
			log.error("Problemas con detalle x posicion ",e);
		}
		log.info("Se cambia estatus  /cambiaEstatusProforma  respuesta: {} ",resultado);
		if(resultado>0)
			respuesta =true;
		data.put("respuesta",new Boolean(respuesta));
		response.setResponseObject(data); 
		log.info("Termina cambia estatus  /cambiaEstatusDetalle");
		return ResponseEntity.status(HttpStatus.OK).body(response);
	}
}
