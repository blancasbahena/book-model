package com.srm.fungandrui.facturacion.models;

import lombok.Data;

@Data
public class RechazadosFacturacion {
	
	private String folio;
	private String po;
	private String blNumber;
	private String booking;
	private String container;
	private String supplier;
	private String carrier;
	private String analyst;
	private String invoiceNumber;
	private String priority;
	private String eta;
	private String pod;

}
