package com.srm.fungandrui.facturacion.models;

import lombok.Data;

@Data
public class SharepointFile {

	private String file;
	private String documentType;
	
}
