package com.srm.fungandrui.pis.service.impl;

import java.util.List;


public interface RevocacionConfirmacionDao {
	
	List<RevocacionConfirmacion> getListByFolio(String folio, String userName);

}
