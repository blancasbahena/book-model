package com.srm.fungandrui.facturacion.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.srm.fungandrui.facturacion.dao.PeticionRabbit;
import com.srm.fungandrui.facturacion.service.FacturacionRestService;

import lombok.extern.slf4j.Slf4j;
@Controller
@RequestMapping("/facturacionManual")
@Slf4j
public class FacturacionManualController {
 
	@Autowired
	FacturacionRestService services;
	@RequestMapping(value = "/", method = { RequestMethod.GET, RequestMethod.POST })
	public String obtieneRespuestaFacturacion(@RequestBody PeticionRabbit peticion) {
		try {
			String cadena= services.obtieneRespuestaFacturacion(peticion);
			log.info("Servicio "+cadena);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			log.error("Error en facturacion Manual ",e);
		}
		return null;
	}
}
