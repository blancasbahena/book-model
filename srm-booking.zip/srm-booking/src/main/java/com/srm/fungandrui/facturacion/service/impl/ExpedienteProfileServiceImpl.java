package com.srm.fungandrui.facturacion.service.impl;

import java.util.List;

import javax.servlet.ServletException;

import org.springframework.stereotype.Service;

import com.srm.fungandrui.facturacion.service.ExpedienteProfileService;
import com.srm.pli.dao.SAR_CDI_DAO;
import com.truper.businessEntity.UserBean;
import com.truper.businessEntity.UserProfileBean;

@Service
public class ExpedienteProfileServiceImpl implements ExpedienteProfileService {

	@Override
	public List<UserProfileBean> getConsultaPerfilUsuario() throws ServletException {
		UserBean usuario = new UserBean();
		usuario.setUserProfile(null);
		return SAR_CDI_DAO.consultaPerfilUsuario(usuario);
	}

}
