package com.srm.fungandrui.expediente.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;

import com.srm.pli.bo.FileUploadBO;
import com.truper.expediente.AnexosDTO;
import com.truper.expediente.DocumentoDTO;
import com.truper.expediente.ExpedientePerfilDTO;
public interface ExpedienteService {

	List<ExpedientePerfilDTO> geAllExpedientes(Integer idPerfil, String blContenedor,String idsTiposDocumentos,String factura);
	
	String getDocumento(Long idDocument,String blContenedor,String div);

	Integer enviaPeticionRabbit(Integer profile,String lbcontenedor,String tipo,FileUploadBO fileUploadBO,String userName,
			String path,boolean esNuevo,Long id,boolean esNecesarioBorrarArchivo,String conditions,String factura,AnexosDTO anexos);
	
	Boolean seBorroEnBaseDatos(Long id,String usuario);
	
	JSONArray dameExpedientes(String lbcontenedor, String idsTiposDeDocumentosAFiltrar,Integer profile,String posFijo,String factura);
	
	JSONArray dameExpedientes(List<ExpedientePerfilDTO> lista,String posFijo);
	
	String getDocumentoByIdUnico(String container,Integer tipo,String lastUrl,String soloNombreArchivo) ;

	DocumentoDTO getDocumentoById(String container,Integer tipo,String lastUrl,String soloNombreArchivo);

	List<ExpedientePerfilDTO> geAllExpedientes(String lbcontenedor, String idsTiposDeDocumentosAFiltrar,Integer profile,String factura) ;
	 
	public String copyReturnPath(String path, String fileName,String pathTMP,Long idUnico,String posfijo);
	
	JSONArray dameExpedientesEntregaSife(String lbcontenedor, String idsTiposDeDocumentosAFiltrar,Integer profile,String posFijo,String invoice,  String condPago);
	
	public  ExpedientePerfilDTO getExpediente(String contenedor, String idsTiposAfiltrar,Integer tipoDocumento,List<String> nombreArchivos );
	
	public boolean copy(File origen, File destino);

	public Boolean enviaAnexos(AnexosDTO anexos);

	void seBorraRabbit(String string, List<Long> ids, String nombre);

	Boolean seBorroEnBaseDatosAll(String blContenedor, Long id);
	 
}