package com.srm.fungandrui.facturacion.service;

import java.util.List;

import com.srm.fungandrui.facturacion.models.BeanFacturacion;
import com.srm.fungandrui.facturacion.models.CatCorreccionModel;
import com.srm.fungandrui.facturacion.models.CatStatusFacturacion;
import com.srm.fungandrui.facturacion.models.CatStatusIncidencias;
import com.srm.fungandrui.facturacion.models.ControlEmbarqueModel;
import com.srm.fungandrui.facturacion.models.EntregaTraficoModel;
import com.srm.fungandrui.facturacion.models.Facturacion;
import com.srm.fungandrui.facturacion.models.FacturacionReporte;
import com.srm.fungandrui.sc.model.FiltroEntregaTrafico;

public interface FactService {
	
	
	List<Facturacion> getFacturacion();
	List<Facturacion> getbyFilterService(Facturacion filtro);
	List<Facturacion> getbyFilterServiceRejectd (Facturacion filtro);
//	List<Facturacion> getListRejectd ();
	public void updateIncidence (BeanFacturacion beanFacturacion, String userName);

	String getEmails(String numIncidencia);
	List<CatStatusFacturacion> getStatusFacturacion(String options);
	public void updateStatusFacturacion (BeanFacturacion beanFacturacion, String userName);

	List<EntregaTraficoModel> getListEntrgeaDocsFinales(String status, FiltroEntregaTrafico filtro);
	
	List<ControlEmbarqueModel> getListControlEmbarque(FiltroEntregaTrafico filtro);
	
	public void cancelacionComments(Facturacion filtro, String userName,Integer userProfile ) throws Exception;
	
	
	public List<CatCorreccionModel> getCatCorreccion();
	
	
	public void correccion(Facturacion filtro, String userName, String status) throws Exception;
	
	
	public Integer enviaTrafico(Facturacion filtro) throws Exception;
	
	public List<FacturacionReporte> getListReport (FacturacionReporte facturacionReporteFiltro);
	
	List<EntregaTraficoModel> getListRechazadosTrafico(String status, FiltroEntregaTrafico filtro);
	
//	public List<ReporteSemanalIncidencias> getReporteSemanalIncidencias ();
	public Boolean deleteFact(Integer idFact) throws Exception;
	
	
	public Integer rejectIncidence(Facturacion filtro, String userName, String status) throws Exception;
	
	List<CatStatusIncidencias> getListCatIncidencias();
	
}
