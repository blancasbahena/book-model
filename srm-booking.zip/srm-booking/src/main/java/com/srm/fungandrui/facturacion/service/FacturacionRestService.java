package com.srm.fungandrui.facturacion.service;
import com.srm.fungandrui.facturacion.dao.PeticionRabbit;
import com.srm.fungandrui.facturacion.models.Facturacion;
public interface FacturacionRestService {
	
	String obtieneRespuestaFacturacion(PeticionRabbit peticion) throws ClassNotFoundException; 
	
}
