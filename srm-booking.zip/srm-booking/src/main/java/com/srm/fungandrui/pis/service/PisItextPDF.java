package com.srm.fungandrui.pis.service;

import java.io.IOException;
import java.net.MalformedURLException;

import com.lowagie.text.DocumentException;
import com.lowagie.text.BadElementException;
import com.lowagie.text.Image;

public interface PisItextPDF {
	Image getImage(String imageFileName,float x, float y) throws BadElementException, MalformedURLException, IOException ;
	void createPdf(String rutaEntrada,String fileEntrada,String rutaSalida,String fileSalida,String imageFileName,
			float x, float y) throws IOException, DocumentException;
}
