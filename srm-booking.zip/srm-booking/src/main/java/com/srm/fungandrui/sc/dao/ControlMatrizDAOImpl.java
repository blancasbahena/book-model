package com.srm.fungandrui.sc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.srm.fungandrui.sc.model.ProveedorVO;
import com.srm.pli.db.ConexionDB;
import com.truper.bpm.enums.StatusControlMatricesEnum;
import com.truper.businessEntity.UserBean;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Repository
public class ControlMatrizDAOImpl implements ControlMatrizDAO {

	String SQL_Proveedor = "select  DISTINCT matriz.po , matriz.status , matriz.fechaModificacion , estatus.rechazado, estatus.isMatriz  "
			+ "from cdiControlMatrices  matriz "
			+ "inner join cdiCatalogoControlMatrices estatus on matriz.status = estatus.id "
			+ "where matriz.proveedor= ?  " + "and status != 'NEW' " + "order by matriz.fechaModificacion asc";

	String SQL_PO_Bloqueadas = "select  DISTINCT matriz.po , matriz.status , matriz.fechaModificacion , estatus.rechazado, estatus.isMatriz  "
			+ "from cdiControlMatrices  matriz "
			+ "inner join cdiCatalogoControlMatrices estatus on matriz.status = estatus.id " + "where status != 'NEW' "
			+ "order by matriz.fechaModificacion asc";

	String SQL_PO_BY_FOLIO_SAR = " SELECT distinct po  FROM cdiSARDetalle  where folio = ? ";

	@Override
	public List<String> getPObloqueadas(String proveedor) {
		List<String> bloqueos = new ArrayList<String>();
		Connection conn = null;
		try {
			conn = ConexionDB.dameConexion();
			try (PreparedStatement pstmt = conn.prepareStatement(SQL_Proveedor)) {
				pstmt.setString(1, proveedor);
				ResultSet rs = pstmt.executeQuery();
				while (rs.next()) {
					llenaArreglo(bloqueos, rs);
				}
			} catch (SQLException eSQL) {
				log.error(getClass().getName() + eSQL.toString());
			}
		} catch (Exception e) {
			log.error(getClass().getName() + e.toString());
		} finally {
			ConexionDB.devolver(conn);
		}
		return bloqueos;
	}

	@Override
	public List<String> getAllPO() {
		List<String> allBloqueos = new ArrayList<String>();
		Connection conn = null;
		try {
			conn = ConexionDB.dameConexion();
			try (PreparedStatement pstmt = conn.prepareStatement(SQL_PO_Bloqueadas)) {
				ResultSet rs = pstmt.executeQuery();
				while (rs.next()) {
					llenaArreglo(allBloqueos, rs);
				}
			} catch (SQLException eSQL) {
				log.error(getClass().getName(), eSQL);
				ConexionDB.renovar(conn);
			}
		} catch (Exception e) {
			log.error(getClass().getName(), e);
		} finally {
			ConexionDB.devolver(conn);
		}
		return allBloqueos;
	}

	/**
	 * @param allBloqueos
	 * @param rs
	 * @throws SQLException
	 */
	private void llenaArreglo(List<String> allBloqueos, ResultSet rs) throws SQLException {
		String po = rs.getString("po");
		boolean rechazado = rs.getBoolean("rechazado");
		boolean isMatriz = rs.getBoolean("isMatriz");
		String status = rs.getString("status");
		if ((rechazado && isMatriz) || StatusControlMatricesEnum.PENDING_PRICE_UPDATE.id().equalsIgnoreCase(status)
				|| StatusControlMatricesEnum.RJPPU.id().equalsIgnoreCase(status)) {
			if (!allBloqueos.contains(po)) {
				allBloqueos.add(po);
			}
		} else if (allBloqueos.contains(po)) {
			allBloqueos.remove(po);
		}
	}

	@Override
	public List<String> getPOsBYFolioSar(String folioSAR) {
		List<String> allPOsByFolioSar = new ArrayList<String>();
		Connection conn = null;
		try {
			conn = ConexionDB.dameConexion();
			try (PreparedStatement pstmt = conn.prepareStatement(SQL_PO_BY_FOLIO_SAR)) {
				pstmt.setString(1, folioSAR);
				ResultSet rs = pstmt.executeQuery();
				while (rs.next()) {
					allPOsByFolioSar.add(rs.getString("po"));
				}
			} catch (SQLException eSQL) {
				log.error(getClass().getName(), eSQL);
				ConexionDB.renovar(conn);
			}
		} catch (Exception e) {
			log.error(getClass().getName(), e);
		} finally {
			ConexionDB.devolver(conn);
		}
		return allPOsByFolioSar;
	}

	@Override
	public int getDaysEtdBySupplier(int proveedor) {
		int daysEtdBySuppler = 0;
		Connection conn = null;
		try {
			conn = ConexionDB.dameConexion();
			try (PreparedStatement pstmt = conn.prepareStatement(
					new StringBuffer().append("select * from [cdiDaysETDbySupplier] where supplier = ? ").toString())) {
				pstmt.setString(1, "P".concat(String.valueOf(proveedor)));
				ResultSet rs = pstmt.executeQuery();
				while (rs.next()) {
					daysEtdBySuppler = rs.getInt("days");
				}
			} catch (SQLException eSQL) {
				log.error(getClass().getName(), eSQL);
			}
		} catch (Exception e) {
			log.error(getClass().getName(), e);
		} finally {
			ConexionDB.devolver(conn);
		}
		return daysEtdBySuppler;
	}

	@Override
	public boolean saveDaysEtdBySupplierBatch(List<String> item, UserBean user) {
		Connection con = null;
		StringBuffer sql = new StringBuffer();

		sql.append(" IF EXISTS(SELECT * FROM cdiDaysETDbySupplier WHERE supplier = ? )").append(" BEGIN  ").append(
				" UPDATE cdiDaysETDbySupplier SET days = ? , userNamebatch = ? , modifyDate = GETDATE() WHERE supplier = ? ")
				.append(" END ELSE      ").append(" BEGIN  ")
				.append(" INSERT INTO cdiDaysETDbySupplier (supplier, days, userNamebatch , modifyDate) VALUES(?,?,?, GETDATE())  ")
				.append(" END ");

		try {
			ProveedorVO supplierByDaysEtd = new ProveedorVO();
			supplierByDaysEtd.setNumProveedor(item.get(0));
			supplierByDaysEtd.setDaysEtdBySupplier(Integer.parseInt(item.get(1)));

			con = ConexionDB.dameConexion();
			PreparedStatement pst = con.prepareStatement(sql.toString());
			pst.setString(1, "P".concat(supplierByDaysEtd.getNumProveedor()));
			pst.setInt(2, supplierByDaysEtd.getDaysEtdBySupplier());
			pst.setString(3, user.getUserName());
			pst.setString(4, "P".concat(supplierByDaysEtd.getNumProveedor()));

			pst.setString(5, "P".concat(supplierByDaysEtd.getNumProveedor()));
			pst.setInt(6, supplierByDaysEtd.getDaysEtdBySupplier());
			pst.setString(7, user.getUserName());
			pst.executeUpdate();
			pst.close();

		} catch (Exception e) {
			log.error(e.getMessage());
			return false;
		} finally {
			ConexionDB.devolver(con);
		}

		return true;

	}
}
