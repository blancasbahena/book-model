package com.srm.fungandrui.revocacion.service;

public interface RevocacionConfirmacionService {
	void revocacionConfirmacion(String folio,String userName);
	
}
