package com.srm.fungandrui.sc.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.srm.fungandrui.pis.service.ProformaInvoiceService;
import com.srm.fungandrui.pis.service.impl.ProformaInvoiceServiceImpl;
import com.srm.fungandrui.sc.model.BeanSession;
import com.srm.fungandrui.sc.model.ProveedorVO;
import com.srm.fungandrui.sc.service.ControlMatrizService;
import com.srm.fungandrui.sc.utils.ProveedorUtil;
import com.srm.fungandrui.sc.utils.SessionUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
@RequestMapping("/proveedor")
public class ProveedorController {

	@Autowired
	ControlMatrizService service;

	@RequestMapping(value = "/{proveedor}", method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView getBloqueosProveedor(HttpServletRequest request, @PathVariable("proveedor") String proveedor) {
		ModelAndView mav = null;
		HttpSession session = request.getSession(false);
		List<String> poBloqueadas = new ArrayList<String>();
		BeanSession beanSession = SessionUtil.validaSesion(session);

		if (beanSession == null || beanSession.getUser() == null) {
			return new ModelAndView("../index");
		}

		if (!beanSession.getUser().isSupplier()) {
			return new ModelAndView("redirect:/Search");
		}
		ProveedorVO proveedorVo = validaProveedor(proveedor);
		if (proveedorVo == null) {
			return new ModelAndView("../index");
		}

		poBloqueadas = service.getBloqueo(proveedorVo.getNumProveedor());
		beanSession.getUser().setUserName(proveedorVo.getNumProveedor());

		proveedorVo.setDaysEtdBySupplier(service.getDaysEtdBySupplier(Integer.parseInt(proveedor)));
		session.setAttribute("proveedor", proveedorVo);

		mav = new ModelAndView("redirect:/Proveedor");
		session.setAttribute("poBloqueadas", poBloqueadas);
		return mav;
	}

	public ProveedorVO validaProveedor(String proveedor) {
		ProveedorVO proveedorVO = ProveedorUtil.validaProveedor(proveedor);
		if (proveedorVO.getNombreProveedor() == null) {
			return null;
		}
		return proveedorVO;
	}

}
