package com.srm.fungandrui.lineamientos.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.srm.fungandrui.lineamientos.dao.LineamientosDao;
import com.srm.fungandrui.lineamientos.dto.GrdLineamientosAccionesDto;
import com.srm.fungandrui.lineamientos.dto.SarLineamientosDto;
import com.srm.pli.db.ConexionDB;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Repository

public class LineamientosDaoImpl implements LineamientosDao {


	
	@Override
	public List<SarLineamientosDto> getSars(Integer estatus) throws SQLException, ClassNotFoundException {
		Connection conn = null;
		List<SarLineamientosDto> data = new ArrayList<>();
		log.info("Busqueda de sar por estatus...");
		try {
			StringBuilder sql = new StringBuilder();
			sql.append(" select folio, proveedor,puertoSalida, naviera from cdisar where status =? ");
			conn = ConexionDB.dameConexion();
			PreparedStatement pstmt = conn.prepareStatement(sql.toString());
			pstmt.setInt(1, estatus);
			ResultSet rs = pstmt.executeQuery();
			SarLineamientosDto sar = new SarLineamientosDto();
			while (rs.next()) {
				sar.setSar(rs.getString("folio"));
				sar.setProveedor(rs.getString("proveedor"));
				sar.setPuertoOrigen(rs.getString("puertoSalida"));
				sar.setNaviera(rs.getInt("naviera"));
				data.add(sar);
			}
			pstmt.close();
			rs.close();
		} finally {
			
				ConexionDB.devuelveConexion(conn);
		}

		return data;
	}

	@Override
	public Integer actualizarSar(GrdLineamientosAccionesDto dto) throws SQLException, ClassNotFoundException {
		Connection conn = ConexionDB.dameConexion();
			int resultado = 0;
		StringBuilder query = new StringBuilder();
		String comentarioCancelaciacion="";
		String comentarioAprobacion="";
		if(dto.getAccion().equals("aprobacionGDRGerente")) {
			comentarioCancelaciacion="";
			comentarioAprobacion=dto.getComentarios();
		}
		else if(dto.getAccion().equals("rechazoGDRGerente")) {
			comentarioCancelaciacion=dto.getComentarios();
			comentarioAprobacion="";
		}
		log.info("Actualizacion de estatus");
		query.append("UPDATE cdiSAR SET ");
		query.append("	messageGRDrechazo=? , messageGRDaprobacion=?, status=?, approvalGRDlineacion=?  ");
		query.append("WHERE folio=? ");

		try {
			PreparedStatement stmt = conn.prepareStatement(query.toString());
			stmt.setString(1, comentarioCancelaciacion);
			stmt.setString(2, comentarioAprobacion);
			stmt.setInt(3, dto.getIdEstatus());
			stmt.setInt(4, dto.getApprovalGRDlineacion());
			stmt.setInt(5, dto.getFolio());

			resultado = stmt.executeUpdate();
			
			if (resultado>0) {
				log.info("Actualizacion correcta");
			}

		
		}finally {
			ConexionDB.devolver(conn);
		} 
		return dto.getFolio();

	}

	@Override
	public Integer consultarGrd(Integer folio) throws SQLException, ClassNotFoundException{
		Connection conn = null;
		log.info("Busqueda de grd por folio...");
		Integer fechaGDRModificada =0;
		try {
			StringBuilder sql = new StringBuilder();
			sql.append(" SELECT fechaGDRModificada  from cdiRevisionGDR WHERE folio = ? ");
			conn = ConexionDB.dameConexion();
			PreparedStatement pstmt = conn.prepareStatement(sql.toString());
			pstmt.setInt(1, folio);
			ResultSet rs = pstmt.executeQuery();
			
			while (rs.next()) {
				fechaGDRModificada = rs.getInt("fechaGDRModificada");
				
			}
			pstmt.close();
			rs.close();
		} finally {
			
				ConexionDB.devuelveConexion(conn);
		}

		return fechaGDRModificada;
	}

}
