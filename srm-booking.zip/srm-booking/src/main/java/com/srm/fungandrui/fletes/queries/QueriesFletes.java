package com.srm.fungandrui.fletes.queries;

public class QueriesFletes {

	public static final String SQL_PAGOS_FACTURA = new StringBuilder( "SELECT pf.claveNaviera  , ")
			.append(" pf.acreedor , ")
			.append(" pf.contenedor_caja  ,")
			.append(" pf.bl ,")
			.append(" pf.factura_proveedor_logistico , ")
			.append(" pf.fecha_factura, ")
			.append(" pf.tipo_contenedor, ")
			.append(" pf.puerto_embarque , ")
			.append(" pf.puerto_descarga, ")
			.append(" pf.importe, ")
			.append(" pf.moneda, ")
			.append(" pf.tipo_factura, ")
			.append(" pf.folio, ")
			.append(" CASE ")
			.append(" WHEN pf.corte_puerto =0  THEN '0' ")
			.append(" Else '1' ")
			.append(" END corte_puerto, ")
			.append(" epf.descripcion estatus_pago_flete ")
			.append(" from pagos_factura pf ")
			.append(" inner join estatus_pago_flete epf on pf.estatus_pago_flete = epf.id")
			.toString();
	
	public static final String SQL_ESTATUS = "select  * from estatus_pago_flete";
	
}
