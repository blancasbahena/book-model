package com.srm.fungandrui.facturacion.controller;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.google.gson.Gson;
import com.srm.app.constantes.Mensajes;
import com.srm.fungandrui.expediente.service.ExpedienteService;
import com.srm.fungandrui.facturacion.dao.IFacturacionDAO;
import com.srm.fungandrui.facturacion.dao.PeticionRabbit;
import com.srm.fungandrui.facturacion.dto.FacturacionFilter;
import com.srm.fungandrui.facturacion.models.BeanFacturacion;
import com.srm.fungandrui.facturacion.models.CatStatusFactura;
import com.srm.fungandrui.facturacion.models.CatStatusFacturacion;
import com.srm.fungandrui.facturacion.models.CatStatusIncidencias;
import com.srm.fungandrui.facturacion.models.Facturacion;
import com.srm.fungandrui.facturacion.models.FacturacionReporte;
import com.srm.fungandrui.facturacion.reportes.ReporteFacturacion;
import com.srm.fungandrui.facturacion.service.FactService;
import com.srm.fungandrui.facturacion.service.RabbitService;
import com.srm.fungandrui.sc.model.BeanSession;
import com.srm.fungandrui.sc.model.ResponseVO;
import com.srm.fungandrui.sc.utils.SessionUtil;
import com.srm.pli.bo.SarBO;
import com.srm.pli.dao.SAR_CDI_DAO;
import com.srm.pli.documents.ShpmntsWdocsService;
import com.srm.pli.enums.DocumentosAccionEnum;
import com.srm.pli.enums.HistoryLogAction;
import com.srm.pli.services.CorreoDocumentosServices;
import com.srm.pli.services.HistoryLogServices;
import com.srm.pli.servlet.ShpmntsWDocs;
import com.srm.pli.utils.FuncionesComunesPLI;
import com.srm.pli.utils.MailUtils;
import com.srm.pli.utils.Paginacion;
import com.srm.pli.utils.UtilsSars;
import com.srm.pli.ws.vo.ResponseImportsVO;
import com.truper.businessEntity.BeanControlSDI;
import com.truper.businessEntity.BeanDocumentosSDI;
import com.truper.businessEntity.BeanFactura;
import com.truper.businessEntity.UserBean;

import lombok.extern.log4j.Log4j2;

@Log4j2
@Controller
@RequestMapping("/facturacion")

public class FacturacionController {

	@Autowired
	HttpServletRequest request;
	@Autowired
	FactService facturacionService;
	@Autowired
	RabbitService rabbitServices;
	
	@Autowired
	private IFacturacionDAO facturacionDAO;
	
	HistoryLogServices historylog = HistoryLogServices.getInstance();
	public static String COMILLAS_SIMPLES = "\'";
	public static String COMILLAS_DOBLES = "\"";
	public static String ESPACIO = "";

	@RequestMapping(value = "/", method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView getFacturacion(ModelAndView mav) {
		HttpSession session = null;
		BeanSession beanSession;
		session = request.getSession(false);
		beanSession = SessionUtil.validaSesion(session);
		if (beanSession.getMav() == null) {
			try {
				mav = new ModelAndView("facturacion");
				List<Facturacion> facList = facturacionService.getFacturacion();
				Facturacion facturacion = new Facturacion();
				String jsonString = new Gson().toJson(facList);
				Locale currentLocale = session.getAttribute("javax.servlet.jsp.jstl.fmt.locale.session") == null
						? new Locale("en", "US")
						: (Locale) session.getAttribute("javax.servlet.jsp.jstl.fmt.locale.session");

				mav.addObject("facList", jsonString);

				mav.addObject("flechas", Paginacion.controlPaginacion(facturacion.getPaginaActual(),
						facturacion.getPaginaAccion(), facList.size(), currentLocale));

				return mav;
			} catch (Exception e) {
				log.error(e.getMessage());
			}
		}
		mav = new ModelAndView("redirect:/Inicio");
		return mav;
	}

	@RequestMapping(value = "/search", method = RequestMethod.POST, consumes = "application/json")
	public ResponseEntity<ResponseVO> search(@RequestBody Facturacion filtro) {

		log.info("[/search/]::Entrando al Servicio para hacer el Filtto:");

		ResponseVO response = new ResponseVO();
		Map<String, Object> data = new HashMap<String, Object>();
		HttpSession session = null;
		BeanSession beanSession;
		session = request.getSession(false);
		beanSession = SessionUtil.validaSesion(session);
		Locale currentLocale = session.getAttribute("javax.servlet.jsp.jstl.fmt.locale.session") == null
				? new Locale("en", "US")
				: (Locale) session.getAttribute("javax.servlet.jsp.jstl.fmt.locale.session");
		try {
			if (beanSession == null)
				throw new Exception("session invalida");

			List<Facturacion> listDetalle = facturacionService.getbyFilterService(filtro);
			
			//Programar el crono
//			JobDetail job = JobBuilder.newJob(EnviaReporteSemanalIncidencia.class)
//					.withIdentity("TestJob1", "group1").build();
//			Trigger trigger = TriggerBuilder
//					.newTrigger()
//					.withIdentity("TestTriggerName", "group2")
//					.withSchedule(
//						SimpleScheduleBuilder.simpleSchedule().withIntervalInSeconds(10).repeatForever())
//					.build();
//			Scheduler scheduler = new StdSchedulerFactory().getScheduler();
//			scheduler.start();
//			scheduler.scheduleJob(job, trigger);
	
			
			response.setTipoMensaje(Mensajes.TIPO_EXITO.getMensaje());
			response.setMensaje(Mensajes.MSG_EXITO.getMensaje());
			data.put("facList", listDetalle);
			data.put("flechas", Paginacion.controlPaginacion(filtro.getPaginaActual(), filtro.getPaginaAccion(),
					listDetalle.size(), currentLocale));
			response.setResponseObject(data);
			log.info("[/search/]::Saliendo al REST para obtener Facturas POST:");
			return ResponseEntity.ok(response);
		} catch (Exception e) {
			response.setTipoMensaje(Mensajes.TIPO_ERROR.getMensaje());
			response.setMensaje(Mensajes.MSG_ERROR.getMensaje());
			data.put("error", ExceptionUtils.getStackTrace(e));
			log.info("Error");
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
		}

	}

	@RequestMapping(value = "/rejected/filtro", method = RequestMethod.POST, consumes = "application/json")
	public ResponseEntity<ResponseVO> rejectedFiltro(@RequestBody Facturacion facturacion) {
		log.info("[/rejected/filtro]::Entrando al REST para obtener Facturas Rechazadas:");
		ResponseVO response = new ResponseVO();
		Map<String, Object> data = new HashMap<String, Object>();
		HttpSession session = null;
		BeanSession beanSession;
		session = request.getSession(false);
		beanSession = SessionUtil.validaSesion(session);
		Locale currentLocale = session.getAttribute("javax.servlet.jsp.jstl.fmt.locale.session") == null
				? new Locale("en", "US")
				: (Locale) session.getAttribute("javax.servlet.jsp.jstl.fmt.locale.session");
		try {
			if (beanSession == null)
				throw new Exception("session invalida");
			List<Facturacion> listDetalleFilterRejectd = facturacionService.getbyFilterServiceRejectd(facturacion);
			response.setTipoMensaje(Mensajes.TIPO_EXITO.getMensaje());
			response.setMensaje(Mensajes.MSG_EXITO.getMensaje());
			data.put("faclistFilterRejectd", listDetalleFilterRejectd);
			data.put("flechas", Paginacion.controlPaginacion(facturacion.getPaginaActual(),
					facturacion.getPaginaAccion(), listDetalleFilterRejectd.size(), currentLocale));
			response.setResponseObject(data);
			log.info("[/reject/filtro]::Saliendo al REST para obtener Facturas Rechazadas:");
			return ResponseEntity.ok(response);

		} catch (Exception e) {
			response.setTipoMensaje(Mensajes.TIPO_ERROR.getMensaje());
			response.setMensaje(Mensajes.MSG_ERROR.getMensaje());
			data.put("error", ExceptionUtils.getStackTrace(e));
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
		}

	}

	@RequestMapping(value = "/update/incidencia", method = RequestMethod.POST, consumes = "application/json", headers = "content-type=application/x-www-form-urlencoded")
	public ResponseEntity<ResponseVO> updateInc(@RequestBody String json) {
		log.info("[/update/incidencia]::Entrando al REST para actualizar las incidencias:");

		ResponseVO response = new ResponseVO();
		HttpSession session = null;
		BeanSession beanSession = null;
		session = request.getSession(false);

		response.setTipoMensaje(Mensajes.TIPO_EXITO.getMensaje());
		response.setMensaje(Mensajes.MSG_EXITO.getMensaje());
		beanSession = SessionUtil.validaSesion(session);
		String userName = beanSession.getUser().getUserName();
		Gson g = new Gson();
		BeanFacturacion bFac = g.fromJson(json, BeanFacturacion.class);

		Locale currentLocale = session.getAttribute("javax.servlet.jsp.jstl.fmt.locale.session") == null
				? new Locale("en", "US")
				: (Locale) session.getAttribute("javax.servlet.jsp.jstl.fmt.locale.session");
		try {
			if (beanSession == null)
				throw new Exception("session invalida");

			// BeanFacturacion bFac = g.fromJson(json, BeanFacturacion.class);

			facturacionService.updateIncidence(bFac, userName);
			historylog.registraAccion(bFac.getFolio(), userName, HistoryLogAction.CAMBIAR_INCIDENCIA_FACTURACION,
					"FACTURACION: Cambio de Incidencia en Facturacion");
		} catch (Exception e) {
			log.info("Error ..", e);
		}


		return ResponseEntity.ok(response);
	}

	@RequestMapping(value = "/dameStatus", method = RequestMethod.GET, consumes = "application/json")
	public ResponseEntity<ResponseVO> dameStatus(@RequestParam("options") String options) {
		log.info("[/dameStatus/]::Entrando al Servicio para obtener status facturacion :");
		ResponseVO response = new ResponseVO();
		Map<String, Object> data = new HashMap<String, Object>();
		HttpSession session = null;
		BeanSession beanSession;
		session = request.getSession(false);
		beanSession = SessionUtil.validaSesion(session);
		Locale currentLocale = session.getAttribute("javax.servlet.jsp.jstl.fmt.locale.session") == null
				? new Locale("en", "US")
				: (Locale) session.getAttribute("javax.servlet.jsp.jstl.fmt.locale.session");
		try {
			if (beanSession == null)
				throw new Exception("session invalida");

			List<CatStatusFacturacion> listIncidencia = facturacionService.getStatusFacturacion(options);
			response.setTipoMensaje(Mensajes.TIPO_EXITO.getMensaje());
			response.setMensaje(Mensajes.MSG_EXITO.getMensaje());
			data.put("listStatus", listIncidencia);
			response.setResponseObject(data);
			log.info("[/dameStatus/]::Saliendo al REST s:");
			return ResponseEntity.ok(response);
		} catch (Exception e) {
			response.setTipoMensaje(Mensajes.TIPO_ERROR.getMensaje());
			response.setMensaje(Mensajes.MSG_ERROR.getMensaje());
			data.put("error", ExceptionUtils.getStackTrace(e));
			log.info("Error");
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
		}

	}

	@RequestMapping(value = "/update/cambiarStatusFacturacion", method = RequestMethod.POST, consumes = "application/json")
	public ResponseEntity<ResponseVO> cambiarStatusIncidencia(@RequestBody String json) {
		ResponseVO response = new ResponseVO();
		Map<String, Object> data = new HashMap<String, Object>();
		HttpSession session = null;
		BeanSession beanSession = null;
		session = request.getSession(false);
		response.setTipoMensaje(Mensajes.TIPO_EXITO.getMensaje());
		response.setMensaje(Mensajes.MSG_EXITO.getMensaje());
		beanSession = SessionUtil.validaSesion(session);
		String userName = beanSession.getUser().getUserName();
		Gson g = new Gson();
		BeanFacturacion bFac = g.fromJson(json, BeanFacturacion.class);
		Locale currentLocale = session.getAttribute("javax.servlet.jsp.jstl.fmt.locale.session") == null
				? new Locale("en", "US")
				: (Locale) session.getAttribute("javax.servlet.jsp.jstl.fmt.locale.session");
		try {
			if (beanSession == null)
				throw new Exception("session invalida");

			facturacionService.updateIncidence(bFac, userName);
			historylog.registraAccion(bFac.getFolio(), userName, HistoryLogAction.CAMBIAR_STATUS_FACTURACION,
					"FACTURACION: Cambio de Status en Facturacion");
		} catch (Exception e) {
			response.setTipoMensaje(Mensajes.TIPO_ERROR.getMensaje());
			response.setMensaje(Mensajes.MSG_ERROR.getMensaje());
			data.put("error", ExceptionUtils.getStackTrace(e));
			log.info("Error");
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
		}


		return ResponseEntity.ok(response);
	}

	@RequestMapping(value = "/cancel/comments", method = RequestMethod.POST, consumes = "application/json")
	public ResponseEntity<ResponseVO> cambiarStatusIncidencia(@RequestBody Facturacion filtro) {

		log.info("/cancel/comments inicio.....");
		ResponseVO response = new ResponseVO();
		Map<String, Object> data = new HashMap<String, Object>();
		try {
			
			HttpSession session = null;
			BeanSession beanSession = null;
			session = request.getSession(false);
			String userName = "";
			Integer userProfile = null;
			if( session != null ) {
			response.setTipoMensaje(Mensajes.TIPO_EXITO.getMensaje());
			response.setMensaje(Mensajes.MSG_EXITO.getMensaje());
			beanSession = SessionUtil.validaSesion(session);
			userName = beanSession.getUser().getUserName();
			userProfile = beanSession.getUser().getUserProfile();
			Locale currentLocale = session.getAttribute("javax.servlet.jsp.jstl.fmt.locale.session") == null
					? new Locale("en", "US")
					: (Locale) session.getAttribute("javax.servlet.jsp.jstl.fmt.locale.session");
			}
			else {
				throw new Exception("Session caducada");
			}


			// Servicio
			facturacionService.cancelacionComments(filtro, userName, userProfile);
			historylog.registraAccion(Integer.parseInt(filtro.getFolio()), userName,
					HistoryLogAction.CAMBIAR_STATUS_FACTURACION,
					"Change of status from 'ENTREGA DOCS FINALES' - Cancelacion ");
		} catch (Exception e) {
			response.setTipoMensaje(Mensajes.TIPO_ERROR.getMensaje());
			response.setMensaje(Mensajes.MSG_ERROR.getMensaje());
			data.put("error", ExceptionUtils.getStackTrace(e));
			log.info("Error " + ExceptionUtils.getStackTrace(e));
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
		}
		log.info("/cancel/comments fin.....");
		return ResponseEntity.ok(response);
	}

	@RequestMapping(value = "/correccion", method = RequestMethod.POST, consumes = "application/json")
	public ResponseEntity<ResponseVO> correccion(@RequestBody Facturacion filtro) {

		log.info("/correccion inicio.....");
		ResponseVO response = new ResponseVO();
		Map<String, Object> data = new HashMap<String, Object>();
		HttpSession session = null;
		BeanSession beanSession = null;
		session = request.getSession(false);

		response.setTipoMensaje(Mensajes.TIPO_EXITO.getMensaje());
		response.setMensaje(Mensajes.MSG_EXITO.getMensaje());
		beanSession = SessionUtil.validaSesion(session);
		String userName = beanSession.getUser().getUserName();
		Locale currentLocale = session.getAttribute("javax.servlet.jsp.jstl.fmt.locale.session") == null
				? new Locale("en", "US")
				: (Locale) session.getAttribute("javax.servlet.jsp.jstl.fmt.locale.session");
		try {
			if (beanSession == null)
				throw new Exception("session invalida");
			// Servicio
			facturacionService.correccion(filtro, userName, "" + CatStatusFactura.REENVIO_FACTURACION.getId());
			historylog.registraAccion(Integer.parseInt(filtro.getFolio()), userName,
					HistoryLogAction.CAMBIAR_STATUS_FACTURACION,
					"Change of status from 'ENTREGA DOCS FINALES' - Re facturacion ");
		} catch (Exception e) {
			response.setTipoMensaje(Mensajes.TIPO_ERROR.getMensaje());
			response.setMensaje(Mensajes.MSG_ERROR.getMensaje());
			data.put("error", ExceptionUtils.getStackTrace(e));
			log.info("Error " + ExceptionUtils.getStackTrace(e));
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
		}
		log.info("/correccion fin.....");
		return ResponseEntity.ok(response);
	}

	@PostMapping(value = "/sharepoint/download2")
	public ResponseEntity<Resource> getFileTop2(@RequestBody FacturacionReporte filtro ) {
		log.info("Entro a /imports ::: [/sharepoint/download]");
		ResponseImportsVO resp = null;
		try {
			String headerValue = "facturacion.xls";
			//FacturacionReporte filtro = new FacturacionReporte();
			List<FacturacionReporte> listReport = facturacionService.getListReport(filtro);
			ReporteFacturacion reporteFacturacion = new ReporteFacturacion(listReport);
			File file = reporteFacturacion.generarReporteExcel(listReport, headerValue);
			Path path = Paths.get(file.getAbsolutePath());
			Resource resource = new UrlResource(path.toUri());
			
			return ResponseEntity.ok().contentType(MediaType.parseMediaType("application/octet-stream"))
			.header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + resource.getFilename() + "\"")
			.body(resource);
		} catch (Exception e) {
			resp.setTipoMensaje(Mensajes.TIPO_ERROR.getMensaje());
			resp.setMensaje(Mensajes.MSG_ERROR.getMensaje());
			Map<String, Object> data = new HashMap<String, Object>();
			data.put("error", ExceptionUtils.getStackTrace(e));
			return null;
		}
	}
	
	
	@GetMapping(value = "/revocationDocument/{idFac}/{sar}/{status}")
	public ResponseEntity<ResponseVO> revocationDocument(@PathVariable Integer idFac,@PathVariable Integer sar, @PathVariable Integer status) {

		log.info("/revocationDocument inicio.....");
		ResponseVO response = new ResponseVO();
		Map<String, Object> data = new HashMap<String, Object>();
		HttpSession session = null;
		BeanSession beanSession = null;
		session = request.getSession(false);

		response.setTipoMensaje(Mensajes.TIPO_EXITO.getMensaje());
		response.setMensaje(Mensajes.MSG_EXITO.getMensaje());
		beanSession = SessionUtil.validaSesion(session);
		String userName = beanSession.getUser().getUserName();
		Locale currentLocale = session.getAttribute("javax.servlet.jsp.jstl.fmt.locale.session") == null
				? new Locale("en", "US")
				: (Locale) session.getAttribute("javax.servlet.jsp.jstl.fmt.locale.session");
		try {
			if (beanSession == null)
				throw new Exception("session invalida");
			
			SarBO bo = new SarBO();
			bo.setFolio(sar);
			bo.setStatus(status != null ? status : null);
			bo.setAprobadoProveedor(false);
			bo.setAprobadoSDI(false);
			SAR_CDI_DAO dao = new SAR_CDI_DAO();
			dao.updateFolio(bo, beanSession.getUser());
			UtilsSars.getInstance().resetDocuments(bo.getFolio() , bo.getBooking(), bo.getProveedor());
			UtilsSars.getInstance().revocacion(bo.getBooking(),idFac);
			FuncionesComunesPLI.guardaSARHistoryLog(HistoryLogAction.SDI_REVOKE_DOCUMENTS.id(), sar,
					userName, null, "F", null);	
			
		} catch (Exception e) {
			response.setTipoMensaje(Mensajes.TIPO_ERROR.getMensaje());
			response.setMensaje(Mensajes.MSG_ERROR.getMensaje());
			data.put("error", ExceptionUtils.getStackTrace(e));
			log.info("Error " + ExceptionUtils.getStackTrace(e));
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
		}
		log.info("/revocationDocument fin.....");
		return ResponseEntity.ok(response);
	}
	
	
	@RequestMapping( value = "/rejectDocuments/valida/{folio}", method = RequestMethod.GET )
	public ResponseEntity<ResponseVO> rejectDocuments(HttpServletRequest request,@PathVariable Integer folio ) {
		ResponseVO response = new ResponseVO();
		Map<String, Object> data = new HashMap<String, Object>();
		HttpSession session = null;
		BeanSession beanSession = null;
		String usuario = null;
		session = request.getSession(false);
		if ( session != null ) {
			beanSession = SessionUtil.validaSesion(session);
			usuario = beanSession.getUser().getUserName();
			Locale currentLocale = session.getAttribute("javax.servlet.jsp.jstl.fmt.locale.session") == null
				? new Locale("en", "US")
				: (Locale) session.getAttribute("javax.servlet.jsp.jstl.fmt.locale.session");
	
		}else {
			response.setTipoMensaje(Mensajes.TIPO_ERROR.getMensaje());
			response.setMensaje(Mensajes.MSG_ERROR.getMensaje());
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
		}
		
		List<Facturacion> registrosFac = facturacionDAO.getFacturasBySAR(folio);
		
		response.createSuccess("facturas", registrosFac);
		
		response.setTipoMensaje(Mensajes.TIPO_EXITO.getMensaje());
		response.setMensaje(Mensajes.MSG_EXITO.getMensaje());	
		
		return ResponseEntity.ok(response);
	}
	
	@RequestMapping(value = "/rejectDocuments", method = RequestMethod.POST, consumes = "application/json")
	public ResponseEntity<ResponseVO> rejectDocuments(@RequestBody Facturacion info){
		ResponseVO response = new ResponseVO();
		Map<String, Object> data = new HashMap<String, Object>();
		HttpSession session = null;
		BeanSession beanSession = null;
		String usuario = null;
		session = request.getSession(false);
		if ( session != null ) {
			beanSession = SessionUtil.validaSesion(session);
			usuario = beanSession.getUser().getUserName();
			Locale currentLocale = session.getAttribute("javax.servlet.jsp.jstl.fmt.locale.session") == null
				? new Locale("en", "US")
				: (Locale) session.getAttribute("javax.servlet.jsp.jstl.fmt.locale.session");
	
		}else {
			response.setTipoMensaje(Mensajes.TIPO_ERROR.getMensaje());
			response.setMensaje(Mensajes.MSG_ERROR.getMensaje());
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
		}
			
		Integer sar = Integer.parseInt(info.getFolio() );
		Integer idDoc = info.getIdDoc();
		String comentarios = info.getComentarios().replace(COMILLAS_SIMPLES, ESPACIO).replace(COMILLAS_DOBLES, ESPACIO);

		try {
			/*
			ArrayList<Integer > listaSars = SAR_CDI_DAO.selectSarsEnBooking(idDoc);
			SarBO bo = FuncionesComunesPLI.concentraTotalesDeFoliosEnUno(listaSars,null,false);
			bo.setBooking(info.getBooking());
			bo.setProveedor(info.getSupplier());
			
			BeanDocumentosSDI doc = SAR_CDI_DAO.selectDocumentosSDI(idDoc);
			doc.setComentariosSDI(comentarios);
			doc.setUsuarioRechazo(usuario);
			//Lo mando a False, porque si cambia de version no tiene nada para mostrar Queda pendiente modificar las versiones
			doc.setTieneOtrosDocumentos(false);
			
			//Metodo que de rechazo 
			ShpmntsWDocs<ExpedienteService> sqd = new ShpmntsWDocs<>();
			sqd.rechazoEnDB(listaSars, idDoc, doc, bo);*/
			
			BeanControlSDI con = new BeanControlSDI();
			con.setComentariosProveedor(comentarios);
			con.setProveedor(info.getSupplier());
			con.setBooking(info.getBooking());
			con.setAprobadoSDI(false);
			SAR_CDI_DAO.updateControlSDI(con);
			
			ShpmntsWdocsService.getInstance().registraLogDocumentos(info.getBooking(), info.getSupplier(), DocumentosAccionEnum.DOCUMENTOS_RECHAZADOS_EN_FACTURACION);
			
			/*
			String facturasStr = "";
			ArrayList<BeanFactura> facturas = SAR_CDI_DAO.selectFactura(null, doc);
			for(BeanFactura fac : facturas) {
				if( !"".equals(facturasStr ) ){
					facturasStr += ",";
				}
				facturasStr += fac.getNombre();
			}
			
			
			new MailUtils().enviaMailRechazoDocumentos(comentarios,facturasStr,info.getSupplier(),idDoc, beanSession.getUser());
			if(info.getRevokeFinalConfirmation()) {
				Set<Integer> sarsSet = new HashSet<>();
				sarsSet.addAll(listaSars);
				CorreoDocumentosServices.getInstance().enviaSolicitudRevokeFinalConfirmation(sarsSet);	
			}*/
			
			//Registros en tablas de facturacion
			SarBO sbo = new SarBO();
			sbo.setFolio(sar);
			sbo.setStatus(SarBO.STATUS_INICIO_SDI);
			sbo.setAprobadoProveedor(false);
			sbo.setAprobadoSDI(false);
			SAR_CDI_DAO dao = new SAR_CDI_DAO();
			dao.updateFolio(sbo, beanSession.getUser());
			info.setSar(sar.toString());
			info.setStatus("15");
			facturacionDAO.setStatusFacturacionByFolio(info,null);
			List<Facturacion> foliosFacturas = facturacionDAO.getFacturasBySAR( sar );
			for (Facturacion facturacion : foliosFacturas) {
				facturacionDAO.deletePODetalle(facturacion.getId());
			}
			
			
			//UtilsSars.getInstance().resetDocuments(info.getFolio() , info.getBooking(), info.getProveedor());
			//UtilsSars.getInstance().revocacion(sbo.getBooking(),info.getId().intValue());
			FuncionesComunesPLI.guardaSARHistoryLog(HistoryLogAction.REJECT_DOCUMENTS_IN_INVOICE.id(), sar,
					usuario, null, "F", comentarios );	
			
			
		}catch (Exception e) {
			log.error(e.getMessage(), e);
			response.setTipoMensaje(Mensajes.TIPO_ERROR.getMensaje());
			response.setMensaje(Mensajes.MSG_ERROR.getMensaje());	
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);

		}
		
		response.setTipoMensaje(Mensajes.TIPO_EXITO.getMensaje());
		response.setMensaje(Mensajes.MSG_EXITO.getMensaje());	
		
		return ResponseEntity.ok(response);
	}
	
	
	
	@RequestMapping(value = "/rejectIndicence", method = RequestMethod.POST, consumes = "application/json")
	public ResponseEntity<ResponseVO> rejectIndicence(@RequestBody Facturacion filtro) {

		log.info("/rejectIndicence inicio.....");
		ResponseVO response = new ResponseVO();
		Map<String, Object> data = new HashMap<String, Object>();
		HttpSession session = null;
		BeanSession beanSession = null;
		session = request.getSession(false);

		response.setTipoMensaje(Mensajes.TIPO_EXITO.getMensaje());
		response.setMensaje(Mensajes.MSG_EXITO.getMensaje());
		beanSession = SessionUtil.validaSesion(session);
		String userName = beanSession.getUser().getUserName();
		Locale currentLocale = session.getAttribute("javax.servlet.jsp.jstl.fmt.locale.session") == null
				? new Locale("en", "US")
				: (Locale) session.getAttribute("javax.servlet.jsp.jstl.fmt.locale.session");
		try {
			if (beanSession == null)
				throw new Exception("session invalida");

			// Servicio
			facturacionService.rejectIncidence(filtro, userName, "" + CatStatusFactura.FACTURACION_REALIZADA.getId());
			historylog.registraAccion(Integer.parseInt(filtro.getFolio()), userName,
					HistoryLogAction.SAR_REJECTED_INCIDENCE,
					"Change of status from 'ENTREGA DOCS FINALES' - Re facturacion ");
		} catch (Exception e) {
			response.setTipoMensaje(Mensajes.TIPO_ERROR.getMensaje());
			response.setMensaje(Mensajes.MSG_ERROR.getMensaje());
			data.put("error", ExceptionUtils.getStackTrace(e));
			log.info("Error " + ExceptionUtils.getStackTrace(e));
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
		}
		log.info("/rejectIndicence fin.....");
		return ResponseEntity.ok(response);
	}	
	
	@RequestMapping(value = "/testFacturacion", method = RequestMethod.POST)
	public ResponseEntity<ResponseVO> TestPeticion(HttpServletRequest request, @RequestBody PeticionRabbit peticion){
		ResponseVO response = new ResponseVO();
		log.info("[ POST /testFacturacion] - Inicia ");
		PeticionRabbit pr = rabbitServices.testFacturacion(peticion);
		response.createSuccess("pr",pr);
		log.info("[ POST /testFacturacion] - Termina ");
		return ResponseEntity.ok(response);
	}
	
	@RequestMapping(value = "/testFR-Facturacion", method = RequestMethod.POST)
	public ResponseEntity<ResponseVO> TestFRPeticion(HttpServletRequest request, @RequestBody PeticionRabbit peticion){
		ResponseVO response = new ResponseVO();
		log.info("[ POST /testFR-Facturacion] - Inicia ");
		PeticionRabbit pr = rabbitServices.testFRFacturacion(peticion);
		response.createSuccess("pr",pr);
		log.info("[ POST /testFR-Facturacion] - Termina ");
		return ResponseEntity.ok(response);
	}
	
	@RequestMapping(value = "/test/BloqueoPo/{folio}", method = RequestMethod.GET)
	public ResponseEntity<ResponseVO> TestFRPeticion(HttpServletRequest request, @PathVariable String folio){
		ResponseVO response = new ResponseVO();
		log.info("[ GET /test/BloqueoPo/{"+folio+"}] - Inicia ");
		response = rabbitServices.bloqueoPOs(folio);
		log.info("[ GET /test/BloqueoPo/{"+folio+"}] - Termina ");
		return ResponseEntity.ok(response);
	}
	
	
	@RequestMapping(value = "/solicita", method = RequestMethod.POST)
	public ResponseEntity<ResponseVO> solicitaFactura(HttpServletRequest request, @RequestBody BeanFacturacion factura){
		ResponseVO response = new ResponseVO();
		log.info("[ POST /solicita ] - Inicia ");
		HttpSession sesion = request.getSession(false);
		UserBean usuario = (UserBean) sesion.getAttribute("usuario");
		if( usuario != null ) {
			Integer idUser = usuario.getIdUser();
			String userName = usuario.getUserName();
			response = rabbitServices.solicitaFacturacion(factura,idUser,userName);
		}else {
			response =  response.createError("error", "Usuario no valido");
		}
		
		log.info("[ POST /solicita ] - Termina ");
		return ResponseEntity.ok(response);
	}
	
	@RequestMapping(value = "/entregaSIFE", method = RequestMethod.POST)
	public ResponseEntity<ResponseVO> entregaSIFE(HttpServletRequest request, @RequestBody Facturacion factura){
		ResponseVO response = new ResponseVO();
		log.info("[ POST /entregaSIFE] - Inicia ");
		HttpSession sesion = request.getSession(false);
		UserBean usuario = (UserBean) sesion.getAttribute("usuario");
		response = rabbitServices.entregaSIFE(factura,sesion);
		log.info("[ POST /entregaSIFE] - Termina ");
		
		historylog.registraAccion (Integer.parseInt(factura.getSar()),usuario.getUserName() , HistoryLogAction.ACTUALIZACION_STATUS_SIFE, "Envio:SIFE");
		return ResponseEntity.ok(response);
	}
	
	
	@RequestMapping(value = "/cancela", method = RequestMethod.POST)
	public ResponseEntity<ResponseVO> cancelaFactura(HttpServletRequest request, @RequestBody FacturacionFilter factura){
		ResponseVO response = new ResponseVO();
		HttpSession session = null;
		BeanSession beanSession = null;
		
		beanSession = SessionUtil.validaSesion(session);
		String userName = beanSession.getUser().getUserName();
		Integer userProfile = beanSession.getUser().getUserProfile();
		
		log.info("[ POST /cancela] - Inicia ");
		response = rabbitServices.cancelaFacturacion(factura.getInvoiceNumber(),userName,userProfile);
		log.info("[ POST /cancela] - Termina ");
		return ResponseEntity.ok(response);
	}
	
	@RequestMapping(value = "/manual/{noFactura}", method = RequestMethod.GET)
	public ResponseEntity<ResponseVO> facturacionManual(HttpServletRequest request, @PathVariable String noFactura){
		ResponseVO response = new ResponseVO();
		log.info("[ POST /manual/{noFactura}] - Inicia ");
		response = rabbitServices.facturacionManual(noFactura);
		log.info("[ POST /manual/{noFactura}] - Termina ");
		return ResponseEntity.ok(response);
		
	}
	
	@RequestMapping(value = "/sar/{idSar}/tipoPago/{tPago}", method = RequestMethod.GET)
	public ResponseEntity<ResponseVO> solicitaFacturaPorTipoPago(HttpServletRequest request, @PathVariable String idSar, @PathVariable String tPago){
		ResponseVO response = new ResponseVO();
		log.info("[ POST /sar/{idSar}/tipoPago/{tPago} - Inicia ");
		response = rabbitServices.facturacionPorTipoDePago(idSar, tPago);
		log.info("[ POST /sar/{idSar}/tipoPago/{tPago} - Termina ");
		return ResponseEntity.ok(response);
	}
	
	@RequestMapping(value = "/refacturacion", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseVO> refacturacion(HttpServletRequest request, @RequestBody BeanFacturacion datos){
		ResponseVO response = new ResponseVO();
		log.info("[ POST /refacturacion ] - Inicia ");
		HttpSession session = null;
		BeanSession beanSession;
		session = request.getSession(false);
		beanSession = SessionUtil.validaSesion(session);
		String userName = beanSession.getUser().getUserName();
		response = rabbitServices.refacturacion(datos,beanSession.getUser().getIdUser());
		
		
		if(response.getTipoMensaje().equals(Mensajes.TIPO_EXITO.getMensaje())){
			historylog.registraAccion (datos.getFolio(),userName , HistoryLogAction.STATUS_REFACTURACION, "RECHAZADOS FACTURACION :Cambio de status de Refacturacion");
		}
		
		log.info("[ POST /refacturacion ] - Termina ");
		return ResponseEntity.ok(response);
	}
	
	
	@RequestMapping(value = "/catalogoIncidencias", method = RequestMethod.GET, consumes = "application/json")
	public ResponseEntity<ResponseVO> catalogoIncidencias() {
		log.info("[/dameStatus/]::Entrando al Servicio para obtener status facturacion :");
		ResponseVO response = new ResponseVO();
		Map<String, Object> data = new HashMap<String, Object>();
		HttpSession session = null;
		BeanSession beanSession;
		session = request.getSession(false);
		beanSession = SessionUtil.validaSesion(session);
		Locale currentLocale = session.getAttribute("javax.servlet.jsp.jstl.fmt.locale.session") == null
				? new Locale("en", "US")
				: (Locale) session.getAttribute("javax.servlet.jsp.jstl.fmt.locale.session");
		try {
			if (beanSession == null)
				throw new Exception("session invalida");

			List<CatStatusIncidencias> listIncidencia = facturacionService.getListCatIncidencias();
			response.setTipoMensaje(Mensajes.TIPO_EXITO.getMensaje());
			response.setMensaje(Mensajes.MSG_EXITO.getMensaje());
			data.put("listStatus", listIncidencia);
			response.setResponseObject(data);
			log.info("[/dameStatus/]::Saliendo al REST s:");
			return ResponseEntity.ok(response);
		} catch (Exception e) {
			response.setTipoMensaje(Mensajes.TIPO_ERROR.getMensaje());
			response.setMensaje(Mensajes.MSG_ERROR.getMensaje());
			data.put("error", ExceptionUtils.getStackTrace(e));
			log.info("Error");
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
		}

	}
}
