package com.srm.fungandrui.facturacion.service;

import java.util.List;

import javax.servlet.ServletException;

import com.truper.businessEntity.UserProfileBean;
import com.truper.expediente.PerfilUsuarioDTO; 
public interface ExpedienteProfileService {	
	public List<UserProfileBean> getConsultaPerfilUsuario() throws ServletException ;

}
