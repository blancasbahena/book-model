package com.srm.fungandrui.pis.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.srm.fungandrui.sc.model.BeanSession;
import com.srm.fungandrui.sc.service.ControlMatrizService;
import com.srm.fungandrui.sc.utils.SessionUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
@RequestMapping("/SpecialProforma")
public class ProformaIIController {

	@Autowired
	ControlMatrizService service;


	@RequestMapping(value = "/view", method = { RequestMethod.GET, RequestMethod.POST})
	public ModelAndView getBloqueos(HttpServletRequest request,
			Model model) {
		HttpSession session = null;
		BeanSession beanSession;
		ModelAndView mav = null;
		
		session = request.getSession(false);
		beanSession = SessionUtil.validaSesion(session);
		if (beanSession.getMav() == null) {
			
				try {
					mav = new ModelAndView("redirect:/ProformaServlet");
				} catch (Exception e) {
					log.error(e.getMessage());
				}
		}
		return mav;
	}
}