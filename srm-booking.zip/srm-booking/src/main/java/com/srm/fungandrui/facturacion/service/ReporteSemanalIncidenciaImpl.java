package com.srm.fungandrui.facturacion.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.srm.fungandrui.facturacion.dao.IFacturacionDAO;
import com.srm.fungandrui.facturacion.models.ReporteSemanalIncidencias;

@Service
public class ReporteSemanalIncidenciaImpl implements ReporteSemanalIncidencia{

	@Autowired
	IFacturacionDAO ifacturacionDAO;
	@Override
	public List<ReporteSemanalIncidencias> getReporteSemanalIncidencias() {
		List<ReporteSemanalIncidencias> reporteSemanalIncidencias = ifacturacionDAO.getReporteSemanalIncidencias();
		return reporteSemanalIncidencias;
	}

}
