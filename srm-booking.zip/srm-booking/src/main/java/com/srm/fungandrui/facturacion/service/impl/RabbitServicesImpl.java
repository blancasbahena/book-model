package com.srm.fungandrui.facturacion.service.impl;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Connection;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpSession;

import org.codehaus.jackson.JsonProcessingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.jfree.util.Log;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.gson.Gson;
import com.srm.app.constantes.Mensajes;
import com.srm.fungandrui.expediente.service.ExpedienteService;
import com.srm.fungandrui.facturacion.dao.FacturacionDAOImpl;
import com.srm.fungandrui.facturacion.dao.IFacturacionDAO;
import com.srm.fungandrui.facturacion.dao.PeticionRabbit;
import com.srm.fungandrui.facturacion.models.BeanFacturacion;
import com.srm.fungandrui.facturacion.models.CatStatusFactura;
import com.srm.fungandrui.facturacion.models.CatTipoOperacion;
import com.srm.fungandrui.facturacion.models.DataFactura;
import com.srm.fungandrui.facturacion.models.DataToSIFE;
import com.srm.fungandrui.facturacion.models.Facturacion;
import com.srm.fungandrui.facturacion.models.ItemFactura;
import com.srm.fungandrui.facturacion.models.SharepointFile;
import com.srm.fungandrui.facturacion.service.RabbitService;
import com.srm.fungandrui.sc.model.ResponseVO;
import com.srm.pli.bo.BeanContactoDocumentos;
import com.srm.pli.bo.SarDetalleBO;
import com.srm.pli.dao.SAR_CDI_DAO;
import com.srm.pli.dao.SarDao;
import com.srm.pli.db.ConexionDB;
import com.srm.pli.utils.DateUtils;
import com.srm.pli.utils.FuncionesComunesPLI;
import com.srm.pli.utils.GeneraDocumentos;
import com.srm.pli.utils.PropertiesDb;
import com.srm.pli.utils.Utilerias;
import com.truper.bpm.enums.TipoDocumentosEnum;
import com.truper.businessEntity.ImportacionesProveedoresBean;
import com.truper.businessEntity.UserBean;
import com.truper.expediente.ExpedientePerfilDTO;
import com.truper.publish.Publisher;

import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;

@Log4j2
@Service()
@RequiredArgsConstructor
public class RabbitServicesImpl implements RabbitService {

	private final String HOST = PropertiesDb.getInstance().getString("rabbit.ws.host");
	private final Integer PORT = PropertiesDb.getInstance().getInteger("rabbit.ws.port");
	private final String PASS = PropertiesDb.getInstance().getString("rabbit.ws.pwd");
	private final String USER = PropertiesDb.getInstance().getString("rabbit.ws.user");
	private final String ROUTING_KEY_FACTURACION = PropertiesDb.getInstance()
			.getString("rabbit.ws.routingKey-facturacion");
	private final String ROUTING_KEY_EXPEDIENTE = PropertiesDb.getInstance()
			.getString("rabbit.ws.routingKey-expedientes");
	private final String ROUTING_KEY_FR_FACTURACION = PropertiesDb.getInstance().getString("rabbit.ws.routingKey-fr");
	private final String VIRTUAL_SERVICE = PropertiesDb.getInstance().getString("rabbit.ws.virtualService");
	private final String EXCHANGE_NAME = PropertiesDb.getInstance().getString("rabbit.ws.exchangeName");
	private final String QUEUE_GENERACION_EXPEDIENTE = PropertiesDb.getInstance()
			.getString("rabbit.ws.queueGeneracionExpediente");
	private final String QUEUE_FACTURACION_SOLICITUDES = PropertiesDb.getInstance()
			.getString("rabbit.ws.queueFacturacionSolicitudes");
	private final String QUEUE_FR_FACTURACION = PropertiesDb.getInstance().getString("rabbit.ws.queueFRFacturacion");
	
	
	
	private final boolean AUTOMATICO = true;
	private final boolean DURABLE = true;
	private final boolean EXCLUSIVE = false;
	private final boolean AUTO_DELETE = false;
	private final String POS_FIJO_ID_UNICO = "_@_";

	private final String TRADING_SPECIALTIES = "TS";
	private final String ZMP = "ZMP";

	public final String AM = "AM";
	public final String PM = "PM";

	public final String notRequired = "N/A";

	private final String RUTA_SHAREPOINT_DOCUMENTOS = PropertiesDb.getInstance()
			.getString("srm.facturacion.sharepoint.documentos");

	@Autowired
	private ExpedienteService expedienteService;

	private static final IFacturacionDAO facturacionDAO = new FacturacionDAOImpl();
	
	private final String taxId44="TRU7911227L6";
	
	private final Integer TIPO_SOLICITUD_43= 43;
	private final Integer TIPO_SOLICITUD_19=19;
	private final String PROVEEDOR_PARCEL="PARCELMOBI S.A. DE C.V.";
	private final String NUMERO_PROVEEDOR_PARCEL="719475";
	private final String RFC_TRUPPER= "THE791105HP2";
	/*
	@Override
	public PeticionRabbit testExpediente(PeticionRabbit peticion) {

		ObjectMapper mapper = new ObjectMapper();
		try {
			Publisher.publish(HOST, PORT, USER, PASS, VIRTUAL_SERVICE, QUEUE_GENERACION_EXPEDIENTE, EXCHANGE_NAME,
					ROUTING_KEY_EXPEDIENTE, null, mapper.writeValueAsString(peticion), DURABLE, EXCLUSIVE, AUTO_DELETE);
		} catch (JsonProcessingException e) {
			log.error(e.getStackTrace().toString(),e);
			e.printStackTrace();
		} catch (IOException e) {
			log.error(e.getStackTrace().toString(),e);
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return peticion;
	}*/

	@Override
	public PeticionRabbit testFacturacion(PeticionRabbit peticion) {

		ObjectMapper mapper = new ObjectMapper();
		try {
			Publisher.publish(HOST, PORT, USER, PASS, VIRTUAL_SERVICE, QUEUE_FACTURACION_SOLICITUDES, EXCHANGE_NAME,
					ROUTING_KEY_FACTURACION, null, mapper.writeValueAsString(peticion), DURABLE, EXCLUSIVE, AUTO_DELETE);
		} catch (JsonProcessingException e) {
			log.error(e.getStackTrace().toString(),e);
			e.printStackTrace();
		} catch (IOException e) {
			log.error(e.getStackTrace().toString(),e);
			e.printStackTrace();
		}

		return peticion;
	}

	@Override
	public PeticionRabbit testFRFacturacion(PeticionRabbit peticion) {

		ObjectMapper mapper = new ObjectMapper();
		try {
			Publisher.publish(HOST, PORT, USER, PASS, VIRTUAL_SERVICE, QUEUE_FR_FACTURACION, EXCHANGE_NAME,
					ROUTING_KEY_FR_FACTURACION, null, mapper.writeValueAsString(peticion), DURABLE, EXCLUSIVE, AUTO_DELETE);
		} catch (JsonProcessingException e) {
			log.error(e.getStackTrace().toString(),e);
			e.printStackTrace();
		} catch (IOException e) {
			log.error(e.getStackTrace().toString(),e);
			e.printStackTrace();
		}

		return peticion;
	}

	@Override
	public void envioDTOAExpediente(ExpedientePerfilDTO dto) {
		Publisher.publish(HOST, PORT, USER, PASS, VIRTUAL_SERVICE, QUEUE_GENERACION_EXPEDIENTE, EXCHANGE_NAME,
				ROUTING_KEY_EXPEDIENTE, null, new Gson().toJson(dto), DURABLE, EXCLUSIVE, AUTO_DELETE);

	}

	@Override
	public ResponseVO solicitaFacturacion(BeanFacturacion factura, Integer idUser,String userName) {
		ResponseVO respuesta = new ResponseVO();
		List<DataFactura> datos = facturacionDAO.getDataFacturacionBySar(factura.getFolio().toString());

		log.info("Inicia proceso de solicitud de Factura: {}",factura.getFolio().toString());
		
		Map<String, Object> payloads = generaPayloads(datos);

		List<PeticionRabbit> salidas = new ArrayList<PeticionRabbit>();

		LocalDateTime aprobacion = LocalDateTime.now();

		payloads.forEach((k, v) -> {

			HashMap<String, Object> mapa = (HashMap<String, Object>) v;

			if (!mapa.isEmpty()) {
				try {

					Map<String, Object> info = (HashMap<String, Object>) mapa.get("info");
					String pos = "";
					ArrayList<ItemFactura> items = (ArrayList<ItemFactura>) mapa.get("item");

					for (ItemFactura item : items) {
						pos += item.getEbeln() + ",";
					}

					// Guardar en BD
					Facturacion registro = new Facturacion();
					registro.setFolio((String) info.get("sar"));
					registro.setAutomatico(AUTOMATICO);
					//registro.setFacturista(idUser.toString());

					// Calcula AM o PM
					if (aprobacion.getHour() > 11 && aprobacion.getHour() <= 17) {
						registro.setAmpm(PM);
					} else {
						registro.setAmpm(AM);
					}

					registro.setFechaHoraAprobacionSDI(aprobacion.toString());

					registro.setSupplier((String) info.get("clave_proveedor"));
					registro.setPriority((Integer) info.get("priority") + "");
					registro.setCondicionPago((String) info.get("condicionPago"));
					registro.setPo(pos);
					registro.setUrgente(factura.getUrgente());
					registro.setAuxkey((String) info.get("auxkey"));
					registro.setPod((String) info.get("pod"));
					registro.setShipmentType((String) info.get("shipmentType"));
					registro.setListItems(items);
					registro.setComentarios("");

					
					if (k.equals( TRADING_SPECIALTIES )) {
						registro.setEsSpecialties(true);
						registro.setCodigoEstatusFactura(CatStatusFactura.FACTURACION_REALIZADA.getId().toString());
					} else if (k.equals( ZMP )) {
						registro.setEsSpecialties(false);
						registro.setCodigoEstatusFactura(CatStatusFactura.FACTURACION_REALIZADA.getId().toString());
					} else {
						registro.setEsSpecialties(false);
						registro.setCodigoEstatusFactura(CatStatusFactura.FACTURACION_SOLICITADA.getId().toString());
					}

					Long lastId = facturacionDAO.saveFacturaPeticion(registro);
					
					DataFactura datosFactura = datos.get(0);
					datosFactura.setAnalistaSDI(userName);
					
					facturacionDAO.ActualizaAnalistaSDI(datosFactura);

					info.put("idFacturacion", lastId);
					info.put("urgente", factura.getUrgente());

					if( !k.equals( TRADING_SPECIALTIES ) && !k.equals( ZMP ) ) {
					
						PeticionRabbit dataRabbit = new PeticionRabbit();
						dataRabbit.setOperationType(CatTipoOperacion.FACTURACION.getTipo());
						dataRabbit.setDescriptionOperation(CatTipoOperacion.FACTURACION.getDescripcion());
						dataRabbit.setPayload(mapa);
	
						salidas.add(dataRabbit);
	
						// Solicitar Facturacion
						ObjectMapper mapper = new ObjectMapper();
	
						Publisher.publish(HOST, PORT, USER, PASS, VIRTUAL_SERVICE, QUEUE_FACTURACION_SOLICITUDES,
								EXCHANGE_NAME, ROUTING_KEY_FACTURACION, null, mapper.writeValueAsString(dataRabbit), DURABLE, EXCLUSIVE, AUTO_DELETE);
						
						log.info("Mensaje de solicitud de facturacion: {}",dataRabbit);
						
					}

				} catch (Exception e) {
					log.error(e.getStackTrace().toString(),e);
					respuesta.createError("Error - No se pudo realizar la peticion de la Factura" + e.getStackTrace());

				}

			}

		});
		log.info("Termina proceso de solicitud de Factura: {}",factura.getFolio().toString());
		respuesta.createSuccess("solicitud", salidas);
		return respuesta;
	}

	private double procesa(double value, int precision)
	{
	    String result = new Double(value).toString();
	    int dot = result.indexOf('.');
	    if (dot < 0){
	        return value;
	    }
	    int newLength = dot + precision + 1;
	    if (newLength == dot + 1){
	        newLength--;
	    }
	    if (newLength > result.length()){
	        newLength = result.length();
	    }
	    String nuevo=  result.substring(0, newLength);
	    return new Double(nuevo);
	}
	
	@Override
	public ResponseVO entregaSIFE(Facturacion factura, HttpSession sesion) {
		ResponseVO respuesta = new ResponseVO();
		// Consumo de expediente
		UserBean usuario = (UserBean) sesion.getAttribute("usuario");

		DataToSIFE datos = null;
		
		if( "-".equals(factura.getNoFacturaPM()) ) {
			datos = facturacionDAO.getDataFacturacionByIdFacturacion(factura);
			 
		}else {
			datos = facturacionDAO.getDataFacturacionByNoFacturaPm(factura);
		}


		Long estatusPeticionCuarentaTres = facturacionDAO.getEstatusFacturaSife(datos.getIdFacturacion(), true, false);

		Long estatusPeticionDieciNueve = facturacionDAO.getEstatusFacturaSife(datos.getIdFacturacion(), false, true);
		
		
		
		String lbcontenedor = datos.getBl() + datos.getContenedor();
		JSONArray documentosExpediente = expedienteService.dameExpedientesEntregaSife(lbcontenedor, "1",
				usuario.getUserProfile(), POS_FIJO_ID_UNICO, datos.getNumeroFactura(),datos.getCondicionDePago());
		

		
		
		List<Integer> lstMateriales = facturacionDAO.getMaterialBySarAndFactura(factura.getSar(),
				factura.getNoFacturaPM());
		
		
		
		ObjectMapper mapper = new ObjectMapper();

		PeticionRabbit dataRabbit19 = null;
		PeticionRabbit dataRabbitExpediente = null;

		
				
		
		
		
		Set<String> posDistinct = new HashSet<String>();

		String[] posa = datos.getOrdenDeCompra().split(",");
		
		boolean isTS = false;

		for (String string : posa) {
			if( string.charAt(0) == '7' ) {
				isTS = true;
			}
			posDistinct.add(string);
		}

		String posAux = posDistinct.toString();
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");

		Date fechaServ = null;
		try {
			fechaServ = Utilerias
					.getDateFromString(SarDao.getInstance().fechaETD(Integer.parseInt(datos.getFolioOrigen())));
		} catch (NumberFormatException | ParseException e) {
			e.printStackTrace();
			log.error(e.getStackTrace().toString(), e);
		}
		datos.setFechaServicio(format.format(fechaServ));

		
		Date fechaEstimadaPago = Utilerias.sumarDiasAFecha(fechaServ, datos.getDiasPago());
		log.info("Problemas con la suma de dias en fecha Estimada Pago :  {} ", fechaEstimadaPago );
		
		
		datos.setFechaEstimadaPago(format.format(fechaEstimadaPago));
		datos.setCentroCostos(notRequired);
		datos.setDescripcion(notRequired);
		datos.setComentariosAdicionales(datos.getBl() == null ? notRequired : datos.getBl());

		datos.setMailContactoTruper(PropertiesDb.getInstance().getString("srm.ws-parcelmobi.sife.mails"));

		datos.setImpuesto(0.0);
		datos.setConImpuesto(false);
		datos.setDocumentoComentarios("GENERADO DESDE FR");

		datos.setDiferencias(false);
		Integer material = !lstMateriales.isEmpty()?lstMateriales.get(0):0;
		
		Integer HANDLING_CHARGE = PropertiesDb.getInstance().getInteger("srm.facturacion.handling.charge");  // 2931
		Integer FLETES = PropertiesDb.getInstance().getInteger("srm.facturacion.pagos.fletes");
		String documentosNumero = facturacionDAO.getNumerosDeDocumentos(factura);
		if (lstMateriales.size() == 1 && !isTS && material.equals(HANDLING_CHARGE) || material.equals(FLETES)) {
			if (estatusPeticionCuarentaTres == 0) {
				PeticionRabbit dataRabbitHandling = null;
					documentosNumero = facturacionDAO.getNumerosDeDocumentosBySarAndInvoide(factura);
					Integer diasPago =Integer.parseInt(PropertiesDb.getInstance().getString("fr.sife.dias.pago"));
					Date fechaEstimadaPago43 =Utilerias.sumarDiasAFecha(new Date(), diasPago);
					datos.setFechaEstimadaPago(format.format(fechaEstimadaPago43));
					DataToSIFE datosSifeExpediente = datos;
					datosSifeExpediente.setIdtipoSolicitud(TIPO_SOLICITUD_43);
					datosSifeExpediente.setIdTipoPartida(1l);
					datosSifeExpediente.setTotal(0.0);
					datosSifeExpediente.setSubtotal(0.0);
					datosSifeExpediente.setImpuesto(0.0);
					datosSifeExpediente.setObservacion(posAux.substring(1, posAux.toString().length() - 1));
					datosSifeExpediente.setNumeroProveedor(NUMERO_PROVEEDOR_PARCEL);
					datosSifeExpediente.setNombreProveedor(PROVEEDOR_PARCEL);
					datosSifeExpediente.setTaxId(taxId44);
					datosSifeExpediente.setRfcEmpresaRecibe(RFC_TRUPPER);
					datosSifeExpediente.setOrdenDeCompra("");
					// datosSifeExpediente.setMoneda("");
					datosSifeExpediente.setNumeroFactura(datos.getNumeroFactura());
					
					
					List<SharepointFile> sharepointFilesExpediente = creaDocumentosExpediente(documentosExpediente, 2);
					List<SharepointFile> sharepointFilesExpedienteFinal = new ArrayList<SharepointFile>();		
					

					for (SharepointFile sharepointFile : sharepointFilesExpediente) {
						boolean isTxt = sharepointFile.getFile().toLowerCase().contains("txt");
						boolean isXml = sharepointFile.getFile().toLowerCase().contains("xml");
						SharepointFile file = sharepointFile;
						if (isTxt) {
							file.setDocumentType("Doc Soporte");
						}
						if (isXml) {
							file.setDocumentType("XML");
						}
						sharepointFilesExpedienteFinal.add(file);
					}		
					
					datosSifeExpediente.setSharepointFiles(sharepointFilesExpedienteFinal);
					dataRabbitHandling = creaObjetoDataRabbit(datosSifeExpediente);
				try {

					Publisher.publish(HOST, PORT, USER, PASS, VIRTUAL_SERVICE, QUEUE_FACTURACION_SOLICITUDES,
							EXCHANGE_NAME, ROUTING_KEY_FACTURACION, null, mapper.writeValueAsString(dataRabbitHandling),
							DURABLE, EXCLUSIVE, AUTO_DELETE);

					// Actualizar Status en BD
					Facturacion facturaSave = new Facturacion();
					facturaSave.setId(datos.getIdFacturacion());
					facturaSave.setStatusId(CatStatusFactura.ENVIADO_A_SIFE.getId());
					facturaSave.setComentarios(factura.getComentarios());
					facturacionDAO.updateStatusById(facturaSave, true, true);

				} catch (IOException e) {
					e.printStackTrace();
					log.error(e.getStackTrace().toString(), e);
				}
			}

		} else {

			

				if (datos.getFolioOrigen() != null) {

					ImportacionesProveedoresBean bean_prov = FuncionesComunesPLI
							.getProveedor(datos.getNumeroProveedor());
					ImportacionesProveedoresBean bean_prov_client = FuncionesComunesPLI
							.getProveedor(datos.getCliente());

					SarDetalleBO sarDetalle = new SarDetalleBO();

					// Calculo de Total
					Double total = 0d;
					BigDecimal totalBig=new BigDecimal(0);
					sarDetalle.setFolio(Integer.parseInt(datos.getFolioOrigen()));
					sarDetalle.setCondicionPago(datos.getCondicionDePago());
					ArrayList<SarDetalleBO> pos;
					try {
						pos = SAR_CDI_DAO.selectSarDetalleDinamico(sarDetalle);

						for (SarDetalleBO po : pos) {
							List<String> FOCS_ITEMS = Arrays.asList(PropertiesDb.getInstance().getStringTrim("cargaImportData.focsItems").split(","));
							if (!FOCS_ITEMS.contains(po.getMaterial().toString())) {
								BigDecimal subtotal = po.getPrecioUnitario().multiply(po.getCantidadUnidadMedida());
								totalBig =totalBig.add(funcionTruncaDecimales(subtotal, 2));
							}
						}
						if(totalBig.doubleValue() >0) {
							log.info("Se envia monto Redondeado >> "+totalBig.doubleValue() );
							total =totalBig.doubleValue();
							datos.setSubtotal(totalBig.doubleValue());
							datos.setTotal(totalBig.doubleValue());
						}
					} catch (ClassNotFoundException e1) {
						e1.printStackTrace();
						log.error(e1.getStackTrace().toString(), e1);
					}

					datos.setIdtipoSolicitud(TIPO_SOLICITUD_19);
					datos.setNombreProveedor(bean_prov.getNombreProveedor());
					datos.setObservacion(posAux.substring(1, posAux.toString().length() - 1));
					datos.setCentroCostos(notRequired);
					datos.setDescripcion(notRequired);
					datos.setComentariosAdicionales(datos.getBl() == null ? notRequired : datos.getBl());
					datos.setFechaServicio(format.format(fechaServ));
					GeneraDocumentos genera = new GeneraDocumentos();
					BeanContactoDocumentos rfc = genera.generaContactosDocumentos(bean_prov, bean_prov_client);
					datos.setRfcEmpresaRecibe(rfc.getRfc_shipper().replace("-", "").replace("RFC: ", ""));
					datos.setMailContactoTruper(PropertiesDb.getInstance().getString("srm.ws-parcelmobi.sife.mails"));

					datos.setTaxId(bean_prov.getTaxId());
					datos.setImpuesto(0.0);
					datos.setConImpuesto(false);
					datos.setDocumentoComentarios("GENERADO DESDE FR");

					datos.setDiferencias(false);

					JSONArray expe = expedienteService.dameExpedientesEntregaSife(lbcontenedor, "2,3,4",
							usuario.getUserProfile(), POS_FIJO_ID_UNICO, "", datos.getCondicionDePago());

					List<SharepointFile> sharepointFiles = creaDocumentosExpediente(expe, 1);

					DataToSIFE datosSife19 = datos;

					datosSife19.setTotal(datos.getTotal());

					datosSife19.setSubtotal(datosSife19.getTotal());
					datosSife19.setIdtipoSolicitud(TIPO_SOLICITUD_19);
					datosSife19.setNumeroFactura(datos.getConcepto());
					datosSife19.setSharepointFiles(sharepointFiles);

	
					datosSife19.setDocumentoNumero(documentosNumero);

					dataRabbit19 = creaObjetoDataRabbit(datosSife19);
					JSONObject json10 = new JSONObject(dataRabbit19);
					try {

						if (estatusPeticionDieciNueve == 0) {
							Publisher.publish(HOST, PORT, USER, PASS, VIRTUAL_SERVICE, QUEUE_FACTURACION_SOLICITUDES,
									EXCHANGE_NAME, ROUTING_KEY_FACTURACION, null, mapper.writeValueAsString(dataRabbit19),
									DURABLE, EXCLUSIVE, AUTO_DELETE);
						}
						log.info(json10.toString());

						if( !isTS ) {
							documentosNumero = facturacionDAO.getNumerosDeDocumentosBySarAndInvoide(factura);
							Integer diasPago =Integer.parseInt(PropertiesDb.getInstance().getString("fr.sife.dias.pago"));
							Date fechaEstimadaPago43 =Utilerias.sumarDiasAFecha(new Date(), diasPago);
							datos.setFechaEstimadaPago(format.format(fechaEstimadaPago43));
							DataToSIFE datosSifeExpediente = datos;
							datosSifeExpediente.setIdtipoSolicitud(TIPO_SOLICITUD_43);
							datosSifeExpediente.setNumeroProveedor(NUMERO_PROVEEDOR_PARCEL);
							datosSifeExpediente.setNombreProveedor(PROVEEDOR_PARCEL);
							datosSifeExpediente.setIdTipoPartida(1l);
							datosSifeExpediente.setTotal(0.0);
							datosSifeExpediente.setSubtotal(0.0);
							datosSifeExpediente.setImpuesto(0.0);
							// datosSifeExpediente.setMoneda("");
							datosSifeExpediente.setOrdenDeCompra("");
							datosSifeExpediente.setTaxId(taxId44);
							datosSifeExpediente.setNumeroFactura(datos.getNumeroFactura());
							datosSifeExpediente.setRfcEmpresaRecibe(RFC_TRUPPER);
							List<SharepointFile> sharepointFilesExpediente = creaDocumentosExpediente(documentosExpediente, 2);
							List<SharepointFile> sharepointFilesExpedienteFinal = new ArrayList<SharepointFile>();		
							

							for (SharepointFile sharepointFile : sharepointFilesExpediente) {
								boolean isTxt = sharepointFile.getFile().contains("txt");
								boolean isXml = sharepointFile.getFile().contains("xml");
								SharepointFile file = sharepointFile;
								if (isTxt) {
									file.setDocumentType("Doc Soporte");
								}
								if (isXml) {
									file.setDocumentType("XML");
								}
								sharepointFilesExpedienteFinal.add(file);
							}	
							datosSifeExpediente.setSharepointFiles(sharepointFilesExpediente);
							dataRabbitExpediente = creaObjetoDataRabbit(datosSifeExpediente);
							JSONObject jsonExpediente = new JSONObject(dataRabbitExpediente);
							log.info(jsonExpediente.toString());
							
							if (estatusPeticionCuarentaTres == 0) {
	
							Publisher.publish(HOST, PORT, USER, PASS, VIRTUAL_SERVICE, QUEUE_FACTURACION_SOLICITUDES,
									EXCHANGE_NAME, ROUTING_KEY_FACTURACION, null,
									mapper.writeValueAsString(dataRabbitExpediente), DURABLE, EXCLUSIVE, AUTO_DELETE);
							}
						}
						
						// Actualizar Status en BD
						Facturacion facturaSave = new Facturacion();
						facturaSave.setId(datos.getIdFacturacion());
						facturaSave.setStatusId(CatStatusFactura.ENVIADO_A_SIFE.getId());
						facturaSave.setComentarios(factura.getComentarios());
						facturacionDAO.updateStatusById(facturaSave, estatusPeticionCuarentaTres == 0, estatusPeticionDieciNueve == 0);

					} catch (IOException e) {
						e.printStackTrace();
						log.error(e.getStackTrace().toString(), e);
					}

					respuesta.createSuccess("solicitud", dataRabbit19);
					return respuesta;
				}
				respuesta.createError("Error - No se pudo realizar la peticion de Entrega SIFE");
			}
		
		return respuesta;
	}
 

	@Override
	public ResponseVO cancelaFacturacion(String noFactura,String userName,Integer userProfile) {
		ResponseVO respuesta = new ResponseVO();

		Facturacion factura = null;

		Connection conn = null;
		try {
			conn = ConexionDB.dameConexion();
			conn.setAutoCommit(false);
			factura = new Facturacion();
			factura.setNoFacturaPM(noFactura);
			factura = facturacionDAO.cancelarFactura(factura, conn);

		} catch (ClassNotFoundException | SQLException e1) {

			try {
				log.info("Fallo cancelacion - haciendo  RollBack");
				conn.rollback();
				conn.setAutoCommit(true);
				ConexionDB.devolver(conn);
			} catch (SQLException e) {
				e.printStackTrace();
				log.error(e.getStackTrace().toString(),e);
			}
			e1.printStackTrace();
			log.error(e1.getStackTrace().toString(),e1);
		}

		try {
			if (factura != null) {

				PeticionRabbit dataRabbit = new PeticionRabbit();
				dataRabbit.setOperationType(CatTipoOperacion.CANCELACION.getTipo());
				dataRabbit.setDescriptionOperation(CatTipoOperacion.CANCELACION.getDescripcion());
				Map<String, Object> payload = new HashMap<String, Object>();

				List<Map<String, String>> items = new ArrayList<Map<String, String>>();

				Map<String, String> item = new HashMap<String, String>();

				item.put("vbelnvf", factura.getNoFacturaPM());

				items.add(item);

				payload.put("item", items);

				Map<String, Object> info = new HashMap<String, Object>();
				info.put("facturaPM", factura.getNoFacturaPM());
				info.put("id", factura.getId());
				info.put("BL", factura.getBlNumber());
				info.put("Contenedor", factura.getContainer());
				info.put("supplier", factura.getSupplier());
				info.put("folio", factura.getSar());
				info.put("userName", userName);
				info.put("userProfile", userProfile);

				payload.put("info", info);

				dataRabbit.setPayload(payload);
				
				ObjectMapper mapper = new ObjectMapper();
				
				Publisher.publish(HOST, PORT, USER, PASS, VIRTUAL_SERVICE, QUEUE_FACTURACION_SOLICITUDES, EXCHANGE_NAME,
						ROUTING_KEY_FACTURACION, null, mapper.writeValueAsString(dataRabbit),DURABLE, EXCLUSIVE, AUTO_DELETE);

				respuesta.setTipoMensaje(Mensajes.TIPO_EXITO.getMensaje());
				respuesta.setMensaje(Mensajes.MSG_EXITO.getMensaje());
				respuesta.createSuccess("solicitud", dataRabbit);
				
				conn.commit();
				conn.setAutoCommit(true);
				ConexionDB.devolver(conn);

				return respuesta;

			} else {

				respuesta.setTipoMensaje(Mensajes.TIPO_WARNING.getMensaje());
				respuesta.setMensaje(Mensajes.MSG_WARINIG.getMensaje());

				return respuesta;
			}
		} catch (Exception e) {

			try {
				log.info("Fallo cancelacion - haciendo  RollBack");
				conn.rollback();
				conn.setAutoCommit(true);
				ConexionDB.devolver(conn);
			} catch (SQLException ex) {
				e.printStackTrace();
				log.error(ex.getStackTrace().toString(),ex);
			}
			log.error(e.getStackTrace().toString(),e);

			respuesta.setTipoMensaje(Mensajes.TIPO_ERROR.getMensaje());
			respuesta.setMensaje(Mensajes.MSG_ERROR.getMensaje());

			return respuesta;
		}
	}
 
	@Override
	public ResponseVO facturacionManual(String noFactura) {
		ResponseVO respuesta = new ResponseVO();
		respuesta.setMensaje("OK");
		respuesta.setTipoMensaje("S");
		respuesta.createSuccess("manual", "OK");

		Map<String, String> salida = new HashMap<String, String>();

		salida.put("noFactura", noFactura);
		return respuesta;
	}

	@Override
	public ResponseVO facturacionPorTipoDePago(String sar, String condicionPAgo) {
		ResponseVO respuesta = new ResponseVO();
		respuesta.setMensaje("OK");
		respuesta.setTipoMensaje("S");
		Map<String, String> salida = new HashMap<String, String>();

		salida.put("idDar", sar);
		salida.put("condicionDePago", condicionPAgo);
		respuesta.createSuccess("TipoPAgo", salida);
		return respuesta;
	}

	@Override
	public ResponseVO refacturacion(BeanFacturacion datos,Integer userId) {
		ResponseVO respuesta = new ResponseVO();
		Facturacion factura = new Facturacion();
		factura.setId(datos.getId());
		factura.setStatus(CatStatusFactura.REENVIO_FACTURACION.getId().toString());
		factura.setComentarios("");
		factura.setFacturista(userId.toString());
		Connection conn = null;
		log.info("Inicia proceso de Refacturacion, idFacturacion: {}",datos.getId());
		try {
			conn = ConexionDB.dameConexion();
			conn.setAutoCommit(false);

			factura = facturacionDAO.UpdateStatusFactura(factura, conn);

			List<DataFactura> data = facturacionDAO.getDataRefacturacionById(datos.getId(), conn);

			Map<String, Object> payloads = generaPayloadsRefacturacion(data);

			PeticionRabbit dataRabbit = new PeticionRabbit();
			dataRabbit.setOperationType(CatTipoOperacion.FACTURACION.getTipo());
			dataRabbit.setDescriptionOperation(CatTipoOperacion.FACTURACION.getDescripcion());
			Map<String, Object> payload = (Map<String, Object>) payloads.get(factura.getCondicionPago());

			if (payload != null && !payload.isEmpty()) {
				dataRabbit.setPayload(payload);

				Map<String, Object> info = (HashMap<String, Object>) payload.get("info");

				info.put("idFacturacion", datos.getId());

				ObjectMapper mapper = new ObjectMapper();

				try {

					Publisher.publish(HOST, PORT, USER, PASS, VIRTUAL_SERVICE, QUEUE_FACTURACION_SOLICITUDES,
							EXCHANGE_NAME, ROUTING_KEY_FACTURACION, null, mapper.writeValueAsString(dataRabbit), DURABLE, EXCLUSIVE, AUTO_DELETE);
					log.info("Mensaje de refacturacion enviado: {}",dataRabbit);
				} catch (IOException e) {
					if (conn != null) {
						log.info("Fall� refacturaci�n - haciendo  RollBack");
						conn.rollback();
						conn.setAutoCommit(true);
						ConexionDB.devolver(conn);
					}
					e.printStackTrace();
					log.error(e.getStackTrace().toString(),e);
				}

				conn.commit();
				conn.setAutoCommit(true);
				ConexionDB.devolver(conn);

				log.info("Flujo de refacturaci�n con exito, solicitud reenviada");

				respuesta.setMensaje(Mensajes.MSG_EXITO.getMensaje());
				respuesta.setTipoMensaje(Mensajes.TIPO_EXITO.getMensaje());
				respuesta.createSuccess("respuesta", dataRabbit);

			} else {
				if (conn != null) {

					log.info("Fall� en flujo de refacturaci�n, RollBack");
					conn.rollback();
					conn.setAutoCommit(true);
					ConexionDB.devolver(conn);
				}
				respuesta.setMensaje(Mensajes.MSG_WARINIG.getMensaje());
				respuesta.setTipoMensaje(Mensajes.TIPO_WARNING.getMensaje());

			}

		} catch (ClassNotFoundException e1) {
			log.error(e1.getStackTrace().toString(),e1);
			e1.printStackTrace();
		} catch (SQLException e1) {
			if (conn != null) {
				try {
					conn.rollback();
					conn.setAutoCommit(true);
					ConexionDB.devolver(conn);
				} catch (SQLException e) {
					log.error(e.getStackTrace().toString(),e);
					e.printStackTrace();
				}

			}
			log.error(e1.getStackTrace().toString(),e1);
			e1.printStackTrace();
			respuesta.setMensaje(Mensajes.MSG_ERROR.getMensaje());
			respuesta.setTipoMensaje(Mensajes.TIPO_ERROR.getMensaje());
		}

		return respuesta;
	}

	private Map<String, Object> generaPayloads(List<DataFactura> datos) {
		Map<String, Object> payloads = new HashMap<String, Object>();
		Integer HANDLING_CHARGE = PropertiesDb.getInstance().getInteger("srm.facturacion.handling.charge");
		Integer FLETES = PropertiesDb.getInstance().getInteger("srm.facturacion.pagos.fletes");
		
		
		for (DataFactura dato : datos) {
			if( dato.getPo().charAt(0) == '1' && payloads.containsKey(ZMP) ) {

				Map<String, Object> payload = (Map<String, Object>) payloads.get(ZMP);

				Map<String, Object> info = (Map<String, Object>) payload.get("info");

				List<ItemFactura> items = (ArrayList<ItemFactura>) payload.get("item");
				ItemFactura item = new ItemFactura();
				item.setEbeln(dato.getPo());
				item.setEbelp(dato.getPosicion());
				info.put("ordenDeCompra", "," + info.get("ordenDeCompra") + dato.getPo());
				if (dato.getCantidadUnidadMedida() == 0) {
					item.setMenge(dato.getCantidad());
				} else {
					item.setMenge(dato.getCantidadUnidadMedida());
				}
				items.add(item);

			} else if ( dato.getPo().charAt(0) == '7' &&  payloads.containsKey(TRADING_SPECIALTIES) ) {
			
				Map<String, Object> payload = (Map<String, Object>) payloads.get(TRADING_SPECIALTIES);

				Map<String, Object> info = (Map<String, Object>) payload.get("info");

				ArrayList<ItemFactura> items = (ArrayList<ItemFactura>) payload.get("item");
				ItemFactura item = new ItemFactura();
				item.setEbeln(dato.getPo());
				item.setEbelp(dato.getPosicion());
				info.put("ordenDeCompra", "," + info.get("ordenDeCompra") + dato.getPo());
				if (dato.getCantidadUnidadMedida() == 0) {
					item.setMenge(dato.getCantidad());
				} else {
					item.setMenge(dato.getCantidadUnidadMedida());
				}
				items.add(item);
				
			}				
			else if (!dato.getMaterial().equals(HANDLING_CHARGE)&&!dato.getMaterial().equals(FLETES) && payloads.containsKey(dato.getCondicionPago())) {

				Map<String, Object> payload = (Map<String, Object>) payloads.get(dato.getCondicionPago());

				Map<String, Object> info = (Map<String, Object>) payload.get("info");

				ArrayList<ItemFactura> items = (ArrayList<ItemFactura>) payload.get("item");
				ItemFactura item = new ItemFactura();
				item.setEbeln(dato.getPo());
				item.setEbelp(dato.getPosicion());
				info.put("ordenDeCompra", "," + info.get("ordenDeCompra") + dato.getPo());
				if (dato.getCantidadUnidadMedida() == 0) {
					item.setMenge(dato.getCantidad());
				} else {
					item.setMenge(dato.getCantidadUnidadMedida());
				}
				items.add(item);

			} else {
				Map<String, Object> payload = new HashMap<String, Object>();

				Map<String, Object> info = new HashMap<String, Object>();
				
				Map<String, String> optional = new HashMap<String, String>();

				ImportacionesProveedoresBean imBeanProv = FuncionesComunesPLI.getProveedor(dato.getProveedor());

				info.put("contenedor", dato.getContenedor());
				info.put("clave_proveedor", dato.getProveedor());
				info.put("sar", dato.getFolio());
				info.put("bl", dato.getBL());
				info.put("condicionPago", dato.getCondicionPago());
				info.put("priority", dato.getPrioridad());
				info.put("taxId", imBeanProv.getTaxId());
				info.put("diferencias", false);
				info.put("folioOrigen", dato.getFolio());
				info.put("ordenDeCompra", dato.getPo());
				info.put("pod", dato.getPod());
				info.put("shipmentType", dato.getShipmentType());
				
				Integer etd = dato.getEtdFinal() == null || dato.getEtdFinal() == 0 ? dato.getEtd() : dato.getEtdFinal();
				
				SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
				
				Date fechaEtd = DateUtils.getInstance().parseIntToDate(etd,"yyyyMMdd");
				
				optional.put("ixblnr",dato.getFacturaProveedor());
				optional.put("izfbdt", dateFormat.format(fechaEtd));
				optional.put("ipais",dato.getPaisOrigen());
				
				

				if (dato.getPo().charAt(0) == '7') {
					info.put("auxkey", "TS");
				}else if (dato.getMaterial().equals(HANDLING_CHARGE) ) {
					info.put("auxkey", dato.getPo() + "-" + dato.getPosicion());
				} else if (dato.getMaterial().equals(FLETES)) {
					info.put("auxkey", dato.getPo() + "-" + dato.getPosicion()+ "F");
				}else {
					info.put("auxkey", "NA");
				}

				ArrayList<ItemFactura> items = new ArrayList<ItemFactura>();
				ItemFactura item = new ItemFactura();
				item.setEbeln(dato.getPo());
				item.setEbelp(dato.getPosicion());
				if (dato.getCantidadUnidadMedida() == 0) {
					item.setMenge(dato.getCantidad());
				} else {
					item.setMenge(dato.getCantidadUnidadMedida());
				}
				items.add(item);

				payload.put("item", items);
				payload.put("info", info);
				payload.put("optional",optional);

				if( dato.getPo().charAt(0) == '7' ) {
					payloads.put(TRADING_SPECIALTIES, payload);
				}else if (dato.getMaterial().equals(HANDLING_CHARGE)) {
					payloads.put(dato.getPo()+"-"+dato.getPosicion(), payload);
				}else if (dato.getMaterial().equals(FLETES)) {
					payloads.put(dato.getPo() + "-" + dato.getPosicion()+"F", payload);
				}else if( dato.getPo().charAt(0) == '1' ) {
					payloads.put(ZMP, payload);
				}else {
					payloads.put(dato.getCondicionPago(), payload);
				}
			}

		}

		return payloads;
	}



	private Map<String, Object> generaPayloadsRefacturacion(List<DataFactura> datos) {

		Map<String, Object> payloads = new HashMap<String, Object>();
		Integer HANDLING_CHARGE = PropertiesDb.getInstance().getInteger("srm.facturacion.handling.charge");
		Integer FLETES = PropertiesDb.getInstance().getInteger("srm.facturacion.pagos.fletes");
		
		for (DataFactura dato : datos) {

			Map<String, Object> payload;
			ArrayList<ItemFactura> items;

			ItemFactura item = new ItemFactura();
			item.setEbeln(dato.getPo());
			item.setEbelp(dato.getPosicion());
			if (dato.getCantidadUnidadMedida() == 0) {
				item.setMenge(dato.getCantidad());
			} else {
				item.setMenge(dato.getCantidadUnidadMedida());
			}

			if (payloads.containsKey(dato.getCondicionPago())) {
				payload = (Map<String, Object>) payloads.get(dato.getCondicionPago());
				items = (ArrayList<ItemFactura>) payload.get("item");
				items.add(item);

			} else {

				Map<String, Object> info = new HashMap<String, Object>();

				Map<String, String> optional = new HashMap<String, String>();

				ImportacionesProveedoresBean imBeanProv = FuncionesComunesPLI.getProveedor(dato.getProveedor());

				info.put("contenedor", dato.getContenedor());
				info.put("clave_proveedor", dato.getProveedor());
				info.put("sar", dato.getFolio());
				info.put("bl", dato.getBL());
				info.put("condicionPago", dato.getCondicionPago());
				info.put("priority", dato.getPrioridad());
				info.put("taxId", imBeanProv.getTaxId());
				info.put("diferencias", false);
				info.put("folioOrigen", dato.getFolio());
				info.put("ordenDeCompra", dato.getPo());
				info.put("pod", dato.getPod());
				info.put("shipmentType", dato.getShipmentType());

				if (dato.getMaterial().equals(HANDLING_CHARGE)) {
					info.put("auxkey", dato.getPo() + "-" + dato.getPosicion());
				}else if (dato.getMaterial().equals(FLETES)) {
					info.put("auxkey", dato.getPo() + "-" + dato.getPosicion()+"F");
				} else {
					info.put("auxkey", "NA");
				}

				payload = new HashMap<String, Object>();
				items = new ArrayList<ItemFactura>();

				SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

				Integer etd = dato.getEtdFinal() == null || dato.getEtdFinal() == 0 ? dato.getEtd()
						: dato.getEtdFinal();

				Date fechaEtd = DateUtils.getInstance().parseIntToDate(etd, "yyyyMMdd");

				optional.put("ixblnr", dato.getFacturaProveedor());
				optional.put("izfbdt", dateFormat.format(fechaEtd));
				optional.put("ipais", dato.getPaisOrigen());

				payload.put("info", info);
				payload.put("optional", optional);
				payloads.put(dato.getCondicionPago(), payload);

				items.add(item);
				payload.put("item", items);
			}

		}

		return payloads;

	}




	@Override
	public ResponseVO bloqueoPOs(String folio) {
		ResponseVO respuesta = new ResponseVO();

		PeticionRabbit dataRabbit = new PeticionRabbit();
		dataRabbit.setOperationType(CatTipoOperacion.BLOQUEO_POS.getTipo());
		dataRabbit.setDescriptionOperation(CatTipoOperacion.BLOQUEO_POS.getDescripcion());

		List<ItemFactura> pos = facturacionDAO.getPosByFolio(folio);

		Map<String, Object> payload = new HashMap<String, Object>();
		payload.put("item", pos);

		Map<String, String> info = new HashMap<String, String>();
		info.put("folioOrigen", folio);
		payload.put("info", info);

		dataRabbit.setPayload(payload);

		ObjectMapper mapper = new ObjectMapper();

		try {
			Publisher.publish(HOST, PORT, USER, PASS, VIRTUAL_SERVICE, QUEUE_FACTURACION_SOLICITUDES, EXCHANGE_NAME,
					ROUTING_KEY_FACTURACION, null, mapper.writeValueAsString(dataRabbit), DURABLE, EXCLUSIVE, AUTO_DELETE);
		} catch (IOException e) {
			log.error(e.getStackTrace().toString(),e);
			e.printStackTrace();
			respuesta.setMensaje(Mensajes.MSG_ERROR.getMensaje());
			respuesta.setTipoMensaje(Mensajes.TIPO_ERROR.getMensaje());
			return respuesta;
		}

		respuesta.setMensaje(Mensajes.MSG_EXITO.getMensaje());
		respuesta.setTipoMensaje(Mensajes.TIPO_EXITO.getMensaje());
		respuesta.createSuccess("peticion", dataRabbit);

		return respuesta;
	}

	private String getDocumentType(int typeI) {
		String type = "";

		// Mejora cambiar a ENUM - TipoDocumentosEnum.
		TipoDocumentosEnum.FACTURA_PARCELMOBI.getId();

		switch (typeI) {
		case 1:
			type = "Factura";	//Factura Parcemobil
			break;
		case 2:
			type = "Factura";	//Factura Proveedor
			break;
		case 3:
			type = "BL";
			break;
		case 4:
			type = "PL";
			break;
		case 5:
			type = "Otros Proveedor";
			break;
		case 6:
			type = "Otros";
			break;
		case 7:
			type = "Pre-BL";
			break;

		}
		return type;
	}
	
	private PeticionRabbit creaObjetoDataRabbit(DataToSIFE dataToSife) {
		PeticionRabbit dataRabbit = new PeticionRabbit();
		dataRabbit.setOperationType(CatTipoOperacion.ENTREGA_SIFE.getTipo());
		dataRabbit.setDescriptionOperation(CatTipoOperacion.ENTREGA_SIFE.getDescripcion());
		Map<String, Object> payload = new HashMap<String, Object>();
		payload.put("info", dataToSife);
		dataRabbit.setPayload(payload);
		return dataRabbit;
		
	}
	
	private List<SharepointFile>  creaDocumentosExpediente(JSONArray documentosExpediente, int opc) {
		List<SharepointFile> sharepointFilesExpediente = new ArrayList<SharepointFile>();
		for (Object object : documentosExpediente) {

			JSONObject json = (JSONObject) object;

			if (json.has("documentos")) {
				JSONArray docs = (JSONArray) json.get("documentos");

				if (docs != null)
					for (Object docO : docs) {

						if (docO != null) {
							JSONObject doc = (JSONObject) docO;
							SharepointFile file = new SharepointFile();
							file.setDocumentType(getDocumentType(json.getInt("tipo")));
							file.setFile(RUTA_SHAREPOINT_DOCUMENTOS + doc.getString("path") + "\\"
									+ doc.getString("archivo"));			
							sharepointFilesExpediente.add(file);
						}

					}
			}

		}
		return sharepointFilesExpediente;

	}
	
	
	
	
	
	
	
	
	
	private BigDecimal funcionTruncaDecimales(BigDecimal valor, int numDecimales) {
		return valor.setScale(numDecimales, RoundingMode.HALF_UP);
	}

}
