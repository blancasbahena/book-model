package com.srm.fungandrui.facturacion.controller;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import com.srm.fungandrui.facturacion.service.ExpedienteProfileService;
import com.srm.pli.dao.SAR_CDI_DAO; 
import com.srm.pli.utils.GeneraDocumentos;
import com.truper.businessEntity.BeanDocumentosSDI;
import com.truper.businessEntity.BeanFactura;
import com.truper.businessEntity.UserProfileBean;
import com.truper.expediente.TotalFacturaDTO;

@Controller
@RequestMapping("/profiles")
public class ExpedienteController {
	@Autowired
	ExpedienteProfileService expedienteProfileService;
	
	@RequestMapping(value = "/", method = { RequestMethod.GET })
	public ResponseEntity<List<UserProfileBean>>  getProfiles() {
		List<UserProfileBean> lista  = new ArrayList<UserProfileBean>();
		try {
			lista= expedienteProfileService.getConsultaPerfilUsuario();
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return   ResponseEntity.ok().body(lista);
	}
	@RequestMapping(value = "/generaFactura", method = { RequestMethod.GET })
	public String generaFactura(@RequestParam String condicion,@RequestParam String numeroFact,
			@RequestParam Boolean isMadera, @RequestParam String proveedor,@RequestParam int id,
			@RequestParam int versionDocumental, @RequestParam String paisOrigen,
			@RequestParam int esPrimerFactura,@RequestParam  String sar) {
		String path = "C:\\arch\\Documents\\2022\\724135\\69464919\\";
		String fileName = "Invoice_" + condicion + "_" ;
		try {
			BeanDocumentosSDI docBase = new BeanDocumentosSDI();
			docBase.setId(id);
			docBase.setVersionFacturas(versionDocumental);
			//// Generar funcion para buscar si el numero de factura ya fue utilizado
			if (SAR_CDI_DAO.nombreYaExiste(numeroFact, proveedor)) {
				throw new ServletException(
						"You can not repeat the number of an existing invoice, please change the Invoice No. and try again. ");
			}
			BeanDocumentosSDI bds = SAR_CDI_DAO.selectDocumentosSDI(id);
			fileName = "Invoice_" + condicion + "_" + bds.getVersionSDI() + ".pdf";
			BeanFactura factura = new BeanFactura();
			factura.setRutaArchivo(path + fileName);
			factura.setCondicionDePago(condicion);
			factura.setTieneMadera(isMadera);
			factura.setNombre(numeroFact);
			factura.setPaisOrigen(paisOrigen);
			factura.setId(id);
			factura.setVersionDocumento(versionDocumental);
			factura.setTieneOtros(esPrimerFactura == 1 ? true : false);
			GeneraDocumentos genera = new GeneraDocumentos();
			genera.generaFactura(factura, versionDocumental, id, condicion, condicion,path, fileName,(esPrimerFactura == 1 ? true : false));
		}catch(Exception e) {
			e.printStackTrace(); 
		}
		return path+fileName;
	}
		
}
