package com.srm.fungandrui.trafico.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.srm.fungandrui.facturacion.models.Facturacion;
import com.srm.fungandrui.trafico.dao.TraficoDao;
import com.srm.fungandrui.trafico.models.TraficoConsolVO;
import com.srm.fungandrui.trafico.service.TraficoService;
import com.truper.trafico.ConsolidacionFolioDto;

import lombok.extern.log4j.Log4j2;

@Log4j2
@Service
public class TraficoServiceImpl implements TraficoService {

	@Autowired
	TraficoDao traficoDao;

	@Override
	public TraficoConsolVO validaConsolidadosAceptados(String proveedor, String booking) throws Exception {
		String[] prov = proveedor.split("-");
		return traficoDao.validaConsolidadosAceptados(prov[0], booking);

	}

	@Override
	public ConsolidacionFolioDto validaEnviadoATrafico(Facturacion factura, String status) throws Exception {
		return traficoDao.validaEnviadoATrafico(factura, status);

	}

	@Override
	public ConsolidacionFolioDto enviadoATrafico(Facturacion factura) throws ClassNotFoundException, Exception {
		// TODO Auto-generated method stub
		return traficoDao.enviadoATrafico(factura);
	}

}
