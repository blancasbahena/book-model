package com.srm.fungandrui.pis.service.impl;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import com.itextpdf.text.pdf.codec.Base64;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;

import com.itextpdf.text.BadElementException;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Image;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfStamper;
import javax.servlet.ServletException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.itextpdf.text.BadElementException;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Image;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfStamper;
import com.itextpdf.text.pdf.codec.Base64;
import com.srm.fungandrui.expediente.service.ExpedienteService;
import com.srm.fungandrui.pis.dao.ProformaInvoiceDAO;
import com.srm.fungandrui.pis.dto.ProformaInvoiceDTO;
import com.srm.fungandrui.pis.dto.ProformaPdfDTO;
import com.srm.fungandrui.pis.dto.ProformaPisDetalleOrden;
import com.srm.fungandrui.pis.dto.RequestAuthWsPos;
import com.srm.fungandrui.pis.dto.RequestWsPos;
import com.srm.fungandrui.pis.dto.ResponseAuthWsPos;
import com.srm.fungandrui.pis.dto.ResponsePdfResponse;
import com.srm.fungandrui.pis.dto.ResponseWsPos;
import com.srm.fungandrui.pis.service.ProformaInvoiceService;
import com.srm.pli.bo.BeanContactoDocumentos;
import com.srm.pli.utils.FuncionesComunesPLI;
import com.srm.pli.utils.GeneraDocumentos;
import com.srm.pli.utils.PropertiesDb;
import com.truper.businessEntity.ImportacionesProveedoresBean;
import com.truper.expediente.DocumentoDTO;
import com.truper.expediente.ExpedientePerfilDTO;

import lombok.extern.log4j.Log4j2;

@Log4j2
@Service
public class ProformaInvoiceServiceImpl implements ProformaInvoiceService {

	private RestTemplate restTemplate = new RestTemplate();
	@Autowired
	private ExpedienteService expedienteService ;
	@Autowired
	private ProformaInvoiceDAO proformaInvoiceDAO;
	
	@Override
	public List<Map<String, Object>> obtenerPOs(RequestWsPos pos) {
		String URL_WSPOS = PropertiesDb.getInstance().getString("srm.truper.proforma");
		final String usuario  = PropertiesDb.getInstance().getString("srm.truper.wspos.user");
		final String password = PropertiesDb.getInstance().getString("srm.truper.wspos.pass");
		ResponseEntity<ResponseAuthWsPos> responseAuthen = authenticated(usuario, password,
				URL_WSPOS + "/authenticate");
		List<Map<String, Object>> posList = new ArrayList<>();
		if (responseAuthen.getStatusCode() == HttpStatus.OK) {
			if(responseAuthen.getBody().getTipoMensaje().equals("S")) {
				String token =  responseAuthen.getBody().getToken();
				posList =  getPos(token, URL_WSPOS + "/posPis", pos);
			}
		}
		return posList;
	}
	
	private ResponseEntity<ResponseAuthWsPos> authenticated(String user, String pass,
			final String url) {
		log.info("Authenticated usuario  :  "+user);
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
		RequestAuthWsPos userDTO=new RequestAuthWsPos();
		userDTO.setUsername(user);
		userDTO.setPassword(pass);
		HttpEntity<RequestAuthWsPos> request = new HttpEntity<>(userDTO, headers);
		return restTemplate.exchange(url, HttpMethod.POST, request,
				new ParameterizedTypeReference<ResponseAuthWsPos>() {});

	}
	
	private List<Map<String, Object>> getPos(String token, String url, RequestWsPos pos){
		HttpHeaders headers = new HttpHeaders();
		log.info("Listado de POs sin proforma,  token  :  "+ token);
		
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.set("Authorization", "Bearer " + token);
		headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
		HttpEntity<RequestWsPos> request = new HttpEntity<RequestWsPos>(pos, headers);
		log.info("url token  :  "+url);
		
		ResponseEntity<ResponseWsPos> respuesta = restTemplate.exchange(
				url, HttpMethod.POST, request,
				new ParameterizedTypeReference<ResponseWsPos>() {
				});
		List<Map<String, Object>> posJson = new ArrayList<>();
		if (respuesta.getStatusCode() == HttpStatus.OK) {
			log.info(respuesta.getBody().getData().toString());
			
			markOtherItems(respuesta.getBody().getData());
			
			obtenerEmpresa(respuesta.getBody().getData(), pos);
			
			posJson = poToJson (respuesta.getBody().getData());
		}
		return posJson;
	
	}
	
	private List<Map<String, Object>> poToJson(Map<String, List<ProformaPisDetalleOrden>> data) {
		
		List<Map<String, Object>> pos = new ArrayList<>();
		try {
			
			Map<String, List<ProformaPisDetalleOrden>> poGroupByPonumber = data.get("pos").stream().collect(Collectors.groupingBy(ProformaPisDetalleOrden::getNumeroOrden));
			for (Map.Entry<String, List<ProformaPisDetalleOrden>> entry: poGroupByPonumber.entrySet()) {
				Map<String, Object> po = new HashMap<>();
	            po.put("numeroOrden", entry.getKey());
	            po.put("ordenesAgrupadas", asignarCondiciones(entry.getValue()));
	            pos.add(po);
	        }
		} catch (Exception ef) {
			log.error("Problemas en " + ef.getMessage());
		}
		return pos;
	}

	private List<ProformaPisDetalleOrden>   asignarCondiciones(List<ProformaPisDetalleOrden> lista) {
		return lista.stream().map(m->asignaCondicion(m)).collect(Collectors.toList());
	}

	private ProformaPisDetalleOrden asignaCondicion(ProformaPisDetalleOrden dto) {
		try {
			String condPagoDesc = dto.getCondicionPago() +"|"+ 
					FuncionesComunesPLI.dameMapaCondicionPago(false).get(dto.getCondicionPago());
			dto.setCondicionPago(condPagoDesc);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return dto;
	}

	private void markOtherItems(Map<String, List<ProformaPisDetalleOrden>> data) {
		List<String>  OTHERS_ITEMS = Arrays.asList(PropertiesDb.getInstance().getStringTrim("cargaImportData.othersItems").split(","));  
		List<String>  FOCS = Arrays.asList(PropertiesDb.getInstance().getStringTrim("cargaImportData.focsItems").split(","));
		for (String codigo : OTHERS_ITEMS) {
			for (ProformaPisDetalleOrden po : data.get("pos")) {
				if (codigo.equals(po.getMaterial())) {
					po.setIsOtherItem(Boolean.TRUE);
				} else {
					po.setIsOtherItem(Boolean.FALSE);
				}
			}
		}
	}
	
	private void obtenerEmpresa(Map<String, List<ProformaPisDetalleOrden>> data, RequestWsPos pos) {
		
		String company = "";
		ImportacionesProveedoresBean consignee = new ImportacionesProveedoresBean();
		GeneraDocumentos generaDocumentos = new GeneraDocumentos();
		BeanContactoDocumentos documentos = new BeanContactoDocumentos();
		
		ImportacionesProveedoresBean  imBeanProv = FuncionesComunesPLI.getProveedor(pos.getClaveProveedor());

		for (ProformaPisDetalleOrden po : data.get("pos")) {
			try {
				if(consignee != null) {
					consignee = FuncionesComunesPLI.getProveedor(po.getCliente());
				}
				
				documentos = generaDocumentos.generaContactosDocumentos(imBeanProv, consignee);
				company = documentos.getNombre_shipper();
				po.setCompany(company);
			} catch (Exception e) {
				log.error("Ocurrio un error al intentar obtener la empresa {} : ", e.getMessage());
			}
		}

	}

	@Override
	public List<ProformaInvoiceDTO> obtenerListadoPos(String proveedor) throws ServletException {
		return proformaInvoiceDAO.dateProformasCreadas(proveedor);
	}

	@Override
	public String generarProformaPdf(ProformaPdfDTO proformaPdf) {
		String URL_WSCONFIRMACIONES = PropertiesDb.getInstance().getString("srm.truper.proforma.confirmaciones");
		HttpHeaders headers = new HttpHeaders();
		log.info("Se inicia el llamada a la generaci�n del Reporte en PDf para Proforma invoice {}",URL_WSCONFIRMACIONES  );		
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
		HttpEntity<ProformaPdfDTO> request = new HttpEntity<ProformaPdfDTO>(proformaPdf, headers);
		
		ResponseEntity<ResponsePdfResponse> respuesta = restTemplate.exchange(
				URL_WSCONFIRMACIONES + "/reports/generaProforma", HttpMethod.POST, request,
				new ParameterizedTypeReference<ResponsePdfResponse>() {
				});
		String archivo = null;
		if(respuesta != null && respuesta.getBody().getTipoMensaje().equalsIgnoreCase("S")){
			archivo = respuesta.getBody().getData().get("reporte");
		}
		return archivo;
	}
	@Override
	public String generarProformaPdfClone (String proveedor,String base64PDF,String fileNamePDF) {
		String rutaSalida = PropertiesDb.getInstance().getStringTrim("srm.truper.proforma.path");
		String pdfFirmado=null; 
		String imagenExpediente =getImagen(proveedor);
		try{
			pdfFirmado= createPdf2(base64PDF,rutaSalida,fileNamePDF,imagenExpediente);
			
		}catch(Exception e) {log.error("Problemas al firmar PDF",e);}
		return pdfFirmado;
	}
	private String getImagen(String proveedor) {
		String lbcontenedor="p"+proveedor;
		String responseDocumento = null;
		String path="p-"+proveedor;
		String idsTiposDeDocumentosAFiltrar=null;
		Integer profile=18;
		String factura=null;
		List<ExpedientePerfilDTO> data
		 	=expedienteService.geAllExpedientes(lbcontenedor, idsTiposDeDocumentosAFiltrar,profile,factura);
		for(ExpedientePerfilDTO dtoP:data){ 
			if(dtoP.getId().getIdTipoDocumento().getId().intValue() == 18 ){
				if(dtoP.getDocumentos()!=null) {
					for(DocumentoDTO  doc: dtoP.getDocumentos()) { 
						Long idDocumento = doc.getId();  
						responseDocumento = expedienteService.getDocumento(idDocumento, lbcontenedor,path);
					}
				}
			}
		}
		return responseDocumento;
	} 
	public String  createPdf2(String base64PDF, String rutaSalida,String fileSalida,String imageFileName) throws IOException, DocumentException
    {  
    	PdfReader reader = new PdfReader(Base64.decode(base64PDF));
        FileOutputStream fileOuS=new FileOutputStream(rutaSalida+fileSalida);
        PdfStamper stamper = new PdfStamper(reader,fileOuS);
        for (int i = 1; i <= reader.getNumberOfPages(); i++) {
            PdfContentByte pdfContentByte = stamper.getOverContent(i);
            //abajo-derecha
            //float x = reader.getPageSize(i).getWidth() -80;
            //float y = reader.getPageSize(i).getHeight() - 780;
            //abajo-izquierda
            float x = reader.getPageSize(i).getWidth() + 80;
            float y = reader.getPageSize(i).getHeight() - 750;
            pdfContentByte.addImage(getImage(imageFileName,x,y));
        }
        stamper.close();
        return java.util.Base64.getEncoder().encodeToString(loadFile(rutaSalida+fileSalida));
    }
    private static byte[] loadFile(String filePath) throws IOException {
    	File file = new File(filePath);
        byte[] bytes = new byte[(int) file.length()];
        FileInputStream fis = null;
        try { 
            fis = new FileInputStream(file); 
            fis.read(bytes);

        } finally {
            if (fis != null) {
                fis.close();
            }
        }
        return bytes;
    }
    private static Image getImage(String imageFileName,float x, float y) throws BadElementException, MalformedURLException, IOException {
    	byte[] decoded = org.apache.commons.codec.binary.Base64.decodeBase64(imageFileName.getBytes());
    	Image logo = Image.getInstance(decoded);  
        logo.setAlignment(Image.TOP);
        logo.scaleAbsolute(65, 65);
        logo.setAbsolutePosition(x,y);
        return logo;
    }
    @Override
	public void actualizaPosiciones1to2(int idPi) throws ServletException, ClassNotFoundException, SQLException {
		proformaInvoiceDAO.actualizaPosiciones1to2(idPi);
	}

}
