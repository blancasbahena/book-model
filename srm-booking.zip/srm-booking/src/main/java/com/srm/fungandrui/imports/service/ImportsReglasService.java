package com.srm.fungandrui.imports.service;

import com.google.gson.JsonObject;
import com.srm.pli.ws.vo.ResponseImportsVO;

public interface ImportsReglasService {
	
	
	ResponseImportsVO deleteRegla(final String producto) throws Exception;
	
	
	ResponseImportsVO getExistsInReglas(JsonObject codigos)  throws Exception;
	
	ResponseImportsVO getReglasProductos(JsonObject codigos)  throws Exception;
	
	
	ResponseImportsVO getReglasProducto(final Long producto)  throws Exception;
	
	ResponseImportsVO getReglasComercioProductos(JsonObject codigos) throws Exception;
	
	ResponseImportsVO getReglasTruperProductos(JsonObject codigos) throws Exception;

}
