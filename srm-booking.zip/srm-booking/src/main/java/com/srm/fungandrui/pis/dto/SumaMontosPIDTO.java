package com.srm.fungandrui.pis.dto;

import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@ToString
public class SumaMontosPIDTO {
	
	private BigDecimal totalCantidadEnviada;
	private BigDecimal totalMontoEnviado;

}
