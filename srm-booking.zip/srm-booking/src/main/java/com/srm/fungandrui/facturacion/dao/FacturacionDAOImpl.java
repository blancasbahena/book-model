package com.srm.fungandrui.facturacion.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import org.springframework.stereotype.Repository;

import com.srm.app.constantes.Mensajes;
import com.srm.fungandrui.facturacion.models.BeanFacturacion;
import com.srm.fungandrui.facturacion.models.CatCorreccionModel;
import com.srm.fungandrui.facturacion.models.CatStatusFactura;
import com.srm.fungandrui.facturacion.models.CatStatusFacturacion;
import com.srm.fungandrui.facturacion.models.CatStatusIncidencias;
import com.srm.fungandrui.facturacion.models.ControlEmbarqueModel;
import com.srm.fungandrui.facturacion.models.DataFactura;
import com.srm.fungandrui.facturacion.models.DataToSIFE;
import com.srm.fungandrui.facturacion.models.EntregaTraficoModel;
import com.srm.fungandrui.facturacion.models.Facturacion;
import com.srm.fungandrui.facturacion.models.FacturacionReporte;
import com.srm.fungandrui.facturacion.models.ItemFactura;
import com.srm.fungandrui.facturacion.models.ReporteSemanalIncidencias;
import com.srm.fungandrui.facturacion.queries.QueriresFacturacionSQL;
import com.srm.fungandrui.sc.model.FiltroEntregaTrafico;
import com.srm.pli.db.ConexionDB;
import com.srm.pli.utils.FuncionesComunesPLI;
import com.srm.pli.ws.vo.ResponseVO;
import com.truper.businessEntity.ImportacionesProveedoresBean;

import lombok.extern.log4j.Log4j2;

@Repository
@Log4j2
public class FacturacionDAOImpl implements IFacturacionDAO {



	private static int NUMBER_FIELDS= 10;
	
	private static final String SQLPO = "SELECT DISTINCT facs.id AS STATUS_ID,f.id,f.automatico as proceso_automatico_o_manual , "
			+ "f.fecha_hora_aprobacion as fecha_SDI , " + "f.am_pm as am_pm , "
			+ "f.numero_factura_pm as no_factura_pm , " + "fact.nombre as factura_proveedor , f.obs_reject_incidencia, "
			+ "f.monto_usd as monto_usd , " + "f.factura_fecha_emision as fecha_emision , "
			+ "f.facturista as facturista , " + "facs.descripcion as status_facturacion , f.factura_status as CODIGO_STATUS_FACTURA , "
			+ "ins.descripcion as type_insidencia , " + "f.comentarios_incidencias as comentarios , "
			+ "f.supplier_code as supplier , " + "s.eta as eta ,  " + "s.booking as number_booking , "
			+ "s.folio as folio , " + "s.BL as BL_Number , " + "f.pod as POD , " + "f.shipment_type as Shipment_Type , "
			+ "f.priority as priority," + "csdi.analista AS Analista_SDI, f.esSpecialties, "
			+ "(SELECT nombre from cdiPuertosOrigen where clave = s.puertoDescarga) as nombre_puerto_descarga, "
			+ "s.contenedor as contenedor "
			+ "from facturacion as f " + "left join cdiSar as s on f.sar = s.folio "
			+ "left join cdi_facturas as fact on fact.id = s.folio "
			+ "left join cat_incidencias as ins on f.incidencia = ins.id "
//			+ "inner join cat_factura_status as facs on f.factura_status = facs.id "
			+ "left join cat_areas as catarea on f.area_responsable_solucion = catarea.id "
			+ "left join cdiControlSDI as csdi on csdi.proveedor = s.proveedor and csdi.booking = s.booking "
			+ "left join cat_factura_status as facs on f.factura_status = facs.id and f.condicionPago = cf.condicionPago "
			+ "left join cdiUsers AS  users ON f.facturista = users.id  "
			+ " WHERE 1=1";
//			+ " f.factura_status IN (1,3,4,5,6,7) ";

	private static final String SQL2 = "SELECT DISTINCT (SELECT realName from cdiUsers  where userName = csdi.analista) AS ANALISTA_SDI, F.usuario_rechazo AS USUARIO_RECHAZO, "
			+ "F.factura_status as CODIGO_STATUS_FACTURA,F.id, "
			+ "F.fecha_rechazo AS FECHA_Y_HORA_RECHAZO_CONTABILIDAD , "
			+ "automatico AS PROCESO_MANUAL_AUTOMATICO ,sar , 	"
			+ "F.fecha_hora_aprobacion AS FECHA_Y_HORA_APROBACION_SDI ,  "
			+ "F.obs_reject_incidencia ,  "
			+ "F.numero_factura_pm as no_factura_pm,  "
			+ "F.facturista AS FACTURISTA ,  "
			+ "CATINCI.descripcion AS INCIDENCIA_FACTURA ,  "
			+ "F.comentarios_incidencias AS COMENTARIONS_INCIDENCIA , 	 "
			+ "F.supplier_code AS SUPPLIER , SAR.eta AS ETA , SAR.contenedor as contenedor ,	 "
			+ "SAR.booking AS BOOKING_NUMBER , F.esSpecialties, "
			+ "SAR.folio AS FOLIOS , SAR.BL AS BL_NUMBER ,  "
			+ "F.POD AS POD , F.shipment_type AS SHIPMENT_TYPE , "
			+ "F.priority AS PRIORITY ,	CATSTATUS.descripcion AS FACTURA_STATUS,CATAREA.descripcion  AS AREA_RESPONSABLE_DAR_SOLUCION, "
			+ "(select TOP(1) nombre from cdi_facturas where id = dsdi.id) AS FACTURA_PROVEEDOR, "
			+ "(SELECT nombre from cdiPuertosOrigen where clave = SAR.puertoDescarga) as nombre_puerto_descarga, "
			+ "users.realName as nombreFacturista, dsdi.id as idDoc "
			+ "FROM facturacion AS F 	INNER JOIN cdiSAR AS SAR ON F.sar = SAR.folio 	 "
			+ "left JOIN cat_incidencias AS CATINCI ON F.incidencia = CATINCI.ID  "
			+ "left JOIN cat_areas AS CATAREA ON CATINCI.area = CATAREA.id  "
			+ "left JOIN cdi_facturas AS CDIFAC ON F.sar = CDIFAC.id 	 "
			+ "left join cdiControlSDI as csdi on csdi.proveedor = SAR.proveedor and csdi.booking = SAR.booking  "
			+ "left join cdiDocumentosSDI as dsdi on SAR.booking = dsdi.booking "	
			+ "left JOIN cat_factura_status AS CATSTATUS ON   F.factura_status= CATSTATUS.id  "
			+ "left join cdiUsers AS  users ON F.facturista = users.id  "
			+ "where 1 = 1 "
			+ "AND dsdi.versionSDI = (SELECT max(cds.versionSDI) FROM cdiDocumentosSDI cds where SAR.booking = cds.booking) ";
		


	private  static final String SQL_DOC_FINALES = new StringBuilder("SELECT DISTINCT f.entregadoTrafico, f.factura_status, f.procesadoSIFE , f.urgente , f.obs_reject_incidencia , dsdi.total ,dsdi.subtotal ,dsdi.subtotalfocs , dsdi.subtotalothers, f.factura_status , f.para_envio_a_trafico, f.esSpecialties, ")
			.append(" f.observaciones_trafico,  ")
			.append(" f.analista_trafico,  ")
			.append(" f.customs_agent,  ")
			//.append(" det.po, ")
			.append(" f.id,  ")
			.append(" s.consolidado, ")
			.append(" s.fechaAprobadoSDI, ")
			.append(" s.booking,  ") 
			.append(" f.sar  , ") 
			.append(" s.BL , ")
			.append(" s.contenedor, ")
			.append(" (select TOP(1) nombre from cdi_facturas where id = dsdi.id) AS [fac_proveedor], ")
			.append(" s.etdFinal as etd , ")
			.append(" s.eta as eta, ") 
			.append(" f.condicionpago , ") 
			.append(" f.pod , ") 
			.append(" pod.nombre as puertoSalida, ") 
			.append(" CASE transporte ") 
			.append(" WHEN 1 THEN 'Fast Train' ") 
			.append(" WHEN 2 THEN 'Hauler' ") 
			.append(" WHEN 3 THEN 'Train' ") 
			.append(" END AS transporte, ") 
			.append(" CASE esAereo ") 
			.append(" WHEN 1 THEN 'AEREO' ") 
			.append(" WHEN 0 THEN 'BARCO' ") 
			.append(" END AS shipment_type ,") 
			//.append(" csdi.analista , ") 
			.append(" (SELECT realName from cdiUsers  where userName = csdi.analista) AS analista , ")
			.append(" nav.nombre as carrier, ")
			.append(" s.prioridad , ")
			.append(" f.numero_factura_pm,  csdi.proveedor , ")
			.append("(select count(DISTINCT  f.id ")
			.append(") from facturacion as f  ")
			.append(" left join cdiSar as s on f.sar = s.folio ")  
			.append(" left join cat_incidencias as ins on f.incidencia = ins.id  ")
			.append(" left join cat_areas as catarea on f.area_responsable_solucion = catarea.id  ")
			.append(" left join (select TOP 1  * from cdiDocumentosSDI) as dsdi on dsdi.booking = s.booking  ")
			.append(" left join cdiNavieras as nav on nav.clave = s.naviera  ")
			.append(" left join cdiPuertosOrigen as pod on pod.clave = s.puertoSalida ")  
			.append(" left join cat_factura_status as facs on f.factura_status= facs.id ")  
			.append("WHERE f.factura_status in  ($$STATUS$$)  and (f.urgente = 1  or f.urgente = 0) $$FILTRO1$$) as number, ")
			.append(" f.estatus_cuarenta_tres, f.estatus_diecinueve ")
			
			.append(" from facturacion as f ") 
			.append(" left join cdiSar as s on f.sar = s.folio ")
			.append(" left join (select TOP 1  * from cdiDocumentosSDI) as dsdi on dsdi.booking = s.booking ") 
			.append(" left join cat_incidencias as ins on f.incidencia = ins.id ") 
			.append(" left join cat_areas as catarea on f.area_responsable_solucion = catarea.id ")
			.append(" left join cdiControlSDI as csdi on csdi.proveedor = s.proveedor and csdi.booking = s.booking ") 
			.append(" left join cdiNavieras as nav on nav.clave = s.naviera ")
			.append(" left join cdiPuertosOrigen as pod on pod.clave = s.puertoSalida ")
			.append(" left join cat_factura_status as facs on f.factura_status = facs.id ") 
			//.append(" left join cdisardetalle as det ON  s.folio = det.folio   ") 
			.append(" WHERE f.factura_status in ($$STATUS$$)  and (f.urgente = 1  or f.urgente = 0) $$FILTRO2$$").toString();
	
 
	
	private  static final String  SQL_RECHAZO_TRAFICO = new StringBuilder("SELECT DISTINCT f.entregadoTrafico, f.procesadoSIFE , f.urgente , f.obs_reject_incidencia , dsdi.total ,dsdi.subtotal ,dsdi.subtotalfocs , dsdi.subtotalothers , f.factura_status , f.para_envio_a_trafico, f.esSpecialties, ")
			.append(" f.observaciones_trafico,  ")
			.append(" f.analista_trafico,  ")
			.append(" f.customs_agent,  ")
			//.append(" det.po, ")
			.append(" f.id,  ")
			.append(" s.consolidado, ")
			.append(" s.fechaAprobadoSDI, ")
			.append(" s.booking,  ") 
			.append(" f.sar  , ") 
			.append(" s.BL , ")
			.append(" s.contenedor, ")
			.append(" (select TOP(1) nombre from cdi_facturas where id = dsdi.id) AS [fac_proveedor], ")
			.append(" s.etdFinal as etd , ")
			.append(" s.eta as eta, ") 
			.append(" f.condicionpago , ") 
			.append(" f.pod , ") 
			.append(" pod.nombre as puertoSalida, ") 
			.append(" CASE transporte ") 
			.append(" WHEN 1 THEN 'Fast Train' ") 
			.append(" WHEN 2 THEN 'Hauler' ") 
			.append(" WHEN 3 THEN 'Train' ") 
			.append(" END AS transporte, ") 
			.append(" CASE esAereo ") 
			.append(" WHEN 1 THEN 'AEREO' ") 
			.append(" WHEN 0 THEN 'BARCO' ") 
			.append(" END AS shipment_type ,") 
			//.append(" csdi.analista , ") 
			.append(" (SELECT realName from cdiUsers  where userName = csdi.analista) AS analista , ")
			.append(" nav.nombre as carrier, ")
			.append(" s.prioridad , ")
			.append(" f.numero_factura_pm,  csdi.proveedor , ")
			.append("(select count(DISTINCT  f.id ")
			.append(") from facturacion as f  ")
			.append(" left join cdiSar as s on f.sar = s.folio ")  
			.append(" left join (select TOP 1  * from cdiDocumentosSDI) as dsdi on dsdi.booking = s.booking ") 
			.append(" left join cat_incidencias as ins on f.incidencia = ins.id  ")
			.append(" left join cat_areas as catarea on f.area_responsable_solucion = catarea.id  ")
			.append(" left join cdiControlSDI as csdi on csdi.proveedor = s.proveedor and csdi.booking = s.booking  ")
			.append(" left join cdiNavieras as nav on nav.clave = s.naviera  ")
			.append(" left join cdiPuertosOrigen as pod on pod.clave = s.puertoSalida ")  
			.append(" left join cat_factura_status as facs on f.factura_status= facs.id ")  
			.append("WHERE f.factura_status IN ( $$STATUS$$ )) as number,			")
			.append(" cce.tAnalist, cce.aa, cce.comment 			")
			.append(" from facturacion as f ") 
			.append(" left join cdiSar as s on f.sar = s.folio ")
			.append(" left join (select TOP 1  * from cdiDocumentosSDI) as dsdi on dsdi.booking = s.booking ") 
			.append(" left join cat_incidencias as ins on f.incidencia = ins.id ") 
			.append(" left join cat_areas as catarea on f.area_responsable_solucion = catarea.id ")
			.append(" left join cdiControlSDI as csdi on csdi.proveedor = s.proveedor and csdi.booking = s.booking ") 
			.append(" left join cdiNavieras as nav on nav.clave = s.naviera ")
			.append(" left join cdiPuertosOrigen as pod on pod.clave = s.puertoSalida ")
			.append(" left join cat_factura_status as facs on f.factura_status = facs.id ") 
			.append(" left join cdiControlEmbarque cce on cce.folio = f.sar   ") 
			.append(" WHERE f.factura_status IN ( $$STATUS$$ )").toString();
 
	
	
	private  static final String SQL_CONTROL_EMBARQUES = new StringBuilder("SELECT DISTINCT ")
			.append(" nav.nombre,  ")
			.append(" ce.shiiping_line, ")
			.append(" ce.buqueSalida, ")
			.append(" ce.shipper,  ") 
			.append(" s.booking, ") 
			.append(" s.BL , ")
			.append(" s.contenedor, ")
			.append(" (case when s.consolidado = 0 THEN 'F' WHEN s.consolidado = 1 THEN 'C' END) as consoFull, ")
			.append(" s.etdFinal as etd , ")
			.append(" s.eta as eta, ") 
			.append(" pod.nombre puertoSalida, ") 
			.append(" pod2.nombre puertoDescarga, ") 
			.append(" ce.lugarEntrega, ") 
			.append(" s.folio, ") 
			.append(" ce.instruccionBl, ") 
			.append("  ") 
			.append("  ") 
			.append(" tc.nombre tipoContenedor, ") 
			.append(" s.tipoProducto, ") 
			.append(" ce.estatusDocumento, ") 
			.append(" csdi.fechaAprobadoSDI, ") 
			.append(" (SELECT realName from cdiUsers  where userName = csdi.analista) AS analista , ")
			.append(" ce.tAnalist, ")
			.append(" ce.aa, ") 
			.append(" ce.comment, ") 
			.append(" ce.estatus, ") 
			.append("(select count(*) ")
			.append("from ")
			.append("(select distinct nav.nombre, ce.shiiping_line, ce.buqueSalida, ce.shipper, s.booking, s.BL, s.contenedor, ce.consoFull, s.etdFinal as td , s.eta as eta, s.puertoSalida, s.puertoDescarga, ce.lugarEntrega, s.folio, ce.instruccionBl, tc.nombre tipoContenedor, s.tipoProducto,   ce.estatusDocumento, csdi.fechaAprobadoSDI, csdi.analista, ce.estatus ")
			.append("from cdiSAR s  ").append("left join cdiNavieras as nav on nav.clave = s.naviera  ")
			.append("inner join cdiControlEmbarque ce on ce.folio = s.folio and ce.booking = s.booking ")
			.append("left join cdiControlSDI as csdi on csdi.proveedor = s.proveedor and csdi.booking = s.booking  ")
			.append("where (contenedor IS NOT NULL and s.contenedor <> '' and s.contenedor <> '-') and (s.booking IS NOT NULL and s.booking <> '') ")
			.append(") as number) as number ").append(" from cdiSAR s  ")
			.append("left join cdiNavieras as nav on nav.clave = s.naviera  ")
			.append("inner join cdiControlEmbarque ce on ce.folio = s.folio and ce.booking = s.booking ")
			.append("left join cdiControlSDI as csdi on csdi.proveedor = s.proveedor and csdi.booking = s.booking  ")
			.append("left join cdiContenedores tc on tc.clave = s.tipoContenedor ")
			.append("left join cdiPuertosOrigen as pod on pod.clave = s.puertoSalida ")
			.append("left join cdiPuertosOrigen as pod2 on pod2.clave = s.puertoDescarga ")
			.append("where (contenedor IS NOT NULL and s.contenedor <> '' and s.contenedor <> '-') and (s.booking IS NOT NULL and s.booking <> '') ").toString();

	private static final String SQL_CAT_CORRECCIONES = "select * from comext_cat_correccion";

	 
	private static final String QUERY_SAVE_FACTURACION = new StringBuilder("SELECT id, factura_status ")
			.append(" FROM facturacion ")
			.append(" WHERE sar = ? AND condicionPago = ? AND auxkey = ? ").toString();
	private  static final String QUERY_DATA_FACTURACION_BY_SAR = new StringBuilder("")
			.append("SELECT DISTINCT cs.folio, cs.proveedor, contenedor,BL,  cd.po, cd.posicion, cd.cantidadUnidadMedida, ")
			.append("cd.cantidad, cd.condicionPago, cs.prioridad, cd.material, esAereo , puertoDescarga, ")
			.append("cs.etd, cs.etdFinal, cs.booking,  ")
			.append("cf.nombre AS factura_proveedor,  ")
			.append("cf.paisorigen AS paisorigen ")
			.append("FROM cdiSAR cs ")
			.append("INNER join cdiSARDetalle cd on cs.folio = cd.folio ")
			.append("INNER join cdiDocumentosSDI as dsdi on cs.booking = dsdi.booking ")
			.append("INNER join cdi_facturas cf ON cf.id = dsdi.id ")
			.append("and cd.condicionPago = cf.condicionPago ")
			.append("and cf.id = dsdi.id ")
			.append("and dsdi.versionSDI = (select MAX(versionSDI) from cdiDocumentosSDI where booking = cs.booking and cs.proveedor = proveedor ) ")
			.append("and cf.versionDocumento = (SELECT max(versionDocumento) from cdi_facturas where id = dsdi.id) ")
			.append(" and cs.proveedor = dsdi.proveedor ")
			.append("WHERE cs.folio = " ).toString();
	private  static final String QUERY_FACTURACION_BY_SAR_CONDICION_PAGO=new StringBuilder("")
			.append("SELECT cs.folio, proveedor, contenedor,BL,  cd.po, cd.posicion, cd.cantidadUnidadMedida, ")
			.append("cd.cantidad, cd.condicionPago, cs.prioridad, cd.material, esAereo , puertoDescarga ")
			.append("FROM cdiSAR cs ")
			.append("inner join cdiSARDetalle cd on cs.folio = cd.folio ")
			.append("where cs.folio = ? AND cd.condicionPago = ?").toString();
	private  static final String  UPDATE_FACTURACION_PARCIAL=new StringBuilder("")
			.append("UPDATE FACTURACION ")
			.append("SET factura_status = ?, ")
			.append("numero_factura_pm = ?, ")
			.append("documentoSociedad = ?, ")
			.append("documentoEjercicio = ?, ")
			.append("documentoNumero = ? ")
			.append("WHERE sar = ? AND condicionPago = ? AND auxkey = ?").toString();
		private  static final String QUERY_UPDATE_INFO_TOTA_FACTURA=new StringBuilder("")
			.append("UPDATE FACTURACION ")
			.append("SET monto_usd = ?, ")
			.append("factura_fecha_emision = ?, ")
			.append("monto_moneda_original = ?, ")
			.append("factura_status = ? ,")
			.append("incidencia = ? ,")
			.append("comentarios_incidencias = ? ")
			.append("WHERE numero_factura_pm = ? ").toString();
		private  static final String QUERY_CANCELAR_FACTURA=new StringBuilder("")
			.append("SELECT f.id, factura_status, sar,supplier_code, f.condicionPago, csa.po, csa.posicion, cs.contenedor, ")
			.append("cs.BL, facturista, comentarios_incidencias ")
			.append("from facturacion f ")
			.append("LEFT join cdiSAR cs on cs.folio = f.sar ")
			.append("left join cdiSARDetalle csa on csa.folio = f.sar  and csa.condicionPago = f.condicionPago ")
			.append("where numero_factura_pm  = ? ").toString();
		private  static final String QUERY_DAT_FACTURACION_BY_FACTURA_PM=new StringBuilder("")
			.append("select sum(csd.cantidadUnidadMedida * csd.precioUnitario) as total, cs.booking, ")
			.append("cs.proveedor, cs.folio, csd.moneda, csd.centro, f.condicionPago,  ")
			.append("f.numero_factura_pm, f.pos, csd.cliente, f.id, ccc.diasPago,  ")
			.append("f.documentoSociedad, f.documentoEjercicio, f.documentoNumero, ")
			.append("cs.BL, cs.contenedor, f.factura_fecha_emision, cf.nombre as facturaProveedor ")
			.append("from facturacion f ")
			.append("inner join cdiSAR cs on cs.folio = f.sar ")
			.append("inner join cdiSARDetalle csd on csd.folio = f.sar and csd.condicionPago = f.condicionPago ")
			.append("inner join cdi_cat_condicionespago ccc on f.condicionPago = ccc.clave  ")
			.append("left join cdiDocumentosSDI as dsdi on cs.booking = dsdi.booking ")
			.append("left join cdi_facturas cf on dsdi.id  = cf.id  ")
			.append("and cf.condicionPago = csd.condicionPago ")
			.append("WHERE numero_factura_pm = ? AND sar = ? and dsdi.proveedor = cs.proveedor ")
			.append("GROUP by cs.booking, cs.proveedor, cs.folio, csd.moneda, csd.centro, f.id, ")
			.append("f.condicionPago, f.numero_factura_pm, f.pos, csd.cliente,ccc.diasPago, ")
			.append("f.documentoSociedad, f.documentoEjercicio, f.documentoNumero, ")
			.append("cs.BL, cs.contenedor, f.factura_fecha_emision, cf.nombre ").toString();
	private  static final String QUERY_FACTURACION_BY_ID=new StringBuilder("")
			.append("SELECT DISTINCT cpf.po, cpf .posicion, cpf.cantidad, cpf.facturaPM, ")
			.append("cs.proveedor, cs.contenedor, cs.BL, f.condicionPago, cs.prioridad, ")
			.append("cs.esAereo, cs.puertoDescarga, cs.folio, cs2.material,  ")
			.append("cs.etd, cs.etdFinal, ")
			.append("(select top(1) nombre from cdi_facturas where id = dsdi.id) AS factura_proveedor, ")
			.append("(select top(1) paisorigen from cdi_facturas where id = dsdi.id) AS paisorigen ")
			.append("FROM cdiPODetalleFacturacion cpf ")
			.append("INNER join facturacion f on f.id = idFacturacion ")
			.append("INNER join cdiSAR cs on f.sar = cs.folio ")
			.append("INNER join cdiSARDetalle cs2 on cpf.po = cs2.po AND cpf.posicion = cs2.posicion ")
			.append("LEFT join cdiDocumentosSDI as dsdi on cs.booking = dsdi.booking  and cs.proveedor =dsdi.proveedor  ")
			.append("WHERE idFacturacion = ? ").toString();

	private  static final String QUERY_MATERIAL_BYSAR_AND_FACTURA=new StringBuilder("")
			.append(" SELECT cs.material  FROM  facturacion f inner join cdiPODetalleFacturacion d on " )
			.append(" f.id = d.idFacturacion and f.numero_factura_pm = d.facturaPM " )
			.append(" inner join  cdiSARDetalle cs on cs.folio = f.sar and cs.po = d.po and cs.posicion = d.posicion " )
			.append(" where f.sar = ? and f.numero_factura_pm =? " ).toString();
	private  static final String QUERY_FACTURACION_BY_ID_FACTURACION=new StringBuilder("")
			.append("select sum(csd.cantidadUnidadMedida * csd.precioUnitario) as total, cs.booking, ")
			.append("cs.proveedor, cs.folio, csd.moneda, csd.centro, f.condicionPago,  ")
			.append("f.numero_factura_pm, f.pos, csd.cliente, f.id, ccc.diasPago,  ")
			.append("f.documentoSociedad, f.documentoEjercicio, f.documentoNumero, ")
			.append("cs.BL, cs.contenedor, f.factura_fecha_emision, cf.nombre as facturaProveedor ")
			.append("from facturacion f ")
			.append("inner join cdiSAR cs on cs.folio = f.sar ")
			.append("inner join cdiSARDetalle csd on csd.folio = f.sar and csd.condicionPago = f.condicionPago ")
			.append("inner join cdi_cat_condicionespago ccc on f.condicionPago = ccc.clave  ")
			.append("left join cdiDocumentosSDI as dsdi on cs.booking = dsdi.booking ")
			.append("left join cdi_facturas cf on dsdi.id  = cf.id  ")
			.append("WHERE f.id = ? AND f.sar = ? and dsdi.proveedor = cs.proveedor ")
			.append("GROUP by cs.booking, cs.proveedor, cs.folio, csd.moneda, csd.centro, f.id, ")
			.append("f.condicionPago, f.numero_factura_pm, f.pos, csd.cliente,ccc.diasPago, ")
			.append("f.documentoSociedad, f.documentoEjercicio, f.documentoNumero, ")
			.append("cs.BL, cs.contenedor, f.factura_fecha_emision, cf.nombre ").toString();
	private  static final String QUERY_GET_FACTURA_BY_SAR=new StringBuilder("")
			.append(" SELECT DISTINCT f.id, f.numero_factura_pm, f.factura_status, f.sar, cfs.descripcion as status ")
			.append(" FROM facturacion f (NOLOCK)" )
			.append(" INNER JOIN cat_factura_status cfs (NOLOCK) ON f.factura_status = cfs.id " ).toString();
	
	
	private static final String QUERY_FACTURACION=new StringBuilder("")
			.append("INSERT INTO facturacion ( automatico, supplier_code, ")
			.append("sar, priority, factura_status, condicionPago, pos, ")
			.append("am_pm, fecha_hora_aprobacion,urgente, auxkey, ")
			.append("pod, shipment_type,esSpecialties, posSecundaria ) ")
			.append("VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)").toString();
	
	
	
	private static final String  UPDATE_FACTURACION = new StringBuilder("")
			.append("UPDATE FACTURACION ")
			.append("SET factura_status = ?, ")
			.append("pos = ?, ")
			.append("am_pm = ?, ")
			.append("fecha_hora_aprobacion = ?, ")
			.append("pod = ?, ")
			.append("shipment_type = ?, ")
			.append("urgente = ?, ")
			.append("esSpecialties = ?, ")
			.append("comentarios_incidencias = ?, ")
			.append("posSecundaria = ? ")
			.append("WHERE sar = ? AND condicionPago = ? AND auxkey = ?").toString();
	
	private static final String INSERT_DETALLE_FACTURACION= new StringBuffer("")
			.append("INSERT INTO cdiPODetalleFacturacion (po,posicion,cantidad, ")
			.append("idFacturacion) ")
			.append("VALUES (?,?,?,?)").toString();
	
	private static final String QUERY_CONSULTA_FACTURACION = new StringBuilder("")
			.append("SELECT documentoNumero " )
			.append("FROM facturacion " )
			.append("WHERE sar = ? and numero_factura_pm = ?" ).toString();
	
	@Override
public List<Facturacion> listarFacturacion() {
		List<Facturacion> listFacturacion = new ArrayList<Facturacion>();
		Connection conn = null;

		try {
			conn = ConexionDB.dameConexion();
			try (PreparedStatement pstmt = conn.prepareStatement(QueriresFacturacionSQL.SQL_LISTA_FACTURACION)) {
				ResultSet rs = pstmt.executeQuery();
				while (rs.next()) {
					Facturacion facturacion = new Facturacion();
					// Id
					facturacion.setId(rs.getLong("id"));

					// Proceso Automatico o /Manual
					facturacion.setAutomatico(rs.getBoolean("proceso_automatico_o_manual"));
					// Fecha y Hora Aprobacion SDI
					facturacion.setFechaHoraAprobacionSDI(rs.getString("fecha_SDI"));
					// AM/PM
					facturacion.setAmpm(rs.getString("am_pm"));
					// No. Factura PM
					facturacion.setNoFacturaPM(rs.getString("no_factura_pm"));
					// #Factura Proveedor --
					facturacion.setFacturaProvedor(rs.getString("factura_proveedor"));
					// Monto USD
					facturacion.setMontoUSD(rs.getString("monto_usd"));
					// Fecha Emision
					facturacion.setFechaEmision(rs.getString("fecha_emision"));
					// Facturista
					facturacion.setFacturista(rs.getString("facturista"));
					// STATUS FALTA STATUS
					facturacion.setStatus(rs.getString("status_facturacion"));
					// Incidencias en Factura
					facturacion.setIncidenciasEnFacturas(rs.getString("type_insidencia"));
					// Comentarios
					facturacion.setComentarios(rs.getString("comentarios"));
					// Supplier
					facturacion.setSupplier(rs.getString("supplier"));
					// ETA
					facturacion.setEta(rs.getString("eta"));
					// Booking Number
					facturacion.setBooking(rs.getString("number_booking"));
					// Folios
					facturacion.setFolio(rs.getString("folio"));
					// BL Number
					facturacion.setBlNumber(rs.getString("BL_Number"));
					// POD
					facturacion.setPod(rs.getString("POD"));
					// Shipment_Type
					facturacion.setShipmentType(rs.getString("Shipment_Type"));
					// Priority
					facturacion.setPriority(rs.getString("priority"));
					// SDI Analyst
				facturacion.setAnalyst(rs.getString("Analista_SDI"));
					// Analista_SDI
				facturacion.setContainer(rs.getString("contenedor"));
				// PO
					facturacion.setPo(rs.getString("pod"));
					
					
					//ImportacionesProveedoresBean bean_prov_client = FuncionesComunesPLI.getProveedor(facturacion.getSupplier());
					
					//facturacion.setNombreProveedor(bean_prov_client.getNombreProveedor());
					
					facturacion.setNombreProveedor("");
					if( facturacion.getSupplier() != null && !facturacion.getSupplier().equals("") &&  !facturacion.getSupplier().isEmpty() ) {
						ImportacionesProveedoresBean bean_prov_client = FuncionesComunesPLI.getProveedor(facturacion.getSupplier());
						
						if( bean_prov_client != null &&  bean_prov_client.getNombreProveedor() != null ) {
							facturacion.setNombreProveedor(bean_prov_client.getNombreProveedor());
						}
					}
					
					
					listFacturacion.add(facturacion);
				}
				pstmt.close();
				rs.close();
			} catch (SQLException e) {
				try {
					ConexionDB.renuevaConexion(conn);
				} catch (Exception ex) {
					log.error(ex.getMessage(), ex);
				}
				log.error(e.getMessage(), e);
			}
		} catch (Exception e) {
			try {
				ConexionDB.devuelveConexion(conn);
			} catch (Exception ex) {
				log.error(ex.getMessage().toString(), ex);
			}
			log.error(e.getMessage(), e);
		} finally {
			try {
				ConexionDB.devuelveConexion(conn);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
	}
		return listFacturacion;
	}

	@Override
	public List<Facturacion> getByFilterDAO(Facturacion filtro) {
//		FacturacionFilter filter = new FacturacionFilter();
		List<Facturacion> listFacturacion = new ArrayList<Facturacion>();
		Connection conn = null;
		ResponseVO respuesta = new ResponseVO();

		if (filtro.getPo() != null && !filtro.getPo().equals("")) {
			// EJECUTA SQL CON PO
			StringBuilder queryPO = new StringBuilder(SQLPO);

			try {
				// 1.- folio--> tipo entero
				if (filtro.getFolio() != null && !filtro.getFolio().equals("")) {
					queryPO.append(" AND s.folio=  ");
					queryPO.append(filtro.getFolio());
				}
				// 2.- supplier
				if (filtro.getSupplier() != null && !filtro.getSupplier().equals("")) {
					queryPO.append(" AND s.proveedor = '");
					queryPO.append(filtro.getSupplier()).append("'");
				}
				// 3 .- priority
				if (filtro.getPriority() != null && !filtro.getPriority().equals("")
						&& !filtro.getPriority().equals("-1")) {
					queryPO.append(" AND priority=  ");
					queryPO.append(filtro.getPriority());
				}
				// 4.- po
				if (filtro.getPo() != null && !filtro.getPo().equals("")) {
					queryPO.append(" AND (SELECT TOP 1 po FROM cdiSARDetalle WHERE folio = s.folio AND po = '");
					queryPO.append(filtro.getPo()).append("'");
					queryPO.append(" ) = '");
					queryPO.append(filtro.getPo()).append("'");
				}
				// 5.- carrier
				if (filtro.getCarrier() != null && !filtro.getCarrier().equals("")
						&& !filtro.getCarrier().equals("-1")) {
					queryPO.append(" AND s.naviera=  ");
					queryPO.append(filtro.getCarrier());
				}
				// 6 .- BL Number
				if (filtro.getBlNumber() != null && !filtro.getBlNumber().equals("")) {
					queryPO.append(" AND s.BL = '");
					queryPO.append(filtro.getBlNumber()).append("'");
				}
				// 7 .- Analyst
				if (filtro.getAnalyst() != null && !filtro.getAnalyst().equals("")
						&& !filtro.getAnalyst().equals("-1")) {
					queryPO.append(" AND analys=  '");
					queryPO.append(filtro.getAnalyst()).append("'");
				}
				// 8.- POD
				if (filtro.getPod() != null && !filtro.getPod().equals("") && !filtro.getPod().equals("-1")) {
					queryPO.append(" AND POD=  '");
					queryPO.append(filtro.getPod()).append("'");
				}
				// 9.- Booking
				if (filtro.getBooking() != null && !filtro.getBooking().equals("")) {
					queryPO.append(" AND s.booking =   '");
					queryPO.append(filtro.getBooking()).append("'");
				}
				// 10 .- Invoice Number
				if (filtro.getInvoiceNumber() != null && !filtro.getInvoiceNumber().equals("")) {
					queryPO.append(" AND f.numero_factura_pm= '");
					queryPO.append(filtro.getInvoiceNumber()).append("'");
				}
				// 11 .- Container
				if (filtro.getContainer() != null && !filtro.getContainer().equals("")) {
					queryPO.append(" AND contenedor = '");
					queryPO.append(filtro.getContainer()).append("'");
				} // ETA
				if (filtro.getEtaFrom() != null && !filtro.getEtaFrom().equals("")) {
					queryPO.append(" AND s.eta  BETWEEN ");
					queryPO.append(filtro.getEtaFrom().toString().replaceAll("/", ""));
				}
				if (filtro.getEtaTo() != null && !filtro.getEtaTo().equals("")) {
					queryPO.append(" AND ");
					queryPO.append(filtro.getEtaTo().replaceAll("/", ""));
				}

				if (filtro.getCodigoEstatusFactura() != null && !filtro.getCodigoEstatusFactura().equals("")
						&& !filtro.getCodigoEstatusFactura().equals("-1")) {
					queryPO.append(" AND f.factura_status=  '");
					queryPO.append(filtro.getCodigoEstatusFactura()).append("'");
				} else {
					queryPO.append(" AND f.factura_status IN (1,3,5,6,8)");
					queryPO.append(" ORDER BY  fecha_SDI  ASC ");
				}

				conn = ConexionDB.dameConexion();  
				try (PreparedStatement pstmt = conn.prepareStatement(queryPO.toString())) {
					
					ResultSet rs = pstmt.executeQuery();
					while (rs.next()) {
						Facturacion facturacion = new Facturacion();
						// ID_STATUS
						facturacion.setStatusId(rs.getInt("STATUS_ID"));

						// Id
						facturacion.setId(rs.getLong("id"));
						// PROCESO MANUAL/AUTOMATICO
						facturacion.setAutomatico(rs.getBoolean("proceso_automatico_o_manual"));
						// AREA_QUE_SOLICITA_RECHAZO
						facturacion.setFechaHoraAprobacionSDI(cambiarFechaSDI(rs.getString("fecha_SDI")));
						// am_pm
						facturacion.setAmpm(rs.getString("am_pm").toUpperCase());
						// No_Factura_pm
						facturacion.setNoFacturaPM(rs.getString("no_factura_pm"));
						// FACTURA PROVEEDOR
						facturacion.setFacturaProvedor(rs.getString("factura_proveedor"));
						// MONTO_USD
						facturacion.setMontoUSD(validaMonto(rs.getString("monto_usd")));
						// FECHA_EMISION
						facturacion.setFechaEmision(rs.getString("fecha_emision"));
						// FACTURISTA
						facturacion.setFacturista(rs.getString("facturista"));
						//facturacion.setRealName(rs.getString("nombreFacturista"));
						// STATUS_FACTURACION
						facturacion.setStatus(rs.getString("status_facturacion"));
						// TYPE_INSIDENCIA
						facturacion.setIncidenciasEnFacturas(rs.getString("type_insidencia"));
						// COMENTARIOAS
						facturacion.setComentarios(rs.getString("comentarios"));
						// SUPPLIER
						facturacion.setSupplier(rs.getString("supplier"));
						// ETA
						facturacion.setEta(cambiarFecha(rs.getString("eta")));
						// NUMBER BOOKING
						facturacion.setBooking(rs.getString("number_booking"));
						// folio
						facturacion.setFolio(rs.getString("folio"));
						// BL_NUMBER
						facturacion.setBlNumber(rs.getString("BL_Number"));
						// POD
						facturacion.setPod(rs.getString("POD"));
						// SHIPMENT_TYPE
						facturacion.setShipmentType(rs.getString("Shipment_Type"));
						// PRIORITY
						facturacion.setPriority(rs.getString("priority"));
						// ANALISTA_SDI
						facturacion.setAnalyst(rs.getString("Analista_SDI"));
						// CONTENEDOR
						//facturacion.setContainer(rs.getString("contenedor"));
						
						facturacion.setCodigoEstatusFactura(rs.getString("CODIGO_STATUS_FACTURA"));
						
						facturacion.setEsSpecialties( rs.getBoolean("esSpecialties") );
						
						facturacion.setObs_reject_incidencia(rs.getString("obs_reject_incidencia"));
						//ImportacionesProveedoresBean bean_prov_client = FuncionesComunesPLI.getProveedor(facturacion.getSupplier());

						//facturacion.setNombreProveedor(bean_prov_client.getNombreProveedor());
						
						facturacion.setNombreProveedor("");
						if( facturacion.getSupplier() != null && !facturacion.getSupplier().equals("") &&  !facturacion.getSupplier().isEmpty() ) {
							ImportacionesProveedoresBean bean_prov_client = FuncionesComunesPLI.getProveedor(facturacion.getSupplier());
							
							if( bean_prov_client != null &&  bean_prov_client.getNombreProveedor() != null ) {
								facturacion.setNombreProveedor(bean_prov_client.getNombreProveedor());
							}
						}

						listFacturacion.add(facturacion);
					}
				} catch (SQLException e) {
					try {
						ConexionDB.renuevaConexion(conn);
					} catch (Exception ex) {
						log.error(ex.getMessage(), ex);
					}
					log.error(e.getMessage(), e);
				}

			} catch (Exception e) {
				try {
					ConexionDB.devuelveConexion(conn);
				} catch (Exception ex) {
					log.error(ex.getMessage(), ex);
				}
				log.error(e.getMessage(), e);
			} finally {
				try {
					ConexionDB.devuelveConexion(conn);
				} catch (Exception sqlEx2) {
					log.error(sqlEx2.getMessage(), sqlEx2);
				}
			}

		} else {
			// Sin PO

			StringBuilder query = new StringBuilder(QueriresFacturacionSQL.SQL_LISTA_FACTURACION);

			try {
				// 1.- folio--> tipo entero
				if (filtro.getFolio() != null && !filtro.getFolio().equals("")) {
					query.append(" AND s.folio=  ");
					query.append(filtro.getFolio());
				}
				// 2.- supplier
				if (filtro.getSupplier() != null && !filtro.getSupplier().equals("")) {
					query.append(" AND s.proveedor = '");
					query.append(filtro.getSupplier()).append("'");
				}
				// 3 .- priority
				if (filtro.getPriority() != null && !filtro.getPriority().equals("")
						&& !filtro.getPriority().equals("-1")) {
					query.append(" AND priority=  ");
					query.append(filtro.getPriority());
				}
				// 4.- po
				if (filtro.getPo() != null && !filtro.getPo().equals("")) {
					query.append(" AND sd.po=  '");
					query.append(filtro.getPo()).append("'");
				}
				// 5.- carrier
				if (filtro.getCarrier() != null && !filtro.getCarrier().equals("")
						&& !filtro.getCarrier().equals("-1")) {
					query.append(" AND s.naviera=  ");
					query.append(filtro.getCarrier());
				}
				// 6 .- BL Number
				if (filtro.getBlNumber() != null && !filtro.getBlNumber().equals("")) {
					query.append(" AND s.BL = '");
					query.append(filtro.getBlNumber()).append("'");
				}
				// 7 .- Analyst
				if (filtro.getAnalyst() != null && !filtro.getAnalyst().equals("")
						&& !filtro.getAnalyst().equals("-1")) {
					query.append(" AND analys=  '");
					query.append(filtro.getAnalyst()).append("'");
				}
				// 8.- POD
				if (filtro.getPod() != null && !filtro.getPod().equals("") && !filtro.getPod().equals("-1")) {
					query.append(" AND POD=  '");
					query.append(filtro.getPod()).append("'");
				}
				// 9.- Booking
				if (filtro.getBooking() != null && !filtro.getBooking().equals("")) {
					query.append(" AND s.booking =   '");
					query.append(filtro.getBooking()).append("'");
				}
				// 10 .- Invoice Number
				if (filtro.getInvoiceNumber() != null && !filtro.getInvoiceNumber().equals("")) {
					query.append(" AND f.numero_factura_pm=  '");
					query.append(filtro.getInvoiceNumber()).append("'");
				}
				// 11 .- Container
				if (filtro.getContainer() != null && !filtro.getContainer().equals("")) {
					query.append(" AND contenedor = '");
					query.append(filtro.getContainer()).append("'");
				} // ETA
				if (filtro.getEtaFrom() != null && !filtro.getEtaFrom().equals("")) {
					query.append(" AND s.eta  BETWEEN ");
					query.append(filtro.getEtaFrom().toString().replaceAll("/", ""));
				}
				if (filtro.getEtaTo() != null && !filtro.getEtaTo().equals("")) {
					query.append(" AND ");
					query.append(filtro.getEtaTo().replaceAll("/", ""));
				}
				if (filtro.getCarrier() != null && !filtro.getCarrier().equals("")
						&& !filtro.getCarrier().equals("-1")) {
					query.append(" AND s.naviera=  ");
					query.append(filtro.getCarrier());
				}

				if (filtro.getCodigoEstatusFactura() != null && !filtro.getCodigoEstatusFactura().equals("")
						&& !filtro.getCodigoEstatusFactura().equals("-1")) {
					query.append(" AND f.factura_status=  ");
					query.append(filtro.getCodigoEstatusFactura());
					// query.append(filtro.getCodigoEstatusFactura()).append("'");
				} else {
					query.append(" AND f.factura_status IN (1,3,4,5,6,7)");
					query.append(" ORDER BY  fecha_SDI  ASC ");
				}

				conn = ConexionDB.dameConexion();
				try (PreparedStatement pstmt = conn.prepareStatement(query.toString())) {
					ResultSet rs = pstmt.executeQuery();
				
					while (rs.next()) {
						Facturacion facturacion = new Facturacion();
						// ID_STATUS
						facturacion.setStatusId(rs.getInt("STATUS_ID"));

						// Id
						facturacion.setId(rs.getLong("id"));
						// PROCESO MANUAL/AUTOMATICO
						facturacion.setAutomatico(rs.getBoolean("proceso_automatico_o_manual"));
						// AREA_QUE_SOLICITA_RECHAZO
						facturacion.setFechaHoraAprobacionSDI(cambiarFechaSDI(rs.getString("fecha_SDI")));
						// am_pm
						facturacion.setAmpm(rs.getString("am_pm").toUpperCase());
						// No_Factura_pm
						facturacion.setNoFacturaPM(rs.getString("no_factura_pm"));
						// FACTURA PROVEEDOR
						facturacion.setFacturaProvedor(rs.getString("factura_proveedor"));
						// MONTO_USD
						facturacion.setMontoUSD(validaMonto(rs.getString("monto_usd")));
						// FECHA_EMISION
						facturacion.setFechaEmision(rs.getString("fecha_emision"));
						// FACTURISTA
						facturacion.setFacturista(rs.getString("facturista"));
						//facturacion.setRealName(rs.getString("nombreFacturista"));
						// STATUS_FACTURACION
						facturacion.setStatus(rs.getString("status_facturacion"));
						// TYPE_INSIDENCIA
						facturacion.setIncidenciasEnFacturas(rs.getString("type_insidencia"));
						// COMENTARIOAS
						facturacion.setComentarios(rs.getString("comentarios"));
						// SUPPLIER
						facturacion.setSupplier(rs.getString("supplier"));
						// ETA
						facturacion.setEta(cambiarFecha(rs.getString("eta")));
						// NUMBER BOOKING
						facturacion.setBooking(rs.getString("number_booking"));
						// folio
						facturacion.setFolio(rs.getString("folio"));
						// BL_NUMBER
						facturacion.setBlNumber(rs.getString("BL_Number"));
						// POD
						facturacion.setNombre_puerto_descarga(rs.getString("nombre_puerto_descarga"));
						facturacion.setPod(rs.getString("POD"));
						// SHIPMENT_TYPE
						facturacion.setShipmentType(rs.getString("Shipment_Type"));
						// PRIORITY
						facturacion.setPriority(rs.getString("priority"));
						// ANALISTA_SDI
						facturacion.setAnalyst(rs.getString("Analista_SDI"));
						// CONTENEDOR
						facturacion.setContainer(rs.getString("contenedor"));
						
						
						//ImportacionesProveedoresBean bean_prov_client = FuncionesComunesPLI.getProveedor(facturacion.getSupplier());

						//facturacion.setNombreProveedor(bean_prov_client.getNombreProveedor());
						facturacion.setNombreProveedor("");
						if( facturacion.getSupplier() != null && !facturacion.getSupplier().equals("") &&  !facturacion.getSupplier().isEmpty() ) {
							ImportacionesProveedoresBean bean_prov_client = FuncionesComunesPLI.getProveedor(facturacion.getSupplier());
							
							if( bean_prov_client != null &&  bean_prov_client.getNombreProveedor() != null ) {
								facturacion.setNombreProveedor(bean_prov_client.getNombreProveedor());
							}
						}
						
						
						listFacturacion.add(facturacion);

					}
				} catch (SQLException e) {
					try {
						ConexionDB.renuevaConexion(conn);
					} catch (Exception ex) {
						log.error(ex.getMessage(), ex);
						respuesta.setMensaje(Mensajes.MSG_ERROR.getMensaje());
					}
					log.error(e.getMessage(), e);
					respuesta.setMensaje(Mensajes.MSG_ERROR.getMensaje());
				}

			} catch (Exception e) {
				try {
					ConexionDB.devuelveConexion(conn);
					
					respuesta.setMensaje(Mensajes.MSG_ERROR.getMensaje());
					respuesta.setTipoMensaje(Mensajes.TIPO_ERROR.getMensaje());
					listFacturacion.removeAll(listFacturacion);
					return listFacturacion;
				} catch (Exception ex) {
					log.error(ex.getMessage(), ex);
					respuesta.setMensaje(Mensajes.MSG_ERROR.getMensaje());
				}
				log.error(e.getMessage(), e);
				respuesta.setMensaje(Mensajes.MSG_ERROR.getMensaje());
			} finally {
				try {
					ConexionDB.devuelveConexion(conn);
				} catch (Exception sqlEx2) {
					log.error(sqlEx2.getMessage(), sqlEx2);
					respuesta.setMensaje(Mensajes.MSG_ERROR.getMensaje());
				}
			}

		}
		
		return listFacturacion;

	}
	
	
	public String validaMonto (String montoUSD) {
		String montoUSDTemp =montoUSD;
		if (montoUSD== null ||  montoUSD.isEmpty()  || montoUSD.equals("")) 
		 montoUSDTemp = "0.0";
		return montoUSDTemp;	
	}
	
	public String hastaDecimal(String montoUSD) {
		StringBuilder montoTemp = new StringBuilder();
		try {
			if (montoUSD != null) {
				montoTemp.append(montoUSD.substring(0, 3));
			
			}else {
				montoTemp.append("0.0");
			}
		} catch (Exception e) {
			log.info(e.getMessage(),e);
		}
		
		return montoTemp.toString();
	}

	public String cambiarFecha(String fechaEta) {
		StringBuilder fechaTmpBuilder = new StringBuilder();
		if( fechaEta != null && fechaEta.length() >= 8 ) {
			fechaTmpBuilder.append(fechaEta.substring(0,4));
			fechaTmpBuilder.append("-");
			fechaTmpBuilder.append(fechaEta.substring(4,6));
			fechaTmpBuilder.append("-");
			fechaTmpBuilder.append(fechaEta.substring(6,8));
		}else {
			return "";
		}
		return fechaTmpBuilder.toString();
	}
	
	public String cambiarFechaSDI(String fechaSDI) {
		StringBuilder fechaTmpBuilder = new StringBuilder();
		fechaTmpBuilder.append(fechaSDI == null ? "" : fechaSDI.substring(0,19));
		return fechaTmpBuilder.toString();
	}
	// RECHAZADOS LISTAR



	@Override
	public Long saveFacturaPeticion(Facturacion factura) {
		Long lastId = null;
		Connection conn = null;
		Facturacion facAux = null;
		try {
			
			conn = ConexionDB.dameConexion(); 

			PreparedStatement pstmt = conn.prepareStatement(QUERY_SAVE_FACTURACION);
			pstmt.setInt(1, Integer.parseInt(factura.getFolio()));
			pstmt.setString(2, factura.getCondicionPago());
			pstmt.setString(3, factura.getAuxkey());
			ResultSet rs = pstmt.executeQuery();

			while (rs.next()) {
				facAux = new Facturacion();
				facAux.setId((Long) rs.getLong("id"));
				facAux.setCodigoEstatusFactura(rs.getInt("factura_status") + "");
				
				lastId = rs.getLong("id");

			}
			pstmt.close();
			ConexionDB.devuelveConexion(conn);

			if (facAux != null) {

				conn = ConexionDB.dameConexion();
			
				PreparedStatement stmt = conn.prepareStatement(UPDATE_FACTURACION);
				stmt.setInt(1, Integer.parseInt(factura.getCodigoEstatusFactura()));
				stmt.setString(2, factura.getPo());
				stmt.setString(3, factura.getAmpm());
				stmt.setString(4, factura.getFechaHoraAprobacionSDI());
				stmt.setString(5, factura.getPod());
				stmt.setString(6, factura.getShipmentType());
				stmt.setBoolean(7, factura.getUrgente());
				stmt.setString(8, factura.getComentarios());
				stmt.setBoolean(9,factura.getEsSpecialties());
				stmt.setString(10, factura.getPosSecundaria());
				stmt.setString(11, factura.getFolio());
				stmt.setString(12, factura.getCondicionPago());
				stmt.setString(13, factura.getAuxkey());
				
				stmt.executeUpdate();
				stmt.close();
				String StatusRechazo = CatStatusFactura.DOCUMENTOS_RECHAZADOS.getId().toString();
				if(  StatusRechazo.equals(facAux.getCodigoEstatusFactura()) )
					saveDataToPODetalleFacturacion(factura.getListItems(),lastId);
				
			} else {
				conn = ConexionDB.dameConexion();
				PreparedStatement stmt = conn.prepareStatement(QUERY_FACTURACION,Statement.RETURN_GENERATED_KEYS);
				stmt.setBoolean(1, factura.getAutomatico());
				stmt.setString(2, factura.getSupplier());
				stmt.setString(3, factura.getFolio());
				stmt.setString(4, factura.getPriority());
				stmt.setInt(5, Integer.parseInt(factura.getCodigoEstatusFactura()));
				stmt.setString(6, factura.getCondicionPago());
				stmt.setString(7, factura.getPo());
				stmt.setString(8, factura.getAmpm());
				stmt.setString(9, factura.getFechaHoraAprobacionSDI());
				stmt.setBoolean(10, factura.getUrgente());
				stmt.setString(11, factura.getAuxkey());
				stmt.setString(12, factura.getPod());
				stmt.setString(13, factura.getShipmentType());
				stmt.setBoolean(14, factura.getEsSpecialties());
				stmt.setString(15, factura.getPosSecundaria());
				
				stmt.executeUpdate();
				
				ResultSet generatedKey = stmt.getGeneratedKeys();
				
				if( generatedKey.next() ) {
					lastId =  generatedKey.getLong(1);
				}
				
				stmt.close();
				
				if( lastId != null )
					saveDataToPODetalleFacturacion(factura.getListItems(),lastId);
			}

		} catch (ClassNotFoundException e) {
			log.info(e.getMessage(),e);
			e.printStackTrace();
		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			try {
				if (conn != null)
					ConexionDB.devuelveConexion(conn);
			} catch (SQLException e) {
				log.info(e.getMessage(),e);
				e.printStackTrace();
			}
		}
		
		return lastId;
	}
	
	
	private Integer saveDataToPODetalleFacturacion( List<ItemFactura> items, Long idft ) {
		int resultado = 0; 
		Connection conn = null;
	
		for (ItemFactura itemFactura : items) {
			try {
				conn = ConexionDB.dameConexion();
				
				PreparedStatement stmt = conn.prepareStatement(INSERT_DETALLE_FACTURACION);
				stmt.setString(1, itemFactura.getEbeln());
				stmt.setString(2, itemFactura.getEbelp());
				stmt.setInt(3, itemFactura.getMenge().intValue());
				stmt.setLong(4, idft);

				resultado += stmt.executeUpdate();
				
				stmt.close();
				
				ConexionDB.devuelveConexion(conn);
				
			} catch (ClassNotFoundException | SQLException e) {
				log.info(e.getMessage(),e);
				e.printStackTrace();
			}finally {
				try {
					ConexionDB.devuelveConexion(conn);
				} catch (Exception sqlEx2) {
					log.error(sqlEx2.getMessage(), sqlEx2);
					log.info("error: " + sqlEx2);
				}
			}
		}
		return resultado;
		
	}
	

	public List<DataFactura> getDataFacturacionBySar(String sar) {

		List<DataFactura> datosSar = new ArrayList<DataFactura>();
		Connection conn = null;

		try {

			conn = ConexionDB.dameConexion();
			PreparedStatement pstmt = conn.prepareStatement(QUERY_DATA_FACTURACION_BY_SAR + sar);
			ResultSet rs = pstmt.executeQuery();

			while (rs.next()) {
				DataFactura dato = new DataFactura();
				dato.setFolio(rs.getString("folio"));
				dato.setProveedor(rs.getString("proveedor"));
				dato.setContenedor(rs.getString("contenedor").trim());
				dato.setBL(rs.getString("BL"));
				dato.setCondicionPago(rs.getString("condicionPago"));
				dato.setPo(rs.getString("po").trim());
				dato.setPosicion(rs.getString("posicion"));
				dato.setCantidad(rs.getDouble("cantidad"));
				dato.setCantidadUnidadMedida(rs.getDouble("cantidadUnidadMedida"));
				dato.setPrioridad(rs.getInt("prioridad"));
				dato.setMaterial(rs.getInt("material"));
				dato.setShipmentType( rs.getBoolean("esAereo") ? "AEREO": "Sea Shipping" );
				dato.setPod(rs.getString("puertoDescarga"));
				dato.setEtd(rs.getInt("etd"));
				dato.setEtdFinal(rs.getInt("etdFinal"));
				dato.setFacturaProveedor(rs.getString("factura_proveedor"));
				dato.setPaisOrigen(rs.getString("paisorigen"));
				dato.setBooking(rs.getString("booking"));
				//dato.setOrdenSecundaria(rs.getString("ordenSecundaria"));
				datosSar.add(dato);

			}
		} catch (Exception e) {
			log.error(e.getStackTrace().toString(),e);

		} finally {
			ConexionDB.devolver(conn);
		}

		return datosSar;
	}

	public List<DataFactura> getDataFacturacionBySarAndCondicionPago(String sar, String codicionPago, Connection con) {

		List<DataFactura> datosSar = new ArrayList<DataFactura>();
		Connection conn = con;


		try {

			conn = con == null ? ConexionDB.dameConexion() : con;
			PreparedStatement pstmt = conn.prepareStatement(QUERY_FACTURACION_BY_SAR_CONDICION_PAGO);
			pstmt.setString(1, sar);
			pstmt.setString(2, codicionPago);
			ResultSet rs = pstmt.executeQuery();

			while (rs.next()) {
				DataFactura dato = new DataFactura();
				dato.setFolio(rs.getString("folio"));
				dato.setProveedor(rs.getString("proveedor"));
				dato.setContenedor(rs.getString("contenedor").trim());
				dato.setBL(rs.getString("BL"));
				dato.setCondicionPago(rs.getString("condicionPago"));
				dato.setPo(rs.getString("po").trim());
				dato.setPosicion(rs.getString("posicion"));
				dato.setCantidad(rs.getDouble("cantidad"));
				dato.setCantidadUnidadMedida(rs.getDouble("cantidadUnidadMedida"));
				dato.setPrioridad(rs.getInt("prioridad"));
				dato.setMaterial(rs.getInt("material"));
				dato.setShipmentType( rs.getBoolean("esAereo") ? "AEREO": "Sea Shipping" );
				dato.setPod(rs.getString("puertoDescarga"));
				datosSar.add(dato);

			}
		} catch (Exception e) {
			log.error(e.getStackTrace().toString(),e);

		}finally {
			try {
				ConexionDB.devuelveConexion(conn);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
				log.info("error: " + sqlEx2);
			}
		}

		return datosSar;
	}

	@Override
	public List<Facturacion> getByFilterRejectedDAO(Facturacion filtro) {

		List<Facturacion> listFacturacionR = new ArrayList<Facturacion>();

		Connection conn = null;

		StringBuilder query2 = new StringBuilder(SQL2);

		// 1.- folio
		if (filtro.getFolio() != null && !filtro.getFolio().equals("")) {
			query2.append(" AND SAR.folio=  ");
			query2.append(filtro.getFolio());
		}
		// 2.- supplier
		if (filtro.getSupplier() != null && !filtro.getSupplier().equals("")) {
			query2.append(" AND supplier_code=  '");
			query2.append(filtro.getSupplier()).append("'");

		}
		// 3 .- priority
		if (filtro.getPriority() != null && !filtro.getPriority().equals("") && !filtro.getPriority().equals("-1")) {
			query2.append(" AND priority=  ");
			query2.append(filtro.getPriority());
		}
		// 4.- po
		if (filtro.getPo() != null && !filtro.getPo().equals("")) {
			query2.append(" AND( ");
			query2.append(" 	SELECT");
			query2.append(" TOP 1 po");
			query2.append("		FROM");
			query2.append("		cdiSARDetalle");
			query2.append("			WHERE");
			query2.append("			folio = SAR.folio ");
			query2.append("			AND po = '");
			query2.append(filtro.getPo()).append("')=");
			query2.append("'").append(filtro.getPo()).append("'");
		}
		// 5.- carrier
		if (filtro.getCarrier() != null && !filtro.getCarrier().equals("") && !filtro.getCarrier().equals("-1")) {
			query2.append(" AND carrier=  ");
			query2.append(filtro.getCarrier());
		}
		// 6 .- BL Number
		if (filtro.getBlNumber() != null && !filtro.getBlNumber().equals("")) {
			query2.append(" AND sar.BL = '");
			query2.append(filtro.getBlNumber()).append("'");
		}
		// 7 .- Analyst
		if (filtro.getAnalyst() != null && !filtro.getAnalyst().equals("") && !filtro.getAnalyst().equals("-1")) {
			query2.append(" AND analyst=  '");
			query2.append(filtro.getAnalyst()).append("'");
		}
		// 8.- POD
		if (filtro.getPod() != null && !filtro.getPod().equals("") && !filtro.getPod().equals("-1")) {
			query2.append(" AND pod=  '");
			query2.append(filtro.getPod()).append("'");
		}
		// 9.- Booking
		if (filtro.getBooking() != null && !filtro.getBooking().equals("")) {
			query2.append(" AND sar.booking =   '");
			query2.append(filtro.getBooking()).append("'");
		}
		// 10 .- Invoice Number
		if (filtro.getInvoiceNumber() != null && !filtro.getInvoiceNumber().equals("")) {
			query2.append(" AND F.numero_factura_pm =  '");
			query2.append(filtro.getInvoiceNumber()).append("'");
		}
		// 11 .- Container
		if (filtro.getContainer() != null && !filtro.getContainer().equals("")) {
			query2.append(" AND contenedor = '");
			query2.append(filtro.getContainer()).append("'");
		}
		// ETA
		if (filtro.getEtaFrom() != null && !filtro.getEtaFrom().equals("")) {
			query2.append(" AND s.eta  BETWEEN ");
			query2.append(filtro.getEtaFrom().toString().replaceAll("/", ""));
		}
		if (filtro.getEtaTo() != null && !filtro.getEtaTo().equals("")) {
			query2.append(" AND ");
			query2.append(filtro.getEtaTo().replaceAll("/", ""));
		}
		if (filtro.getCodigoEstatusFactura() != null && !filtro.getCodigoEstatusFactura().equals("")
				&& !filtro.getCodigoEstatusFactura().equals("-1")) {
			query2.append(" AND f.factura_status=  (");
			query2.append(filtro.getCodigoEstatusFactura()).append(")");
		} else {
			query2.append(" AND f.factura_status IN (2,3,7,8,15)");
			query2.append(" ORDER BY  FECHA_Y_HORA_APROBACION_SDI  ASC;");
		}

		try {

			// campo ETA
			conn = ConexionDB.dameConexion();
			try (PreparedStatement pstmt = conn.prepareStatement(query2.toString())) {
				
				ResultSet rs = pstmt.executeQuery();
				while (rs.next()) {
					Facturacion facturacion = new Facturacion();
					// Id
					facturacion.setId(rs.getLong("id"));
					// FECHA_Y_HORA_RECHAZO_CONTABILIDAD
					facturacion.setFechaHoraRechazoContabilidad(rs.getString("FECHA_Y_HORA_RECHAZO_CONTABILIDAD"));
					// AREA_QUE_SOLICITA_RECHAZO
					facturacion.setAreaRechazo(rs.getString("AREA_RESPONSABLE_DAR_SOLUCION"));
					// USUARIIO
					facturacion.setUsuarioRechazo(rs.getString("USUARIO_RECHAZO"));

					// PROCESO_MANUAL_AUTOMATICO
					facturacion.setAutomatico(rs.getBoolean("PROCESO_MANUAL_AUTOMATICO"));
					// SAR
					facturacion.setSar(rs.getString("sar"));
					// Fecha y Hora Aprobacion SDI
					facturacion.setFechaHoraAprobacionSDI(cambiarFechaSDI(rs.getString("FECHA_Y_HORA_APROBACION_SDI")));
					// #Factura Proveedor
					facturacion.setFacturaProvedor(rs.getString("FACTURA_PROVEEDOR"));
					// FACTURISTA
					facturacion.setFacturista(rs.getString("FACTURISTA"));
					facturacion.setRealName(rs.getString("nombreFacturista"));
					// INCIDENCIA FACTURISTA
					facturacion.setIncidenciasEnFacturas(rs.getString("INCIDENCIA_FACTURA"));
					// COMENTARIONS_INCIDENCIA
					facturacion.setComentarios(rs.getString("COMENTARIONS_INCIDENCIA"));
					// AREA_RESPONSABLE SOLUCION
					//facturacion.setAreaResponsableSolucion(rs.getString("AREA_RESPONSABLE"));
					// SUPPLIER
					facturacion.setSupplier(rs.getString("SUPPLIER"));
					// ETA
					
					facturacion.setEta(cambiarFecha(rs.getString("ETA")));
					facturacion.setAnalyst(rs.getString("ANALISTA_SDI"));
					// BOOKING_NUMBER
					facturacion.setBooking(rs.getString("BOOKING_NUMBER"));
					// FOLIOS
					facturacion.setFolio(rs.getString("FOLIOS"));
					// BL_NUMBER
					facturacion.setBlNumber(rs.getString("BL_NUMBER"));
					// POD
					facturacion.setPod(rs.getString("POD"));
					
					facturacion.setNombre_puerto_descarga(rs.getString("nombre_puerto_descarga"));
					// SHIPMENT_TYPE
					facturacion.setShipmentType(rs.getString("SHIPMENT_TYPE"));
					// PRIORITY
					facturacion.setPriority(rs.getString("PRIORITY"));
					// STATUS
					facturacion.setStatus(rs.getString("FACTURA_STATUS"));
					facturacion.setCodigoEstatusFactura(rs.getString("CODIGO_STATUS_FACTURA"));
					facturacion.setObs_reject_incidencia(rs.getString("obs_reject_incidencia"));
					facturacion.setNoFacturaPM(rs.getString("no_factura_pm"));
					facturacion.setContainer(rs.getString("contenedor"));
					
					facturacion.setEsSpecialties( rs.getBoolean("esSpecialties") );
					
					facturacion.setIdDoc( rs.getInt("idDoc"));
					
					//ImportacionesProveedoresBean bean_prov_client = FuncionesComunesPLI.getProveedor(facturacion.getSupplier());

					//facturacion.setNombreProveedor(bean_prov_client.getNombreProveedor());
					
					facturacion.setNombreProveedor("");
					if( facturacion.getSupplier() != null && !facturacion.getSupplier().equals("") &&  !facturacion.getSupplier().isEmpty() ) {
						ImportacionesProveedoresBean bean_prov_client = FuncionesComunesPLI.getProveedor(facturacion.getSupplier());
						
						if( bean_prov_client != null &&  bean_prov_client.getNombreProveedor() != null ) {
							facturacion.setNombreProveedor(bean_prov_client.getNombreProveedor());
						}
					}
					

					listFacturacionR.add(facturacion);
				}
			} catch (SQLException e) {
				e.getMessage();
				e.printStackTrace();
				try {
					ConexionDB.renuevaConexion(conn);
				} catch (Exception ex) {
					log.error(ex.getMessage(), ex);
				}
				log.error(e.getMessage(), e);
			}

		} catch (Exception e) {
			try {
				ConexionDB.devuelveConexion(conn);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
				log.info("Info: " + ex);
			}
			log.error(e.getMessage(), e);
			log.info("Info: " + e);

		} finally {
			try {
				ConexionDB.devuelveConexion(conn);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
				log.info("Info: " + sqlEx2);
			}
		}

		return listFacturacionR;
	}

	@Override
	public Facturacion updateByFolio(BeanFacturacion params, String userName) {
		
		Connection con = null;
		int success = 0;
		Facturacion datosFacturacion = new Facturacion();
		try {
			con = ConexionDB.dameConexion();
			StringBuilder sqlUPDATE = new StringBuilder();
			sqlUPDATE.append("UPDATE FACTURACION ");
			sqlUPDATE.append("SET  incidencia =  ");
			sqlUPDATE.append(params.getIncidencia()).append(" ");
			sqlUPDATE.append(" , comentarios_incidencias =  '");
			sqlUPDATE.append(params.getComentarios()).append("'");
			sqlUPDATE.append(" WHERE id =  ");
			sqlUPDATE.append(params.getId());
			
			StringBuilder sqlSELECT = new StringBuilder();
			sqlSELECT.append("SELECT sar, s.BL AS Contenedor , numero_factura_pm AS [Factura proveedor], incidencias.descripcion AS [Cambio de Incidencia]  FROM facturacion AS F ");
			sqlSELECT.append(" left join cdiSar AS s ON f.sar = s.folio  ");
			sqlSELECT.append("left join cat_incidencias AS incidencias ON f.incidencia = incidencias.id ");
			sqlSELECT.append(" WHERE f.id =  ");
			sqlSELECT.append(params.getId());
			
			try (PreparedStatement pst = con.prepareStatement(sqlUPDATE.toString())) {
				success = pst.executeUpdate();
			} catch (SQLException e) {
				e.printStackTrace();
				log.info("Info: " + params == null ? "NULL " : params.toString(), e);
			}
			
			try  (PreparedStatement pst = con.prepareStatement(sqlSELECT.toString())){
				ResultSet rs = pst.executeQuery();				
	
				while (rs.next()) {
					//Facturacion actualizacionIncidencia = new Facturacion();
					datosFacturacion.setFolio(rs.getString("sar"));
					datosFacturacion.setBlNumber(rs.getString("Contenedor"));
					datosFacturacion.setNoFacturaPM(rs.getString("Factura proveedor"));
					datosFacturacion.setIncidenciasEnFacturas(rs.getString("Cambio de Incidencia"));				
					//datosFacturacion.add(actualizacionIncidencia);
					} 
				
			}catch (SQLException e) {
				e.printStackTrace();
				log.info("Error  : ",e.toString());
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			log.info("Info: " + params == null ? "NULL " : params.toString(), e);

		} finally {
			ConexionDB.devolver(con);
		}
		return datosFacturacion;
	
	}

	@Override
	public Integer updateInfoParcialFactura(Facturacion factura) {
		Connection conn = null;
		Integer resultado = null;
		try {
			conn = ConexionDB.dameConexion();
			PreparedStatement stmt = conn.prepareStatement(UPDATE_FACTURACION_PARCIAL);
			stmt.setInt(1, Integer.parseInt(factura.getStatus()));
			stmt.setString(2, factura.getNoFacturaPM());
			stmt.setString(3, factura.getDocumentoSociedad());
			stmt.setString(4, factura.getDocumentoEjercicio());
			stmt.setString(5, factura.getDocumentoNumero());
			stmt.setString(6, factura.getFolio());
			stmt.setString(7, factura.getCondicionPago());
			stmt.setString(8, factura.getAuxkey());

			resultado = stmt.executeUpdate();
			stmt.close();

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e.getStackTrace().toString(),e);
		} finally {
			ConexionDB.devolver(conn);
		}
		return resultado;
	}

	@Override
	public Integer updateFacturaError(Facturacion factura,Boolean procesaEstatusPeticiones ,Boolean error,Boolean peticionCuarentaYTres, Boolean peticionDieciNueve) {
		Connection conn = null;
		Integer resultado = null;

		try {
			conn = ConexionDB.dameConexion();
			StringBuilder query = new StringBuilder();
			query.append("UPDATE FACTURACION ");
			query.append("SET comentarios_incidencias = ?, ");
			
			if (procesaEstatusPeticiones) {
				if (error) {
					if(peticionCuarentaYTres) {
						query.append("estatus_cuarenta_tres=0," );
					}
					if(peticionDieciNueve) {
						query.append("estatus_diecinueve=0, " );
					}
				}else {
					if(peticionCuarentaYTres) {
						query.append("estatus_cuarenta_tres=1," );
					}
					if(peticionDieciNueve) {
						query.append("estatus_diecinueve=1, " );
					}
				}
			}
			
			query.append("incidencia = ?, ");
			query.append("area_responsable_solucion = ?, ");
			query.append("factura_status = ? ");
			query.append("WHERE sar = ? AND condicionPago = ? AND id = ?");

			PreparedStatement stmt = conn.prepareStatement(query.toString());
			stmt.setString(1, factura.getComentarios());
			stmt.setInt(2, Integer.parseInt(factura.getIncidenciasEnFacturas()));
			stmt.setInt(3, Integer.parseInt(factura.getAreaResponsableSolucion()));
			stmt.setInt(4, Integer.parseInt(factura.getStatus()));
			stmt.setString(5, factura.getFolio());
			stmt.setString(6, factura.getCondicionPago());
			stmt.setInt(7, factura.getId().intValue());

			resultado = stmt.executeUpdate();
			stmt.close();

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e.getStackTrace().toString(),e);
		} finally {
			ConexionDB.devolver(conn);
		}
		return resultado;

	}

	@Override
	public Integer updateInfoTotalFactura(Facturacion factura) {
		Connection conn = null;
		Integer resultado = null;
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");

		try {
			conn = ConexionDB.dameConexion();


			PreparedStatement stmt = conn.prepareStatement(QUERY_UPDATE_INFO_TOTA_FACTURA);
			stmt.setDouble(1, Double.parseDouble(factura.getMontoUSD()));
			stmt.setDate(2, new Date(factura.getFechaEmisionFacturaParcel().getTime()));
			stmt.setDouble(3, factura.getImporteOriginal());
			stmt.setInt(4, Integer.parseInt(factura.getStatus()));
			stmt.setString(5, factura.getIncidenciasEnFacturas());
			stmt.setString(6, factura.getComentarios());
			stmt.setString(7, factura.getNoFacturaPM());

			resultado = stmt.executeUpdate();
			stmt.close();

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e.getStackTrace().toString(),e);
		} finally {
			ConexionDB.devolver(conn);
		}
		return resultado;
	}

	@Override
	public Facturacion cancelarFactura(Facturacion factura, Connection con) {
		Connection conn = con;
		Facturacion facturaAux = null;

		List<Map<String, String>> lista = new ArrayList<Map<String, String>>();

		try {
			conn = conn == null ? ConexionDB.dameConexion() : con;


			PreparedStatement stmt = conn.prepareStatement(QUERY_CANCELAR_FACTURA);
			stmt.setString(1, factura.getNoFacturaPM());

			ResultSet rs = stmt.executeQuery();

			while (rs.next()) {

				if (facturaAux == null) {
					facturaAux = new Facturacion();
					facturaAux.setId(rs.getLong("id"));
					facturaAux.setSar(rs.getString("sar"));
					facturaAux.setStatus(rs.getInt("factura_status") + "");
					facturaAux.setSupplier(rs.getString("supplier_code"));
					facturaAux.setCondicionPago(rs.getString("condicionPago"));
					facturaAux.setContainer(rs.getString("contenedor"));
					facturaAux.setBlNumber(rs.getString("BL"));
					facturaAux.setNoFacturaPM(factura.getNoFacturaPM());
					facturaAux.setFacturista(rs.getString("facturista"));
					facturaAux.setComentarios(rs.getString("comentarios_incidencias"));

				}
				Map<String, String> item = new HashMap<String, String>();
				item.put("ebeln", rs.getString("po").trim());
				item.put("ebelp", rs.getInt("posicion") + "");

				lista.add(item);

			}
			if (facturaAux != null)
				facturaAux.setListaPos(lista);

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e.getStackTrace().toString(),e);
		}
		return facturaAux;
	}

	public String getEmails(String numIncidencia) {
		Connection conn = null;
		String emails = "";

		StringBuilder queryEmails = new StringBuilder();
		queryEmails.append("SELECT correos FROM CAT_INCIDENCIAS where id = ").append(Integer.parseInt(numIncidencia));
		;

		try {

			conn = ConexionDB.dameConexion();
			try (PreparedStatement pstmt = conn.prepareStatement(queryEmails.toString())) {
				ResultSet rs = pstmt.executeQuery();
				while (rs.next()) {

					// Id
					emails = rs.getString("correos");

				}
			} catch (SQLException e) {
				try {
					ConexionDB.renuevaConexion(conn);
				} catch (Exception ex) {
					log.error(ex.getMessage(), ex);
					log.info("error: " + ex);
				}
				log.error(e.getMessage(), e);
				log.info("error: " + e);
			}

		} catch (Exception e) {
			try {
				ConexionDB.devuelveConexion(conn);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
				log.info("error: " + ex);
			}
			log.error(e.getMessage(), e);
			log.info("error: " + e);

		} finally {
			try {
				ConexionDB.devuelveConexion(conn);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
				log.info("error: " + sqlEx2);
			}
		}

		return emails;
	}

	@Override
	public List<CatStatusFacturacion> getListCatStatusFacturacion(String options) {

		Connection conn = null;
		List<CatStatusFacturacion> listCatStatusFacturacion = new ArrayList<CatStatusFacturacion>();

		StringBuilder queryIncidencia = new StringBuilder();
		queryIncidencia.append("SELECT * FROM CAT_FACTURA_STATUS ");

		if (options != null) {
			queryIncidencia.append(" where id in (").append(options).append(")");
		}
		try {
			conn = ConexionDB.dameConexion();
			try (PreparedStatement pstmt = conn.prepareStatement(queryIncidencia.toString())) {
				ResultSet rs = pstmt.executeQuery();
				while (rs.next()) {
					CatStatusFacturacion codigoIncidencia = new CatStatusFacturacion();
					codigoIncidencia.setCodigo(rs.getInt("id"));
					codigoIncidencia.setDescripcion(rs.getString("descripcion"));
					listCatStatusFacturacion.add(codigoIncidencia);

				}

			} catch (SQLException e) {
				try {
					ConexionDB.renuevaConexion(conn);
				} catch (Exception ex) {
					log.error(ex.getMessage(), ex);
				}
				log.error(e.getMessage(), e);
			}

		} catch (Exception e) {
			try {
				ConexionDB.devuelveConexion(conn);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
				log.info("error: " + ex);
			}
			log.error(e.getMessage(), e);
			log.info("error: " + e);

		} finally {
			try {
				ConexionDB.devuelveConexion(conn);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
				log.info("error: " + sqlEx2);
			}
		}

		return listCatStatusFacturacion;
	}

	@Override
	public Integer updateByFolioStatusIncidencia(BeanFacturacion params, String userName) {
		Connection con = null;
		int success = 0;
		try {
			con = ConexionDB.dameConexion();
			StringBuilder sql = new StringBuilder();
			sql.append("UPDATE FACTURACION ");
			sql.append("SET  incidencia = 5 ");
			sql.append(" WHERE id =  ");
			sql.append(params.getId());
			try (PreparedStatement pst = con.prepareStatement(sql.toString())) {
				success = pst.executeUpdate();
			} catch (SQLException e) {
				e.printStackTrace();
				log.info("Info: " + params == null ? "NULL " : params.toString(), e);
			}
		} catch (Exception e) {
			e.printStackTrace();
			log.info("Info: " + params == null ? "NULL " : params.toString(), e);

		} finally {
			ConexionDB.devolver(con);
		}
		return success;

	}

	@Override
	public Facturacion UpdateStatusFactura(Facturacion factura, Connection con)
			throws ClassNotFoundException, SQLException {
		Connection conn = con;
		try {
			conn = con == null ? ConexionDB.dameConexion() : con;
			StringBuilder query = new StringBuilder();
			query.append("UPDATE FACTURACION ");
			query.append("SET factura_status = ?, ");
			query.append("comentarios_incidencias= ?, ");
			query.append("facturista = ? ");
			query.append("WHERE id = ? ");
	
			PreparedStatement stmt = conn.prepareStatement(query.toString());
			stmt.setInt(1, Integer.parseInt(factura.getStatus()));
			stmt.setString(2, factura.getComentarios());
			stmt.setString(3, factura.getFacturista());
			stmt.setLong(4, factura.getId());
	
			stmt.executeUpdate();
	
			query = new StringBuilder();
			query.append("SELECT sar, factura_status, condicionPago, ");
			query.append("numero_factura_pm FROM facturacion ");
			query.append("WHERE id = ? ");
			stmt = conn.prepareStatement(query.toString());
			stmt.setLong(1, factura.getId());
	
			ResultSet rs = stmt.executeQuery();
	
			while (rs.next()) {
				factura.setNoFacturaPM(rs.getString("numero_factura_pm"));
				factura.setStatus(rs.getInt("factura_status") + "");
				factura.setCondicionPago(rs.getString("condicionPago"));
				factura.setSar(rs.getString("sar"));
			}
	
			
		} catch (Exception e) {
			e.printStackTrace();
			log.error(e.getStackTrace().toString(),e);
		} finally {
			try {
				if(con == null)
					ConexionDB.devuelveConexion(conn);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
				log.info("error: " + sqlEx2);
			}
		}

		return factura;

	}
//
//	@Override
//	public Long updateRevocationConfirmation(Long folio) {
//		Connection con = null;
//		long success = 0;
//		try {
//			con = ConexionDB.dameConexion();
//			StringBuilder sql = new StringBuilder();
//			sql.append("UPDATE FACTURACION ");
//			sql.append("SET  incidencia = 5 ");
//			sql.append(" WHERE id =  ");
//			sql.append(folio);
//			try (PreparedStatement pst = con.prepareStatement(sql.toString())) {
//				success = pst.executeUpdate();
//			} catch (SQLException e) {
//				e.printStackTrace();
//				log.info("Info: " + folio == null ? "NULL " : folio.toString(), e);
//			}
//		} catch (Exception e) {
//			e.printStackTrace();
//			log.info("Info: " + folio == null ? "NULL " : folio.toString(), e);
//
//		} finally {
//			ConexionDB.devolver(con);
//		}
//		return success;
//	
//	}

	@Override
	public List<ItemFactura> getPosByFolio(String folio) {
		Connection conn = null;

		List<ItemFactura> lista = new ArrayList<ItemFactura>();

		String query = new StringBuilder("SELECT po,posicion FROM cdiSarDetalle ").append("WHERE folio = ?").toString();

		try {

			conn = ConexionDB.dameConexion();

			PreparedStatement stmt = conn.prepareStatement(query.toString());
			stmt.setString(1, folio);

			ResultSet rs = stmt.executeQuery();

			while (rs.next()) {
				ItemFactura data = new ItemFactura();
				data.setEbeln(rs.getString("po").trim());
				data.setEbelp(rs.getInt("posicion") + "");
				lista.add(data);
			}

		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			log.error(e.getStackTrace().toString(),e);
		} finally {
			ConexionDB.devolver(conn);
		}

		return lista;
	}

	@Override
	public Integer setProcesadoSIFE(Facturacion factura, Long idTipoSolicitud) {
		Connection conn = null;
		int success = 0;
		try {
			conn = ConexionDB.dameConexion();
			StringBuilder query = new StringBuilder();			
			query.append("UPDATE FACTURACION ");
			query.append("SET  procesadoSIFE = 1, ");
			query.append("factura_status = ?, ");
			if(factura.getFolioSIFE()!=null) {
				if(idTipoSolicitud==19) {
					query.append("FolioSIFE = ?, ");
				}else if(idTipoSolicitud==43) {
					query.append("FolioSIFE43 = ?, ");
				}
			}
			if(factura.getMensaje()!=null && !factura.getMensaje().isEmpty()) {  
				if(idTipoSolicitud==19) {
					query.append("mensaje_sife_19  = ?, ");
				}else if(idTipoSolicitud==43) {
					query.append("mensaje_sife_43  = ?, ");
				}
			}
			int contador  =1;
			query.append("fechaProcesadoSIFE = CURRENT_TIMESTAMP ");
			query.append("WHERE sar = ? ");
			query.append("AND condicionPago = ? ");
			query.append("AND id = ? ");
			PreparedStatement stmt = conn.prepareStatement(query.toString());
			stmt.setInt(contador++, Integer.parseInt(factura.getCodigoEstatusFactura()));
			if(factura.getFolioSIFE()!=null) {
				stmt.setLong(contador++, factura.getFolioSIFE());
			}
			if(factura.getMensaje()!=null && !factura.getMensaje().isEmpty()) {
				stmt.setString(contador++, factura.getMensaje());
			}
			stmt.setInt(contador++, Integer.parseInt(factura.getSar()));
			stmt.setString(contador++, factura.getCondicionPago());
			stmt.setLong(contador++, factura.getId());
			
			
			success = stmt.executeUpdate();
			
			
			
			stmt.close();

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e.getStackTrace().toString(),e);
		} finally {
			if( conn != null )
				ConexionDB.devolver(conn);
		}
		return success;
	}

	@Override
	public List<EntregaTraficoModel> getListEntrgeaDocsFinales(String status, FiltroEntregaTrafico filtro) {
		List<EntregaTraficoModel> list = new ArrayList<EntregaTraficoModel>();
		Connection conn = null;
		int totalRegistros =0;
		String query = new String(SQL_DOC_FINALES.toString());
		query = query.replaceAll(Pattern.quote("$$STATUS$$"), status);
		StringBuilder final_query_filtro = new StringBuilder("");
		StringBuilder final_query_count = new StringBuilder("");
		
		if (filtro != null) {
			if (filtro.getFolio() != null && !filtro.getFolio().equals("")) {
				final_query_filtro.append(" AND f.sar = ").append(filtro.getFolio()).append(" ");
			}
			if (filtro.getBlNumber() != null && !filtro.getBlNumber().equals("")) {
				final_query_filtro.append(" AND s.BL = '").append(filtro.getBlNumber()).append("' ");
			}
			if (filtro.getBooking() != null && !filtro.getBooking().equals("")) {
				final_query_filtro.append(" AND s.booking = '").append(filtro.getBooking()).append("' ");
			}
			if (filtro.getContenedor() != null && !filtro.getContenedor().equals("")) {
				final_query_filtro.append(" AND s.contenedor = '").append(filtro.getContenedor()).append("' ");
			}
			if (filtro.getProveedor() != null && !filtro.getProveedor().equals("")) {
				final_query_filtro.append(" AND csdi.proveedor = '").append(filtro.getProveedor()).append("' ");
			}
			if (filtro.getCarrier() != null && !filtro.getCarrier().equals("") && !filtro.getCarrier().equals("-1")) {
				final_query_filtro.append(" AND nav.clave = '").append(filtro.getCarrier()).append("' ");
			}
			if (filtro.getAnalyst() != null && !filtro.getAnalyst().equals("") && !filtro.getAnalyst().equals("-1")) {
				final_query_filtro.append(" AND csdi.analista = '").append(filtro.getAnalyst()).append("' ");
			}
			if (filtro.getInvoiceNumber() != null && !filtro.getInvoiceNumber().equals("")) {
				final_query_filtro.append(" AND f.numero_factura_pm = '").append(filtro.getInvoiceNumber()).append("' ");
			}
			if (filtro.getPriority() != null && !filtro.getPriority().equals("")
					&& !filtro.getPriority().equals("-1")) {
				final_query_filtro.append(" AND s.prioridad = '").append(filtro.getPriority()).append("' ");
			}
			if (filtro.getEtaFrom() != null && !filtro.getEtaFrom().equals("")) {
				final_query_filtro.append(" AND s.eta between ").append(filtro.getEtaFrom().toString().replaceAll("/", ""));
				if (filtro.getEtaTo() != null && !filtro.getEtaTo().equals("")) {
					final_query_filtro.append(" AND  ").append(filtro.getEtaTo().toString().replaceAll("/", ""));
				} else {
					final_query_filtro.append(" AND  ").append(filtro.getEtaFrom().toString().replaceAll("/", ""));
				}
			}
			if (filtro.getPod() != null && !filtro.getPod().equals("") && !filtro.getPod().equals("-1")) {
				String[] val = filtro.getPod().split("-");
				final_query_filtro.append(" AND f.pod = '").append(val[1]).append("' ");
			}
			if (filtro.getPo() != null && !filtro.getPo().equals("") && !filtro.getPo().equals("-1")) {
				final_query_filtro.append(" AND( ");
				final_query_filtro.append(" 	SELECT");
				final_query_filtro.append(" TOP 1 po");
				final_query_filtro.append("		FROM");
				final_query_filtro.append("		cdiSARDetalle");
				final_query_filtro.append("			WHERE");
				final_query_filtro.append("			folio = s.folio ");
				final_query_filtro.append("			AND po = '");
				final_query_filtro.append(filtro.getPo()).append("')=");
				final_query_filtro.append("'").append(filtro.getPo()).append("'");
				
			}
			totalRegistros =0;
			String queryConteo = query.replaceAll(Pattern.quote("$$FILTRO1$$"), final_query_filtro.toString());
			queryConteo = queryConteo.replaceAll(Pattern.quote("$$FILTRO2$$"), final_query_filtro.toString() );
			try {
				conn = ConexionDB.dameConexion();
			}catch(Exception e) {
				e.printStackTrace();
			}
			try (PreparedStatement pstmt = conn.prepareStatement(queryConteo)) {
				ResultSet rs = pstmt.executeQuery();
				while (rs.next()) {
					totalRegistros ++;
				}
				pstmt.close();
				rs.close();
			} catch (SQLException e) {
				try {
					ConexionDB.renuevaConexion(conn);
				} catch (Exception ex) {
					log.error(ex.getMessage(), ex);
				}
				log.error(e.getMessage(), e);
			}finally {
				try {
					ConexionDB.devuelveConexion(conn);
				} catch (Exception sqlEx2) {
					log.error(sqlEx2.getMessage(), sqlEx2);
				}
			}
			log.info("Log conteo ::  {}",totalRegistros);
			if (filtro.getPaginaActual().equals("0")) {
				final_query_count.append("ORDER BY f.sar  DESC OFFSET ");
				final_query_count.append("0");
				final_query_count.append(" ROWS FETCH NEXT ").append(NUMBER_FIELDS).append(" ROWS ONLY");
			} else {
					final_query_count.append("ORDER BY f.sar  DESC OFFSET ");
					if(filtro.getPaginaActual().equals(NUMBER_FIELDS)) {
						final_query_count.append("" + 0);
					}else{
						int dato =Integer.parseInt(filtro.getPaginaActual());
						if(totalRegistros<NUMBER_FIELDS) {
							final_query_count.append("" + 0);
						}else {
							final_query_count.append("" + dato);
						}
					}
					final_query_count.append(" ROWS FETCH NEXT ").append(NUMBER_FIELDS).append(" ROWS ONLY");
			}

		} else {
			final_query_count.append("ORDER BY f.sar  DESC OFFSET 0 ROWS FETCH NEXT ").append(NUMBER_FIELDS)
					.append(" ROWS ONLY");
		}
		
		
		query = query.replaceAll(Pattern.quote("$$FILTRO1$$"), final_query_filtro.toString());
		query = query.replaceAll(Pattern.quote("$$FILTRO2$$"), final_query_filtro.toString() + final_query_count.toString());
		
		
		try {
			conn = ConexionDB.dameConexion();
		}catch(Exception e) {
			e.printStackTrace();
		}
		try { 			
			try (PreparedStatement pstmt = conn.prepareStatement(query)) {
				ResultSet rs = pstmt.executeQuery();
				while (rs.next()) {
					int t=0;
					try {
						EntregaTraficoModel etm = new EntregaTraficoModel();
						etm.setVisible(NUMBER_FIELDS);
						etm.setId(rs.getLong("id"));
						etm.setConsolidado(
								(rs.getString("consolidado") == null || rs.getString("consolidado").equalsIgnoreCase("NULL")
										|| rs.getInt("consolidado") == 0) ? false : rs.getBoolean("consolidado"));
						etm.setFechaAprobadoSDI((rs.getString("fechaAprobadoSDI") == null) ? false : true);
						etm.setBooking(rs.getString("booking"));
						etm.setFolio(rs.getString("sar"));
						etm.setBL((rs.getString("BL") == null || rs.getString("BL").equals("")) ? "-" : rs.getString("BL"));
						etm.setContenedor(
								(rs.getString("contenedor") == null || rs.getString("contenedor").equals("")) ? "-"
										: rs.getString("contenedor"));
						etm.setProveedor((rs.getString("proveedor") == null) ? "-" : rs.getString("proveedor") + "-"+ FuncionesComunesPLI.getProveedor(rs.getString("proveedor")).getNombreProveedor());
						etm.setEtd(rs.getString("etd") == null ? "-" : FuncionesComunesPLI.formateaFecha(Integer.parseInt(rs.getString("etd"))));
						etm.setEta(rs.getString("eta") == null ? "-" : FuncionesComunesPLI.formateaFecha(Integer.parseInt(rs.getString("eta"))));
						etm.setCondicionpago((rs.getString("condicionpago") == null) ? "-" : rs.getString("condicionpago"));
						etm.setPod((rs.getString("pod") == null) || rs.getString("pod").equals("-1") ? "-" : FuncionesComunesPLI.mapaPuertosDestino
								.get(rs.getString("pod")).getNombre());
						etm.setAnalista((rs.getString("analista") == null) ? "-" : rs.getString("analista"));
						etm.setPuertoSalida(rs.getString("puertoSalida"));
						etm.setTransporte(rs.getString("transporte"));
						etm.setShipment_type(rs.getString("shipment_type"));
						etm.setCarrier(rs.getString("carrier"));
						etm.setPrioridad(rs.getString("prioridad"));
						etm.setFacturaPm(
								(rs.getString("numero_factura_pm") == null) ? "-" : rs.getString("numero_factura_pm"));
						etm.setNumber(rs.getInt("number"));
						t++;
						etm.setProcesadoSIFE(rs.getBoolean("procesadoSIFE"));
						etm.setEntregadoTrafico(rs.getBoolean("entregadoTrafico"));
						etm.setAnalista_trafico(
								(rs.getString("analista_trafico") == null || rs.getString("analista_trafico").equals(""))
										? "-"
										: rs.getString("analista_trafico"));
						etm.setObservaciones_trafico((rs.getString("observaciones_trafico") == null
								|| rs.getString("observaciones_trafico").equals("")) ? "-"
										: rs.getString("observaciones_trafico"));
						etm.setCustoms_agent(
								(rs.getString("customs_agent") == null || rs.getString("customs_agent").equals("")) ? "-"
										: rs.getString("customs_agent"));
						etm.setCondicionpago_desc(etm.getCondicionpago() +"|"+ FuncionesComunesPLI.dameMapaCondicionPago(false).get(etm.getCondicionpago()));
						etm.setUrgente(rs.getBoolean("urgente"));
						etm.setObs_reject_incidencia((rs.getString("obs_reject_incidencia") == null) ? "-":rs.getString("obs_reject_incidencia"));
						etm.setTotal(rs.getDouble("total") < 0 ? 0.0:rs.getDouble("total"));
						etm.setSubtotal(rs.getDouble("subtotal") < 0 ? 0.0:rs.getDouble("subtotal"));
						etm.setSubtotalfocs(rs.getDouble("subtotalfocs") < 0 ? 0.0:rs.getDouble("subtotalfocs"));
						etm.setSubtotalothers(rs.getDouble("subtotalothers") < 0 ? 0.0:rs.getDouble("subtotalothers"));
						etm.setFacturaProveedor((rs.getString("fac_proveedor") == null || rs.getString("fac_proveedor").equals(""))
										? "-"
										: rs.getString("fac_proveedor"));
						etm.setPara_envio_a_trafico(rs.getString("para_envio_a_trafico"));
						etm.setIdStatus(rs.getInt("factura_status"));
						etm.setIdEsatusDieciNueve(rs.getInt("estatus_diecinueve"));
						etm.setIdEstatusCuarentaYtres(rs.getInt("estatus_cuarenta_tres"));
						etm.setEsSpecialties( rs.getBoolean("esSpecialties") );
						
						list.add(etm);
					}catch(Exception e) {
						log.info("Folio  -> {} -> {}"+ rs.getLong("id") , t);
					}

				}
				pstmt.close();
				rs.close();
			} catch (SQLException e) {
				try {
					ConexionDB.renuevaConexion(conn);
				} catch (Exception ex) {
					log.error(ex.getMessage(), ex);
				}
				log.error(e.getMessage(), e);
			}
		} catch (Exception e) {
			try {
				ConexionDB.devuelveConexion(conn);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} finally {
			try {
				ConexionDB.devuelveConexion(conn);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
		return list;
	}
	
	

	@Override
	public List<EntregaTraficoModel> getListRechazadosTrafico(String status, FiltroEntregaTrafico filtro) {
		int totalRegistros=0;
		List<EntregaTraficoModel> list = new ArrayList<EntregaTraficoModel>();
		Connection conn = null;
		String query = new String(SQL_RECHAZO_TRAFICO.toString());
		query = query.replaceAll(Pattern.quote("$$STATUS$$"), status);
		StringBuilder final_query = new StringBuilder(query);

		if (filtro != null) {
			if (filtro.getFolio() != null && !filtro.getFolio().equals("")) {
				final_query.append(" AND f.sar = ").append(filtro.getFolio()).append(" ");
			}
			if (filtro.getBlNumber() != null && !filtro.getBlNumber().equals("")) {
				final_query.append(" AND s.BL = '").append(filtro.getBlNumber()).append("' ");
			}
			if (filtro.getBooking() != null && !filtro.getBooking().equals("")) {
				final_query.append(" AND s.booking = '").append(filtro.getBooking()).append("' ");
			}
			if (filtro.getContenedor() != null && !filtro.getContenedor().equals("")) {
				final_query.append(" AND s.contenedor = '").append(filtro.getContenedor()).append("' ");			
			}
			if (filtro.getProveedor() != null && !filtro.getProveedor().equals("")) {
				final_query.append(" AND csdi.proveedor = '").append(filtro.getProveedor()).append("' ");
			}
			if (filtro.getCarrier() != null && !filtro.getCarrier().equals("") && !filtro.getCarrier().equals("-1")) {
				final_query.append(" AND nav.clave = '").append(filtro.getCarrier()).append("' ");
			}			
			if (filtro.getAnalyst() != null && !filtro.getAnalyst().equals("") && !filtro.getAnalyst().equals("-1")) {
				final_query.append(" AND csdi.analista = '").append(filtro.getAnalyst()).append("' ");
			}
			if (filtro.getInvoiceNumber() != null && !filtro.getInvoiceNumber().equals("")) {
				final_query.append(" AND f.numero_factura_pm = '").append(filtro.getInvoiceNumber()).append("' ");
			}
			if (filtro.getPriority() != null && !filtro.getPriority().equals("")
					&& !filtro.getPriority().equals("-1")) {
				final_query.append(" AND s.prioridad = '").append(filtro.getPriority()).append("' ");
			}
			if (filtro.getEtaFrom() != null && !filtro.getEtaFrom().equals("")) {
				final_query.append(" AND s.eta between ").append(filtro.getEtaFrom().toString().replaceAll("/", ""));
				if (filtro.getEtaTo() != null && !filtro.getEtaTo().equals("")) {
					final_query.append(" AND  ").append(filtro.getEtaTo().toString().replaceAll("/", ""));
				} else {
					final_query.append(" AND  ").append(filtro.getEtaFrom().toString().replaceAll("/", ""));
				}
			}
			if (filtro.getPod() != null && !filtro.getPod().equals("") && !filtro.getPod().equals("-1")) {
				String[] val = filtro.getPod().split("-");
				final_query.append(" AND f.pod = '").append(val[1]).append("' ");
			}
			if (filtro.getPo() != null && !filtro.getPo().equals("") && !filtro.getPo().equals("-1")) {				
				final_query.append(" AND( ");
				final_query.append(" 	SELECT");
				final_query.append(" TOP 1 po");
				final_query.append("		FROM");
				final_query.append("		cdiSARDetalle");
				final_query.append("			WHERE");
				final_query.append("			folio = s.folio ");
				final_query.append("			AND po = '");
				final_query.append(filtro.getPo()).append("')=");
				final_query.append("'").append(filtro.getPo()).append("'");
			}
			totalRegistros=0;
			try {
				conn = ConexionDB.dameConexion();
			}catch(Exception e) {
				e.printStackTrace();
			}
			try (PreparedStatement pstmt = conn.prepareStatement(final_query.toString())) {
				ResultSet rs = pstmt.executeQuery();
				while (rs.next()) {
					totalRegistros ++;
				}
				pstmt.close();
				rs.close();
			} catch (SQLException e) {
				try {
					ConexionDB.renuevaConexion(conn);
				} catch (Exception ex) {
					log.error(ex.getMessage(), ex);
				}
				log.error(e.getMessage(), e);
			}finally {
				try {
					ConexionDB.devuelveConexion(conn);
				} catch (Exception sqlEx2) {
					log.error(sqlEx2.getMessage(), sqlEx2);
				}
			}
			log.info("Log conteo Rechazados ::  {}",totalRegistros);
			if (filtro.getPaginaActual().equals("0")) {
				final_query.append(" ORDER BY f.sar  DESC OFFSET ");
				final_query.append(" 0");
				final_query.append(" ROWS FETCH NEXT ").append(NUMBER_FIELDS).append(" ROWS ONLY");
			}else {
				final_query.append(" ORDER BY f.sar  DESC OFFSET ");
				if(filtro.getPaginaActual().equals(NUMBER_FIELDS)) {
					final_query.append("" + 0);
				}else{
					int dato =Integer.parseInt(filtro.getPaginaActual());
					if(totalRegistros<NUMBER_FIELDS) {
						final_query.append("" + 0);
					}else {
						final_query.append("" + dato);
					}
				}
				final_query.append(" ROWS FETCH NEXT ").append(NUMBER_FIELDS).append(" ROWS ONLY");
			}

		} else {
			final_query.append(" ORDER BY f.sar  DESC OFFSET 0 ROWS FETCH NEXT ").append(NUMBER_FIELDS)
					.append(" ROWS ONLY");
		}
		try {
			conn = ConexionDB.dameConexion();
		}catch(Exception e) {
			e.printStackTrace();
		}
	
		try { 
			try (PreparedStatement pstmt = conn.prepareStatement(final_query.toString())) {
				ResultSet rs = pstmt.executeQuery();
				while (rs.next()) {

					EntregaTraficoModel etm = new EntregaTraficoModel();
					etm.setVisible(NUMBER_FIELDS);
					etm.setId(rs.getLong("id"));
					etm.setConsolidado(
							(rs.getString("consolidado") == null || rs.getString("consolidado").equalsIgnoreCase("NULL")
									|| rs.getInt("consolidado") == 0) ? false : rs.getBoolean("consolidado"));
					etm.setFechaAprobadoSDI((rs.getString("fechaAprobadoSDI") == null) ? false : true);
					etm.setBooking(rs.getString("booking"));
					etm.setFolio(rs.getString("sar"));
					etm.setBL((rs.getString("BL") == null || rs.getString("BL").equals("")) ? "-" : rs.getString("BL"));
					etm.setContenedor(
							(rs.getString("contenedor") == null || rs.getString("contenedor").equals("")) ? "-"
									: rs.getString("contenedor"));
					etm.setProveedor((rs.getString("proveedor") == null) ? "-" : rs.getString("proveedor") + "-"+ FuncionesComunesPLI.getProveedor(rs.getString("proveedor")).getNombreProveedor());
					etm.setEtd(rs.getString("etd") == null ? "-" : FuncionesComunesPLI.formateaFecha(Integer.parseInt(rs.getString("etd"))));
					etm.setEta(rs.getString("eta") == null ? "-" : FuncionesComunesPLI.formateaFecha(Integer.parseInt(rs.getString("eta"))));
					etm.setCondicionpago((rs.getString("condicionpago") == null) ? "-" : rs.getString("condicionpago"));
					etm.setPod((rs.getString("pod") == null) ? "-" : FuncionesComunesPLI.mapaPuertosDestino
							.get(rs.getString("pod")).getNombre());
					etm.setAnalista((rs.getString("analista") == null) ? "-" : rs.getString("analista"));
					etm.setPuertoSalida(rs.getString("puertoSalida"));
					etm.setTransporte(rs.getString("transporte"));
					etm.setShipment_type(rs.getString("shipment_type"));
					etm.setCarrier(rs.getString("carrier"));
					etm.setPrioridad(rs.getString("prioridad"));
					etm.setFacturaPm(
							(rs.getString("numero_factura_pm") == null) ? "-" : rs.getString("numero_factura_pm"));
					etm.setNumber(rs.getInt("number"));
					etm.setProcesadoSIFE(rs.getBoolean("procesadoSIFE"));
					etm.setEntregadoTrafico(rs.getBoolean("entregadoTrafico"));
					etm.setAnalista_trafico(
							(rs.getString("analista_trafico") == null || rs.getString("analista_trafico").equals(""))
									? "-"
									: rs.getString("analista_trafico"));
					etm.setObservaciones_trafico((rs.getString("observaciones_trafico") == null
							|| rs.getString("observaciones_trafico").equals("")) ? "-"
									: rs.getString("observaciones_trafico"));
					etm.setCustoms_agent(
							(rs.getString("customs_agent") == null || rs.getString("customs_agent").equals("")) ? "-"
									: rs.getString("customs_agent"));
					etm.setCondicionpago_desc(etm.getCondicionpago() +"|"+ FuncionesComunesPLI.dameMapaCondicionPago(false).get(etm.getCondicionpago()));
					etm.setObs_reject_incidencia((rs.getString("obs_reject_incidencia") == null) ? "-":rs.getString("obs_reject_incidencia"));
					etm.setTotal(rs.getDouble("total") < 0 ? 0.0:rs.getDouble("total"));
					etm.setSubtotal(rs.getDouble("subtotal") < 0 ? 0.0:rs.getDouble("subtotal"));
					etm.setSubtotalfocs(rs.getDouble("subtotalfocs") < 0 ? 0.0:rs.getDouble("subtotalfocs"));
					etm.setSubtotalothers(rs.getDouble("subtotalothers") < 0 ? 0.0:rs.getDouble("subtotalothers"));
					etm.setFacturaProveedor((rs.getString("fac_proveedor") == null || rs.getString("fac_proveedor").equals(""))
							? "-"
							: rs.getString("fac_proveedor"));
					etm.setIdStatus(rs.getInt("factura_status"));
					etm.setPara_envio_a_trafico(rs.getString("para_envio_a_trafico"));
					
					etm.setTAnalist(
							rs.getString("tAnalist") == null || rs.getString("tAnalist").equals("")
							? "-"
					: rs.getString("tAnalist"));
		
					etm.setAnalistaAsignado(
							rs.getString("aa") == null || rs.getString("aa").equals("")
							? "-"
					: rs.getString("aa"));
					
					etm.setComentarioEmbarque(
							rs.getString("comment") == null || rs.getString("comment").equals("")
							? "-"
					: rs.getString("comment"));					
					etm.setEsSpecialties( rs.getBoolean("esSpecialties") );
					list.add(etm);

				}
				pstmt.close();
				rs.close();
			} catch (SQLException e) {
				try {
					ConexionDB.renuevaConexion(conn);
				} catch (Exception ex) {
					log.error(ex.getMessage(), ex);
				}
				log.error(e.getMessage(), e);
			}
		} catch (Exception e) {
			try {
				ConexionDB.devuelveConexion(conn);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} finally {
			try {
				ConexionDB.devuelveConexion(conn);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
		return list;
	}	
	

	@Override
	public Integer cancelComments(Facturacion factura, String username) {
		Connection con = null;
		int success = 0;
		try {
			con = ConexionDB.dameConexion();
			StringBuilder sql = new StringBuilder();
			sql.append("UPDATE FACTURACION ");
			sql.append("SET  factura_status = ").append(factura.getStatus());
			sql.append(" , comentarios_incidencias =  '");
			sql.append(factura.getComentarios()).append("'");
			sql.append(" WHERE numero_factura_pm =  '");
			sql.append(factura.getInvoiceNumber());
			sql.append("' and sar =  ");
			sql.append(factura.getFolio());
			try (PreparedStatement pst = con.prepareStatement(sql.toString())) {
				success = pst.executeUpdate();
			} catch (SQLException e) {
				e.printStackTrace();
				log.error(e.getStackTrace().toString(),e);
				log.info("Info: " + factura.getInvoiceNumber() == null ? "NULL " : factura.getInvoiceNumber(), e);
			}
		} catch (Exception e) {
			e.printStackTrace();
			log.info("Info: " + factura.getInvoiceNumber() == null ? "NULL " : factura.getInvoiceNumber(), e);
			log.error(e.getStackTrace().toString(),e);
		} finally {
			ConexionDB.devolver(con);
		}
		return success;
	}

	@Override
	public List<CatCorreccionModel> getCatCorreccion() {
		List<CatCorreccionModel> list = new ArrayList<CatCorreccionModel>();
		Connection con = null;
		int success = 0;
		try {
			con = ConexionDB.dameConexion();
			try (PreparedStatement pst = con.prepareStatement(SQL_CAT_CORRECCIONES)) {
				ResultSet rs = pst.executeQuery();
				while (rs.next()) {
					CatCorreccionModel r = new CatCorreccionModel();
					r.setId(rs.getInt("id"));
					r.setDescripcion(rs.getString("descripcion"));
					r.setCorreos(rs.getString("correos"));
					list.add(r);
				}
			} catch (SQLException e) {
				e.printStackTrace();
				log.info("Info getCatCorreccion: ", e);
			}
		} catch (Exception e) {
			e.printStackTrace();
			log.info("Info getCatCorreccion: ", e);

		} finally {
			ConexionDB.devolver(con);
		}
		return list;
	}

	@Override
	public Integer correccion(Facturacion factura, String user, String status) {
		Connection con = null;
		int success = 0;
		try {
			con = ConexionDB.dameConexion();
			StringBuilder sql = new StringBuilder();
			sql.append("UPDATE FACTURACION ");
			sql.append("SET  factura_status =  ").append(status);
			sql.append(" , comentarios_incidencias =  '");
			sql.append(factura.getDescripcionCorreccion()).append("--").append(factura.getComentarios()).append("',");
			sql.append(" usuario_rechazo = ").append("'").append(user).append("',");
			sql.append(" fecha_rechazo = ").append("GETDATE()");
			sql.append(" WHERE id = ");
			sql.append(factura.getId());
			sql.append(" and sar =  ");
			sql.append(factura.getFolio());
			try (PreparedStatement pst = con.prepareStatement(sql.toString())) {
				success = pst.executeUpdate();
			} catch (SQLException e) {
				e.printStackTrace();
				log.info("Info: " + factura.getInvoiceNumber() == null ? "NULL " : factura.getInvoiceNumber(), e);
			}
		} catch (Exception e) {
			e.printStackTrace();
			log.info("Info: " + factura.getInvoiceNumber() == null ? "NULL " : factura.getInvoiceNumber(), e);

		} finally {
			ConexionDB.devolver(con);
		}
		return success;
	}

	@Override
	public List<ControlEmbarqueModel> getListControlEmbarque(FiltroEntregaTrafico filtro) {
		List<ControlEmbarqueModel> list = new ArrayList<ControlEmbarqueModel>();
		Connection conn = null;
		StringBuilder final_query = new StringBuilder(SQL_CONTROL_EMBARQUES);

		if (filtro != null) {
			if (filtro.getFolio() != null && !filtro.getFolio().equals("")) {
				final_query.append(" AND s.folio = ").append(filtro.getFolio()).append(" ");
				filtro.setPaginaActual("0");
			}
			if (filtro.getBlNumber() != null && !filtro.getBlNumber().equals("")) {
				final_query.append(" AND s.BL = '").append(filtro.getBlNumber()).append("' ");
				filtro.setPaginaActual("0");
			}
			if (filtro.getBooking() != null && !filtro.getBooking().equals("")) {
				final_query.append(" AND s.booking = '").append(filtro.getBooking()).append("' ");
				filtro.setPaginaActual("0");
			}
			if (filtro.getContenedor() != null && !filtro.getContenedor().equals("")) {
				final_query.append(" AND s.contenedor = '").append(filtro.getContenedor()).append("' ");
				filtro.setPaginaActual("0");
			}
			if (filtro.getEtaFrom() != null && !filtro.getEtaFrom().equals("")) {
				final_query.append(" AND s.eta between ").append(filtro.getEtaFrom().toString().replaceAll("/", ""));
				if (filtro.getEtaTo() != null && !filtro.getEtaTo().equals("")) {
					final_query.append(" AND  ").append(filtro.getEtaTo().toString().replaceAll("/", ""));
				} else {
					final_query.append(" AND  ").append(filtro.getEtaFrom().toString().replaceAll("/", ""));
				}
				filtro.setPaginaActual("0");
			}

			if (filtro.getPaginaActual().equals("0")) {
				final_query.append(
						"order by s.eta desc, nav.nombre, ce.buqueSalida, pod2.nombre, s.contenedor DESC OFFSET ");
				final_query.append("0");
				final_query.append(" ROWS FETCH NEXT ").append(NUMBER_FIELDS).append(" ROWS ONLY");
			} else {
				final_query.append(
						"order by s.eta desc, nav.nombre, ce.buqueSalida, pod2.nombre, s.contenedor DESC OFFSET ");
				final_query.append("" + Integer.parseInt(filtro.getPaginaActual()));
				final_query.append(" ROWS FETCH NEXT ").append(NUMBER_FIELDS).append(" ROWS ONLY");
			}
		} else {
			final_query.append("ORDER BY s.eta desc, nav.nombre, ce.buqueSalida, pod2.nombre, s.contenedor DESC OFFSET 0 ROWS FETCH NEXT ").append(NUMBER_FIELDS)
					.append(" ROWS ONLY");
		}

	
		try {
			conn = ConexionDB.dameConexion();
			try (PreparedStatement pstmt = conn.prepareStatement(final_query.toString())) {

				Calendar calendar = Calendar.getInstance();
				calendar.setFirstDayOfWeek(Calendar.SUNDAY);
				calendar.setMinimalDaysInFirstWeek(4);

				ResultSet rs = pstmt.executeQuery();
				while (rs.next()) {

					ControlEmbarqueModel cem = new ControlEmbarqueModel();

					cem.setNaviera((rs.getString("nombre") == null || rs.getString("nombre").equals("")) ? "-"
							: rs.getString("nombre"));
					cem.setShippingLine(
							(rs.getString("shiiping_line") == null || rs.getString("shiiping_line").equals("")) ? "-"
									: rs.getString("shiiping_line"));
					cem.setBuqueSalida(
							(rs.getString("buqueSalida") == null || rs.getString("buqueSalida").equals("")) ? "-"
									: rs.getString("buqueSalida"));
					cem.setShipper((rs.getString("shipper") == null || rs.getString("shipper").equals("")) ? "-"
							: rs.getString("shipper"));
					cem.setBooking((rs.getString("booking") == null || rs.getString("booking").equals("")) ? "-"
							: rs.getString("booking"));
					cem.setBl((rs.getString("BL") == null || rs.getString("BL").equals("")) ? "-" : rs.getString("BL"));
					cem.setContenedor(
							(rs.getString("contenedor") == null || rs.getString("contenedor").equals("")) ? "-"
									: rs.getString("contenedor"));
					cem.setConso((rs.getString("consoFull") == null || rs.getString("consoFull").equals("")) ? "-"
							: rs.getString("consoFull"));
					cem.setEtd(rs.getString("etd") == null ? "-" : rs.getString("etd"));
					cem.setEta(rs.getString("eta") == null ? "-" : rs.getString("eta"));
					cem.setPuertoCarga(
							(rs.getString("puertoSalida") == null || rs.getString("puertoSalida").equals("")) ? "-"
									: rs.getString("puertoSalida"));
					cem.setPuertoDescarga(
							(rs.getString("puertoDescarga") == null || rs.getString("puertoDescarga").equals("")) ? "-"
									: rs.getString("puertoDescarga"));
					cem.setLugarEntrega(
							(rs.getString("lugarEntrega") == null || rs.getString("lugarEntrega").equals("")) ? "-"
									: rs.getString("lugarEntrega"));
					cem.setFolio((rs.getString("folio") == null || rs.getString("folio").equals("")) ? "-"
							: rs.getString("folio"));
					cem.setInstruccionBl(
							(rs.getString("instruccionBl") == null || rs.getString("instruccionBl").equals("")) ? "-"
									: rs.getString("instruccionBl"));
					calendar.setTime(cem.getEtd().length() >= 8
							? Date.valueOf(LocalDate.parse(cem.getEtd(), DateTimeFormatter.BASIC_ISO_DATE))
							: Timestamp.valueOf(LocalDateTime.now()));
					cem.setSemEtd(String.valueOf(calendar.get(Calendar.WEEK_OF_YEAR)));
					calendar.setTime(cem.getEta().length() >= 8
							? Date.valueOf(LocalDate.parse(cem.getEta(), DateTimeFormatter.BASIC_ISO_DATE))
							: Timestamp.valueOf(LocalDateTime.now()));
					cem.setSemEta(String.valueOf(calendar.get(Calendar.WEEK_OF_YEAR)));
					cem.setTipoCont(
							(rs.getString("tipoContenedor") == null || rs.getString("tipoContenedor").equals("")) ? "-"
									: rs.getString("tipoContenedor"));
					cem.setTipoEmb(
							(rs.getString("tipoProducto") == null || rs.getString("tipoProducto").equals("")) ? "-"
									: rs.getString("tipoProducto"));
					cem.setStatusDoc(
							(rs.getString("estatusDocumento") == null || rs.getString("estatusDocumento").equals(""))
									? "-"
									: rs.getString("estatusDocumento"));
					cem.setFechaLiberacionSDI(
							(rs.getString("fechaAprobadoSDI") == null || rs.getString("fechaAprobadoSDI").equals(""))
									? "-"
									: rs.getString("fechaAprobadoSDI"));
					cem.setSdiAnalist((rs.getString("analista") == null) ? "-" : rs.getString("analista"));
					cem.setStatus(rs.getInt("estatus"));
					cem.setNumber(rs.getInt("number"));
					cem.setTrafficAnalist((rs.getString("tAnalist") == null || rs.getString("tAnalist").equals(""))
							? "-"
							: rs.getString("tAnalist"));
					cem.setCustomAgent((rs.getString("aa") == null || rs.getString("aa").equals(""))
							? "-"
							: rs.getString("aa"));
					cem.setComment((rs.getString("comment") == null || rs.getString("comment").equals(""))
							? "-"
							: rs.getString("comment"));
					list.add(cem);

				}
				pstmt.close();
				rs.close();
			} catch (SQLException e) {
				try {
					ConexionDB.renuevaConexion(conn);
				} catch (Exception ex) {
					log.error(ex.getMessage(), ex);
				}
				log.error(e.getMessage(), e);
			}
		} catch (Exception e) {
			try {
				ConexionDB.devuelveConexion(conn);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} finally {
			try {
				ConexionDB.devuelveConexion(conn);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
		return list;
	}

	@Override
	public Integer enviaTrafico(Facturacion factura) {
		Connection con = null;
		int success = 0;
		try {
			con = ConexionDB.dameConexion();
			StringBuilder sql = new StringBuilder();
			sql.append(" UPDATE FACTURACION ");
			sql.append(" SET  para_envio_a_trafico =  1 , ");
			sql.append(" factura_status =  13 ,");
			sql.append(" observaciones_trafico =  '").append(factura.getComentarios()).append("' ");
			sql.append(" WHERE id =  ");
			sql.append(factura.getId());
			try (PreparedStatement pst = con.prepareStatement(sql.toString())) {
				success = pst.executeUpdate();
			} catch (SQLException e) {
				e.printStackTrace();
				log.info("Info enviaTrafico: " + factura.getId(), e);
			}
		} catch (Exception e) {
			e.printStackTrace();
			log.info("Info enviaTrafico: " + factura.getId(), e);

		} finally {
			ConexionDB.devolver(con);
		}
		return success;
	}

	public DataToSIFE getDataFacturacionByNoFacturaPm(Facturacion factura) {
		DataToSIFE datos = new DataToSIFE();
		Connection conn = null;


		try {

			conn = ConexionDB.dameConexion();
			PreparedStatement stmt = conn.prepareStatement(QUERY_DAT_FACTURACION_BY_FACTURA_PM);
			stmt.setString(1, factura.getNoFacturaPM());
			stmt.setInt(2, Integer.parseInt(factura.getSar()));
			ResultSet rs = stmt.executeQuery();

			while (rs.next()) {
				datos.setIdFacturacion(rs.getLong("id"));
				datos.setFolioOrigen(rs.getInt("folio") + "");
				datos.setNumeroProveedor(rs.getString("proveedor"));
				datos.setCondicionDePago(rs.getString("condicionPago"));
				datos.setSubtotal(rs.getDouble("total"));
				datos.setTotal(rs.getDouble("total"));
				datos.setOrdenDeCompra(rs.getString("pos").trim());
				datos.setMoneda(rs.getString("moneda"));
				datos.setCentroCostos(rs.getString("centro"));
				datos.setNumeroFactura(rs.getString("numero_factura_pm"));
				datos.setBooking(rs.getString("booking"));
				datos.setCliente(rs.getString("cliente"));
				datos.setDocumentoSociedad(rs.getString("documentoSociedad"));
				datos.setDocumentoEjercicio(rs.getString("documentoEjercicio"));
				datos.setDocumentoNumero(rs.getString("documentoNumero"));
				datos.setDiasPago(rs.getInt("diasPago"));
				datos.setBl(rs.getString("bl"));
				datos.setContenedor(rs.getString("contenedor"));
				datos.setConcepto(rs.getString("facturaProveedor"));
			}

		} catch (Exception e) {
			log.error(e.getMessage(), e);

		} finally {
			ConexionDB.devolver(conn);
		}

		return datos;
	}


	@Override
	public Integer updateStatusById(Facturacion factura, boolean peticionCuarentaYCinco, boolean peticionDieciNueve) {
		Connection conn = null;
		Integer resultado = null;

		try {
			conn = ConexionDB.dameConexion();

			StringBuilder query = new StringBuilder();
			query.append("UPDATE FACTURACION ");
			query.append("SET factura_status = ? , ");
			
			if(peticionCuarentaYCinco) {
				query.append("estatus_cuarenta_tres=1," );
			}
			if(peticionDieciNueve) {
				query.append("estatus_diecinueve=1, " );
			}
			
			query.append(" sife_observaciones = ? ");
			query.append("WHERE id = ? ");

			PreparedStatement stmt = conn.prepareStatement(query.toString());
			stmt.setInt(1, factura.getStatusId());
			stmt.setString(2, factura.getComentarios());
			stmt.setLong(3, factura.getId());

			resultado = stmt.executeUpdate();

		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			log.error(e.getMessage(), e);
			e.printStackTrace();
		}finally {
			try {
				ConexionDB.devuelveConexion(conn);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}

		return resultado;

	}

	@Override
	public Integer setIncidenciaById(Facturacion factura, Connection con) {
		Connection conn = null;
		Integer resultado = null;

		try {
			conn = ConexionDB.dameConexion();
			StringBuilder query = new StringBuilder();
			query.append("UPDATE FACTURACION ");
			query.append("SET comentarios_incidencias = ?, ");
			query.append("incidencia = ?, ");
			query.append("area_responsable_solucion = ?, ");
			query.append("factura_status = ? ");
			query.append("WHERE id = ?");

			PreparedStatement stmt = conn.prepareStatement(query.toString());
			stmt.setString(1, factura.getComentarios());
			stmt.setInt(2, Integer.parseInt(factura.getIncidenciasEnFacturas()));
			stmt.setInt(3, Integer.parseInt(factura.getAreaResponsableSolucion()));
			stmt.setInt(4, Integer.parseInt(factura.getStatus()));
			stmt.setLong(5, factura.getId());

			resultado = stmt.executeUpdate();
			stmt.close();

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e.getMessage(), e);
		} finally {
			ConexionDB.devolver(conn);
		}
		return resultado;
	}

	@Override
	public List<DataFactura> getDataRefacturacionById(Long id, Connection con) {

		List<DataFactura> datosSar = new ArrayList<DataFactura>();
		Connection conn = con;


		try {

			conn = con == null ? ConexionDB.dameConexion() : con;
			PreparedStatement pstmt = conn.prepareStatement(QUERY_FACTURACION_BY_ID);
			pstmt.setLong(1, id);
			ResultSet rs = pstmt.executeQuery();

			while (rs.next()) {
				DataFactura dato = new DataFactura();
				dato.setFolio(rs.getString("folio"));
				dato.setProveedor(rs.getString("proveedor"));
				dato.setContenedor(rs.getString("contenedor").trim());
				dato.setBL(rs.getString("BL"));
				dato.setCondicionPago(rs.getString("condicionPago"));
				dato.setPo(rs.getString("po").trim());
				dato.setPosicion(rs.getString("posicion"));
				dato.setCantidad(rs.getDouble("cantidad"));
				dato.setCantidadUnidadMedida(rs.getDouble("cantidad"));
				dato.setPrioridad(rs.getInt("prioridad"));
				dato.setMaterial(rs.getInt("material"));
				dato.setShipmentType( rs.getBoolean("esAereo") ? "AEREO": "Sea Shipping" );
				dato.setPod(rs.getString("puertoDescarga"));
				dato.setEtd(rs.getInt("etd"));
				dato.setEtdFinal(rs.getInt("etdFinal"));
				dato.setPaisOrigen(rs.getString("paisorigen"));
				dato.setFacturaProveedor(rs.getString("factura_proveedor"));
				datosSar.add(dato);

			}
			
			
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}finally {
			try {
				if(con == null)
					ConexionDB.devuelveConexion(conn);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}

		return datosSar;
	}

	@Override
	public Integer updateFacturaPODetalleFacturacion(Long id, String facturaPM) {
		Connection conn = null;
		Integer resultado = null;

		try {
			conn = ConexionDB.dameConexion();
			StringBuilder query = new StringBuilder();
			query.append("UPDATE cdiPODetalleFacturacion ");
			query.append("SET facturaPM = ? ");
			query.append("WHERE idFacturacion = ?");

			PreparedStatement stmt = conn.prepareStatement(query.toString());
			stmt.setString(1, facturaPM);
			stmt.setLong(2, id);


			resultado = stmt.executeUpdate();
			stmt.close();

		} catch (Exception e) {
			log.error(e.getMessage(), e);

		} finally {
			try {
				ConexionDB.devuelveConexion(conn);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
		return resultado;
	}
	
	
	@Override
public List<FacturacionReporte> getListReportDAO(FacturacionReporte facturacionReporteFiltro) {
		//List<FacturacionReporte> listFacturacionReport = new ArrayList<FacturacionReporte>();
		List<FacturacionReporte> listFacturacion = new ArrayList<FacturacionReporte>();
		Connection conn = null;
		ResponseVO respuesta = new ResponseVO();

		if (facturacionReporteFiltro.getPo() != null && !facturacionReporteFiltro.getPo().equals("")) {
			// EJECUTA SQL CON PO
			StringBuilder queryPO = new StringBuilder(SQLPO);

			try {
				// 1.- folio--> tipo entero
				if (facturacionReporteFiltro.getFolio() != null && !facturacionReporteFiltro.getFolio().equals("")) {
					queryPO.append(" AND s.folio=  ");
					queryPO.append(facturacionReporteFiltro.getFolio());
				}
				// 2.- supplier
				if (facturacionReporteFiltro.getSupplier() != null && !facturacionReporteFiltro.getSupplier().equals("")) {
					queryPO.append(" AND s.proveedor = '");
					queryPO.append(facturacionReporteFiltro.getSupplier()).append("'");
				}
				// 3 .- priority
				if (facturacionReporteFiltro.getPriority() != null && !facturacionReporteFiltro.getPriority().equals("")
						&& !facturacionReporteFiltro.getPriority().equals("-1")) {
					queryPO.append(" AND priority=  ");
					queryPO.append(facturacionReporteFiltro.getPriority());
				}
				// 4.- po
				if (facturacionReporteFiltro.getPo() != null && !facturacionReporteFiltro.getPo().equals("")) {
					queryPO.append(" AND (SELECT TOP 1 po FROM cdiSARDetalle WHERE folio = s.folio AND po = '");
					queryPO.append(facturacionReporteFiltro.getPo()).append("'");
					queryPO.append(" ) = '");
					queryPO.append(facturacionReporteFiltro.getPo()).append("'");
					queryPO = new StringBuilder(queryPO.toString().replace("@@PO@@",
							", (SELECT TOP 1 po FROM cdiSARDetalle WHERE folio = s.folio AND po = '" + facturacionReporteFiltro.getPo()
									+ "') as po "));
				}
				// 5.- carrier
				if (facturacionReporteFiltro.getCarrier() != null && !facturacionReporteFiltro.getCarrier().equals("")
						&& !facturacionReporteFiltro.getCarrier().equals("-1")) {
					queryPO.append(" AND s.naviera=  ");
					queryPO.append(facturacionReporteFiltro.getCarrier());
				}
				// 6 .- BL Number
				if (facturacionReporteFiltro.getBlNumber() != null && !facturacionReporteFiltro.getBlNumber().equals("")) {
					queryPO.append(" AND s.BL = '");
					queryPO.append(facturacionReporteFiltro.getBlNumber()).append("'");
				}
				// 7 .- Analyst
				if (facturacionReporteFiltro.getAnalyst() != null && !facturacionReporteFiltro.getAnalyst().equals("")
						&& !facturacionReporteFiltro.getAnalyst().equals("-1")) {
					queryPO.append(" AND analys=  '");
					queryPO.append(facturacionReporteFiltro.getAnalyst()).append("'");
				}
				// 8.- POD
				if (facturacionReporteFiltro.getPod() != null && !facturacionReporteFiltro.getPod().equals("") && !facturacionReporteFiltro.getPod().equals("-1")) {
					queryPO.append(" AND POD=  '");
					queryPO.append(facturacionReporteFiltro.getPod()).append("'");
				}
				// 9.- Booking
				if (facturacionReporteFiltro.getBooking() != null && !facturacionReporteFiltro.getBooking().equals("")) {
					queryPO.append(" AND s.booking =   '");
					queryPO.append(facturacionReporteFiltro.getBooking()).append("'");
				}
				// 10 .- Invoice Number
				if (facturacionReporteFiltro.getInvoiceNumber() != null && !facturacionReporteFiltro.getInvoiceNumber().equals("")) {
					queryPO.append(" AND f.numero_factura_pm=  '");
					queryPO.append(facturacionReporteFiltro.getInvoiceNumber()).append("'");
				}
				// 11 .- Container
				if (facturacionReporteFiltro.getContainer() != null && !facturacionReporteFiltro.getContainer().equals("")) {
					queryPO.append(" AND contenedor = '");
					queryPO.append(facturacionReporteFiltro.getContainer()).append("'");
				} // ETA
				if (facturacionReporteFiltro.getEtaFrom() != null && !facturacionReporteFiltro.getEtaFrom().equals("")) {
					queryPO.append(" AND s.eta  BETWEEN ");
					queryPO.append(facturacionReporteFiltro.getEtaFrom().toString().replaceAll("/", ""));
				}
				if (facturacionReporteFiltro.getEtaTo() != null && !facturacionReporteFiltro.getEtaTo().equals("")) {
					queryPO.append(" AND ");
					queryPO.append(facturacionReporteFiltro.getEtaTo().replaceAll("/", ""));
				}

				if (facturacionReporteFiltro.getCodigoEstatusFactura() != null && !facturacionReporteFiltro.getCodigoEstatusFactura().equals("")
						&& !facturacionReporteFiltro.getCodigoEstatusFactura().equals("-1")) {
					queryPO.append(" AND f.factura_status=  '");
					queryPO.append(facturacionReporteFiltro.getCodigoEstatusFactura()).append("'");
				} else {
					queryPO.append(" AND f.factura_status IN (1,3,5,6)");
					queryPO.append(" ORDER BY  fecha_SDI  ASC;");
				}

				conn = ConexionDB.dameConexion();
				try (PreparedStatement pstmt = conn.prepareStatement(queryPO.toString())) {
					
					ResultSet rs = pstmt.executeQuery();
					while (rs.next()) {
						FacturacionReporte facturacion = new FacturacionReporte();
						// ID_STATUS
						facturacion.setStatusId(rs.getInt("STATUS_ID"));

						// Id
						facturacion.setId(rs.getLong("id"));
						// PROCESO MANUAL/AUTOMATICO
						facturacion.setAutomatico(rs.getBoolean("proceso_automatico_o_manual"));
						// AREA_QUE_SOLICITA_RECHAZO
						facturacion.setFechaHoraAprobacionSDI(cambiarFechaSDI(rs.getString("fecha_SDI")));
						// am_pm
						facturacion.setAmpm(rs.getString("am_pm").toUpperCase());
						// No_Factura_pm
						facturacion.setNoFacturaPM(rs.getString("no_factura_pm"));
						// FACTURA PROVEEDOR
						facturacion.setFacturaProvedor(rs.getString("factura_proveedor"));
						// MONTO_USD
						facturacion.setMontoUSD(validaMonto(rs.getString("monto_usd")));
						// FECHA_EMISION
						facturacion.setFechaEmision(rs.getString("fecha_emision"));
						// FACTURISTA
						facturacion.setFacturista(rs.getString("facturista"));
						// STATUS_FACTURACION
						facturacion.setStatus(rs.getString("status_facturacion"));
						// TYPE_INSIDENCIA
						facturacion.setIncidenciasEnFacturas(rs.getString("type_insidencia"));
						// COMENTARIOAS
						facturacion.setComentarios(rs.getString("comentarios"));
						// SUPPLIER
						facturacion.setSupplier(rs.getString("supplier"));
						// ETA
						facturacion.setEta(cambiarFecha(rs.getString("eta")));
						// NUMBER BOOKING
						facturacion.setBooking(rs.getString("number_booking"));
						// folio
						facturacion.setFolio(rs.getString("folio"));
						// BL_NUMBER
						facturacion.setBlNumber(rs.getString("BL_Number"));
						// POD
						facturacion.setPod(rs.getString("POD"));
						// SHIPMENT_TYPE
						facturacion.setShipmentType(rs.getString("Shipment_Type"));
						// PRIORITY
						facturacion.setPriority(rs.getString("priority"));
						// ANALISTA_SDI
						facturacion.setAnalyst(rs.getString("Analista_SDI"));
						// CONTENEDOR
						facturacion.setContainer(rs.getString("contenedor"));
						
						
						//ImportacionesProveedoresBean bean_prov_client = FuncionesComunesPLI.getProveedor(facturacion.getSupplier());

						//facturacion.setNombreProveedor(bean_prov_client.getNombreProveedor());
						
						facturacion.setNombreProveedor("");
						if( facturacion.getSupplier() != null && !facturacion.getSupplier().equals("") &&  !facturacion.getSupplier().isEmpty() ) {
							ImportacionesProveedoresBean bean_prov_client = FuncionesComunesPLI.getProveedor(facturacion.getSupplier());
							
							if( bean_prov_client != null &&  bean_prov_client.getNombreProveedor() != null ) {
								facturacion.setNombreProveedor(bean_prov_client.getNombreProveedor());
							}
						}

						listFacturacion.add(facturacion);
					}
				} catch (SQLException e) {
					try {
						ConexionDB.renuevaConexion(conn);
					} catch (Exception ex) {
						log.error(ex.getMessage(), ex);
					}
					log.error(e.getMessage(), e);
				}

			} catch (Exception e) {
				try {
					ConexionDB.devuelveConexion(conn);
				} catch (Exception ex) {
					log.error(ex.getMessage(), ex);
				}
				log.error(e.getMessage(), e);
			} finally {
				try {
					ConexionDB.devuelveConexion(conn);
				} catch (Exception sqlEx2) {
					log.error(sqlEx2.getMessage(), sqlEx2);
				}
			}

		} else {
			// Sin PO

			StringBuilder query = new StringBuilder(QueriresFacturacionSQL.SQL_LISTA_FACTURACION);

			try {
				// 1.- folio--> tipo entero
				if (facturacionReporteFiltro.getFolio() != null && !facturacionReporteFiltro.getFolio().equals("")) {
					query.append(" AND s.folio=  ");
					query.append(facturacionReporteFiltro.getFolio());
				}
				// 2.- supplier
				if (facturacionReporteFiltro.getSupplier() != null && !facturacionReporteFiltro.getSupplier().equals("")) {
					query.append(" AND s.proveedor = '");
					query.append(facturacionReporteFiltro.getSupplier()).append("'");
				}
				// 3 .- priority
				if (facturacionReporteFiltro.getPriority() != null && !facturacionReporteFiltro.getPriority().equals("")
						&& !facturacionReporteFiltro.getPriority().equals("-1")) {
					query.append(" AND priority=  ");
					query.append(facturacionReporteFiltro.getPriority());
				}
				// 4.- po
				if (facturacionReporteFiltro.getPo() != null && !facturacionReporteFiltro.getPo().equals("")) {
					query.append(" AND sd.po=  '");
					query.append(facturacionReporteFiltro.getPo()).append("'");
				}
				// 5.- carrier
				if (facturacionReporteFiltro.getCarrier() != null && !facturacionReporteFiltro.getCarrier().equals("")
						&& !facturacionReporteFiltro.getCarrier().equals("-1")) {
					query.append(" AND s.naviera=  ");
					query.append(facturacionReporteFiltro.getCarrier());
				}
				// 6 .- BL Number
				if (facturacionReporteFiltro.getBlNumber() != null && !facturacionReporteFiltro.getBlNumber().equals("")) {
					query.append(" AND s.BL = '");
					query.append(facturacionReporteFiltro.getBlNumber()).append("'");
				}
				// 7 .- Analyst
				if (facturacionReporteFiltro.getAnalyst() != null && !facturacionReporteFiltro.getAnalyst().equals("")
						&& !facturacionReporteFiltro.getAnalyst().equals("-1")) {
					query.append(" AND analys=  '");
					query.append(facturacionReporteFiltro.getAnalyst()).append("'");
				}
				// 8.- POD
				if (facturacionReporteFiltro.getPod() != null && !facturacionReporteFiltro.getPod().equals("") && !facturacionReporteFiltro.getPod().equals("-1")) {
					query.append(" AND POD=  '");
					query.append(facturacionReporteFiltro.getPod()).append("'");
				}
				// 9.- Booking
				if (facturacionReporteFiltro.getBooking() != null && !facturacionReporteFiltro.getBooking().equals("")) {
					query.append(" AND s.booking =   '");
					query.append(facturacionReporteFiltro.getBooking()).append("'");
				}
				// 10 .- Invoice Number
				if (facturacionReporteFiltro.getInvoiceNumber() != null && !facturacionReporteFiltro.getInvoiceNumber().equals("")) {
					query.append(" AND fact.nombre=  '");
					query.append(facturacionReporteFiltro.getInvoiceNumber()).append("'");
				}
				// 11 .- Container
				if (facturacionReporteFiltro.getContainer() != null && !facturacionReporteFiltro.getContainer().equals("")) {
					query.append(" AND contenedor = '");
					query.append(facturacionReporteFiltro.getContainer()).append("'");
				} // ETA
				if (facturacionReporteFiltro.getEtaFrom() != null && !facturacionReporteFiltro.getEtaFrom().equals("")) {
					query.append(" AND s.eta  BETWEEN ");
					query.append(facturacionReporteFiltro.getEtaFrom().toString().replaceAll("/", ""));
				}
				if (facturacionReporteFiltro.getEtaTo() != null && !facturacionReporteFiltro.getEtaTo().equals("")) {
					query.append(" AND ");
					query.append(facturacionReporteFiltro.getEtaTo().replaceAll("/", ""));
				}
				if (facturacionReporteFiltro.getCarrier() != null && !facturacionReporteFiltro.getCarrier().equals("")
						&& !facturacionReporteFiltro.getCarrier().equals("-1")) {
					query.append(" AND s.naviera=  ");
					query.append(facturacionReporteFiltro.getCarrier());
				}

				if (facturacionReporteFiltro.getCodigoEstatusFactura() != null && !facturacionReporteFiltro.getCodigoEstatusFactura().equals("")
						&& !facturacionReporteFiltro.getCodigoEstatusFactura().equals("-1")) {
					query.append(" AND f.factura_status=  ");
					query.append(facturacionReporteFiltro.getCodigoEstatusFactura());
					// query.append(filtro.getCodigoEstatusFactura()).append("'");
				} else {
					query.append(" AND f.factura_status IN (1,3,4,5,6,7)");
					query.append(" ORDER BY  fecha_SDI  ASC;");
				}

				conn = ConexionDB.dameConexion();
				try (PreparedStatement pstmt = conn.prepareStatement(query.toString())) {
					ResultSet rs = pstmt.executeQuery();
				
					while (rs.next()) {
						FacturacionReporte facturacion = new FacturacionReporte();
						// ID_STATUS
						facturacion.setStatusId(rs.getInt("STATUS_ID"));

						// Id
						facturacion.setId(rs.getLong("id"));
						// PROCESO MANUAL/AUTOMATICO
						facturacion.setAutomatico(rs.getBoolean("proceso_automatico_o_manual"));
						// AREA_QUE_SOLICITA_RECHAZO
						facturacion.setFechaHoraAprobacionSDI(cambiarFechaSDI(rs.getString("fecha_SDI")));
						// am_pm
						facturacion.setAmpm(rs.getString("am_pm").toUpperCase());
						// No_Factura_pm
						facturacion.setNoFacturaPM(rs.getString("no_factura_pm"));
						// FACTURA PROVEEDOR
						facturacion.setFacturaProvedor(rs.getString("factura_proveedor"));
						// MONTO_USD
						facturacion.setMontoUSD(validaMonto(rs.getString("monto_usd")));
						// FECHA_EMISION
						facturacion.setFechaEmision(rs.getString("fecha_emision"));
						// FACTURISTA
						facturacion.setFacturista(rs.getString("facturista"));
						// STATUS_FACTURACION
						facturacion.setStatus(rs.getString("status_facturacion"));
						// TYPE_INSIDENCIA
						facturacion.setIncidenciasEnFacturas(rs.getString("type_insidencia"));
						// COMENTARIOAS
						facturacion.setComentarios(rs.getString("comentarios"));
						// SUPPLIER
						facturacion.setSupplier(rs.getString("supplier"));
						// ETA
						facturacion.setEta(cambiarFecha(rs.getString("eta")));
						// NUMBER BOOKING
						facturacion.setBooking(rs.getString("number_booking"));
						// folio
						facturacion.setFolio(rs.getString("folio"));
						// BL_NUMBER
						facturacion.setBlNumber(rs.getString("BL_Number"));
						// POD
						facturacion.setNombre_puerto_descarga(rs.getString("nombre_puerto_descarga"));
						facturacion.setPod(rs.getString("POD"));
						// SHIPMENT_TYPE
						facturacion.setShipmentType(rs.getString("Shipment_Type"));
						// PRIORITY
						facturacion.setPriority(rs.getString("priority"));
						// ANALISTA_SDI
						facturacion.setAnalyst(rs.getString("Analista_SDI"));
						// CONTENEDOR
						facturacion.setContainer(rs.getString("contenedor"));
						
						
						//ImportacionesProveedoresBean bean_prov_client = FuncionesComunesPLI.getProveedor(facturacion.getSupplier());
						
						//facturacion.setNombreProveedor(bean_prov_client.getNombreProveedor());
						facturacion.setNombreProveedor("");
						try {
						if( facturacion.getSupplier() != null && !facturacion.getSupplier().equals("") &&  !facturacion.getSupplier().isEmpty() ) {
							ImportacionesProveedoresBean bean_prov_client = FuncionesComunesPLI.getProveedor(facturacion.getSupplier());
							
							if( bean_prov_client != null &&  bean_prov_client.getNombreProveedor() != null ) {
								facturacion.setNombreProveedor(bean_prov_client.getNombreProveedor());
							}
							
						}
							
						}catch (Exception e) {
							log.info(e.getMessage(),e);
							
						}
						
						listFacturacion.add(facturacion);

					}
				} catch (SQLException e) {
					try {
						ConexionDB.renuevaConexion(conn);
					} catch (Exception ex) {
						log.error(ex.getMessage(), ex);
						respuesta.setMensaje(Mensajes.MSG_ERROR.getMensaje());
					}
					log.error(e.getMessage(), e);
					respuesta.setMensaje(Mensajes.MSG_ERROR.getMensaje());
				}

			} catch (Exception e) {
				try {
					ConexionDB.devuelveConexion(conn);
					
					respuesta.setMensaje(Mensajes.MSG_ERROR.getMensaje());
					respuesta.setTipoMensaje(Mensajes.TIPO_ERROR.getMensaje());
					listFacturacion.removeAll(listFacturacion);
					return listFacturacion;
				} catch (Exception ex) {
					log.error(ex.getMessage(), ex);
					respuesta.setMensaje(Mensajes.MSG_ERROR.getMensaje());
				}
				log.error(e.getMessage(), e);
				respuesta.setMensaje(Mensajes.MSG_ERROR.getMensaje());
			} finally {
				try {
					ConexionDB.devuelveConexion(conn);
				} catch (Exception sqlEx2) {
					log.error(sqlEx2.getMessage(), sqlEx2);
					respuesta.setMensaje(Mensajes.MSG_ERROR.getMensaje());
				}
			}

		}
		
		return listFacturacion;

			
	}

	


	@Override
	public Integer ActualizaStatusSIFE(Facturacion factura) {
		Connection conn = null;
		Integer resultado = null;

		try {
			conn = ConexionDB.dameConexion();
			StringBuilder query = new StringBuilder();
			query.append("UPDATE facturacion ");
			query.append("SET statusSIFE = ?, ");
			query.append("FechaActulizacionStatusSIFE = ?, ");
			query.append("idStatusSIFE = ? ");
			query.append("WHERE FolioSIFE = ? OR FolioSIFE43 = ?");

			PreparedStatement stmt = conn.prepareStatement(query.toString());
			stmt.setString(1, factura.getDescriStatusSIFE());
			stmt.setString(2, factura.getFechaActualizaStatusSIFE());
			stmt.setInt(3, factura.getStatusSIFE());
			stmt.setLong(4, factura.getFolioSIFE());
			stmt.setLong(5, factura.getFolioSIFE());

			resultado = stmt.executeUpdate();
			stmt.close();

		} catch (Exception e) {
			e.printStackTrace();

		} finally {
			try {
				ConexionDB.devuelveConexion(conn);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
		return resultado;
	}

	@Override
	public List<ReporteSemanalIncidencias> getReporteSemanalIncidencias() {
	
		List<ReporteSemanalIncidencias> listReporteSemanalIncidencias = new ArrayList<ReporteSemanalIncidencias>();
		Connection conn = null;

		try {
			conn = ConexionDB.dameConexion();
			try (PreparedStatement pstmt = conn.prepareStatement(QueriresFacturacionSQL.SQL_LISTA_FACTURACION_REPORTE)) {
				ResultSet rs = pstmt.executeQuery();
				while (rs.next()) {
					ReporteSemanalIncidencias reporteSI = new ReporteSemanalIncidencias();
					reporteSI.setIdIncidencia("IFA.id_incidencia");
					reporteSI.setDescripcion("CI.descripcion");
					reporteSI.setTiempoSolucion("tiempo_solucion");
					listReporteSemanalIncidencias.add(reporteSI);
				}
				pstmt.close();
				rs.close();
			} catch (SQLException e) {
				try {
					ConexionDB.renuevaConexion(conn);
				} catch (Exception ex) {
					log.error(ex.getMessage(), ex);
				}
				log.error(e.getMessage(), e);
			}
		} catch (Exception e) {
			try {
				ConexionDB.devuelveConexion(conn);
			} catch (Exception ex) {
				log.error(ex.getMessage().toString(), ex);
			}
			log.error(e.getMessage(), e);
		} finally {
			try {
				ConexionDB.devuelveConexion(conn);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
	}
		return listReporteSemanalIncidencias;
	}

	@Override
	public Integer ActualizaAnalistaSDI(DataFactura data) {
		Connection conn = null;
		Integer resultado = 0;
		
		try {
			conn = ConexionDB.dameConexion();
			
			StringBuilder query = new StringBuilder();
			query.append("UPDATE cdiControlSDI ");
			query.append("SET analista = ? ");
			query.append("WHERE proveedor = ? AND booking = ? ");

			PreparedStatement stmt = conn.prepareStatement(query.toString());
			stmt.setString(1, data.getAnalistaSDI() );
			stmt.setString(2, data.getProveedor() );
			stmt.setString(3, data.getBooking() );

			
			resultado = stmt.executeUpdate();
			stmt.close();
			
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			log.error(e.getMessage(), e);
			e.printStackTrace();
		}finally {
			try {
				ConexionDB.devuelveConexion(conn);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}

		return resultado;
	}

	@Override
	public Facturacion getFolioByFolioSife(Long folioSIFE) {
		
		Connection conn = null;
		Facturacion facAux = null;
			
			try {
				conn = ConexionDB.dameConexion();
				
				StringBuilder query = new StringBuilder();
				query.append("select sar from facturacion f where FolioSIFE = ?");

				
				PreparedStatement pstmt = conn.prepareStatement(query.toString());
				pstmt.setLong(1, folioSIFE);
				ResultSet rs = pstmt.executeQuery();
				
				while (rs.next()) {
					facAux = new Facturacion();
					Integer folio = rs.getInt("sar");
					facAux.setFolio( folio.toString() );

				}
				pstmt.close();
				
				
			} catch (ClassNotFoundException e) {
				log.error(e.getMessage(), e);
				e.printStackTrace();
			} catch (SQLException e) {
				log.error(e.getMessage(), e);
				e.printStackTrace();
			}finally {
				try {
					ConexionDB.devuelveConexion(conn);
				} catch (Exception sqlEx2) {
					log.error(sqlEx2.getMessage(), sqlEx2);
				}
			}

		return facAux;
	}

		
	public boolean deleteFact(Integer idFact) {
		// TODO Auto-generated method stub
		return false;
	}

	
	@Override
	public Integer rejectIncidence(Facturacion filtro, String userName, String status) throws Exception {
		Connection conn = null;
		Integer resultado = null;

		try {
			conn = ConexionDB.dameConexion();
			StringBuilder query = new StringBuilder();
			query.append("UPDATE facturacion ");
			query.append("SET factura_status = ? , ");
			query.append("obs_reject_incidencia = ? ");
			query.append("WHERE id = ? ");

			PreparedStatement stmt = conn.prepareStatement(query.toString());
			stmt.setInt(1, Integer.parseInt(status));
			stmt.setString(2, filtro.getComentarios());
			stmt.setLong(3, Long.parseLong(filtro.getInvoiceNumber()));
			resultado = stmt.executeUpdate();
			stmt.close();

		} catch (Exception e) {
			log.error(e.getMessage(), e);
			throw e;

		} finally {
			try {
				ConexionDB.devuelveConexion(conn);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
		return resultado;

	}

	@Override

	public List<Integer> getMaterialBySarAndFactura(String sar, String noFacturaPM) {
		Connection conn = null;
		List<Integer> lstMateriales = new ArrayList<>();
			
			try {
				conn = ConexionDB.dameConexion();
				PreparedStatement pstmt = conn.prepareStatement(QUERY_MATERIAL_BYSAR_AND_FACTURA);
				pstmt.setString(1, sar);
				pstmt.setString(2, noFacturaPM);
				ResultSet rs = pstmt.executeQuery();
				
				while (rs.next()) {
					
					Integer material = rs.getInt("material");
					lstMateriales.add(material);

				}
				pstmt.close();
				
			} catch (ClassNotFoundException e) {
				log.error(e.getMessage(), e);
				e.printStackTrace();
			} catch (SQLException e) {
				log.error(e.getMessage(), e);
				e.printStackTrace();
			}finally {
				try {
					ConexionDB.devuelveConexion(conn);
				} catch (Exception sqlEx2) {
					log.error(sqlEx2.getMessage(), sqlEx2);
				}
			}

		return lstMateriales;
	}
	public boolean borraIncidencia(Facturacion factura, Connection con) throws ClassNotFoundException, SQLException {
		
		Connection conn = con;
		int resultado = 0;
		try {
		conn = con == null ? ConexionDB.dameConexion() : con;
		StringBuilder query = new StringBuilder();
		query.append("UPDATE FACTURACION ");
		query.append("SET incidencia = NULL ");
		query.append("WHERE id = ? ");

		PreparedStatement stmt = conn.prepareStatement(query.toString());
		stmt.setLong(1, factura.getId());

		resultado = stmt.executeUpdate();
	} catch (SQLException e) {
		log.error(e.getMessage(), e);
		e.printStackTrace();
	}finally {
		try {
			 if(con == null)
				 ConexionDB.devuelveConexion(conn);
		} catch (Exception sqlEx2) {
			log.error(sqlEx2.getMessage(), sqlEx2);
		}
	}
		return resultado == 1;
		
		
	}
	
	@Override
	public boolean setStatusFactura(Facturacion factura, Connection con) throws ClassNotFoundException, SQLException {
		
		Connection conn = con;
		int resultado = 0;
		try {
		conn = con == null ? ConexionDB.dameConexion() : con;
		StringBuilder query = new StringBuilder();
		query.append("UPDATE FACTURACION ");
		query.append("SET factura_status = ?, ");
		query.append("comentarios_incidencias= ? ");
		query.append("WHERE id = ?  ");

		PreparedStatement stmt = conn.prepareStatement(query.toString());
		stmt.setInt(1, Integer.parseInt(factura.getStatus()));
		stmt.setString(2, factura.getComentarios());
		stmt.setLong(3, factura.getId());

		resultado = stmt.executeUpdate();
	} catch (ClassNotFoundException e) {
		log.error(e.getMessage(), e);
		e.printStackTrace();
	} catch (SQLException e) {
		log.error(e.getMessage(), e);
		e.printStackTrace();
	}finally {
		try {
			 if(con == null)
				 ConexionDB.devuelveConexion(conn);
		} catch (Exception sqlEx2) {
			log.error(sqlEx2.getMessage(), sqlEx2);
		}
	}
		return resultado == 1;
	}
	
	@Override
	public boolean setStatusFacturacionByFolio(Facturacion factura, Connection con) {
		
		Connection conn = con;
		int resultado = 0;
		try {
		conn = con == null ? ConexionDB.dameConexion() : con;
		StringBuilder query = new StringBuilder();
		query.append("UPDATE FACTURACION ");
		query.append("SET factura_status = ?, ");
		query.append("comentarios_incidencias= ? ");
		query.append("WHERE sar = ?  ");

		PreparedStatement stmt = conn.prepareStatement(query.toString());
		stmt.setInt(1, Integer.parseInt(factura.getStatus()));
		stmt.setString(2, factura.getComentarios());
		stmt.setLong(3, Long.parseLong(factura.getSar()));

		resultado = stmt.executeUpdate();
	} catch (ClassNotFoundException e) {
		log.error(e.getMessage(), e);
		e.printStackTrace();
	} catch (SQLException e) {
		log.error(e.getMessage(), e);
		e.printStackTrace();
	}finally {
		try {
			 if(con == null)
				 ConexionDB.devuelveConexion(conn);
		} catch (Exception sqlEx2) {
			log.error(sqlEx2.getMessage(), sqlEx2);
		}
	}
		return resultado == 1;
	}

	public String getNumerosDeDocumentos(Facturacion factura) {
		Connection conn = null;
		List<String> documentosNumero = new ArrayList<String>();	
			try {
				conn = ConexionDB.dameConexion();
				
				StringBuilder query = new StringBuilder();
				
				query.append("SELECT documentoNumero " );
				query.append("FROM facturacion " );
				query.append("WHERE sar = ? and condicionPago = ? " );
				
				PreparedStatement pstmt = conn.prepareStatement(query.toString());
				pstmt.setInt(1, Integer.parseInt(factura.getSar() ) );
				pstmt.setString(2, factura.getCondicionPago() );
				ResultSet rs = pstmt.executeQuery();
				
				
				
				while (rs.next()) {
					
					documentosNumero.add( rs.getString("documentoNumero") ) ;

				}
				pstmt.close();
				
			} catch (ClassNotFoundException e) {
				log.error(e.getMessage(), e);
				e.printStackTrace();
			} catch (SQLException e) {
				log.error(e.getMessage(), e);
				e.printStackTrace();
			}finally {
				try {
					ConexionDB.devuelveConexion(conn);
				} catch (Exception sqlEx2) {
					log.error(sqlEx2.getMessage(), sqlEx2);
				}
			}

		return String.join(",", documentosNumero);
	}

	@Override
	public Long getEstatusFacturaSife(Long id, boolean peticionCuarentaYTres, boolean peticionDieciNueve) {
		Connection conn = null;
		Long valorReturno = 0l;
			try {
				conn = ConexionDB.dameConexion();
						StringBuilder query = new StringBuilder();
				
				if(peticionCuarentaYTres) {
					query.append("SELECT estatus_cuarenta_tres " );
				}
				if(peticionDieciNueve) {
					query.append("SELECT estatus_diecinueve " );
				}
				query.append("FROM facturacion " );
				query.append("WHERE id = ?" );
				
				PreparedStatement pstmt = conn.prepareStatement(query.toString());
				pstmt.setLong(1, id);
				ResultSet rs = pstmt.executeQuery();
				
				while (rs.next()) {
					
					if(peticionCuarentaYTres) {
						valorReturno = (rs.getLong("estatus_cuarenta_tres")  );
					}
					if(peticionDieciNueve) {
						valorReturno =(rs.getLong("estatus_diecinueve") );
					}

				}
				pstmt.close();
				
			} catch (ClassNotFoundException e) {
				log.error(e.getMessage(), e);
				e.printStackTrace();
			} catch (SQLException e) {
				log.error(e.getMessage(), e);
				e.printStackTrace();
			}finally {
				try {
					ConexionDB.devuelveConexion(conn);
				} catch (Exception sqlEx2) {
					log.error(sqlEx2.getMessage(), sqlEx2);
				}
			}

		return valorReturno;
	}

	
	public DataToSIFE getDataFacturacionByIdFacturacion(Facturacion factura) {
		DataToSIFE datos = new DataToSIFE();
		Connection conn = null;

		try {

			conn = ConexionDB.dameConexion();
			PreparedStatement stmt = conn.prepareStatement(QUERY_FACTURACION_BY_ID_FACTURACION);
			stmt.setLong(1, factura.getId());
			stmt.setInt(2, Integer.parseInt(factura.getSar()));
			ResultSet rs = stmt.executeQuery();

			while (rs.next()) {
				datos.setIdFacturacion(rs.getLong("id"));
				datos.setFolioOrigen(rs.getInt("folio") + "");
				datos.setNumeroProveedor(rs.getString("proveedor"));
				datos.setCondicionDePago(rs.getString("condicionPago"));
				datos.setSubtotal(rs.getDouble("total"));
				datos.setTotal(rs.getDouble("total"));
				datos.setOrdenDeCompra(rs.getString("pos").trim());
				datos.setMoneda(rs.getString("moneda"));
				datos.setCentroCostos(rs.getString("centro"));
				datos.setNumeroFactura(rs.getString("numero_factura_pm"));
				datos.setBooking(rs.getString("booking"));
				datos.setCliente(rs.getString("cliente"));
				datos.setDocumentoSociedad(rs.getString("documentoSociedad"));
				datos.setDocumentoEjercicio(rs.getString("documentoEjercicio"));
				datos.setDocumentoNumero(rs.getString("documentoNumero"));
				datos.setDiasPago(rs.getInt("diasPago"));
				datos.setBl(rs.getString("bl"));
				datos.setContenedor(rs.getString("contenedor"));
				datos.setConcepto(rs.getString("facturaProveedor"));
			}

		} catch (Exception e) {
			log.error(e.getMessage(), e);

		} finally {
			ConexionDB.devolver(conn);
		}

		return datos;
	}


	@Override
	public Integer deletePODetalle(Long idFacturacion) {
		Connection conn = null;
		Integer resultado = null;

		try {
			conn = ConexionDB.dameConexion();
			StringBuilder query = new StringBuilder()
			.append("DELETE FROM cdiPODetalleFacturacion ")
			.append(" WHERE idFacturacion = ? ");

			PreparedStatement stmt = conn.prepareStatement(query.toString());
			stmt.setLong(1, idFacturacion);

			resultado = stmt.executeUpdate();

			stmt.close();
			
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		} finally {
			ConexionDB.devolver(conn);
		}
		return resultado;
	}

	@Override
	public List<Facturacion> getFacturasBySAR(Integer sar) {
		List<Facturacion> listFacturacion = new ArrayList<Facturacion>();
		Connection conn = null;

		try {
			conn = ConexionDB.dameConexion();
			PreparedStatement stmt = conn.prepareStatement(QUERY_GET_FACTURA_BY_SAR);
			stmt.setInt(1, sar);
			
			ResultSet rs = stmt.executeQuery();
			
			while (rs.next()) {
				Facturacion f = new Facturacion(); 
				f.setSar(rs.getInt("sar")+"");
				f.setId(rs.getLong("id"));
				f.setNoFacturaPM(rs.getString("numero_factura_pm"));
				f.setStatusId(rs.getInt("factura_status"));		
				f.setStatus(rs.getString("status"));
				
				listFacturacion.add(f);
			}
			
			stmt.close();
			
		} catch (ClassNotFoundException | SQLException e) {
			log.error(e.getStackTrace());
			e.printStackTrace();
		}
		
		
		return listFacturacion;
	}

	@Override
	public List<CatStatusIncidencias> getListCatIncidencias() {
		Connection conn = null;
		List<CatStatusIncidencias> lstCatalogo= new ArrayList<CatStatusIncidencias>();

		StringBuilder queryIncidencia = new StringBuilder();
		queryIncidencia.append("SELECT id, descripcion FROM cat_incidencias ");

		try {
			conn = ConexionDB.dameConexion();
			try (PreparedStatement pstmt = conn.prepareStatement(queryIncidencia.toString())) {
				ResultSet rs = pstmt.executeQuery();
				while (rs.next()) {
					CatStatusIncidencias cat = new CatStatusIncidencias();
					cat.setCodigo(rs.getInt("id"));
					cat.setDescripcion(rs.getString("descripcion"));
					lstCatalogo.add(cat);

				}

			} catch (SQLException e) {
				try {
					ConexionDB.renuevaConexion(conn);
				} catch (Exception ex) {
					log.error(ex.getMessage(), ex);
				}
				log.error(e.getMessage(), e);
			}

		} catch (Exception e) {
			try {
				ConexionDB.devuelveConexion(conn);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
				log.info("error: " + ex);
			}
			log.error(e.getMessage(), e);
			log.info("error: " + e);

		} finally {
			try {
				ConexionDB.devuelveConexion(conn);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
				log.info("error: " + sqlEx2);
			}
		}

		return lstCatalogo;
	}

	
	@Override
	public String getNumerosDeDocumentosBySarAndInvoide(Facturacion factura) {
		Connection conn = null;
		List<String> documentosNumero = new ArrayList<String>();	
			try {
				conn = ConexionDB.dameConexion();
			
				PreparedStatement pstmt = conn.prepareStatement(QUERY_CONSULTA_FACTURACION);
				pstmt.setInt(1, Integer.parseInt(factura.getSar() ) );
				pstmt.setString(2, factura.getInvoiceNumber()  );
				ResultSet rs = pstmt.executeQuery();
				
				while (rs.next()) {
					
					documentosNumero.add( rs.getString("documentoNumero") ) ;

				}
				pstmt.close();
				
			} catch (ClassNotFoundException e) {
				log.error(e.getMessage(), e);
				e.printStackTrace();
			} catch (SQLException e) {
				log.error(e.getMessage(), e);
				e.printStackTrace();
			}finally {
				try {
					ConexionDB.devuelveConexion(conn);
				} catch (Exception sqlEx2) {
					log.error(sqlEx2.getMessage(), sqlEx2);
				}
			}

		return String.join(",", documentosNumero);
	}

	
}