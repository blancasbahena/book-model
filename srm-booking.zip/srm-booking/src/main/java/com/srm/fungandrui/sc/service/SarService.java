package com.srm.fungandrui.sc.service;

import java.util.ArrayList;
import java.util.List;

import com.srm.pli.bo.RevisionIDAVistaBean;
import com.srm.pli.bo.SarBO;
import com.srm.pli.bo.SarConsolBO;

public interface SarService {

	public ArrayList<SarConsolBO> listHighVolSarConsolBO(ArrayList<SarConsolBO> listaConsol);

	public List<SarBO> listHighVolSarBO(List<SarBO> listaSARs ,  String vista);
	
	public ArrayList<RevisionIDAVistaBean> listHighVolSarBOIDA(ArrayList<RevisionIDAVistaBean> listaSARsIDA);
}
