package com.srm.fungandrui.sc.utils;

import org.apache.commons.lang3.StringEscapeUtils;

import com.srm.fungandrui.sc.model.ProveedorVO;
import com.srm.pli.utils.FuncionesComunesPLI;
import com.truper.businessEntity.ImportacionesProveedoresBean;

public class ProveedorUtil {

	public static  ProveedorVO validaProveedor(String proveedor) {
		ProveedorVO proveedorVO = new ProveedorVO();
		if (proveedor != null && !proveedor.equals("")) {
			proveedor=proveedor.trim();
			ImportacionesProveedoresBean prov = FuncionesComunesPLI.getProveedor(proveedor);
			if (prov != null) {
				proveedorVO.setNumProveedor(proveedor);
				proveedorVO.setNombreProveedor(StringEscapeUtils.escapeHtml3(prov.getNombreProveedor()));
			}
		}
		return proveedorVO;
	}
}
