package com.srm.fungandrui.lineamientos.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.srm.fungandrui.lineamientos.dto.GrdLineamientosAccionesDto;
import com.srm.fungandrui.lineamientos.service.EnvioCorreoLineamientosBOService;
import com.srm.fungandrui.lineamientos.service.LineamientosService;
import com.srm.fungandrui.response.ErrorMessage;
import com.srm.fungandrui.response.ResponseService;
import com.srm.fungandrui.response.Respuesta;
import com.srm.fungandrui.sc.model.BeanSession;
import com.srm.fungandrui.sc.utils.SessionUtil;
import com.srm.pli.bo.HistoryLogBean;
import com.srm.pli.bo.SarBO;
import com.srm.pli.bo.SarDetalleBO;
import com.srm.pli.bo.jasperReports.BeanReporteControlPrecio;
import com.srm.pli.constants.DataConstants;
import com.srm.pli.dao.RevisionGDRDAO;
import com.srm.pli.dao.SAR_CDI_DAO;
import com.srm.pli.enums.HistoryLogAction;
import com.srm.pli.helper.AuditoriaHelper;
import com.srm.pli.services.AuditoriaService;
import com.srm.pli.services.CorreoServices;
import com.srm.pli.services.impl.HistoryLogServiceImpl;
import com.srm.pli.utils.FuncionesComunesPLI;
import com.srm.pli.utils.MailUtils;
import com.srm.pli.utils.uploadFile.UploadUtils;
import com.truper.businessEntity.BeanAuditoriaSinMatrizDetalle;
import com.truper.businessEntity.RevisionGDR;
import com.truper.businessEntity.UserBean;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/lineamientos")

public class LineamientosController {
	@Autowired
	HttpServletRequest request;
	@Autowired
	private static Integer FECHAGRDTEST = new Integer(1);
	EnvioCorreoLineamientosBOService envioCorreoLineamientosBOService;
	public static int FIN_REVISION_GDR = 0;
	public static int GDR_NO_APROBADO = 0;
	public static int GDR_APROBADO = 1;
	public static SAR_CDI_DAO dao = new SAR_CDI_DAO();
	@Autowired
	private LineamientosService lineamientosService;

	@RequestMapping(value = "/getSars/{estatus}", method = RequestMethod.GET)
	public ResponseEntity<ResponseService> getSars(@PathVariable("estatus") Integer estatus ) {
		Map<String, Object> data = new HashMap<>();
		try {
			
			
			data.put("data", lineamientosService.getSars(estatus));
			Respuesta respuesta = new Respuesta();
			respuesta.setData(data);
			respuesta.setEstado(HttpStatus.OK);
			respuesta.setMensaje("Consulta con exito");
			respuesta.setTipoMensaje("S");
			
			return new ResponseEntity<>(respuesta, respuesta.getEstado());
		} catch (ClassNotFoundException e1) {
			log.error(e1.getMessage());
		} catch (SQLException e1) {
			log.error(e1.getMessage());
		}
		return null;
		
		
	}
	
	
	@PostMapping(path = "/actualizarSar/", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseService> actualizarSar(HttpServletRequest req, HttpServletResponse res,
			@Valid @RequestBody GrdLineamientosAccionesDto dto) throws IOException {
		Respuesta respuesta = new Respuesta();
		boolean changeStatusBack=false;
		List<SarBO> lista =new ArrayList<SarBO>();
		boolean reject=false;
		HttpSession sesion = req.getSession(false);
		if (sesion == null) {
			res.sendRedirect(req.getContextPath() + "/index.jsp");
			respuesta.setTipoMensaje("Hubo un error al ejecutar la Operacion.");
	    	respuesta.setMensaje("Session invalided");
	    	respuesta.setEstado(HttpStatus.INTERNAL_SERVER_ERROR); 
			return new ResponseEntity<>(respuesta, respuesta.getEstado());
		}
		UserBean usuario = (UserBean) sesion.getAttribute("usuario");
		if (usuario == null) {
			res.sendRedirect(req.getContextPath() + "/index.jsp");
			respuesta.setTipoMensaje("Hubo un error al ejecutar la Operacion.");
			respuesta.setMensaje("Session invalided");
	    	respuesta.setEstado(HttpStatus.INTERNAL_SERVER_ERROR);
			return new ResponseEntity<>(respuesta, respuesta.getEstado());
		}
		Map<String, Object> data = new HashMap<>();
		Integer statusAnterior=0;
		
		SarBO sar = new SarBO();
		try {
			
			sar.setFolio(dto.getFolio());
			lista=  dao.selectSar(sar, false);
			if(lista!=null && !lista.isEmpty() && lista.size()>0) {
				sar = lista.get(0);
				dto.setStatusAnterior(sar.getStatusAnteriorGRD());
				if(dto.getIdEstatus()==-1 || dto.getIdEstatus()==-2) {
					statusAnterior=(dto.getStatusAnterior());
					changeStatusBack=true;
					if(dto.getIdEstatus()==-1) {
						reject=false;
					}
					
				}
			}else {
				sar =null;
			}
		}catch(Exception ex) {
			log.info("Error:{}",ex.getMessage(),ex);
		}
		if(sar!=null) {
			try {
				HttpSession session = null;
				BeanSession beanSession = null;
				try {
					session = request.getSession(false);
					beanSession = SessionUtil.validaSesion(session);
					String userName = beanSession.getUser().getUserName();
					int status= 0;
					if(!changeStatusBack) {
						if(dto.getAccion().equals("aprobacionGDRGerente")) {
							if(dto.getIdEstatus()==SarBO.STATUS_LIBERATION_BO_CONFIRMATION_MR)
								status=HistoryLogAction.APROVAL_LIBERATION_BO_CONFIRMATION.id();
							else if(dto.getIdEstatus()==SarBO.STATUS_LIBERATION_BO_CONFIRMATION_BO)
								status=HistoryLogAction.APROVAL_LIBERATION_BO_CONFIRMATION_MR.id();
						}
						else if(dto.getAccion().equals("rechazoGDRGerente")) {
							if(dto.getStatusActual()== SarBO.STATUS_LIBERATION_BO_CONFIRMATION) {
								status=HistoryLogAction.REJECT_LIBERATION_BO_CONFIRMATION.id();
								dto.setIdEstatus(SarBO.STATUS_LIBERATION_BO_ON_HOLD_BO);
							}
							else if(dto.getStatusActual()== SarBO.STATUS_LIBERATION_BO_CONFIRMATION_MR) {
								status=HistoryLogAction.REJECT_LIBERATION_BO_CONFIRMATION_MR.id();
								dto.setIdEstatus(SarBO.STATUS_LIBERATION_BO_ON_HOLD_BO);
							}
							else if(dto.getStatusActual()== SarBO.STATUS_LIBERATION_BO_CONFIRMATION_BO) {
								status=HistoryLogAction.REJECT_LIBERATION_BO_CONFIRMATION_BO.id();
								dto.setIdEstatus(SarBO.STATUS_LIBERATION_BO_ON_HOLD_BO);
							}
						}
						data.put("lineamiento", lineamientosService.actualizarSar(dto));
					}else {
						if(dto.getAccion().equals("aprobacionGDRGerente")) {
							reject = false;
						}
						else if(dto.getAccion().equals("rechazoGDRGerente")) {
							reject =true;
						}
						status=sar.getStatus().intValue();
						dto.setIdEstatus(statusAnterior);
						data.put("lineamiento", dto.getFolio());
						aprobacionGDRGerenteLineamiento(usuario,dto,lista,changeStatusBack,reject,dameMailsDirectorImportCompradorSrCompradorJrGerenteMatrizGerenteAudit());
					}
					
					HistoryLogBean historyLogBean = HistoryLogBean.builder()
						.tipoAccion(status)
						.folio(dto.getFolio())
						.sarType(DataConstants.SAR_TYPE)
						.comentarios(dto.getComentarios())
						.username(userName).build();
					log.info("Datos a insertar en el history log: Accion:{}, username: {} ", historyLogBean.getTipoAccion(), historyLogBean.getUsername());
					HistoryLogServiceImpl.getInstance().saveHistoryLogComments(historyLogBean);
					respuesta.setData(data);
					respuesta.setEstado(HttpStatus.OK);
					respuesta.setMensaje("Actualizacion con exito");
					respuesta.setTipoMensaje("S");

					return new ResponseEntity<>(respuesta, respuesta.getEstado());
				}catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				
			} catch (Exception e1) {
				log.error(e1.getMessage()); 
		    	respuesta.setTipoMensaje("Hubo un error al ejecutar la Operacion.");
		    	respuesta.setMensaje(e1.getMessage());
		    	respuesta.setEstado(HttpStatus.INTERNAL_SERVER_ERROR);
				ErrorMessage errorMessage = new ErrorMessage(new Date(), e1.getMessage());
				data.put("error", errorMessage);
				respuesta.setData(data);
				return new ResponseEntity<>(respuesta, respuesta.getEstado());
			}
		}
		return null;

	}
	 public String[] dameMailsDirectorImportCompradorSrCompradorJrGerenteMatrizGerenteAudit() {
		ArrayList<BeanReporteControlPrecio> listaReportes = null;
		HashSet<BeanAuditoriaSinMatrizDetalle> detalles = null;
		HashSet<String> bus = null;
		try {
			listaReportes = AuditoriaService.getInstance().getPosConPbPendientesDeLiberarMatriz();
			detalles = AuditoriaService.getInstance().getDetalles(listaReportes);
			bus = AuditoriaHelper.getInstance().getBUs(detalles);
			Set<String> correos_set = new HashSet<>();
			correos_set.add(SarBO.MAIL_GIL);
			correos_set.add(SarBO.EMAIL_GERENTE_AUDITORIA);
			correos_set.add(SarBO.EMAIL_GERENTE_MATRIZ);
			for (String bu : bus) {
				Set<String> correos_temp = CorreoServices.getInstance().getCorreosDirectorBu(bu);
				if (correos_temp != null && correos_temp.size() > 0) {
					correos_set.addAll(correos_temp);
				}
				correos_temp = CorreoServices.getInstance().getCorreosGerenteBu(bu);
				if (correos_temp != null && correos_temp.size() > 0) {
					correos_set.addAll(correos_temp);
				}
			}
			String[] correos = new String[correos_set.size()];
			correos_set.toArray(correos);
			return correos;
		} catch (Exception e) {
			log.error("Error [mailReportesAuditoria] al crear el archivo", e);
		}
		return new String[0];
	}
	public void aprobacionGDRGerenteLineamiento(UserBean usuario,GrdLineamientosAccionesDto dto,List<SarBO> lista,
			boolean changefolio,boolean reject,String[] correosBU)
			throws IOException, ServletException {
		RevisionGDR revisado = new RevisionGDR();
		RevisionGDRDAO revisionesDAO = new RevisionGDRDAO();
		try {
			if(!reject) {
				SAR_CDI_DAO.updateSARStatusGDR_AND_LINEAMIENTOS(dto.getFolio(), FIN_REVISION_GDR, GDR_APROBADO,changefolio);
			}
			else {
				SAR_CDI_DAO.updateSARStatusGDR_AND_LINEAMIENTOS(dto.getFolio(), FIN_REVISION_GDR, GDR_NO_APROBADO,changefolio);
			}
			SAR_CDI_DAO.aprobacionGDRBOLINEAMIENTO(dto.getFolio(),changefolio);
			revisado.setFolio(dto.getFolio());
			revisado.setActivo(Boolean.FALSE);
			revisionesDAO.update(revisado);
			//Env�o de correo de notificacion
			FuncionesComunesPLI.dameDatosCDIDetalle(lista);
			if (lista != null && lista.size() > 0) {
				SarDetalleBO detalleObj = new SarDetalleBO();
				detalleObj.setFolio(lista.get(0).getFolio());
				ArrayList<SarDetalleBO> listaDet = (ArrayList<SarDetalleBO>)FuncionesComunesPLI.getDetalleSAR(lista.get(0));
				List<SarDetalleBO> listaDetOtros = SAR_CDI_DAO
						.consultaDetalleOtros(lista.get(0).getFolio().toString());
				lista.get(0).setDetalleBO(listaDet);
				lista.get(0).setDetalleOthers((ArrayList<SarDetalleBO>)listaDetOtros);
				lista.get(0).setValorEmbarque(FuncionesComunesPLI.CERO);
				//FuncionesComunesPLI.sacaTotales(lista.get(0), listaDet, listaDetOtros);
				Map<String, Object> datosMail = MailUtils.dameDatosDestinoMail(lista.get(0));
				//MailUtils mu = new MailUtils();
				envioCorreoLineamientosBOService.enviarCorreoLineaminetosBO(usuario, lista.get(0),listaDet, datosMail,reject,correosBU);
				
			}
		} catch (NumberFormatException nfe) {
			log.error("Error al aplicar los cambios solicitados por el proveedor en el SAR: " + dto.getFolio(), nfe);
		} catch (SQLException e) {
			log.error("Error al aplicar los cambios solicitados por el proveedor en el SAR: " + dto.getFolio(), e);
		} catch (ClassNotFoundException e) {
			log.error("Error al aplicar los cambios solicitados por el proveedor en el SAR: " + dto.getFolio(), e);
		} catch (Exception e) {
			log.error("Error al aplicar los cambios solicitados por el proveedor en el SAR: " + dto.getFolio(), e);
		}
	}

	@RequestMapping(value = "/validacionIda/{folio}", method = RequestMethod.GET)
	public ResponseEntity<ResponseService> validacionIda(@PathVariable("folio") Integer folio ) {
		Map<String, Object> data = new HashMap<>();
		try {
			boolean verLogsLineacionIDA = UploadUtils.getInstance().getBoolean(("lineamientosBO.logs.ver"));
			data.put("data", lineamientosService.validacionIdaBO(folio,FECHAGRDTEST,verLogsLineacionIDA));
			Respuesta respuesta = new Respuesta();
			respuesta.setData(data);
			respuesta.setEstado(HttpStatus.OK);
			respuesta.setMensaje("Consulta con exito");
			respuesta.setTipoMensaje("S");
			
			return new ResponseEntity<>(respuesta, respuesta.getEstado());
		} catch (ClassNotFoundException e1) {
			log.error(e1.getMessage());
		} catch (SQLException e1) {
			log.error(e1.getMessage());
		}
		return null;
		
		
	}

	public Locale validateSession() throws Exception {
		HttpSession session = null;
		BeanSession beanSession;
		session = request.getSession(false);
		beanSession = SessionUtil.validaSesion(session);
		if (beanSession == null)
			throw new Exception("session invalida");
		
		Locale currentLocale = session.getAttribute("javax.servlet.jsp.jstl.fmt.locale.session") == null
				? new Locale("en", "US")
				: (Locale) session.getAttribute("javax.servlet.jsp.jstl.fmt.locale.session");
		
		return currentLocale;
	}
	
}
