package com.srm.fungandrui.facturacion.utils;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import org.jfree.util.Log;

import com.srm.fungandrui.facturacion.models.ReporteSemanalIncidencias;
import com.srm.fungandrui.facturacion.service.impl.FacturacionServiceImpl;
import com.srm.pli.utils.MailUtils;
import com.srm.pli.utils.PropertiesDb;

import lombok.extern.slf4j.Slf4j;
@Slf4j
public class SendReporteIncidenciaSemanal {
	
//	
////	private ReporteSemanalIncidencia reporteSI;
////	
////	public SendReporteIncidenciaSemanal(ReporteSemanalIncidencia reporteSI) {
////		this.reporteSI = reporteSI;
////	}
////	@Autowired
////	ReporteSemanalIncidencia reporteSI;
//	
//	FacturacionServiceImpl reporte = new FacturacionServiceImpl();
//	
//	//ReporteSemanalIncidencia reporte
//	
//	
//
//	private  final String DIA_DE_ENVIO  = "FRIDAY";
//	 private  final String HORA_DE_ENVIO = "18:00:00";
//	 List<ReporteSemanalIncidencias> reporteSIJ = new ArrayList<ReporteSemanalIncidencias>();
//		String plantilla = PlantillasEmailFacturacion.REPORTE_SEMANAL_INCIDENCIA;
//	 
//	 public void executeReporteIncidenciasSemanal() {
//		 
//		 
//		 
//			//reporteSIJ= reporte.getReporteSemanalIncidencias();
//			log.info("# registros encontrados: " + (reporteSIJ != null && !reporteSIJ.isEmpty() ? reporteSIJ.size() : 0));
//			if (reporteSIJ != null) {
//				try {
//					
//				for (int i = 0; i <  reporteSIJ.size() ; i++) {
//					String idIncidencia = reporteSIJ.get(i).getIdIncidencia() != null ? reporteSIJ.get(i).getIdIncidencia() : "--";
//					String descripcion = reporteSIJ.get(i).getDescripcion() != null ? reporteSIJ.get(i).getDescripcion() : "--";
//					String tiempoSolucion = reporteSIJ.get(i).getTiempoSolucion() != null ? reporteSIJ.get(i).getTiempoSolucion() : "--";
//					
//							
//					plantilla = plantilla.replaceAll("-INCIDENCIA-", idIncidencia);
//					plantilla = plantilla.replaceAll("-DESCRIPCION-", descripcion);
//					plantilla = plantilla.replaceAll("-TIEMPOSOLUCION-", tiempoSolucion);
//						
//				}
//					
//				 String correos = PropertiesDb.getInstance().getString("email.reporteSemanal.incidencias");
//				 String[] strArrayCorreos = new String[] {correos};
//				 MailUtils.enviaCorreo(strArrayCorreos, null, "Reporte Semanal Incidencias", "system@fung-rui.hk", plantilla.toString(), null);
//					//String[] correos = listEmails.split(";");
//					log.info("Plantilla para correo " , plantilla);
//					System.out.println("Plantilla para correo " + plantilla);
//					//String[] splitDestinatarios = listdestinatarios.split(";");
//					//SendEmail.sendEmail(listEmails, "Envio Incidencias");
//				 
//					//Obtengo la hora del dia
//					DateTimeFormatter dtf = DateTimeFormatter.ofPattern("HH:mm:ss");
//			        System.out.println("Hora a Comparar: " + dtf.format(LocalDateTime.now()));
//					//Formateo
//			        String hora = dtf.format(LocalDateTime.now());
//			        System.out.println("Hora: " + hora);
//					 LocalDateTime diaActual = LocalDateTime.now();
////					 System.out.println("DIA ACTUAL: "+ diaActual);
//					 //Obtener el dia de la semana
//					 //System.out.println(diaActual.getDayOfWeek().toString());
//					 
//					
//					 if(DIA_DE_ENVIO == diaActual.getDayOfWeek().toString() && hora.equals(HORA_DE_ENVIO)) {
//						 log.info("Se inicia envio de Correo");
//						 MailUtils.enviaCorreo(strArrayCorreos, null, "Reporte Semanal Incidencias", "system@fung-rui.hk", plantilla.toString(), null);
//						 
//					 }else {
//						 log.info("No se envio de Correo");
//					 }
//			 
//				 
//			
//				
//				//	MailUtils.enviaCorreo(correos, null, "Reporte Semanal Incidencias", "system@fung-rui.hk", plantilla.toString(), null);
//					
//				} catch (Exception e) {
//					Log.info("Error  ",e);
//					e.printStackTrace();
//				}
//			} else {
//			
//				Log.info("No se envia correo  ");
//			}
//			
//		}
//		
//		 
//		 
//	 

}
