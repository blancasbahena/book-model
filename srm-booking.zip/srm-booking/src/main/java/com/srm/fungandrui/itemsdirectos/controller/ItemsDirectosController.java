package com.srm.fungandrui.itemsdirectos.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.srm.app.constantes.Mensajes;
import com.srm.fungandrui.itemsdirectos.dto.ItemsDirectosDTO;
import com.srm.fungandrui.itemsdirectos.service.ItemsDirectosService;
import com.srm.fungandrui.sc.model.BeanSession;
import com.srm.fungandrui.sc.model.ResponseVO;
import com.srm.fungandrui.sc.utils.SessionUtil;
import com.srm.pli.dao.SAR_CDI_DAO;
import com.srm.pli.utils.FuncionesComunesPLI;
import com.truper.businessEntity.UserBean;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/items-directos")
public class ItemsDirectosController {
	
	@Autowired
	HttpServletRequest request;
	
	@Autowired
	private ItemsDirectosService itemsDirectosService;
	
	public static SAR_CDI_DAO dao = new SAR_CDI_DAO();
	
	public static final String ITEMS_CHECKED = "Items checked in SAR for BO elimination";
	
	@PostMapping(path = "/marcar-items", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseVO> marcarProyeccionBOItemsDirectos(@RequestBody ItemsDirectosDTO itemsDirectosDTO) {

		log.info("[/search/]::Entrando al Servicio para hacer el Filtto:");

		ResponseVO response = new ResponseVO();
		Map<String, Object> data = new HashMap<String, Object>();
		HttpSession session = null;
		BeanSession beanSession;
		session = request.getSession(false);
		beanSession = SessionUtil.validaSesion(session);
			
		UserBean usuario = (UserBean) session.getAttribute("usuario");
		int action = 0;
		
		try {
			
			if (beanSession == null) {
				throw new Exception("session invalida");
			}
			
			itemsDirectosService.marcarProyeccionBOItemsDirectos(itemsDirectosDTO);
			
			action = dao.findActionHistoryByAction(ITEMS_CHECKED);
			FuncionesComunesPLI.guardaSARHistoryLog(action, itemsDirectosDTO.getFolio(), usuario.getUserName(), null, "F", itemsDirectosDTO.getComentario());
				
			response.setTipoMensaje(Mensajes.TIPO_EXITO.getMensaje());
			response.setMensaje("Please notice that changes in BO elimination will only be applied upon SAR approval");
			
			return ResponseEntity.ok(response);
			
		} catch (Exception e) {
			response.setTipoMensaje(Mensajes.TIPO_ERROR.getMensaje());
			response.setMensaje(Mensajes.MSG_ERROR.getMensaje());
			data.put("error", ExceptionUtils.getStackTrace(e));
			log.info("Error");
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
		}
	
	}

}
