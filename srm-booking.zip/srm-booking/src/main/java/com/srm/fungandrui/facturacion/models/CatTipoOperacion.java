package com.srm.fungandrui.facturacion.models;

import lombok.Getter;

@Getter
public enum CatTipoOperacion {
	
	FACTURACION("1001","Facturaci�n"),
	CANCELACION("2001","Cancelaci�n"),
	RESPUESTA_PARCIAL("1002","En Espera de Documentos"),
	RESPUESTA_FACTURACION("1003","Facturada"),
	ENTREGA_SIFE("1005","Entrega SIFE"),
	BLOQUEO_POS("3001","Bloqueo de POs");
	
	
	private String tipo;
	private String descripcion;
	
	private CatTipoOperacion(String tipo, String descripcion) {
		this.descripcion = descripcion;
		this.tipo = tipo;
	}
	
}
