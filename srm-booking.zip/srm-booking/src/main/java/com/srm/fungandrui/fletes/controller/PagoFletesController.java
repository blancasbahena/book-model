package com.srm.fungandrui.fletes.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.srm.fungandrui.fletes.entities.FiltersPagoFletes;
import com.srm.fungandrui.fletes.entities.PagoFlete;
import com.srm.fungandrui.fletes.service.PagoFeleteService;
import com.srm.fungandrui.sc.model.BeanSession;
import com.srm.fungandrui.sc.model.ResponseVO;
import com.srm.fungandrui.sc.utils.SessionUtil;
import com.srm.pli.enums.Mensajes;
import com.srm.pli.utils.Paginacion;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
@RequestMapping("/pagoFletes")
public class PagoFletesController {

	@Autowired
	HttpServletRequest request;

	@Autowired
	PagoFeleteService pagoFleteservice;

	@RequestMapping(value = "/", method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView getBloqueos(Model model) {
		HttpSession session = null;
		BeanSession beanSession;
		ModelAndView mav = null;

		session = request.getSession(false);
		beanSession = SessionUtil.validaSesion(session);
		if (beanSession.getMav() == null) {
			try {
				mav = new ModelAndView("pagoFletes");
				mav.addObject("STATUS", pagoFleteservice.getAllEstatus());
				return mav;
			} catch (Exception e) {
				log.error(e.getMessage());
			}
		}
		mav = new ModelAndView("redirect:/Inicio");
		return mav;
	}

	@PostMapping(value = "/search", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseVO> search(@RequestBody FiltersPagoFletes filtro) {
		log.info("[/search/]::Entrando al REST para obtener Facturas de flete POST:");
		ResponseVO response = new ResponseVO();
		Map<String, Object> data = new HashMap<String, Object>();
		HttpSession session = null;
		BeanSession beanSession;
		session = request.getSession(false);
		beanSession = SessionUtil.validaSesion(session);
		Locale currentLocale = session.getAttribute("javax.servlet.jsp.jstl.fmt.locale.session") == null
				? new Locale("en", "US")
				: (Locale) session.getAttribute("javax.servlet.jsp.jstl.fmt.locale.session");
		try {
			if(beanSession == null)
				throw new Exception("session invalida");
			List<PagoFlete> listDetalle = pagoFleteservice.getListByFilters(filtro);
			response.setTipoMensaje(Mensajes.TIPO_EXITO.getMensaje());
			response.setMensaje(Mensajes.MSG_EXITO.getMensaje()); 
			data.put("list", listDetalle);
			data.put("flechas", Paginacion.controlPaginacion(filtro.getPaginaActual(), filtro.getPaginaAccion(),  listDetalle.size(), currentLocale));
			response.setResponseObject(data);
			log.info("[/search/]::Saliendo al REST para obtener Facturas de flete POST:");
			return ResponseEntity.ok(response);

		} catch (Exception e) {
			response.setTipoMensaje(Mensajes.TIPO_ERROR.getMensaje());
			response.setMensaje(Mensajes.MSG_ERROR.getMensaje());
			data.put("error", ExceptionUtils.getStackTrace(e));
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
		}

	}

	@GetMapping("/test")

	public ResponseEntity<List<PagoFlete>> test(@RequestBody FiltersPagoFletes filtro) {
		return ResponseEntity.ok(pagoFleteservice.getListByFilters(filtro));

	}

	
	
	@GetMapping("/consultaFleteByEstatus/{estatus}")
	public ResponseEntity<List<PagoFlete>> consultaFleteByEstatus( @PathVariable("estatus") String estatus){
		return ResponseEntity.ok(pagoFleteservice.getListByStatus(estatus));

	}

}