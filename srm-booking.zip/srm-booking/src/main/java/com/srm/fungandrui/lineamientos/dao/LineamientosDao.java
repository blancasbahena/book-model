package com.srm.fungandrui.lineamientos.dao;

import java.sql.SQLException;
import java.util.List;

import com.srm.fungandrui.lineamientos.dto.GrdLineamientosAccionesDto;
import com.srm.fungandrui.lineamientos.dto.SarLineamientosDto;

public interface LineamientosDao {

	List<SarLineamientosDto> getSars(Integer estatus)throws SQLException,ClassNotFoundException;
	
	Integer actualizarSar(GrdLineamientosAccionesDto dto) throws SQLException,ClassNotFoundException;
	
	Integer consultarGrd(Integer folio )throws SQLException, ClassNotFoundException;
}
