package com.srm.fungandrui.pis.servlet;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.srm.fungandrui.pis.dao.PisDao;
import com.srm.fungandrui.pis.dao.impl.PisDaoImpl;
import com.srm.fungandrui.pis.dto.ProformaInvoiceDTO;
import com.srm.fungandrui.sc.service.SarService;
import com.srm.fungandrui.sc.service.SarServiceImpl;
import com.srm.pli.bo.SarBO;
import com.srm.pli.bo.SarDetalleBO;
import com.srm.pli.dao.RevisionGDRDAO;
import com.srm.pli.dao.SAR_CDI_DAO;
import com.srm.pli.helper.FormatSAR;
import com.srm.pli.helper.FormatSARDetalle;
import com.srm.pli.helper.FormatSARDetalleOthers;
import com.srm.pli.utils.FuncionesComunesPLI;
import com.srm.pli.utils.uploadFile.UploadUtils;
import com.truper.businessEntity.RevisionGDR;
import com.truper.businessEntity.SARDetalleSimulador;
import com.truper.businessEntity.UserBean;
import com.truper.infra.annotation.RequestHandler;
import com.truper.infra.servlet.BaseServlet;

public class ProformaServlet extends BaseServlet {
	List<SARDetalleSimulador> listaDetallesSimuladorAGuardar = new ArrayList<SARDetalleSimulador>();

	private static final long serialVersionUID = 7691610007679393745L;
	public static final Logger log = LogManager.getRootLogger();
	private static Gson gson = new GsonBuilder().serializeSpecialFloatingPointValues().create();
	public static int MAX_REGISTROS_VISIBLES = 10;
	public static int FIN_REVISION_GDR = 0;
	public static int GDR_NO_APROBADO = 0;
	public static int GDR_APROBOADO = 1;
	public static int GuidelineONE = 1;
	public static int GuidelineTWO = 2;
	public static int GuidelineTHREE = 3;
	public static UploadUtils properties = null;
	public static SAR_CDI_DAO dao = new SAR_CDI_DAO();
	public boolean esHighVol = false;
	public static final String sender = "system@fung-rui.hk";
	@Autowired
	private PisDao daoPis=new PisDaoImpl();
	@Autowired
	SarService service = new SarServiceImpl();

	public void init() throws ServletException {
		FuncionesComunesPLI.cargaPropertiesCDI(false);
		FuncionesComunesPLI.recargaMapaProveedorXplaneador(false);
		FuncionesComunesPLI.getProveedores(false);
		FuncionesComunesPLI.cargaPlanners(false);
		FuncionesComunesPLI.cargaPuertosDestino(false);
		FuncionesComunesPLI.cargaPuertosOrigen(false);
		FuncionesComunesPLI.cargaNavierasXPuerto(false);
		FuncionesComunesPLI.cargaContenedores(false);
		FuncionesComunesPLI.cargaAerolineas(false);
		properties = UploadUtils.getInstance();
		SAR_CDI_DAO.cargaPoliticaPenalizacionProveedores(false);
	}

	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doPost(req, resp);
	}

	@Override
	protected void doPostManager(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		//
		HttpSession sesion = req.getSession(false);
		if (sesion == null) {
			resp.sendRedirect(req.getContextPath() + "/index.jsp");
			return;
		}

		UserBean usuario = (UserBean) sesion.getAttribute("usuario");
		if (usuario == null) {
			resp.sendRedirect(req.getContextPath() + "/index.jsp");
			return;
		}
		//
		RequestDispatcher rd = req.getRequestDispatcher("/booking/ProformaII.jsp");
		rd.forward(req, resp);
	}

	/**
	 * @author Luis Blancas
	 * 
	 *         Este metodo obtiene el pool de SARs a mostrarse en GRD
	 * 
	 * @param req
	 * @param res
	 * @param posicion
	 * @param regInicial
	 * @param cambio
	 * @param tipoFolio
	 * @param planeador
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	@RequestHandler(parameterNames = { "req", "res", "tipoFolio", "celula", "planeador", "supplier", "po", "folio",
			"posicion", "regInicial", "highVolume", "status" }, parameterClasses = { HttpServletRequest.class,
					HttpServletResponse.class, String.class, String.class, String.class, String.class, String.class,
					Integer.class, String.class, String.class, String.class, String.class })
	public void loadProformas(HttpServletRequest req, HttpServletResponse res, String tipoFolio, String celula,
			String planeador, String supplier, String po, Integer folio, String posicion, String regInicial,
			String highVolume, String status) throws IOException, ServletException {
		HttpSession sesion = req.getSession(false);
		res.setCharacterEncoding("ISO-8859-1"); 
		res.setContentType("application/json; charset=utf-8");
		if (sesion == null) {
			res.sendRedirect(req.getContextPath() + "/index.jsp");
			return;
		}
		UserBean usuario = (UserBean) sesion.getAttribute("usuario");
		if (usuario == null) {
			res.sendRedirect(req.getContextPath() + "/index.jsp");
			return;
		}
		JSONObject json = new JSONObject();
		List<ProformaInvoiceDTO> lista= new ArrayList<ProformaInvoiceDTO>();
		log.info("Datos de busqueda estatus[ "+status+"] po["+po+"] planeador["+planeador+"] supplier["+supplier+"]");
		try{ 
			if(planeador==null && supplier==null && po==null) {
				lista=daoPis.getProformaByStatus(Integer.parseInt(status));
			}else if (po!=null) { 
				lista =daoPis.getProformaByPOAndEstatus(po,Integer.parseInt(status));
			}else if (planeador!=null) {  
					lista=daoPis.getProformaByPLanerAndEstatus(planeador.trim(),Integer.parseInt(status));
			}else if (supplier!=null) { 
					lista=daoPis.getProformaByProveedorAndEstatus(supplier.trim(),Integer.parseInt(status)); 
			}
        }
        catch (Exception ex){
        	
            log.info("Problemas en proforma PI II {}",ex.getMessage(),ex);
        }
		// Control de la paginacion
		int intPaginaAct = 0;
		int intRegIni = 0;
		int intRegFin = 0;
		if ("none".equals(posicion)) {
			if (regInicial == null || "".equals(regInicial)) {
				intPaginaAct = 0;
			} else {
				intPaginaAct = Integer.parseInt(regInicial);
			}
			intRegIni = intPaginaAct;
			intRegFin = intPaginaAct + MAX_REGISTROS_VISIBLES;
		}
		if ("inicio".equals(posicion)) {
			intPaginaAct = 0;
			intRegIni = 0;
			intRegFin = MAX_REGISTROS_VISIBLES;
		}
		if ("back".equals(posicion)) {
			intPaginaAct = Integer.parseInt(regInicial);
			intPaginaAct = intPaginaAct == 0 ? 0 : intPaginaAct - MAX_REGISTROS_VISIBLES;
			intRegIni = intPaginaAct;
			intRegFin = intPaginaAct + MAX_REGISTROS_VISIBLES;
		}
		if ("next".equals(posicion)) {
			intPaginaAct = Integer.parseInt(regInicial);
			intPaginaAct = (intPaginaAct + MAX_REGISTROS_VISIBLES) < lista.size()
					? intPaginaAct + MAX_REGISTROS_VISIBLES
					: intPaginaAct;
			intRegIni = intPaginaAct;
			intRegFin = intPaginaAct + MAX_REGISTROS_VISIBLES;
		}
		if ("ultimo".equals(posicion)) {
			intPaginaAct = lista.size() / MAX_REGISTROS_VISIBLES;
			intPaginaAct = intPaginaAct * MAX_REGISTROS_VISIBLES;
			intRegIni = intPaginaAct;
			intRegFin = intPaginaAct + MAX_REGISTROS_VISIBLES;
			if (intRegIni == lista.size()) {
				intRegIni = intPaginaAct - MAX_REGISTROS_VISIBLES;
				intRegFin = intPaginaAct;
			}
		}
		Locale currentLocale = sesion.getAttribute("javax.servlet.jsp.jstl.fmt.locale.session") == null
				? new Locale("en", "US")
				: (Locale) sesion.getAttribute("javax.servlet.jsp.jstl.fmt.locale.session");
		// Objeto para paginacion
		String flechas = FuncionesComunesPLI.generaFlechas(MAX_REGISTROS_VISIBLES, intRegIni, intRegFin,
				lista.size(), "consultaRevisedGRD", currentLocale);
		JSONArray jSars = new JSONArray(gson.toJson(lista));
		json.put("sars", jSars);
		json.put("flechas", flechas);
		json.put("regInicial", intRegIni);
		res.getWriter().print(json);
		return;
	} 
}
