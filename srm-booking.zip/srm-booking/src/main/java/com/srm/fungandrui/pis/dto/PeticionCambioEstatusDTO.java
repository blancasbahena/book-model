package com.srm.fungandrui.pis.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class PeticionCambioEstatusDTO {
	String idPi;
	String noOrden;
	ProformaDetalleDTO detallePI;
	int status;
	String usuario;
}
