package com.srm.fungandrui.expediente.service;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;

import com.srm.pli.bo.FileUploadBO;

public interface ExpedienteUpLoadService {

	public FileUploadBO guardaDocumentoDirectorio(HttpServletRequest request,String uploadPath);
	
	Boolean saveFileToSharePoint(String filename, String lbContenedor,String pathFile) throws IOException;
	public String guardaArchivoProformaDirectorio(HttpServletRequest request, String uploadPath);
}
