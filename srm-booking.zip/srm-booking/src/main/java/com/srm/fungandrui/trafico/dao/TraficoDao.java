package com.srm.fungandrui.trafico.dao;

import java.sql.SQLException;

import com.srm.fungandrui.facturacion.models.Facturacion;
import com.srm.fungandrui.trafico.models.TraficoConsolVO;
import com.truper.trafico.ConsolidacionFolioDto;

public interface TraficoDao {

	ConsolidacionFolioDto enviadoATrafico(Facturacion factura) throws ClassNotFoundException, Exception;
	TraficoConsolVO validaEnviaTrafico(String proveedor, String booking);
	TraficoConsolVO validaConsolidadosAceptados(String proveedor, String booking) throws Exception;
	ConsolidacionFolioDto validaEnviadoATrafico(Facturacion factura, String status) throws Exception;
	
	int actualizaEstatusAceptacion(Integer sar)throws ClassNotFoundException, SQLException;
	
	int actualizaEstatusRechazo(Integer sar, Integer id,String observacionesTrafico)throws ClassNotFoundException, SQLException;

}
