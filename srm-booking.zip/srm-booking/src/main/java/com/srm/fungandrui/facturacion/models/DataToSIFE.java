package com.srm.fungandrui.facturacion.models;

import java.util.List;

import lombok.Data;

@Data
public class DataToSIFE {

	
	private Integer idtipoSolicitud;
	private String numeroProveedor;
	private String nombreProveedor;
	private String concepto;
	private String observacion;
	private String fechaEstimadaPago;
	private String centroCostos;
	private String descripcion;
	private String comentariosAdicionales;
	private String fechaServicio;
	private String rfcEmpresaRecibe;
	private String mailContactoTruper;
	private String moneda;
	private Double total;
	private Double impuesto;
	private Double subtotal;
	private Boolean conImpuesto;
	private String numeroFactura;
	private String documentoNumero;
	private String documentoSociedad;
	private String documentoEjercicio;
	private String documentoComentarios;
	private Integer diasPago;
	private String taxId;
	private Boolean diferencias;
	private String folioOrigen;
	private String ordenDeCompra;
	private String condicionDePago;
	private List<SharepointFile> sharepointFiles;
	
	// Datos no necesarios
	private Long idFacturacion;
	private String booking;
	private String cliente;
	private String bl;
	private String contenedor;
	
	private Long idTipoPartida;
}
