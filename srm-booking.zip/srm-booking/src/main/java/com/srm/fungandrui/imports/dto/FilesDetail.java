package com.srm.fungandrui.imports.dto;

import java.io.Serializable;

import lombok.Data;

@Data
public class FilesDetail implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 3335054828355324074L;
	
	private String strName;
	private String strUrl;
	private String length;
	private String dcreatedTime;
	private String dlastModTime;
	
}
