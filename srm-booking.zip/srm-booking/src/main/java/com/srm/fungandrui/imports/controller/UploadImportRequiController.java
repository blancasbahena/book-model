package com.srm.fungandrui.imports.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.ws.rs.core.Context;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.srm.fungandrui.imports.service.UploadImportRequiService;
import com.srm.pli.enums.Mensajes;
import com.srm.pli.ws.vo.ResponseImportsVO;
import com.truper.businessEntity.UserBean;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
@AllArgsConstructor
@RequestMapping("/importRequi/file")
public class UploadImportRequiController {

	final UploadImportRequiService importRequiService;
	
	@Context
	private HttpServletRequest request;

	@PostMapping("/uploadFile")
	public ResponseEntity<ResponseImportsVO> uploadFileImportRequirements(@RequestParam("file") MultipartFile file, @RequestParam("update") boolean update) {
		log.info("/uploadFile/ Se carga archivo de requerimientos importacion ");
		ResponseImportsVO response = null;
		try {
			HttpSession sesion = request.getSession(false);
			UserBean usuario = (UserBean) sesion.getAttribute("usuario");
			
			response = importRequiService.uploadFileImportRequirements(file, update, usuario.getUserName());
			return ResponseEntity.ok(response);
		} catch (Exception e) {
			response.setTipoMensaje(Mensajes.TIPO_ERROR.getMensaje());
			response.setMensaje(Mensajes.MSG_ERROR.getMensaje());
			Map<String, Object> data = new HashMap<String, Object>();
			data.put("error", ExceptionUtils.getStackTrace(e));
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
		}
	}
	
	
	@GetMapping("/add/folder/{path}")
	public ResponseEntity<ResponseImportsVO> addFolder(@PathVariable String path) {
		log.info("/uploadFile/ Se carga archivo de requerimientos importacion ");
		ResponseImportsVO response = null;
		try {
			HttpSession sesion = request.getSession(false);
			UserBean usuario = (UserBean) sesion.getAttribute("usuario");
			
			importRequiService.creaDirectorio(path);
			return ResponseEntity.ok(response);
		} catch (Exception e) {
			response.setTipoMensaje(Mensajes.TIPO_ERROR.getMensaje());
			response.setMensaje(Mensajes.MSG_ERROR.getMensaje());
			Map<String, Object> data = new HashMap<String, Object>();
			data.put("error", ExceptionUtils.getStackTrace(e));
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
		}
	}
	
	
	
}