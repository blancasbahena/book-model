package com.srm.fungandrui.fletes.entities;

import lombok.Data;

@Data
public class EstatusFlete {
	
	private Long id;
	private String nombre;

}
