package com.srm.fungandrui.sc.model;

import java.io.Serializable;
import java.sql.Date;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ControlMatrizVO implements Serializable {
	private static final long serialVersionUID = 1L;

	private Date fechaInsert;
	private String po;
	private Integer posicion;
	private Integer material;
	private String centro;
	private Integer cantidad;
	private double preioUnitario;
	private Integer etd;
	private String proveedor;
	private boolean isBacklog;
	private Date fechaBacklog;
	private String doumentosRequeridos;
	private Date fechaModificacion;
	private String comentario;
	private String status;
	private Date fechaLastUpdate;

}
