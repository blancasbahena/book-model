package com.srm.fungandrui.facturacion.service;

import com.srm.fungandrui.sc.model.ResponseVO;
import com.truper.trafico.ConsolidacionFolioDto;

public interface TraficoRabbitService {

	public ResponseVO envioTrafico(ConsolidacionFolioDto consolidacionFolioDto);

	void procesaAceptacionTrafico(Integer sar);


	void procesaRechazoTrafico(Integer sar, Integer idOrigenDocumento, String comentarioTrafico);

}
