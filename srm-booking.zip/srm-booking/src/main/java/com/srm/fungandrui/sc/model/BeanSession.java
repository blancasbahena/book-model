package com.srm.fungandrui.sc.model;

import java.io.Serializable;

import org.springframework.web.servlet.ModelAndView;

import com.truper.businessEntity.UserBean;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BeanSession implements Serializable{

	private static final long serialVersionUID = 1L;

	private UserBean user;
	private ModelAndView mav;
	
}
