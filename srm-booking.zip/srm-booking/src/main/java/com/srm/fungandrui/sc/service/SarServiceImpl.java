package com.srm.fungandrui.sc.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.srm.fungandrui.sc.dao.SarDAO;
import com.srm.fungandrui.sc.dao.SarDAOImpl;
import com.srm.pli.bo.RevisionIDAVistaBean;
import com.srm.pli.bo.SarBO;
import com.srm.pli.bo.SarConsolBO;

@Service
@Transactional
public class SarServiceImpl implements SarService{

	@Autowired
	private SarDAO sarDAO = new SarDAOImpl();

	@Override
	public ArrayList<SarConsolBO> listHighVolSarConsolBO(ArrayList<SarConsolBO> listaConsol) {
		return this.sarDAO.listHighVolSarConsolBO(listaConsol);
	}
	@Override
	public List<SarBO> listHighVolSarBO(List<SarBO> listaSARs ,  String vista) {
		return this.sarDAO.listHighVolSarBO(listaSARs , vista);
	}
	@Override
	public ArrayList<RevisionIDAVistaBean> listHighVolSarBOIDA(ArrayList<RevisionIDAVistaBean> listaSARsIDA) {
		return this.sarDAO.listHighVolSarBOIDA(listaSARsIDA);
	}
}
