package com.srm.fungandrui.expediente.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

import com.srm.pli.utils.PropertiesDb;
import com.truper.expediente.NotificationDTO;
import com.truper.expediente.RequestAuth;
import com.truper.expediente.StandarResponse;
@Service
public class NotificacionServiceImp implements NotificacionService {

	private final String PROPERTY_URL="srm.truper.expediente";
	
	private final String usrExpe = PropertiesDb.getInstance().getString("api.expediente.user");
	private final String passExpe = PropertiesDb.getInstance().getString("api.expediente.pass");
	
	@Autowired
	private RestTemplate restTemplate= new RestTemplate();
	
	@Override
	public boolean delete(Long id) {
		String url = PropertiesDb.getInstance().getString(PROPERTY_URL);
		ResponseEntity<StandarResponse<String>> responseAuthen=authenticated(usrExpe,passExpe, url +"/auth/");
		if(responseAuthen.getStatusCode()== HttpStatus.OK) {
			String urlDelete =  url+"/rabbit";
			return deleteNotification(responseAuthen.getBody(),id,urlDelete);
		}
		return false;
	}

	@Override
	public List<NotificationDTO> getNotifications(String usuario) {
		List<NotificationDTO> lista = new ArrayList<NotificationDTO>();
		String url = PropertiesDb.getInstance().getString(PROPERTY_URL);
		ResponseEntity<StandarResponse<String>> responseAuthen=authenticated(usrExpe,passExpe, url +"/auth/");
		if(responseAuthen.getStatusCode()== HttpStatus.OK) {
			String urlDelete = url+"/rabbit";
			lista = findAllNotifications(responseAuthen.getBody(),usuario,urlDelete);
		}
		return lista;
	}
	@SuppressWarnings("unused")
	private  ResponseEntity<StandarResponse<String>> authenticated(final String user, final String pass, final String url) {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
		HttpEntity<RequestAuth> request = new HttpEntity<>(new RequestAuth(user, pass), headers);
		return restTemplate.exchange(url, HttpMethod.POST, request,
					new ParameterizedTypeReference<StandarResponse<String>>() {});
		
	}
	@SuppressWarnings("unused")
	private Boolean deleteNotification(final StandarResponse<?> responseAuth,final Long id,final String url) {
		Boolean response= false;
		HttpHeaders headers = new HttpHeaders();
		UriComponents builder = UriComponentsBuilder.fromHttpUrl(url)
                .queryParam("id", id.toString())
                .build(); 
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.set("Authorization", "Bearer " + (String) responseAuth.getData());
		headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
		HttpEntity<String> request = new HttpEntity<String>(headers);
		ResponseEntity<Boolean> respuesta =restTemplate.exchange(builder.toUriString() , HttpMethod.DELETE, request,
				new ParameterizedTypeReference<Boolean>() {});
		if(respuesta.getStatusCode() == HttpStatus.OK) {
			response =  respuesta.getBody();
		}
		return response;
	}
	@SuppressWarnings("unused")
	private List<NotificationDTO> findAllNotifications(
			final StandarResponse<?> responseAuth, final String usuario, final  String url) {
		List<NotificationDTO> lista = new ArrayList<NotificationDTO>();
		HttpHeaders headers = new HttpHeaders();
		UriComponents builder = UriComponentsBuilder.fromHttpUrl(url)
                .queryParam("usuario", usuario)
                .build();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.set("Authorization", "Bearer " + (String) responseAuth.getData());
		headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
		HttpEntity<String> request = new HttpEntity<String>(headers);
		ResponseEntity<List<NotificationDTO>> respuesta =restTemplate.exchange(builder.toUriString() , HttpMethod.GET, request,
				new ParameterizedTypeReference<List<NotificationDTO>>() {});
		if(respuesta.getStatusCode() == HttpStatus.OK) {
			lista =respuesta.getBody();
		}
		return lista;
	}
}
