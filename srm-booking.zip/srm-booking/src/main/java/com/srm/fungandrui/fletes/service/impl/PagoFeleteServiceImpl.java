package com.srm.fungandrui.fletes.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.srm.fungandrui.fletes.entities.EstatusFlete;
import com.srm.fungandrui.fletes.entities.FiltersPagoFletes;
import com.srm.fungandrui.fletes.entities.PagoFlete;
import com.srm.fungandrui.fletes.repository.EstatusFleteDao;
import com.srm.fungandrui.fletes.repository.PagosFleteDao;
import com.srm.fungandrui.fletes.service.PagoFeleteService;

@Service
public class PagoFeleteServiceImpl implements PagoFeleteService {
	
	
	@Autowired
	PagosFleteDao pagosFleteDao;
	
	@Autowired
	private EstatusFleteDao estatusFleteDao;
	

	@Override
	public void addPagoFlete(PagoFlete pagoFlete) {
		// TODO Auto-generated method stub

	}

	@Override
	public List<PagoFlete> getList() {

		return pagosFleteDao.getList();

		
	}

	@Override
	public List<PagoFlete> getListByStatus(String status) {
		
		return pagosFleteDao.getListByStatus(status);
	}

	@Override
	public List<PagoFlete> getListByContenedor(String contenedor) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<PagoFlete> getListByFolio(String folio) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<PagoFlete> getListByFecha(String fecha) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<PagoFlete> getListByFilters(FiltersPagoFletes filtros) {
	
		return pagosFleteDao.getList(filtros);
	}

	@Override
	public List<EstatusFlete> getAllEstatus() {
		return estatusFleteDao.getAll();
	}

}
