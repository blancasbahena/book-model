package com.srm.fungandrui.pis.service;

import java.text.ParseException;
import java.util.List;

import com.srm.fungandrui.pis.dto.FileSignedDTO;
import com.srm.fungandrui.pis.dto.FullProformaInvoiceDTO;
import com.srm.fungandrui.pis.dto.ProformaPdfDTO;

public interface EnvioCorreoPISService {
	
	void enviarCorreoPIS(List<FileSignedDTO> objetoPdf, ProformaPdfDTO pdfDTO, FullProformaInvoiceDTO dto,String filename) throws ParseException;

}
