package com.srm.fungandrui.facturacion.dao;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Map;

import com.srm.fungandrui.facturacion.models.ItemErrorFactura;

import lombok.Data;
import lombok.ToString;
@ToString
@Data
public class PeticionRabbit implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 2383534048054384233L;
	private String operationType;
	private String descriptionOperation;
	private Map<String, Object> payload;
	private String type;
	private String mensaje;
	private ArrayList<ItemErrorFactura> errores; 
}
