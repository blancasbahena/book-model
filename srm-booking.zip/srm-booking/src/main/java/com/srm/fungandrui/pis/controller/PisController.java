package com.srm.fungandrui.pis.controller;
import com.srm.fungandrui.pis.dao.PisDao;
import com.srm.fungandrui.pis.dto.FileSignedDTO;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.srm.fungandrui.pis.dto.FullProformaInvoiceDTO;
import com.srm.fungandrui.pis.dto.ProformaDetalleDTO;
import com.srm.fungandrui.pis.dto.ProformaDetalleHistoricoDTO;
import com.srm.fungandrui.pis.dto.ProformaInvoiceDTO;
import com.srm.fungandrui.pis.dto.ProformaInvoiceHistoricoDTO;
import com.srm.fungandrui.pis.dto.ProformaPdfDTO;
import com.srm.fungandrui.pis.dto.RequestWsPos;
import com.srm.fungandrui.pis.dto.ResponseService;
import com.srm.fungandrui.pis.dto.Respuesta;
import com.srm.fungandrui.pis.repository.ProformaDetalleDao;
import com.srm.fungandrui.pis.repository.ProformaInvoiceDao;
import com.srm.fungandrui.pis.service.EnvioCorreoPISService;
import com.srm.fungandrui.pis.service.PisService;
import com.srm.fungandrui.pis.service.ProformaInvoiceService;
import com.srm.fungandrui.sc.model.BeanSession;
import com.srm.fungandrui.sc.model.ResponseVO;
import com.srm.fungandrui.sc.utils.SessionUtil;
import com.srm.pli.bo.BeanContactoDocumentos;
import com.srm.pli.utils.FuncionesComunesPLI;
import com.srm.pli.utils.GeneraDocumentos;
import com.truper.businessEntity.ImportacionesProveedoresBean;
import com.truper.expediente.enums.Mensajes;

import lombok.extern.slf4j.Slf4j;
@Slf4j
@RestController
@RequestMapping("/pis")
public class PisController {

	@Autowired
	HttpServletRequest request;

	@Autowired
	private PisService pisService;

	@Autowired
	private ProformaInvoiceService proformaService;

	@Autowired
	EnvioCorreoPISService envioCorreoPISService;
	
	@Autowired
	private ProformaDetalleDao detalle;
	
	@Autowired
	private PisDao dao;
	
	@Autowired
	private ProformaInvoiceDao invoice;
	 
	@PostMapping(path = "/addHistorico/", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseService> aagregarProformaHistorico(
			@Valid @RequestBody ProformaInvoiceHistoricoDTO dto) {
		Map<String, Object> data = new HashMap<>();
		try {
			pisService.creaHistoricoProforma(dto);
			Respuesta respuesta = new Respuesta();
			respuesta.setData(data);
			respuesta.setEstado(HttpStatus.OK);
			respuesta.setMensaje("Historico creado con exito");
			respuesta.setTipoMensaje("S");

			return new ResponseEntity<>(respuesta, respuesta.getEstado());
		} catch (ClassNotFoundException e1) {
			log.error(e1.getMessage());
		} catch (SQLException e1) {
			log.error(e1.getMessage());
		}
		return null;

	}

	@PostMapping(path = "/addDetalleHistorico/", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseService> agregarDetalleHistoricoProforma(
			@Valid @RequestBody ProformaDetalleHistoricoDTO dto) {
		Map<String, Object> data = new HashMap<>();
		try {
			pisService.creaHistoricoProformaDetalle(dto);

			Respuesta respuesta = new Respuesta();
			respuesta.setData(data);
			respuesta.setEstado(HttpStatus.OK);
			respuesta.setMensaje("Detalle Historico creado con exito");
			respuesta.setTipoMensaje("S");

			return new ResponseEntity<>(respuesta, respuesta.getEstado());
		} catch (ClassNotFoundException e1) {
			log.error(e1.getMessage());
		} catch (SQLException e1) {
			log.error(e1.getMessage());
		}
		return null;

	}

	@PostMapping(path = "/actualizar/", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseService> actualizarProforma(@Valid @RequestBody ProformaInvoiceDTO dto) {

		try {
			pisService.actualizarProforma(dto);
			Map<String, Object> data = new HashMap<>();
			Respuesta respuesta = new Respuesta();
			respuesta.setData(data);
			respuesta.setEstado(HttpStatus.OK);
			respuesta.setMensaje("Actualizacion con exito");
			respuesta.setTipoMensaje("S");

			return new ResponseEntity<>(respuesta, respuesta.getEstado());
		} catch (ClassNotFoundException e1) {
			log.error(e1.getMessage());
		} catch (SQLException e1) {
			log.error(e1.getMessage());
		}
		return null;

	}

	@PostMapping(path = "/actualizarDetalleHistorico/", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseService> actualizarDetalleHistorico(@Valid @RequestBody ProformaDetalleDTO dto) {

		try {
			pisService.actualizarProformaDetalle(dto);

			Map<String, Object> data = new HashMap<>();
			Respuesta respuesta = new Respuesta();
			respuesta.setData(data);
			respuesta.setEstado(HttpStatus.OK);
			respuesta.setMensaje("Actualizacion detalle  con exito");
			respuesta.setTipoMensaje("S");
			return new ResponseEntity<>(respuesta, respuesta.getEstado());
		} catch (ClassNotFoundException e1) {
			log.error(e1.getMessage());
		} catch (SQLException e1) {
			log.error(e1.getMessage());
		}
		return null;

	}

	@PostMapping(path = "/editaProformaNumber/", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseService> editaProformaNumber(@Valid @RequestBody ProformaInvoiceDTO dto) {

		try {
			pisService.editaProformaNumber(dto);

			Map<String, Object> data = new HashMap<>();
			Respuesta respuesta = new Respuesta();
			respuesta.setData(data);
			respuesta.setEstado(HttpStatus.OK);
			respuesta.setMensaje("Actualizacion detalle  con exito");
			respuesta.setTipoMensaje("S");
			return new ResponseEntity<>(respuesta, respuesta.getEstado());
		} catch (ClassNotFoundException e1) {
			log.error(e1.getMessage());
		} catch (SQLException e1) {
			log.error(e1.getMessage());
		}
		return null;

	}
	
	@PutMapping(path = "/updateFullInvoice/", produces = MediaType.APPLICATION_JSON_VALUE)
	public  ResponseEntity<ResponseVO> updateFullInvoice(@Valid @RequestBody FullProformaInvoiceDTO dto) {
		int idPIS=0;
		ResponseVO response = new ResponseVO();
		if(dto!=null) {
			if(dto.getProformaInvoice()!=null) {
				idPIS = dto.getProformaInvoice().getIdPi();
			}
		}
		try {
			if(dto.getAction()!=null  && dto.getProformaInvoice()!=null && dto.getProformaDetalleLst()!=null  && !dto.getProformaDetalleLst().isEmpty()) {

				log.info("INVOICE ---  INICIO  {} ",dto.getProformaInvoice());
				if (dto.getAction().equalsIgnoreCase("SAVE")) {
					if(dto.getProformaInvoice().getIdPi().intValue() == -1) {
						ProformaInvoiceDTO invoice= pisService.creaProforma(dto);
						idPIS= invoice.getIdPi();
					}else {
						 pisService.updateFullInvoice(dto);
					}
				} else if (dto.getAction().equalsIgnoreCase("SEND")) {
					ProformaPdfDTO pdfDTO = pisService.llenadoPdf(dto);
					String nombreProforma="sign_"+pdfDTO.getFileName();
					String objetoPdf = proformaService.generarProformaPdf(pdfDTO);
					String signObjetoPdf= proformaService.generarProformaPdfClone(dto.getProformaInvoice().getProveedor(),objetoPdf,nombreProforma);
					List<FileSignedDTO> listaAr=new ArrayList<FileSignedDTO>();
					if(signObjetoPdf!=null) {
						listaAr.add(new FileSignedDTO(signObjetoPdf,nombreProforma));
					}else { 
						if(objetoPdf!=null) {
							listaAr.add(new FileSignedDTO(objetoPdf,pdfDTO.getFileName()));
						}
					}
					if (objetoPdf != null && !objetoPdf.equals("")) {
						envioCorreoPISService.enviarCorreoPIS(listaAr, pdfDTO, dto,pdfDTO.getFileName()); 
						if(dto.getProformaInvoice().getIdPi().intValue() == -1) {
							ProformaInvoiceDTO invoice= pisService.creaProforma(dto);
							idPIS = invoice.getIdPi();
							response = leerDetalle(idPIS);
							if(response.getResponseObject()!=null) {
								Map<String, Object> data=  response.getResponseObject();
								dto.setProformaInvoice((ProformaInvoiceDTO)data.get("invoice")); 
								dto.setProformaDetalleLst((List<ProformaDetalleDTO>)data.get("detalles"));
							}
						}else {
							pisService.updateFullInvoice(dto);
						}
						//Se actualiza proforma estatus 10
						dao.actualizarSendProforma(dto.getProformaInvoice());
						pisService.agregarHistorico(dto);
						//Se actualizan las 1que fueron borradas a 2
						try {
							
							log.info("Sen actualizan las pos que tienan 1 : {} "+dto.getProformaDetalleLst().size());
							for(ProformaDetalleDTO d:dto.getProformaDetalleLst()) {
								log.info("Sen actualizan las pos que tienan  : {} - >  {} ",d.getPosicion() ,d.getIdEstatusChange()); 
							}
							proformaService.actualizaPosiciones1to2(dto.getProformaInvoice().getIdPi());
						}catch(Exception e) {log.error("Error al: Actualizar pos estatus 1 que fueron borradas a 2"); }
					}
				}
			}
		} catch (Exception e) {
			log.error("Ocurrio un error al intentar guardar la informacion {} : ", e.getMessage());
			response.setTipoMensaje(Mensajes.TIPO_ERROR.getMensaje());
			response.setMensaje(Mensajes.MSG_ERROR.getMensaje() + e.getMessage());
		}
		response = leerDetalle(idPIS);
		return ResponseEntity.status(HttpStatus.OK).body(response);

	}

	@RequestMapping(value = "/obtenerMontosCantidadesModificadas/{po}", method = RequestMethod.GET)
	public ResponseEntity<ResponseService> obtenerMontosCantidadesModificadas(@PathVariable("po") String po) {
		Map<String, Object> data = new HashMap<>();
		try {

			data.put("data", pisService.obtenerMontosCantidadesModificadas(po));
			Respuesta respuesta = new Respuesta();
			respuesta.setData(data);
			respuesta.setEstado(HttpStatus.OK);
			respuesta.setMensaje("Proforma creada con exito");
			respuesta.setTipoMensaje("S");

			return new ResponseEntity<>(respuesta, respuesta.getEstado());
		} catch (ClassNotFoundException e1) {
			log.error(e1.getMessage());
		} catch (SQLException e1) {
			log.error(e1.getMessage());
		}
		return null;

	}

	@PostMapping(path = "/cargarPos", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseService> obtenerPosSinProforma(@RequestBody RequestWsPos params)
			throws ServletException {
		Map<String, Object> data = new HashMap<>();
		List<ProformaInvoiceDTO> proformasCreadas = proformaService.obtenerListadoPos(params.getClaveProveedor());
		List<String> lista = new ArrayList<>();
		List<ProformaInvoiceDTO> invoiceP = new ArrayList<>();
		List<FullProformaInvoiceDTO> fullProformaInvoiceDTOs = new ArrayList<>();
		for (ProformaInvoiceDTO proforma : proformasCreadas) {
			lista.add(proforma.getNoOrden());

			invoiceP = invoice.getAll(proforma.getIdPi());
			if (invoiceP.get(0).getIdEstatus().getIdEstatus() != 10) {
				FullProformaInvoiceDTO full = new FullProformaInvoiceDTO();
				full.setProformaInvoice(invoiceP.get(0));
				full.setProformaDetalleLst(detalle.getAll(invoiceP.get(0).getIdPi()));
				fullProformaInvoiceDTOs.add(full);
			}
		}
		params.setPos(lista);
		data.put("ordenesCreadas", fullProformaInvoiceDTOs);
		data.put("ordenes", proformaService.obtenerPOs(params));

		Respuesta respuesta = new Respuesta();
		respuesta.setData(data);
		respuesta.setEstado(HttpStatus.OK);
		respuesta.setMensaje("Proforma creada con exito");
		respuesta.setTipoMensaje("S");
		return new ResponseEntity<>(respuesta, respuesta.getEstado());

	}

	@PostMapping(path = "/generaProformaPdf", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseService> generarReporteProformaPdf(@RequestBody ProformaPdfDTO proformaPdf) {
		String data = null;
		Map<String, Object> respuestaReporte = new HashMap<>();

		data = proformaService.generarProformaPdf(proformaPdf);
		Respuesta respuesta = new Respuesta();
		if (data != null) {
			respuestaReporte.put("reporte", data);
			respuesta.setData(respuestaReporte);
			respuesta.setEstado(HttpStatus.OK);
			respuesta.setMensaje("Proforma creada con exito");
			respuesta.setTipoMensaje("S");
		} else {
			respuestaReporte.put("reporte", "");
			respuesta.setData(respuestaReporte);
			respuesta.setEstado(HttpStatus.OK);
			respuesta.setMensaje("Error al generar reporte");
			respuesta.setTipoMensaje("E");
		}

		return new ResponseEntity<>(respuesta, respuesta.getEstado());
	}
	public ResponseVO leerDetalle(Integer  numeroOrden)  {
		ResponseVO response = new ResponseVO();
		HttpSession session = null;
		BeanSession beanSession; 
		Map<String, Object> data = new HashMap<String, Object>();
		session = request.getSession(false);
		beanSession = SessionUtil.validaSesion(session);  
		List<ProformaInvoiceDTO> listInvoice=invoice.getAll( numeroOrden); 
		if(listInvoice!=null && listInvoice.size()>0) {
			ProformaInvoiceDTO dto = listInvoice.get(0);
		
			ImportacionesProveedoresBean  imBeanProv 	= FuncionesComunesPLI.getProveedor(dto.getProveedor());
			String  inco = (imBeanProv.getIncotetm_cve() != null ? imBeanProv.getIncotetm_cve() : "" );
			inco+= ", ";
			inco+= (imBeanProv.getIncotetm_def() != null ? imBeanProv.getIncotetm_def() : "" );
			inco+= ", ";
			inco+= (imBeanProv.getPais() != null ? imBeanProv.getPais() : "" );

			
			listInvoice.get(0).setIncoterm(inco);
			String condPagoDesc="";
			try {
				condPagoDesc = dto.getCondicionPago() +"|"+ 
						FuncionesComunesPLI.dameMapaCondicionPago(false).get(dto.getCondicionPago());
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			listInvoice.get(0).setCondicionPago(condPagoDesc); 
			data.put("invoice",listInvoice.get(0));
			List<ProformaDetalleDTO> listDetalle=detalle.getAll(numeroOrden); 
			
			String company = "";
			ImportacionesProveedoresBean consignee = new ImportacionesProveedoresBean();
			GeneraDocumentos generaDocumentos = new GeneraDocumentos();
			BeanContactoDocumentos documentos = new BeanContactoDocumentos();

			try {
				if(consignee != null) {
					consignee = FuncionesComunesPLI.getProveedor(listDetalle.get(0).getCliente());
				}
				
				documentos = generaDocumentos.generaContactosDocumentos(imBeanProv, consignee);
				company = documentos.getNombre_shipper();
			} catch (Exception e) {
				log.error("Ocurrio un error al intentar obtener la empresa {} : ", e.getMessage());
			}
		
			data.put("company", company);
			log.info("Se obtuvo  company : "+company);
			data.put("detalles",listDetalle);
			log.info("Se obtuvo  listDetalle : "+listDetalle.size());
		} 
		response.setTipoMensaje(Mensajes.TIPO_EXITO.getMensaje());
		response.setMensaje(Mensajes.MSG_EXITO.getMensaje());
		response.setResponseObject(data); 
		return  response;
	}
	
	
	@GetMapping(path = "/getPDF", produces = MediaType.APPLICATION_JSON_VALUE)
	public  ResponseEntity<ResponseVO> getPDF(@RequestParam Integer idPi,@RequestParam int limpio) {
		ResponseVO response = new ResponseVO();
		Map<String, Object> responseObject = new HashMap<>();
		try { 
			ProformaInvoiceDTO proformaInvoice =  dao.getProforma(idPi);
			List<ProformaDetalleDTO> proformaDetalleLst= dao.getProformaDetalle(idPi);
			if(proformaInvoice.getIncoterm()==null && proformaInvoice.getDetalles()!=null &&proformaInvoice.getDetalles().size()>0) {
				proformaInvoice.setIncoterm(proformaInvoice.getDetalles().get(0).getIncotermPrv());
			}
			
			List<ProformaDetalleDTO> proformDe=  new ArrayList<ProformaDetalleDTO>();
			if(proformaDetalleLst!=null) {
				for(ProformaDetalleDTO d:proformaDetalleLst) {
					//Toma la pos que se enviaron y no limpieas
					//El pdf que se envio por correo.
					if(d.getIdEstatusChange()==0 && limpio==0) {  
						proformDe.add(d);
					}
					//Toma la pos que se enviaron y no limpieas
					//El pdf que se envio por correo.
					if(limpio==1) { 
						d.setCantidadEnviada(d.getCantidadOriginal());
						d.setShippingDateEnviado(d.getShippingDate());
						d.setVolumenEnviado(d.getVolumenOriginal());
						d.setMontoEnviado(d.getMontoOriginal());
						d.setPesoEnviado(d.getPesoOriginal());
						d.setPrecioUnitarioEnviado(d.getPrecioUnitarioOriginal());  
						proformDe.add(d);
					}
				}
			} 
			FullProformaInvoiceDTO fullDTO= new FullProformaInvoiceDTO(proformaInvoice,proformDe,"VERPDF");
			String objetoPdf ="";
			ProformaPdfDTO pdfDTO =null;
			if(limpio==1) { 
				pdfDTO=pisService.llenadoPdfTodo(fullDTO);
				objetoPdf = proformaService.generarProformaPdf(pdfDTO);
				responseObject.put("PDF", objetoPdf);
			}
			else {
				pdfDTO=pisService.llenadoPdf(fullDTO);
				objetoPdf = proformaService.generarProformaPdf(pdfDTO);
				String nombreProforma="sign_"+pdfDTO.getFileName(); 
				String signObjetoPdf= proformaService.generarProformaPdfClone(proformaInvoice.getProveedor(),objetoPdf,nombreProforma);	
				responseObject.put("PDF", signObjetoPdf);
			}
			response.setResponseObject(responseObject);
			response.setTipoMensaje(Mensajes.MSG_EXITO.getMensaje());
			response.setMensaje(Mensajes.MSG_EXITO.getMensaje());
		} catch (Exception e) {
			log.error("Ocurrio un error al intentar guardar la informacion {} : ", e.getMessage());
			response.setTipoMensaje(Mensajes.TIPO_ERROR.getMensaje());
			response.setMensaje(Mensajes.MSG_ERROR.getMensaje() + e.getMessage());
		}
		return ResponseEntity.status(HttpStatus.OK).body(response);

	}
	
}
