package com.srm.fungandrui.pis.service.impl;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.Format;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.srm.fungandrui.pis.dao.PisDao;
import com.srm.fungandrui.pis.dto.CatalogoPIDTO;
import com.srm.fungandrui.pis.dto.FullProformaInvoiceDTO;
import com.srm.fungandrui.pis.dto.PiDetallePdfDTO;
import com.srm.fungandrui.pis.dto.PiOrdenPdfDTO;
import com.srm.fungandrui.pis.dto.PiPdfDTO;
import com.srm.fungandrui.pis.dto.ProformaDetalleDTO;
import com.srm.fungandrui.pis.dto.ProformaDetalleHistoricoDTO;
import com.srm.fungandrui.pis.dto.ProformaInvoiceDTO;
import com.srm.fungandrui.pis.dto.ProformaInvoiceHistoricoDTO;
import com.srm.fungandrui.pis.dto.ProformaPdfDTO;
import com.srm.fungandrui.pis.dto.Respuesta;
import com.srm.fungandrui.pis.dto.SumaMontosPIDTO;
import com.srm.fungandrui.pis.service.PisService;
import com.srm.fungandrui.pis.util.EnglishNumberToWords;
import com.srm.pli.bo.BeanContactoDocumentos;
import com.srm.pli.utils.FuncionesComunesPLI;
import com.srm.pli.utils.GeneraDocumentos;
import com.srm.pli.utils.PropertiesDb;
import com.truper.businessEntity.ContenedorCDI;
import com.truper.businessEntity.ImportacionesProveedoresBean;

import lombok.extern.log4j.Log4j2;

@Service
@Log4j2
public class PisServiceImpl implements PisService {

	public static String LEYENDA_MADERA_SI = "SOLID WOOD PACKING MATERIAL CONTAINED ON THIS SHIPMENT IS MARKED AND TREATED ACCORDING TO IPPC AND NOM-144 REQUIREMENTS";
	public static String LEYENDA_MADERA_NO = "THIS SHIPMENT DOES NOT CONTAIN SOLID WOOD PACKING MATERIAL";
	public static String LEYENDA_ORIGEN0 = "WE CERTIFY THAT ";
	public static String LEYENDA_ORIGEN1 = " IS THE COUNTRY OF ORIGIN OF THE GOODS HERE INVOICED";
	public static String MENSAJE1 = "THIS SHIPMENT DOES NOT CONTAIN SOLID WOOD PACKING MATERIAL";
	public static String MENSAJE2 = "WE CERTIFY THAT China IS THE COUNTRY OF ORIGIN OF THE GOODS HERE INVOINCED";

	public static String[] SUFFIXES =
			// 0 1 2 3 4 5 6 7 8 9
			{ "th", "st", "nd", "rd", "th", "th", "th", "th", "th", "th",
					// 10 11 12 13 14 15 16 17 18 19
					"th", "th", "th", "th", "th", "th", "th", "th", "th", "th",
					// 20 21 22 23 24 25 26 27 28 29
					"th", "st", "nd", "rd", "th", "th", "th", "th", "th", "th",
					// 30 31
					"th", "st" };
	private ProformaInvoiceDTO proformaInvoice=null;
	@Autowired
	private PisDao dao;

	@Override
	public ProformaInvoiceDTO creaProforma(FullProformaInvoiceDTO dto) throws ClassNotFoundException, SQLException {
		AtomicBoolean flagModCantidad = new AtomicBoolean();
		AtomicBoolean flagModPrice = new AtomicBoolean();
		AtomicBoolean flagModShipping = new AtomicBoolean();
		try {
			dto.getProformaDetalleLst().forEach((objDetalle) -> {
				if (objDetalle.isFlgModCantidad()) {
					flagModCantidad.set(true);
				}

				if (objDetalle.isFlgModPrice()) {
					flagModPrice.set(true);
				}

				if (objDetalle.isFlgModShipping()) {
					flagModShipping.set(true);
				}
			});
			proformaInvoice= dto.getProformaInvoice();
			proformaInvoice.setCantidadModificada(flagModCantidad.get());
			proformaInvoice.setPrecioModificado(flagModPrice.get());
			proformaInvoice.setShippingModificado(flagModShipping.get());
			proformaInvoice = dao.creaProforma(proformaInvoice);
			dto.getProformaDetalleLst().forEach((objDetalle) -> {
				try {
					objDetalle.setIdPI(proformaInvoice.getIdPi());
					dao.creaProformaDetalle(objDetalle);
				} catch (ClassNotFoundException | SQLException e) {
					e.printStackTrace();
					throw new RuntimeException(e);
				}
			});
			return proformaInvoice;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public void creaProformaDetalle(ProformaDetalleDTO dto) throws ClassNotFoundException, SQLException {
		dao.creaProformaDetalle(dto);

	}

	@Override
	public void creaHistoricoProforma(ProformaInvoiceHistoricoDTO dto) throws SQLException, ClassNotFoundException {
		dao.creaHistoricoProforma(dto);

	}

	@Override
	public void creaHistoricoProformaDetalle(ProformaDetalleHistoricoDTO dto)
			throws ClassNotFoundException, SQLException {
		dao.creaHistoricoProformaDetalle(dto);

	}

	@Override
	public void actualizarProforma(ProformaInvoiceDTO dto) throws SQLException, ClassNotFoundException {
		dao.actualizarProforma(dto);

	}

	@Override
	public void actualizarProformaDetalle(ProformaDetalleDTO dto) throws ClassNotFoundException, SQLException {
		dao.actualizarProformaDetalle(dto);

	}

	@Override
	public void editaProformaNumber(ProformaInvoiceDTO dto) throws ClassNotFoundException, SQLException {
		dao.editaProformaNumber(dto);

	}

	@Override
	public Respuesta updateFullInvoice(FullProformaInvoiceDTO dto) {

		Respuesta resp = new Respuesta();

		AtomicBoolean flagModCantidad = new AtomicBoolean();
		AtomicBoolean flagModPrice = new AtomicBoolean();
		AtomicBoolean flagModShipping = new AtomicBoolean();

		try {

			dto.getProformaDetalleLst().forEach((objDetalle) -> {

				if (objDetalle.isFlgModCantidad()) {
					flagModCantidad.set(true);
				}

				if (objDetalle.isFlgModPrice()) {
					flagModPrice.set(true);
				}

				if (objDetalle.isFlgModShipping()) {
					flagModShipping.set(true);
				}

				try {
					dao.actualizarProformaDetalle(objDetalle);
				} catch (ClassNotFoundException | SQLException e) {
					log.error("Ocurrio un error al intentar actualizar la proforma {} : ", e.getMessage());
					throw new RuntimeException(e);
				}
			});

			dto.getProformaInvoice().setCantidadModificada(flagModCantidad.get());
			dto.getProformaInvoice().setPrecioModificado(flagModPrice.get());
			dto.getProformaInvoice().setShippingModificado(flagModShipping.get());

			if (dto.getAction().equalsIgnoreCase("SEND")) {
				dao.actualizarSendProforma(dto.getProformaInvoice());
			} else {
				dao.actualizarProforma(dto.getProformaInvoice());
			}

			resp.setEstado(HttpStatus.OK);
			resp.setMensaje("Proforma actualizada con exito");
		} catch (Exception e) {
			log.error("Ocurrio un error al intentar actualizar la proforma {} : ", e.getMessage());

			resp.setTipoMensaje("E");
			resp.setMensaje("Error al actualizar la PI");
			resp.setEstado(HttpStatus.BAD_REQUEST);
		}

		return resp;
	}

	@Override
	public SumaMontosPIDTO obtenerMontosCantidadesModificadas(String po) throws ClassNotFoundException, SQLException {
		return dao.obtenerMontosCantidadesModificadas(po);
	}

	@Override
	public Respuesta agregarHistorico(FullProformaInvoiceDTO dto) {

		Respuesta resp = new Respuesta();

		try {

			dao.creaHistoricoProforma(convertObject(dto.getProformaInvoice()));

			dto.getProformaDetalleLst().forEach((objDetalle) -> {

				try {
					dao.creaHistoricoProformaDetalle(convertObjectHistorico(objDetalle));
				} catch (Exception e) {
					log.error("Ocurrio un error al intentar guardar el historico de la proforma {} : ", e.getMessage());
					throw new RuntimeException(e);
				}

			});

			resp.setEstado(HttpStatus.OK);
			resp.setMensaje("Proforma actualizada con exito");
			resp.setTipoMensaje("S");

		} catch (Exception e) {
			e.printStackTrace();
			log.error("Ocurrio un error al intentar guardar el historico de la proforma {} : ", e.getMessage());

			resp.setTipoMensaje("E");
			resp.setMensaje("Error al guardar el historico de la PI");
			resp.setEstado(HttpStatus.BAD_REQUEST);
		}

		return resp;
	}
	@Override
	public ProformaInvoiceHistoricoDTO convertObject(ProformaInvoiceDTO proformaInvoiceDTO) {

		CatalogoPIDTO catalogoPIDTO = new CatalogoPIDTO();
		catalogoPIDTO.setActivo(proformaInvoiceDTO.getIdEstatus().isActivo());
		catalogoPIDTO.setIdEstatus(proformaInvoiceDTO.getIdEstatus().getIdEstatus());
		catalogoPIDTO.setStatus(proformaInvoiceDTO.getIdEstatus().getStatus());

		ProformaInvoiceHistoricoDTO dto = new ProformaInvoiceHistoricoDTO();
		dto.setIdPi(proformaInvoiceDTO.getIdPi());
		dto.setProveedor(proformaInvoiceDTO.getProveedor());
		dto.setNoOrden(proformaInvoiceDTO.getNoOrden());
		dto.setProformaNumber(proformaInvoiceDTO.getProformaNumber());
		dto.setProformaDate(proformaInvoiceDTO.getProformaDate());
		dto.setCondicionPago(proformaInvoiceDTO.getCondicionPago());
		dto.setShippingPort(proformaInvoiceDTO.getShippingPort());
		dto.setShippingDate(proformaInvoiceDTO.getShippingDate());
		dto.setFullContainer(proformaInvoiceDTO.isFullContainer());
		dto.setPosModificadas(proformaInvoiceDTO.isPosModificadas());
		dto.setIdEstatus(catalogoPIDTO);

		return dto;

	}
	@Override
	public ProformaDetalleHistoricoDTO convertObjectHistorico(ProformaDetalleDTO objDetalle) {

		ProformaDetalleHistoricoDTO dto = new ProformaDetalleHistoricoDTO();
		dto.setNoOrden(objDetalle.getNoOrden());
		dto.setPosicion(objDetalle.getPosicion());
		dto.setIdPI(objDetalle.getIdPI());
		dto.setBrand(objDetalle.getBrand());
		dto.setItem(objDetalle.getItem());
		dto.setCode(objDetalle.getCode());
		dto.setDescription(objDetalle.getDescription());
		dto.setShippingDate(objDetalle.getShippingDate());
		dto.setCantidadOriginal(objDetalle.getCantidadOriginal());
		dto.setUnidadeMedida(objDetalle.getUnidadeMedida());
		dto.setPrecioUnitario(objDetalle.getPrecioUnitarioEnviado()); // revisar cual enviar
		dto.setCantidadEnviada(objDetalle.getCantidadEnviada());
		dto.setMontoOriginal(objDetalle.getMontoOriginal());
		dto.setMontoEnviado(objDetalle.getMontoEnviado());
		dto.setPesoOriginal(objDetalle.getPesoOriginal());
		dto.setPesoEnviado(objDetalle.getPesoEnviado());
		dto.setVolumenOriginal(objDetalle.getVolumenOriginal());
		dto.setVolumenEnviado(objDetalle.getVolumenEnviado());
		dto.setFoc(objDetalle.isFoc());
		dto.setOtherItem(objDetalle.isOtherItem());

		return dto;
	}

	@Override
	public ProformaPdfDTO llenadoPdf(FullProformaInvoiceDTO dto) throws ParseException {

		ArrayList<PiDetallePdfDTO> detalles = new ArrayList<>();
		DecimalFormat df = new DecimalFormat("#,##0.00");
		DecimalFormat dfdecimals = new DecimalFormat("#,###.0000");
		DecimalFormat dfc = new DecimalFormat("#,###");

		DateFormat fromFormate = new SimpleDateFormat("yyyyMMdd");
		DateFormat toFormate = new SimpleDateFormat("dd/MM/yyyy");

		BigDecimal subtotalPo = new BigDecimal(0);
		BigDecimal subtotalOther = new BigDecimal(0);
		BigDecimal subtotalOtherFoc = new BigDecimal(0);
		
		BigDecimal subtotalPeso = new BigDecimal(0);
		BigDecimal subtotalVolumen = new BigDecimal(0);
		
		boolean modificaShipping = false;
		boolean modificaCantidad = false;
		boolean modificaPrecio = false;
		
		int totalCantidad = 0;
		for(ProformaDetalleDTO obj :dto.getProformaDetalleLst()) {
			obj.setFlgModShipping(!obj.getShippingDate().equals(obj.getShippingDateEnviado()));
			obj.setFlgModCantidad(!obj.getCantidadOriginal().equals(obj.getCantidadEnviada()));
			obj.setFlgModPrice(!obj.getPrecioUnitarioOriginal().equals(obj.getPrecioUnitarioEnviado()));
		}
		for (ProformaDetalleDTO obj : dto.getProformaDetalleLst()) {
			if(obj.getIdEstatusChange()==0) {
				if (obj.isFlgModShipping()) {
					modificaShipping = true;
				}
				if (obj.isFlgModCantidad()) {
					modificaCantidad = true;
				}
				if (obj.isFlgModPrice()) {
					modificaPrecio = true;
				}
	
				if (obj.isOtherItem()) {
					subtotalOther = subtotalOther.add(obj.getMontoEnviado());
				} else if (obj.isFoc()) {
					subtotalOtherFoc = subtotalOtherFoc.add(obj.getMontoEnviado());
				} else {
					subtotalPo = subtotalPo.add(obj.getMontoEnviado());
				}
	
				totalCantidad += totalCantidad + obj.getCantidadEnviada();
				
				subtotalPeso = subtotalPeso.add(obj.getPesoEnviado());
				subtotalVolumen = subtotalVolumen.add(obj.getVolumenEnviado());
				
				PiDetallePdfDTO detalle = new PiDetallePdfDTO();
				detalle.setCantidad(dfc.format(obj.getCantidadEnviada()));
				detalle.setCodigo(obj.getCode());
				detalle.setDescripcion(obj.getDescription());
				detalle.setMarca(obj.getBrand());
				detalle.setPeso(df.format(obj.getPesoEnviado()));
				detalle.setPo(obj.getNoOrden());
				detalle.setPosicion(obj.getItem());
				detalle.setPrecioUnitario(dfdecimals.format(obj.getPrecioUnitarioEnviado()));
				
				detalle.setModificaCantidad(modificaCantidad);
				detalle.setModificaPrecio(modificaPrecio);
				detalle.setModificaShipping(modificaShipping);
	
				Date d = fromFormate.parse(obj.getShippingDateEnviado().toString());
				detalle.setShippingDate(toFormate.format(d));
	
				detalle.setTotal(df.format(obj.getMontoEnviado()));
				detalle.setUnidad(obj.getUnidadeMedida());
				detalle.setVolumen(df.format(obj.getVolumenEnviado()));
	
				detalles.add(detalle);
			}
		}

		PiOrdenPdfDTO piOrdenPdfDTO = new PiOrdenPdfDTO();
		piOrdenPdfDTO.setDetalles(detalles);
		piOrdenPdfDTO.setSubtotalPO(df.format(subtotalPo.doubleValue()));
		piOrdenPdfDTO.setSubtotalOther(df.format(subtotalOtherFoc.doubleValue()));
		piOrdenPdfDTO.setSubPeso(df.format(subtotalPeso.doubleValue()));
		piOrdenPdfDTO.setSubVolumen(df.format(subtotalVolumen.doubleValue()));
		

		ArrayList<PiOrdenPdfDTO> listaPi = new ArrayList<PiOrdenPdfDTO>();
		listaPi.add(piOrdenPdfDTO);

		PiPdfDTO piPdfDTO = new PiPdfDTO();
		piPdfDTO.setOrdenPI(listaPi);

		Map<String, Object> params = obtenerParams(dto, df.format(subtotalPo.doubleValue()),
				df.format(subtotalOther.doubleValue()), df.format(subtotalOtherFoc.doubleValue()),
				dfc.format(totalCantidad), subtotalPo.doubleValue());

		ProformaPdfDTO pdfDTO = new ProformaPdfDTO();
		pdfDTO.setFileName(dto.getProformaInvoice().getProformaNumber().trim() + ".pdf");
		pdfDTO.setDatosPI(piPdfDTO);
		pdfDTO.setParams(params);

		return pdfDTO;

	}

	private Map<String, Object> obtenerParams(FullProformaInvoiceDTO dto, String subtotalPo, String subtotalOther,
			String subtotalOtherFoc, String totalCantidad, double subtotalPoNumber) throws ParseException {
		ImportacionesProveedoresBean consignee = new ImportacionesProveedoresBean();
		GeneraDocumentos generaDocumentos = new GeneraDocumentos();
		BeanContactoDocumentos contactos = new BeanContactoDocumentos();

		ImportacionesProveedoresBean proveedor = FuncionesComunesPLI
				.getProveedor(dto.getProformaInvoice().getProveedor());

		try {
			if (consignee != null) {
				consignee = FuncionesComunesPLI.getProveedor(dto.getProformaDetalleLst().get(0).getCliente());
			}

			contactos = generaDocumentos.generaContactosDocumentos(proveedor, consignee);

		} catch (Exception e) {
			log.error("Ocurrio un error al intentar obtener la informacion para los params {} : ", e.getMessage());
		}

		Map<String, Object> params = new HashMap<>();

		params.put("subNombre", proveedor.getNombreProveedor() != null ? proveedor.getNombreProveedor() : "");

		StringBuffer direccion2 = new StringBuffer();
		StringBuffer direccion3 = new StringBuffer();

		if (proveedor.getPoblacion() != null) {
			direccion2.append(proveedor.getPoblacion()).append(" ");
		}
		if (proveedor.getRegion() != null) {
			direccion2.append(proveedor.getRegion()).append(" ");
		}
		if (proveedor.getPais() != null) {
			direccion2.append(proveedor.getPais()).append(" ");
		}
		if (proveedor.getCodigoPostal() != null) {
			direccion3.append(proveedor.getCodigoPostal());
		}

		params.put("subDireccion1", (proveedor.getCalleNumero() != null ? proveedor.getCalleNumero() : ""));
		params.put("subDireccion2", direccion2 != null ? direccion2.toString() : "");
		params.put("subDireccion3", direccion3 != null ? direccion3.toString() : "");

		params.put("subTaxId",
				"TAX ID/BUSINESS REGISTRATION: " + (proveedor.getTaxId() != null ? proveedor.getTaxId() : ""));
		params.put("nombre_shipper",
				contactos != null && contactos.getNombre_shipper() != null ? contactos.getNombre_shipper() : "");
		params.put("calle_shipper",
				contactos != null && contactos.getCalle_shipper() != null ? contactos.getCalle_shipper() : "");
		params.put("edo_shipper",
				contactos != null && contactos.getEdo_shipper() != null ? contactos.getEdo_shipper() : "");
		params.put("pais_shipper",
				contactos != null && contactos.getPais_shipper() != null ? contactos.getPais_shipper() : "");
		params.put("rfc_shipper",
				contactos != null && contactos.getRfc_shipper() != null ? contactos.getRfc_shipper() : "");
		params.put("OrderNo", dto.getProformaInvoice().getNoOrden().toString());
		params.put("invoiceNo", dto.getProformaInvoice().getProformaNumber().toString());

		params.put("invoiceDate", formatDate(dto.getProformaInvoice().getProformaDate().toString()));
		
		
		String condPagoDesc = "-|-";
		try {
			if(dto.getProformaInvoice().getCondicionPago() != null && !dto.getProformaInvoice().getCondicionPago().equals("")) {
				condPagoDesc = dto.getProformaInvoice().getCondicionPago() +"|"+ 
						limpia(FuncionesComunesPLI.dameMapaCondicionPago(false).get(dto.getProformaInvoice().getCondicionPago()));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} 
		params.put("terminoPago", condPagoDesc);
		params.put("incoTerm", "-");
		if(dto.getProformaInvoice()!=null)
			if(dto.getProformaInvoice().getIncoterm()!=null)
				params.put("incoTerm", dto.getProformaInvoice().getIncoterm().toString());

		DateFormat fromFormate = new SimpleDateFormat("yyyyMMdd");
		DateFormat toFormate = new SimpleDateFormat("dd/MM/yyyy");
		Date d = fromFormate.parse(String.valueOf(dto.getProformaDetalleLst().get(0).getShippingDateEnviado()));

		params.put("etd", toFormate.format(d));

		params.put("totalCantidad", totalCantidad);
		params.put("moneda",
				dto.getProformaDetalleLst().get(0).getCurrency() != null
						? dto.getProformaDetalleLst().get(0).getCurrency().toString()
						: "");
		
		params.put("subtotalAmountOther", subtotalOther);
		params.put("subtotalPO", subtotalPo);
		params.put("subtotalAmountOtherFOC", subtotalOtherFoc);

		params.put("mensaje1", "");
		params.put("mensaje2", "");
		params.put("shippingPort", dto.getProformaInvoice().getShippingPort()!=null?
				dto.getProformaInvoice().getShippingPort() : "-");
		
		params.put("totalInvoice", subtotalPo);
		params.put("cantidadLetra", convertirCantidadLetra(String.valueOf(subtotalPoNumber))); 

		return params;

	}
	
	private String limpia(String condicionPago) {
		if(condicionPago!=null)
			return "-";
		if(condicionPago.equals("null"))
			return "-";
		return condicionPago;
	}

	private String convertirCantidadLetra(String totalCantidad) {
		
		int dollars = (int) Math.floor(Float.parseFloat(totalCantidad));
		int cent = (int) Math.floor((Float.parseFloat(totalCantidad) - dollars) * 100.0f);

		String s = EnglishNumberToWords.convert(dollars) + " U.S. dollars and " + EnglishNumberToWords.convert(cent)
				+ " cents";

		return s.substring(0,1).toUpperCase() + s.substring(1, s.length());
	}

	private String formatDate(String fecha) {
		
		DateFormat fromFormate = new SimpleDateFormat("yyyyMMdd");
		//DateFormat toFormate = new SimpleDateFormat("dd/MM/yyyy");		
		Date date = null;
		try {
			date = fromFormate.parse(fecha.toString());
		} catch (ParseException e) {
			log.error("Ocurrio un error al obtener la fecha {} : ", e.getMessage());
		}
	
		Format f = new SimpleDateFormat("MMM", new Locale("en"));
		Calendar c = Calendar.getInstance();
		c.setTime(date);
		String mes = f.format(date);
		int day = c.get(Calendar.DAY_OF_MONTH);
		int year = c.get(Calendar.YEAR);
		String dayStr = mes + " " + day + SUFFIXES[day] + "," + " " + year;
		
		return dayStr;
	}
	
	public boolean validarPesoVolumenPorContenedor(String contenedor, List<ProformaDetalleDTO> list) {

		String DEBUG = PropertiesDb.getInstance().getString("bandera.pesoVolumen.pis");

		if (DEBUG.equals("false")) {
			return true;
		}

		BigDecimal subtotalPeso = new BigDecimal(0);
		BigDecimal subtotalVolumen = new BigDecimal(0);

		for (ProformaDetalleDTO obj : list) {
			subtotalPeso = subtotalPeso.add(obj.getPesoEnviado());
			subtotalVolumen = subtotalVolumen.add(obj.getVolumenEnviado());
		}

		ContenedorCDI cont = FuncionesComunesPLI.mapaContenedores.get(Integer.parseInt(contenedor));
		if (cont != null) {

			return (subtotalVolumen.doubleValue() <= cont.getVolumenMaximo()
					&& subtotalVolumen.doubleValue() >= cont.getVolumenMinimo())
					|| (subtotalPeso.doubleValue() <= cont.getPesoMaximo()
							&& subtotalPeso.doubleValue() >= cont.getPesoMinimo());

		}

		return true;
	}
	@Override
	public ProformaPdfDTO llenadoPdfTodo(FullProformaInvoiceDTO dto) throws ParseException {
		ArrayList<PiDetallePdfDTO> detalles = new ArrayList<>();
		DecimalFormat df = new DecimalFormat("#,##0.00");
		DecimalFormat dfdecimals = new DecimalFormat("#,###.0000");
		DecimalFormat dfc = new DecimalFormat("#,###");

		DateFormat fromFormate = new SimpleDateFormat("yyyyMMdd");
		DateFormat toFormate = new SimpleDateFormat("dd/MM/yyyy");

		BigDecimal subtotalPo = new BigDecimal(0);
		BigDecimal subtotalOther = new BigDecimal(0);
		BigDecimal subtotalOtherFoc = new BigDecimal(0);
		
		BigDecimal subtotalPeso = new BigDecimal(0);
		BigDecimal subtotalVolumen = new BigDecimal(0);
		
		boolean modificaShipping = false;
		boolean modificaCantidad = false;
		boolean modificaPrecio = false;
		
		int totalCantidad = 0; 
		for (ProformaDetalleDTO obj : dto.getProformaDetalleLst()) { 
				if (obj.isOtherItem()) {
					subtotalOther = subtotalOther.add(obj.getMontoEnviado());
				} else if (obj.isFoc()) {
					subtotalOtherFoc = subtotalOtherFoc.add(obj.getMontoEnviado());
				} else {
					subtotalPo = subtotalPo.add(obj.getMontoEnviado());
				}
	
				totalCantidad += totalCantidad + obj.getCantidadEnviada();
				
				subtotalPeso = subtotalPeso.add(obj.getPesoEnviado());
				subtotalVolumen = subtotalVolumen.add(obj.getVolumenEnviado());
				
				PiDetallePdfDTO detalle = new PiDetallePdfDTO();
				detalle.setCantidad(dfc.format(obj.getCantidadEnviada()));
				detalle.setCodigo(obj.getCode());
				detalle.setDescripcion(obj.getDescription());
				detalle.setMarca(obj.getBrand());
				detalle.setPeso(df.format(obj.getPesoEnviado()));
				detalle.setPo(obj.getNoOrden());
				detalle.setPosicion(obj.getItem());
				detalle.setPrecioUnitario(dfdecimals.format(obj.getPrecioUnitarioEnviado()));
				
				detalle.setModificaCantidad(modificaCantidad);
				detalle.setModificaPrecio(modificaPrecio);
				detalle.setModificaShipping(modificaShipping);
	
				Date d = fromFormate.parse(obj.getShippingDateEnviado().toString());
				detalle.setShippingDate(toFormate.format(d));
	
				detalle.setTotal(df.format(obj.getMontoEnviado()));
				detalle.setUnidad(obj.getUnidadeMedida());
				detalle.setVolumen(df.format(obj.getVolumenEnviado()));
	
				detalles.add(detalle);
			
		}

		PiOrdenPdfDTO piOrdenPdfDTO = new PiOrdenPdfDTO();
		piOrdenPdfDTO.setDetalles(detalles);
		piOrdenPdfDTO.setSubtotalPO(df.format(subtotalPo.doubleValue()));
		piOrdenPdfDTO.setSubtotalOther(df.format(subtotalOtherFoc.doubleValue()));
		piOrdenPdfDTO.setSubPeso(df.format(subtotalPeso.doubleValue()));
		piOrdenPdfDTO.setSubVolumen(df.format(subtotalVolumen.doubleValue()));
		

		ArrayList<PiOrdenPdfDTO> listaPi = new ArrayList<PiOrdenPdfDTO>();
		listaPi.add(piOrdenPdfDTO);

		PiPdfDTO piPdfDTO = new PiPdfDTO();
		piPdfDTO.setOrdenPI(listaPi);

		Map<String, Object> params = obtenerParams(dto, df.format(subtotalPo.doubleValue()),
				df.format(subtotalOther.doubleValue()), df.format(subtotalOtherFoc.doubleValue()),
				dfc.format(totalCantidad), subtotalPo.doubleValue());

		ProformaPdfDTO pdfDTO = new ProformaPdfDTO();
		pdfDTO.setFileName(dto.getProformaInvoice().getProformaNumber().trim() + ".pdf");
		pdfDTO.setDatosPI(piPdfDTO);
		pdfDTO.setParams(params);

		return pdfDTO;
	}
}
