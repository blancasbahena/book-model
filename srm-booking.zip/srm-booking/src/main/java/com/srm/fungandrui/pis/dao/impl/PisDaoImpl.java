package com.srm.fungandrui.pis.dao.impl;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.srm.fungandrui.pis.dao.PisDao;
import com.srm.fungandrui.pis.dto.PeticionCambioEstatusDTO;
import com.srm.fungandrui.pis.dto.ProformaDetalleDTO;
import com.srm.fungandrui.pis.dto.ProformaDetalleHistoricoDTO;
import com.srm.fungandrui.pis.dto.ProformaInvoiceDTO;
import com.srm.fungandrui.pis.dto.ProformaInvoiceHistoricoDTO;
import com.srm.fungandrui.pis.dto.SumaMontosPIDTO;
import com.srm.fungandrui.pis.util.Querys;
import com.srm.pli.db.ConexionDB;
import com.srm.pli.utils.FuncionesComunesPLI;
import com.truper.businessEntity.ImportacionesProveedoresBean;

import lombok.extern.slf4j.Slf4j;
@Slf4j
@Repository
public class PisDaoImpl implements PisDao{
	
	

	@Override
	public ProformaInvoiceDTO creaProforma(ProformaInvoiceDTO dto)  throws SQLException, ClassNotFoundException {
		Connection conn = ConexionDB.dameConexion() ;
		Integer lastId = -1;
		
		try {
			PreparedStatement stmt = conn.prepareStatement(Querys.CREA_PROFORMA, Statement.RETURN_GENERATED_KEYS);
			stmt.setString(1, dto.getProveedor().trim());
			stmt.setString(2, dto.getNoOrden().trim());
			stmt.setString(3, dto.getProformaNumber().trim());
			stmt.setInt(4, dto.getProformaDate());
			stmt.setString(5, dto.getCondicionPago());
			stmt.setInt(6, dto.getShippingDate());
			stmt.setBoolean(7, dto.isFullContainer());
			stmt.setInt(8, 1);
			stmt.setString(9,    dto.isPosModificadas()?"1":"0");
			
			stmt.setBoolean(10, dto.isCantidadModificada());
			stmt.setBoolean(11, dto.isPrecioModificado());
			stmt.setBoolean(12, dto.isShippingModificado());
			stmt.setString(13, dto.getShippingPort());
			stmt.setString(14, dto.getContenedor());
			stmt.executeUpdate();
			lastId= obtenerIdProforma(dto.getProveedor().trim(),dto.getNoOrden().trim(),dto.getProformaNumber().trim());
		}catch (SQLException e) {
			log.error("Error al insertar Proforma Invoice en BD... {} {}", e.getMessage(), e);
			ConexionDB.devolver(conn);
		}catch (Exception e) {
			log.error("Error en BD... {} {}", e.getMessage(), e);
			ConexionDB.devolver(conn);
		}finally {
			ConexionDB.devolver(conn);
		}
		
		dto.setIdPi(lastId);
		return dto;
		
	}

	@Override
	public void creaProformaDetalle(ProformaDetalleDTO dto) throws ClassNotFoundException, SQLException {
		Connection conn = ConexionDB.dameConexion() ;
		
		try {
			PreparedStatement stmt = conn.prepareStatement(Querys.CREA_PROFORMA_DETALLE);
			stmt.setString(1, dto.getNoOrden());
			stmt.setInt(2, dto.getPosicion());
			stmt.setInt(3, dto.getIdPI());
			stmt.setString(4, dto.getBrand());
			stmt.setString(5, dto.getItem());
			stmt.setString(6, dto.getCode());
			stmt.setString(7, dto.getDescription());
			stmt.setInt(8, dto.getShippingDate());
			stmt.setInt(9, dto.getCantidadOriginal());
			stmt.setString(10, dto.getUnidadeMedida());
			
			stmt.setBigDecimal(11, dto.getPrecioUnitarioOriginal());
			stmt.setInt(12, dto.getCantidadEnviada());
			stmt.setBigDecimal(13, dto.getMontoOriginal());
			stmt.setBigDecimal(14, dto.getMontoEnviado());
			stmt.setBigDecimal(15, dto.getPesoOriginal());
			stmt.setBigDecimal(16, dto.getPesoEnviado());
			stmt.setBigDecimal(17, dto.getVolumenOriginal());
			stmt.setBigDecimal(18, dto.getVolumenEnviado());
			stmt.setBoolean(19, dto.isFoc());
			stmt.setBigDecimal(20, dto.getPrecioUnitarioEnviado());
			stmt.setString(21, dto.getCliente());
			stmt.setBoolean(22, dto.isOtherItem());
			stmt.setString(23, dto.getCurrency());
			stmt.setInt(24, dto.getShippingDateEnviado());
			stmt.setString(25, dto.getCentro());
			stmt.setString(26, dto.getPlaneador());
			stmt.setString(27, dto.getAlmacen());
			stmt.setInt(28, dto.getEsPedidoDirecto());
			stmt.executeUpdate();
		}catch (SQLException e) {
			log.error("Error al insertar Proforma Invoice Detalle en BD... {} {}", e.getMessage(), e);
			ConexionDB.devolver(conn);
		}catch (Exception e) {
			log.error("Error en BD... {} {}", e.getMessage(), e);
			ConexionDB.devolver(conn);
		}finally {
			ConexionDB.devolver(conn);
		}
		
	}

	@Override
	public void creaHistoricoProforma(ProformaInvoiceHistoricoDTO dto) throws SQLException, ClassNotFoundException {
		Connection conn = ConexionDB.dameConexion() ;
		
		try {
			PreparedStatement stmt = conn.prepareStatement(Querys.CREA_HISTORICO_PROFORMA);
			stmt.setString(1, dto.getProveedor());
			stmt.setString(2, dto.getNoOrden());
			stmt.setString(3, dto.getProformaNumber());
			stmt.setInt(4, dto.getProformaDate());
			stmt.setString(5, dto.getCondicionPago());
			stmt.setString(6, dto.getShippingPort());
			stmt.setInt(7, dto.getShippingDate());
			stmt.setBoolean(8, dto.isFullContainer());
			stmt.setInt(9, dto.getIdEstatus().getIdEstatus());
			stmt.setBoolean(10, dto.isPosModificadas());
			
			stmt.executeUpdate();
		}catch (SQLException e) {
			log.error("Error al insertar Proforma Invoice Detalle en BD... {} {}", e.getMessage(), e);
			ConexionDB.devolver(conn);
		}catch (Exception e) {
			log.error("Error en BD... {} {}", e.getMessage(), e);
			ConexionDB.devolver(conn);
		}finally {
			ConexionDB.devolver(conn);
		}
		
	}

	@Override
	public void creaHistoricoProformaDetalle(ProformaDetalleHistoricoDTO dto)
			throws ClassNotFoundException, SQLException {
		Connection conn = ConexionDB.dameConexion() ;
		
		try {
			PreparedStatement stmt = conn.prepareStatement(Querys.CREA_HISTORICO_PROFORMA_DETALLE);
			stmt.setString(1, dto.getNoOrden());
			stmt.setInt(2, dto.getPosicion());
			stmt.setInt(3, dto.getIdPI());
			stmt.setString(4, dto.getBrand());
			stmt.setString(5, dto.getItem());
			stmt.setString(6, dto.getCode());
			stmt.setString(7, dto.getDescription());
			stmt.setInt(8, dto.getShippingDate());
			stmt.setInt(9, dto.getCantidadOriginal());
			stmt.setString(10, dto.getUnidadeMedida());
			
			stmt.setBigDecimal(11, dto.getPrecioUnitario());
			stmt.setInt(12, dto.getCantidadEnviada());
			stmt.setBigDecimal(13, dto.getMontoOriginal());
			stmt.setBigDecimal(14, dto.getMontoEnviado());
			stmt.setBigDecimal(15, dto.getPesoOriginal());
			stmt.setBigDecimal(16, dto.getPesoEnviado());
			stmt.setBigDecimal(17, dto.getVolumenOriginal());
			stmt.setBigDecimal(18, dto.getVolumenEnviado());
			stmt.setBoolean(19, dto.isFoc());
			
			stmt.executeUpdate();
		}catch (SQLException e) {
			log.error("Error al insertar Proforma Invoice Detalle en BD... {} {}", e.getMessage(), e);
			ConexionDB.devolver(conn);
		}catch (Exception e) {
			log.error("Error en BD... {} {}", e.getMessage(), e);
			ConexionDB.devolver(conn);
		}finally {
			ConexionDB.devolver(conn);
		}
		
		
	}

	@Override
	public Integer actualizarProforma(ProformaInvoiceDTO dto) throws SQLException, ClassNotFoundException {
		Connection conn = ConexionDB.dameConexion() ;
		int resultado = 0;
		
		try {
			PreparedStatement stmt = conn.prepareStatement(Querys.ACTUALIZAR_PROFORMA);
			stmt.setString(1, dto.getProformaNumber());
			stmt.setBoolean(2, dto.isFullContainer());
			stmt.setBoolean(3, dto.isPosModificadas());
			stmt.setInt(4, dto.getIdPi());
			
			resultado = stmt.executeUpdate();

		}catch (SQLException e) {
			log.error("Error al insertar Proforma Invoice Detalle en BD... {} {}", e.getMessage(), e);
			ConexionDB.devolver(conn);
		}catch (Exception e) {
			log.error("Error en BD... {} {}", e.getMessage(), e);
			ConexionDB.devolver(conn);
		}finally {
			ConexionDB.devolver(conn);
		}

		return resultado;
		
	}
	
	@Override
	public Integer actualizarSendProforma(ProformaInvoiceDTO dto) throws SQLException, ClassNotFoundException {
		Connection conn = ConexionDB.dameConexion() ;
		int resultado = 0;
		
		try {
			PreparedStatement stmt = conn.prepareStatement(Querys.ACTUALIZAR_SEND_PROFORMA);
			stmt.setString(1, dto.getProformaNumber());
			stmt.setBoolean(2, dto.isFullContainer());
			stmt.setBoolean(3, dto.isPosModificadas());
			stmt.setInt(4, 10);
			stmt.setInt(5, dto.getIdPi());
			
			resultado = stmt.executeUpdate();

		}catch (SQLException e) {
			log.error("Error al insertar Proforma Invoice Detalle en BD... {} {}", e.getMessage(), e);
			ConexionDB.devolver(conn);
		}catch (Exception e) {
			log.error("Error en BD... {} {}", e.getMessage(), e);
			ConexionDB.devolver(conn);
		}finally {
			ConexionDB.devolver(conn);
		}

		return resultado;
		
	}

	@Override
	public void actualizarProformaDetalle(ProformaDetalleDTO dto) throws ClassNotFoundException, SQLException {
		Connection conn = ConexionDB.dameConexion() ;
		
		try {
			PreparedStatement stmt = conn.prepareStatement(Querys.ACTUALIZAR_PROFORMA_DETALLE);
			
			stmt.setInt(1, dto.getCantidadEnviada());
			stmt.setBigDecimal(2, dto.getMontoEnviado());
			stmt.setBigDecimal(3, dto.getPesoEnviado());
			stmt.setBigDecimal(4, dto.getVolumenEnviado());
			stmt.setBigDecimal(5, dto.getPrecioUnitarioEnviado());
			stmt.setInt(6, dto.getShippingDateEnviado() );
			stmt.setString(7, dto.getNoOrden());
			stmt.setInt(8, dto.getPosicion());
			stmt.setInt(9, dto.getIdPI());
			
			stmt.executeUpdate();
		}catch (SQLException e) {
			log.error("Error al insertar Proforma Invoice Detalle en BD... {} {}", e.getMessage(), e);
			ConexionDB.devolver(conn);
		}catch (Exception e) {
			log.error("Error en BD... {} {}", e.getMessage(), e);
			ConexionDB.devolver(conn);
		}finally {
			ConexionDB.devolver(conn);
		}
		
		
	}

	@Override
	public void actualizarHistoricoProforma(ProformaInvoiceHistoricoDTO dto)
			throws SQLException, ClassNotFoundException {
		Connection conn = ConexionDB.dameConexion() ;
		
		try {
			PreparedStatement stmt = conn.prepareStatement(Querys.ACTUALIZAR_HISTORICO_PROFORMA);
			stmt.setString(1, dto.getProveedor());
			stmt.setString(2, dto.getNoOrden());
			stmt.setString(3, dto.getProformaNumber());
			stmt.setInt(4, dto.getProformaDate());
			stmt.setString(5, dto.getCondicionPago());
			stmt.setString(6, dto.getShippingPort());
			stmt.setInt(7, dto.getShippingDate());
			stmt.setBoolean(8, false);
			stmt.setInt(9, 1);
			stmt.setString(10, "");
			stmt.setInt(11, dto.getIdPi());
			
			stmt.executeUpdate();
		}catch (SQLException e) {
			log.error("Error al insertar Proforma Invoice Detalle en BD...{} {}", e.getMessage(), e);
			ConexionDB.devolver(conn);
		}catch (Exception e) {
			log.error("Error en BD... {} {}", e.getMessage(), e);
			ConexionDB.devolver(conn);
		}finally {
			ConexionDB.devolver(conn);
		}
		
	}

	@Override
	public void actualizarHistoricoProformaDetalle(ProformaDetalleHistoricoDTO dto)
			throws ClassNotFoundException, SQLException {
		Connection conn = ConexionDB.dameConexion() ;
		
		try {
			PreparedStatement stmt = conn.prepareStatement(Querys.ACTUALIZAR_HISTORICO_PROFORMA_DETALLE);
			
			stmt.setString(1, dto.getBrand());
			stmt.setString(2, dto.getItem());
			stmt.setString(3, dto.getCode());
			stmt.setString(4, dto.getDescription());
			stmt.setInt(5, dto.getShippingDate());
			stmt.setInt(6, dto.getCantidadOriginal());
			stmt.setString(7, dto.getUnidadeMedida());
			stmt.setBigDecimal(8, dto.getPrecioUnitario());
			stmt.setInt(9, dto.getCantidadEnviada());
			stmt.setBigDecimal(10, dto.getMontoOriginal());
			stmt.setBigDecimal(11, dto.getMontoEnviado());
			stmt.setBigDecimal(12, dto.getPesoOriginal());
			stmt.setBigDecimal(13, dto.getPesoEnviado());
			stmt.setBigDecimal(14, dto.getVolumenOriginal());
			stmt.setBigDecimal(15, dto.getVolumenEnviado());
			stmt.setBoolean(16, dto.isFoc());
			stmt.setString(17, dto.getNoOrden());
			stmt.setInt(18, dto.getPosicion());
			stmt.setInt(19, dto.getIdPI());
			
			stmt.executeUpdate();
		}catch (SQLException e) {
			log.error("Error al insertar Proforma Invoice Detalle en BD... {} {} ", e.getMessage(), e);
			ConexionDB.devolver(conn);
		}catch (Exception e) {
			log.error("Error en BD... {} {}", e.getMessage(), e);
			ConexionDB.devolver(conn);
		}finally {
			ConexionDB.devolver(conn);
		}
		
	}

	@Override
	public void editaProformaNumber(ProformaInvoiceDTO dto) throws SQLException, ClassNotFoundException {
		Connection conn = ConexionDB.dameConexion() ;
		int resultado;
			  
		try {
			PreparedStatement stmt = conn.prepareStatement(Querys.EDITA_PROFORMA_NUMBER);
			stmt.setString(1, dto.getProformaNumber());
			stmt.setInt(2, dto.getIdPi());
			stmt.setString(3, dto.getNoOrden());
			resultado = stmt.executeUpdate();
			if (resultado>0) {
				log.info("Row update success!!");
			}
		}catch (SQLException e) {
			log.error("Error al actualizar Proforma Invoice en BD... {} {} ", e.getMessage(), e);
			ConexionDB.devolver(conn);
		}catch (Exception e) {
			log.error("Error en BD... {} {} ", e.getMessage(), e);
			ConexionDB.devolver(conn);
		}finally {
			ConexionDB.devolver(conn);
		}
		
	}

	@Override
	public SumaMontosPIDTO obtenerMontosCantidadesModificadas(String po) throws ClassNotFoundException, SQLException {
		SumaMontosPIDTO data = new SumaMontosPIDTO();
		Connection conn = null;
		
		try {
			conn = ConexionDB.dameConexion();
			try (PreparedStatement pstmt = conn.prepareStatement(Querys.OBTENER_MONTOS_CANTIDADES_MODIFICADAS)) {
				pstmt.setString(1, po);
				ResultSet rs = pstmt.executeQuery();
				while (rs.next()) {
					data.setTotalCantidadEnviada(rs.getBigDecimal("totalCantidadEnviada"));
					data.setTotalMontoEnviado(rs.getBigDecimal("totalMontoEnviado"));
				}
				pstmt.close();
				rs.close();
			} catch (SQLException e) {
				try {
					ConexionDB.renuevaConexion(conn);
				} catch (Exception ex) {
					log.error(ex.getMessage(), ex);
				}
				log.error(e.getMessage(), e);
			}
		} catch (Exception e) {
			try {
				ConexionDB.devuelveConexion(conn);
			} catch (Exception ex) {
				log.error(ex.getMessage().toString(), ex);
			}
			log.error(e.getMessage(), e);
		} finally {
			try {
				ConexionDB.devuelveConexion(conn);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
	}
		return data;
	}

	public int obtenerIdProforma(String proveedor,String noOrden,String proformaNumber) throws ClassNotFoundException, SQLException {
		Connection conn = null;
		int idPi = 0;
		
		try {
			conn = ConexionDB.dameConexion();
			try (PreparedStatement pstmt = conn.prepareStatement(Querys.OBTENER_ID_PROFORMA)) {
				pstmt.setString(1, proveedor);
				pstmt.setString(2, noOrden);
				pstmt.setString(3, proformaNumber);
				ResultSet rs = pstmt.executeQuery();
				if (rs.next()) {
					idPi = rs.getInt("idPI");
				}
				pstmt.close();
				rs.close();
			} catch (SQLException e) {
				try {
					ConexionDB.renuevaConexion(conn);
				} catch (Exception ex) {
					log.error(ex.getMessage(), ex);
				}
				log.error(e.getMessage(), e);
			}
		} catch (Exception e) {
			try {
				ConexionDB.devuelveConexion(conn);
			} catch (Exception ex) {
				log.error(ex.getMessage().toString(), ex);
			}
			log.error(e.getMessage(), e);
		} finally {
			try {
				ConexionDB.devuelveConexion(conn);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
		return idPi;
	}
	@Override
	public List<ProformaInvoiceDTO> getProformaByStatus(Integer idStatus) throws ClassNotFoundException, SQLException {
		List<ProformaInvoiceDTO> lista= new ArrayList<ProformaInvoiceDTO>();
		Connection conn = null;
		try {
			conn = ConexionDB.dameConexion();
			try (PreparedStatement pstmt = conn.prepareStatement(Querys.GET_PROFORMABY_STATUS)) {
				pstmt.setLong(1, idStatus);
				ResultSet rs = pstmt.executeQuery();
				while (rs.next()) { 
					lista.add(regresaProforma(rs));
				}
				pstmt.close();
				rs.close();
			} catch (SQLException e) {
				try {
					ConexionDB.renuevaConexion(conn);
				} catch (Exception ex) {
					log.error(ex.getMessage(), ex);
				}
				log.error(e.getMessage(), e);
			}
		} catch (Exception e) {
			try {
				ConexionDB.devuelveConexion(conn);
			} catch (Exception ex) {
				log.error(ex.getMessage().toString(), ex);
			}
			log.error(e.getMessage(), e);
		} finally {
			try {
				ConexionDB.devuelveConexion(conn);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
		return lista;
	}
	@Override
	public ProformaInvoiceDTO getProforma(Integer idProforma) throws ClassNotFoundException, SQLException {
		ProformaInvoiceDTO data = new ProformaInvoiceDTO();
		Connection conn = null;
		try {
			conn = ConexionDB.dameConexion();
			try (PreparedStatement pstmt = conn.prepareStatement(Querys.GET_PROFORMA)) {
				pstmt.setLong(1, idProforma);
				ResultSet rs = pstmt.executeQuery();
				if (rs.next()) { 
					data= regresaProforma(rs);
				}
				pstmt.close();
				rs.close();
			} catch (SQLException e) {
				try {
					ConexionDB.renuevaConexion(conn);
				} catch (Exception ex) {
					log.error(ex.getMessage(), ex);
				}
				log.error(e.getMessage(), e);
			}
		} catch (Exception e) {
			try {
				ConexionDB.devuelveConexion(conn);
			} catch (Exception ex) {
				log.error(ex.getMessage().toString(), ex);
			}
			log.error(e.getMessage(), e);
		} finally {
			try {
				ConexionDB.devuelveConexion(conn);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
		log.info("Query  :: {}  ",data.getIdPi() );
		return data;
	} 
	@Override
	public List<ProformaInvoiceDTO> getProformaByPOAndEstatus(String PO, Integer idStatus) throws ClassNotFoundException, SQLException {
		List<ProformaInvoiceDTO> lista= new ArrayList<ProformaInvoiceDTO>();
		Connection conn = null;
		try {
			conn = ConexionDB.dameConexion();
			try (PreparedStatement pstmt = conn.prepareStatement(Querys.GET_PROFORMABY_STATUS_PO)) {
				pstmt.setLong(1, idStatus);
				pstmt.setString(2, PO); 
				ResultSet rs = pstmt.executeQuery();
				while (rs.next()) { 
					lista.add(regresaProforma(rs));
				}
				pstmt.close();
				rs.close();
			} catch (SQLException e) {
				try {
					ConexionDB.renuevaConexion(conn);
				} catch (Exception ex) {
					log.error(ex.getMessage(), ex);
				}
				log.error(e.getMessage(), e);
			}
		} catch (Exception e) {
			try {
				ConexionDB.devuelveConexion(conn);
			} catch (Exception ex) {
				log.error(ex.getMessage().toString(), ex);
			}
			log.error(e.getMessage(), e);
		} finally {
			try {
				ConexionDB.devuelveConexion(conn);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
		return lista;
	}
	
	@Override
	public List<ProformaInvoiceDTO> getProformaByPLanerAndEstatus(String planer, Integer idStatus) throws ClassNotFoundException, SQLException {
		List<ProformaInvoiceDTO> lista= new ArrayList<ProformaInvoiceDTO>();
		Connection conn = null;
		try {
			conn = ConexionDB.dameConexion();
			try (PreparedStatement pstmt = conn.prepareStatement(Querys.GET_PROFORMABY_STATUS_PLANER)) {
				pstmt.setLong(1, idStatus);
				pstmt.setString(2, planer); 
				ResultSet rs = pstmt.executeQuery();
				while (rs.next()) { 
					lista.add(regresaProforma(rs));
				}
				pstmt.close();
				rs.close();
			} catch (SQLException e) {
				try {
					ConexionDB.renuevaConexion(conn);
				} catch (Exception ex) {
					log.error(ex.getMessage(), ex);
				}
				log.error(e.getMessage(), e);
			}
		} catch (Exception e) {
			try {
				ConexionDB.devuelveConexion(conn);
			} catch (Exception ex) {
				log.error(ex.getMessage().toString(), ex);
			}
			log.error(e.getMessage(), e);
		} finally {
			try {
				ConexionDB.devuelveConexion(conn);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
		return lista;
	}
	@Override
	public List<ProformaInvoiceDTO> getProformaByProveedorAndEstatus(String proveedor, Integer idStatus) throws ClassNotFoundException, SQLException {
		List<ProformaInvoiceDTO> lista= new ArrayList<ProformaInvoiceDTO>();
		Connection conn = null;
		try {
			conn = ConexionDB.dameConexion();
			try (PreparedStatement pstmt = conn.prepareStatement(Querys.GET_PROFORMABY_STATUS_PROVEEDOR)) {

				pstmt.setLong(1, idStatus);
				pstmt.setString(2,proveedor);
				ResultSet rs = pstmt.executeQuery();
				while (rs.next()) { 
					lista.add(regresaProforma(rs));
				}
				pstmt.close();
				rs.close();
			} catch (SQLException e) {
				try {
					ConexionDB.renuevaConexion(conn);
				} catch (Exception ex) {
					log.error(ex.getMessage(), ex);
				}
				log.error(e.getMessage(), e);
			}
		} catch (Exception e) {
			try {
				ConexionDB.devuelveConexion(conn);
			} catch (Exception ex) {
				log.error(ex.getMessage().toString(), ex);
			}
			log.error(e.getMessage(), e);
		} finally {
			try {
				ConexionDB.devuelveConexion(conn);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
		return lista;
	}
	public List<ProformaDetalleDTO> getProformaDetalle(Integer idProforma) throws ClassNotFoundException, SQLException {
		List<ProformaDetalleDTO> lista = new ArrayList<ProformaDetalleDTO>();
		Connection conn = null;
		try {
			conn = ConexionDB.dameConexion();
			try (PreparedStatement pstmt = conn.prepareStatement(Querys.GET_PROFORMA_DETALLE)) {
				pstmt.setLong(1, idProforma);
				ResultSet rs = pstmt.executeQuery();
				while(rs.next()) {
					ProformaDetalleDTO data= new ProformaDetalleDTO();
					data.setNoOrden(rs.getString("noOrden"));
					data.setPosicion(rs.getInt("posicion"));
					data.setBrand(rs.getString("brand"));
					data.setItem(rs.getString("item"));
					data.setCode(rs.getString("code"));
					data.setNoOrden(rs.getString("noOrden"));
					data.setDescription(rs.getString("description"));
					data.setShippingDate(rs.getInt("shippingDate"));
					data.setShippingDateEnviado(rs.getInt("shippingDateEnviado"));
					data.setCantidadOriginal(rs.getInt("cantidadOriginal"));
					data.setCantidadEnviada(rs.getInt("cantidadEnviada"));
					data.setUnidadeMedida(rs.getString("unidadeMedida"));
					data.setPrecioUnitarioOriginal(rs.getBigDecimal("precioUnitarioOriginal"));
					data.setPrecioUnitarioEnviado(rs.getBigDecimal("precioUnitarioEnviado"));
					data.setMontoOriginal(rs.getBigDecimal("montoOriginal"));
					data.setMontoEnviado(rs.getBigDecimal("montoEnviado"));
					data.setPesoOriginal(rs.getBigDecimal("pesoOriginal"));
					data.setPesoEnviado(rs.getBigDecimal("pesoEnviado"));
					data.setVolumenOriginal(rs.getBigDecimal("volumenOriginal"));
					data.setVolumenEnviado(rs.getBigDecimal("volumenEnviado"));
					data.setFoc(rs.getBoolean("isFoc"));
					data.setCliente(rs.getString("cliente"));
					data.setOtherItem(rs.getBoolean("isOtherItem"));
					data.setCurrency(rs.getString("currency"));
					data.setCentro(rs.getString("centro"));
					data.setPlaneador(rs.getString("planeador"));
					data.setIdEstatusChange(rs.getInt("idEstatusChange"));
					data.setAlmacen(rs.getString("almacen"));
					data.setEsPedidoDirecto(rs.getInt("esPedidoDirecto"));
					data.setMatriz(rs.getString("matriz"));
					data.setValidacionesExtraordinarias(rs.getString("validaciones"));
					lista.add(data);
				}
				pstmt.close();
				rs.close();
			} catch (SQLException e) {
				try {
					ConexionDB.renuevaConexion(conn);
				} catch (Exception ex) {
					log.error(ex.getMessage(), ex);
				}
				log.error(e.getMessage(), e);
			}
		} catch (Exception e) {
			try {
				ConexionDB.devuelveConexion(conn);
			} catch (Exception ex) {
				log.error(ex.getMessage().toString(), ex);
			}
			log.error(e.getMessage(), e);
		} finally {
			try {
				ConexionDB.devuelveConexion(conn);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
		return lista;
	}

	private ProformaInvoiceDTO regresaProforma(ResultSet rs) throws SQLException, ClassNotFoundException {
		ProformaInvoiceDTO data = new ProformaInvoiceDTO();
		String pattern = "yyyyMMdd";
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
		data.setIdPi(rs.getInt("idPi")); 
		data.setNoOrden(rs.getString("noOrden")); 
		data.setProveedor(rs.getString("proveedor"));
		String datosF="";
		String termPa="";
		String dirPro="";
		String taxId="";
		String incotermPrv="";
		try {
			ImportacionesProveedoresBean prov=FuncionesComunesPLI.getProveedor(rs.getString("proveedor"));
			data.setSupplier(prov.getNombreProveedor());
			String  inco = (prov.getIncotetm_cve() != null ? prov.getIncotetm_cve() : "" );
			inco+= ", ";
			inco+= (prov.getIncotetm_def() != null ? prov.getIncotetm_def() : "" );
			inco+= ", ";
			inco+= (prov.getPais() != null ? prov.getPais() : "" );
			incotermPrv=inco;
			taxId=prov.getTaxId();
			dirPro=prov.getCodigoPostal();
			termPa=prov.getCondicionesPago();
			datosF=prov.getRfc();
		}catch(Exception e) {log.error("Problemas al obtener proveedor ",e);}
		data.setProformaNumber(rs.getString("proformaNumber"));
		if(rs.getInt("proformaDate")>0) {
			data.setProformaDate(rs.getInt("proformaDate"));
			try {
				Date fechaactual = new Date(System.currentTimeMillis());
				Date prformaDate = simpleDateFormat.parse(""+rs.getInt("proformaDate"));
				int milisecondsByDay = 86400000;
				int days = (int) ((fechaactual.getTime()-prformaDate.getTime()) / milisecondsByDay);
				data.setDays(""+days);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		data.setCondicionPago(rs.getString("condicionPago"));
		data.setShippingPort(rs.getString("shippingPort"));
		data.setShippingDate(rs.getInt("shippingDate"));
		data.setFullContainer(rs.getBoolean("fullContainer"));
		data.setComentariosRechaza(rs.getString("comentariosRechaza"));
		data.setFechaRechaza(rs.getDate("fechaRechaza"));
		data.setPrecioModificado(rs.getBoolean("precioModificado"));
		data.setShippingModificado(rs.getBoolean("ShippingModificado"));
		data.setCantidadModificada(rs.getBoolean("CantidadModificada"));
		data.setPosModificadas(rs.getBoolean("posModificadas"));
		data.setContenedor(rs.getString("contenedor")); 
		List<ProformaDetalleDTO> lista=getProformaDetalle(data.getIdPi());
		BigDecimal cero = new BigDecimal(0);
		BigDecimal amount = new BigDecimal(0);
		BigDecimal amountE = new BigDecimal(0);
		BigDecimal weight = new BigDecimal(0);
		BigDecimal weightE = new BigDecimal(0);
		BigDecimal volumen = new BigDecimal(0);
		BigDecimal volumenE = new BigDecimal(0);
		BigDecimal price = new BigDecimal(0);
		BigDecimal priceE = new BigDecimal(0);
		for(ProformaDetalleDTO d: lista) {
			amount.add(d.getMontoOriginal()!=null?d.getMontoOriginal():cero);
			amountE.add(d.getMontoEnviado()!=null?d.getMontoEnviado():cero);
			volumen.add(d.getVolumenOriginal()!=null?d.getVolumenOriginal():cero);
			volumenE.add(d.getVolumenEnviado()!=null?d.getVolumenEnviado():cero);
			weight.add(d.getPesoOriginal()!=null?d.getPesoOriginal():cero);
			weightE.add(d.getPesoEnviado()!=null?d.getPesoEnviado():cero);
			price.add(d.getPrecioUnitarioOriginal()!=null?d.getPrecioUnitarioOriginal():cero);
			priceE.add(d.getPrecioUnitarioEnviado()!=null?d.getPrecioUnitarioEnviado():cero);
			if(d.getPlaneador()!=null && data.getPlanner()==null) {
				data.setPlanner(d.getPlaneador());
			}
			String qtyOK="MAL";
			String amountOK="MAL";
			String weightOK="MAL";
			String volumeOK="MAL";
			String priceOK="MAL";
			String etdOK="MAL";
			if(d.getCantidadOriginal()!=null  && d.getCantidadEnviada()!=null)
				if(d.getCantidadOriginal().intValue() ==  d.getCantidadEnviada().intValue() ){
					qtyOK="OK";}
			if(d.getMontoOriginal()!=null  && d.getMontoEnviado()!=null)
				if(d.getMontoOriginal().doubleValue() == d.getMontoEnviado().doubleValue()){
					amountOK="OK";}
			if(d.getPesoOriginal()!=null  && d.getPesoEnviado()!=null)
				if(d.getPesoOriginal().doubleValue() == d.getPesoEnviado().doubleValue()){
					weightOK="OK";}
			if(d.getVolumenOriginal() !=null  && d.getVolumenEnviado()!=null)
				if(d.getVolumenOriginal().doubleValue() == d.getVolumenEnviado().doubleValue()){
					volumeOK="OK";}
			if(d.getPrecioUnitarioOriginal()!=null  && d.getPrecioUnitarioEnviado()!=null)
				if(d.getPrecioUnitarioOriginal().doubleValue()==d.getPrecioUnitarioEnviado().doubleValue()){
					priceOK="OK";}
			if(d.getShippingDate()!=null  && d.getShippingDateEnviado()!=null)
				if(d.getShippingDate().toString().equals(d.getShippingDateEnviado().toString())) {
					etdOK="OK";} 
			
			d.setQtyStr(qtyOK);
			d.setEtdStr(etdOK);
			d.setPriceStr(priceOK);
			d.setAmountStr(amountOK);
			d.setWeightStr(weightOK);
			d.setVolumeStr(volumeOK);
			d.setDatosFiscales(datosF);

			d.setDatosF(datosF);
			d.setTermPa(termPa);
			d.setDirPro(dirPro);
			d.setTaxid(taxId);
			d.setIncotermPrv(incotermPrv);
		}
		data.setAmount(amount);
		data.setAmountEnviado(amountE);
		data.setVolumen(volumen);
		data.setVolumenEnviado(volumenE);
		data.setWeight(weight);
		data.setWeightEnviado(weightE);		
		data.setPrice(price);
		data.setPriceEnviado(priceE);
		data.setDetalles(lista); 
		return data;
	}

	
	@Override
	public int actualizarEstatusDetalle(PeticionCambioEstatusDTO dto) throws SQLException, ClassNotFoundException {
		Connection conn = ConexionDB.dameConexion() ; 
		int resultado = 0;
		try {
			PreparedStatement stmt = conn.prepareStatement(Querys.CAMBIA_ESTATUS);
			stmt.setString(1, dto.getUsuario()); 
			stmt.setInt(2, dto.getStatus());
			stmt.setString(3, dto.getNoOrden());
			stmt.setInt(4, dto.getDetallePI().getPosicion());
			stmt.setString(5, dto.getIdPi()); 
			resultado = stmt.executeUpdate(); 

		}catch (SQLException e) {
			log.error("Error al actualizar Estatus Detalle Proforma Invoice en BD... {} {}", e.getMessage(), e);
			ConexionDB.devolver(conn);
		}catch (Exception e) {
			log.error("Error en BD... {} {}", e.getMessage(), e);
			ConexionDB.devolver(conn);
		}finally {
			ConexionDB.devolver(conn);
		}

		return resultado;
		
	}
	@Override
	public int actualizarImagen(String idPi,long idImagen,String user) throws SQLException, ClassNotFoundException {
		Connection conn = ConexionDB.dameConexion() ; 
		int resultado = 0;
		try {
			PreparedStatement stmt = conn.prepareStatement(Querys.ACEPTA_IMG);
			stmt.setLong(1,idImagen);
			stmt.setString(2, user);
			stmt.setString(3, idPi); 
			resultado = stmt.executeUpdate(); 
		}catch (SQLException e) {
			log.error("Error al actualizar imagen de  Proforma Invoice en BD... {} {}", e.getMessage(), e);
			ConexionDB.devolver(conn);
		}catch (Exception e) {
			log.error("Error en BD... {} {}", e.getMessage(), e);
			ConexionDB.devolver(conn);
		}finally {
			ConexionDB.devolver(conn);
		}

		return resultado;
		
	}
	@Override
	public int cambiaEstatusProforma(int idPi,int status,String user) throws SQLException, ClassNotFoundException {
		Connection conn = ConexionDB.dameConexion() ; 
		int resultado = 0;
		try {
			PreparedStatement stmt = conn.prepareStatement(Querys.CAMBIA_ESTATUS_PROFORMA);
			stmt.setInt(1, status);  
			stmt.setInt(2, idPi);
			resultado = stmt.executeUpdate(); 

		}catch (SQLException e) {
			log.error("Error al actualizar Estatus Invoice Proforma Invoice en BD... {} {}", e.getMessage(), e);
			ConexionDB.devolver(conn);
		}catch (Exception e) {
			log.error("Error en BD... {} {}", e.getMessage(), e);
			ConexionDB.devolver(conn);
		}finally {
			ConexionDB.devolver(conn);
		}

		return resultado;
		
	}
	@Override
	public int cambiaEstatusProformas(int status,String user,int reject) throws SQLException, ClassNotFoundException {
		Connection conn = ConexionDB.dameConexion() ; 
		int resultado = 0;
		try {
			PreparedStatement stmt = conn.prepareStatement(Querys.REJECT_ESTATUS_PROFORMA);
			stmt.setInt(1, reject);  
			stmt.setInt(2, status);
			resultado = stmt.executeUpdate(); 

		}catch (SQLException e) {
			log.error("Error al actualizar Estatus Invoice Proforma Invoice en BD... {} {}", e.getMessage(), e);
			ConexionDB.devolver(conn);
		}catch (Exception e) {
			log.error("Error en BD... {} {}", e.getMessage(), e);
			ConexionDB.devolver(conn);
		}finally {
			ConexionDB.devolver(conn);
		}

		return resultado;
		
	}
	
	@Override
	public int actualizarDetalleXLS(List<String> renglon) throws SQLException, ClassNotFoundException {
		Connection conn = ConexionDB.dameConexion() ; 
		int resultado = 0;
		try {
			PreparedStatement stmt = conn.prepareStatement(Querys.CAMBIA_MATRIZ);
			log.info("Actualizamos >>> "+renglon.get(1)+","+renglon.get(2)+","+renglon.get(3)+","+renglon.get(4));
			stmt.setString(1,renglon.get(3)); 
			stmt.setString(2, renglon.get(4));
			stmt.setString(3, renglon.get(1));
			stmt.setString(4, renglon.get(2));
			resultado = stmt.executeUpdate(); 

		}catch (SQLException e) {
			log.error("Error al actualizar Estatus Detalle Proforma Invoice en BD... {} {}", e.getMessage(), e);
			ConexionDB.devolver(conn);
		}catch (Exception e) {
			log.error("Error en BD... {} {}", e.getMessage(), e);
			ConexionDB.devolver(conn);
		}finally {
			ConexionDB.devolver(conn);
		}

		return resultado;
		
	}
	 
}
