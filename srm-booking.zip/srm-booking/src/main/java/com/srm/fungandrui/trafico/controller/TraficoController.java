package com.srm.fungandrui.trafico.controller;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.google.gson.Gson;
import com.srm.app.constantes.Mensajes;
import com.srm.fungandrui.facturacion.models.Facturacion;
import com.srm.fungandrui.facturacion.service.FactService;
import com.srm.fungandrui.facturacion.service.TraficoRabbitService;
import com.srm.fungandrui.sc.model.BeanSession;
import com.srm.fungandrui.sc.model.ResponseVO;
import com.srm.fungandrui.sc.utils.SessionUtil;
import com.srm.fungandrui.trafico.models.TraficoConsolVO;
import com.srm.fungandrui.trafico.service.TraficoService;
import com.srm.pli.enums.HistoryLogAction;
import com.srm.pli.services.HistoryLogServices;
import com.srm.pli.ws.vo.ResponseImportsVO;
import com.truper.businessEntity.UserBean;

import lombok.extern.slf4j.Slf4j;


@Slf4j
@Controller
@RequestMapping(path = "/trafico")
public class TraficoController {
	
	@Autowired
	HttpServletRequest request;
	
	@Autowired
	TraficoService traficoService;
	
	@Autowired
	FactService facturacionService;
	@Autowired
	TraficoRabbitService traficoRabbitService;
	
	HistoryLogServices historylog = HistoryLogServices.getInstance();
	
	@RequestMapping(value = "/entregaTrafico", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	public ResponseEntity<ResponseVO> entregaTrafico(@RequestBody Facturacion factura) {
		log.info("[/enviaTrafico/]::Entrando:");
		ResponseVO response = new ResponseVO();
		HttpSession session = null;
		BeanSession beanSession = null;
		Map<String, Object> data = new HashMap<String, Object>();
		try {
			Locale locate = validateSession();
			session = request.getSession(false);
			beanSession = SessionUtil.validaSesion(session);
			String userName = beanSession.getUser().getUserName();

			Integer result = facturacionService.enviaTrafico(factura);
			if(result == 1) {
				historylog.registraAccion(Integer.parseInt(factura.getFolio()), userName, HistoryLogAction.CAMBIAR_STATUS_FACTURACION,
						"FACTURACION: Marcado para envio a trafico");
				TraficoConsolVO consolidacionFolioDto = traficoService.validaConsolidadosAceptados(factura.getSupplier(), factura.getBooking());
				consolidacionFolioDto.getConsolidado().setSar(Integer.parseInt(factura.getFolio()));
				consolidacionFolioDto.getConsolidado().setIdOrigenDocumento(factura.getId().intValue());
				log.info(new Gson().toJson(consolidacionFolioDto));
				
				//aqui se envia a la cola
				if(Boolean.parseBoolean(consolidacionFolioDto.getStatus())) {
					response.setTipoMensaje(Mensajes.TIPO_EXITO.getMensaje());
					response.setMensaje(Mensajes.MSG_EXITO.getMensaje());
					historylog.registraAccion(Integer.parseInt(factura.getFolio()), userName, HistoryLogAction.SENT_TO_TRAFFIC,
							"FACTURACION: Se mando el folio a trafico");
					
					traficoRabbitService.envioTrafico(consolidacionFolioDto.getConsolidado());
					
					
					
				}else {
					response.setTipoMensaje(Mensajes.TIPO_WARNING.getMensaje());
					response.setMensaje("Los siguientes folios aun no tienen documentos ::: " + consolidacionFolioDto.getFolios());
				}
				
				log.info("[/enviaTrafico/]::Saliendo:");
			}else {
				throw new Exception("No se puede actualizar el registro :::" + factura.getFolio());
			}
			return ResponseEntity.status(HttpStatus.OK).body(response);

		} catch (Exception e) {
			response.setTipoMensaje(Mensajes.TIPO_ERROR.getMensaje());
			response.setMensaje(Mensajes.MSG_ERROR.getMensaje());
			data.put("error", ExceptionUtils.getStackTrace(e));
			log.info("Error");
			log.info("[/enviaTrafico/]::Saliendo con error {} :", e.getMessage());
			response.setResponseObject(data);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
		}
	}
	
	public Locale validateSession() throws Exception {
		HttpSession session = null;
		BeanSession beanSession;
		session = request.getSession(false);
		beanSession = SessionUtil.validaSesion(session);
		if (beanSession == null)
			throw new Exception("session invalida");
		
		Locale currentLocale = session.getAttribute("javax.servlet.jsp.jstl.fmt.locale.session") == null
				? new Locale("en", "US")
				: (Locale) session.getAttribute("javax.servlet.jsp.jstl.fmt.locale.session");
		
		return currentLocale;
	}

}
