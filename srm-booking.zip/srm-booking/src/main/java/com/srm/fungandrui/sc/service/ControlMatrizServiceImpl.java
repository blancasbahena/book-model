package com.srm.fungandrui.sc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.srm.fungandrui.sc.dao.ControlMatrizDAO;

@Service
public class ControlMatrizServiceImpl implements ControlMatrizService{

	@Autowired(required = true)
	ControlMatrizDAO dao ;
		
	public List<String> getBloqueo(String proveedor) {
		return dao.getPObloqueadas(proveedor);
	}

	public List<String> getAllPO() {
		return dao.getAllPO();
	}

	public List<String> getPOsByFolio(String folioSAR) {
		return dao.getPOsBYFolioSar(folioSAR);
	}
	
	public List<String> getPOsBYFolioSar(String folioSAR){
		return dao.getPOsBYFolioSar(folioSAR);
	}
	
	public int getDaysEtdBySupplier(int proveedor) {
		return dao.getDaysEtdBySupplier(proveedor);
	}

}
