package com.srm.fungandrui.facturacion.queues;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.rabbitmq.client.AMQP;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.DefaultConsumer;
import com.rabbitmq.client.Envelope;
import com.srm.app.constantes.Mensajes;
import com.srm.fungandrui.expediente.service.ExpedienteService;
import com.srm.fungandrui.facturacion.dao.IFacturacionDAO;
import com.srm.fungandrui.facturacion.dao.PeticionRabbit;
import com.srm.fungandrui.facturacion.models.CatStatusFactura;
import com.srm.fungandrui.facturacion.models.Facturacion;
import com.srm.fungandrui.facturacion.models.ItemErrorFactura;
import com.srm.fungandrui.facturacion.models.ItemFactura;
import com.srm.fungandrui.facturacion.utils.PlantillasEmailFacturacion;
import com.srm.fungandrui.facturacion.utils.SendEmail;
import com.srm.pli.db.ConexionDB;
import com.srm.pli.enums.HistoryLogAction;
import com.srm.pli.services.HistoryLogServices;
import com.srm.pli.utils.PropertiesDb;
import com.truper.bpm.enums.TipoDocumentosEnum;
import com.truper.expediente.DocumentoDTO;
import com.truper.expediente.ExpedientePerfilDTO;
import com.truper.subscribe.Subscriber;
import com.truper.utils.ConvertUtils;

import lombok.extern.log4j.Log4j2;

@Configuration
@Log4j2
public class QueusConfig {

	private String HOST = PropertiesDb.getInstance().getString("rabbit.ws.host");
	private Integer PORT = PropertiesDb.getInstance().getInteger("rabbit.ws.port");
	private String PASS = PropertiesDb.getInstance().getString("rabbit.ws.pwd");
	private String USER = PropertiesDb.getInstance().getString("rabbit.ws.user");
	private String EXCHANGENAME = PropertiesDb.getInstance().getString("rabbit.ws.exchangeName");
	private String VIRTUAL_SERVICE = PropertiesDb.getInstance().getString("rabbit.ws.virtualService");
	private String ROUTING_KEY = PropertiesDb.getInstance().getString("rabbit.ws.routingKey-fr");
	private String QUEUE_FR_FACTURACION = PropertiesDb.getInstance().getString("rabbit.ws.queueFRFacturacion");

	private Integer AREA_RESP_FACTURACION_INCIDENCIA = PropertiesDb.getInstance()
			.getInteger("srm.facturacion.incidencia.facturacion.id");

	private Integer AREA_RESP_CANCELACION_INCIDENCIA = PropertiesDb.getInstance()
			.getInteger("srm.facturacion.incidencia.cancelacion.id");
	
	private Integer AREA_RESP_SIFE_INCIDENCIA = PropertiesDb.getInstance()
			.getInteger("srm.facturacion.incidencia.sife.id");

	private final boolean AUTO_DELETE = false;
	private final boolean DURABLE = true;
	private final boolean EXCLUSIVE = true;
	private final String TYPE = "direct";

	private final String TEST_MENSAJE = "0000";
	private final String RESPUESTA_PARCIAL = "1002";
	private final String RESPUESTA_FACTURACION = "1003";
	private final String RESPUESTA_SIFE = "1005";
	private final String ACTUALIZACION_STATUS_SIFE = "1006";
	private final String RESPUESTA_CANCELACION = "2001";
	private final String RESPUESTA_BLOQUEO_PO = "3001";

	private final Integer INCIDENCIA_FACTURACION = 36;
	private final Integer INCIDENCIA_CANCELADA = 33;
	
	private final Integer INCIDENCIA_SIFE = 40;

	public final String EMAILS_ERROR_BLOQUEO_POS = PropertiesDb.getInstance()
			.getString("srm.facturacion.email.BloqueoPO.error");

	@Autowired
	private IFacturacionDAO facturacionDAO;

	@Autowired
	private ExpedienteService expedienteService;

	@Bean
	public String getMensajeFacturacion() {

		try {
			final Channel channel = Subscriber.createQueue(HOST, PORT, USER, PASS, VIRTUAL_SERVICE, EXCHANGENAME, TYPE,
					DURABLE, !EXCLUSIVE, AUTO_DELETE, QUEUE_FR_FACTURACION, ROUTING_KEY, null);

			boolean autoAck = false;

			channel.basicConsume(QUEUE_FR_FACTURACION, autoAck, "FR-Queue-Consumer", new DefaultConsumer(channel) {
				@Override
				public void handleDelivery(String consumerTag, Envelope sobre, AMQP.BasicProperties properties,
						byte[] body) {
					long deliveryTag = sobre.getDeliveryTag();

					Connection conn = null;

					try {
						ObjectMapper mapper = new ObjectMapper();

						String respuesta = ConvertUtils.deserialize(body).toString();

						log.info("Inicia procesamiento de Queue");
						log.info(respuesta);

						PeticionRabbit respRabbit = mapper.readValue(respuesta, PeticionRabbit.class);

						Map<String, Object> payload = respRabbit.getPayload();
						ArrayList<Map<String, Object>> items = (ArrayList<Map<String, Object>>) payload.get("item");
						Map<String, Object> info = (Map<String, Object>) payload.get("info");

						if (respRabbit.getType().equals(Mensajes.TIPO_EXITO.getMensaje())
								|| respRabbit.getType().equals(null)) {

							switch (respRabbit.getOperationType()) {
							case TEST_MENSAJE:
									log.info("[ TEST COMUNICACION - OK ]");
									log.info("QUEUE: "+QUEUE_FR_FACTURACION);
									log.info("RK: "+ROUTING_KEY);
									log.info("Mensaje: "+respuesta);
								break;
							case RESPUESTA_PARCIAL:

								String folio = null;
								Long idTabla = null;

								Boolean urgente = (Boolean) info.get("urgente");
								
								if( urgente == null ) {
									urgente = false;
								}

								Object folioObj = info.get("sar");

								if (folioObj instanceof Integer) {
									folio = ((Integer) folioObj).toString();
								} else if (folioObj instanceof String) {
									folio = (String) folioObj;
								}
								if (folioObj instanceof Double) {
									folio = ((Double) folioObj).intValue() + "";
								}

								Object idFt = info.get("idFacturacion");
								if (idFt instanceof Integer) {
									idTabla = ((Integer) idFt).longValue();
								} else if (idFt instanceof String) {
									idTabla = Long.parseLong((String) idFt);
								}
								if (idFt instanceof Double) {
									idTabla = ((Double) idFt).longValue();
								}

								String condicionPago = (String) info.get("condicionPago");
								String auxkey = (String) info.get("auxkey");

								// Map<String, Object> item = items.get(0);

								for (Map<String, Object> item : items) {

									Facturacion factura = new Facturacion();

									String no_factura = (String) item.get("vbelnvf");

									no_factura = ((Long) Long.parseLong(no_factura)).toString();

									Map<String, Object> pasivocon = new HashMap<String, Object>();
									pasivocon = (Map<String, Object>) item.get("pasivocon");

									String documentoSociedad = (String) pasivocon.get("bukrs");
									String documentoNumero = (String) pasivocon.get("belnr");
									String documentoEjercicio = (String) pasivocon.get("gjahr");

									factura.setFolio(folio);
									factura.setCondicionPago(condicionPago);
									factura.setAuxkey(auxkey);
									factura.setNoFacturaPM(no_factura);


									factura.setStatus(CatStatusFactura.EN_ESPERA_DE_DOCUMENTOS.getId().toString());


									factura.setDocumentoEjercicio(documentoEjercicio);
									factura.setDocumentoNumero(documentoNumero);
									factura.setDocumentoSociedad(documentoSociedad);

									facturacionDAO.updateInfoParcialFactura(factura);
									facturacionDAO.updateFacturaPODetalleFacturacion(idTabla, no_factura);

								}

								break;
							case RESPUESTA_FACTURACION:

								Map<String, Object> resp = (Map<String, Object>) payload.get("respuesta");

								SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");

								Facturacion factura = new Facturacion();

								String folioAux = ((String) resp.get("facturaParcel")).trim();

								Long folioI = Long.parseLong(folioAux.toString());

								factura.setNoFacturaPM(folioI.toString());
								factura.setMontoUSD(((Double) resp.get("importeUsd")).toString());
								factura.setImporteOriginal((Double) resp.get("importeMonedaOriginal"));
								
								
								factura.setStatus(CatStatusFactura.FACTURACION_REALIZADA.getId().toString());
								factura.setComentarios("");
								factura.setIncidenciasEnFacturas(null);
								String fechaFP = "";
								if( resp.get("fechaEmisionFacturaParcel") instanceof Double ) {
									fechaFP = ((Double) resp.get("fechaEmisionFacturaParcel")).toString();
								} else if( resp.get("fechaEmisionFacturaParcel") instanceof Integer ) {
									fechaFP = ((Integer) resp.get("fechaEmisionFacturaParcel")).toString();
								}else {
									fechaFP = ((String) resp.get("fechaEmisionFacturaParcel")).toString();
								}
							
								

								try {
									factura.setFechaEmisionFacturaParcel(format.parse(fechaFP));
								} catch (ParseException e2) {
									log.info("fecha en formato incorrecto incorrecta: " + fechaFP);
									factura.setFechaEmisionFacturaParcel(new Date());
									log.error(e2.getMessage(), e2);
									e2.printStackTrace();
								}

								facturacionDAO.updateInfoTotalFactura(factura);

								break;
							case RESPUESTA_CANCELACION:

								try {
									conn = ConexionDB.dameConexion();
									conn.setAutoCommit(false);

									boolean bSuccess = true;
									String sError = "";
									String sSuccess = "";

									factura = new Facturacion();

									for (Map<String, Object> item : items) {

										Map<String, Object> ntreturn = (Map<String, Object>) item.get("ntreturn");

										ArrayList<Map<String, Object>> itemreturn = (ArrayList<Map<String, Object>>) ntreturn
												.get("item");

										if (itemreturn != null && !itemreturn.isEmpty()) {

											for (Map<String, Object> map : itemreturn) {

												if (((String) map.get("type"))
														.equals(Mensajes.TIPO_ERROR.getMensaje())) {
													bSuccess = false;
													sError += map.get("message") + "\n";
												} else {
													sSuccess = map.get("message") + "\n";
												}

											}

										}

									}

									if (bSuccess) {

										String no_factura = (String) info.get("facturaPM");
										String username = (String) info.get("userName");
										Integer profile = null;
										String blnumberContenedor = (String) info.get("BL")
												+ (String) info.get("Contenedor");

										Object objId = info.get("id");
										Long id = null;
										if (objId instanceof Integer) {
											id = ((Integer) objId).longValue();
										}else if (objId instanceof Long) {
											id = (Long) objId;
										}else if( objId instanceof Double ) {
											id = ((Double) objId).longValue();
										}

										Object objuP = info.get("userProfile");
										if (objuP instanceof Integer) {
											profile = ((Integer) objuP);
										} else if (objuP instanceof Long) {
											profile = ((Long) objuP).intValue();
										} else if (objuP instanceof Double) {
											profile = ((Double) objuP).intValue();
										}

										if (id != null) {
											factura.setId(id);
											factura.setNoFacturaPM(no_factura);
											factura.setStatus(CatStatusFactura.CANCELACION.getId().toString());
											factura.setComentarios(sSuccess);
											facturacionDAO.setStatusFactura(factura, conn);
											
											facturacionDAO.borraIncidencia(factura, conn);
											

											List<ExpedientePerfilDTO> listExpedientes = expedienteService
													.geAllExpedientes(blnumberContenedor,
															"" + TipoDocumentosEnum.FACTURA_PARCELMOBI.getId(),
															profile,null);
											if( listExpedientes != null && !listExpedientes.isEmpty() )
											for (ExpedientePerfilDTO dto : listExpedientes) {
												if( dto != null ) {
													if( dto.getDocumentos() != null && !dto.getDocumentos().isEmpty()  ) {
														for (DocumentoDTO doc : dto.getDocumentos()) {
															if (doc != null)
																expedienteService.seBorroEnBaseDatos(doc.getId(), username);
														}
													}
												}
											}

										} else {

											factura.setComentarios("ID No encontrado");
											factura.setAreaResponsableSolucion(
													AREA_RESP_FACTURACION_INCIDENCIA.toString());
											factura.setIncidenciasEnFacturas(INCIDENCIA_CANCELADA.toString());

											log.info("Error en la Cancelacion");

										}

									} else {
										Object objId = info.get("id");
										Long id = null;
										if (objId instanceof Integer) {
											id = ((Integer) objId).longValue();

										} else if (objId instanceof Long) {
											id = (Long) objId;
										}else if( objId instanceof Double ) {
											id = ( (Double) objId ).longValue();
										}else if( objId instanceof String ) {
											id = Long.parseLong( (String) objId );
										}
										
										factura.setId(id);
										factura.setComentarios(sError);
										factura.setAreaResponsableSolucion(AREA_RESP_CANCELACION_INCIDENCIA.toString());
										factura.setIncidenciasEnFacturas(INCIDENCIA_CANCELADA.toString());
										factura.setStatus(CatStatusFactura.FACTURACION_REALIZADA.getId().toString());
										log.info("Error en la Cancelacion");
										log.info(sError);
										facturacionDAO.setIncidenciaById(factura, conn);

									}

									conn.commit();
									conn.setAutoCommit(true);
									ConexionDB.devolver(conn);

								} catch (SQLException e) {

									if (conn != null) {
										log.info("Fall� proceso de cancelaci�n - RollBack");
										try {
											conn.rollback();
											conn.setAutoCommit(true);
											ConexionDB.devolver(conn);
										} catch (SQLException e1) {
											e1.printStackTrace();
										}

									}
									log.error(e.getMessage(), e);
									e.printStackTrace();
								}

								break;
							case RESPUESTA_SIFE:
								log.info("Procesando respuesta SIFE");
								log.info("payload: ");
								log.info(payload.toString());

								for (Map<String, Object> item : items) {
									factura = new Facturacion();

									Map<String, Object> request = new HashMap<String, Object>();

									request = (Map<String, Object>) item.get("request");

									Long idFacturacion = null;

									Long FolioSIFE = null;
									Long idtipoSolicitud = null;
									String mensaje = "";
									Object objIdF = request.get("idFacturacion");
									Object objFO = request.get("folioOrigen");
									Object objFSIFE = item.get("folioSIFE");
									Object objMSIFE = item.get("mensaje");
									
									Object objIdtipoSolicitud = request.get("idtipoSolicitud");
									

									if (objMSIFE instanceof String) {
										mensaje =(String) objMSIFE;
										mensaje=  mensaje.substring(0, mensaje.length()>80?80:mensaje.length());
									}
									
									if (objIdF instanceof String) {
										idFacturacion = Long.parseLong( (String) objIdF);
									} else if (objIdF instanceof Integer) {
										idFacturacion = ((Integer) objIdF).longValue();
									} else if (objIdF instanceof Long) {
										idFacturacion = (Long) objIdF;
									} else if (objIdF instanceof Double) {
										idFacturacion = ((Double) objIdF).longValue();
									}
									
									if (objIdtipoSolicitud instanceof String) {
										idtipoSolicitud = Long.parseLong((String) objIdtipoSolicitud);
									} else if (objIdtipoSolicitud instanceof Integer) {
										idtipoSolicitud = ((Integer) objIdtipoSolicitud).longValue();
									} else if (objIdtipoSolicitud instanceof Long) {
										idtipoSolicitud = (Long) objIdtipoSolicitud;
									} else if (objIdtipoSolicitud instanceof Double) {
										idtipoSolicitud = ((Double) objIdtipoSolicitud).longValue();
									}

									condicionPago = (String) request.get("condicionDePago");

									folio = null;

									if (objFO instanceof String) {
										folio = (String) objFO;
									} else if (objFO instanceof Integer) {
										folio = ((Integer) objFO).toString();
									} else if (objFO instanceof Long) {
										folio = ((Long) objFO).toString();
									} else if (objFO instanceof Double) {
										folio = ((Double) objFO).toString();
									}

									if (objFSIFE instanceof String) {
										FolioSIFE = Long.parseLong((String) objFSIFE);
									} else if (objFSIFE instanceof Integer) {
										FolioSIFE = ((Integer) objFSIFE).longValue();
									} else if (objFSIFE instanceof Long) {
										FolioSIFE = (Long) objFSIFE;
									} else if (objFSIFE instanceof Double) {
										FolioSIFE = ((Double) objFSIFE).longValue();
									}

									LocalDateTime fechaProcesadoSIFE = LocalDateTime.now();

									factura.setId(idFacturacion);
									factura.setCondicionPago(condicionPago);
									factura.setSar(folio);
									factura.setMensaje(mensaje);
									factura.setFolioSIFE(FolioSIFE);
									factura.setCodigoEstatusFactura(
											CatStatusFactura.ENTREGADO_A_SIFE.getId().toString());
									factura.setFechaProcesadoSIFE(fechaProcesadoSIFE.toString());
									facturacionDAO.setProcesadoSIFE(factura,idtipoSolicitud);

								}
								log.info("Respuesta SIFE Procesada");

								break;

							case RESPUESTA_BLOQUEO_PO:

								List<ItemFactura> posError = new ArrayList<ItemFactura>();

								for (Map<String, Object> item : items) {

									String type = (String) item.get("type");

									if (type.equals(Mensajes.TIPO_ERROR.getMensaje())) {

										ItemFactura itemf = new ItemFactura();
						
										
										itemf.setEbeln((String) item.get("ebeln"));
										
										Integer posicion = Integer.parseInt((String) item.get("ebelp"));
										itemf.setEbelp(posicion.toString());
										
										
										itemf.setMsj((String) item.get("message"));
										posError.add(itemf);
									}

								}

								if (posError.size() > 0) {

									String plantilla = PlantillasEmailFacturacion.ERROR_BLOQUEO_POS;
									
									Object objF = info.get("folioOrigen"); 
									String foliof = "---";
									
									if(  objF instanceof String ) {
										foliof = (String) objF;
									}else if(  objF instanceof Integer ) {
										foliof = ((Integer) objF).toString();
									}else if( objF instanceof Long ) {
										foliof = ((Long) objF).toString();
									}else if( objF instanceof Double ) {
										foliof = ((Double) objF).toString();
									}
									
									plantilla = plantilla.replaceAll("-FOLIO-", foliof);

									String bodyTable = "";

									int i = 1;
									for (ItemFactura itemFactura : posError) {
										StringBuilder tr = new StringBuilder()
												.append("<tr " + (i % 2 == 0 ? "class=\"cebra-on\" >" : ">") + "<td>")
												.append(itemFactura.getEbelp()).append("</td><td>")
												.append(itemFactura.getEbeln()).append("</td><td>")
												.append(itemFactura.getMsj()).append("</td></tr>");
										i++;
										bodyTable += tr.toString();
									}

									plantilla = plantilla.replaceAll("-DATOS-", bodyTable);

									// Envio de Email
									SendEmail.sentEmailErrorBloqueoPo(EMAILS_ERROR_BLOQUEO_POS,
											"Error al Bloquear POs", plantilla);

									log.info("Se envio correo de notificacion de Error al bloquear PO");

								}

								break;

							case ACTUALIZACION_STATUS_SIFE:

								Long FolioSIFE = null;
								Integer idStatus = null;
								String descripcionStatus = null;

								Object objFS = info.get("idSife");
								Object objIdSt = info.get("idStatus");

								descripcionStatus = (String) info.get("status");

								if (objFS instanceof Integer) {
									FolioSIFE = ((Integer) objFS).longValue();
								} else if (objFS instanceof String) {
									FolioSIFE = Long.parseLong((String) objFS);
								} else if (objFS instanceof Double) {
									FolioSIFE = ((Double) objFS).longValue();
								} else if (objFS instanceof Long) {
									FolioSIFE = (Long) objFS;
								}

								if (objIdSt instanceof Integer) {
									idStatus = ((Integer) objIdSt);
								} else if (objIdSt instanceof String) {
									idStatus = Integer.parseInt((String) objIdSt);
								} else if (objIdSt instanceof Double) {
									idStatus = ((Double) objIdSt).intValue();
								} else if (objIdSt instanceof Long) {
									idStatus = ((Integer) objIdSt).intValue();
								}

								if (FolioSIFE != null && idStatus != null && descripcionStatus != null) {

									LocalDateTime fechaActualizaStatusSIFE = LocalDateTime.now();

									factura = new Facturacion();
									factura.setFolioSIFE(FolioSIFE);
									factura.setStatusSIFE(idStatus);
									factura.setDescriStatusSIFE(descripcionStatus);
									factura.setFechaActualizaStatusSIFE(fechaActualizaStatusSIFE.toString());

									facturacionDAO.ActualizaStatusSIFE(factura);
									
									Facturacion folioHistory = facturacionDAO.getFolioByFolioSife(FolioSIFE);
									if( folioHistory != null )
									{
										//Se realiza guardado en HistoryLog
										HistoryLogServices historylog = HistoryLogServices.getInstance();
										
										Integer folioSar = Integer.parseInt( folioHistory.getFolio() ); 
										
										if( folioSar != null )
										{
											historylog.registraAccion (folioSar,"userSIFE" , HistoryLogAction.ACTUALIZACION_STATUS_SIFE, "SIFE Status Update: "+descripcionStatus);
										}		
									}else {
										log.error("No existe folio SIFE en Facturacion");
									}

								} else {
									log.info("Informacion insuficiente para actualizar registro de Status SIFE");
									
								}

								break;

							}

						} else {

							switch (respRabbit.getOperationType()) {
							case RESPUESTA_PARCIAL:
							case RESPUESTA_FACTURACION:

								Facturacion factura = new Facturacion();

								String plantilla = PlantillasEmailFacturacion.INCIDENCIA_FACTURACION;

								Long idFacturacion = null;

								Object objidFact = info.get("idFacturacion");
								Object obj = info.get("sar");

								if (obj instanceof Double) {
									Double valor = (Double) obj;
									factura.setFolio(valor.intValue() + "");
									plantilla = plantilla.replaceAll("-FOLIO-", valor.intValue() + "");
								} else if (obj instanceof Integer) {
									Integer valor = (Integer) obj;
									factura.setFolio(valor + "");
									plantilla = plantilla.replaceAll("-FOLIO-", valor.intValue() + "");
								}

								if (objidFact instanceof Integer) {
									idFacturacion = ((Integer) objidFact).longValue();
								} else if (objidFact instanceof String) {
									idFacturacion = Long.parseLong((String) objidFact);
								}
								if (objidFact instanceof Double) {
									idFacturacion = ((Double) objidFact).longValue();
								}
								if (objidFact instanceof Long) {
									idFacturacion = (Long) objidFact;
								}

								String folio = (String) info.get("contenedor") == null ? "---"
										: (String) info.get("contenedor");
								String proveedor = (String) info.get("clave_proveedor") == null ? "---"
										: (String) info.get("clave_proveedor");
								String Pago = (String) info.get("condicionPago") == null ? "---"
										: ((String) info.get("condicionPago")).trim();

								factura.setCondicionPago(Pago);
								
								if( respRabbit.getErrores() != null && !respRabbit.getErrores().isEmpty() ) {
									String manyComments = "";
									for (ItemErrorFactura item: respRabbit.getErrores()) {
										manyComments+= item.getMessage()+"\n"; 
									}
									
									factura.setComentarios(manyComments);
									
								}else {
									factura.setComentarios(respRabbit.getMensaje());
								}
								
								factura.setIncidenciasEnFacturas(INCIDENCIA_FACTURACION.toString());
								factura.setAreaResponsableSolucion(AREA_RESP_FACTURACION_INCIDENCIA.toString());
								factura.setStatus(CatStatusFactura.INCIDENCIA.getId().toString());
								factura.setId(idFacturacion);

								

								facturacionDAO.updateFacturaError(factura,false, respRabbit.getType().contains("E"),false,false);
								
								
								String comments = "" ;
								
								if( factura.getComentarios() != null ) {
									comments = factura.getComentarios();
								}else if( respRabbit.getMensaje() != null ) {
									comments = respRabbit.getMensaje();
								}

								plantilla = plantilla.replaceAll("-CONTE-", folio);
								plantilla = plantilla.replaceAll("-PROV-", proveedor);
								plantilla = plantilla.replaceAll("-CPAGO-", Pago);
								plantilla = plantilla.replaceAll("-ERROR-",comments);

								String emails = facturacionDAO.getEmails(INCIDENCIA_FACTURACION.toString());

								SendEmail.sentEmailErrorBloqueoPo(emails, "Incidencia al Solicitar Facturaci�n",
										plantilla);

								log.info("Se envio correo de notificacion de incidencia");

								break;

							case RESPUESTA_CANCELACION:
								
								break;
							case RESPUESTA_SIFE:
								
								
								String emailsIncidenciaSife = facturacionDAO.getEmails(INCIDENCIA_SIFE.toString());
								
								
								String plantillaSife = PlantillasEmailFacturacion.INCIDENCIA_SIFE;


								Map<String, Object> request = new HashMap<String, Object>();
								
								for (Map<String, Object> item : items) {									
									request = (Map<String, Object>) item.get("request");
								}

								
								String folioOrigen = (String) request.get("folioOrigen") == null ? "---"
										: (String) request.get("folioOrigen");
								String numeroFactura = (String) request.get("numeroFactura") == null ? "---"
										: (String) request.get("numeroFactura");
								String ordenDeCompra = (String) request.get("ordenDeCompra") == null ? "---"
										: ((String) request.get("ordenDeCompra")).trim();


								idFacturacion = null;
								String condicionPago = (String) request.get("condicionDePago");

								Object objIdF = request.get("idFacturacion");
								
								Object objIdtipoSolicitud2 = request.get("idtipoSolicitud");


								if (objIdF instanceof String) {
									idFacturacion = Long.parseLong( (String) objIdF);
								} else if (objIdF instanceof Integer) {
									idFacturacion = ((Integer) objIdF).longValue();
								} else if (objIdF instanceof Long) {
									idFacturacion = (Long) objIdF;
								} else if (objIdF instanceof Double) {
									idFacturacion = ((Double) objIdF).longValue();
								}
								Long idtipoSolicitud =null;
								if (objIdtipoSolicitud2 instanceof String) {
									idtipoSolicitud = Long.parseLong( (String) objIdtipoSolicitud2);
								} else if (objIdtipoSolicitud2 instanceof Integer) {
									idtipoSolicitud = ((Integer) objIdtipoSolicitud2).longValue();
								} else if (objIdtipoSolicitud2 instanceof Long) {
									idtipoSolicitud = (Long) objIdtipoSolicitud2;
								} else if (objIdtipoSolicitud2 instanceof Double) {
									idtipoSolicitud = ((Double) objIdtipoSolicitud2).longValue();
								}
								
								if( idFacturacion != null ) {
									
									Facturacion facturaAux = new Facturacion();
									facturaAux.setId(idFacturacion);
									facturaAux.setComentarios(respRabbit.getMensaje());
									facturaAux.setIncidenciasEnFacturas(INCIDENCIA_SIFE.toString());
									facturaAux.setAreaResponsableSolucion(AREA_RESP_SIFE_INCIDENCIA.toString());
									facturaAux.setStatus(CatStatusFactura.FACTURACION_REALIZADA.getId().toString());
									facturaAux.setFolio(folioOrigen);
									facturaAux.setCondicionPago(condicionPago);								
									facturaAux.setId(idFacturacion);
									
									facturacionDAO.updateFacturaError(facturaAux, true,respRabbit.getType().equals("E"),idtipoSolicitud==43,idtipoSolicitud==19);

									
								}
								
								plantillaSife =plantillaSife.replaceAll("-FOLIO-", folioOrigen);
								plantillaSife = plantillaSife.replaceAll("-NUMERO_FACTURA-", numeroFactura);
								plantillaSife = plantillaSife.replaceAll("-ORDENES_COMPRA-", ordenDeCompra);
								
								

								SendEmail.sentEmailErrorBloqueoPo(emailsIncidenciaSife, "Incidencia SIFE",
										plantillaSife);

								log.info("Se envio correo de notificacion de incidencia");
								
								break;
							}

						}

						channel.basicAck(deliveryTag, false);

					} catch (ClassCastException e) {
						try {
							channel.basicAck(deliveryTag, false);
						} catch (IOException e1) {
							e1.printStackTrace();
							log.error(e1.getMessage(), e1);
						}
						e.printStackTrace();
						log.error(e.getMessage(), e);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						try {
							channel.basicAck(deliveryTag, false);
						} catch (IOException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
							log.error(e.getMessage(), e1);
						}
						e.printStackTrace();
						log.error(e.getMessage(), e);
					} catch (ClassNotFoundException e) {

						try {
							channel.basicAck(deliveryTag, false);
						} catch (IOException e1) {
							log.error(e1.getMessage(), e1);
							e1.printStackTrace();
						}
						log.error(e.getMessage(), e);
						e.printStackTrace();
					}
				}
			});

		} catch (IOException e) {
			log.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return "OK";

	}

}
