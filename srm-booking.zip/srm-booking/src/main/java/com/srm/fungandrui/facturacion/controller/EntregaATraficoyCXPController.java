package com.srm.fungandrui.facturacion.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.maven.model.Model;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.srm.app.constantes.Mensajes;
import com.srm.fungandrui.facturacion.models.ControlEmbarqueModel;
import com.srm.fungandrui.facturacion.models.EntregaTraficoModel;
import com.srm.fungandrui.facturacion.models.Facturacion;
import com.srm.fungandrui.facturacion.service.FactService;
import com.srm.fungandrui.sc.model.BeanSession;
import com.srm.fungandrui.sc.model.FiltroEntregaTrafico;
import com.srm.fungandrui.sc.model.ResponseVO;
import com.srm.fungandrui.sc.utils.SessionUtil;
import com.srm.pli.enums.HistoryLogAction;
import com.srm.pli.services.HistoryLogServices;
import com.srm.pli.utils.Paginacion;

import lombok.extern.log4j.Log4j2;

@Log4j2
@Controller
@RequestMapping("/entregaATraficoyCXP")
public class EntregaATraficoyCXPController {

	@Autowired
	HttpServletRequest request;

	@Autowired
	FactService facturacionService;
	
	HistoryLogServices historylog = HistoryLogServices.getInstance();
	
	
	@RequestMapping(value = "/", method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView getBloqueos(Model model) {
		HttpSession session = null;
		BeanSession beanSession;
		ModelAndView mav = null;

		session = request.getSession(false);
		beanSession = SessionUtil.validaSesion(session);
		if (beanSession.getMav() == null) {
			try {
				Locale locate = validateSession();
				mav = new ModelAndView("entregaATraficoyCXP");
				return mav;
			} catch (Exception e) {
				log.error(e.getMessage());
			}
		}
		mav = new ModelAndView("redirect:/Inicio");
		return mav;
	}

	@RequestMapping(value = "/search", method = { RequestMethod.GET, RequestMethod.POST })
	public ResponseEntity<ResponseVO> search(Model model, FiltroEntregaTrafico filtro) {
		log.info("/search {}", filtro);
		ResponseVO response = new ResponseVO();
		Map<String, Object> data = new HashMap<String, Object>();
		List<EntregaTraficoModel> facList = null;
		List<ControlEmbarqueModel>  facList2 =  null;
		try {
			Locale location = validateSession();
			log.info("[/tab/]::Saliendo InformactionTab:");
			switch (filtro.getTipoBusqueda()) {
			case "ENTREGA DOCS FINALES":
				log.info("{}", filtro);
				facList = facturacionService.getListEntrgeaDocsFinales("6,9,11,13", filtro);
				break;
			case "CONTROL DE EMBARQUES":
				log.info("{}", filtro);
				facList2 = facturacionService.getListControlEmbarque(filtro);
				break;
			case "RECHAZADOS TRAFICO":
				log.info("{}", filtro);
				facList = facturacionService.getListRechazadosTrafico("10", filtro);
				break;
			default:
				break;
			}
			data.put("facList", facList == null ? facList2 : facList);
			if(facList != null) {
			data.put("flechas", Paginacion.controlPaginacion(filtro.getPaginaActual(),
					filtro.getPaginaAccion(), (facList.isEmpty()?0:facList.get(0).getNumber() ), location));
			}
			if(facList2 != null) {
				data.put("flechas", Paginacion.controlPaginacion(filtro.getPaginaActual(),
						filtro.getPaginaAccion(), (facList2.isEmpty()?0:facList2.get(0).getNumber() ), location));
			}
			data.put("correciones", facturacionService.getCatCorreccion());
			response.setTipoMensaje(Mensajes.TIPO_EXITO.getMensaje());
			response.setMensaje(Mensajes.MSG_EXITO.getMensaje());
			response.setResponseObject(data);
			log.info("Saliendo /search {}", filtro);
			return ResponseEntity.status(HttpStatus.OK).body(response);

		} catch (Exception e) {

			response.setTipoMensaje(Mensajes.TIPO_ERROR.getMensaje());
			response.setMensaje(Mensajes.MSG_ERROR.getMensaje());
			data.put("error", ExceptionUtils.getStackTrace(e));
			log.info("Error");
			log.info("[/tab/]::Saliendo  InformactionTab con error {} :", e.getMessage());
			response.setResponseObject(data);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);

		}

	}

	@RequestMapping(value = "/docFinales", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	public ResponseEntity<ResponseVO> docFinales() {
		log.info("[/tab/]::Entrando InformactionTab:");
		ResponseVO response = new ResponseVO();
		Map<String, Object> data = new HashMap<String, Object>();
		try {
			Locale locate = validateSession();
			List<EntregaTraficoModel>  facList = facturacionService.getListEntrgeaDocsFinales("6,1,9,11,13", null);
			data.put("facList", facList);
			data.put("flechas", Paginacion.controlPaginacion(null,
					"none", (facList.isEmpty()?0:facList.get(0).getNumber() ), locate));
			data.put("correciones", facturacionService.getCatCorreccion());
			log.info("[/tab/]::Saliendo InformactionTab:");
			response.setTipoMensaje(Mensajes.TIPO_EXITO.getMensaje());
			response.setMensaje(Mensajes.MSG_EXITO.getMensaje());
			response.setResponseObject(data);
			return ResponseEntity.status(HttpStatus.OK).body(response);
		} catch (Exception e) {
			response.setTipoMensaje(Mensajes.TIPO_ERROR.getMensaje());
			response.setMensaje(Mensajes.MSG_ERROR.getMensaje());
			data.put("error", ExceptionUtils.getStackTrace(e));
			log.info("Error");
			log.info("[/tab/]::Saliendo  InformactionTab con error {} :", e.getMessage());
			response.setResponseObject(data);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
		}
	}
	
	
	@RequestMapping(value = "/controlEmbarque", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	public ResponseEntity<ResponseVO> controlEmbarque() {
		log.info("[/tab/]::Entrando InformactionTab:");
		ResponseVO response = new ResponseVO();
		Map<String, Object> data = new HashMap<String, Object>();
		try {
			Locale locate = validateSession();
			List<ControlEmbarqueModel>  facList = facturacionService.getListControlEmbarque(null);
			data.put("facList", facList);
			data.put("flechas", Paginacion.controlPaginacion(null,
					"none", (facList.isEmpty()?0:facList.get(0).getNumber() ), locate));
			data.put("correciones", facturacionService.getCatCorreccion());
			log.info("[/tab/]::Saliendo InformactionTab:");
			response.setTipoMensaje(Mensajes.TIPO_EXITO.getMensaje());
			response.setMensaje(Mensajes.MSG_EXITO.getMensaje());
			response.setResponseObject(data);
			return ResponseEntity.status(HttpStatus.OK).body(response);
		} catch (Exception e) {
			response.setTipoMensaje(Mensajes.TIPO_ERROR.getMensaje());
			response.setMensaje(Mensajes.MSG_ERROR.getMensaje());
			data.put("error", ExceptionUtils.getStackTrace(e));
			log.info("Error");
			log.info("[/tab/]::Saliendo  InformactionTab con error {} :", e.getMessage());
			response.setResponseObject(data);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
		}
	}	
	
	@RequestMapping(value = "/rechazoTrafico", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	public ResponseEntity<ResponseVO> rechazoTrafico() {
		log.info("[/rechazoTrafico/]::Entrando InformactionTab:");
		ResponseVO response = new ResponseVO();
		HttpSession session = null;
		BeanSession beanSession = null;
		Map<String, Object> data = new HashMap<String, Object>();
		try {
			Locale locate = validateSession();
			session = request.getSession(false);
			beanSession = SessionUtil.validaSesion(session);
			String userName = beanSession.getUser().getUserName();
			List<EntregaTraficoModel>  facList = facturacionService.getListRechazadosTrafico("10", null);
			data.put("facList", facList);
			data.put("flechas", Paginacion.controlPaginacion(null,
					"none", (facList.isEmpty()?0:facList.get(0).getNumber() ), locate));
			data.put("correciones", facturacionService.getCatCorreccion());
			log.info("[/rechazoTrafico/]::Saliendo InformactionTab:");
			response.setTipoMensaje(Mensajes.TIPO_EXITO.getMensaje());
			response.setMensaje(Mensajes.MSG_EXITO.getMensaje());
			response.setResponseObject(data);
			return ResponseEntity.status(HttpStatus.OK).body(response);
		} catch (Exception e) {
			response.setTipoMensaje(Mensajes.TIPO_ERROR.getMensaje());
			response.setMensaje(Mensajes.MSG_ERROR.getMensaje());
			data.put("error", ExceptionUtils.getStackTrace(e));
			log.info("Error");
			log.info("[/tab/]::Saliendo  InformactionTab con error {} :", e.getMessage());
			response.setResponseObject(data);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
		}
	}	
	

	public Locale validateSession() throws Exception {
		HttpSession session = null;
		BeanSession beanSession;
		session = request.getSession(false);
		beanSession = SessionUtil.validaSesion(session);
		if (beanSession == null)
			throw new Exception("session invalida");
		
		Locale currentLocale = session.getAttribute("javax.servlet.jsp.jstl.fmt.locale.session") == null
				? new Locale("en", "US")
				: (Locale) session.getAttribute("javax.servlet.jsp.jstl.fmt.locale.session");
		
		return currentLocale;
	}
	
	
	@RequestMapping(value = "/enviaTrafico", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	public ResponseEntity<ResponseVO> enviaTrafico(@RequestBody Facturacion filtro) {
		log.info("[/enviaTrafico/]::Entrando InformactionTab:");
		ResponseVO response = new ResponseVO();
		HttpSession session = null;
		BeanSession beanSession = null;
		Map<String, Object> data = new HashMap<String, Object>();
		try {
			Locale locate = validateSession();
			session = request.getSession(false);
			beanSession = SessionUtil.validaSesion(session);
			String userName = beanSession.getUser().getUserName();
			facturacionService.enviaTrafico(filtro);
			historylog.registraAccion(Integer.parseInt(filtro.getFolio()), userName, HistoryLogAction.SENT_TO_TRAFFIC,"Send to Traffic ");
			log.info("[/enviaTrafico/]::Saliendo InformactionTab:");
			response.setTipoMensaje(Mensajes.TIPO_EXITO.getMensaje());
			response.setMensaje(Mensajes.MSG_EXITO.getMensaje());
			response.setResponseObject(data);
			return ResponseEntity.status(HttpStatus.OK).body(response);
		} catch (Exception e) {
			response.setTipoMensaje(Mensajes.TIPO_ERROR.getMensaje());
			response.setMensaje(Mensajes.MSG_ERROR.getMensaje());
			data.put("error", ExceptionUtils.getStackTrace(e));
			log.info("Error");
			log.info("[/enviaTrafico/]::Saliendo  InformactionTab con error {} :", e.getMessage());
			response.setResponseObject(data);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
		}
	}	

}
