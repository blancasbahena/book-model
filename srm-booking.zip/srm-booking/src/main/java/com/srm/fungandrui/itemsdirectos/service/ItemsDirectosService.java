package com.srm.fungandrui.itemsdirectos.service;

import java.util.HashMap;

import com.srm.fungandrui.itemsdirectos.dto.ItemsDirectosDTO;
import com.srm.fungandrui.itemsdirectos.dto.ItemsSeleccionados;

public interface ItemsDirectosService {
	
	void marcarProyeccionBOItemsDirectos(ItemsDirectosDTO itemsDirectosDTO);
	
	void borrarProyeccionBOItemsDirectos(Integer folio);
	
	HashMap<String, ItemsSeleccionados> obtenerItemsSeleccionados(Integer folio);

}
