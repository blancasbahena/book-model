package com.srm.fungandrui.imports.service.impl;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.NoSuchFileException;

import javax.naming.directory.NoSuchAttributeException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;

import org.apache.http.HttpStatus;
import org.codehaus.jackson.jaxrs.JacksonJsonProvider;

import com.srm.fungandrui.imports.dto.FilesDetailSharingDto;
import com.srm.pli.utils.PropertiesDb;
import com.sun.jersey.api.NotFoundException;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.WebResource.Builder;
import com.sun.jersey.api.client.config.ClientConfig;
import com.sun.jersey.api.client.config.DefaultClientConfig;
import com.sun.jersey.core.header.FormDataContentDisposition;
import com.sun.jersey.core.util.MultivaluedMapImpl;
import com.sun.jersey.multipart.FormDataMultiPart;
import com.sun.jersey.multipart.MultiPart;
import com.sun.jersey.multipart.file.FileDataBodyPart;
import com.sun.jersey.multipart.impl.MultiPartWriter;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;


@Slf4j
@Data
public class SharePointAPI {
	
	private String url;
	private String username;
	private String password;
	private String site;
	private String pathBase;

	public SharePointAPI() {
		this.url = PropertiesDb.getInstance().getString("sharepoint.rest.url");
		if(this.url == null || this.url.isEmpty())
			throw new InstantiationError("No existe la configuracion de URL para Sharing"); 
	}
	
	/**
	 * Obtiene el InputStream de un Archivo de Sharepoint, se integra las versiones de TLS para que pueda funcionar
	 * Al ser una invocacion del back, se debe incluir ya que el Tomcat no tendra un certificado, si no que
	 * pasa por Barracuda WAF
	 * @param fileName
	 * @param fileName2 
	 * @return
	 * @throws NotFoundException
	 */
	public InputStream getFile(String path, String fileName) throws NotFoundException{
		java.lang.System.setProperty("https.protocols", "TLSv1,TLSv1.1,TLSv1.2");
		
		ClientConfig clientConfig = new DefaultClientConfig(JacksonJsonProvider.class);
	    Client cliente = Client.create(clientConfig);
	    
	    MultivaluedMap<String, String> queryParams = new MultivaluedMapImpl();
	    queryParams.add("path", path);
	    queryParams.add("file", fileName);
	    queryParams.add("user", this.username);
	    queryParams.add("pwd", this.password);
	    queryParams.add("site", this.site);
	    
		WebResource webResource = cliente.resource(this.url +"/files/data")
				.queryParams(queryParams);
		
		ClientResponse clientResponse = webResource.get(ClientResponse.class);
		if(clientResponse.getStatus() != HttpStatus.SC_OK){
			throw new NotFoundException("HTTP STATUS " + clientResponse.getStatus() + " Documento no encontrado");
		}
		
		return clientResponse.getEntityInputStream();
	}
	
	
	public void uploadFile(String path, File fileToUpload, Boolean async) throws NoSuchFileException, NoSuchAttributeException {
		if(path == null)
			throw new NoSuchAttributeException("El paremetro \"path\" no fue recibio y es necesario");
		
		if(fileToUpload == null)
			throw new NoSuchAttributeException("El archivo no fue recibido y es necesario");
		
		if(!fileToUpload.exists())
			throw new NoSuchFileException("El archivo" + fileToUpload.getName() + " no existe");
		
		java.lang.System.setProperty("https.protocols", "TLSv1,TLSv1.1,TLSv1.2");
	    
	    MultivaluedMap<String, String> queryParams = new MultivaluedMapImpl();
	    queryParams.add("path", pathBase + "/" + path);
	    
	    if(async != null)
	    	queryParams.add("async", async.toString());

        ClientConfig config = new DefaultClientConfig();
        config.getClasses().add(MultiPartWriter.class);
        Client client = Client.create(config);
        
        WebResource webResource = client.resource(this.url+PropertiesDb.getInstance().getString("sharepoint.rest.path.upload-file")).queryParams(queryParams);
        
        Builder webResourseBuilder = webResource.accept(MediaType.APPLICATION_JSON);
        webResourseBuilder.header("user", this.username);
        webResourseBuilder.header("pwd", this.password);
        webResourseBuilder.header("site", this.site);

        // the file to upload, represented as FileDataBodyPart
        FileDataBodyPart fileDataBodyPart = new FileDataBodyPart("file",
                fileToUpload,
                MediaType.APPLICATION_OCTET_STREAM_TYPE);
        fileDataBodyPart.setContentDisposition(
                FormDataContentDisposition.name("file")
                        .fileName(fileToUpload.getName()).build());

        /* create the MultiPartRequest with:
         * Binary body part called "file" using fileDataBodyPart
         */
        final MultiPart multiPart = new FormDataMultiPart()
                .bodyPart(fileDataBodyPart);
        multiPart.setMediaType(MediaType.MULTIPART_FORM_DATA_TYPE);

        // POST request final
        ClientResponse response = webResourseBuilder
                .type("multipart/form-data").post(ClientResponse.class,
                        multiPart);


		if(response.getStatus() != HttpStatus.SC_OK){
			throw new NoSuchFileException("HTTP STATUS " + response.getStatus() + " No se pudo cargar el archivo");
		}
		
		try {
			multiPart.close();
		} catch (IOException e) {
			log.error(e.getMessage());
		}
		
		client.destroy();
		
	}
	
	
	public void createOneFolderInSharepoint(String folder) {
		java.lang.System.setProperty("https.protocols", "TLSv1,TLSv1.1,TLSv1.2");
		
		
		ClientConfig clientConfig = new DefaultClientConfig(JacksonJsonProvider.class);
	    Client cliente = Client.create(clientConfig);
	    
	    MultivaluedMap<String, String> queryParams = new MultivaluedMapImpl();
	    queryParams.add("path", this.pathBase);
	    queryParams.add("folder", folder);
	    
		WebResource webResource = cliente.resource(this.url + "/" + PropertiesDb.getInstance().getString("sharepoint.rest.path.create-directory"))
				.queryParams(queryParams);
	      Builder webResourseBuilder = webResource.accept(MediaType.APPLICATION_JSON);
	        webResourseBuilder.header("user", this.username);
	        webResourseBuilder.header("pwd", this.password);
	        webResourseBuilder.header("site", this.site);
		
		ClientResponse clientResponse = webResourseBuilder.post(ClientResponse.class);
		if(clientResponse.getStatus() != HttpStatus.SC_OK){
			throw new NotFoundException("HTTP STATUS " + clientResponse.getStatus() + " Documento no encontrado");
		}
		
	}
	
	
	public FilesDetailSharingDto getFolderFilesInSharepoint(String path ) {
		java.lang.System.setProperty("https.protocols", "TLSv1,TLSv1.1,TLSv1.2");
		
		ClientConfig clientConfig = new DefaultClientConfig(JacksonJsonProvider.class);
	    Client cliente = Client.create(clientConfig);
	    
	    MultivaluedMap<String, String> queryParams = new MultivaluedMapImpl();
	    queryParams.add("path", PropertiesDb.getInstance().getString("imports.norms.sharepoint.site.path") + "/" + path);
	    
	    WebResource webResource = cliente.resource(this.url + "/files" )
				.queryParams(queryParams);
	    Builder webResourseBuilder = webResource.accept(MediaType.APPLICATION_JSON);
	        webResourseBuilder.header("user", this.username);
	        webResourseBuilder.header("pwd", this.password);
	        webResourseBuilder.header("site", this.site);
	        
	   ClientResponse clientResponse = webResourseBuilder.get(ClientResponse.class);
	   
	   FilesDetailSharingDto jsonResponse = new FilesDetailSharingDto();
	   if(clientResponse.getStatus() == HttpStatus.SC_OK){
		   jsonResponse = clientResponse.getEntity(FilesDetailSharingDto.class);
		}

		return jsonResponse;
		
	}
	
}
