package com.srm.fungandrui.revocacion.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.gson.Gson;
import com.srm.fungandrui.revocacion.dao.RevocacionConfirmacionDao;
import com.srm.fungandrui.revocacion.dao.impl.RevocacionConfirmacionDaoImpl;
import com.srm.fungandrui.revocacion.entities.RequestRevocacionConfirmacionDto;
import com.srm.fungandrui.revocacion.entities.RevocacionConfirmacion;
import com.srm.fungandrui.revocacion.service.RevocacionConfirmacionService;
import com.srm.pli.utils.PropertiesDb;
import com.truper.publish.Publisher;

import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;

@Log4j2
@Service()
@RequiredArgsConstructor
public class RevocacionConfirmacionServiceImpl implements RevocacionConfirmacionService {
	
	
	private final boolean DURABLE = true;
	private final boolean EXCLUSIVE = false;
	private final boolean AUTO_DELETE = false;
	
	@Autowired
	private RevocacionConfirmacionDao dao = new RevocacionConfirmacionDaoImpl();

	@Override
	public void revocacionConfirmacion(String folio, String userName) {
		
		String HOST = PropertiesDb.getInstance().getString("rabbit.ws.host");
		Integer PORT = PropertiesDb.getInstance().getInteger("rabbit.ws.port");
		String PASS = PropertiesDb.getInstance().getString("rabbit.ws.pwd");
		String USER = PropertiesDb.getInstance().getString("rabbit.ws.user");
		String VIRTUAL_SERVICE = PropertiesDb.getInstance().getString("rabbit.ws.virtualService");
		String EXCHANGE_NAME = PropertiesDb.getInstance().getString("rabbit.ws.exchangeName");
		String ROUTING_KEY_FR_REVOCACION= PropertiesDb.getInstance().getString("rabbit.ws.routingKey-fr-revocacion-confirmacion");
		String QUEUE_FR_REVOCACION = PropertiesDb.getInstance().getString("rabbit.ws.queueFRRevocacionConfirmacion");
		
		log.info("Busqueda por folio : "+ folio);
		String gsonM = "";
		List<RevocacionConfirmacion> data = dao.getListByFolio(folio, userName);
		int totalDatos = !data.isEmpty()?data.size():0;
		log.info("Informacion encontrada :"+ totalDatos);
		RequestRevocacionConfirmacionDto dto = new RequestRevocacionConfirmacionDto();
		
		if (!data.isEmpty()) {
			dto.setData(data);
			Gson gson = new Gson();
			gsonM = gson.toJson(dto);
			Publisher.publish(HOST, PORT, USER, PASS, VIRTUAL_SERVICE, QUEUE_FR_REVOCACION, EXCHANGE_NAME,
					ROUTING_KEY_FR_REVOCACION, null, gsonM, DURABLE, EXCLUSIVE, AUTO_DELETE);
		}else {
			log.info("Lo sentimos no se encontro informacion para enviar");
		}
		
		
	}
	


}
