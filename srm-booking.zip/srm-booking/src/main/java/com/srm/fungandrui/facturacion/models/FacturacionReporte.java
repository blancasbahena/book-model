package com.srm.fungandrui.facturacion.models;

import java.util.Date;
import java.util.List;
import java.util.Map;

import lombok.Data;
@Data
public class FacturacionReporte {

	private String folio;
	private String po;
	private String blNumber;
	private String booking;
	private String container;
	private String supplier;
	private String carrier;
	private String analyst;
	private String invoiceNumber;
	private String priority;
	private String etaFrom;
	private String etaTo;
	private String pod;
	//CAMPOS PARA VISTA
	private Boolean automatico;  //Proceso Automatico o Manual  VISTA FACTURACION
	private String fechaHoraAprobacionSDI; //Fecha y hora de aprobacion SDI
	private String ampm; //am_pm  VISTA FACTURACION
	private String noFacturaPM; //No. Factura PM
	private String montoUSD; //Monto USD VISTA FACTURACION
	private Double importeOriginal;
	private String fechaEmision;  //VISTA FACTURACION
	private String facturista;
    private String status;
	private String incidenciasEnFacturas;
	private String comentarios;
	private String eta;
	private String shipmentType;
	private String facturaProvedor;
    private String nombreProveedor;
	private Date  fechaEmisionFacturaParcel;
	private String areaRechazo;
	private String sar;
	private String descripcion;
	private String   fechaHoraRechazoContabilidad;  //Contabilidad
	private String areaResponsableSolucion;
	private String fechaInicial;
	private String fechaFinal;
	private String paginaAccion;
	private String paginaActual;
	private Long id;
	private String condicionPago;
	private Integer statusId;
	private String codigoEstatusFactura;
	private String usuarioRechazo;
	private Long FolioSIFE;
	private String fechaProcesadoSIFE;
	private Integer statusSIFE;
	private String descriStatusSIFE;
	private String fechaActualizaStatusSIFE;
	
	private List<Map<String, String>> listaPos;
	
	// para envio de correo correcciones
	private String emails;
	private Integer statusCorreccion;
	private String descripcionCorreccion;
	
	//Datos auxiliares
	private Boolean urgente;
	private String documentoSociedad;
	private String documentoEjercicio;
	private String documentoNumero;
	private Integer diasPago;
	private String auxkey;
	private List<ItemFactura> listItems;
	private String nombre_puerto_descarga;
	
}
