package com.srm.fungandrui.pis.dto;

import java.util.Map;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
@AllArgsConstructor
public class ResponsePdfResponse {

	private String mensaje;
	private String tipoMensaje;
	private String sub;
	private Map<String, String> data;
	
}
