package com.srm.fungandrui.imports.service.impl;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import javax.ws.rs.core.MediaType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.srm.fungandrui.imports.service.UploadImportRequiService;
import com.srm.pli.utils.PropertiesDb;
import com.srm.pli.ws.vo.ResponseImportsVO;
import com.sun.jersey.multipart.FormDataBodyPart;
import com.sun.jersey.multipart.FormDataMultiPart;
import com.sun.jersey.multipart.file.FileDataBodyPart;

@Service
public class UploadImportRequiServiceImpl implements UploadImportRequiService {


	@Autowired
	ImportsServiceClient tsc;
	


@Override
public ResponseImportsVO uploadFileImportRequirements(MultipartFile file,  boolean update, String user) throws IOException {
	tsc.setClient("sharepoint/upload");
	FormDataMultiPart form = new FormDataMultiPart();
	File convFile = new File( file.getOriginalFilename() );
    FileOutputStream fos = new FileOutputStream( convFile );
    fos.write( file.getBytes() );
    fos.close();
	form.field("filename", file.getName());
	form.bodyPart(new FileDataBodyPart("file", convFile));
	form.bodyPart(new FormDataBodyPart("path", "versiones"));
	form.bodyPart(new FormDataBodyPart("update", update ? "true" : "false"));
	form.bodyPart(new FormDataBodyPart("user", user));
	return tsc.getRequest(form, "PARAM");
}


@Override
public void creaDirectorio(String path) {
	SharePointAPI sharePointService = new SharePointAPI();
	sharePointService.setUsername(PropertiesDb.getInstance().getString("imports.fr.sharepoint.username"));
	sharePointService.setPassword(PropertiesDb.getInstance().getString("imports.fr.sharepoint.password"));
	sharePointService.setPathBase(PropertiesDb.getInstance().getString("imports.fr.sharepoint.site.path"));
	sharePointService.setSite(PropertiesDb.getInstance().getString("imports.fr.sharepoint.site"));
	sharePointService.createOneFolderInSharepoint(path);
	
}



}