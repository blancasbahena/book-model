package com.srm.fungandrui.imports.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.gson.JsonObject;
import com.srm.fungandrui.imports.service.ImportsReglasService;
import com.srm.pli.ws.vo.ResponseImportsVO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class ImportsReglasServiceImpl implements ImportsReglasService {

	
	@Autowired
	ImportsServiceClient tsc;
	
	
	@Override
	public ResponseImportsVO deleteRegla(final String producto) throws Exception {
		tsc.setClient("/reglas/delete/producto/"+producto);
		return tsc.getRequest("", "GET");
	}
	
	
	
	@Override
	public ResponseImportsVO getExistsInReglas(final JsonObject codigos) {
		ResponseImportsVO response = null;
		try {
			tsc.setClient("reglas/productos/existeEnReglas");
			response = tsc.getRequest(codigos, "post");

		} catch (Exception e) {
			log.info("ReglasServiceImpl: {}", e);
		}

		return response;
	}
	
	@Override
	public ResponseImportsVO getReglasProductos(JsonObject codigos){
		ResponseImportsVO response = null;
		try {
			tsc.setClient("reglas/reglasInListProducts");
			response = tsc.getRequest(codigos, "post");
		} catch (Exception e) {
			log.info("ReglasServiceImpl: {}", e);
		}

		return response;
	}

	@Override
	public ResponseImportsVO getReglasComercioProductos(JsonObject codigos) throws Exception {
		ResponseImportsVO response = null;
		try {
			tsc.setClient("reglas/comercio/reglasInListProducts");
			response = tsc.getRequest(codigos, "post");
		} catch (Exception e) {
			log.info("ReglasServiceImpl: {}", e);
		}

		return response;
	}
	
	@Override
	public ResponseImportsVO getReglasTruperProductos(JsonObject codigos) throws Exception {
		ResponseImportsVO response = null;
		try {
			tsc.setClient("reglas/truper/reglasInListProducts");
			response = tsc.getRequest(codigos, "post");
		} catch (Exception e) {
			log.info("ReglasServiceImpl: {}", e);
		}

		return response;
	}
	

	@Override
	public ResponseImportsVO getReglasProducto(final Long producto) throws Exception {
		ResponseImportsVO response = null;
		try {
			tsc.setClient("reglas/producto/"+producto);
			response = tsc.getRequest("", "get");
		} catch (Exception e) {
			log.info("ReglasServiceImpl: {}", e);
		}

		return response;
	}
	

}
