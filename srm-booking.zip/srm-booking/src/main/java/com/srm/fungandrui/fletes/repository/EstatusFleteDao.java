package com.srm.fungandrui.fletes.repository;

import java.util.List;

import com.srm.fungandrui.fletes.entities.EstatusFlete;

public interface EstatusFleteDao {
	
	List<EstatusFlete> getAll();

}
