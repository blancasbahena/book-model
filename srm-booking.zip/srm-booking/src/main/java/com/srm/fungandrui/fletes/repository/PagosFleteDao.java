package com.srm.fungandrui.fletes.repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.srm.fungandrui.fletes.entities.FiltersPagoFletes;
import com.srm.fungandrui.fletes.entities.PagoFlete;

@Repository
public interface PagosFleteDao {
	
	List<PagoFlete> getList();
	List<PagoFlete> getListByStatus(String status);
	List<PagoFlete> getListByContenedor(String contenedor);
	List<PagoFlete> getListByFolio(String folio);
	List<PagoFlete> getListByFecha(String fecha);
	
	List<PagoFlete> getList(FiltersPagoFletes filtros);

}
