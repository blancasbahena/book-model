package com.srm.fungandrui.pis.repository;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.srm.fungandrui.pis.dto.ProformaDetalleDTO;
import com.srm.fungandrui.pis.util.Querys;
import com.srm.pli.db.ConexionDB;
@Repository
public class ProformaDetalleDaoImpl implements ProformaDetalleDao {

	@Override
	public List<ProformaDetalleDTO> getAll(Integer id) {
		List<ProformaDetalleDTO> prfs = new ArrayList<ProformaDetalleDTO>();
		Connection conn = null;
		try {
			conn = ConexionDB.dameConexion();
			String  query = new StringBuilder(Querys.SQL_PROFORMA_DETALLE)
					.append(id.toString()).toString();
			try (PreparedStatement pstmt = conn.prepareStatement(query)) {
				ResultSet rs = pstmt.executeQuery();
				while (rs.next()) {
					Date       shippingEnviado=null;
					BigDecimal cero =new BigDecimal(0);
					BigDecimal montoOriginal=cero;
					BigDecimal montoEnviado=cero;
					BigDecimal pesoOriginal=cero;
					BigDecimal pesoEnviado=cero;
					BigDecimal volumenOriginal=cero;
					BigDecimal volumenEnviado=cero;
					BigDecimal precioUnitarioEnviado=cero;
					BigDecimal precioUnitarioOriginal=cero; 
					try {montoOriginal=new BigDecimal(rs.getDouble("montoOriginal"));}catch(Exception e) {}
					try {montoEnviado=new BigDecimal(rs.getDouble("montoEnviado"));}catch(Exception e) {}
					try {pesoOriginal=new BigDecimal(rs.getDouble("pesoOriginal"));}catch(Exception e) {}
					try {pesoEnviado=new BigDecimal(rs.getDouble("pesoEnviado"));}catch(Exception e) {}
					try {volumenOriginal=new BigDecimal(rs.getDouble("volumenOriginal"));}catch(Exception e) {}
					try {volumenEnviado=new BigDecimal(rs.getDouble("volumenEnviado"));}catch(Exception e) {}
					try {precioUnitarioEnviado=new BigDecimal(rs.getDouble("precioUnitarioEnviado"));}catch(Exception e) {}
					try {precioUnitarioOriginal=new BigDecimal(rs.getDouble("precioUnitarioOriginal"));}catch(Exception e) {}
					try {shippingEnviado = getDate(rs.getInt("shippingDateEnviado")); }catch(Exception e) {e.printStackTrace();}
					ProformaDetalleDTO ct = new ProformaDetalleDTO(
							rs.getString("noOrden"),
							rs.getInt("posicion"),
							rs.getInt("idPI"),
							rs.getString("item"),
							rs.getString("brand"),
							rs.getString("code"),
							rs.getString("description"),
							rs.getInt("shippingDate"),
							rs.getInt("cantidadOriginal"),
							rs.getString("unidadeMedida"),
							precioUnitarioOriginal,
							rs.getInt("cantidadEnviada"),
							montoOriginal,
							montoEnviado,
							pesoOriginal,
							pesoEnviado,
							volumenOriginal,
							volumenEnviado,
							rs.getBoolean("isFoc"),
							rs.getBoolean("isOtherItem"),
							precioUnitarioEnviado,
							rs.getInt("shippingDateEnviado"),
							shippingEnviado,
							rs.getString("cliente"),
							rs.getInt("idPI")+"-"+rs.getString("noOrden")+"-"+rs.getInt("posicion"),
							false,
							false,
							false,
							false,
							false,
							false,
							rs.getString("currency"),
							rs.getString("centro"),
							rs.getString("planeador")
							);
					ct.setIdEstatusChange(rs.getInt("idEstatusChange"));
					ct.setUserChange(rs.getString("userChange"));
					ct.setFechaChange(getStrDate(rs.getDate("fechaChange")));
					prfs.add(ct);
				}
			} catch (SQLException eSQL) {
				eSQL.printStackTrace();
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			ConexionDB.devolver(conn);
		}
		return prfs;
	}

	private Date getDate(Integer shipping) throws ParseException {
		if(shipping!=null) {
			if(shipping>0) {
				SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
				String fecha = shipping.toString();
				return (Date)sdf.parse(fecha);
			}
		}
		return null;
	}
	private String getStrDate(Date fecha) throws ParseException {
		if(fecha!=null) { 
			 DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");  
             String strDate = dateFormat.format(fecha);  
			return strDate; 
		}
		return null;
	}
 
}
