package com.srm.fungandrui.pis.service.impl;

import lombok.Data;

@Data
public class PIS {
	
	private String position;
	
	private String shippingDate;
	private String shippingDateEnviado;
	
	private String quantity;
	private String quantityEnviado;
	
	private String unitPrice;
	private String unitPriceEnviado;
	
	private String totalAmount;
	private String totalAmountEnviado;
	
	private String weight;
	private String weightEnviado;
	
	private String volume;
	private String volumeEnviado;
	
}
