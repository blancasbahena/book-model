package com.srm.fungandrui.facturacion.models;

import lombok.Data;

@Data
public class CatStatusFacturacion {
	public Integer codigo;
	public String descripcion;

}
