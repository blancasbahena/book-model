package com.srm.fungandrui.facturacion.service;

import java.util.List;

import com.srm.fungandrui.facturacion.models.ReporteSemanalIncidencias;

public interface ReporteSemanalIncidencia {
	
	public List<ReporteSemanalIncidencias> getReporteSemanalIncidencias ();

	
}
