package com.srm.fungandrui.expediente.service;

import java.io.File;
import java.io.IOException;
import java.util.Collections;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.srm.pli.bo.FileUploadBO;
import com.srm.pli.utils.PropertiesDb;
import com.truper.expediente.RequestAuth;
import com.truper.expediente.StandarResponse;

import lombok.extern.slf4j.Slf4j;
@Service
@Slf4j
public class ExpedienteUpLoadServiceImp implements ExpedienteUpLoadService {
	private static final String POS_FIJO_ID_UNICO="_@_";
	private static final int MEMORY_THRESHOLD   = 1024 * 1024 * 3;  // 3MB
    private static final int MAX_FILE_SIZE      = 1024 * 1024 * 1002; // 40MB
    private static final int MAX_REQUEST_SIZE   = 1024 * 1024 * 1204; // 50MB
    private static final long SIZE_ALLOWED  =62914560;
	@Autowired
	private final RestTemplate restTemplate = new RestTemplate(); 
	private final String PROPERTY_URL="srm.truper.expediente";
	@Override
	public FileUploadBO guardaDocumentoDirectorio(HttpServletRequest request, String uploadPath) {
		Long   idUnico = (new java.util.Date()).getTime();
		try { 
			if (!ServletFileUpload.isMultipartContent(request)) {
				return new  FileUploadBO(idUnico,"",0l,"","","Error: el formulario debe contener enctype = multipart / form-data",true);
			}
			String contentType="";
			Long   sizeFile=1l;
			String fileName="";
			String extent="";
			
			DiskFileItemFactory factory = new DiskFileItemFactory();
			factory.setSizeThreshold(MEMORY_THRESHOLD);
			factory.setRepository(new File(System.getProperty("java.io.tmpdir")));		 
			ServletFileUpload upload = new ServletFileUpload(factory);
			upload.setFileSizeMax(MAX_FILE_SIZE);
			upload.setSizeMax(MAX_REQUEST_SIZE); 
			upload.setHeaderEncoding("UTF-8"); 
			File uploadDir = new File(uploadPath);
			if (!uploadDir.exists()) {
				uploadDir.mkdir();
			}
			try { 
				List<FileItem> formItems = upload.parseRequest(request);
				if (formItems != null && formItems.size() > 0) {
					for (FileItem item : formItems) {
						contentType=item.getContentType();
						sizeFile=item.getSize();
						if(sizeFile<=SIZE_ALLOWED) {
							if (!item.isFormField()) {
								sizeFile=item.getSize();
								fileName =  idUnico.toString()+ POS_FIJO_ID_UNICO+new File(item.getName()).getName();
								String filePath = uploadPath +File.separator  + fileName;
								File storeFile = new File(filePath); 
								extent= FilenameUtils.getExtension(fileName);
								item.write(storeFile);
							}
						}
						else {
							return new  FileUploadBO(idUnico,"",0l,"","","the request was rejected because its size ("+sizeFile+") exceeds the configured maximum ("+SIZE_ALLOWED+")",true);	
						}
					}
					return new  FileUploadBO(idUnico,fileName,sizeFile,contentType,extent,"OK",false);
				}
			} catch (Exception ex) {
				return new  FileUploadBO(idUnico,"",0l,"","",ex.getMessage(),true);
			} 
		} catch (Exception e) {
			return new  FileUploadBO(idUnico,"",0l,"","",e.getMessage(),true);
		}
		return new  FileUploadBO(idUnico,"",0l,"","","Error, problem with load file",true);
	}
	@Override
	public String guardaArchivoProformaDirectorio(HttpServletRequest request, String uploadPath) {
		Long   idUnico = (new java.util.Date()).getTime();
		String contentType="";
		Long   sizeFile=1l;
		String fileName="";
		String extent="";
		try { 
			if (!ServletFileUpload.isMultipartContent(request)) {
				return "Error";
			}
			DiskFileItemFactory factory = new DiskFileItemFactory();
			factory.setSizeThreshold(MEMORY_THRESHOLD);
			factory.setRepository(new File(System.getProperty("java.io.tmpdir")));		 
			ServletFileUpload upload = new ServletFileUpload(factory);
			upload.setFileSizeMax(MAX_FILE_SIZE);
			upload.setSizeMax(MAX_REQUEST_SIZE); 
			upload.setHeaderEncoding("UTF-8"); 
			File uploadDir = new File(uploadPath);
			if (!uploadDir.exists()) {
				uploadDir.mkdir();
			}
			try { 
				List<FileItem> formItems = upload.parseRequest(request);
				if (formItems != null && formItems.size() > 0) {
					for (FileItem item : formItems) {
						contentType=item.getContentType();
						sizeFile=item.getSize();
						if(sizeFile<=SIZE_ALLOWED) {
							if (!item.isFormField()) {
								sizeFile=item.getSize();
								fileName =  idUnico.toString()+ POS_FIJO_ID_UNICO+new File(item.getName()).getName();
								String filePath = uploadPath +File.separator  + fileName;
								File storeFile = new File(filePath); 
								extent= FilenameUtils.getExtension(fileName);
								item.write(storeFile);
								return fileName;
							}
						}
						else {
							return "Error.the request was rejected because its size ("+sizeFile+") exceeds the configured maximum ("+SIZE_ALLOWED+")";	
						}
					} 
				}
			} catch (Exception ex) {
				return "Error."+ex.getMessage();
			} 
		} catch (Exception e) {
			return "Error."+e.getMessage();
		}
		return "Error. problem with load file";
	}

	@Override
	public Boolean saveFileToSharePoint(String filename, String lbContenedor,String pathFile) throws IOException {
		String url = PropertiesDb.getInstance().getString(PROPERTY_URL);
		ResponseEntity<StandarResponse<String>> responseAuthen=authenticated("prueba","prueba", url +"/auth/");
		if(responseAuthen.getStatusCode()== HttpStatus.OK) {
			HttpHeaders headers = new HttpHeaders();
			headers.set("Authorization", "Bearer " + (String) responseAuthen.getBody().getData());
			headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));			
	        headers.setContentType(MediaType.MULTIPART_FORM_DATA);
	        String urlCreateDocumentShare= url+"/file/uploadFile/"+lbContenedor+"/"+filename;
	        MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
	        body.add("file", new FileSystemResource(new File(pathFile+"/"+filename)));
	        HttpEntity<MultiValueMap<String, Object>> requestEntity = new HttpEntity<>(body, headers);
	        ResponseEntity<StandarResponse<String>> respuesta = restTemplate.exchange(urlCreateDocumentShare, HttpMethod.POST, requestEntity,
					new ParameterizedTypeReference<StandarResponse<String>>() {}); 	        
	        log.error("Response code: " + respuesta.getStatusCode());
	        return true;
		}
		return false;
    } 

	@SuppressWarnings("unused")
	private  ResponseEntity<StandarResponse<String>> authenticated(final String user, final String pass, final String url) {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
		HttpEntity<RequestAuth> request = new HttpEntity<>(new RequestAuth(user, pass), headers);
		return restTemplate.exchange(url, HttpMethod.POST, request,
					new ParameterizedTypeReference<StandarResponse<String>>() {});
		
	}
}
