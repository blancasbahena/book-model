package com.srm.fungandrui.pis.service.impl;

import java.io.Serializable;

import lombok.Data;

@Data
public class AtachFiles implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String nombre;

	private String file;

}
