package com.srm.fungandrui.revocacion.dao;

import java.util.List;

import com.srm.fungandrui.revocacion.entities.RevocacionConfirmacion;

public interface RevocacionConfirmacionDao {
	
	List<RevocacionConfirmacion> getListByFolio(String folio, String userName);

}
