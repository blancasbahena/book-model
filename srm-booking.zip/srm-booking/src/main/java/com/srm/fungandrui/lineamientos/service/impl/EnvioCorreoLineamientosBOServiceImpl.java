package com.srm.fungandrui.lineamientos.service.impl;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.google.gson.Gson;
import com.srm.fungandrui.lineamientos.dto.DetalleBO;
import com.srm.fungandrui.lineamientos.dto.EnvioCorreoBODTO;
import com.srm.fungandrui.lineamientos.service.EnvioCorreoLineamientosBOService;
import com.srm.pli.bo.SarDetalleBO;
import com.srm.pli.dao.RevisionGDRDAO;
import com.srm.pli.utils.PropertiesDb;
import com.truper.businessEntity.RevisionGDR;
import com.truper.businessEntity.UserBean;
import com.truper.publish.Publisher;
@Service
public class EnvioCorreoLineamientosBOServiceImpl implements EnvioCorreoLineamientosBOService {
	private final boolean DURABLE = true;
	private final boolean EXCLUSIVE = false;
	private final boolean AUTO_DELETE = false;

	@Override
	public void enviarCorreoLineaminetosBO(UserBean usuario, com.srm.pli.bo.SarBO sar, ArrayList<SarDetalleBO> listaDet,
			Map<String, Object> datosMail,boolean reject,String[] correosBU)
			throws ParseException {
		
		String HOST = PropertiesDb.getInstance().getString("rabbit.ws.pis.host");
		Integer PORT = PropertiesDb.getInstance().getInteger("rabbit.ws.pis.port");
		String PASS = PropertiesDb.getInstance().getString("rabbit.ws.pis.pwd");
		String USER = PropertiesDb.getInstance().getString("rabbit.ws.pis.user");
		String VIRTUAL_SERVICE = PropertiesDb.getInstance().getString("rabbit.ws.pis.virtualService");
		String EXCHANGE_NAME = PropertiesDb.getInstance().getString("rabbit.ws.pis.exchangeName");
		String ROUTING_KEY_FR_PIS = PropertiesDb.getInstance().getString("rabbit.ws.routingKey-fr-pis");
		String QUEUE_FR_PIS = PropertiesDb.getInstance().getString("rabbit.ws.queue-fr-pis");
		
		String MAIL_SENDER_BO = PropertiesDb.getInstance().getString("lineamientos.bos.mail.sender");
		String MAIL_TEMPLATE_REJECT = PropertiesDb.getInstance().getString("lineamientos.bos.mail.template.reject");
		String MAIL_TEMPLATE_SUCCESSFUL = PropertiesDb.getInstance().getString("lineamientos.bos.mail.template.sucessful");
		String DEBUG = PropertiesDb.getInstance().getString("lineamientos.bos.mail.debug");
		String MAIL_DEBUG = PropertiesDb.getInstance().getString("lineamientos.bos.mail.debug.correos");
		String MAIL_SUBJECT = PropertiesDb.getInstance().getString("lineamientos.bos.mail.subject");
		String MAIL_GRUPO = PropertiesDb.getInstance().getString("lineamientos.bos.mail.grupo.correos"); 
		
		
		
		String[] toMail = {MAIL_DEBUG};
		String[] toDebug = MAIL_DEBUG.trim().split(";");
		
		String gsonM = "";
		List<String> to = new ArrayList<>();
		List<String> cc = new ArrayList<>();
		
		List<String> correosDebug = new ArrayList<>();
		
		

		if (DEBUG.equals("true")) {
			to.addAll(Arrays.asList(toDebug));
			for(String correo: Arrays.asList(MAIL_GRUPO)) {
				correosDebug.add(correo);	
			}
			for(String correo: Arrays.asList(correosBU)) {
				correosDebug.add(correo);	
			}
			
		} else {
			to.add(MAIL_GRUPO);
			to.addAll(Arrays.asList(correosBU));
		}  
		Map<String, Object> params = new HashMap<>();

		Map<String, Object> data = new HashMap<>();
		data.put("supplier", sar.getProveedor());
		data.put("folio", sar.getFolio().toString()); 
		List<DetalleBO> listDetalleBO= new ArrayList<DetalleBO>();
		RevisionGDR revision = new RevisionGDR();
		revision.setFolio(sar.getFolio());
		revision.setActivo(false);
		RevisionGDRDAO gdrDao = new RevisionGDRDAO();
		List<RevisionGDR> revisiones = (List<RevisionGDR>) gdrDao.select(revision);
		if(revisiones!=null && revisiones.size()>0) {
			RevisionGDR revision01 = revisiones.get(0);
			DetalleBO deta = new DetalleBO();
			deta.setGrdAprobado(revision01.getFechaGDRModificadaFormat());
			deta.setGrdOoriginal(revision01.getFechaGDRActualFormat());
			deta.setNuevoEtd(revision01.getFechaETDModificadaFormat());
			listDetalleBO.add(deta);
		}
		Map<String, Object> data1 = new HashMap<>();
 		data1.put("details", listDetalleBO);
		params.put("data", data);
		params.put("debug", DEBUG);
		params.put("debugTO", correosDebug);
		params.put("debugCC", "");
		params.put("data1", data1);


		EnvioCorreoBODTO envioCorreoDTO = new EnvioCorreoBODTO();
		envioCorreoDTO.setTo(to);
		envioCorreoDTO.setCc(cc);
		envioCorreoDTO.setSubject(MAIL_SUBJECT.replaceAll("XXXXXX",sar.getFolio().toString()));

		if (!reject) {
			envioCorreoDTO.setTemplate(MAIL_TEMPLATE_SUCCESSFUL);
		} else {
			envioCorreoDTO.setTemplate(MAIL_TEMPLATE_REJECT);
		}

		envioCorreoDTO.setSender(MAIL_SENDER_BO);
		envioCorreoDTO.setParams(params);

		Gson gson = new Gson();
		gsonM = gson.toJson(envioCorreoDTO);
		Publisher.publish(HOST, PORT, USER, PASS, VIRTUAL_SERVICE, QUEUE_FR_PIS, EXCHANGE_NAME, ROUTING_KEY_FR_PIS,
				null, gsonM, DURABLE, EXCLUSIVE, AUTO_DELETE);

	}
 

}
