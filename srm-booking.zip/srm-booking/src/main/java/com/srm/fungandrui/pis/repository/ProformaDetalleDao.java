package com.srm.fungandrui.pis.repository;

import java.util.List;

import com.srm.fungandrui.pis.dto.ProformaDetalleDTO;

public interface ProformaDetalleDao{

	public List<ProformaDetalleDTO> getAll(Integer id);
}
