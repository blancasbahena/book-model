package com.srm.fungandrui.revocacion.entities;

import lombok.Data;

@Data
public class RenovacionConfirmacionDto {
	private String ebeln;
	private String ebelp;
	private String type;
	private String message;

}
