package com.srm.fungandrui.facturacion.models;

import java.io.Serializable;

import lombok.Data;

@Data
public class CatCorreccionModel implements Serializable {
	/**
	* 
	*/
	private static final long serialVersionUID = 1L;
	private Integer id;
	private String descripcion;
	private String correos;

}
