package com.srm.fungandrui.revocacion.queues;

import java.io.IOException;
import java.nio.charset.StandardCharsets;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.google.gson.Gson;
import com.rabbitmq.client.AMQP;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.DefaultConsumer;
import com.rabbitmq.client.Envelope;
import com.srm.fungandrui.revocacion.entities.RenovacionConfirmacionDto;
import com.srm.fungandrui.revocacion.entities.ResponseRenovacionConfirmacionDto;
import com.srm.pli.utils.PropertiesDb;
import com.truper.subscribe.Subscriber;
import com.truper.utils.ConvertUtils;

import lombok.extern.log4j.Log4j2;

@Configuration
@Log4j2
public class QueusRevocacionConfig {
	
	


	private final boolean AUTO_DELETE = false;
	private final boolean DURABLE = true;
	private final boolean EXCLUSIVE = true;
	private final String TYPE = "direct";
	
	@Bean
	public String revocacionConfirmacion() {
		String HOST = PropertiesDb.getInstance().getString("rabbit.ws.host");
		Integer PORT = PropertiesDb.getInstance().getInteger("rabbit.ws.port");
		String PASS = PropertiesDb.getInstance().getString("rabbit.ws.pwd");
		String USER = PropertiesDb.getInstance().getString("rabbit.ws.user");
		String VIRTUAL_SERVICE = PropertiesDb.getInstance().getString("rabbit.ws.virtualService");
		String EXCHANGE_NAME = PropertiesDb.getInstance().getString("rabbit.ws.exchangeName");
		String QUEUE_FR_REVOCACION_RESPUESTA = PropertiesDb.getInstance().getString("rabbit.ws.queueFRRevocacionConfirmacionRespuesta");
		String ROUTING_KEY_FR_REVOCACION_RESPUESTA= PropertiesDb.getInstance().getString("rabbit.ws.routingKeyFRRevocacionConfirmacionRespuesta");

		try {
			final Channel channel = Subscriber.createQueue(HOST, PORT, USER, PASS, VIRTUAL_SERVICE, EXCHANGE_NAME, TYPE,
					DURABLE, !EXCLUSIVE, AUTO_DELETE, QUEUE_FR_REVOCACION_RESPUESTA, ROUTING_KEY_FR_REVOCACION_RESPUESTA, null);

			boolean autoAck = false;

			channel.basicConsume(QUEUE_FR_REVOCACION_RESPUESTA, autoAck, "FR-Queue-Consumer", new DefaultConsumer(channel) {
				@Override
				public void handleDelivery(String consumerTag, Envelope sobre, AMQP.BasicProperties properties,
						byte[] body) {
					long deliveryTag = sobre.getDeliveryTag();
					try {
						log.info("*** Respuesta de revocacion final ");
						String respuesta = ConvertUtils.deserialize(body).toString();
						ResponseRenovacionConfirmacionDto response =  new Gson().fromJson(respuesta, ResponseRenovacionConfirmacionDto.class);		
						response.getData().forEach((b) -> log.info("PO: {} Posicion:{} Mensaje: {}" ,b.getEbeln(), b.getEbelp(),b.getMessage()));
						log.info("Proceso de revocacion finalizado");
					
                        channel.basicAck(deliveryTag, false);

					} catch (ClassCastException e) {
						try {
							channel.basicAck(deliveryTag, false);
						} catch (IOException e1) {
							e1.printStackTrace();
							log.error(e1.getMessage(), e1);
						}
						e.printStackTrace();
						log.error(e.getMessage(), e);
					} catch (IOException e1) {
						e1.printStackTrace();
						log.error(e1.getMessage(), e1);
					} catch (Exception e1) {
						try {
							channel.basicAck(deliveryTag, false);
						} catch (IOException e) {
							log.error(e1.getMessage(), e1);
							e.printStackTrace();
						}
						log.error(e1.getMessage(), e1);
						e1.printStackTrace();
					}  
				}
			});

		} catch (IOException e) {
			log.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return "OK";

	}

}
