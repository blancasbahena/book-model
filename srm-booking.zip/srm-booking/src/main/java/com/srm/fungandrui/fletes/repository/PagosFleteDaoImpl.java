package com.srm.fungandrui.fletes.repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.srm.fungandrui.fletes.entities.FiltersPagoFletes;
import com.srm.fungandrui.fletes.entities.PagoFlete;
import com.srm.fungandrui.fletes.queries.QueriesFletes;
import com.srm.pli.dao.DAOUtils;
import com.srm.pli.db.ConexionDB;
import com.srm.pli.utils.FuncionesComunesPLI;
import com.truper.utils.date.UtilsFechas;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Repository
public class PagosFleteDaoImpl implements PagosFleteDao{
	

	@Override
	public List<PagoFlete> getList() {
		List<PagoFlete> bloqueos = new ArrayList<PagoFlete>();
		Connection conn = null;
		try {
			conn = ConexionDB.dameConexion();
			try (PreparedStatement pstmt = conn.prepareStatement(QueriesFletes.SQL_PAGOS_FACTURA)) {

				ResultSet rs = pstmt.executeQuery();
				while (rs.next()) {
					PagoFlete pago = rowMapper(rs);
					bloqueos.add(pago);
				}
			} catch (SQLException eSQL) {
				log.error(getClass().getName() + eSQL.toString());
			}
		} catch (Exception e) {
			log.error(getClass().getName() + e.toString());
		} finally {
			ConexionDB.devolver(conn);
		}
		return bloqueos;
	}
	
	

	@Override
	public List<PagoFlete> getListByStatus(String status) {
		List<PagoFlete> bloqueos = new ArrayList<PagoFlete>();
		Connection conn = null;
		try {
			conn = ConexionDB.dameConexion();
			String condicion = " where estatus_pago_flete = ?";
			try (PreparedStatement pstmt = conn.prepareStatement(QueriesFletes.SQL_PAGOS_FACTURA+ condicion)) {
				pstmt.setString(1, status);
				ResultSet rs = pstmt.executeQuery();
				while (rs.next()) {
					PagoFlete pago = rowMapper(rs);
					bloqueos.add(pago);
				}
			} catch (SQLException eSQL) {
				log.error(getClass().getName() + eSQL.toString());
			}
		} catch (Exception e) {
			log.error(getClass().getName() + e.toString());
		} finally {
			ConexionDB.devolver(conn);
		}
		return bloqueos;
	}

	@Override
	public List<PagoFlete> getListByContenedor(String contenedor) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<PagoFlete> getListByFolio(String folio) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<PagoFlete> getListByFecha(String fecha) {
		// TODO Auto-generated method stub
		return null;
	}
	
private PagoFlete rowMapper (ResultSet rs ) throws SQLException {
		
		PagoFlete pago = new PagoFlete();
		pago.setClaveNaviera(rs.getString("claveNaviera"));
		pago.setAcreedor(rs.getString("acreedor")!=null?rs.getString("acreedor"):"-");
		pago.setContenedorCaja(rs.getString("contenedor_caja")!=null?rs.getString("contenedor_caja"):"-");
		pago.setBl(rs.getString("bl")!=null?rs.getString("bl"):"-");
		pago.setFacturaProveedorLogistico(rs.getString("factura_proveedor_logistico")!=null?rs.getString("factura_proveedor_logistico"):"-");
		pago.setFechaFactura(rs.getString("fecha_factura")!=null?rs.getString("fecha_factura"):"-");
		pago.setTipoContenedor(rs.getString("tipo_contenedor")!=null?rs.getString("tipo_contenedor"):"-");
		pago.setPuertoEmbarque(rs.getString("puerto_embarque")!=null?rs.getString("puerto_embarque"):"-");
		pago.setPuertoDescarga(rs.getString("puerto_descarga")!=null?rs.getString("puerto_descarga"):"-");
		pago.setImporte(rs.getDouble("importe"));
		pago.setMoneda(rs.getString("moneda"));
		pago.setTipoFactura(rs.getString("tipo_factura")!=null?rs.getString("tipo_factura"):"-");
		pago.setFolio(rs.getString("folio"));
		pago.setCortePuerto(rs.getString("corte_puerto")!=null?rs.getString("corte_puerto"):"-");
		pago.setEstatusPagoFlete(rs.getString("estatus_pago_flete")!=null?rs.getString("estatus_pago_flete"):"-");
		return pago;
	}



	@Override
	public List<PagoFlete> getList(FiltersPagoFletes filtros) {
		List<PagoFlete> bloqueos = new ArrayList<PagoFlete>();
		Connection conn = null;
		DAOUtils utils = new DAOUtils();

		PreparedStatement pst = null;
		ResultSet rs = null;
		try {
			conn = ConexionDB.dameConexion();
			StringBuilder sql = new StringBuilder(QueriesFletes.SQL_PAGOS_FACTURA);
			sql.append(" WHERE 1=1  ");
			utils.setSelect(true);

			if (!filtros.getFolio().isEmpty()) {
				sql.append(utils.ajustaColumna(" and folio = ? "));

			}

			if (!filtros.getFechaInicial().isEmpty() && !filtros.getFechaFinal().isEmpty()) {
				sql.append(utils.ajustaColumna(" and fecha_factura BETWEEN ? and  ? "));
			}

			if (!"-1".equals(filtros.getStatus())) {
				sql.append(utils.ajustaColumna(" and estatus_pago_flete = ? "));
			}

			if (!filtros.getContenedor().isEmpty()) {
				sql.append(utils.ajustaColumna(" and contenedor_caja = ? "));
			}
			

			int cont = 1;

			try {

				pst = conn.prepareStatement(sql.toString());
				utils.inicializaQuery(sql.toString());

				if (!filtros.getFolio().isEmpty()) {
					utils.ajustaParametro(cont++, pst, filtros.getFolio(), String.class);
				}

				if (!filtros.getFechaInicial().isEmpty() && !filtros.getFechaFinal().isEmpty()) {
					
					int inicioInt = FuncionesComunesPLI.fechaJquery2int(filtros.getFechaInicial(), "-");
					int finInt = FuncionesComunesPLI.fechaJquery2int(filtros.getFechaFinal(), "-");
					
					//Date date1 = UtilsFechas.setConvierteFechaIntToDate(inicioInt);
					//Date date2 = UtilsFechas.setConvierteFechaIntToDate(finInt);
					
					//utils.ajustaParametro(cont++, pst, UtilsFechas.setConvierteFechaToSQLDate(date1), Date.class);
				//	utils.ajustaParametro(cont++, pst, UtilsFechas.setConvierteFechaToSQLDate(date2), Date.class);
					
					
					utils.ajustaParametro(cont++, pst, inicioInt, Integer.class);
					utils.ajustaParametro(cont++, pst, finInt, Integer.class);
				}

				if (!"-1".equals(filtros.getStatus())) {

					utils.ajustaParametro(cont++, pst, filtros.getStatus(), String.class);
				}

				if (!filtros.getContenedor().isEmpty()) {
					utils.ajustaParametro(cont++, pst, filtros.getContenedor(), String.class);
				}

				rs = pst.executeQuery();
				while (rs.next()) {
					PagoFlete pago = rowMapper(rs);
					bloqueos.add(pago);
				}
			} catch (SQLException eSQL) {
				log.error(getClass().getName() + eSQL.toString());
			}
		} catch (Exception e) {
			log.error(getClass().getName() + e.toString());
		} finally {
			ConexionDB.devolver(conn);
		}
		return bloqueos;
	}
	

}
