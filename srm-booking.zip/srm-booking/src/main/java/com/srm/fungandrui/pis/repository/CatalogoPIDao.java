package com.srm.fungandrui.pis.repository;

import java.util.List;

import com.srm.fungandrui.pis.dto.CatalogoPIDTO;

public interface CatalogoPIDao {
	public List<CatalogoPIDTO> getAll();
	public CatalogoPIDTO findById(Integer id);
}
