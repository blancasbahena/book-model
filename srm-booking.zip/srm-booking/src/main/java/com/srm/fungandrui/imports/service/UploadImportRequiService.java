package com.srm.fungandrui.imports.service;

import java.io.FileNotFoundException;
import java.io.IOException;

import org.springframework.web.multipart.MultipartFile;

import com.srm.pli.ws.vo.ResponseImportsVO;

public interface UploadImportRequiService {

	
	ResponseImportsVO uploadFileImportRequirements(MultipartFile file, boolean update, String user) throws FileNotFoundException, IOException;
	
	void creaDirectorio(String path);
	
	
}
