package com.srm.fungandrui.facturacion.service.impl;


import java.util.List;

import org.jfree.util.Log;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.srm.fungandrui.facturacion.dao.IFacturacionDAO;
import com.srm.fungandrui.facturacion.models.BeanFacturacion;
import com.srm.fungandrui.facturacion.models.CatCorreccionModel;
import com.srm.fungandrui.facturacion.models.CatStatusFactura;
import com.srm.fungandrui.facturacion.models.CatStatusFacturacion;
import com.srm.fungandrui.facturacion.models.CatStatusIncidencias;
import com.srm.fungandrui.facturacion.models.ControlEmbarqueModel;
import com.srm.fungandrui.facturacion.models.EntregaTraficoModel;
import com.srm.fungandrui.facturacion.models.Facturacion;
import com.srm.fungandrui.facturacion.models.FacturacionReporte;
import com.srm.fungandrui.facturacion.service.FactService;
import com.srm.fungandrui.facturacion.service.TraficoRabbitService;
import com.srm.fungandrui.facturacion.utils.PlantillasEmailFacturacion;
import com.srm.fungandrui.facturacion.utils.SendEmail;
import com.srm.fungandrui.sc.model.FiltroEntregaTrafico;
import com.srm.fungandrui.sc.model.ResponseVO;
import com.srm.pli.utils.MailUtils;
import com.truper.trafico.ConsolidacionFolioDto;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class FacturacionServiceImpl implements FactService {

	@Autowired
	IFacturacionDAO ifacturacionDAO;

	@Autowired
	RabbitServicesImpl rabbitServicesImpl;
	
	@Autowired
	private TraficoRabbitService traficoRabbitService;

	@Override
	public List<Facturacion> getFacturacion() {
		List<Facturacion> listFacturacion = ifacturacionDAO.listarFacturacion();
		return listFacturacion;
	}

	@Override
	public List<Facturacion> getbyFilterService(Facturacion filtro) {
		List<Facturacion> listFacturacion = ifacturacionDAO.getByFilterDAO(filtro);
		//Facturacion facturacion = new Facturacion ();
		return listFacturacion;
	}

	@Override
	public List<Facturacion> getbyFilterServiceRejectd(Facturacion filtro) {
		List<Facturacion> listFacturacionReject = ifacturacionDAO.getByFilterRejectedDAO(filtro);
		return listFacturacionReject;
	}

//	@Override
//	public List<Facturacion> getListRejectd() {
//		List<Facturacion> listFacturacionReject = ifacturacionDAO.getListRejectedDAO();
//		return listFacturacionReject;
//	}

	@Override
	public void updateIncidence(BeanFacturacion beanFacturacion, String userName) {
//		int retorno = 0;
        Facturacion retorno ;
		String numeroIncidencia = beanFacturacion.getIncidencia();
		String plantilla = PlantillasEmailFacturacion.INCIDENCIA_ACTUALIZACION;
		log.info("NumeroIncidencia : ",numeroIncidencia);

		String listEmails = getEmails(numeroIncidencia);
		log.info("Se obtiene Lista de Correos", listEmails);
	
		retorno = ifacturacionDAO.updateByFolio(beanFacturacion, userName);
		if (retorno != null) {
			try {
				
				log.info("Inicia correo por parte de: " + userName);
				String sar = retorno.getFolio() != null ? retorno.getFolio() : "--";
				String contenedor = retorno.getBlNumber() != null ? retorno.getBlNumber() : "--";
				String facturaProveedor = retorno.getNoFacturaPM() != null ? retorno.getNoFacturaPM() : "--";
				String incidenciaFactura = retorno.getIncidenciasEnFacturas() != null ? retorno.getIncidenciasEnFacturas() : "--";
						
				plantilla = plantilla.replaceAll("-FOLIO-", sar);
				plantilla = plantilla.replaceAll("-CONTENEDOR-", contenedor);
				plantilla = plantilla.replaceAll("-FACTURAPROVEEDOR-", facturaProveedor);
				plantilla = plantilla.replaceAll("INCFACTURA", incidenciaFactura);
				
				String[] correos = listEmails.split(";");
				
				//String[] splitDestinatarios = listdestinatarios.split(";");)
				//SendEmail.sendEmail(listEmails, "Envio Incidencias");
				MailUtils.enviaCorreo(correos, null, "Incidencias", "system@fung-rui.hk", plantilla.toString(), null);
				
			} catch (Exception e) {
				Log.info("Error  ",e);
				e.printStackTrace();
			}
		} else {
		
			Log.info("No se envia correo  ");
		}
	}

	@Override
	public String getEmails(String numIncidencia) {
		String listCorreos = ifacturacionDAO.getEmails(numIncidencia);
		return listCorreos;
	}

	@Override
	public List<CatStatusFacturacion> getStatusFacturacion(String options) {
		List<CatStatusFacturacion> listCodigoIncidencia = ifacturacionDAO.getListCatStatusFacturacion(options);
		return listCodigoIncidencia;
	}

	@Override
	public void updateStatusFacturacion(BeanFacturacion beanFacturacion, String userName) {
		int retorno = 0;

		long numeroIncidenciaStatus = beanFacturacion.getId();

		retorno = ifacturacionDAO.updateByFolioStatusIncidencia(beanFacturacion, userName);

		if (retorno > 0) {
			try {

				// SendEmail.sendEmail(listEmails,"Envio Incidencias");
			} catch (Exception e) {
				Log.info("Error  ", e);
				e.printStackTrace();
			}
		} else {
			log.info("No se envia correo----");
		}

	}

	@Override
	public List<EntregaTraficoModel> getListEntrgeaDocsFinales(String status, FiltroEntregaTrafico filtro) {
		// TODO Auto-generated method stub
		return ifacturacionDAO.getListEntrgeaDocsFinales(status, filtro);
	}
	

	@Override
	public void cancelacionComments(Facturacion filtro, String userName,Integer userProfile) throws Exception {
		String listEmails = getEmails("33");
		filtro.setStatus("" + CatStatusFactura.EN_PROCESO_DE_CANCELCACION_DE_FACTURA.getId());
		try {
			log.info("Inicia correo por parte de cancelacionComments por {}: ", userName);
			ResponseVO response = rabbitServicesImpl.cancelaFacturacion(filtro.getInvoiceNumber(),userName,userProfile);
			if (response.getTipoMensaje().equals("S")) {
				ifacturacionDAO.cancelComments(filtro, userName);
				try {
					SendEmail.sendEmailSolicitudCancelacion(listEmails, "Solicitud de Cancelaci�n - #"
							+ filtro.getInvoiceNumber() + " - " + filtro.getFacturaProvedor(), filtro);
				} catch (Exception ex) {
					log.info("No se pudo mandar correo a ::: {}", listEmails);
				}
			} else {
				throw new Exception("Error al enviar a cola de cancelacion " + response.getMensaje());
			}

		} catch (Exception e) {
			Log.info("Error  ", e);
			e.printStackTrace();
			throw e;
		}
	}

	@Override
	public List<CatCorreccionModel> getCatCorreccion() {
		// TODO Auto-generated method stub
		return ifacturacionDAO.getCatCorreccion();
	}

	@Override
	public void correccion(Facturacion filtro, String userName, String status) throws Exception {
		String listEmails = filtro.getEmails();
		BeanFacturacion datos = new BeanFacturacion();
		try {
			datos.setId(filtro.getId());
			filtro.setComentarios(filtro.getComentarios());
			int res = ifacturacionDAO.correccion(filtro, userName, "8");
			if (res != 0 ) {
				log.info("Inicia correo por parte de correccion por {}: ", userName);
				try {
					SendEmail.sendEmailSolicitudCorreccion(listEmails,
							"Solicitud de correccion - #" + filtro.getInvoiceNumber() + " - "
									+ filtro.getFacturaProvedor() + "-" + filtro.getDescripcionCorreccion(),
							filtro, "SDI Solicita la siguiente correccion de la factura (" + filtro.getInvoiceNumber()
									+ ") :" + filtro.getComentarios());
				} catch (Exception ex) {
					log.info("No se pudo mandar correo a ::: {}", listEmails);
				}			
			}else {
				log.info("No se actualizo registro ::: {}", filtro.getFolio());
			}

		} catch (Exception e) {
			Log.info("Error  ", e);
			e.printStackTrace();
			throw e;
		}
	}

	@Override
	public List<ControlEmbarqueModel> getListControlEmbarque(FiltroEntregaTrafico filtro) {
		// TODO Auto-generated method stub
		return ifacturacionDAO.getListControlEmbarque(filtro);
	}

	@Override
	public Integer enviaTrafico(Facturacion filtro) throws Exception {
		try {
			return ifacturacionDAO.enviaTrafico(filtro);
		} catch (Exception e) {
			Log.info("Error  ", e);
			e.printStackTrace();
			throw e;
		}
		
	}

	@Override
	public List<FacturacionReporte> getListReport(FacturacionReporte facturacionReporteFiltro) {
		List<FacturacionReporte> listFacturacionReport = ifacturacionDAO.getListReportDAO(facturacionReporteFiltro);	
	return listFacturacionReport;
	}

	@Override
	public List<EntregaTraficoModel> getListRechazadosTrafico(String status, FiltroEntregaTrafico filtro) {
		// TODO Auto-generated method stub
	 return ifacturacionDAO.getListRechazadosTrafico(status, filtro);
	}

	@Override
	public Boolean deleteFact(Integer idFact) throws Exception {
		return ifacturacionDAO.deleteFact(idFact);
		
	}

	@Override
	public Integer rejectIncidence(Facturacion filtro, String userName, String status) throws Exception {
		// TODO Auto-generated method stub
		return ifacturacionDAO.rejectIncidence(filtro, userName, status);
	}

	@Override
	public List<CatStatusIncidencias> getListCatIncidencias() {
		return ifacturacionDAO.getListCatIncidencias();
	}

//	@Override
//	public List<ReporteSemanalIncidencias> getReporteSemanalIncidencias() {
//		List<ReporteSemanalIncidencias> reporteSemanalIncidencias = ifacturacionDAO.getReporteSemanalIncidencias();
//
//		return reporteSemanalIncidencias;
//	}

	

//	@Override
//	public List<Facturacion> getListRejectd() {
//		
//	}
	
	
//	@Override
//	public List<Facturacion> getListRejectd() {
//		List<Facturacion> listFacturacionReject = ifacturacionDAO.getListRejectedDAO();
//		return listFacturacionReject;
//	}
}
