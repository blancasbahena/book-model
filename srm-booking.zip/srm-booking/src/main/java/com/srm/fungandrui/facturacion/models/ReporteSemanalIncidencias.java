package com.srm.fungandrui.facturacion.models;

import lombok.Data;

@Data
public class ReporteSemanalIncidencias {

	private String idIncidencia;
	private String descripcion;
	private String tiempoSolucion;
}
