package com.srm.fungandrui.facturacion.models;

import lombok.Data;

@Data
public class BeanFacturacion {
	
	private Long id;
	private String comentarios;
	private String incidencia;
	private Integer folio;
	private Boolean urgente;
	
	
	

}
