package com.srm.fungandrui.facturacion.models;

import lombok.Data;

@Data
public class CatStatusIncidencias {
	
	public Integer codigo;
	public String descripcion;

}
