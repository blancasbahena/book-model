package com.srm.fungandrui.imports.dto;

import lombok.Data;

@Data
public class ResponseReglasCuotaC {
	private Long sar;
	private String claveProducto;
	private boolean haveCuotaC;
}
