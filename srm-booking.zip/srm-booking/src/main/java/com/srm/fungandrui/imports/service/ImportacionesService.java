package com.srm.fungandrui.imports.service;

import com.srm.pli.ws.vo.ResponseImportsVO;





public interface ImportacionesService {
	public ResponseImportsVO downloadFileTopReglas() throws Exception;
}
