package com.srm.fungandrui.revocacion.queries;

public class QueriesRevocacion {

	
	public static final String SQL_CDI_SAR_DETALLE = new StringBuilder( "SELECT cs.po , cs.posicion ")
			.append(" from cdiSARDetalle cs where folio = ? ")
			.toString();
}
