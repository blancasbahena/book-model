package com.srm.fungandrui.lineamientos.service;

import java.sql.SQLException;
import java.util.List;

import com.srm.fungandrui.lineamientos.dto.GrdLineamientosAccionesDto;
import com.srm.fungandrui.lineamientos.dto.SarLineamientosDto;

public interface LineamientosService {
	
	List<SarLineamientosDto> getSars(Integer estatus)throws SQLException, ClassNotFoundException;
	Integer actualizarSar(GrdLineamientosAccionesDto dto) throws SQLException,ClassNotFoundException;
	Boolean validacionIdaBO(Integer folio, Integer fechaGrd,boolean verLogsLineacionIDA) throws SQLException, ClassNotFoundException;

}
