package com.srm.fungandrui.pis.service;

import java.sql.SQLException;
import java.text.ParseException;
import java.util.List;

import com.srm.fungandrui.pis.dto.FullProformaInvoiceDTO;
import com.srm.fungandrui.pis.dto.ProformaDetalleDTO;
import com.srm.fungandrui.pis.dto.ProformaDetalleHistoricoDTO;
import com.srm.fungandrui.pis.dto.ProformaInvoiceDTO;
import com.srm.fungandrui.pis.dto.ProformaInvoiceHistoricoDTO;
import com.srm.fungandrui.pis.dto.ProformaPdfDTO;
import com.srm.fungandrui.pis.dto.Respuesta;
import com.srm.fungandrui.pis.dto.SumaMontosPIDTO;

public interface PisService {

	ProformaInvoiceDTO creaProforma(FullProformaInvoiceDTO dto) throws ClassNotFoundException, SQLException;
	void creaProformaDetalle(ProformaDetalleDTO dto) throws ClassNotFoundException, SQLException;
	void creaHistoricoProforma(ProformaInvoiceHistoricoDTO dto) throws SQLException,ClassNotFoundException;
	void creaHistoricoProformaDetalle(ProformaDetalleHistoricoDTO dto) throws ClassNotFoundException, SQLException;
	void actualizarProforma(ProformaInvoiceDTO dto) throws SQLException,ClassNotFoundException;
	void actualizarProformaDetalle(ProformaDetalleDTO dto) throws ClassNotFoundException, SQLException;
	void editaProformaNumber(ProformaInvoiceDTO dto) throws ClassNotFoundException, SQLException;
	Respuesta updateFullInvoice(FullProformaInvoiceDTO dto);
	SumaMontosPIDTO obtenerMontosCantidadesModificadas(String po) throws ClassNotFoundException, SQLException;
	Respuesta agregarHistorico(FullProformaInvoiceDTO dto);
	public ProformaInvoiceHistoricoDTO convertObject(ProformaInvoiceDTO proformaInvoiceDTO);
	ProformaPdfDTO llenadoPdf(FullProformaInvoiceDTO dto) throws ParseException;
	public ProformaDetalleHistoricoDTO convertObjectHistorico(ProformaDetalleDTO objDetalle);
	boolean validarPesoVolumenPorContenedor(String contenedor, List<ProformaDetalleDTO> list);
	public ProformaPdfDTO llenadoPdfTodo(FullProformaInvoiceDTO dto) throws ParseException;
	
}
