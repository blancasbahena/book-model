package com.srm.fungandrui.sc.service;


import java.util.List;


public interface ControlMatrizService {

		public List<String>  getBloqueo(String proveedor);
		public List<String>  getAllPO();		 
		public List<String>  getPOsBYFolioSar(String folioSAR);	
		public int getDaysEtdBySupplier(int proveedor);
}
