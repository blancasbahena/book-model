package com.srm.fungandrui.facturacion.models;

import java.io.Serializable;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
public class ControlEmbarqueModel implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String naviera;
	private String shippingLine;
	private String buqueSalida;
	private String shipper;
	private String booking;
	private String bl;
	private String contenedor;
	private String conso;
	private String etd;
	private String eta;
	private String puertoCarga;
	private String puertoDescarga;
	private String lugarEntrega;
	private String folio;
	private String instruccionBl;
	private String semEtd;
	private String semEta;
	private String tipoCont;
	private String tipoEmb;
	private String statusDoc;
	private String fechaLiberacionSDI;
	private String sdiAnalist;
	private String trafficAnalist;
	private String customAgent;
	private String comment;
	private int status;
	private int number;
	
	@Override
	public boolean equals(Object obj)
    {
		if ( !(obj instanceof ControlEmbarqueModel)) return false;    
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        ControlEmbarqueModel other = (ControlEmbarqueModel) obj;
        if (!buqueSalida.equals(other.buqueSalida) && !contenedor.equals(other.contenedor) )
            return false;
        return true;
    }
	
}
