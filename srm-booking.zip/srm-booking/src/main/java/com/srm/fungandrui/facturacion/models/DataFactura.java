package com.srm.fungandrui.facturacion.models;

import lombok.Data;

@Data
public class DataFactura {

	private String folio;
	private String proveedor;
	private String contenedor;
	private String BL;
	private String po;
	private String posicion;
	private Double cantidad;
	private Double cantidadUnidadMedida;
	private String condicionPago;
	private Integer prioridad;
	private Integer material;
	private String shipmentType;
	private String pod;
	private Integer etd;
	private Integer etdFinal;
	private String facturaProveedor;
	private String paisOrigen;
	private String booking;
	private String analistaSDI;
	private String ordenSecundaria;
}
