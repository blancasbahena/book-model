package com.srm.fungandrui.facturacion.models;

import java.io.Serializable;

import lombok.Data;
import lombok.ToString;
@ToString
@Data
public class ItemErrorFactura implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5670325458160985860L;
	private String ebelp;
	private String ebeln;
	private String type;
	private String message;
	
}
