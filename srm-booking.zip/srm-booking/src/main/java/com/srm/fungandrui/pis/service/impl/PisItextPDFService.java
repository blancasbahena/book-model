package com.srm.fungandrui.pis.service.impl;

import java.io.FileOutputStream;
import java.io.IOException;
import java.net.MalformedURLException;

import com.lowagie.text.pdf.PdfContentByte;
import com.lowagie.text.pdf.PdfReader;
import com.lowagie.text.pdf.PdfStamper;
import com.lowagie.text.BadElementException;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Image;
import com.srm.fungandrui.pis.service.PisItextPDF;

public class PisItextPDFService implements PisItextPDF {

	@Override 
	public Image getImage(String imageFileName,float x, float y) 
			throws BadElementException, MalformedURLException, IOException {
    	Image logo = null;
    	logo = Image.getInstance(imageFileName);
        logo.setAlignment(Image.TOP);
        logo.scaleAbsolute(50, 50);
        logo.setAbsolutePosition(x,y);
        return logo;
    }
    //abajo-derecha
    //float x = reader.getPageSize(i).getWidth() -80;
    //float y = reader.getPageSize(i).getHeight() - 780;
	//abajo-izquierda
    //float x = reader.getPageSize(i).getWidth() -580;
    //float y = reader.getPageSize(i).getHeight() - 750;
	@Override
	public void createPdf(String rutaEntrada,String fileEntrada,String rutaSalida,String fileSalida,String imageFileName,
			float x, float y) 
			throws IOException, DocumentException
    {  
        PdfReader reader = new PdfReader(rutaEntrada+fileEntrada);
        FileOutputStream fileOuS=new FileOutputStream(rutaSalida+fileSalida);
        PdfStamper stamper = new PdfStamper(reader,fileOuS);
        for (int i = 1; i <= reader.getNumberOfPages(); i++) {
            PdfContentByte pdfContentByte = stamper.getOverContent(i);
            pdfContentByte.addImage(getImage(imageFileName,x,y));
        } 
        stamper.close(); 
    }

}
