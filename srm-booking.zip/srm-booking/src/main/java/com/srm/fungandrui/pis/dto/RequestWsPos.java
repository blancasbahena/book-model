package com.srm.fungandrui.pis.dto;

import java.io.Serializable;
import java.util.List;

import lombok.Data;

@Data
public class RequestWsPos implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String claveProveedor;
	private String fechaInicio;
	private String fechaFin;
	private String esLiberada;
	private String ordenCerrada;
	private List<String> pos;
	
}
