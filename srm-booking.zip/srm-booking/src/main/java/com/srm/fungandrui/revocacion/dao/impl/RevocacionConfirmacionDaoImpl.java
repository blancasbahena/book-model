package com.srm.fungandrui.revocacion.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.srm.fungandrui.revocacion.dao.RevocacionConfirmacionDao;
import com.srm.fungandrui.revocacion.entities.RevocacionConfirmacion;
import com.srm.fungandrui.revocacion.queries.QueriesRevocacion;
import com.srm.pli.db.ConexionDB;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Repository
public class RevocacionConfirmacionDaoImpl implements RevocacionConfirmacionDao {

	@Override
	public List<RevocacionConfirmacion> getListByFolio(String folio,String userName) {
		List<RevocacionConfirmacion> bloqueos = new ArrayList<RevocacionConfirmacion>();
		Connection conn = null;
		try {
			conn = ConexionDB.dameConexion();
			try (
				PreparedStatement pstmt = conn.prepareStatement(QueriesRevocacion.SQL_CDI_SAR_DETALLE)) {
				pstmt.setString(1, folio);
				ResultSet rs = pstmt.executeQuery();
				while (rs.next()) {
					RevocacionConfirmacion pago = rowMapper(rs, userName);
					bloqueos.add(pago);
				}
			} catch (SQLException eSQL) {
				log.error(getClass().getName() + eSQL.toString());
			}
		} catch (Exception e) {
			log.error(getClass().getName() + e.toString());
		} finally {
			ConexionDB.devolver(conn);
		}
		return bloqueos;
	}

	private RevocacionConfirmacion rowMapper(ResultSet rs, String userName) throws SQLException {
		RevocacionConfirmacion data = new RevocacionConfirmacion();
		data.setEbeln(rs.getString("po")!= null ? rs.getString("po").trim() : "-");
		data.setEbelp(rs.getString("posicion") != null ? rs.getString("posicion").trim() : "-");
		data.setNivelgm("");
		data.setNivelpo("");
		data.setUserName(userName);
		return data;
	}

}
