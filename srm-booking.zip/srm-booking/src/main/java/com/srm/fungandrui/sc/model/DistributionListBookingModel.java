package com.srm.fungandrui.sc.model;

import java.io.Serializable;
import java.util.List;

import com.truper.businessEntity.CompradoresBean;
import com.truper.businessEntity.PlaneadorBean;
import com.truper.businessEntity.UnidadNegocio;

import lombok.Getter;
import lombok.Setter;
@Getter
@Setter
public class DistributionListBookingModel implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	private UnidadNegocio Director;
	private List<CompradoresBean> Gerentes;
	private List<CompradoresBean> Compradores;
	private PlaneadorBean Planeador;
	private String[] MailsDirectos;
	private String[] MAIL_GRUPO_AUT_BOOKING_GERENTES;
	private String[] MAILCC_GRUPO_AUT_BOOKING_CC;
}
