package com.srm.fungandrui.facturacion.dao;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import com.srm.fungandrui.facturacion.models.BeanFacturacion;
import com.srm.fungandrui.facturacion.models.CatCorreccionModel;
import com.srm.fungandrui.facturacion.models.CatStatusFacturacion;
import com.srm.fungandrui.facturacion.models.CatStatusIncidencias;
import com.srm.fungandrui.facturacion.models.ControlEmbarqueModel;
import com.srm.fungandrui.facturacion.models.DataFactura;
import com.srm.fungandrui.facturacion.models.DataToSIFE;
import com.srm.fungandrui.facturacion.models.EntregaTraficoModel;
import com.srm.fungandrui.facturacion.models.Facturacion;
import com.srm.fungandrui.facturacion.models.FacturacionReporte;
import com.srm.fungandrui.facturacion.models.ItemFactura;
import com.srm.fungandrui.facturacion.models.ReporteSemanalIncidencias;
import com.srm.fungandrui.sc.model.FiltroEntregaTrafico;

public interface IFacturacionDAO {

	public List<Facturacion> listarFacturacion();

	public Long saveFacturaPeticion(Facturacion factura);

	public List<DataFactura> getDataFacturacionBySar(String SAR);

	public List<DataFactura> getDataFacturacionBySarAndCondicionPago(String sar, String codicionPago, Connection con);
	
	public List<DataFactura> getDataRefacturacionById(Long id, Connection con);

	public List<Facturacion> getByFilterDAO(Facturacion filtro);

	public List<Facturacion> getByFilterRejectedDAO(Facturacion filtro);

	//public List<Facturacion> getListRejectedDAO();

	public Facturacion updateByFolio(BeanFacturacion params, String userName);

	public Integer updateInfoParcialFactura(Facturacion factura);

	public Integer updateInfoTotalFactura(Facturacion factura);

	public Integer updateFacturaError(Facturacion factura,Boolean procesaEstatsPeticiones ,Boolean error,Boolean peticionCuarentaYTres, Boolean peticionDieciNueve);

	public Facturacion cancelarFactura(Facturacion factura, Connection con);

	public List<CatStatusFacturacion> getListCatStatusFacturacion(String options);

	public String getEmails(String numIncidencia);

	public Facturacion UpdateStatusFactura(Facturacion factura, Connection con)
			throws ClassNotFoundException, SQLException;

	public Integer updateByFolioStatusIncidencia(BeanFacturacion params, String userName);

	public List<ItemFactura> getPosByFolio(String folio);

	public List<EntregaTraficoModel> getListEntrgeaDocsFinales(String status, FiltroEntregaTrafico filtro);
	
	public List<ControlEmbarqueModel> getListControlEmbarque(FiltroEntregaTrafico filtro);
	
	public Integer cancelComments(Facturacion factura, String user);

	public Integer setProcesadoSIFE(Facturacion factura, Long idTipoSolicitud);

	public List<CatCorreccionModel> getCatCorreccion();
	
	public Integer correccion(Facturacion factura, String user, String status);

	public Integer enviaTrafico(Facturacion factura);

	public DataToSIFE getDataFacturacionByNoFacturaPm(Facturacion factura);
	
	public Integer updateStatusById(Facturacion factura, boolean peticionCuarentaYTres, boolean peticionDieciNueve);

	public Integer setIncidenciaById(Facturacion factura,Connection con );
	
	public Integer updateFacturaPODetalleFacturacion(Long id, String facturaPM);
	

	public List<FacturacionReporte> getListReportDAO(FacturacionReporte facturacionReporteFiltro);

	public Integer ActualizaStatusSIFE(Facturacion factura);
	
	public List<ReporteSemanalIncidencias> getReporteSemanalIncidencias ();
	
	public Integer ActualizaAnalistaSDI(DataFactura data);
	
	public Facturacion getFolioByFolioSife(Long FolioSIFE);

	List<EntregaTraficoModel> getListRechazadosTrafico(String status, FiltroEntregaTrafico filtro);
	
	public boolean deleteFact(Integer idFact);
	
	public Integer rejectIncidence(Facturacion filtro, String userName, String status) throws Exception;
	
	public List<Integer> getMaterialBySarAndFactura(String sar, String noFacturaPM);

	public boolean borraIncidencia(Facturacion factura, Connection con) throws ClassNotFoundException, SQLException; 


	public boolean setStatusFactura(Facturacion factura, Connection con)
			throws ClassNotFoundException, SQLException;
	
	public String getNumerosDeDocumentos( Facturacion factura );
	
	
	public Long getEstatusFacturaSife(  Long id, boolean peticionCuarentaYTres, boolean peticionDieciNueve);
	
	public DataToSIFE getDataFacturacionByIdFacturacion(Facturacion factura);
	
	public Integer deletePODetalle( Long idFacturacion  );
	
	public List<Facturacion> getFacturasBySAR(Integer SAR);
	
	
	public List<CatStatusIncidencias> getListCatIncidencias();
	
	public boolean setStatusFacturacionByFolio(Facturacion factura,Connection con);
	
	String getNumerosDeDocumentosBySarAndInvoide(Facturacion factura);
}

	

	