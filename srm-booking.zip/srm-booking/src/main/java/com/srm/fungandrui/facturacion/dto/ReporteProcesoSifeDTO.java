package com.srm.fungandrui.facturacion.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class ReporteProcesoSifeDTO {
	private String sar;
	private String diaFacturacion;
	private String turnoDeentrega;
	private String numeroFactura;
	private String FolioSIFE;
	private String numeroProveedor;
	private String nombreProveedor;
	private String numeroDocumentoSap;
	private String numeroParceMobil;
	private String FolioSIFE43;
	private String importeUsd;
	private String auxkey;
	private String fechaSife;
}
