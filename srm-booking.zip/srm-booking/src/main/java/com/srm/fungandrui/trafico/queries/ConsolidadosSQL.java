package com.srm.fungandrui.trafico.queries;

public class ConsolidadosSQL {
	public static final String ALL_CONSOLIDATED_COMPLETE;
	public static final String ALL_SELECT_DOCUMENTS;
	public static final String ALL_SELECT;
	public static final String VALIDATE_DOCUMENTS_CONSOLIDADOS;
	public static final String GET_CONSOLIDADOS;

	static {
		ALL_CONSOLIDATED_COMPLETE = allConsolidatedComplete().toString();
		ALL_SELECT_DOCUMENTS = allSelectDocuments().toString();
		ALL_SELECT = SelectDocuments().toString();
		VALIDATE_DOCUMENTS_CONSOLIDADOS = validateConsolidadoDocuments().toString();
		GET_CONSOLIDADOS = getConsolidados().toString();
	}
	
	
	public static StringBuilder getConsolidados() {
		StringBuilder sql = new StringBuilder();
		sql.append(" select cdi.folioConsolidado,cdi.folio, cdi.proveedor, cdi.booking, f.id  from cdisar cdi inner join ");
		sql.append(" facturacion f on cdi.folio= f.sar where cdi.folioConsolidado in ($$FOLIOS$$)");
		return sql;
	}
	
	public static StringBuilder validateConsolidadoDocuments() {
		StringBuilder sql = new StringBuilder();
		sql.append("select   ");
		sql.append("case when count(  ");
		sql.append("(case when f.para_envio_a_trafico is null or f.para_envio_a_trafico=0  or f.id is null then 'false' else  ");
		sql.append("(case when f.esSpecialties =1 and f.para_envio_a_trafico =1 then 'true' else  (case when f.numero_factura_pm is null then 'false' else 'true' end) end) end)  ");
		sql.append(") > 0 then 'false' else 'true' end  as result  ");
		sql.append("from cdisar as s left join facturacion as f   ");
		sql.append("on s.folio = f.sar   ");
		sql.append("where s.folio in  ($$FOLIOS$$)  ");
		sql.append("and (case when (f.para_envio_a_trafico is null or f.para_envio_a_trafico=0)  or f.id is null then 'false' else   ");
		sql.append("(case when f.esSpecialties =1 and f.para_envio_a_trafico =1 then 'true' else  (case when f.numero_factura_pm is null then 'false' else 'true' end) end)   ");
		sql.append(" end) = 'false'");
		return sql;
	}

	
/*
	public static StringBuilder validateConsolidadoDocuments() {
		StringBuilder sql = new StringBuilder();
		sql.append(
				" select case when count((case when (f.para_envio_a_trafico is null or f.para_envio_a_trafico=0) or  f.numero_factura_pm is null or f.id is null then 'false' else 'true' end))  > 0 then 'false' else 'true' end  as result");
		sql.append(" from cdisar as s left join facturacion as f ");
		sql.append(" on s.folio = f.sar ");
		sql.append(
				" where s.folio in ($$FOLIOS$$) and (case when (f.para_envio_a_trafico is null or f.para_envio_a_trafico=0) or  f.numero_factura_pm is null or f.id is null then 'false' else 'true' end) = 'false' ");
		return sql;
	}
*/

	public static StringBuilder SelectDocuments() {
		StringBuilder sql = new StringBuilder();
		sql.append(" select s.contenedor,nav.clave,s.eta, pod.clave,s.proveedor,s.booking,f.sar,s.prioridad , ");
		sql.append(" s.esAereo AS shipment_type,s.BL, f.observaciones_trafico from facturacion as f ");
		sql.append(" left join cdiSar as s on s.folio = f.sar ");
		sql.append(" left join cdiNavieras as nav on nav.clave = s.naviera ");
		sql.append(" left join cdiPuertosOrigen as pod on pod.clave = s.puertoSalida ");
		sql.append(" where s.contenedor = ? and id = ? ");
		return sql;
	}

	public static StringBuilder allSelectDocuments() {
		StringBuilder sql = new StringBuilder();
		sql.append(
				" select s.contenedor,nav.clave,s.eta, pod.clave ,s.proveedor,s.booking,f.sar,s.prioridad, s.esAereo AS shipment_type,s.BL, f.observaciones_trafico ,");
		sql.append(
				" (select count(*) as total from facturacion left join cdiSar as s on s.folio = f.sar  where s.contenedor = ? and  factura_status in $$STATUS$$ and (para_envio_a_trafico is null or para_envio_a_trafico = 0) ");
		sql.append(" group by sar) as total from facturacion as f ");
		sql.append(" left join cdiSar as s on s.folio = f.sar ");
		sql.append(" left join cdiNavieras as nav on nav.clave = s.naviera ");
		sql.append(" left join cdiPuertosOrigen as pod on pod.clave = s.puertoSalida ");
		sql.append(" where s.contenedor = ? and id = ? and  factura_status in $$STATUS$$ ");
		return sql;
	}

	public static StringBuilder allConsolidatedComplete() {
		StringBuilder sql = new StringBuilder();

		sql.append(
				"  DECLARE @booking VARCHAR(100) , @proveedor VARCHAR(20) , @folioconsolidado VARCHAR(20)                                                               ");
		sql.append(
				"  SET @proveedor  = ?                                                                                                                            ");
		sql.append(
				"  SET @booking = ?                                                                                                                            ");
		sql.append(
				"  SET @folioconsolidado  =  (SELECT   DISTINCT( sar.folioconsolidado)  FROM CDISAR sar where  sar.booking = @booking and sar.proveedor = @proveedor) ");
		sql.append("  if(@folioconsolidado is not null) ");
		sql.append(
				"  (SELECT  'consolidado' as result ,s.folioConsolidado, s.transporte , s.bl, s.prioridad , s.folio ,s.proveedor, s.booking , s.contenedor, s.tipocontenedor , s.naviera , s.eta , s.puertoSalida , s.puertoDescarga, ce.aa, ce.tAnalist, ce.comment  FROM CDISAR s left join cdiControlEmbarque ce on ce.folio = s.folio WHERE s.proveedor = @proveedor  and s.booking = @booking  ) ");
		sql.append("  else ");
		sql.append(
				"  (SELECT  'noConsolidado' as result ,s.folioConsolidado,  s.transporte , s.bl, s.prioridad , s.folio ,s.proveedor, s.booking , s.contenedor, s.tipocontenedor , s.naviera , s.eta , s.puertoSalida , s.puertoDescarga, ce.aa, ce.tAnalist, ce.comment   FROM CDISAR s left join cdiControlEmbarque ce on ce.folio = s.folio WHERE s.proveedor = @proveedor  and s.booking = @booking  ) ");

		return sql;
	}

}
