package com.srm.fungandrui.imports.dto;

import java.util.Iterator;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;

@AllArgsConstructor
public class RequestSarDetalle {

	private long idSar;
	private String contenedor;
	private String booking;
	private List<String> clavesProducto;
	
	
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("{\"idSar\":\"");
		builder.append(idSar);
		builder.append("\",\"contenedor\":\"");
		builder.append(contenedor);
		builder.append("\",\"booking\":\"");
		builder.append(booking);
		builder.append("\"");
		
		if (clavesProducto != null) {
			builder.append(",\"clavesProducto\":[");
			for (int i = 0; i < clavesProducto.size(); i++) {
				builder.append("\"" + clavesProducto.get(i) +"\"");
				if (i < clavesProducto.size() - 1 ) {
					builder.append(",");
				}
			}
			builder.append("]");
		}
		builder.append("}");
		return builder.toString();
	}
	
	

}
