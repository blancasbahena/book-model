package com.srm.fungandrui.lineamientos.service;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Map;

import com.srm.pli.bo.SarBO;
import com.srm.pli.bo.SarDetalleBO;
import com.truper.businessEntity.UserBean;
public interface EnvioCorreoLineamientosBOService {
	void enviarCorreoLineaminetosBO(UserBean usuario,SarBO sar,
			ArrayList<SarDetalleBO> listaDet,Map<String, Object> datosMail,boolean reject,String[] correosBU)  throws ParseException;
}
