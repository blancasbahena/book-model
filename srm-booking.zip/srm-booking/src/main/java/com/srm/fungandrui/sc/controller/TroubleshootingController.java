package com.srm.fungandrui.sc.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.srm.fungandrui.sc.service.TSREnvioMailsService;

import lombok.extern.slf4j.Slf4j;
@Slf4j
@Controller
@RequestMapping("/troubleshooting")
public class TroubleshootingController {
	
	@Autowired
	TSREnvioMailsService service;
	
	@PostMapping(path="/mails")
	public void enviaMailsTSRPendientes() {
		log.info("Iniciando servicio TSR");
		service.enviarCorreosTSRPendientes();
	}
	
}
