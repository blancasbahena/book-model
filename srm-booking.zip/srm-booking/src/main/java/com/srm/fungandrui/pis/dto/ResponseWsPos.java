package com.srm.fungandrui.pis.dto;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
@AllArgsConstructor
public class ResponseWsPos {
	private String mensaje;
	private String tipoMensaje;
	private String folio;
	private String descripcionError;
	private Map<String, List<ProformaPisDetalleOrden>> data;
	
	public ResponseWsPos(String tipo, String msg, String descError, String nombreObjeto, List<ProformaPisDetalleOrden> data) {
		this.mensaje = msg;
		this.tipoMensaje = tipo;
		this.descripcionError = descError;
		this.data = new HashMap<String, List<ProformaPisDetalleOrden>>();
		this.data.put(nombreObjeto, data);
		this.folio = UUID.randomUUID().toString();
	}
}
