package com.srm.fungandrui.pis.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ResponseAuthWsPos {
	private String mensaje;
	private String tipoMensaje;
	private String token;	
}
