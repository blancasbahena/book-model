package com.srm.app.response.vo;

import lombok.Setter;
import java.util.Set;
import com.srm.pli.bo.ConsultaDatosCdiSARBean;
import lombok.Getter;

@Getter
@Setter
public class ResponseEmbarqueDirectosVO extends ResponseVO
{
	private static final long serialVersionUID = 1L;
	Set<ConsultaDatosCdiSARBean> consultaDatosCdiSARBeans;	
}
