package com.srm.app.response.vo;

import java.io.Serializable;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ResponseVO implements Serializable
{
	private static final long serialVersionUID = 1L;
	private String tipoMensaje;
	private String mensaje;
}
