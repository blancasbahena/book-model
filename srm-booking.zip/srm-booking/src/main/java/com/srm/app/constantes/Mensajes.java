package com.srm.app.constantes;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum Mensajes
{
	TIPO_EXITO("S"),
	TIPO_WARNING("W"),
	TIPO_ERROR("E"),
	MSG_ERROR("Hubo un error al ejecutar la Operacion."),
	MSG_EXITO("Proceso ejecutado correctamente."), 
	MSG_WARINIG("No se encontraron resultados."),
	MSG_ERROR_WS_NO_DISPONIBLE("The service is not available.");
	private String mensaje;
}
