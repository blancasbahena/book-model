package com.srm.pli.bo;

public class BeanFiltroProveedorFolioPo {

	private String proveedor;
	private Integer folio;
	private String po;

	public String getProveedor() {
		return proveedor;
	}

	public void setProveedor(String proveedor) {
		this.proveedor = proveedor;
	}

	public Integer getFolio() {
		return folio;
	}

	public void setFolio(Integer folio) {
		this.folio = folio;
	}

	public String getPo() {
		return po;
	}

	public void setPo(String po) {
		this.po = po;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("BeanFiltroProveedorFolioPo [getProveedor=");
		builder.append(getProveedor());
		builder.append(", getFolio=");
		builder.append(getFolio());
		builder.append(", getPo=");
		builder.append(getPo());
		builder.append("]");
		return builder.toString();
	}
}