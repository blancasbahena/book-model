package com.srm.pli.services;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.srm.fungandrui.facturacion.dto.ReporteProcesoSifeDTO;
import com.srm.pli.utils.FuncionesComunesPLI;
import com.srm.pli.utils.PropertiesDb;
import com.truper.businessEntity.ImportacionesProveedoresBean;
public class ExcelWriter {
	private static final Logger log = LogManager.getRootLogger();
	private static String[] columns = 
		{"Folio F&R","Dia de facturaci�n", "Turno de entrega", "Numero de Factura","Folio SIFE", "Numero de Proveedor", "Nombre de Proveedor",
		"Numero documento SAP", "Numero Factura PM a Truper","Factura SIFE PM" ,"Importe USD", "Identificacion factura Handling","Fecha procesado SIFE"};
	Integer HANDLING_CHARGE = PropertiesDb.getInstance().getInteger("srm.facturacion.handling.charge");
    public File getReporteSife(List<ReporteProcesoSifeDTO> records,String nombreArchivo,String nombreHoja,String path) throws IOException, InvalidFormatException {
        Workbook workbook = new XSSFWorkbook(); 
        Sheet sheet = workbook.createSheet(nombreHoja);
        Font headerFont = workbook.createFont();
        CreationHelper createHelper = workbook.getCreationHelper();
        headerFont.setBold(true);
        headerFont.setFontHeightInPoints((short) 12);
        headerFont.setColor(IndexedColors.BLACK.getIndex());
        CellStyle headerCellStyle = workbook.createCellStyle();
        headerCellStyle.setFont(headerFont);
        Row headerRow = sheet.createRow(0);
        for(int i = 0; i < columns.length; i++) {
            Cell cell = headerRow.createCell(i);
            cell.setCellValue(columns[i]);
            try {
				cell.setCellValue(new String(columns[i].getBytes(), "UTF-8"));
			} catch (Exception e) { 
				cell.setCellValue(columns[i]);
			}
            cell.setCellStyle(headerCellStyle);
        } // Create Cell Style for formatting Date
        CellStyle dateCellStyle = workbook.createCellStyle();
        dateCellStyle.setDataFormat(createHelper.createDataFormat().getFormat("dd-MM-yyyy"));
        // Create Other rows and cells with employees data
        int rowNum = 1;
        for(ReporteProcesoSifeDTO rec: records) {
            Row row = sheet.createRow(rowNum++);
            row.createCell(0).setCellValue(rec.getSar());
            row.createCell(1).setCellValue(rec.getDiaFacturacion());
            row.createCell(2).setCellValue(rec.getTurnoDeentrega());
            row.createCell(3).setCellValue(rec.getNumeroFactura());
            row.createCell(4).setCellValue(rec.getFolioSIFE());
            row.createCell(5).setCellValue(rec.getNumeroProveedor());
            if(rec.getNumeroProveedor()!=null) {
            ImportacionesProveedoresBean bean_prov_client = FuncionesComunesPLI.getProveedor(rec.getNumeroProveedor());
				if( bean_prov_client != null &&  bean_prov_client.getNombreProveedor() != null ) {
					row.createCell(6).setCellValue(bean_prov_client.getNombreProveedor());
				}
			}
            row.createCell(7).setCellValue(rec.getNumeroDocumentoSap());
            row.createCell(8).setCellValue(rec.getNumeroParceMobil());
            row.createCell(9).setCellValue(rec.getFolioSIFE43());
            row.createCell(10).setCellValue(rec.getImporteUsd());
            row.createCell(11).setCellValue(rec.getAuxkey());
            row.createCell(12).setCellValue(rec.getFechaSife());
        }
        for(int i = 0; i < columns.length; i++) {
            sheet.autoSizeColumn(i);
        }
        FileOutputStream  fileOut = new FileOutputStream(path + nombreArchivo); 
        workbook.write(fileOut);                        
        fileOut.close();
        workbook.close();
        log.info("Reporte generado :: {} ",path + nombreArchivo) ;
        return new File(path + nombreArchivo);
        
    }
}
