package com.srm.pli.constants;

public class DataParametrosExcelConstants
{
	public static final String PATH_REPORTES_CHANGE_REQUEST = "C:\\arch\\reportes\\booking\\request_changes";
	public static final String PATH_REPORTES_KPIS = "C:\\arch\\reportes\\kpis";
	
	public static final String[] HEADERS_EXCEL_TITLE_IDAS_PENDIENTES = new String[] {"FOLIO", "ETD NUEVO", "CONSOLIDADO",  "ORIGEN VISTA"};
	public static final String[] HEADERS_EXCEL_TITLE_REQUEST_CHANGES = 
			new String[] {"FECHA SOLICITADO", "FECHA APROBADO", "FECHA RECHAZADO", "REASON", "SAR", "SUPPLIER",  "BOOKING", "LAST ETD REGISTERED ON SAR", "NUM DE CAMBIOS DE ETD REGISTRADO", "CURRENT ETD REGISTERED BY TB",
						"LAST ETA REGISTERED ON SAR", "CURRENT ETA REGISTERED", "CONTENEDOR", "BL", "VESSEL", "VOYAGE", "POL", "POD", "TYPE","TEUS", "DIFERENCIA EN ETD ASIGNADO",
						"CARRIER", "WEEK"};
	public static final String APROBADO_RM = "aprobado_rm";
	public static final String RECHAZADO_RM = "rechazado_rm";
	
	public static final String[] HEADERS_EXCEL_TITLE_CAMBIOS_X_SEMANA = new String[] {"WEEK", "DELAY SHIPPER", "DELAY CARRIER", "ROLL SHIPPER", "ROLL CARRIER", "ADVANCE SHIPPER", 
			"ADVANCE CARRIER", "2 OPTION SHIPPER", "DELAY WITHOUT NEW ETD BY SHIPPER", "DELAY WITHOUT NEW ETD BY CARRIER"};
	
	public static final String[] HEADERS_EXCEL_TITLE_CAMBIOS_X_NAVIERA_PROVEEDOR = new String[] {"DELAY", "ADVANCE", "ROLL", "DELAY WITHOUT NEW ETD BY"};
	public static final String[] HEADERS_EXCEL_TITLE_CAMBIOS_X_TOP_DE_PUERTOS_X_SEMANA = new String[] {"WEEK", "NOMBRE PUERTO", "DELAY", "ADVANCE", "ROLL", "2 OPTION CARRIER"};
	
	public static final String TITLE_CAMBIOS_X_SEMANA = "TABLA. CAMBIOS POR SEMANA";
	public static final String TITLE_CAMBIOS_X_NAVIERA_PROVEEDOR = "TABLA. CAMBIOS POR NAVIERA PROVEEDOR";
	public static final String TITLE_VOL_DE_CONTENEDOR_X_NAVIERA_X_SEMANA = "TABLA. VOLUMEN DE CONTENEDORES POR NAVIERA POR SEMANA";
	public static final String TITLE_VOL_DE_CONTENEDOR_X_TOP_PUERTOS_X_SEMANA = "TABLA. VOLUMEN DE CONTENEDORES POR TOP PUERTOS POR SEMANA";
	public static final String TITLE_CAMBIOS_POR_TOP_DE_PUERTOS_X_SEMANA = "TABLA. CAMBIOS POR TOP DE PUERTOS POR SEMANA";
	
	public static final Integer REPORTE_KPIS_CAMBIOS_X_SEMANA = 1;
	public static final Integer REPORTE_KPIS_CAMBIOS_X_NAVIERA_PROVEEDOR = 2;
	public static final Integer REPORTE_KPIS_VOLUMEN_DE_CONTENEDORES_X_NAVIERA_X_SEMANA = 3;
	public static final Integer REPORTE_KPIS_CAMBIOS_X_TOP_N_DE_PUERTOS = 4;
	public static final Integer REPORTE_KPIS_VOLUMEN_DE_CONTENEDORES_X_TOP_PUERTOS_X_SEMANA = 5;
	public static final String SEMANA = "SEMANA_";
	
	public static final String DELAY_SHIPPER = "DELAY SHIPPER";
	public static final String DELAY_CARRIER = "DELAY CARRIER";
	public static final String ROLL_SHIPPER = "ROLL SHIPPER";
	public static final String ROLL_CARRIER = "ROLL CARRIER";
	public static final String ADVANCE_SHIPPER = "ADVANCE SHIPPER";
	public static final String ADVANCE_CARRIER = "ADVANCE CARRIER";
	public static final String SECOND_OPCION_CARRIER = "2 OPTION CARRIER";
	public static final String DELAY_WITHOUT_NEW_ETD_BY_SHIPPER = "DELAY WITHOUT NEW ETD BY SHIPPER";
	public static final String DELAY_WITHOUT_NEW_ETD_BY_CARRIER = "DELAY WITHOUT NEW ETD BY CARRIER";
	
	public static final String KEY_CARRIER = "CARRIER";
	public static final String KEY_SHIPPER = "SHIPPER";
	public static final String HEADER_WEEK_ETD = "WEEK(ETD)";
	public static final String HEADER_TEUS = "TEUS";
	public static final String HEADER_CNTRS = "CNTRS";
	public static final String HEADER_TOTAL = "TOTAL";
	public static final String TOTAL_TEUS = "TOTAL_TEUS";
	public static final String TOTAL_CNTRS = "TOTAL_CNTRS";
	
	public static final String OTHER_CARRIER = "OTHER CARRIER";
	
	public static final String[] HEADERS_EXCEL_TITLE_CONTROL_EMB_PENDIENTES = new String[] {"STATUS DOCS", "NAVIERA", "ETD", "ETA POL", "CONTAINER", "BOOKING", "UNIDAD DE NEGOCIO", "FOLIO", "PROOVEDOR"};
	public static final String[] HEADERS_EXCEL_TITLE_CONTROL_EMB_PENDEINTES_ETA = new String[] {"STATUS DOCS", "NAVIERA", "ETA POL", "CONTAINER", "INV# F�BRICA", "FACTURA PM", "FECHA DE CARGA DEL DOC EN F&R POR PARTE DEL PROVEEDOR", "ANALISTA DE SDI", "FOLIO/ FOLIOS", "TOTAL"};
	public static final String PENDING = "SIN DOCUMENTOS";
}
