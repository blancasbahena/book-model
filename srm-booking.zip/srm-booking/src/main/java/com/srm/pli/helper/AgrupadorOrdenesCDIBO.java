package com.srm.pli.helper;

import java.util.ArrayList;

import com.srm.pli.bo.OrdenCdiBO;

public class AgrupadorOrdenesCDIBO {
	
	private String numeroOrden;
	ArrayList<OrdenCdiBO> ordenes;
	private int fechaUltimaConfirmacion;
	///Si tiene null, no pinto icono si tiene false, en gris si tiene en 
	private Boolean tieneCambioETD = null;
	private Boolean redFlagOn = null;
	
	//private String fechaUltimaConfirmacionFormat;
	
	/**
	 * constructor para poder convertir despues este objeto a Json por medio de GSON
	 * @param bean
	 */
	public AgrupadorOrdenesCDIBO(AgrupadorOrdenesCDIBO bean){
		numeroOrden 			= bean.getNumeroOrden();
		ordenes   				= bean.getOrdenes();
		fechaUltimaConfirmacion	= bean.getFechaUltimaConfirmacion();
		tieneCambioETD			= bean.getTieneCambioETD();
		redFlagOn				= bean.getRedFlagOn();
	}
	
	public AgrupadorOrdenesCDIBO(String numeroOrden, Boolean cambioETD, Boolean redFlagOn){
		this.numeroOrden = numeroOrden;
		if(cambioETD != null  ){
			this.tieneCambioETD = cambioETD;
		}
		if(redFlagOn != null) {
			this.redFlagOn = redFlagOn;
		}
		ordenes = new ArrayList<OrdenCdiBO>();
	}
		
	public String getNumeroOrden() {
		return numeroOrden;
	}
	public void setNumeroOrden(String numeroOrden) {
		this.numeroOrden = numeroOrden;
	}
	public ArrayList<OrdenCdiBO> getOrdenes() {
		return ordenes;
	}
	public void setOrdenes(ArrayList<OrdenCdiBO> ordenes) {
		this.ordenes = ordenes;
	}	
	public int getFechaUltimaConfirmacion(){
		return fechaUltimaConfirmacion;
	}	
	public Boolean getTieneCambioETD() {
		return tieneCambioETD;
	}

	public void setTieneCambioETD(Boolean tieneCambioETD) {
		this.tieneCambioETD = tieneCambioETD;
	}

	
	/**
	 * @return the redFlagOn
	 */
	public Boolean getRedFlagOn() {
		return redFlagOn;
	}

	/**
	 * @param redFlagOn the redFlagOn to set
	 */
	public void setRedFlagOn(Boolean redFlagOn) {
		this.redFlagOn = redFlagOn;
	}

	public void setFechaUltimaConfirmacion(int fechaUltimaConfirmacion) {
		this.fechaUltimaConfirmacion = fechaUltimaConfirmacion;
	}

	public ArrayList<OrdenCdiBO> getOrdenesBO(){
		ArrayList<OrdenCdiBO> lista = new ArrayList<OrdenCdiBO>();
		for(OrdenCdiBO tmp : ordenes){
			lista.add(new OrdenCdiBO(tmp.getOrden(), tmp.getPosicion(), 
					tmp.getMaterial(), tmp.getCantidad(), tmp.getCentro(), 
					tmp.getPlaneador(), tmp.getContenedor(), tmp.getCliente(),
					tmp.getTieneCambioETD(), tmp.getRedFlagOn()));
		}
		return lista;
	}
		
	public void agregaOrden(OrdenCdiBO orden){
		ordenes.add(orden);
		if(orden.getFechaUltimaConfirmacion() > fechaUltimaConfirmacion && orden.getRemanente() > 0){
			fechaUltimaConfirmacion = orden.getFechaUltimaConfirmacion();
		}

		if(tieneCambioETD == null || !tieneCambioETD){
			tieneCambioETD = orden.getTieneCambioETD();
		}
		
		if(redFlagOn == null || !redFlagOn){
			redFlagOn = orden.getRedFlagOn();
		}
		
	}
	
}
