package com.srm.pli.bo;

import java.util.Date;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class FasesSARBO {
	
	private Integer folio;
	private Integer folioConsolidado;
	private Integer status;

	private Boolean needAuthImpDir;
	private Boolean aprobadoDirImportaciones;
	private Boolean aprobadoConfMngr;
	private Boolean consolidado;
	private String booking;
	private Boolean enRevisionConfirmFinal;
	private Date fechaConfirmacionFinal;
	private Boolean aprobadoProveedor;
	private Integer versionSetDocumentos;
	private String proveedor;
	private Boolean aprobadoSDI;
	private String referenceNumber;
	private Boolean existeRegistroControl;
	private Boolean existeRegistroReference;
	private Integer porcentajeAvance;
	private String leyenda;
	private Boolean preciosRevisados;
	
}
