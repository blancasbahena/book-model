package com.srm.pli.dao;

import static com.srm.pli.dao.sql.DocumentosSql.SELECT_SET_DOCUMENTOS;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import javax.servlet.ServletException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.srm.pli.bo.SarBO;
import com.srm.pli.constants.ConsultasConstants;
import com.srm.pli.constants.SRMManagerConstants;
import com.srm.pli.db.ConexionDB;
import com.truper.bpm.enums.DocumentoSetEnum;
import com.truper.businessEntity.BeanBL;
import com.truper.businessEntity.BeanDocumentoSet;
import com.truper.businessEntity.BeanDocumentosSDI;
import com.truper.businessEntity.BeanFactura;
import com.truper.businessEntity.BeanLetoniano;
import com.truper.businessEntity.BeanPL;
import com.truper.businessEntity.pojo.BuscaDocumentoPojo;
import com.truper.utils.date.UtilsFechas;
import com.truper.utils.string.UtilsString;

public class DocumentosDao {

	private static final DocumentosDao instance = new DocumentosDao();
	private static final Logger log = LogManager.getRootLogger();

	public DocumentosDao() {
	}

	public static DocumentosDao getInstance() {
		return instance;
	}

	public ArrayList<BeanDocumentoSet> selectSetDeDocumentos(BuscaDocumentoPojo buscar) {
		ArrayList<BeanDocumentoSet> resultado = null;
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();
			try (PreparedStatement pst = con.prepareStatement(SELECT_SET_DOCUMENTOS)) {
				pst.setString(1, buscar.getProveedor());
				pst.setString(2, buscar.getBooking());
				try (ResultSet rs = pst.executeQuery()) {
					resultado = new ArrayList<>();
					BeanDocumentoSet doc = null;
					while (rs.next()) {
						String tipo_s = rs.getString("Tipo");
						DocumentoSetEnum tipo = DocumentoSetEnum.valueOf(tipo_s);
						String rutaArchivo = rs.getString("rutaArchivo");
						String nombre = rs.getString("nombre");
						String condicionPago = rs.getString("condicionPago");
						doc = new BeanDocumentoSet(tipo, rutaArchivo);
						if (UtilsString.isStringValida(nombre))
							doc.setNombre(nombre);
						if (UtilsString.isStringValida(condicionPago))
							doc.setCondicionPago(condicionPago);
						resultado.add(doc);
					}
				}
			}
		} catch (SQLException sqle) {
			sqle.printStackTrace();
			log.error("BuscaDocumentoPojo: " + buscar, sqle);
			ConexionDB.renovar(con);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("BuscaDocumentoPojo: " + buscar, e);
		} finally {
			ConexionDB.devolver(con);
		}
		return resultado;
	}

	public boolean insertLetoniano(BeanLetoniano letoniano) {
		Connection conn = null;
		try {
			conn = ConexionDB.dameConexion();
			String sql = "IF EXISTS (SELECT idDescripcion, item, descripcionLetoniano, fechaCarga" + 
					" FROM cdiDescLetoniano (NOLOCK) WHERE item=?) "
					+ "UPDATE cdiDescLetoniano SET descripcionLetoniano= ?  ,"
					+ "fechaCarga= ?  WHERE item = ?"
					+ "ELSE INSERT INTO cdiDescLetoniano(item, descripcionLetoniano, fechaCarga) VALUES(?,?,?)";
			try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
				pstmt.setInt(1, letoniano.getItem());
				pstmt.setString(2, letoniano.getDescripcion());
				pstmt.setTimestamp(3,  getCurrentDate() );
				pstmt.setInt(4, letoniano.getItem());
				pstmt.setInt(5, letoniano.getItem());
				pstmt.setString(6, letoniano.getDescripcion());
				pstmt.setTimestamp(7, getCurrentDate());
				return pstmt.execute();

			} catch (SQLException eSQL) {
				log.error(getClass().getName() + eSQL.toString());
				ConexionDB.renovar(conn);
			}
		} catch (Exception e) {
			log.error(getClass().getName() + e.toString());
		} finally {
			ConexionDB.devolver(conn);
		}
		return false;
	}

	public boolean insertHebreo(BeanLetoniano letoniano) {
		Connection conn = null;
		try {
			conn = ConexionDB.dameConexion();
			String sql = ConsultasConstants.INSERTA_HEBREO.toString();
			try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
				pstmt.setInt(1, letoniano.getItem());
				pstmt.setString(2, letoniano.getDescripcion());
				pstmt.setTimestamp(3,  getCurrentDate() );
				pstmt.setInt(4, letoniano.getItem());
				pstmt.setInt(5, letoniano.getItem());
				pstmt.setString(6, letoniano.getDescripcion());
				pstmt.setTimestamp(7, getCurrentDate());
				return pstmt.execute();

			} catch (SQLException eSQL) {
				log.error(getClass().getName() + eSQL.toString());
				ConexionDB.renovar(conn);
			}
		} catch (Exception e) {
			log.error(getClass().getName() + e.toString());
		} finally {
			ConexionDB.devolver(conn);
		}
		return false;
	}

	public BeanLetoniano consultaLetoniano(Integer item) {
		Connection conn = null;
		BeanLetoniano letoniano = new BeanLetoniano();
		try {
			conn = ConexionDB.dameConexion();
			String sql = "select * from cdiDescLetoniano where item = ? ";
			try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
				pstmt.setInt(1, item);
				ResultSet rs = pstmt.executeQuery();

				while (rs.next()) {
					letoniano.setItem(rs.getInt("item"));
					letoniano.setDescripcion(rs.getString("descripcionLetoniano"));
				}

			} catch (SQLException eSQL) {
				log.error(getClass().getName() + eSQL.toString());
				ConexionDB.renovar(conn);
			}
		} catch (Exception e) {
			log.error(getClass().getName() + e.toString());
		} finally {
			ConexionDB.devolver(conn);
		}
		return letoniano;
	}

	public BeanLetoniano consultaHebreo(Integer item) {
		Connection conn = null;
		BeanLetoniano letoniano = new BeanLetoniano();
		try {
			conn = ConexionDB.dameConexion();
			String sql = ConsultasConstants.CONSULTA_HEBREO.toString();
			try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
				pstmt.setInt(1, item);
				ResultSet rs = pstmt.executeQuery();

				while (rs.next()) {
					letoniano.setItem(rs.getInt("item"));
					letoniano.setDescripcion(rs.getString("descripcionHebreo"));
				}

			} catch (SQLException eSQL) {
				log.error(getClass().getName() + eSQL.toString());
				ConexionDB.renovar(conn);
			}
		} catch (Exception e) {
			log.error(getClass().getName() + e.toString());
		} finally {
			ConexionDB.devolver(conn);
		}
		return letoniano;
	}

	private static Timestamp getCurrentDate() {
		return UtilsFechas.getFechaActual_SQL_smalldatetime();
	}
	
	
	
	
	
	
	public int insertaDocumentosSDIRechazo(BeanDocumentosSDI doc, Connection con) throws ServletException {
		PreparedStatement pst = null;
		StringBuffer insert  = new StringBuffer();
		int idAuto = 0;
		
		insert.append("INSERT INTO cdiDocumentosSDI ( ");
		insert.append("versionSDI, proveedor, booking,"); 
		insert.append(" versionFacturas, versionPK, versionBL, versionPreBL,");
		insert.append(" facturasCompletas, packingListCargado, preBLGenerado, BLGenerado, ");
		insert.append(" tieneOtrosDocumentos, fechaCreacion,fechaRechazo,comentariosSDI, usuarioRechazo ");		
		insert.append(")");
		insert.append(" VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,getDate(),?,?)");
		
		try {
			pst = con.prepareStatement(insert.toString(), Statement.RETURN_GENERATED_KEYS);
			int cont = 1;
			pst.setInt(cont++, doc.getVersionSDI()+1);
			pst.setString(cont++, doc.getProveedor());
			pst.setString(cont++, doc.getBooking());
			pst.setInt(cont++, doc.getVersionFacturas());
			pst.setInt(cont++,doc.getVersionPK() );
			pst.setInt(cont++,doc.getVersionBL() );
			pst.setInt(cont++, doc.getVersionPreBL());
			pst.setInt(cont++, Boolean.TRUE.equals(doc.getFacturasCompletas()) ? 1 : 0 );
			pst.setInt(cont++, Boolean.TRUE.equals(doc.getPackingListGenerado()) ? 1 : 0);
			pst.setInt(cont++, Boolean.TRUE.equals(doc.getPreBLGenerado()) ? 1 : 0);
			pst.setInt(cont++, Boolean.TRUE.equals(doc.getBlGenerado()) ? 1 : 0);
			pst.setInt(cont++, Boolean.TRUE.equals(doc.getTieneOtrosDocumentos()) ? 1 : 0);
			pst.setDate(cont++, UtilsFechas.setConvierteFechaToSQLDate(doc.getFechaCreacion()));
			pst.setString(cont++, doc.getComentariosSDI());
			pst.setString(cont++, doc.getUsuarioRechazo());
			int result = pst.executeUpdate();
			
			ResultSet rs = pst.getGeneratedKeys();
			if(rs.next()) {
				idAuto = rs.getInt(1);
			}
			
			if(result == 0) {
				throw new SQLException("No se realizo el insert en el rechazo de Documentos");
			}
			rs.close();
			pst.close();
			log.info("La instruccion sql se ejecutara sin problemas instrucci�n: {}, booking:{},proveedor:{},versionSDI:{}",
					pst.toString(),doc.getBooking(),doc.getProveedor(),doc.getVersionSDI()+1);
		} catch (Exception e) {
			log.error("[insertaDocumentosSDI] Error,booking:{},proveedor:{},versionSDI:{}  ",doc.getBooking(),doc.getProveedor(),doc.getVersionSDI()+1, e.getMessage(), e);
			throw new ServletException(e);
		}

		return idAuto;
	}
	
	public void insertaSarsEnBooking(SarBO bo, int id, Connection con) throws ServletException {
		Statement st = null;
		StringBuffer insert  = null;
		ArrayList<String> sars = new ArrayList<String>();
		if(Boolean.TRUE.equals(bo.getEsMultiple())) {
			String[] arreglos = bo.getFoliosMultiples().split(",");
			for(String tmp : arreglos) {
				sars.add(tmp);
			}
		}else {
			sars.add(bo.getFolio()+"");
		}
		
		try {
			st = con.createStatement();
			for(String tmp : sars) {
				insert  = new StringBuffer();
				insert.append("INSERT INTO cdisarsenbooking ( ");
				insert.append("id, sar");		
				insert.append(")");
				insert.append(" VALUES (");
				insert.append(id);
				insert.append(",");
				insert.append(tmp);		
				insert.append(")");
				st.addBatch(insert.toString());
			}
				
			int[] resultados = st.executeBatch();
			
			for(int data : resultados) {
				if(data == 0) {
					throw new SQLException("Un elemento no se actualizo correctamente, en la tabla cdisarsenbooking");
				}
			}
			st.close();
			log.info("La instruccion para insertar en la tabla de cdisarsenbooking deberia ejecutarse correctamente.");
		} catch (Exception e) {
			log.error("[insertaSarsEnBooking] Error "+e.getMessage(), e);
			throw new ServletException(e);
		}
	}
	
	public boolean insertFactura(BeanFactura fact, Connection con) throws ServletException {
		PreparedStatement pst = null;
		StringBuffer insert  = new StringBuffer();
		boolean exito = false;

		try {
			insert.append("INSERT INTO cdi_facturas ( ");
			insert.append("id, versionDocumento, condicionPago, nombre, madera,");
			insert.append("paisorigen, fechaCreacion, rutaArchivo, tieneOtros)");
			insert.append(" VALUES (?,?,?,?,?,?,getDate(),?,?)");
			pst = con.prepareStatement(insert.toString());
			
			int cont = 1;
			pst.setInt(cont++, fact.getId());
			pst.setInt(cont++, fact.getVersionDocumento());
			pst.setString(cont++, fact.getCondicionDePago());
			pst.setString(cont++, fact.getNombre());
			pst.setBoolean(cont++, fact.getTieneMadera());
			pst.setString(cont++, fact.getPaisOrigen());
			pst.setString(cont++, fact.getRutaArchivo());
			pst.setBoolean(cont++, Boolean.TRUE.equals(fact.getTieneOtros()));
			
			exito = pst.executeUpdate() > 0;
			if(!exito) {
				throw new SQLException("No se inserto el registro");
			}
			log.info("la instruccion Sql deberia ejecutarse sin problema");
			pst.close();
		} catch (Exception e) {
			log.error("[insertFactura] Error "+e.getMessage(), e);
			throw new ServletException(e);
		} 

		return exito;
	}
	
	
	public boolean insertaPL(BeanPL fact,Connection con) throws ServletException {
		Statement st = null;
		StringBuffer insert  = new StringBuffer();
		insert.append("INSERT INTO cdi_PackingList ( ");
		insert.append("id,nombre,versionDocumento,");
		insert.append("fechaCreacion,rutaArchivo)");
		insert.append(" VALUES (");
		insert.append(fact.getId());
		insert.append(",'");
		insert.append(fact.getNombre());
		insert.append("',");
		insert.append(fact.getVersionDocumento());
		insert.append(",");
		insert.append("GETDATE()");
		insert.append(",");
		insert.append("'").append(fact.getRutaArchivo()).append("'");

		insert.append(")");
				
		boolean exito = false;

		try {
			st = con.createStatement();
			exito = st.executeUpdate(insert.toString()) == 1;
			if(!exito) {
				throw new SQLException("Fallo la instruccion SQL, ningun registro insertado");
			}
			st.close();
			log.info("Se ejecuta correctamente la sentencia SQL");
		} catch (Exception e) {
			log.error("[insertaPL] Error "+e.getMessage(), e);
			throw new ServletException(e);
		}
		return exito;
	}
	
	
	public boolean insertaBL(BeanBL bl,Connection con) throws ServletException {
		Statement st = null;
		StringBuffer insert  = new StringBuffer();
		insert.append("INSERT INTO cdi_bl ( ");
		insert.append("id, tipo, versionDocumento, nombre, rutaArchivo, fechaCreacion) ");		
		insert.append(" VALUES (");
		insert.append(bl.getId());
		insert.append(",");
		insert.append("'").append(bl.getTipo()).append("'");
		insert.append(",");
		insert.append(bl.getVersionDocumento());
		insert.append(",");
		insert.append("'").append(bl.getNombre()).append("'");
		insert.append(",");
		insert.append("'").append(bl.getRutaArchivo()).append("'");
		insert.append(",GETDATE() )");
				
		boolean exito = false;

		try {
			st = con.createStatement();
			exito = st.executeUpdate(insert.toString()) == 1;
			if(!exito) {
				throw new SQLException("No se inserto regisgtro");
			}
			st.close();
			log.info("Se ejecuta correctamente la sentencia SQL");
		} catch (Exception e) {
			log.error("[insertaBL] Error "+e.getMessage(), e);
			throw new ServletException(e);
		}
		return exito;
	}
	
	
	
	
	public void updateSARRechazoSDI(int status, List<Integer> sars, int versionSDI, Connection con) throws Exception {
		int resultado = 0;
		DAOUtils utils = new  DAOUtils();
		try {
			PreparedStatement pst = null;
			StringBuffer query = new StringBuffer();

			query.append(" UPDATE cdiSAR ");
			query.append(" SET status= ").append(status).append(" ");
			query.append(" , versionSetDocumentos= ").append(versionSDI).append(" ");
			query.append(" WHERE folio  in ( ");
			int x = 0;
			for(Integer folio : sars) {
				if(x > 0) {
					query.append(",");
				}
				query.append("?");
				x++;
			}						
			query.append(" ) ");
			pst = con.prepareStatement(query.toString());
			
			utils.inicializaQuery(query.toString());					
			int cont = 1;
			for(Integer folio : sars) {
				utils.ajustaParametro(cont++, pst,folio, Integer.class);
			}
			resultado = pst.executeUpdate();
			pst.close();
			if(resultado ==  0) {
				throw new SQLException("No se actualizo registro...");
			}
			log.info("Se ejecuta correctamente la sentencia SQL");
		} catch (Exception sqlE) {
			throw sqlE;
		} 
	}

	public void insertHebreo(HashSet<BeanLetoniano> lkdListHebreo) {
		try {
			
			Set<BeanLetoniano> lkdListHebreoUp = new HashSet<BeanLetoniano>(0);
			int BATCH_SIZE = 20000;
			AtomicInteger counter = new AtomicInteger();
			Collection<List<String>> partition = lkdListHebreo.parallelStream().map(he -> he.getItem().toString())
					.collect(Collectors.groupingBy(it -> counter.getAndIncrement() / Integer.valueOf(BATCH_SIZE)))
					.values();
			
			partition.stream().forEach((final List<String> part) -> {
				try {
					String itemsHe = part.stream().parallel().collect(Collectors.joining(","));
					lkdListHebreoUp.addAll(consultDescByLeng(itemsHe,lkdListHebreo, SRMManagerConstants.HEBREO));
				} catch (Exception e){
					e.printStackTrace();
				}
			}
			);
			
			updateDescByLeng(lkdListHebreoUp, SRMManagerConstants.HEBREO);
			insertDescByLeng(lkdListHebreo, SRMManagerConstants.HEBREO);

		} catch (Exception e) {
			log.error(getClass().getName() + e.toString());
		}
	}

	public void insertLetoniano(HashSet<BeanLetoniano> lkdListLetoniano) {
		try {
			
			Set<BeanLetoniano> lkdListLetonianoUp = new HashSet<BeanLetoniano>(0);
			int BATCH_SIZE = 20000;
			AtomicInteger counter = new AtomicInteger();
			Collection<List<String>> partition = lkdListLetoniano.parallelStream().map(lv -> lv.getItem().toString())
					.collect(Collectors.groupingBy(it -> counter.getAndIncrement() / Integer.valueOf(BATCH_SIZE)))
					.values();
			
			partition.stream().forEach((final List<String> part) -> {
				try {
					String itemsLv = part.stream().parallel().collect(Collectors.joining(","));
					lkdListLetonianoUp.addAll(consultDescByLeng(itemsLv,lkdListLetoniano, SRMManagerConstants.LETONIANO));
				} catch (Exception e){
					e.printStackTrace();
				}
			}
			);
			
			updateDescByLeng(lkdListLetonianoUp,SRMManagerConstants.LETONIANO);
			insertDescByLeng(lkdListLetoniano,SRMManagerConstants.LETONIANO);
			
		} catch (Exception e) {
			log.error(getClass().getName() + e.toString());
		}
	}

	private void insertDescByLeng(HashSet<BeanLetoniano> lkdListInsertLeng, Object letoniano) {

		Connection conn = null;
		boolean currentAutocommit = false;
		try {
			conn = ConexionDB.dameConexion();
			currentAutocommit = conn.getAutoCommit();
			conn.setAutoCommit(false); //keep auto commit false for better performance
			
			String insertLeng = "";
			if(letoniano.equals(SRMManagerConstants.HEBREO)) {
				insertLeng = "INSERT INTO cdiDescHebreo(item, descripcionHebreo, fechaCarga) VALUES(?,?,?)";
			}else if (letoniano.equals(SRMManagerConstants.LETONIANO)){
				insertLeng = "INSERT INTO cdiDescLetoniano(item, descripcionLetoniano, fechaCarga) VALUES(?,?,?)";
			}
			
			PreparedStatement pStatement = conn.prepareStatement(insertLeng);
			int BATCH_SIZE = 10000;
			AtomicInteger counter = new AtomicInteger();
			Collection<List<BeanLetoniano>> partition = lkdListInsertLeng.parallelStream()
					.collect(Collectors.groupingBy(it -> counter.getAndIncrement() / Integer.valueOf(BATCH_SIZE)))
					.values();
			
			partition.stream().forEach((final List<BeanLetoniano> part) -> {
				try {
					part.stream().forEach(descLeng -> {
						try {
							pStatement.setInt(1, descLeng.getItem());
							pStatement.setString(2, descLeng.getDescripcion());
							pStatement.setTimestamp(3, getCurrentDate());
							pStatement.addBatch();
						} catch (SQLException e) {
							e.printStackTrace();
							log.error(getClass().getName() + e.toString());
						}
					});
					pStatement.executeBatch();
				} catch (Exception e) {
					e.printStackTrace();
					log.error(getClass().getName() + e.toString());
				}

			});

			pStatement.executeBatch();
			conn.commit();
			pStatement.close();
			conn.setAutoCommit(currentAutocommit);

		} catch (Exception e) {
			log.error(getClass().getName() + e.toString());
		} finally {
			ConexionDB.devolver(conn);
		}

	}

	private void updateDescByLeng(Set<BeanLetoniano> lkdListLetonianoUp, Object letoniano) {

		Connection conn = null;
		boolean currentAutocommit = false;
		try {
			conn = ConexionDB.dameConexion();
			currentAutocommit = conn.getAutoCommit();
			conn.setAutoCommit(false); //keep auto commit false for better performance
			
			String updateLeng = "";
			if(letoniano.equals(SRMManagerConstants.HEBREO)) {
				updateLeng = "UPDATE cdiDescHebreo SET descripcionHebreo= ?  ,fechaCarga= ?  WHERE item = ? ";
			}else if (letoniano.equals(SRMManagerConstants.LETONIANO)){
				updateLeng = "UPDATE cdiDescLetoniano SET descripcionLetoniano= ?  ,fechaCarga= ?  WHERE item = ?";
			}
			
		    PreparedStatement pStatement = conn.prepareStatement(updateLeng);
		    
			int BATCH_SIZE = 10000;
			AtomicInteger counter = new AtomicInteger();
			Collection<List<BeanLetoniano>> partition = lkdListLetonianoUp.parallelStream()
					.collect(Collectors.groupingBy(it -> counter.getAndIncrement() / Integer.valueOf(BATCH_SIZE)))
					.values();

			partition.stream().forEach((final List<BeanLetoniano> part) -> {
			try {
				
				part.stream().forEach(descLetoniano -> {
					try {
						pStatement.setString(1, descLetoniano.getDescripcion());
						pStatement.setTimestamp(2, getCurrentDate());
						pStatement.setInt(3, descLetoniano.getItem());
						pStatement.addBatch();
					
					} catch (SQLException e) {
						e.printStackTrace();
						log.error(getClass().getName() + e.toString());
					}
				});
				
				pStatement.executeBatch();
			} catch (Exception e){
				e.printStackTrace();
				log.error(getClass().getName() + e.toString());
			}
				
			});
			

			pStatement.executeBatch();
			conn.commit();
			pStatement.close();

			conn.setAutoCommit(currentAutocommit);
			

		} catch (Exception e) {
			e.printStackTrace();
			log.error(getClass().getName() + e.toString());
		} finally {
			ConexionDB.devolver(conn);
		}

	}

	private Set<BeanLetoniano> consultDescByLeng(String itemsLv, HashSet<BeanLetoniano> lkdListLeng, Object letoniano) {

		Connection conn = null;
		Set<BeanLetoniano> lkdListLengUp = new HashSet<BeanLetoniano>(0);
		try {
			conn = ConexionDB.dameConexion();

			StringBuffer sqlUpdates = new StringBuffer();
			if(letoniano.equals(SRMManagerConstants.HEBREO)) {
				sqlUpdates.append("SELECT DISTINCT item, descripcionHebreo, fechaCarga FROM cdiDescHebreo WHERE item in ( ");
			}else if (letoniano.equals(SRMManagerConstants.LETONIANO)){
				sqlUpdates.append("SELECT DISTINCT item, descripcionLetoniano, fechaCarga FROM cdiDescLetoniano WHERE item in ( ");
			}
			sqlUpdates.append(itemsLv).append(" )");
			
			PreparedStatement pstmt = conn.prepareStatement(sqlUpdates.toString());
			ResultSet rsUpdates = pstmt.executeQuery();
			while (rsUpdates.next()) {
				BeanLetoniano beanLetonianoUpdate = new BeanLetoniano();
				beanLetonianoUpdate.setItem(rsUpdates.getInt(1));
				
				Optional<BeanLetoniano> result = lkdListLeng.stream().parallel()
						.filter(obj -> obj.getItem().equals(beanLetonianoUpdate.getItem())).findFirst();
				if (result.isPresent()) {
					beanLetonianoUpdate.setDescripcion(result.get().getDescripcion());
					lkdListLeng.remove(result.get());
				}
				
				lkdListLengUp.add(beanLetonianoUpdate);
			}
			rsUpdates.close();

		} catch (Exception e) {
			e.printStackTrace();
			log.error(getClass().getName() + e.toString());
		} finally {
			ConexionDB.devolver(conn);
		}

		return lkdListLengUp;
	}
	
	
}
