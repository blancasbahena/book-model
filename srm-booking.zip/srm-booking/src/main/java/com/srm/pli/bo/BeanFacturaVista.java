package com.srm.pli.bo;

import java.util.Map;

import com.srm.pli.utils.FuncionesComunesPLI;
import com.truper.businessEntity.BeanFactura;

public class BeanFacturaVista extends BeanFactura{
	
	/**
	 * 
	 */
	
	private static final long serialVersionUID = 1L;	
	private String condicionPagoDes;

	public BeanFacturaVista() {
		
	}
	
	public BeanFacturaVista(BeanFactura bean) {
		this.setCondicionDePago(bean.getCondicionDePago());
		this.setFechaCreacion(bean.getFechaCreacion());
		this.setId(bean.getId());
		this.setNombre(bean.getNombre());
		this.setPaisOrigen(bean.getPaisOrigen());
		this.setRutaArchivo(bean.getRutaArchivo());
		this.setTieneMadera(bean.getTieneMadera());
		this.setTieneOtros(bean.getTieneOtros());
		this.setVersionDocumento(bean.getVersionDocumento());
	}
	
	public String getCondicionPagoDes() {
		return condicionPagoDes;
	}
	public void setCondicionPagoDes(String condicionPagoDes) {
		this.condicionPagoDes = condicionPagoDes;
	}
	
	public void cargaDatosVista() {
		Map<String, String> hash;
		try {
			hash = FuncionesComunesPLI.dameMapaCondicionPago(false);
			this.setCondicionPagoDes(hash != null ? hash.get(this.getCondicionDePago())  : "N.D");
		} catch (Exception e) {
			//TODO generar registro en log			
		}
	}
	
}
