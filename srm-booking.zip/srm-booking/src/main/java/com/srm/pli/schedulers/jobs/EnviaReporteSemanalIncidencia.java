package com.srm.pli.schedulers.jobs;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;



import com.srm.pli.services.ReporteSemanalIncidenciaService;
import com.truper.infra.loggers.BaseLogger;




public class EnviaReporteSemanalIncidencia implements Job{
	
	private final ReporteSemanalIncidenciaService enviaReporteMails = ReporteSemanalIncidenciaService.getInstance();



	@Override
	public void execute(JobExecutionContext context) throws JobExecutionException {
		BaseLogger.BOOKING_LOGGER.info("Inicia Job EnviaReporteSemanalIncidencia");
		try {
			enviaReporteMails.executeReporteIncidenciasSemanal();
		} catch (Exception e) {
			JobExecutionException e2 = new JobExecutionException (e);
			e2.setRefireImmediately (false); // para descartar el Job y seguir con el siguiente
			throw e2;
		} finally {
			BaseLogger.BOOKING_LOGGER.info("Termina Job EnviaReporteSemanalIncidencia");
		}
		
	}
	
	
}
