package com.srm.pli.services;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import com.srm.pli.bo.ClientePodBean;
import com.srm.pli.bo.SarBO;
import com.srm.pli.bo.SarDetalleBO;
import com.srm.pli.helper.DatosTelHelper;
import com.srm.pli.utils.FuncionesComunesPLI;
import com.srm.pli.utils.FuncionesWebservises;
import com.truper.businessEntity.BeanDatosTel;
import com.truper.businessEntity.BeanPuerto;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class DatosTelService {

	private static final DatosTelService instance = new DatosTelService();

	private DatosTelService() {
	}

	public static DatosTelService getInstance() {
		return instance;
	}

	public HashMap<Integer, List<SarDetalleBO>> getDetalle(List<SarBO> sars) {
		HashMap<Integer, List<SarDetalleBO>> respuesta = null;
		try {
			FuncionesComunesPLI.dameDatosCDIDetalle(sars);
			respuesta = new HashMap<>();
			for (SarBO sar : sars) {
				if (sar == null)
					continue;
				Integer folio = sar.getFolio();
				if (folio == null)
					continue;
				List<SarDetalleBO> detalles = FuncionesComunesPLI.getDetalleSAR(sar);
				if (detalles == null)
					continue;
				respuesta.put(folio, detalles);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return respuesta;
	}

	public BeanDatosTel getIdaMinimoAndBackorderAlArribo(List<SarDetalleBO> detalles) {
		if (detalles == null)
			return null;
		BeanDatosTel datos = new BeanDatosTel();
		Integer idaMinimo = null;
		BigDecimal backorderAlArribo = null;
		for (SarDetalleBO bean : detalles) {
			Integer ida = bean.getInventaroAlArribo();
			ida = ida == null ? 0 : ida;
			if (idaMinimo == null || ida.compareTo(0) == 1 && ida.compareTo(idaMinimo) == -1) {
				idaMinimo = ida;
			}
			BigDecimal backOrder = bean.getBackorderPronosticado();
			backOrder = backOrder == null ? BigDecimal.ZERO : backOrder;
			if (backorderAlArribo == null) {
				backorderAlArribo = backOrder;
			} else {
				backorderAlArribo = backorderAlArribo.add(backOrder);
			}
		}
		datos.setIdaMinimo(idaMinimo);
		datos.setBackorderAlArribo(backorderAlArribo);
		return datos;
	}

	public Map<String, BeanPuerto> getPuertoDescarga(Set<String> po) {
		Map<String, BeanPuerto> respuesta = null;
		try {
			Map<String, ClientePodBean> puertosTel = FuncionesWebservises.getPuertoDescarga(po);
			if (puertosTel == null)
				return respuesta;
			respuesta = new HashMap<>();
			if (puertosTel.isEmpty()) {
				return respuesta;
			}
			for (Entry<String, ClientePodBean> entry : puertosTel.entrySet()) {
				String key = entry.getKey();
				ClientePodBean value = entry.getValue();
				BeanPuerto bean = DatosTelHelper.getInstance().conviertePuerto(value);
				if (bean == null)
					continue;
				respuesta.put(key, bean);
			}
		} catch (Exception e) {
			log.error("@po {}", po, e);
		}
		return respuesta;
	}
}
