package com.srm.pli.bo;

public class SearchParamsDocs {
	private Integer folio;
	private Integer etdFrom;
	private Integer etdTo;
	private String etaFrom;
	private String etaTo;
	private String creationDateFrom;
	private String creationDateTo;
	private String proveedor;
	private Integer puertoOrigen;
	private String puertoDestino;
	private Integer naviera;
	private String booking;
	private String contenedor;
	private Integer prioridad;
	private String statusSAR;
	private String viaje;
	private String barco;
	private String analyst;
	private String bl;
	private String po;
	private String invoice;
	private String approvalFrom;
	private String approvalTo;
	private String condicionPago;

	/// Agrego esta variable si el POD es dinamico, es decir va por todos los
	/// puertos
	/// de descarga sean directos, normales incluso aereos
	private String PODDinamico;

	public Integer getFolio() {
		return folio;
	}

	public void setFolio(Integer folio) {
		this.folio = folio;
	}

	public Integer getEtdFrom() {
		return etdFrom;
	}

	public void setEtdFrom(Integer etdFrom) {
		this.etdFrom = etdFrom;
	}

	public Integer getEtdTo() {
		return etdTo;
	}

	public void setEtdTo(Integer etdTo) {
		this.etdTo = etdTo;
	}

	public String getEtaFrom() {
		return etaFrom;
	}

	public void setEtaFrom(String etaFrom) {
		this.etaFrom = etaFrom;
	}

	public String getEtaTo() {
		return etaTo;
	}

	public void setEtaTo(String etaTo) {
		this.etaTo = etaTo;
	}

	public String getCreationDateFrom() {
		return creationDateFrom;
	}

	public void setCreationDateFrom(String creationDateFrom) {
		this.creationDateFrom = creationDateFrom;
	}

	public String getCreationDateTo() {
		return creationDateTo;
	}

	public void setCreationDateTo(String creationDateTo) {
		this.creationDateTo = creationDateTo;
	}

	public String getProveedor() {
		return proveedor;
	}

	public void setProveedor(String proveedor) {
		this.proveedor = proveedor;
	}

	public Integer getPuertoOrigen() {
		return puertoOrigen;
	}

	public void setPuertoOrigen(Integer puertoOrigen) {
		this.puertoOrigen = puertoOrigen;
	}

	public Integer getNaviera() {
		return naviera;
	}

	public void setNaviera(Integer naviera) {
		this.naviera = naviera;
	}

	public String getBooking() {
		return booking;
	}

	public void setBooking(String booking) {
		this.booking = booking;
	}

	public String getContenedor() {
		return contenedor;
	}

	public void setContenedor(String contenedor) {
		this.contenedor = contenedor;
	}

	public Integer getPrioridad() {
		return prioridad;
	}

	public void setPrioridad(Integer prioridad) {
		this.prioridad = prioridad;
	}

	public String getStatusSAR() {
		return statusSAR;
	}

	public void setStatusSAR(String statusSAR) {
		this.statusSAR = statusSAR;
	}

	public String getViaje() {
		return viaje;
	}

	public void setViaje(String viaje) {
		this.viaje = viaje;
	}

	public String getBarco() {
		return barco;
	}

	public void setBarco(String barco) {
		this.barco = barco;
	}

	public String getAnalyst() {
		return analyst;
	}

	public void setAnalyst(String analyst) {
		this.analyst = analyst;
	}

	public String getPODDinamico() {
		return PODDinamico;
	}

	public void setPODDinamico(String pODDinamico) {
		PODDinamico = pODDinamico;
	}

	public String getBl() {
		return bl;
	}

	public void setBl(String bl) {
		this.bl = bl;
	}

	public String getPo() {
		return po;
	}

	public void setPo(String po) {
		this.po = po;
	}

	public String getInvoice() {
		return invoice;
	}

	public void setInvoice(String invoice) {
		this.invoice = invoice;
	}

	public String getPuertoDestino() {
		return puertoDestino;
	}

	public void setPuertoDestino(String puertoDestino) {
		this.puertoDestino = puertoDestino;
	}

	public String getApprovalTo() {
		return approvalTo;
	}

	public void setApprovalTo(String approvalTo) {
		this.approvalTo = approvalTo;
	}

	public String getApprovalFrom() {
		return approvalFrom;
	}

	public void setApprovalFrom(String approvalFrom) {
		this.approvalFrom = approvalFrom;
	}

	public String getCondicionPago() {
		return condicionPago;
	}

	public void setCondicionPago(String condicionPago) {
		this.condicionPago = condicionPago;
	}

}
