package com.srm.pli.helper;

import java.util.ArrayList;

import com.srm.pli.bo.OrdenCdiBO;
import com.srm.pli.utils.FuncionesComunesPLI;


public class FormatAgrupadorOrdenesCDI {

	private String numeroOrden;
	private int fechaUltimaConfirmacion;
	private String fechaUltimaConfirmacionFormat;
	private Boolean tieneCambioETD;
	private Boolean bloqueadaRedFlag;
	ArrayList<FormatOrdenCDI> ordenes;

	public FormatAgrupadorOrdenesCDI(AgrupadorOrdenesCDIBO bean) {
		numeroOrden = bean.getNumeroOrden();
		fechaUltimaConfirmacion = bean.getFechaUltimaConfirmacion();
		fechaUltimaConfirmacionFormat = FuncionesComunesPLI.formateaFecha(bean
				.getFechaUltimaConfirmacion());
		ArrayList<FormatOrdenCDI> tmp = new ArrayList<FormatOrdenCDI>();
		for(OrdenCdiBO orden : bean.getOrdenes()){
			FormatOrdenCDI bo = new FormatOrdenCDI(orden);
			tmp.add(bo);
		}
		

		
		tieneCambioETD = bean.getTieneCambioETD();
		bloqueadaRedFlag = bean.getRedFlagOn();
		
		ordenes = tmp;
	}

	public String getNumeroOrden() {
		return numeroOrden;
	}

	public void setNumeroOrden(String numeroOrden) {
		this.numeroOrden = numeroOrden;
	}

	public int getFechaUltimaConfirmacion() {
		return fechaUltimaConfirmacion;
	}

	public void setFechaUltimaConfirmacion(int fechaUltimaConfirmacion) {
		this.fechaUltimaConfirmacion = fechaUltimaConfirmacion;
	}

	public String getFechaUltimaConfirmacionFormat() {
		return fechaUltimaConfirmacionFormat;
	}

	public void setFechaUltimaConfirmacionFormat(
			String fechaUltimaConfirmacionFormat) {
		this.fechaUltimaConfirmacionFormat = fechaUltimaConfirmacionFormat;
	}

	public Boolean getTieneCambioETD() {
		return tieneCambioETD;
	}

	public void setTieneCambioETD(Boolean tieneCambioETD) {
		this.tieneCambioETD = tieneCambioETD;
	}

	/**
	 * @return the bloqueadaRedFlag
	 */
	public Boolean getBloqueadaRedFlag() {
		return bloqueadaRedFlag;
	}

	/**
	 * @param bloqueadaRedFlag the bloqueadaRedFlag to set
	 */
	public void setBloqueadaRedFlag(Boolean bloqueadaRedFlag) {
		this.bloqueadaRedFlag = bloqueadaRedFlag;
	}
	

}
