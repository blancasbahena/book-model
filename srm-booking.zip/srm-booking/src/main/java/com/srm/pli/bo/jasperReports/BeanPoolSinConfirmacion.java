package com.srm.pli.bo.jasperReports;

import java.util.HashSet;

import com.srm.pli.bo.SarDetalleBO;
import com.srm.pli.helper.FormatSAR;
import com.srm.pli.helper.FormatSARDetalle;

public class BeanPoolSinConfirmacion {
	private String folio;
	private String proveedor;
	private String shippingPort;
	private String creationDate;
	private String daySinceCreation;
	private String etd;
	private String container;
	private String volumen;
	private String peso;
	private String pos;
	private int items;
	
	public BeanPoolSinConfirmacion(FormatSAR f) {
		this.folio = f.getFolio();
		this.proveedor = f.getProveedor();
		this.shippingPort = f.getPuertoOrigen();
		this.creationDate = f.getFechaCreacion();
		this.daySinceCreation = f.getDaysSinceCreationDate();
		this.etd = f.getEtdReal();
		this.container = f.getContenedor();
		this.volumen = f.getVolumen();
		this.peso = f.getPeso();
		this.items = dameNumeroDePartidas(f);
		this.pos = damePos(f);
	}
	
	public int dameNumeroDePartidas(FormatSAR f) {
		int partidasDet = 0, partidasDetOtros=0;
		if(f.getDetalle() != null ) {
			partidasDet = f.getDetalle().size(); 
		}
		if(f.getDetalleOthers() != null) {
			partidasDetOtros =f.getDetalleOthers().size(); 
		}
		
		return partidasDet+partidasDetOtros;
	}
	
	
	public String damePos(FormatSAR f) {
		StringBuffer partidas = new StringBuffer();
		HashSet<String> map = new HashSet<>();
		if(f.getDetalle() != null ) {
			for(FormatSARDetalle det : f.getDetalle()) {
				map.add(det.getPo());
			}
		}
		if(f.getDetalleOthers() != null) {
			for(FormatSARDetalle det : f.getDetalleOthers()) {
				if(det.getPoOtherItem() != null && !"".equals(det.getPoOtherItem())) {
					map.add(det.getPoOtherItem());
				}
				
			}
		}
		int cont = 0;
		for(String tmp : map) {
			if(cont > 0) {
				partidas.append(",");
			}
			cont++;
			partidas.append(tmp);
		}
		return partidas.toString();
	}
	
	public String getFolio() {
		return folio;
	}
	public void setFolio(String folio) {
		this.folio = folio;
	}
	public String getProveedor() {
		return proveedor;
	}
	public void setProveedor(String proveedor) {
		this.proveedor = proveedor;
	}
	public String getShippingPort() {
		return shippingPort;
	}
	public void setShippingPort(String shippingPort) {
		this.shippingPort = shippingPort;
	}
	public String getCreationDate() {
		return creationDate;
	}
	public void setCreationDate(String creationDate) {
		this.creationDate = creationDate;
	}
	public String getDaySinceCreation() {
		return daySinceCreation;
	}
	public void setDaySinceCreation(String daySinceCreation) {
		this.daySinceCreation = daySinceCreation;
	}
	public String getEtd() {
		return etd;
	}
	public void setEtd(String etd) {
		this.etd = etd;
	}
	public String getContainer() {
		return container;
	}
	public void setContainer(String container) {
		this.container = container;
	}
	public String getVolumen() {
		return volumen;
	}
	public void setVolumen(String volumen) {
		this.volumen = volumen;
	}
	public String getPeso() {
		return peso;
	}
	public void setPeso(String peso) {
		this.peso = peso;
	}
	public String getPos() {
		return pos;
	}
	public void setPos(String pos) {
		this.pos = pos;
	}
	public int getItems() {
		return items;
	}
	public void setItems(int items) {
		this.items = items;
	}
	
}
