package com.srm.pli.helper;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.srm.pli.bo.CdiDocumentBO;
import com.srm.pli.bo.SarBO;
import com.srm.pli.dao.SAR_CDI_DAO;

public class FiltraSAR {
	private int status;
	public FiltraSAR(int status) {
		this.status = status;
	}
	public boolean pasaFiltro(SarBO sar) {
		boolean pasa = false;
		CdiDocumentBO doc = new CdiDocumentBO();
		doc.setSar(sar.getFolio());
		ArrayList<CdiDocumentBO> lista = new ArrayList<CdiDocumentBO>();
		try {
			lista = SAR_CDI_DAO.selectDocumentosFact(doc);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		boolean fac = false,bl = false,pkl = false, tienetodosDoc = false;
		for(CdiDocumentBO d :lista){
			if("FAC".equals(d.getTipo())){
				fac = true;
			}
			if("BL".equals(d.getTipo())){
				bl = true;
			}
			if("PKL".equals(d.getTipo())){
				pkl = true;
			}
		}
		if (fac && bl && pkl) {
			tienetodosDoc = true;
		}
		if (status == -1){
			pasa = true;
		} else if (status == -99 && sar.getStatus() > SarBO.STATUS_SIN_SOLICITUD_APROBACION
				&& sar.getStatus() < SarBO.STATUS_DOCUMENTOS_SDI) {
			pasa = true;
		} else if (status == 12 && (sar.getStatus() == SarBO.STATUS_APROBADO || sar.getStatus() == SarBO.STATUS_EMBARCADO) 
				&& (sar.esModificadoProveedor() != null && sar.esModificadoProveedor()) 
				&& (sar.getAceptadoConDiferencias() == null || !sar.getAceptadoConDiferencias())) {
			pasa = true;
		} else if (status == 0 && sar.getStatus() == SarBO.STATUS_SIN_SOLICITUD_APROBACION) {
			pasa = true;
		} else if (status == 2 && sar.getStatus() == SarBO.STATUS_CANCELADO) {
			pasa = true;
		} else if (status == 3 && sar.getStatus() == SarBO.STATUS_RECHAZADO) {
			pasa = true;
		} else if (status == 1 && sar.getStatus() == SarBO.STATUS_ESPERA_APROBACION_PLANEACION) {
			pasa = true;
		} else if (status == 4 && sar.getStatus() == SarBO.STATUS_ESPERA_APROBACION_SHIPPING) {
			pasa = true;
		} else if (status == 5 && sar.getStatus() == SarBO.STATUS_APROBADO && (sar.getFolioConsolidado() == null || sar.getFolioConsolidado() == 0)) {
			pasa = true;
		} else if (status == 6 && sar.getStatus() < SarBO.STATUS_EMBARCADO && sar.getFolioConsolidado() != null && sar.getFolioConsolidado() > 0) {
			pasa = true;
		} else if (status == 7 && sar.getStatus() == SarBO.STATUS_EMBARCADO && (sar.getAprobadoProveedor() == null   || !sar.getAprobadoProveedor())) {
			pasa = true;
		} else if (status == 8 && sar.getStatus() == SarBO.STATUS_EMBARCADO && sar.getAprobadoProveedor() != null && sar.getAprobadoProveedor() && !tienetodosDoc) {
			pasa = true;
		} else if (status == 9 && sar.getStatus() == SarBO.STATUS_EMBARCADO && tienetodosDoc){
			pasa = true;
		} else if (status == 10 && sar.getStatus() == SarBO.STATUS_DOCUMENTOS_SDI && sar.esAprobadoSDI()== null && !sar.esAprobadoSDI()) {
			pasa = true;
		} else if (status == 11 && sar.getStatus() == SarBO.STATUS_DOCUMENTOS_SDI && sar.esAprobadoSDI()!= null && sar.esAprobadoSDI()) {
			pasa = true;
		} else {
			pasa = false;
		}
		return pasa;
	}
	
	public List<SarBO> filtraSARs(List<SarBO> sars) {
		List<SarBO> temp = new ArrayList<SarBO>();
		
		for(SarBO sar : sars){
			if(pasaFiltro(sar)){
				temp.add(sar);
			}
		}
		
		return temp;
	}
}
