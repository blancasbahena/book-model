package com.srm.pli.bo;

import java.util.ArrayList;

import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

public class SarBOJasper {
	private ArrayList<SarDetalleAgrupadoJasper> agrupaPO;
	private ArrayList<SarDetalleAgrupadoJasper> agrupadoOtro;
	private String invoiceNo;
	private String conName;
	private String conDireccion;
	private String conRFC;
	private String invoiceDate;
	private String terminoPago;
	private String incoTerm;
	private String etd;
	private String subDireccion;
	private String subNombre;
	private String subTaxId;
	

	public String getInvoiceNo() {
		return invoiceNo;
	}
	public void setInvoiceNo(String invoiceNo) {
		this.invoiceNo = invoiceNo;
	}
	
	public JRDataSource getAgrupaPO() {
		return new JRBeanCollectionDataSource(agrupaPO);
	}
	public JRDataSource getAgrupadoOtro() {
		return new JRBeanCollectionDataSource(agrupadoOtro);
	}
	public String getConName() {
		return conName;
	}
	public void setConName(String conName) {
		this.conName = conName;
	}
	public String getConDireccion() {
		return conDireccion;
	}
	public void setConDireccion(String conDireccion) {
		this.conDireccion = conDireccion;
	}
	public String getConRFC() {
		return conRFC;
	}
	public void setConRFC(String conRFC) {
		this.conRFC = conRFC;
	}
	public String getInvoiceDate() {
		return invoiceDate;
	}
	public void setInvoiceDate(String invoiceDate) {
		this.invoiceDate = invoiceDate;
	}
	public String getTerminoPago() {
		return terminoPago;
	}
	public void setTerminoPago(String terminoPago) {
		this.terminoPago = terminoPago;
	}
	public String getIncoTerm() {
		return incoTerm;
	}
	public void setIncoTerm(String incoTerm) {
		this.incoTerm = incoTerm;
	}
	public String getEtd() {
		return etd;
	}
	public void setEtd(String etd) {
		this.etd = etd;
	}
	public String getSubDireccion() {
		return subDireccion;
	}
	public void setSubDireccion(String subDireccion) {
		this.subDireccion = subDireccion;
	}
	public String getSubNombre() {
		return subNombre;
	}
	public void setSubNombre(String subNombre) {
		this.subNombre = subNombre;
	}
	public String getSubTaxId() {
		return subTaxId;
	}
	public void setSubTaxId(String subTaxId) {
		this.subTaxId = subTaxId;
	}
	public void setAgrupaPO(ArrayList<SarDetalleAgrupadoJasper> agrupaPO) {
		this.agrupaPO = agrupaPO;
	}
	public void setAgrupadoOtro(ArrayList<SarDetalleAgrupadoJasper> agrupadoOtro) {
		this.agrupadoOtro = agrupadoOtro;
	}
}
