package com.srm.pli.bo;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import com.truper.businessEntity.ImportacionesProveedoresBean;
import com.truper.businessEntity.UserBean;

import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
public class SarRM_BO implements Serializable {

	private static final long serialVersionUID = -7663309896234437963L;
	
	private String folio;
	private String booking;
	private String carrier;
	private int carrierId;
	private String vessel;
	private String voyage;
	private String pol;
	private String pod;
	private String etd;
	private String etdAnterior;
	private String eta; 
	private String transist_time;
	private Timestamp create_date;
	private List<SarRMChat_BO>  chat_RM;
	private UserBean userRM;
	private String estatus_RM;
	private boolean isConsol;
	private String motivo;
	private int idProveedor;
	private ImportacionesProveedoresBean proveedorBean;
	private int idUserLastChat;
	private boolean isUnread;
	private boolean esPedidoDirecto;
	private boolean tieneConfFinal;	
	private String supplier;
	private String bl;
	private Integer tipoContenedor;
	private String contenedor;
	private String reason;
	private String action;
	private Date fechaSolicitado;
	private Integer paisDestino;
}
