package com.srm.pli.schedulers.jobs;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import com.srm.pli.services.impl.ProcesoActualizaCatalogos;
import com.truper.infra.loggers.BaseLogger;


public class ProcesosActualizaTablas implements Job {
	
	@Override
	public void execute(JobExecutionContext arg0) throws JobExecutionException {
		BaseLogger.BOOKING_LOGGER.info("Inicia carga de tabla de condiciones de pago");
		ProcesoActualizaCatalogos proceso = new ProcesoActualizaCatalogos();
		proceso.actualizaCondicionesPago();
		BaseLogger.BOOKING_LOGGER.info("Fin carga de tabla de condiciones de pago");
	}

}
