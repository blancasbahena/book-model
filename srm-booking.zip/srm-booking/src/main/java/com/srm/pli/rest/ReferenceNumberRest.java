package com.srm.pli.rest;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.json.JSONArray;
import org.json.JSONObject;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.srm.pli.bo.HistoryLogBean;
import com.srm.pli.bo.SarBO;
import com.srm.pli.constants.DataConstants;
import com.srm.pli.dao.SAR_CDI_DAO;
import com.srm.pli.enums.HistoryLogAction;
import com.srm.pli.helper.HistoryLogHelper;
import com.srm.pli.services.impl.HistoryLogServiceImpl;
import com.srm.pli.utils.FuncionesComunesPLI;
import com.srm.pli.utils.PoSerializer;
import com.truper.bpm.enums.ErrorValidacionEtdEta;
import com.truper.businessEntity.Naviera;
import com.truper.businessEntity.ReferenceNumberBean;
import com.truper.businessEntity.UserBean;
import com.truper.infra.rs.BaseRS;
import com.truper.utils.date.EnumFechas;

import lombok.extern.log4j.Log4j2;

@Path("/reference-number")
@Log4j2
public class ReferenceNumberRest extends BaseRS{

	private static final long serialVersionUID = 5023055154485895846L;

	Gson g = new GsonBuilder()
			.registerTypeAdapter(ErrorValidacionEtdEta.class, new PoSerializer.ErrorValidacionEtdEtaSerializer())
			.serializeSpecialFloatingPointValues().setDateFormat(EnumFechas.FORMATO_YYYY_MM_DD.to()).create();
	
	@Context
	private HttpServletRequest request;
	
	@POST
	@Path("/buscaBooking")
	@Produces(MediaType.APPLICATION_JSON)
	public Response buscaBooking(
			@FormParam("folio") String folio
			, @FormParam("esConsol") Boolean esConsol){
		
		JSONObject json = new JSONObject();
		JSONArray jArrNavieras = new JSONArray();
		JSONArray jArrRefNumbers = new JSONArray();
		try{
			
			List<Integer> lstFolios = new ArrayList<Integer>();
			lstFolios.add(Integer.parseInt(folio));
			if (esConsol != null && esConsol) {
				lstFolios = SAR_CDI_DAO.dameSARsEnCC(Integer.parseInt(folio));
			}
			List<SarBO> lstSars = new ArrayList<SarBO>();
			for (Integer iFolio : lstFolios) {
				SarBO sar = new SarBO();
				sar.setFolio(iFolio);
				sar.setConsolidado(esConsol);
				lstSars.add(sar);
			}
			
			Map<Integer, ReferenceNumberBean> mapRefNumbers = SAR_CDI_DAO.selectReferenceNumbers(lstSars);
			
			for (Map.Entry<Integer, ReferenceNumberBean> entry : mapRefNumbers.entrySet()) {
				ReferenceNumberBean rf = entry.getValue();
				if(rf == null) {
					json.put("yaExiste", 0);
				}else {
					json.put("yaExiste", 1);
					JSONObject jsonDataObj = new JSONObject();
					jsonDataObj.put("folio", rf.getFolio());
					jsonDataObj.put("requestDate", rf.getBookingRequestDateCompany());
					Naviera _carrier = FuncionesComunesPLI.mapaNavieras.get(rf.getCarrier());
					jsonDataObj.put("carrier", _carrier == null ? "0" : _carrier.getClave());
					jsonDataObj.put("etd", rf.getETD());
					jsonDataObj.put("reference", rf.getReferenceNumber());
					jsonDataObj.put("vessel", rf.getVesselName());
					jsonDataObj.put("version", rf.getVersion());
					jsonDataObj.put("comentario", rf.getComentario() != null ? rf.getComentario() : "");
					jArrRefNumbers.put(jsonDataObj);
				}
			}
			json.put("refNumbers", jArrRefNumbers);				
			
			for(Entry<Integer, Naviera> mapaNav : FuncionesComunesPLI.mapaNavieras.entrySet()) {
				JSONObject j = new JSONObject();
				j.put("id", mapaNav.getKey());
				j.put("nombre", mapaNav.getValue().getNombre());
				jArrNavieras.put(j);
			}
			json.put("navieras", jArrNavieras);
			
			json.put("errorCode", 0);
			json.put("errorStr", "");
			
		} catch(Exception e){
			json.put("errorCode", 1);
			json.put("errorStr", e.getMessage());
			log.error(json, e);
			return buildErrorResponse(json.toString());
		}
		return buildOKResponse(json.toString());
	}
	
	@POST
	@Path("/guardaBooking")
	@Produces(MediaType.APPLICATION_JSON)
	public Response guardaBooking(
			@QueryParam("folio") String folio
			, @QueryParam("reference") String refNumber
			, @QueryParam("carrier") String carrier
			, @QueryParam("bookingRequest") String bookingRequest
			, @QueryParam("etd") String etd
			, @QueryParam("vessel") String vessel
			, @QueryParam("update") String update
			, @QueryParam("version") String version) {
		
		JSONObject json = new JSONObject();
		try {
			if (folio != null) {
				folio = folio.trim();
			}
			if (refNumber != null) {
				refNumber = refNumber.trim();
			}
			String carrierName = carrier;
			if (carrierName != null) {
				carrierName = carrierName.trim();
			}
			if (bookingRequest != null) {
				bookingRequest = bookingRequest.trim();
			}
			if (etd != null) {
				etd = etd.trim();
			}
			if (vessel != null) {
				vessel = vessel.trim();
			}
			if (update != null) {
				update = update.trim();
			}
			if (version != null) {
				version = version.trim();
			}
			UserBean user = getUser();
			
			ReferenceNumberBean refNumberObj = new ReferenceNumberBean();
			refNumberObj.setBookingRequestDateCompany(Integer.parseInt(bookingRequest));
			refNumberObj.setCarrier(Integer.parseInt(carrierName));
			refNumberObj.setETD(Integer.parseInt(etd));
			refNumberObj.setReferenceNumber(refNumber);
			refNumberObj.setUsuario(user.getUserName());
			refNumberObj.setVesselName(vessel);
			refNumberObj.setFolio(Integer.parseInt(folio));
			if("1".equals(update )) {
				////Busco si la otra verison fue respondida por Booking
				SarBO bo = new SarBO();
				bo.setFolio(Integer.parseInt(folio));
				ArrayList<SarBO> lista = new ArrayList<SarBO>();
				lista.add(bo);
				Map<Integer, ReferenceNumberBean>  map = SAR_CDI_DAO.selectReferenceNumbers(lista);
				ReferenceNumberBean reference = map.get(bo.getFolio());
				version  = validaUndefinedVersion(version,map);
				if(reference.getRespuestaBooking() == null) {
					refNumberObj.setVersion(Integer.parseInt(version));
					SAR_CDI_DAO.updateReferenceNumber(refNumberObj);						
				}else {
					refNumberObj.setVersion((Integer.parseInt(version)+1));
					SAR_CDI_DAO.insertaReferenceNumber(refNumberObj);
				}
			}else {
				version = "undefined".equals(version) ? "1":version ; 
				refNumberObj.setVersion(Integer.parseInt(version));
				SAR_CDI_DAO.insertaReferenceNumber(refNumberObj);
			}

				// Guarda SAR History Log
			String username = HistoryLogHelper.getInstance().getUserName(user);	
			HistoryLogBean historyLogBean = HistoryLogBean.builder()
					.tipoAccion(HistoryLogAction.BOOKING_REQUEST_BY_VENDOR.id())
					.folio(Integer.parseInt(folio))
					.sarType(DataConstants.SAR_TYPE)
					.comentarios(refNumberObj.getReferenceNumber())
					.username(username).build();
			log.info("Datos a insetar en el history log: Accion: {}, username:{}", historyLogBean.getTipoAccion(), historyLogBean.getUsername());
			HistoryLogServiceImpl.getInstance().saveHistoryLogComments(historyLogBean);

			json.put("errorCode", 0);
			json.put("errorStr", "");
		}catch(Exception e){
			json.put("errorCode", 1);
			json.put("errorStr", e.getMessage());
			return buildErrorResponse(json.toString());
		}
		return buildOKResponse(json.toString());
	}
	
	
	private String validaUndefinedVersion(String version, Map<Integer, ReferenceNumberBean> map) {
		// TODO Auto-generated method stub
		int maximo =0;
		try {
			Integer.parseInt(version);
		}catch(Exception  xc) {
			log.error("Problemas conversion {} validaUndefinedVersion ",version);
		}
		for(Map.Entry<Integer,ReferenceNumberBean> entry: map.entrySet()) {
			if(entry.getValue().getVersion()>maximo) {
				maximo=  entry.getValue().getVersion();
			}
		}
		return ""+maximo;
	}

	private UserBean getUser() {
		HttpSession session = request.getSession(false);
		if (session == null)
			return null;
		UserBean usuario = (UserBean) session.getAttribute("usuario");
		return usuario;
	}
}
