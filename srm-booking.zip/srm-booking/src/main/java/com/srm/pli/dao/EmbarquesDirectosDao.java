package com.srm.pli.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import com.srm.pli.bo.ConsultaDatosCdiSARBean;
import com.srm.pli.bo.ParametrosIndexBean;
import com.srm.pli.constants.ConsultasConstants;
import com.srm.pli.db.ConexionDB;
import lombok.extern.slf4j.Slf4j;


@Slf4j
public class EmbarquesDirectosDao
{
	private static final EmbarquesDirectosDao INSTANCE = new EmbarquesDirectosDao();
	
	
	private EmbarquesDirectosDao() 
	{
	}

	public static EmbarquesDirectosDao getInstance() 
	{
		return INSTANCE;
	}

	public Set<ConsultaDatosCdiSARBean> getInformacionCdiSAR(ParametrosIndexBean parametrosIndexBean)	
	{
		log.info("Inicio::DAO Obteniendo datos de la tabla de cdiSAR para directos");
		Set<ConsultaDatosCdiSARBean> consultaDatosCdiSARResponse = null;
		Connection con = null;
		
		try 
		{
			con = ConexionDB.dameConexion();
			
			try(PreparedStatement pst = con.prepareStatement(ConsultasConstants.GET_INFORMACION_CDI_SAR)) 
			{
				pst.setString(1, parametrosIndexBean.getFolioSAR());
				try (ResultSet rs = pst.executeQuery()) 
				{
					consultaDatosCdiSARResponse = new HashSet<>();
					ConsultaDatosCdiSARBean bean = null;
					while(rs.next()) 
					{
						 bean = new ConsultaDatosCdiSARBean();
						 bean.setNumProveedor(rs.getString("proveedor"));
						 bean.setPuertoOrigen(rs.getString("puertoOrigen"));
						 bean.setPuertoDestino(rs.getString("puertoDestino"));
						 bean.setNombrePuertoDestino(rs.getString("nombrePuertoOrigen"));
						 bean.setNumCliente(rs.getString("cliente"));
						 bean.setPoParcel(rs.getString("poParcel").trim());
						 bean.setFolioSAR(rs.getInt("folioSAR"));
						 bean.setEtdSAR(rs.getInt("etdSAR"));
						 bean.setNumBooking(rs.getString("numBKG"));
						 bean.setEdtBooking(rs.getInt("etdBooking"));
						 bean.setContenedor(rs.getString("contenedor"));
						 bean.setNaviera(rs.getInt("naviera"));
						 bean.setEtaEstimadaNaviera(rs.getInt("etaEstimadaNaviera"));
						 bean.setInstruccionInicialBL(rs.getString("instruccionInicialBL"));
						 consultaDatosCdiSARResponse.add(bean);
					} 
				}
			}
		} 
		catch(SQLException sqle) 
		{
			log.error("Error al obtener datos de las tablas cdiSAR y cdiSARDetalle: ", sqle);
		}
		catch(Exception e) 
		{
			log.error("Error al obtener datos de las tablas cdiSAR y cdiSARDetalle: ", e);
		} 
		finally 
		{
			ConexionDB.devolver(con);
		}
		log.info("Fin::DAO Se termino de obtener los datos de la tabla de cdiSAR para directos");
		return consultaDatosCdiSARResponse;
	}
	
	public String getNombreNaviera(Integer clave)
	{
		log.info("Inicio::DAO Obteniendo el nombre de la Naviera por clave para directos");
		String nombreNaviera = null;
		Connection con = null;
		
		try 
		{
			con = ConexionDB.dameConexion();	
			
			try(PreparedStatement pst = con.prepareStatement(ConsultasConstants.GET_NOMBRE_NAVIERA)) 
			{
				pst.setInt(1, clave);
				try (ResultSet rs = pst.executeQuery()) 
				{
					if(rs.next()) 
					{
						nombreNaviera = rs.getString("nombre");
					} 
				}
			}
		} 
		catch(SQLException sqle) 
		{
			log.error("Error al obtener datos de las tabla (cdiNavieras): ", sqle);
		}
		catch(Exception e) 
		{
			log.error("Error al obtener datos de las tabla (cdiNavieras): ", e);
		} 
		finally 
		{
			ConexionDB.devolver(con);
		}
		log.info("Fin::DAO Se termino de obtener el nombre de la Naviera");
		return nombreNaviera;
	}

	public Integer getVersionDocumento(String booking, String proveedor)
	{		
		log.info("Inicio::DAO Obteniendo la version del documento");
		Connection con = null;
		Integer versionDocumento = null;
		
		try 
		{
			con = ConexionDB.dameConexion();	
			try(PreparedStatement pst = con.prepareStatement(ConsultasConstants.GET_VERSION_DOCUMENTO)) 
			{
				pst.setString(1, booking);
				pst.setString(2, proveedor);
				try(ResultSet rs = pst.executeQuery()) 
				{
					if(rs.next()) 
					{
						versionDocumento = rs.getInt("versionSetDocumentos");
					}
				}
			}
		}
		catch(SQLException sqle) 
		{
			log.error("Error al obtener datos de la tabla(cdiSAR): ", sqle);
		}
		catch(Exception e) 
		{
			log.error("Error al obtener datos de la tabla(cdiSAR): ", e);
		} 
		finally 
		{
			ConexionDB.devolver(con);
		}		
		log.info("Fin::DAO Se termino de obtener el la version del documento");
		return versionDocumento;
	}
	
	public Map<Integer, Integer> getDocumentosSDI(String proveedor, String booking, Integer versionSDI)
	{
		log.info("Inicio::DAO Obteniendo el documento SDI");
		Connection con = null;
		Map<Integer, Integer> mapResponse = new HashMap<Integer, Integer>();
		
		try 
		{
			con = ConexionDB.dameConexion();	
			try(PreparedStatement pst = con.prepareStatement(ConsultasConstants.GET_DOCUMENTOS_SDI)) 
			{
				pst.setString(1, proveedor);
				pst.setString(2, booking);
				pst.setInt(3, versionSDI);
				try(ResultSet rs = pst.executeQuery()) 
				{
					if(rs.next()) 
					{
						mapResponse.put(rs.getInt("id"), rs.getInt("versionFacturas"));
					}
				}
			}
		}
		catch(SQLException sqle) 
		{
			log.error("Error al obtener datos de la tabla(cdiDocumentosSDI): ", sqle);
		}
		catch(Exception e) 
		{
			log.error("Error al obtener datos de la tabla(cdiDocumentosSDI): ", e);
		} 
		finally 
		{
			ConexionDB.devolver(con);
		}		
		log.info("Fin::DAO Se termino de obtener el documento SDI");
		return mapResponse;
	}
	
	public Map<Integer, String> getNombreFactura(Integer id, Integer versionDocumento)
	{
		log.info("Inicio::DAO Obteniendo el nombre de la factura");
		Connection con = null;
		Map<Integer, String> mapResponse = new HashMap<Integer, String>();
		
		try 
		{
			con = ConexionDB.dameConexion();	
			try (PreparedStatement pst = con.prepareStatement(ConsultasConstants.FIND_NAME_FACTURA)) 
			{
				pst.setInt(1, id);
				pst.setInt(2, versionDocumento);
				try (ResultSet rs = pst.executeQuery()) 
				{
					if(rs.next()) 
					{
						mapResponse.put(rs.getInt("id"), rs.getString("nombre"));
					}
				}
			}
		}
		catch(SQLException sqle) 
		{
			log.error("Error al obtener datos de la tabla(cdi_facturas): ", sqle);
		}
		catch(Exception e) 
		{
			log.error("Error al obtener datos de la tabla(cdi_facturas): ", e);
		} 
		finally 
		{
			ConexionDB.devolver(con);
		}		
		log.info("Fin::DAO Se termino de obtener el nombre de la factura");
		return mapResponse;
	}
}
