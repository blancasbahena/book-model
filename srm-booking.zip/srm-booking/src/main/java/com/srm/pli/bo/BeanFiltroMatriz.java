package com.srm.pli.bo;

import java.util.Date;

public class BeanFiltroMatriz {
	
	private String proveedor;
	private String po;
	private String status;
	private boolean onlyBackLog;
	private Date logIni;
	private Date logFin;
	private Date modIni;
	private Date modFin;
	
	public String getProveedor() {
		return proveedor;
	}
	public void setProveedor(String proveedor) {
		this.proveedor = proveedor;
	}
	public String getPo() {
		return po;
	}
	public void setPo(String po) {
		this.po = po;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public boolean isOnlyBackLog() {
		return onlyBackLog;
	}
	public void setOnlyBackLog(boolean onlyBackLog) {
		this.onlyBackLog = onlyBackLog;
	}
	public Date getLogIni() {
		return logIni;
	}
	public void setLogIni(Date logIni) {
		this.logIni = logIni;
	}
	public Date getLogFin() {
		return logFin;
	}
	public void setLogFin(Date logFin) {
		this.logFin = logFin;
	}
	public Date getModIni() {
		return modIni;
	}
	public void setModIni(Date modIni) {
		this.modIni = modIni;
	}
	public Date getModFin() {
		return modFin;
	}
	public void setModFin(Date modFin) {
		this.modFin = modFin;
	}
	
}
