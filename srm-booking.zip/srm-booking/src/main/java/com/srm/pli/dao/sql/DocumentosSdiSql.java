package com.srm.pli.dao.sql;

public class DocumentosSdiSql {

	public static final String SELECT_FOLIO_ANALISIS;
	private static final String SELECT_FOLIOS_ANALISIS_DIAS;
	public static final String SELECT_FOLIOS_ANALISIS_BOOKING;
	public static final String SELECT_FOLIOS_ANALISIS_CORRECION_BOOKING;
	public static final String SELECT_FOLIOS_RECHAZADOS_SDI_REPORTE;
	public static final String SELECT_FOLIOS_CONFIRMACION_FINAL_MAYOR_1_DIA_SIN_PRIMER_ENVIO_DE_DOCUMENTOS;
	public static final String UPDATE_DISPONIBILIDAD_OTROS_DOCUMENTOS;

	static {
		StringBuilder sql = new StringBuilder();
		sql.append("SELECT s.proveedor ");
		sql.append("       , s.booking ");
		sql.append("       , s.eta ");
		sql.append("FROM   cdisar s ");
		sql.append("WHERE  s.folio = ?");
		SELECT_FOLIO_ANALISIS = sql.toString();

		sql = new StringBuilder();
		sql.append("SELECT s.proveedor ");
		sql.append("       , s.booking ");
		sql.append("       , s.eta ");
		sql.append("       , s.folio ");
		sql.append(" FROM cdisar s ");
		sql.append("		LEFT JOIN cdidocumentossdi d ");
		sql.append("			ON s.proveedor = d.proveedor ");
		sql.append("                 AND s.booking = d.booking ");
		sql.append("                 AND s.versionsetdocumentos = d.versionsdi ");
		sql.append("        INNER JOIN cdiProveedorModulo pm ON s.proveedor = pm.supplier ");
		sql.append(" WHERE ISNULL(s.booking, '') <> '' ");
		sql.append("	AND ?tipo ");
		sql.append("	AND CONVERT(VARCHAR(8), ");
		sql.append("				CONVERT(smalldatetime, ");
		sql.append("						CAST( ");
		sql.append("							(CASE ");
		sql.append("								 WHEN s.etdFinal IS NOT NULL AND s.etdFinal > 20000101 ");
		sql.append("									THEN s.etdFinal ");
		sql.append("									ELSE s.fechaEmbarque ");
		sql.append("							  END) ");
		sql.append("						AS varchar ");
		sql.append("						)) + ?dias ");
		sql.append("		, 112) = CONVERT(VARCHAR(8), GETDATE(), 112) ");
		sql.append(" AND ( ");
		sql.append("			SELECT DISTINCT TOP 1 sd.material ");
		sql.append("			FROM cdiSARDetalle sd ");
		sql.append("				INNER JOIN cdiProductoCertificado c ");
		sql.append("					ON sd.material = c.material ");
		sql.append("			WHERE sd.folio = s.folio ");
		sql.append("	   ) IS NULL ");
		sql.append(" ORDER BY s.booking, s.folio DESC");
		SELECT_FOLIOS_ANALISIS_DIAS = sql.toString();

		sql = new StringBuilder();
		sql.append("SELECT s.proveedor ");
		sql.append("       , s.booking ");
		sql.append("       , s.eta ");
		sql.append("       , s.folio ");
		sql.append(" FROM cdisar s ");
		sql.append(" WHERE s.booking = ? AND s.proveedor  = ? ");
		sql.append(" ORDER BY s.booking, s.folio DESC");
		SELECT_FOLIOS_ANALISIS_BOOKING = sql.toString();
		
		sql = new StringBuilder();
		sql.append("SELECT s.proveedor ");
		sql.append("       , s.booking ");
		sql.append("       , s.eta ");
		sql.append("       , s.folio ");
		sql.append("	   , d.comentariosSDI ");
		sql.append("FROM cdisar s ");
		sql.append("		LEFT JOIN cdidocumentossdi d ");
		sql.append("			ON s.proveedor = d.proveedor ");
		sql.append("                 AND s.booking = d.booking ");
		sql.append("                 AND s.versionsetdocumentos = d.versionsdi ");
		sql.append("WHERE s.booking = ? AND s.proveedor = ? ");
		sql.append("ORDER BY s.booking, s.folio DESC");
		SELECT_FOLIOS_ANALISIS_CORRECION_BOOKING = sql.toString();
		
		sql = new StringBuilder();
		sql.append("SELECT s.proveedor , s.booking, s.eta, s.folio , ");
		sql.append("s.versionSetDocumentos,d.fechaRechazo,c.aprobado, ");
		sql.append("c.fechaAceptaProveedor,c.analista,s.prioridad, ");
		sql.append("det.esPedidoDirecto,det.centro,s.naviera,det.material ");
		sql.append(",det.po,det.posicion,det.condicionPago,s.consolidado,DATEDIFF(day,d.fechaRechazo,getdate()) as fecRec ");
		sql.append("FROM cdisar s ");
		sql.append("LEFT JOIN cdidocumentossdi d ");
		sql.append("ON s.proveedor = d.proveedor ");
		sql.append("AND s.booking = d.booking ");
		sql.append("AND s.versionsetdocumentos = d.versionsdi ");
		sql.append("INNER JOIN cdiControlSDI c ");
		sql.append("ON s.proveedor = c.proveedor ");
		sql.append("and s.booking = c.booking ");
		sql.append("LEFT JOIN cdiSARDetalle det ");
		sql.append("ON s.folio = det.folio ");
		sql.append("WHERE s.versionSetDocumentos is not null  ");
		sql.append("and s.versionSetDocumentos > 0 ");
		sql.append("and d.fechaRechazo is not null ");
		sql.append("and c.aprobado = 0 ");
		sql.append(" ORDER BY s.proveedor ,s.booking, s.folio DESC ");
		SELECT_FOLIOS_RECHAZADOS_SDI_REPORTE = sql.toString();
		
		sql = new StringBuilder();
		sql.append(" SELECT DISTINCT s.proveedor ");
		sql.append("       , s.booking ");
		sql.append("       , s.eta ");
		sql.append("       , s.folio ");
		sql.append(" FROM cdisar s ");
		sql.append("        INNER JOIN cdiProveedorModulo pm ON s.proveedor = pm.supplier AND s.fechaConfirmacionFinal >= pm.createDate ");
		sql.append("		INNER JOIN cdiSARDetalle sd ON s.folio = sd.folio ");
		sql.append("		INNER JOIN cdiProductoCertificado c ON sd.material = c.material ");
		sql.append("		LEFT JOIN cdidocumentossdi d ON s.proveedor = d.proveedor ");
		sql.append("                 AND s.booking = d.booking ");
		sql.append("                 AND s.versionsetdocumentos = d.versionsdi");
		sql.append(" WHERE  Isnull(s.booking, '') <> '' ");
		sql.append("       AND d.fechaaceptaproveedor IS NULL ");
		sql.append("       AND d.fecharechazo IS NULL ");
		sql.append("       AND Dateadd(day, Datediff(day, 0, s.fechaconfirmacionfinal), 0) <= ");
		sql.append("           Dateadd(day, Datediff(day, 0, Getdate() - 1), 0) ");
		sql.append(" ORDER  BY s.folio DESC ");
		SELECT_FOLIOS_CONFIRMACION_FINAL_MAYOR_1_DIA_SIN_PRIMER_ENVIO_DE_DOCUMENTOS = sql.toString();
		
		sql = new StringBuilder();
		sql.append(" DECLARE @id int = ?; ");
		sql.append(" UPDATE cdiDocumentosSDI ");
		sql.append("	SET tieneOtrosDocumentos ");
		sql.append("		= CAST((SELECT COUNT(rutaArchivo) archivos ");
		sql.append("						FROM cdi_otros_documentos i ");
		sql.append("						WHERE i.id = @id ");
		sql.append("						AND (i.eliminado IS NULL OR i.eliminado = 0) ");
		sql.append("					) AS bit) ");
		sql.append(" WHERE id = @id");
		UPDATE_DISPONIBILIDAD_OTROS_DOCUMENTOS = sql.toString();		
	}

	private DocumentosSdiSql() {
	}

	public static String getSelectFoliosAnalisisDias(DocumentosSdiDaoEnum accion) {
		String sql = null;
		if (accion == DocumentosSdiDaoEnum.SOLICITUD_DOC_AVISO_0_DIAS
				|| accion == DocumentosSdiDaoEnum.SOLICITUD_DOC_AVISO_3_DIAS
				|| accion == DocumentosSdiDaoEnum.SOLICITUD_DOC_AVISO_5_DIAS) {
			sql = SELECT_FOLIOS_ANALISIS_DIAS.replace("?tipo",
					" d.fechaAceptaProveedor IS NULL AND d.fechaRechazo IS NULL ");
			switch (accion) {
			case SOLICITUD_DOC_AVISO_0_DIAS:
				sql = sql.replace("?dias", "0");
				break;
			case SOLICITUD_DOC_AVISO_3_DIAS:
				sql = sql.replace("?dias", "3");
				break;
			case SOLICITUD_DOC_AVISO_5_DIAS:
				sql = sql.replace("?dias", "5");
				break;
			default:
				break;
			}
		}
		return sql;
	}
	
	public enum DocumentosSdiDaoEnum {
		SOLICITUD_DOC_AVISO_0_DIAS, 
		SOLICITUD_DOC_AVISO_3_DIAS, 
		SOLICITUD_DOC_AVISO_5_DIAS, 
		SOLICITUD_DOC_CORRECCION_AVISO_0_DIAS, 
		SOLICITUD_DOC_CORRECCION_AVISO_2_DIAS, 
		SOLICITUD_DOC_CORRECCION_AVISO_4_DIAS;
	}

}
