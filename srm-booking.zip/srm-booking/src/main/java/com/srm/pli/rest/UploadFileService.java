package com.srm.pli.rest;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.srm.pli.helper.FileHelper;
import com.srm.pli.utils.Constantes;
import com.sun.jersey.core.header.FormDataContentDisposition;
import com.sun.jersey.multipart.BodyPart;
import com.sun.jersey.multipart.FormDataBodyPart;
import com.sun.jersey.multipart.FormDataMultiPart;
import com.truper.utils.string.UtilsString;

@Path("/file")
public class UploadFileService {

	public static final String PATH_FILE_UPLOAD = "/file/upload/";

	/***
	 * - Metodo encargado de guardar 1 o mas archivos. <br>
	 * <br>
	 * - Se debe usar de la siguiente manera, enviar un formulario con los archivos,
	 * una lista con los nombres de los input de los archivos "names" y el "path"
	 * que sera el subdirectorio donde se guardara.
	 * 
	 * @param multiPart
	 * @return subpath
	 * @author rsantiagor
	 */
	@POST
	@Path("/upload")
	@Consumes(MediaType.MULTIPART_FORM_DATA)
	public Response uploadFile(FormDataMultiPart multiPart) {

		FormDataBodyPart pathPart = multiPart.getField("path");
		String pathParam = pathPart.getValue();
		List<FormDataBodyPart> names = multiPart.getFields("names");
		try {
			for (FormDataBodyPart name : names) {
				String nombre = name.getValue();
				if (!UtilsString.isStringValida(nombre))
					continue;
				FormDataBodyPart file = multiPart.getField(nombre);
				String contentType = file.getMediaType().getSubtype().toString();
				if (file == null)
					continue;
				InputStream is = file.getValueAs(InputStream.class);
				FormDataContentDisposition f = file.getFormDataContentDisposition();
				String[] aux = f.getFileName().split("\\.");

				/*
				 * if(!contentType.equalsIgnoreCase(aux[aux.length - 1])) { throw new
				 * Exception("Content Type error."); }
				 * 
				 * validateExtension(aux[aux.length - 1]);
				 */

				String fileName = nombre + "." + aux[aux.length - 1];
				writeToFile(is, pathParam, fileName);
			}

		} catch (Exception e) {
			return Response.status(500).entity(e.getMessage()).build();
		}
		String output = "File uploaded to : " + pathParam;
		return Response.status(200).entity(output).build();
	}

	private void validateExtension(String extension) throws Exception {
		if (Constantes.EXTEN_JPEG.equalsIgnoreCase(extension) || Constantes.EXTEN_JPG.equalsIgnoreCase(extension)
				|| Constantes.EXTEN_PNG.equalsIgnoreCase(extension)
				|| Constantes.EXTEN_PDF.equalsIgnoreCase(extension)) {

		} else {
			throw new Exception("Content Type error.");
		}

	}

	private void writeToFile(InputStream uploadedInputStream, String uploadedFileLocation, String fileName)
			throws Exception {
		try {
			String pathFinal = FileHelper.getInstance().creaDirectorioLocal(PATH_FILE_UPLOAD + uploadedFileLocation);
			String archivo = UtilsString.append(pathFinal, "/", fileName);
			OutputStream out = new FileOutputStream(new File(archivo));
			int read = 0;
			byte[] bytes = new byte[1024];
			out = new FileOutputStream(new File(archivo));
			while ((read = uploadedInputStream.read(bytes)) != -1) {
				out.write(bytes, 0, read);
			}
			out.flush();
			out.close();
		} catch (IOException e) {
			e.printStackTrace();
			throw new Exception(e.getMessage());
		}
	}
}
