package com.srm.pli.bo;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.ResourceBundle;

import org.apache.commons.lang3.StringEscapeUtils;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.jfree.util.Log;

import com.srm.pli.dao.SAR_CDI_DAO;
import com.srm.pli.helper.FormatSAR;
import com.srm.pli.helper.FormatSARHelper;
import com.srm.pli.utils.Constantes;
import com.srm.pli.utils.FuncionesComunesPLI;
import com.srm.pli.utils.PropertiesDb;
import com.truper.businessEntity.BeanTiposDeCambio;
import com.truper.businessEntity.ContenedorCDI;
import com.truper.businessEntity.ProductoBean;
import com.truper.businessEntity.SAR;
import com.truper.businessEntity.SARDetalle;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Getter
@Setter
@ToString(callSuper = true)
public class SarBO extends SAR implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -7663309896234437963L;
	
	private static PropertiesDb propertiesDb = PropertiesDb.getInstance();
	
	private int cumplimiento;
	private String fase;
	
	/** sarBOAntesFormato  esta variable la usamos para guardar una copia del BO dentro del formateo para no formatear 
	 * multiples veces al recorrer una lista o acciones similares */
	private SarBO  	sarBOAntesFormato;
	/** formatSARFormatoTemp objeto ya formateado que voy a reenviar en caso de que el BO no sufriera cambios, 
	 * ahorrandome tiempo de formateo*/
	private FormatSAR formatSARFormatoTemp;
	private int diasEnStatus;
	private int fechaEnStatus;
	private boolean tienePOsEliminadas;
	private boolean tieneOthersEliminadas;
	private boolean tieneDocumentos;
	private Boolean tieneFOCs;
	private BigDecimal totalCubicaje;
	private BigDecimal totalPesoNeto;
	private BigDecimal totalPesoBruto;
	private int totalCartones;
	private int totalCantidad;
	private boolean tieneProblemas;
	private String sarsABuscar;
	private ArrayList<String> erroresDocumentos;
	private boolean cierraConfirmacionFinal;
	private boolean acceptedIDAValidation;
	private Integer nuevaFechaETD_IDA;
	private Boolean tieneTSRAbiertos;
	private Boolean tieneTSRResueltos;
	private String bookingUpdateSupplier;
	private int carrierUpdateSupplier;
	private Date dateETDFinalUpdateSupplier;
	private String carrierNameUpdateSupplier;
	
	private Boolean resetUpdateSupplier;
	private Date dateUpdateSupplier;
	private boolean requestSupplier;
	private String estatusRequestSupplier;
	private String commentsRequestSupplier;
	private Boolean approvalGRDlineacion;
	private String messageGRDrechazo;
	private String messageGRDaprobacion;
	
	private Boolean goodsAreReady;
	private Date goodsReadyDate;
	private String goodsReadyDateStr;
	private BigDecimal cantidadUnidadMedida;
	private BigDecimal factorCantidadUnidadMedida;
	private String intervaloEstatus;
	private String obs_reject;
	private Boolean gdrEnRevision;
	private Boolean esRechazado;
	private String referenciaContenedorProveedor;

	private Integer tinyFechIniProfileApproved;
	private Integer guideline;
	private Boolean approvedConfirmationManager;
	private Boolean approvedSrManager;
	private Boolean approvedDirector;
	private Boolean approvedOverStock;
	private String commentProfiles;
	private Boolean releaseRequirementsBC;
	private Integer statusAnteriorGRD;
	
	private String commentDeleteProjection;
	
	public SarBO (){
		super();
	}
	
	public SarBO (int folio, String proveedor, Integer tipoContenedor){
		super(folio, proveedor, tipoContenedor);
	}
	public SarBO (String concatenado, Integer folioConsolidado){
		super(concatenado, folioConsolidado);
	}

	public SarBO clone(){
		SarBO nuevo = new SarBO();
		nuevo.setFolio(this.getFolio());
		nuevo.setAceptadoConDiferencias(this.getAceptadoConDiferencias());
		nuevo.setAprobadoProveedor(this.getAprobadoProveedor()); 
		/////////nuevo.setdetalle = this.getdetalle
		nuevo.setEsMultiple(this.getEsMultiple()); 	
		nuevo.setFoliosMultiples(this.getFoliosMultiples()); 
		nuevo.setProveedor(this.getProveedor()); 
		nuevo.setMandante(this.getMandante());
		nuevo.setStatus(this.getStatus()); 
		nuevo.setPaisDestino(this.getPaisDestino()); 
		nuevo.setBooking(this.getBooking()); 
		nuevo.setAvion(this.getAvion()); 
		nuevo.setBackorderPronosticadoTot(this.getBackorderPronosticadoTot()); 
		nuevo.setOverStockTot(this.getOverStockTot());
		nuevo.setBarcoSugerido(this.getBarcoSugerido()); 
		nuevo.setBl(this.getBl()); 
		nuevo.setCargoAProveedor(this.getCargoAProveedor()); 
		nuevo.setColorWarning(this.getColorWarning()); 
		nuevo.setComentarioCancelacion(this.getComentarioCancelacion()); 
		nuevo.setComentarioPlanner(this.getComentarioPlanner()); 
		nuevo.setComentarioShipping(this.getComentarioShipping());
		nuevo.setComentarioTruperBooking(this.getComentarioTruperBooking()); 
		nuevo.setConsolidado(this.getConsolidado()); 
		nuevo.setContenedor(this.getContenedor()); 
		nuevo.setCreationDate(this.getCreationDate()); 
		nuevo.setEsAereo(this.getEsAereo());
		nuevo.setEsSinPO(this.getEsSinPO());
		nuevo.setEta(this.getEta());
		nuevo.setEtdProveedor(this.getEtdProveedor());
		nuevo.setEtdPlanner(this.getEtdPlanner()); 
		nuevo.setEtdReal(this.getEtdReal());
		nuevo.setEtdModificada(this.getEtdModificada());
		nuevo.setFechaBl(this.getFechaBl()); 
		nuevo.setFechaEmbarque(this.getFechaEmbarque());
		nuevo.setFechaEmbarqueFin(this.getFechaEmbarqueFin()); 
		nuevo.setFechaEmbarqueIni(this.getFechaEmbarqueIni()); 
		nuevo.setFechaSolicitudDeAprobacion(this.getFechaSolicitudDeAprobacion()); 
		nuevo.setFechaUltimaAprobacionRechazo(this.getFechaUltimaAprobacionRechazo());
		nuevo.setFolioConsolidado(this.getFolioConsolidado());
		nuevo.setIda(this.getIda());
		nuevo.setIncluyeSarConsol(this.getIncluyeSarConsol()); 
		nuevo.setListaPos(this.getListaPos()); 
		nuevo.setLlegadaAvion(this.getLlegadaAvion());
		nuevo.setModificadoProveedor(this.getModificadoProveedor()); 
		nuevo.setNaviera(this.getNaviera());
		nuevo.setOtraAerolinea(this.getOtraAerolinea()); 
		nuevo.setPaisDestino(this.getPaisDestino()); 
		nuevo.setPeso(this.getPeso() );
		nuevo.setPesoConfirmado(this.getPesoConfirmado()); 
		nuevo.setPrioridad(this.getPrioridad());
		nuevo.setProveedor(this.getProveedor());
		nuevo.setPuertoDescarga(this.getPuertoDescarga());
		nuevo.setPuertoOrigen(this.getPuertoOrigen()); 
		nuevo.setTextoWarning(this.getTextoWarning()); 
		nuevo.setTieneBL(this.getTieneBL()); 
		nuevo.setTieneFacura(this.getTieneFacura());
		nuevo.setTienePackingList(this.getTienePackingList());
		nuevo.setTipoContenedor(this.getTipoContenedor());
		nuevo.setTipoRetraso(this.getTipoRetraso()); 
		nuevo.setTransporte(this.getTransporte());
		nuevo.setUsuarioApruebaRechaza(this.getUsuarioApruebaRechaza()); 
		nuevo.setUsuarioSolicitudDeAprobacion(this.getUsuarioSolicitudDeAprobacion());
		nuevo.setValorEmbarque(this.getValorEmbarque()); 
		nuevo.setValorEmbarqueConfirmado(this.getValorEmbarqueConfirmado()); 
		nuevo.setViaje(this.getViaje()); 
		nuevo.setVolumen(this.getVolumen()); 
		nuevo.setVolumenConfirmado(this.getVolumenConfirmado()); 
		nuevo.setLstChat(this.getLstChat());
		nuevo.setTieneDiferenciaMRP(this.getTieneDiferenciaMRP());
		nuevo.setCargaArchivoMRP(this.getCargaArchivoMRP());
		nuevo.setNombreArchivoMRP(this.getNombreArchivoMRP());
		nuevo.setPiDate(this.getPiDate());
		nuevo.setSafetyStock(this.getSafetyStock());
		nuevo.setForecastModel(this.getForecastModel());
		nuevo.setVar8Sem(this.getVar8Sem());
		nuevo.setNeedsAuthImpDir(this.getNeedsAuthImpDir());
		nuevo.setAprobadoDirImportaciones(this.getAprobadoDirImportaciones());
		nuevo.setUserApruebaDirImportaciones(this.getUserApruebaDirImportaciones());
		nuevo.setFechaAprobacionDirImportaciones(this.getFechaAprobacionDirImportaciones());
		nuevo.setCommentForImpDir(this.getCommentForImpDir());
		nuevo.setImpDirComments(this.getImpDirComments());
		nuevo.setAdelantoAtrasoETDImpDir(this.getAdelantoAtrasoETDImpDir());
		nuevo.setNotificacionMRP(this.getNotificacionMRP());
		nuevo.setEnRevisionConfirmFinal(this.getEnRevisionConfirmFinal());
		nuevo.setTieneProdsNuevos(this.getTieneProdsNuevos());
		nuevo.setTieneSimulador(this.getTieneSimulador());
		nuevo.setPreciosLiberados(this.getPreciosLiberados());
		nuevo.setPreciosEnRevision(this.getPreciosEnRevision());
		nuevo.setNeedsAuthPlanningMgr(this.getNeedsAuthPlanningMgr());
		nuevo.setNuevaFechaETD_IDA(this.getNuevaFechaETD_IDA());
		nuevo.setCantidadUnidadMedida(this.getCantidadUnidadMedida());
		nuevo.setFactorCantidadUnidadMedida(this.getFactorCantidadUnidadMedida());
		nuevo.setObs_reject(this.getObs_reject());
		nuevo.setGoodsAreReady(this.goodsAreReady);
		nuevo.setGoodsReadyDate(this.goodsReadyDate);
		nuevo.setGoodsReadyDateStr(this.goodsReadyDateStr);
		nuevo.setGdrEnRevision(this.gdrEnRevision);
		nuevo.setReferenciaContenedorProveedor(this.referenciaContenedorProveedor);
		nuevo.setGuideline(this.guideline);
		nuevo.setTinyFechIniProfileApproved(this.tinyFechIniProfileApproved);
		nuevo.setApprovedConfirmationManager(this.approvedConfirmationManager);
		nuevo.setApprovedSrManager(this.approvedSrManager);
		nuevo.setApprovedDirector(this.approvedDirector);
		nuevo.setApprovedOverStock(this.approvedOverStock);
		nuevo.setCommentProfiles(this.commentProfiles);
		nuevo.setReleaseRequirementsBC(this.releaseRequirementsBC);
		
		nuevo.setMessageGRDrechazo(this.messageGRDrechazo);
		nuevo.setMessageGRDaprobacion(this.messageGRDaprobacion);
		nuevo.setApprovalGRDlineacion(this.approvalGRDlineacion);
		
		return nuevo;
	}
	
	public void addDetalle(SARDetalle detalle){
		if(getDetalle() == null){
			setDetalle(new ArrayList<SARDetalle>());
		}
		getDetalle().add(detalle);
		
		if(detalle.getPesoProveedor() != null){
			setPeso(getPeso() + detalle.getPesoProveedor());
		}else{
			setPeso(getPeso() + detalle.getPesoPO());
		}
		
		if(detalle.getVolumenProveedor() != null){
			setVolumen(getVolumen() + detalle.getVolumenProveedor());
		}else{
			setVolumen(getVolumen() + detalle.getVolumenPO());
		}
		
		if(detalle.getPesoModificado() != null){
			setPesoConfirmado(getPesoConfirmado() + detalle.getPesoModificado());
		}
		
		if(detalle.getVolumenModificado() != null){
			setVolumenConfirmado(getVolumenConfirmado() + detalle.getVolumenModificado());
		}
		
		ProductoBean prod = FuncionesComunesPLI.productos.get(detalle.getMaterial().toString());
		if(prod != null){
			setValorEmbarque(getValorEmbarque().add(new BigDecimal(getCostoFOB(String.valueOf(detalle.getMaterial())) * detalle.getCantidad())));
			if(detalle.getCantidadModificada() != null){
				setValorEmbarqueConfirmado(getValorEmbarqueConfirmado().add(new BigDecimal(getCostoFOB(String.valueOf(detalle.getMaterial())) * detalle.getCantidadModificada())));
			}
		}
	}
	
	public static double getCostoFOB(String material) {
		if(FuncionesComunesPLI.productos==null) {
			Log.info("Problemas con el catalogo de productos");
		}
		if(material==null) {
			Log.info("Problemas con el elemento de material " + material);
		}else {
			Log.info("Material a consultar " + material);
		}
		ProductoBean prod = FuncionesComunesPLI.productos.get(material);
		if(prod == null){
			return 0;
		} else {
			String moneda = prod.getMonedaCostoFOB();
			Log.info("Moneda a consultar " + moneda);
			double costoFOB = prod.getCostoFOB();
			if (!"USD".equals(moneda) && !"MXN".equals(moneda)) {
				BeanTiposDeCambio btdc = mapaTipoMoneda.get(moneda+"|MXN");
				if (btdc != null) {
					double exchangeRate = btdc.getExchangeRate() == null ? 0.0 : btdc.getExchangeRate().doubleValue();
					costoFOB = costoFOB * exchangeRate;
					Log.info("Tipo de cambio correcto " + moneda+"|MXN" + " |  "+btdc.getOriginCurrency()+"<->"+btdc.getDestinationCurrency()
						+" $"+exchangeRate + " COSTO "+costoFOB);
					
				}
			}
			
			if (!"USD".equals(moneda)) {
				BeanTiposDeCambio btdc = mapaTipoMoneda.get("USD|MXN");
				if (btdc != null) {
					double exchangeRate = btdc.getExchangeRate() == null ? 1.0 : btdc.getExchangeRate().doubleValue();
					costoFOB = costoFOB / exchangeRate;
					Log.info("Tipo de cambio correcto " + "USD|MXN" + " |  "+btdc.getOriginCurrency()+"<->"+btdc.getDestinationCurrency()
						+" $"+exchangeRate+ " COSTO "+costoFOB);
				}
			}
			
			return costoFOB;
		}
	}
	
	public void addDetalleOthers(SARDetalle detalle){
		if(getDetalleOtros() == null){
			setDetalleOtros(new ArrayList<SARDetalle>());
		}
		getDetalleOtros().add(detalle);
		
		if(detalle.getPesoProveedor() != null){
			setPeso(getPeso() + detalle.getPesoProveedor());
		}else{
			setPeso(getPeso() + detalle.getPesoPO());
		}
		
		if(detalle.getVolumenProveedor() != null){
			setVolumen(getVolumen() + detalle.getVolumenProveedor());
		}else{
			setVolumen(getVolumen() + detalle.getVolumenPO());
		}
		
	}
	
	public boolean esValidoParaSolicitarAprobacion(int contenedor, boolean esAereo) {
		FuncionesComunesPLI.cargaContenedores(false);
		if(contenedor == SAR.LCL || esAereo){
			return true;
		}
		ContenedorCDI cont = FuncionesComunesPLI.mapaContenedores.get(contenedor);
		if(cont != null){			
			if(cont.getClave() == 1){	
				return getPeso() <= cont.getPesoMaximo() && getPeso() >= cont.getPesoMinimo() && getVolumen() <= cont.getVolumenMaximo() && getVolumen() >= cont.getVolumenMinimo();
			}else{
				return  getVolumen() <= cont.getVolumenMaximo() && getVolumen() >= cont.getVolumenMinimo() && getPeso() <= cont.getPesoMaximo() && getPeso() >= cont.getPesoMinimo();
			}
		}
		return false;
	}

	public boolean esValidoParaStatus(int status){
		GregorianCalendar gcHoy = new GregorianCalendar();
		GregorianCalendar gcRechazoMas30 = null;
		
		if(getFechaUltimaAprobacionRechazo() == null || getFechaUltimaAprobacionRechazo() == 0){
			gcRechazoMas30 = new GregorianCalendar();
			gcRechazoMas30.add(Calendar.DATE, -1);
		}else{
			gcRechazoMas30 = FuncionesComunesPLI.int2GregorianCalendar(getFechaUltimaAprobacionRechazo());
			gcRechazoMas30.add(Calendar.DATE, 30);
		}
		
		return (status == -1 ) || //status -1
		(status == 0 && getStatus() == STATUS_SIN_SOLICITUD_APROBACION) || //status 0
		(status == 1 && (getStatus() == SAR.STATUS_ESPERA_APROBACION_PLANEACION || getStatus() == SAR.STATUS_ESPERA_APROBACION_SHIPPING)) ||
		(status == 3 && getStatus() == SAR.STATUS_APROBADO) ||
		(status == 7 && getStatus() == SAR.STATUS_RECHAZADO) ||
		(getStatus() == SAR.STATUS_LIBERATION_BO_CONFIRMATION) ||
		(getStatus() == SAR.STATUS_LIBERATION_BO_CONFIRMATION_MR) ||
		(getStatus() == SAR.STATUS_LIBERATION_BO_CONFIRMATION_BO) ||
		(status == 4 && getStatus() == SAR.STATUS_CANCELADO && gcHoy.before(gcRechazoMas30));
	}

	public String getDescripcion() {
		FuncionesComunesPLI.cargaContenedores(false);
		return getFolioCompleto() + " " + (getTipoContenedor() != 4 ? "(FC" : "(") + (FuncionesComunesPLI.mapaContenedores.get(getTipoContenedor()) != null ? 
				FuncionesComunesPLI.mapaContenedores.get(getTipoContenedor()).getNombre() : "-") + " - " + FuncionesComunesPLI.formatea(getPeso()) + "kg - " + FuncionesComunesPLI.formatea(getVolumen()) + "m3)";
	}
	
	//TODO revisar si se tiene que borrar
	/**
	 * Metodo que me va a ayudar a identificar si es un SAR mandante y llenar de forma logica sus datos de los 
	 * Folios dependientes de el, asi mismo voy a llegar estos campos en los SAR's dependientes para que todos esten
	 * Con la misma informacion
	 * @deprecated
	 */
	public  void llenaDatosMandante(){
		if(esMultiple() != null && esMultiple() && getFolio().compareTo(getMandante()) == 0){
			///TODO mandar este metodo a un metodo en FUnciones comunes.
			//SAR_CDI_DAO dao = new SAR_CDI_DAO();
			//SAR sar = new SAR();
			
			//dao.selectSar();
		}			
	}
	
	public String armaFolioVista() throws ClassNotFoundException {
		Boolean sarImportado = esImportado(this);
		StringBuilder sb = new StringBuilder();
		
		sb.append(getConsolidado() != null && getConsolidado() ? "C" : "F");
		sb.append(getFolio());
		sb.append((sarImportado != null && sarImportado) ? detMercImportado
				: detMercNoImportado);
		if(getRevision() != null && getRevision() > 0  ){
			sb.append("R"+getRevision());
		}
		
		if(getNumRevFinal() != null && getNumRevFinal() > 0) {
			sb.append("M"+getNumRevFinal());
		}
		return sb.toString();
	}
	
	public String accesoALeyendaStatus(Locale locale) {
		String leyenda;
		leyenda = dameLeyendaStatus(locale);
		return leyenda;
	}
	
	public String dameLeyendaStatus(Locale locale) {
		String statusLegend = "";
		int status = getStatus();
		CdiDocumentBO doc = new CdiDocumentBO();
		doc.setSar(getFolio());
		ArrayList<CdiDocumentBO> lista = new ArrayList<CdiDocumentBO>();
		ResourceBundle messages = ResourceBundle.getBundle("com.srm.pli.i18n.text", locale);
		try {
			lista = SAR_CDI_DAO.getInstance().selectDocumentosFact(doc); 
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		boolean fac = false,bl = false,pkl = false, tienetodosDoc = false;
		for(CdiDocumentBO d :lista){
			if("FAC".equals(d.getTipo())){
				fac = true;
			}
			if("BL".equals(d.getTipo())){
				bl = true;
			}
			if("PKL".equals(d.getTipo())){
				pkl = true;
			}
		}
		if (fac && bl && pkl) {
			tienetodosDoc = true;
		}
		if (getFolio().equals(getFolioConsolidado())) {
			if (getStatus() == STATUS_APROBADO ) {
				statusLegend = messages.getString("general.status.appByShipping");
			} else if (getStatus() == STATUS_EMBARCADO) {
				statusLegend = messages.getString("general.status.shipped");
			}  else {
				statusLegend = "-";
			}
		} else {
			if ((getStatus() == STATUS_APROBADO || getStatus() == STATUS_EMBARCADO) && (esModificadoProveedor() != null && esModificadoProveedor()) &&
					(getAceptadoConDiferencias() == null || !getAceptadoConDiferencias())) {
				statusLegend = messages.getString("general.status.onHold");
	//		} else if (getStatus() == STATUS_APROBADO && getAprobadoProveedor()!=null && getAprobadoProveedor()) {
	//			statusLegend = ingles ? "On Hold Booking" : "En espera Booking";
			} else if (status == STATUS_SIN_SOLICITUD_APROBACION) {
				statusLegend = messages.getString("general.status.initial");
			} else if (getStatus() == STATUS_EMBARCADO && (getAprobadoProveedor() == null   || !getAprobadoProveedor())) {
				statusLegend = messages.getString("general.status.shipped");
			} else if (status == STATUS_CANCELADO) {
				statusLegend = messages.getString("general.status.cancelled");
			} else if (status == STATUS_RECHAZADO) {
				statusLegend = messages.getString("general.status.rejected");
			} else if (status == STATUS_ESPERA_APROBACION_PLANEACION) {
				statusLegend = messages.getString("general.status.generated");
			} else if (status == STATUS_ESPERA_APROBACION_SHIPPING) {
				statusLegend = messages.getString("general.status.appByPlanning");
			} else if (getStatus() == STATUS_APROBADO && (getFolioConsolidado() == null || getFolioConsolidado() == 0)) {
				statusLegend = messages.getString("general.status.appByShipping");
			} else if (getStatus() < STATUS_EMBARCADO && getFolioConsolidado() != null && getFolioConsolidado() > 0) {
				statusLegend = messages.getString("general.status.consol");
			} else if (getStatus() == STATUS_EMBARCADO && getAprobadoProveedor() != null && getAprobadoProveedor()) {
				statusLegend = messages.getString("general.status.sarConfirm");
			} else if (getStatus() == STATUS_EN_REVISION_PRECIOS) {
				statusLegend = messages.getString("general.status.priceRelease");
			}
			/* else if (getStatus() == STATUS_EMBARCADO && tienetodosDoc){
				statusLegend = messages.getString("general.status.docsLoaded");
			} else if (getStatus() == STATUS_DOCUMENTOS_SDI && (esAprobadoSDI()== null || !esAprobadoSDI())) {
				statusLegend = messages.getString("general.status.docsAppReq");
			} else if (getStatus() == STATUS_DOCUMENTOS_SDI && esAprobadoSDI()!= null && esAprobadoSDI()) {
				statusLegend = messages.getString("general.status.docsApproved");
			}*/ else {
				statusLegend = "-";
			}
		}
				
		return StringEscapeUtils.escapeHtml3(statusLegend);
	}
	
	public void setDetalleBO(List<SarDetalleBO> lstDetBO) {
		ArrayList<SARDetalle> lstSarDet = new ArrayList<SARDetalle>();
		if(lstDetBO != null) {
			for (SarDetalleBO detBO : lstDetBO ) {
				SARDetalle det = new SARDetalle();
				det.setAbc(detBO.getAbc());
				det.setPo(detBO.getPo());
				det.setPosicion(detBO.getPosicion());
				det.setMaterial(detBO.getMaterial());
				det.setMarca(detBO.getMarca());
				det.setCantidad(detBO.getCantidad());
				det.setPesoProveedor(detBO.getPesoProveedor());
				det.setVolumenProveedor(detBO.getVolumenProveedor());
				det.setFolio(detBO.getFolio());
				det.setCentro(detBO.getCentro());
				det.setPlaneador(detBO.getPlaneador());
				det.setNumeroDoc(detBO.getNumeroDoc());
				det.setCantidadModificada(detBO.getCantidadModificada());
				det.setPesoModificado(detBO.getPesoModificado());
				det.setVolumenModificado(detBO.getVolumenModificado());
				det.setCliente(detBO.getCliente());
				det.setPaisOrigen(detBO.getPaisOrigen());
				det.setCartones(detBO.getCartones());
				det.setCantidadXCarton(detBO.getCantidadXCarton());
				det.setPesoNetoPKL(detBO.getPesoNetoPKL());
				det.setPesoBrutoPKL(detBO.getPesoBrutoPKL());
				det.setCubicajePKL(detBO.getCubicajePKL());
				det.setPallet(detBO.getPallet());
				det.setCartonXPallet(detBO.getCartonXPallet());
				det.setUnidaMedida(detBO.getUnidaMedida());
				det.setCondicionPago(detBO.getCondicionPago());
				det.setMoneda(detBO.getMoneda());
				det.setPrecioUnitario(detBO.getPrecioUnitario());
				det.setPedidoDirecto(detBO.isPedidoDirecto());
				det.setValorEmbarque(detBO.getValorEmbarque());
				det.setDescripcion(detBO.getDescripcion());
				det.setPicoInventarioDeseado(detBO.getPicoInventarioDeseado());
				det.setInventaroAlArribo(detBO.getInventaroAlArribo());
				det.setBackorderPronosticado(detBO.getBackorderPronosticado());
				det.setDiasAlArribo(detBO.getDiasAlArribo());
				det.setDifVSPico(detBO.getDifVSPico());
				det.setDifDiasConfirm(detBO.getDifDiasConfirm());
				det.setDifPesoUserVSSistem(detBO.getDifPesoUserVSSistem());
				det.setDifVolumenUserVSSistem(detBO.getDifVolumenUserVSSistem());
				det.setDaysSafetyStock(detBO.getDaysSafetyStock());
				det.setVar8Semanas(detBO.getVar8Semanas());
				det.setVar8SemanasDirectos(detBO.getVar8SemanasDirectos());
				det.setFacturacionPedidosDirectos(detBO.getFacturacionPedidosDirectos());
				det.setFechaEtdProveedor(detBO.getFechaEtdProveedor());
				det.setFechaUltConfirm(detBO.getFechaUltConfirm());
				det.setOverStock(detBO.getOverStock());
				det.setNoEsPOCompleta(detBO.isNoEsPOCompleta());
				det.setTieneDiferenciasMRP(detBO.isTieneDiferenciasMRP());
				det.setPesoPO(detBO.getPesoPO());
				det.setVolumenPO(detBO.getVolumenPO());
				det.setFechaProforma(detBO.getFechaProforma());
				det.setCantidadTotalPO(detBO.getCantidadTotalPO());
				det.setTipoPron(detBO.getTipoPron());
				det.setStatusMRP(detBO.getStatusMRP());
				det.setTipoValidacionMRP(detBO.getTipoValidacionMRP());
				det.setTipoModificacion(detBO.getTipoModificacion());
				det.setCantidad100(detBO.getCantidad100());
				det.setPeso100(detBO.getPeso100());
				det.setVolumen100(detBO.getVolumen100());
				det.setBalanceAction(detBO.isBalanceAction());
				det.setNeedsAuthPlanningMgr(detBO.getNeedsAuthPlanningMgr());
				det.setAlmacen(detBO.getAlmacen());
				det.setCantidadUnidadMedida(detBO.getCantidadUnidadMedida());
				det.setFactorCantidadUnidadMedida(detBO.getFactorCantidadUnidadMedida());
			    det.setDescripcionComplementoFactura(detBO.getDescripcionComplementoFactura());			
				lstSarDet.add(det);
			}
		}
		super.setDetalle(lstSarDet);
	}
	
	public void setDetalleOthers(List<SarDetalleBO> lstDetOthers) {
		ArrayList<SARDetalle> lstSarDet = new ArrayList<SARDetalle>();
		for (SarDetalleBO detOthers : lstDetOthers ) {
			SARDetalle det = new SARDetalle();
			det.setPo(detOthers.getPo());
			det.setPosicion(detOthers.getPosicion());
			det.setDescripcion(detOthers.getDescripcion());
			det.setCantidad(detOthers.getCantidad());
			det.setPesoProveedor(detOthers.getPesoProveedor());
			det.setVolumenProveedor(detOthers.getVolumenProveedor());
			det.setCantidadModificada(detOthers.getCantidadModificada());
			det.setPesoModificado(detOthers.getPesoModificado());
			det.setVolumenModificado(detOthers.getVolumenModificado());
			det.setFolio(detOthers.getFolio());
			det.setTipoModificacion(detOthers.getTipoModificacion());
			det.setNeedsAuthPlanningMgr(detOthers.getNeedsAuthPlanningMgr());
			det.setMarca(detOthers.getMarca());
			det.setMaterial(detOthers.getMaterial());
			det.setPesoBrutoPKL(detOthers.getPesoBrutoPKL());
			det.setPesoNetoPKL(detOthers.getPesoNetoPKL());
			det.setCubicajePKL(detOthers.getCubicajePKL());
			det.setCartones(detOthers.getCartones());
			det.setPoOtherItem(detOthers.getPoOtherItem());
			det.setCondicionPago(detOthers.getCondicionPago());
			det.setPrecioUnitario(detOthers.getPrecioUnitario());
			det.setUnidaMedida(detOthers.getUnidaMedida());
			det.setPoOtherItem(detOthers.getPoOtherItem());
			det.setCantidadUnidadMedida(detOthers.getCantidadUnidadMedida());
			det.setFactorCantidadUnidadMedida(detOthers.getFactorCantidadUnidadMedida());
			lstSarDet.add(det);
		}
		super.setDetalleOtros(lstSarDet);
	}
	
	public ArrayList<SarDetalleBO> getDetalleBO() {
		ArrayList<SarDetalleBO> lstSarDetBO = new ArrayList<SarDetalleBO>();
		ArrayList<SARDetalle> lstSarDet = getDetalle();
		if(lstSarDet == null){
			return null;
		}
		
		for (SARDetalle det : lstSarDet ) {
			SarDetalleBO detBO = new SarDetalleBO();
			detBO.setAbc(det.getAbc());
			detBO.setPo(det.getPo());
			detBO.setPosicion(det.getPosicion());
			detBO.setMaterial(det.getMaterial());
			detBO.setMarca(det.getMarca());
			detBO.setCantidad(det.getCantidad());
			detBO.setPesoProveedor(det.getPesoProveedor());
			detBO.setVolumenProveedor(det.getVolumenProveedor());
			detBO.setFolio(det.getFolio());
			detBO.setCentro(det.getCentro());
			detBO.setPlaneador(det.getPlaneador());
			detBO.setNumeroDoc(det.getNumeroDoc());
			detBO.setCantidadModificada(det.getCantidadModificada());
			detBO.setPesoModificado(det.getPesoModificado());
			detBO.setVolumenModificado(det.getVolumenModificado());
			detBO.setCliente(det.getCliente());
			detBO.setPaisOrigen(det.getPaisOrigen());
			detBO.setCartones(det.getCartones());
			detBO.setCantidadXCarton(det.getCantidadXCarton());
			detBO.setPesoNetoPKL(det.getPesoNetoPKL());
			detBO.setPesoBrutoPKL(det.getPesoBrutoPKL());
			detBO.setCubicajePKL(det.getCubicajePKL());
			detBO.setPallet(det.getPallet());
			detBO.setCartonXPallet(det.getCartonXPallet());
			detBO.setUnidaMedida(det.getUnidaMedida());
			detBO.setCondicionPago(det.getCondicionPago());
			detBO.setMoneda(det.getMoneda());
			detBO.setPrecioUnitario(det.getPrecioUnitario());
			detBO.setPedidoDirecto(det.isPedidoDirecto());
			detBO.setValorEmbarque(det.getValorEmbarque());
			detBO.setDescripcion(det.getDescripcion());
			detBO.setPicoInventarioDeseado(det.getPicoInventarioDeseado());
			detBO.setInventaroAlArribo(det.getInventaroAlArribo());
			detBO.setBackorderPronosticado(det.getBackorderPronosticado());
			detBO.setDiasAlArribo(det.getDiasAlArribo());
			detBO.setDifVSPico(det.getDifVSPico());
			detBO.setDifDiasConfirm(det.getDifDiasConfirm());
			detBO.setDifPesoUserVSSistem(det.getDifPesoUserVSSistem());
			detBO.setDifVolumenUserVSSistem(det.getDifVolumenUserVSSistem());
			detBO.setDaysSafetyStock(det.getDaysSafetyStock());
			detBO.setVar8Semanas(det.getVar8Semanas());
			detBO.setVar8SemanasDirectos(det.getVar8SemanasDirectos());
			detBO.setFacturacionPedidosDirectos(det.getFacturacionPedidosDirectos());
			detBO.setFechaProforma(det.getFechaProforma());
			detBO.setFechaEtdProveedor(det.getFechaEtdProveedor());
			detBO.setFechaUltConfirm(det.getFechaUltConfirm());
			detBO.setUnidaMedida(det.getUnidaMedida());
			detBO.setOverStock(det.getOverStock());
			detBO.setNoEsPOCompleta(det.isNoEsPOCompleta());
			detBO.setCantidadTotalPO(det.getCantidadTotalPO());
			detBO.setTieneDiferenciasMRP(det.isTieneDiferenciasMRP());
			detBO.setCantidadTotalPO(det.getCantidadTotalPO());
			detBO.setTipoPron(det.getTipoPron());
			detBO.setStatusMRP(det.getStatusMRP());
			detBO.setTipoValidacionMRP(det.getTipoValidacionMRP());
			detBO.setTipoModificacion(det.getTipoModificacion());
			detBO.setCantidad100(det.getCantidad100());
			detBO.setPeso100(det.getPeso100());
			detBO.setVolumen100(det.getVolumen100());
			detBO.setBalanceAction(det.isBalanceAction());
			detBO.setNeedsAuthPlanningMgr(det.getNeedsAuthPlanningMgr());
			detBO.setAlmacen(det.getAlmacen());
			detBO.setCantidadUnidadMedida(det.getCantidadUnidadMedida());
			detBO.setFactorCantidadUnidadMedida(det.getFactorCantidadUnidadMedida());
			detBO.setDescripcionComplementoFactura(det.getDescripcionComplementoFactura());
			lstSarDetBO.add(detBO);
		}
		return lstSarDetBO;	
	}
	
	/**
	 * Genera otra lista, es decir es un tipo clon cuidado se pueden perder valores nuevos, si no se agregan
	 * a este metodo
	 * 
	 * @return
	 */
	public ArrayList<SarDetalleBO> getDetalleOthers() {
		ArrayList<SarDetalleBO> lstSarDetOthers = new ArrayList<SarDetalleBO>();
		ArrayList<SARDetalle> lstSarDet = getDetalleOtros();
		
		if(lstSarDet == null){
			return null;
		}
		
		for (SARDetalle det : lstSarDet ) {
			SarDetalleBO detOthers = new SarDetalleBO();
			detOthers.setPo(det.getPo());
			detOthers.setPosicion(det.getPosicion());
			detOthers.setDescripcion(det.getDescripcion());
			detOthers.setCantidad(det.getCantidad());
			detOthers.setPesoProveedor(det.getPesoProveedor());
			detOthers.setVolumenProveedor(det.getVolumenProveedor());
			detOthers.setCantidadModificada(det.getCantidadModificada());
			detOthers.setPesoModificado(det.getPesoModificado());
			detOthers.setVolumenModificado(det.getVolumenModificado());
			detOthers.setFolio(det.getFolio());
			detOthers.setTipoModificacion(det.getTipoModificacion());
			detOthers.setNeedsAuthPlanningMgr(det.getNeedsAuthPlanningMgr());
			detOthers.setCartones(det.getCartones());
			detOthers.setCubicajePKL(det.getCubicajePKL());
			detOthers.setPesoBrutoPKL(det.getPesoBrutoPKL());
			detOthers.setPesoNetoPKL(det.getPesoNetoPKL());
			detOthers.setCondicionPago(det.getCondicionPago());
			detOthers.setPoOtherItem(det.getPoOtherItem());
			detOthers.setPrecioUnitario(det.getPrecioUnitario());
			detOthers.setUnidaMedida(det.getUnidaMedida());
			detOthers.setCantidadUnidadMedida(det.getCantidadUnidadMedida());
			detOthers.setFactorCantidadUnidadMedida(det.getFactorCantidadUnidadMedida());
			lstSarDetOthers.add(detOthers);
		}
		return lstSarDetOthers;	
	}
	
	/**
	 * 
	 * @return 
	 * @deprecated Se cambia este metodo en la clase del FormatSARHelper {@link FormatSARHelper #tienePedioDirecto(SarBO)}
	 */
	public boolean tienePedidoDirecto() {
		return FormatSARHelper.getInstance().tienePedioDirecto(this);
	}
	
	public String dameIconosSARHtml(boolean ingles) {
		StringBuilder sb = new StringBuilder();
		//valido por idioma
		if(ingles){
			//Valida si ya fue rechazado
			if(this.esRechazado!= null && this.esRechazado) {
				sb.append("<i class=\"fa fa-thumbs-down fa-2x iconosAwesome\" title=\"The SAR Rejected by Shipping\" aria-hidden=\"true\"></i>");
			}
			///validacion si es bloqueado
			if(isSarOnHold()){			
				sb.append("<img title=\"On Hold\" width=\"15px\" height=\"15px\" src=\"/srm_booking/images/stop.gif\">");
			}
			//validacion si el sar es Aereo
			if(this.esAereo() != null && this.esAereo()){
				sb.append("<img title=\"Air\" width=\"15px\" height=\"15px\" src=\"/srm_booking/images/avion.gif\">");
			}
			//Icono si es que tiene ya un contenedor consolidado
			if(this.getFolioConsolidado() != null && this.getFolioConsolidado() > 0){
				sb.append("<img title=\"This SAR has been assigned to consolidation: CC"+this.getFolioConsolidado()+"\" width=\"15px\" height=\"15px\" src=\"/srm_booking/images/consol.png\">");
			}
			//Icono si tiene productos nuevos
			if (this.getTieneProdsNuevos() != null && this.getTieneProdsNuevos()) {
				sb.append("<img title=\"This SAR contains new items\" width=\"15px\" height=\"15px\" src=\"/srm_booking/images/new.png\">");
			}
			//Icono pedidos directos
			if (Boolean.TRUE.equals(this.getTienePedidoDirecto())  || tienePedidoDirecto() ) {
				sb.append("<img title=\"Direct order\" width=\"15px\" height=\"15px\" src=\"/srm_booking/images/infoD.png\">");
			}
			//Icono almacen 45
			if (Constantes.ALMACEN_45.equals(this.getAlmacen())) {
				sb.append("<img title=\"Store 45\" width=\"15px\" height=\"15px\" src=\"/srm_booking/images/45icon.png\">");
			}else {
				if(this.getDetalleBO() != null && this.getDetalleBO().size() > 0) {
					for(SarDetalleBO det : this.getDetalleBO()) {
						if(Constantes.ALMACEN_45.equals(det.getAlmacen())) {
							sb.append("<img title=\"Store 45\" width=\"15px\" height=\"15px\" src=\"/srm_booking/images/45icon.png\">");
							break;
						}
					}
				}
			}
		}else{
			
			//Valida si ya fue rechazado
			if(this.esRechazado!= null && this.esRechazado) {
				sb.append("<i class=\"fa fa-thumbs-down fa-2x iconosAwesome\" title=\"The SAR Rejected by Shipping\" aria-hidden=\"true\"></i>");
			}
			///validacion si es bloqueado
			if(isSarOnHold() ){
				sb.append("<img title=\"On Hold\" width=\"15px\" height=\"15px\" src=\"/srm_booking/images/stop.gif\">");
			}
			//validacion si el sar es Aereo
			if(this.esAereo() != null && this.esAereo()  ){
				sb.append("<img title=\"Contenedor Aereo\" width=\"15px\" height=\"15px\" src=\"/srm_booking/images/avion.gif\">");
			}
			//Icono si es que tiene ya un contenedor consolidado
			if(this.getFolioConsolidado() != null && this.getFolioConsolidado() > 0  ){
				sb.append("<img title=\"Este SAR ha sido asignado al folio consolidado: CC"+this.getFolioConsolidado()+"\" width=\"15px\" height=\"15px\" src=\"/srm_booking/images/consol.png\">");
			}
			//Icono si tiene productos nuevos
			if (this.getTieneProdsNuevos() != null && this.getTieneProdsNuevos()) {
				sb.append("<img title=\"This SAR contains new items\" width=\"15px\" height=\"15px\" src=\"/srm_booking/images/new.png\">");				
			}
			//Icono pedidos directos
			if (Boolean.TRUE.equals(this.getTienePedidoDirecto())  || tienePedidoDirecto() ) {
				sb.append("<img title=\"Direct order\" width=\"15px\" height=\"15px\" src=\"/srm_booking/images/infoD.png\">");
			}
			//Icono almacen 45
			if (Constantes.ALMACEN_45.equals(this.getAlmacen())) {
				sb.append("<img title=\"Almac&eacute;n 45\" width=\"15px\" height=\"15px\" src=\"/srm_booking/images/45icon.png\">");
			}else {
				if(this.getDetalleBO() != null && this.getDetalleBO().size() > 0) {
					for(SarDetalleBO det : this.getDetalleBO()) {
						if(Constantes.ALMACEN_45.equals(det.getAlmacen())) {
							sb.append("<img title=\"Almac&eacute;n 45\" width=\"15px\" height=\"15px\" src=\"/srm_booking/images/45icon.png\">");
							break;
						}
					}
				}
			}
		}
		return sb.toString();
	}
	
	/**
	 * Regresa un true si el sarBO tiene cambios con respecto al sarBo que se guarda solamente
	 * cuando se hace un formatSAR, la idea es que si es una lista, no se este formateando
	 * una y otra vez un mismo BO, ya que el formateo lleva mucho tiempo.
	 * 
	 * @param sarOriginal
	 * @return
	 */
	public boolean sarBOConCambios(SarBO sarOriginal ){
		SarBO respaldo = sarBOAntesFormato; 
		boolean tieneCambios = true;
		if(respaldo != null && formatSARFormatoTemp != null){
			tieneCambios = !EqualsBuilder.reflectionEquals(sarOriginal, respaldo, false);
		}
		return tieneCambios;
	}
	
	/**
	 * Regresa si algun item en detalle no esta completo en cantidad
	 * 
	 * @return
	 */
	public boolean tienePosNoCompletas(){
		ArrayList<SARDetalle> detalle = getDetalle();
		if(detalle == null || detalle.size() == 0){
			return false;
		}else{
			for(SARDetalle det : detalle){
				if(det.isNoEsPOCompleta()){
					return true;
				}
			}
			return false;
		}
	}
	
	

	/**
	 * @return the cumplimiento
	 */
	public int getCumplimiento() {
		return cumplimiento;
	}

	/**
	 * @param cumplimiento the cumplimiento to set
	 */
	public void setCumplimiento(int cumplimiento) {
		this.cumplimiento = cumplimiento;
	}

	/**
	 * @return the fase
	 */
	public String getFase() {
		return fase;
	}

	/**
	 * @param fase the fase to set
	 */
	public void setFase(String fase) {
		this.fase = fase;
	}

	public FormatSAR getFormatSARFormatoTemp() {
		return formatSARFormatoTemp;
	}

	public void setFormatSARFormatoTemp(FormatSAR formatSARFormatoTemp) {
		this.formatSARFormatoTemp = formatSARFormatoTemp;
	}

	public SarBO getSarBOAntesFormato() {
		return sarBOAntesFormato;
	}

	public void setSarBOAntesFormato(SarBO sarBOAntesFormato) {
		this.sarBOAntesFormato = sarBOAntesFormato;
	}

	/**
	 * @return the diasEnStatus
	 */
	public int getDiasEnStatus() {
		return diasEnStatus;
	}

	/**
	 * @param diasEnStatus the diasEnStatus to set
	 */
	public void setDiasEnStatus(int diasEnStatus) {
		this.diasEnStatus = diasEnStatus;
	}

	/**
	 * @return the fechaEnStatus
	 */
	public int getFechaEnStatus() {
		return fechaEnStatus;
	}

	/**
	 * @param fechaEnStatus the fechaEnStatus to set
	 */
	public void setFechaEnStatus(int fechaEnStatus) {
		this.fechaEnStatus = fechaEnStatus;
	}

	public Boolean getTieneFOCs() {
		return tieneFOCs;
	}

	public void setTieneFOCs(Boolean tieneFOCs) {
		this.tieneFOCs = tieneFOCs;
	}

	
	public BigDecimal getTotalCubicaje() {
		return totalCubicaje;
	}

	public void setTotalCubicaje(BigDecimal totalCubicaje) {
		this.totalCubicaje = totalCubicaje;
	}

	public BigDecimal getTotalPesoNeto() {
		return totalPesoNeto;
	}

	public void setTotalPesoNeto(BigDecimal totalPesoNeto) {
		this.totalPesoNeto = totalPesoNeto;
	}

	public BigDecimal getTotalPesoBruto() {
		return totalPesoBruto;
	}

	public void setTotalPesoBruto(BigDecimal totalPesoBruto) {
		this.totalPesoBruto = totalPesoBruto;
	}

	public int getTotalCartones() {
		return totalCartones;
	}

	public void setTotalCartones(int totalCartones) {
		this.totalCartones = totalCartones;
	}

	public boolean isTienePOsEliminadas() {
		return tienePOsEliminadas;
	}
	
	public void setTienePOsEliminadas(boolean tienePOsEliminadas) {
		this.tienePOsEliminadas = tienePOsEliminadas;
	}
	
	public boolean isTieneOthersEliminadas() {
		return tieneOthersEliminadas;
	}
	
	public void setTieneOthersEliminadas(boolean tieneOthersEliminadas) {
		this.tieneOthersEliminadas = tieneOthersEliminadas;
	}

	public boolean isTieneProblemas() {
		return tieneProblemas;
	}

	public void setTieneProblemas(boolean tieneProblemas) {
		this.tieneProblemas = tieneProblemas;
	}
	
	public ArrayList<String> getErroresDocumentos() {
		return erroresDocumentos;
	}

	public void setErroresDocumentos(ArrayList<String> erroresDocumentos) {
		this.erroresDocumentos = erroresDocumentos;
	}

	public boolean isTieneDocumentos() {
		
		if(getTieneFacura() == null || getTieneBL() == null || getTienePackingList() == null) { 
			tieneDocumentos = false;
		} else if (getTieneFacura() && getTieneBL() && getTienePackingList()) {
			tieneDocumentos = true;
		} else {
			tieneDocumentos = false;
		}
		return tieneDocumentos;
	}

	public void setTieneDocumentos(boolean tieneDocumentos) {
		this.tieneDocumentos = tieneDocumentos;
	}
	
	public String getSarsABuscar() {
		return sarsABuscar;
	}

	public void setSarsABuscar(String sarsABuscar) {
		this.sarsABuscar = sarsABuscar;
	}

	
	public int getTotalCantidad() {
		return totalCantidad;
	}

	public void setTotalCantidad(int totalCantidad) {
		this.totalCantidad = totalCantidad;
	}

	/**
	 * Si quiero calcular el detalle en el SAR uso este metodo,
	 * Si quiero saber lo que tiene o settee uso el isTieneDiferenciaMRP
	 * @return
	 */
	public Boolean calculaSitieneDiferenciaMRP() {
		if(getDetalle() == null || getDetalle().size() == 0){
			return null;
		}else{
			for(SARDetalle det : getDetalle()){				
				if(det.isTieneDiferenciasMRP()){					
					return true;
				}
			}
			return false;
		}
	}
	
	public Boolean requiereAutorizacionDirImports() {
		Integer minBackorder = propertiesDb.getInteger("srm.importsDirector.minBO");
		Integer minOverStock = propertiesDb.getInteger("srm.importsDirector.minOS");
		Integer minIda = propertiesDb.getInteger("srm.importsDirector.minIda");
		Integer currentIda = this.getIda();
		minIda = minIda == null ? 0 : minIda;
		currentIda = currentIda == null ? 0 : currentIda;
		Double overStockPctTot = 0.0;
		for (SarDetalleBO detTemp : this.getDetalleBO()) {
			if(detTemp.getOverStock() != null &&detTemp.getOverStock() != 0 &&  this.getValorEmbarque() !=null && this.getValorEmbarque().doubleValue() != 0) {
				Double pctOverStock = (detTemp.getOverStock()/this.getValorEmbarque().doubleValue())*100;
				detTemp.setOverStockPt(pctOverStock);
				overStockPctTot += pctOverStock;
			}
		}
				
		this.setOverStockPctTot(overStockPctTot);
		if (Math.abs(this.getBackorderPronosticadoTot().intValue()) >= minBackorder
				|| Math.abs(this.getOverStockPctTot()) >= minOverStock || currentIda.compareTo(minIda) > 0) {
			return true;
		} else {
			return false;
		}
	}
	
	/**
	 * Me regresa el ETD del planeacion o el etd real dependiendo el caso
	 */
	public int dameETDDelSAR(){
		
		return  ( this.getEtdReal() != null &&  this.getEtdReal() > 0) ? this.getEtdReal() : 
			(this.getFechaEmbarque() != null ? this.getFechaEmbarque() : 0 );
	}

	public boolean isCierraConfirmacionFinal() {
		return cierraConfirmacionFinal;
	}

	public void setCierraConfirmacionFinal(boolean cierraConfirmacionFinal) {
		this.cierraConfirmacionFinal = cierraConfirmacionFinal;
	}

	public boolean isAcceptedIDAValidation() {
		return acceptedIDAValidation;
	}

	public void setAcceptedIDAValidation(boolean acceptedIDAValidation) {
		this.acceptedIDAValidation = acceptedIDAValidation;
	}

	public Integer getNuevaFechaETD_IDA() {
		return nuevaFechaETD_IDA;
	}

	public void setNuevaFechaETD_IDA(Integer nuevaFechaETD_IDA) {
		this.nuevaFechaETD_IDA = nuevaFechaETD_IDA;
	}
	
	
	public static Boolean esImportado(SarBO sar ) {
		Boolean flag = null;
		boolean sarConDetalles = sar != null && sar.getDetalle() != null && !sar.getDetalle().isEmpty();
		ArrayList<SarDetalleBO> detalles = sarConDetalles ? sar.getDetalleBO() : null; 
		if( detalles == null ) {
			try {
				SarDetalleBO sd = new SarDetalleBO();
				sd.setFolio(sar.getFolio());
				detalles = SAR_CDI_DAO.selectSarDetalleDinamico(sd);
				
				if( detalles == null || detalles.isEmpty() ) {
					return true;
				}		
			} catch (ClassNotFoundException e) {
				
			}
			
		}
		List<String> OTHER_ITEMS = Arrays.asList(PropertiesDb.getInstance().getStringTrim("cargaImportData.othersItems").split(","));
		
		try {
			FuncionesComunesPLI.cargaProductos(false);
		} catch (Exception e) {
			log.error(e.getMessage());
		}
		
		
		Optional<SarDetalleBO> sdb = detalles.stream().filter(detalle -> detalle.getMaterial() != null
				&& !OTHER_ITEMS.contains(detalle.getMaterial().toString())
				&& FuncionesComunesPLI.productos.get(detalle.getMaterial().toString()) != null
			).findFirst();
		
		if( sdb.isPresent() ) {
			SarDetalleBO sarDetalle = sdb.get();
			Integer material = sarDetalle.getMaterial();
			ProductoBean p = FuncionesComunesPLI.productos.get(material.toString());
			flag = p != null ? p.isComercializado() : null ;
			return flag;
		}else {
			return flag;
		}
		
	}
	public Boolean getApprovalGRDlineacion() {
		return approvalGRDlineacion;
	}
	public void setApprovalGRDlineacion(Boolean approvalGRDlineacion) {
		this.approvalGRDlineacion = approvalGRDlineacion;
	}
	public String getMessageGRDrechazo() {
		return messageGRDrechazo;
	}
	public void setMessageGRDrechazo(String messageGRDrechazo) {
		this.messageGRDrechazo = messageGRDrechazo;
	}
	public String getMessageGRDaprobacion() {
		return messageGRDaprobacion;
	}
	public void setMessageGRDaprobacion(String messageGRDaprobacion) {
		this.messageGRDaprobacion = messageGRDaprobacion;
	}
	
}
