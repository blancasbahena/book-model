package com.srm.pli.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringEscapeUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.taglibs.standard.lang.jstl.ELException;
import org.springframework.web.util.HtmlUtils;

import com.srm.pli.bo.BitacoraVistaBean;
import com.srm.pli.db.ConexionDB;
import com.truper.businessEntity.BitacoraIDABean;

public class BitacoraIDADAO {

	private static BitacoraIDADAO instance;
	private static final Logger log = LogManager.getRootLogger();

	private BitacoraIDADAO() {
	}

	public static BitacoraIDADAO getInstance() {
		if (instance == null) {
			instance = new BitacoraIDADAO();
		}
		return instance;
	}
	
	public Connection insertaRegistroBitacora(BitacoraIDABean bean, Connection con) throws SQLException {
		int num_insert = 0;
		Boolean isAutoCommit = null;
		try {
			con = con != null ? con : ConexionDB.dameConexion();
			isAutoCommit = con.getAutoCommit();
			con.setAutoCommit(false);
			
			StringBuilder sql = new StringBuilder();
			sql.append(" INSERT INTO cdiBitacora_IDARevision ");
			sql.append(" (folio,foliocc,comentario,userName,creationDate) ");
			sql.append(" VALUES (?,?,?,?,GETDATE() ) ");
			try (PreparedStatement ps = con.prepareStatement(sql.toString());) {
				int cont = 1 ;
				ps.setInt(cont++, bean.getFolio());
				ps.setInt(cont++, bean.getFolioCC());
				ps.setString(cont++, bean.getComentario());
				ps.setString(cont++, bean.getUserName());
				num_insert = ps.executeUpdate();
				if(num_insert == 0) {
					throw new SQLException("Error, no se inserto registro alguno");
				}
			}
		} catch (Exception e) {
			log.error("Folio: " + bean.toString(), e);
			if(isAutoCommit != null) {
				con.setAutoCommit(isAutoCommit);
			}
			ConexionDB.renovar(con);
			ConexionDB.devolver(con);
			throw new SQLException(e);
		}
		return con;
	}
	
	public Connection upsertBitacoraStatus(BitacoraIDABean bean , Connection con) throws SQLException {
		int num_insert = 0;
		Boolean isAutoCommit = null;
		try {
			con = con != null ? con : ConexionDB.dameConexion();
			isAutoCommit = con.getAutoCommit();
			con.setAutoCommit(false);
			StringBuilder sql = new StringBuilder();		
			sql.append(" MERGE  cdiBitacora_IDAstatus as [target] ");
			sql.append(" USING (select ? folio, ? esCC , ? usuarioCreacion ) AS [source] ");
			sql.append(" ON ([target].folio = [source].folio AND [target].esCC = [source].esCC) ");
			sql.append(" WHEN matched THEN  ");
			sql.append(" UPDATE SET [target].usuarioCierre = NULL, [target].fechaCierre = NULL  ");
			sql.append(" WHEN not matched THEN ");
			sql.append(" INSERT (folio,esCC,fechacreacion,usuarioCreacion) ");
			sql.append(" values ([source].folio,[source].esCC,GETDATE(),[source].usuarioCreacion); ");
			try (PreparedStatement ps = con.prepareStatement(sql.toString());) {
				int cont = 1 ;
				ps.setInt(cont++, bean.getFolio());
				ps.setInt(cont++, bean.getFolioCC());
				ps.setString(cont++, bean.getUserName());
				num_insert = ps.executeUpdate();
				if(num_insert == 0) {
					throw new SQLException("Error, no se inserto registro alguno");
				}
			}
		} catch (Exception e) {
			log.error("[upsertBitacoraStatus]: " + bean.toString(), e);
			if(isAutoCommit != null) {
				con.setAutoCommit(isAutoCommit);
			}
			ConexionDB.renovar(con);
			ConexionDB.devolver(con);
			throw new SQLException(e);
		}
		return con;
	}
	
	public List<BitacoraVistaBean> selectBitacoraOpen(){
		List<BitacoraVistaBean> resultado = null;
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();	
			StringBuilder sql = new StringBuilder();
			sql.append(" SELECT a.folio,a.folioCC,a.userName,c.fechacreacion, u.realname  ");
			sql.append(" FROM cdiBitacora_IDARevision a JOIN CDIBITACORA_IDAStatus c ON c.folio = a.folio and c.esCC = a.foliocc ");
			sql.append(" JOIN cdiUsers u ON u.userName = a.userName  ");
			sql.append(" WHERE   ");
			sql.append("  (SELECT MAX(b.id) from  cdiBitacora_IDARevision b ");
			sql.append("  WHERE b.folio = a.folio and b.folioCC = a.folioCC) = a.id  AND c.fechacierre is  null");
		try (PreparedStatement pst = con.prepareStatement(sql.toString())) {
			try (ResultSet rs = pst.executeQuery()) {
				resultado = new ArrayList<>();
				BitacoraVistaBean bean = null;
				while (rs.next()) {
					 bean = new BitacoraVistaBean();
					 bean.setFolio(rs.getInt("folio"));
					 bean.setFolioCC(rs.getInt("folioCC"));
					 bean.setLastUser(rs.getString(3));
					 bean.setLastModification(rs.getString("fechacreacion"));
					 bean.setNombreUserLast(rs.getString(5));
					 resultado.add(bean);
				} 
			}
		}
		} catch (SQLException sqle) {
			sqle.printStackTrace();
			log.error("selectSarEnIDARevition: " + sqle.toString(), sqle);
			ConexionDB.renovar(con);
		}catch (Exception e) {
			e.printStackTrace();
			log.error("selectSarEnIDARevition: " + e.toString(), e);
		} finally {
			ConexionDB.devolver(con);
		}
		return resultado;
	}
	
	public List<BitacoraIDABean> selectBitacoraMensajes(BitacoraIDABean bitacora){
		List<BitacoraIDABean> resultado = null;
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();
			StringBuilder sql = new StringBuilder();
			sql.append(" SELECT folio,folioCC,comentario,userName,creationDate ");
			sql.append(" FROM cdiBitacora_IDARevision ");
			sql.append(" WHERE folio = ? and folioCC = ? ");
			sql.append(" ORDER by creationDate asc");
			try (PreparedStatement pst = con.prepareStatement(sql.toString())) {
				pst.setInt(1, bitacora.getFolio());
				pst.setInt(2, bitacora.getFolioCC());
				
				try (ResultSet rs = pst.executeQuery()) {
					resultado = new ArrayList<>();
					BitacoraIDABean bean = null;
					while (rs.next()) {
						 bean = new BitacoraIDABean();
						 bean.setFechaCreacion(rs.getString("creationDate"));
						 bean.setFolio(rs.getInt("folio"));
						 bean.setFolioCC(rs.getInt("folioCC"));
						 bean.setUserName(rs.getString("userName"));
						 bean.setComentario(StringEscapeUtils.escapeHtml4(rs.getString("comentario")));
						 resultado.add(bean);
					}
				}
			}
		} catch (SQLException sqle) {
			sqle.printStackTrace();
			log.error("selectSarEnIDARevition: " + sqle.toString(), sqle);
			ConexionDB.renovar(con);
		}catch (Exception e) {
			e.printStackTrace();
			log.error("selectSarEnIDARevition: " + e.toString(), e);
		} finally {
			ConexionDB.devolver(con);
		}
		return resultado;
	}
	
	public Connection updateRegistroBitacora(int folio, int foliocc, String usuario) throws SQLException {
		Integer num_insert = null;
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();
			con.setAutoCommit(false);
			StringBuilder sql = new StringBuilder();
			sql.append(" UPDATE  cdiBitacora_IDAstatus ");
			sql.append(" SET  fechaCierre = GETDATE(), usuarioCierre = ? ");
			sql.append(" WHERE folio = ? and escc = ? ");
			try (PreparedStatement pst = con.prepareStatement(sql.toString());) {
				int i = 1;
				pst.setString(i++, usuario);
				pst.setInt(i++, folio);
				pst.setInt(i++, foliocc);
				num_insert = pst.executeUpdate();
			}
			if(num_insert == 0 ) {
				log.info("[updateRegistroBitacora] ERROR  registro bitacora, folio:"+folio+",foliocc:"+foliocc+",usuario:"+usuario);
				throw new ELException("Ningun registro actualizado");
			} else {
				log.info("[updateRegistroBitacora] OK se ingresa registro bitacora, folio:"+folio+",foliocc:"+foliocc+",usuario:"+usuario);
			}
		} catch (Exception e) {
			e.printStackTrace();
			con.rollback();
			con.setAutoCommit(true);
			ConexionDB.devolver(con);
			log.error("Informacion: folio:"+folio+",foliocc:"+foliocc+",usuario:"+usuario, e);
		}
		return con;
	}
}
