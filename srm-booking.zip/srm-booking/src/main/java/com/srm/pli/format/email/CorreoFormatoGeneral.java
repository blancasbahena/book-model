package com.srm.pli.format.email;

import static com.srm.pli.helper.CorreoHelper.LOGIN_FR;
import static com.srm.pli.utils.TelServiceClient.baseUri;

import com.srm.pli.helper.CorreoHelper;
import com.srm.pli.services.CorreoServices;
import com.truper.utils.string.UtilsString;

public class CorreoFormatoGeneral {
	
	private static final String HEAD;
	private static final CorreoFormatoGeneral instance = new CorreoFormatoGeneral();

	private CorreoFormatoGeneral() {
	}
	
	static {
		StringBuilder email = new StringBuilder();
		email.append("<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional //EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\" /> ");
		email.append("<html lang=\"en\" xmlns=\"http://www.w3.org/1999/xhtml\" xmlns:v=\"urn:schemas-microsoft-com:vml\" xmlns:o=\"urn:schemas-microsoft-com:office:office\"> ");
		email.append("  <head>  ");
		email.append("    <meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\" /> ");
		email.append("    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\" /> ");
		email.append("    <meta name=\"x-apple-disable-message-reformatting\" /> ");
		email.append("    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\" /> ");
		email.append("    <style type=\"text/css\">           ");
		email.append("      * {        ");
		email.append("        text-size-adjust: 100%;         ");
		email.append("        -ms-text-size-adjust: 100%;     ");
		email.append("        -moz-text-size-adjust: 100%;    ");
		email.append("        -webkit-text-size-adjust: 100%; ");
		email.append("      }          ");
		email.append("                 ");
		email.append("      html {     ");
		email.append("        height: 100%;                   ");
		email.append("        width: 100%;                    ");
		email.append("      }          ");
		email.append("                 ");
		email.append("      body {     ");
		email.append("        height: 100% !important;        ");
		email.append("        margin: 0 !important;           ");
		email.append("        padding: 0 !important;          ");
		email.append("        width: 100% !important;         ");
		email.append("        mso-line-height-rule: exactly;  ");
		email.append("      }          ");
		email.append("                 ");
		email.append("      div[style*=\"margin: 16px 0\"] {  ");
		email.append("        margin: 0 !important;           ");
		email.append("      }          ");
		email.append("                 ");
		email.append("      table,     ");
		email.append("      td {       ");
		email.append("        mso-table-lspace: 0pt;          ");
		email.append("        mso-table-rspace: 0pt;          ");
		email.append("      }          ");
		email.append("                 ");
		email.append("      img {      ");
		email.append("        border: 0;                      ");
		email.append("        height: auto;                   ");
		email.append("        line-height: 100%;              ");
		email.append("        outline: none;                  ");
		email.append("        text-decoration: none;          ");
		email.append("        -ms-interpolation-mode: bicubic;");
		email.append("      }          ");
		email.append("                 ");
		email.append("      .ReadMsgBody,                     ");
		email.append("      .ExternalClass {                  ");
		email.append("        width: 100%;                    ");
		email.append("      }          ");
		email.append("                 ");
		email.append("      .ExternalClass,                   ");
		email.append("      .ExternalClass p,                 ");
		email.append("      .ExternalClass span,              ");
		email.append("      .ExternalClass td,                ");
		email.append("      .ExternalClass div {              ");
		email.append("        line-height: 100%;              ");
		email.append("      }          ");
		email.append("    </style>     ");
		email.append("    <title>F&R</title>                  ");
		email.append("    <meta name=\"author\" content=\"RENE SANTIAGO RESENDIZ\" /> ");
		email.append("  </head>        ");
		HEAD = email.toString();
	}
	
	public static CorreoFormatoGeneral getInstance() {
		return instance;
	}
	
	private String getFoot(String url, String textButton, String prioridad){
		StringBuilder email = new StringBuilder();
		email.append("                              <div class=\"margenContenido row\" large=\"3\" style=\"margin: 0 4em;\">        ");
		email.append("                                <table class=\"row__table\" width=\"100%\" align=\"center\" role=\"presentation\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"table-layout: fixed;\">     ");
		email.append("                                  <tr class=\"row__row\">       ");
		email.append("                                    <td class=\"barra botBarra prioridad column col-sm-12\" width=\"850\" style=\"border-collapse: collapse; background-color: ").append(prioridad).append("; padding: 3px; vertical-align: top; border-bottom-left-radius: 5px; border-bottom-right-radius: 5px;width: 100%\" ");
		email.append("                                      align=\"left\" valign=\"top\" bgcolor=\"#00A9BF\"> </td>      ");
		email.append("                                  </tr> ");
		email.append("                                </table>");
		email.append("                              </div>    ");
		email.append("                              <div class=\"blockOtros block\" large=\"3\" style=\"width: 100%; text-align: center; margin-top: 1em;\">                  ");
		email.append("                                      <table class=\"block__table\" role=\"presentation\" border=\"0\" align=\"center\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\">    ");
		email.append("                                        <tr class=\"block__row\">   ");
		email.append("                                          <td class=\"block__cell\" width=\"100%\" align=\"left\" valign=\"top\">                                       ");
		email.append("                                            <div class=\"row\"> ");
		email.append("                                              <table class=\"row__table\" width=\"100%\" align=\"center\" role=\"presentation\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"table-layout: fixed;\">                           ");
		email.append("                                                <tr class=\"row__row\">                             ");
		email.append("                                                  <td class=\"column col-sm-12\" width=\"850\" style=\"width: 100%\" align=\"left\" valign=\"top\">     ");
		email.append("                                                    <p class=\"textoOtros text p\" style=\"display: block; margin: 14px 0; font-family: Helvetica,Arial,sans-serif; line-height: 20px; color: #808080; font-size: 12px; text-align: center;\">Please check our system for more information</p> ");
		email.append("                                                    <p class=\"text p\" style=\"display: block; margin: 14px 0; color: #000000; font-family: Helvetica,Arial,sans-serif; font-size: 16px; line-height: 20px; text-align: center;\">        ");
		email.append("                                                    	<a class=\"botonLogin a\" style=\"padding: 10px 16px; font-weight: 700; font-size: 13px; border-radius: 4px; background-color: #4285F4; color: #FFFFFF; text-decoration: none;\" ");
		email.append("href=\"").append(url).append("\">");
		email.append("                                                    		<span class=\"a__text\" style=\"color: #FFFFFF; text-decoration: none;\">");
		email.append(textButton);
		email.append("                                                    		</span>");
		email.append("                                                    	</a>      ");
		email.append("                                                    </p>        ");
		email.append("                                                  </td>         ");
		email.append("                                                </tr>           ");
		email.append("                                              </table>          ");
		email.append("                                            </div>              ");
		email.append("                                          </td>                 ");
		email.append("                                        </tr>                   ");
		email.append("                                      </table>                  ");
		email.append("							  </div>      ");
		email.append("                            </tr>       ");
		email.append("                          </table>      ");
		email.append("                        </div>          ");
		email.append("                      </td>             ");
		email.append("                    </tr>               ");
		email.append("                  </table>              ");
		email.append("				</div>                    ");
		email.append("        </td>    ");
		email.append("      </tr>      ");
		email.append("      </table>   ");
		email.append("      <div style=\"display:none; white-space:nowrap; font-size:15px; line-height:0;\">&nbsp; </div> "); 
		email.append("  </body>        ");
		email.append("</html>          ");
		return email.toString();
	}
	
	public String getFormatoFR(String saludo, String parrafo, String preview) {
		return getFormatoFR(saludo, parrafo, preview, null, null);
	}
	
	public String getFormatoFR(String saludo, String parrafo, String preview, String prioridad) {
		return getFormatoFR(saludo, parrafo, preview, prioridad, null);
	}
	
	public String getFormatoFR(String saludo, String parrafo, String preview, String prioridad, String table) {
		return getFormato(saludo, parrafo, baseUri, LOGIN_FR, preview, prioridad, table);
	}
	
	public String getFormato(String saludo, String parrafo, String url, String textButton, String preview, String prioridad) {
		return getFormato(saludo, parrafo, url, textButton, preview, prioridad, null);
	}
	
	public String getFormato(String saludo, String parrafo, String url, String textButton, String preview, String prioridad, String table) {
		if(UtilsString.isEmptyNullOrUndefined(prioridad)) {
			prioridad = CorreoHelper.PRIORIDAD_NORMAL;
		}
		StringBuilder email = new StringBuilder(HEAD);
		email.append("  <body class=\"body\" style=\"margin: 0; width: 100%;\">       ");
		email.append("    <div class=\"preview\" style=\"display: none; font-size: 1px; line-height: 1px; max-height: 0px; max-width: 0px; opacity: 0; overflow: hidden; mso-hide: all;\"> ");
		email.append(preview);
		email.append("    </div> ");
		email.append("    <table       ");
		email.append("      class=\"bodyTable\" role=\"presentation\" width=\"100%\" align=\"left\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width: 100%; margin: 0;\">              ");
		email.append("      <tr>       ");
		email.append("        <td class=\"body__content\" align=\"left\" width=\"100%\" valign=\"top\" style=\"color: #000000; font-family: Helvetica,Arial,sans-serif; font-size: 16px; line-height: 20px;\">               ");
		email.append("          <div class=\"container\" style=\"margin: 0 auto; width: 100%; max-width: 1050px;\">        ");
		email.append("                  <table class=\"container__table\" role=\"presentation\" border=\"0\" align=\"center\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\">                    ");
		email.append("                    <tr class=\"container__row\">               ");
		email.append("                      <td class=\"container__cell\" width=\"100%\" align=\"left\" valign=\"top\" style=\"background-color: #F2F2F2; padding: 40px 0;\" bgcolor=\"#F2F2F2\">    ");
		email.append("                        <div class=\"margenContenido row\" style=\"margin: 0 4em;\">                ");
		email.append("                          <table class=\"row__table\" width=\"100%\" align=\"center\" role=\"presentation\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"table-layout: fixed;\">           ");
		email.append("                            <tr class=\"row__row\">             ");
		email.append("                              <div large=\"3\" class=\"row\">   ");
		email.append("                                <table class=\"row__table\" width=\"100%\" align=\"center\" role=\"presentation\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"table-layout: fixed;\">     ");
		email.append("                                  <tr class=\"row__row\">       ");
		email.append("                                    <td class=\"barra topBarra prioridad column col-sm-12\" width=\"850\" style=\"border-collapse: collapse; background-color: ").append(prioridad).append("; padding: 3px; vertical-align: top; border-top-left-radius: 5px; border-top-right-radius: 5px;width: 100%\" ");
		email.append("                                      align=\"left\" valign=\"top\" bgcolor=\"#00A9BF\"> </td> ");
		email.append("                                  </tr> ");
		email.append("                                </table> ");
		email.append("                              </div> ");
		email.append("                              <div class=\"contenido row\" large=\"3\" style=\"background-color: #FFFFFF; margin: 0 4em;\">                             ");
		email.append("                                <table class=\"row__table\" width=\"100%\" align=\"center\" role=\"presentation\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"table-layout: fixed;\">     ");
		email.append("                                  <tr class=\"row__row\">       ");
		email.append("                                    <td class=\"column col-sm-12\" width=\"850\" style=\"width: 100%\" align=\"left\" valign=\"top\">                   ");
		email.append("                                      <div class=\"row\">       ");
		email.append("                                        <table class=\"row__table\" width=\"100%\" align=\"center\" role=\"presentation\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"table-layout: fixed;\"> ");
		email.append("                                          <tr class=\"row__row\"> ");
		email.append("                                            <td class=\"saludo column col-sm-12\" width=\"850\" style=\"font-size: 18px; color: #555555; font-family: sans-serif; text-align: left; padding: 2em 0 .5em 1em;width: 100%\" align=\"left\" valign=\"top\"> ");
		email.append(saludo);
		email.append("                                            </td> ");
		email.append("                                          </tr>                 ");
		email.append("                                        </table>                ");
		email.append("                                      </div>                    ");
		email.append("                                      <div class=\"row\">       ");
		email.append("                                        <table class=\"row__table\" width=\"100%\" align=\"center\" role=\"presentation\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"table-layout: fixed;\"> ");
		email.append("                                          <tr class=\"row__row\">	");
		email.append("                                            <colum large=\"12\">	");
		email.append("                                              <p class=\"textoContenido text p\" style=\"display: block; margin: 14px 0; padding: 0 1em; color: #555555; font-family: sans-serif; font-size: 15px; line-height: 20px; text-align: left;\"> ");
		email.append(parrafo);
		email.append("                                              </p>              ");
		email.append("                                            </colum>            ");
		email.append("                                          </tr>                 ");
		email.append("                                        </table>                ");
		email.append("                                      </div>                    ");
		if(UtilsString.isStringValida(table)) {
			email.append("  <div id=\"hor-minimalist-b\" class=\"zebra row\" style=\"background-color: #FFFFFF; border-collapse: collapse; font-family: 'Lucida Sans Unicode','Lucida Grande',Sans-Serif; font-size: 12px; margin: .1em 5em; text-align: left;\"> ");
			email.append("	<table class=\"row__table\" width=\"100%\" align=\"center\" role=\"presentation\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"table-layout: fixed;\"> ");
			email.append("	  <tr class=\"row__row\"> ");
			email.append(table);
			email.append("	  </tr> ");
			email.append("	</table> ");
			email.append("  </div> ");	
		}
		email.append("                                      <div class=\"row\">       ");
		email.append("                                        <table class=\"row__table\" width=\"100%\" align=\"center\" role=\"presentation\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"table-layout: fixed;\"> ");
		email.append("                                          <tr class=\"row__row\">   ");
		email.append("                                            <colum large=\"12\">");
		email.append("                                              <p class=\"despedida text p\" style=\"display: block; margin: 14px 0; color: #555555; font-family: sans-serif; text-align: left; padding: 1em; font-size: 15px; line-height: 20px;\">Best regards.</p> ");
		email.append("                                            </colum>            ");
		email.append("                                          </tr>                 ");
		email.append("                                        </table>                ");
		email.append("                                      </div>                    ");
		email.append("                                    </td>                       ");
		email.append("                                  </tr> ");
		email.append("                                </table>");
		email.append("                              </div>    ");
		email.append(getFoot(url, textButton, prioridad));
		return email.toString();
	}
	
	
	public String getTrHeader() {
		return "<tr large=\"2\" class=\"tr\" style=\"background-color: #FFFFFF;\" bgcolor=\"#FFFFFF\">";
	}
	
	public String getThHeader(Object titulo) {
		return new StringBuilder("<th style=\"border-bottom: 2px solid #6678B1; color: #003399; font-size: 14px; font-weight: 400; padding: 10px 8px;\">").append(titulo == null ? "null" : titulo.toString()).append("</th>").toString();
	}
	
	public String getTrOdd() {
		return "<tr large=\"2\" class=\"tr\" style=\"background-color: #51a2e812;\" bgcolor=\"#51a2e812\">";
	}
	
	public String getTrEven() {
		return "<tr large=\"2\" class=\"tr\" style=\"background-color: #FFFFFF;\" bgcolor=\"#FFFFFF\">";
	}
	
	public String getTd(Object valor) {
		return new StringBuilder("<td class=\"td\" style=\"padding: 6px 8px; border-bottom: 1px solid #CCCCCC;\">").append(valor == null ? "null" : valor.toString()).append("</td>").toString();
	}

}
