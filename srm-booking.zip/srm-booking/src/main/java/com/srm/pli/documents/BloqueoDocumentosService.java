package com.srm.pli.documents;

import static com.srm.pli.enums.HistoryLogAction.BLOQUEO_DE_DOCUMENTOS;
import static com.srm.pli.enums.HistoryLogAction.ELIMINA_BLOQUEO_DE_DOCUMENTOS;

import java.util.Set;

import com.srm.pli.services.HistoryLogServices;

import lombok.extern.log4j.Log4j2;

@Log4j2
public class BloqueoDocumentosService {

	private static BloqueoDocumentosService instance = null;
	private static BloqueoDocumentosDao dao = null;
	private static HistoryLogServices history = null;

	private BloqueoDocumentosService() {
		dao = BloqueoDocumentosDao.getInstance();
		history = HistoryLogServices.getInstance();
	}

	public static BloqueoDocumentosService getInstance() {
		if (instance == null)
			instance = new BloqueoDocumentosService();
		return instance;
	}

	public void bloqueaDocumentos(Integer folio, String usuario, String comentario) {
		try {
			dao.insertBloqueoDocumentos(folio);
			history.registraAccion(folio, usuario, BLOQUEO_DE_DOCUMENTOS, comentario);
		} catch (Exception e) {
			log.error("bloqueaDocumentos | {} {} {}", folio, usuario, comentario, e);
		}
	}

	public Integer getBloqueoDocumentos(Integer folio) {
		Integer _folio = null;
		try {
			_folio = dao.selectBloqueoDocumentos(folio);
		} catch (Exception e) {
			log.error("getBloqueoDocumentos | {}", folio, e);
		}
		return _folio;
	}

	public void eliminaBloqueoDocumentos(Integer folio, String usuario, String comentario) {
		try {
			dao.deleteBloqueoDocumentos(folio);
			history.registraAccion(folio, usuario, ELIMINA_BLOQUEO_DE_DOCUMENTOS, comentario);
		} catch (Exception e) {
			log.error("eliminaDocumentos | {} {} {}", folio, usuario, comentario, e);
		}
	}

	public boolean containsFoliosBloqueados(Set<Integer> folios) {
		if (folios == null || folios.isEmpty())
			return false;
		for (Integer folio : folios) {
			boolean isBloqueado = isFolioBloqueoDocumentos(folio);
			if (isBloqueado)
				return true;
		}
		return false;
	}

	public boolean isFolioBloqueoDocumentos(Integer folio) {
		Integer folioBloqueado = getBloqueoDocumentos(folio);
		if (folioBloqueado == null)
			return false;
		return true;
	}

}
