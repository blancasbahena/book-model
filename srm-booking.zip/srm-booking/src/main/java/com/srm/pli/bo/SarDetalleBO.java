package com.srm.pli.bo;



import com.srm.pli.utils.FuncionesComunesPLI;
import com.truper.businessEntity.ProductoBean;
import com.truper.businessEntity.SARDetalle;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
@ToString(callSuper = true)
public class SarDetalleBO extends SARDetalle {
	
	private static final long serialVersionUID = -247441799090900392L;
// *****NO DESCOMENTAR 
//	@Getter @Setter
//	private String  descripcionComplementoFactura;
	
	
	
	public SarDetalleBO() {
		super();
	}
	
	public SarDetalleBO(int folio, String po, int posicion, Integer material, int cantidad, String centro,String planeador,String cliente){ 
		super(folio, po, posicion, material, cantidad, centro, planeador, cliente);
		ProductoBean prod = FuncionesComunesPLI.productos.get(material.toString());
		if(prod != null){
			setDescripcion(prod.getDescripcion());
		}
		setPesoPO(FuncionesComunesPLI.calculaPesoParaCantidad(getCantidad(), material.toString()));
		setVolumenPO(FuncionesComunesPLI.calculaVolumenParaCantidad(getCantidad(), material.toString()));
	}
	
	
	

	/**
	 * Para hacer uso de una llave para el mapa, la llave sera po+posicion
	 * @return
	 */
	public String dameLlave() {
		StringBuilder buf = new StringBuilder();
		buf.append(this.getPo() != null ? this.getPo().trim() : "");
		buf.append("_");
		buf.append(this.getPosicion() != null ? this.getPosicion().toString() : "");
		return buf.toString();
	}
}
