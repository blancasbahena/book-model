package com.srm.pli.dao.sql;

public class ProductoCertificadoSql {

	public static final String SELECT_PRODUCTOS_CERTIFICADO;

	static {
		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT material FROM cdiProductoCertificado ");
		sql.append(" WHERE material IN binaryFractal ");
		SELECT_PRODUCTOS_CERTIFICADO = sql.toString();
	}

	private ProductoCertificadoSql() {
	}
}
