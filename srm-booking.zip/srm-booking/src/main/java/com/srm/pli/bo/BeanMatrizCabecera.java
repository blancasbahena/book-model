package com.srm.pli.bo;


import java.util.Date;

import com.truper.bpm.enums.StatusControlMatricesEnum;


public class BeanMatrizCabecera {
	private Date fechaInsert;
	private boolean isBacklog;
	private Date fechaBacklog;
	private Date fechaModificacion;
	private String  comentario;
	private StatusControlMatricesEnum status;
	private String po;
	private String centro;
	private int etd;
	private String proveedor;
	private String documentosRequeridos;
	private Integer material;
	private Integer xDias;
	
	
	public Date getFechaInsert() {
		return fechaInsert;
	}
	public void setFechaInsert(Date fechaInsert) {
		this.fechaInsert = fechaInsert;
	}
	public boolean isBacklog() {
		return isBacklog;
	}
	public void setBacklog(boolean isBacklog) {
		this.isBacklog = isBacklog;
	}
	public Date getFechaBacklog() {
		return fechaBacklog;
	}
	public void setFechaBacklog(Date fechaBacklog) {
		this.fechaBacklog = fechaBacklog;
	}
	public Date getFechaModificacion() {
		return fechaModificacion;
	}
	public void setFechaModificacion(Date fechaModificacion) {
		this.fechaModificacion = fechaModificacion;
	}
	public String getComentario() {
		return comentario;
	}
	public void setComentario(String comentario) {
		this.comentario = comentario;
	}
	public StatusControlMatricesEnum getStatus() {
		return status;
	}
	public void setStatus(StatusControlMatricesEnum status) {
		this.status = status;
	}
	public String getPo() {
		return po;
	}
	public void setPo(String po) {
		this.po = po;
	}
	public String getCentro() {
		return centro;
	}
	public void setCentro(String centro) {
		this.centro = centro;
	}
	public int getEtd() {
		return etd;
	}
	public void setEtd(int etd) {
		this.etd = etd;
	}
	public String getProveedor() {
		return proveedor;
	}
	public void setProveedor(String proveedor) {
		this.proveedor = proveedor;
	}
	public String getDocumentosRequeridos() {
		return documentosRequeridos;
	}
	public void setDocumentosRequeridos(String documentosRequeridos) {
		this.documentosRequeridos = documentosRequeridos;
	}
	public Integer getMaterial() {
		return material;
	}
	public void setMaterial(Integer material) {
		this.material = material;
	}
	public Integer getxDias() {
		return xDias;
	}
	public void setxDias(Integer xDias) {
		this.xDias = xDias;
	}
	
}
