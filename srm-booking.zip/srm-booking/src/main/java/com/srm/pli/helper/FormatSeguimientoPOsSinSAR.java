package com.srm.pli.helper;

import java.util.List;

import javax.servlet.ServletException;

import org.apache.commons.lang3.StringEscapeUtils;

import com.srm.pli.dao.SAR_CDI_DAO;
import com.srm.pli.utils.FuncionesComunesPLI;
import com.truper.businessEntity.ImportacionesProveedoresBean;
import com.truper.businessEntity.SeguimientoPOsSinSARBean;
import com.truper.businessEntity.UserBean;
import com.truper.infra.loggers.BaseLogger;

public class FormatSeguimientoPOsSinSAR {
	private String po;
	private String mes;
	private String supplier;
	private String supplierName;
	private String etd;
	private String intEtd;
	private String montoBO;
	private String montoBOSinFormato;
	private String planningResponsible;
	private String fungRuiResponsible;
	private String buResponsible;
	private String booking;
	private String container;
	private String shipmentOnTime;
	private String comments;
	private String folio;
	private String status;
	private String piDate;
	
	public FormatSeguimientoPOsSinSAR(SeguimientoPOsSinSARBean bean) {
		try {
			po = bean.getPo() == null ? "" : bean.getPo();
			setMes(bean.getMes() == null ? "" : bean.getMes().toString());
			supplier = bean.getSupplier() == null ? "" : bean.getSupplier();
			ImportacionesProveedoresBean ipb = FuncionesComunesPLI.getProveedor(bean.getSupplier());
			supplierName = bean.getSupplier() == null ? "" : ipb == null ? "" : ipb.getNombreProveedor();
			etd = bean.getEtd() == null ? "" : FuncionesComunesPLI.formateaFecha(bean.getEtd());
			intEtd = bean.getEtd() == null ? "" : bean.getEtd() + "" ;
			montoBO = bean.getMontoBO() == null ? "" : FuncionesComunesPLI.formatea(bean.getMontoBO().doubleValue(), 2) ;
			montoBOSinFormato = bean.getMontoBO() == null ? "" : bean.getMontoBO().doubleValue() + "";
			UserBean user = new UserBean();
			user.setUserName(bean.getPlanningResponsible());
			List<UserBean> lstUsrs = SAR_CDI_DAO.dameUsuarios(user);		
			planningResponsible = bean.getPlanningResponsible() == null ? "" : lstUsrs == null || lstUsrs.isEmpty() ? "" : StringEscapeUtils.escapeHtml3(lstUsrs.get(0).getRealName());
			user.setUserName(bean.getFungRuiResponsible());
			lstUsrs = SAR_CDI_DAO.dameUsuarios(user);
			fungRuiResponsible = bean.getFungRuiResponsible() == null ? "" : lstUsrs == null || lstUsrs.isEmpty() ? "" : StringEscapeUtils.escapeHtml3(lstUsrs.get(0).getRealName());
			buResponsible = bean.getFungRuiResponsible() == null ? "" : StringEscapeUtils.escapeHtml3(bean.getBuResponsible());
			booking = bean.getBooking() == null ? "" : StringEscapeUtils.escapeHtml3(bean.getBooking());
			container = bean.getContainer() == null ? "" : StringEscapeUtils.escapeHtml3(bean.getContainer());
			shipmentOnTime = bean.getOnTime() == null ? "-1" : bean.getOnTime() + "";
			comments = bean.getComments() == null ? "" : StringEscapeUtils.escapeHtml3(bean.getComments());
			folio = bean.getFolio() == null || bean.getFolio() == 0 ? "" : bean.getFolio() + "";
			status = bean.getStatus() == null ? "-1" : bean.getStatus() + "";
			piDate	= bean.getPiDate() == null ? "" : FuncionesComunesPLI.formateaFecha(bean.getPiDate());
		} catch (ServletException e) {
			BaseLogger.BOOKING_LOGGER.error("[FormatSeguimientoPOsSinSAR] Error al dar formato.", e);
		}
	}

	public String getPo() {
		return po;
	}

	public void setPo(String po) {
		this.po = po;
	}

	public String getMes() {
		return mes;
	}

	public void setMes(String mes) {
		this.mes = mes;
	}

	public String getSupplier() {
		return supplier;
	}

	public void setSupplier(String supplier) {
		this.supplier = supplier;
	}

	public String getSupplierName() {
		return supplierName;
	}

	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}

	public String getEtd() {
		return etd;
	}

	public void setEtd(String etd) {
		this.etd = etd;
	}

	public String getIntEtd() {
		return intEtd;
	}

	public void setIntEtd(String intEtd) {
		this.intEtd = intEtd;
	}

	public String getMontoBO() {
		return montoBO;
	}

	public void setMontoBO(String montoBO) {
		this.montoBO = montoBO;
	}

	public String getMontoBOSinFormato() {
		return montoBOSinFormato;
	}

	public void setMontoBOSinFormato(String montoBOSinFormato) {
		this.montoBOSinFormato = montoBOSinFormato;
	}

	public String getPlanningResponsible() {
		return planningResponsible;
	}

	public void setPlanningResponsible(String planningResponsible) {
		this.planningResponsible = planningResponsible;
	}

	public String getFungRuiResponsible() {
		return fungRuiResponsible;
	}

	public void setFungRuiResponsible(String fungRuiResponsible) {
		this.fungRuiResponsible = fungRuiResponsible;
	}

	public String getBuResponsible() {
		return buResponsible;
	}

	public void setBuResponsible(String buResponsible) {
		this.buResponsible = buResponsible;
	}

	public String getBooking() {
		return booking;
	}

	public void setBooking(String booking) {
		this.booking = booking;
	}

	public String getContainer() {
		return container;
	}

	public void setContainer(String container) {
		this.container = container;
	}

	public String getShipmentOnTime() {
		return shipmentOnTime;
	}

	public String isShipmentOnTime() {
		return shipmentOnTime;
	}

	public void setShipmentOnTime(String shipmentOnTime) {
		this.shipmentOnTime = shipmentOnTime;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getFolio() {
		return folio;
	}

	public void setFolio(String folio) {
		this.folio = folio;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getPiDate() {
		return piDate;
	}

	public void setPiDate(String piDate) {
		this.piDate = piDate;
	}
	
}
