package com.srm.pli.bo;

import java.io.Serializable;
import java.util.List;

import com.truper.businessEntity.BeanDocumentoSet;

public class StatusDocumentosBean implements Serializable{
	
	private static final long serialVersionUID = 1L;
	private List<BeanDocumentoSet> listaDocs;
	private boolean facturasCompletas;
	private boolean preBl;
	private boolean Bl;
	private boolean PKL;
	private boolean otrosDocumentos;
	
	
	public List<BeanDocumentoSet> getListaDocs() {
		return listaDocs;
	}
	public void setListaDocs(List<BeanDocumentoSet> listaDocs) {
		this.listaDocs = listaDocs;
	}
	public boolean isFacturasCompletas() {
		return facturasCompletas;
	}
	public void setFacturasCompletas(boolean facturasCompletas) {
		this.facturasCompletas = facturasCompletas;
	}
	public boolean isPreBl() {
		return preBl;
	}
	public void setPreBl(boolean preBl) {
		this.preBl = preBl;
	}
	public boolean isBl() {
		return Bl;
	}
	public void setBl(boolean bl) {
		Bl = bl;
	}
	public boolean isPKL() {
		return PKL;
	}
	public void setPKL(boolean pKL) {
		PKL = pKL;
	}
	public boolean isOtrosDocumentos() {
		return otrosDocumentos;
	}
	public void setOtrosDocumentos(boolean otrosDocumentos) {
		this.otrosDocumentos = otrosDocumentos;
	}
	
}
