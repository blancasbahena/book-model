package com.srm.pli.helper;

public class SarHelper {

	private static SarHelper instance;
	private static final int FECHA_MINIMA = 19891230;

	private SarHelper() {
	}

	public static SarHelper getInstance() {
		if (instance == null)
			instance = new SarHelper();
		return instance;
	}

	public Integer getFechaEtdReal(Integer fechaEmbarque, Integer etdFinal) {
		if (fechaEmbarque == null && etdFinal == null)
			return null;
		if (fechaEmbarque == null && etdFinal != null)
			return etdFinal;
		if (fechaEmbarque != null && etdFinal == null)
			return fechaEmbarque;
		int fechaEtdFinal = etdFinal.intValue();
		if (fechaEtdFinal > FECHA_MINIMA)
			return etdFinal;
		return fechaEmbarque;
	}

}
