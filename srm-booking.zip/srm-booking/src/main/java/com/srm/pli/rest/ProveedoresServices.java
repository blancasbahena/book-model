package com.srm.pli.rest;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.net.URLDecoder;
import java.nio.file.Files;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;
import javax.ws.rs.core.UriInfo;

import org.apache.commons.io.FilenameUtils;
import org.apache.poi.util.IOUtils;
import org.json.JSONArray;
import org.json.JSONObject;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.srm.fungandrui.expediente.service.ExpedienteService;
import com.srm.fungandrui.expediente.service.ExpedienteServiceImp;
import com.srm.pli.bo.FileUploadBO;
import com.srm.pli.bo.HistoryLogBean;
import com.srm.pli.bo.SarBO;
import com.srm.pli.bo.SarDetalleBO;
import com.srm.pli.bo.SarDetalleJasper;
import com.srm.pli.bo.StatusDocumentosBean;
import com.srm.pli.dao.CatalogosTablas;
import com.srm.pli.dao.SAR_CDI_DAO;
import com.srm.pli.documents.ShpmntsWdocsService;
import com.srm.pli.enums.DocumentosAccionEnum;
import com.srm.pli.enums.HistoryLogAction;
import com.srm.pli.helper.DocumentosHelper;
import com.srm.pli.helper.FormatSAR;
import com.srm.pli.helper.FormatSARDetalle;
import com.srm.pli.helper.FormatSARDetalleHelper;
import com.srm.pli.helper.HistoryLogHelper;
import com.srm.pli.services.DocumentosServices;
import com.srm.pli.services.SarDetailServices;
import com.srm.pli.services.impl.HistoryLogServiceImpl;
import com.srm.pli.services.impl.ProveedoresServicesImpl;
import com.srm.pli.utils.DeleteFile;
import com.srm.pli.utils.FormatoUtils;
import com.srm.pli.utils.FuncionesComunesPLI;
import com.srm.pli.utils.GeneraDocumentos;
import com.srm.pli.utils.GeneraDocumentosUtils;
import com.srm.pli.utils.PropertiesDb;
import com.sun.jersey.core.header.FormDataContentDisposition;
import com.sun.jersey.multipart.FormDataParam;
import com.truper.bpm.enums.TipoDocumentosEnum;
import com.truper.businessEntity.BeanBL;
import com.truper.businessEntity.BeanCommonResponse;
import com.truper.businessEntity.BeanControlSDI;
import com.truper.businessEntity.BeanDocumentoSet;
import com.truper.businessEntity.BeanDocumentosSDI;
import com.truper.businessEntity.BeanFactura;
import com.truper.businessEntity.BeanOtrosDocumentos;
import com.truper.businessEntity.BeanPL;
import com.truper.businessEntity.ProductoBean;
import com.truper.businessEntity.SAR;
import com.truper.businessEntity.UpdateDataDetail;
import com.truper.businessEntity.UserBean;
import com.truper.businessEntity.pojo.BuscaDocumentoPojo;
import com.truper.expediente.AnexosDTO;
import com.truper.expediente.DocumentoDTO;
import com.truper.expediente.ExpedientePerfilDTO;
import com.truper.expediente.TotalFacturaDTO;
import com.truper.infra.rs.BaseRS;
import com.truper.utils.string.UtilsString;

import lombok.extern.log4j.Log4j2;
@Log4j2
@Path("/proveedoresServices")
public class ProveedoresServices extends BaseRS{
	
	private static final long serialVersionUID = -3295258570394852215L;
	private static Gson gson = new GsonBuilder()
			.serializeSpecialFloatingPointValues().create();
	
	public static String TIPOPREBL = "PBL";
	public static String TIPOBL = "BL";
	public static String TIPOINVOICE = "INVOICE";
	public static String TIPOOTHERS = "OTHERS";
	public static String TIPOPKL = "PL";
	private static int   VERSION_INI = 1;
	private final String pathTemporal =  PropertiesDb.getInstance().getString("srm.truper.expediente.folder.local");
	private static final String POS_FIJO_ID_UNICO="_@_";
	private final boolean esNecesarioBorrarArchivo=true;
	private ExpedienteService expedienteService= new ExpedienteServiceImp(); 
	private SAR_CDI_DAO daoSAR= new SAR_CDI_DAO();
	@GET
	@Path("/dameDatosFacturas")
	public Response dameDatosFacturas(@Context UriInfo ui) {
		Response r = null;
		MultivaluedMap<String, String> map = ui.getQueryParameters();
		String folio = map.getFirst("folio");
		String booking = map.getFirst("booking");
		String proveedor = map.getFirst("proveedor");
		
		SarBO boTot = null;
		JSONObject jsonRestul = new JSONObject();
		String condicionesYaFacturadas = "";
		try {			
			int folioint = Integer.parseInt(folio);
			SarBO bo = new SarBO();
			bo.setFolio(folioint);
			////Voy a buscar los folios que tengan el booking
			
			ArrayList<Integer> listaSars = SAR_CDI_DAO.selectSarsConMismoBooking(proveedor, booking);
			///1.- Mandar a llamar metodo que me regresa los detalles de la lista de SARs
			boTot = FuncionesComunesPLI.concentraTotalesDeFoliosEnUno(listaSars,null,false);			
			///2.- obtengo datos de documentos para el este booking, si no existe creo el registro
			boTot.setBooking(booking);
			boTot.setProveedor(proveedor);
			BeanDocumentosSDI documentos =  dameRegistroDocumentos(boTot);
			///2.- recorrer los detalles  y separar por condicion de pago
			HashSet<String> condicionPago = new HashSet<String>();
			for(SarDetalleBO det : boTot.getDetalleBO()) {
				condicionPago.add(det.getCondicionPago());
			}
			////Voy por los registros de la tabla de facturas si no hay, son versiones nuevas ya ya existen
			/// debo generar boton de download
			
			ArrayList<BeanFactura> facturas = SAR_CDI_DAO.selectFactura(null, documentos);
			
			
			if(facturas.size() > 0 ) {
				for(BeanFactura fa : facturas ) {
					condicionesYaFacturadas += fa.getCondicionDePago()+";";
				}
			}///Si es = 0 no existe ninguna factura para ese numero de version
			////junto todos los detalles en un array que voy a recorrer por cada condicion de pago
			JSONArray detallePorCondpago = null;
			JSONArray tituloCondPago = null;
			String moneda = "";
			moneda = GeneraDocumentosUtils.getInstance().getMonedaParaFactura(boTot.getDetalleBO());
			ArrayList<SarDetalleJasper> listaDetallesVista = GeneraDocumentosUtils.getInstance().generaBeanInvoice(false, boTot.getDetalleBO());
			ArrayList<SarDetalleJasper> listaDetallesOtrosVista = GeneraDocumentosUtils.getInstance().generaBeanInvoice(true, boTot.getDetalleOthers());
			
			SarBO boTmp = bo.clone();
			FuncionesComunesPLI.sacaTotales(boTmp, boTmp.getDetalleBO(), boTot.getDetalleOthers());
			List<String> sortedlist = new ArrayList<>(condicionPago);
			///Recorro las condiciones de pago y genero los gson
			tituloCondPago = new JSONArray();
			boolean primerCondicion = true;
			for(String condPago : sortedlist) {
				JSONObject cabeza = new JSONObject();
				cabeza.put("condicionPago", condPago);
				cabeza.put("condPagoDesc", FuncionesComunesPLI.dameMapaCondicionPago(false).get(condPago) );
				boolean facturado =false;
				if(condPago!=null && !condPago.isEmpty()){
					facturado = condicionesYaFacturadas.contains(condPago);
				}
				cabeza.put("facturado" , facturado);
				cabeza.put("idDocumental" , documentos.getId());
				cabeza.put("versionDoc" , documentos.getVersionFacturas());
				cabeza.put("proveedor" , documentos.getProveedor());
				
				detallePorCondpago = new JSONArray();
				ArrayList<SarDetalleJasper> listaDetallesCond = GeneraDocumentosUtils.getInstance().limpiaArreglo(listaDetallesVista, condPago);
				for(SarDetalleJasper tmp : listaDetallesCond) {
					detallePorCondpago.put(gson.toJson(tmp));
				}
				if(primerCondicion) {
					for(SarDetalleJasper tmp : listaDetallesOtrosVista) {
						detallePorCondpago.put(gson.toJson(tmp));
					}
				}
				primerCondicion = false;
				cabeza.put("detalles", detallePorCondpago);
				tituloCondPago.put(cabeza);
			}
			jsonRestul.put("moneda", moneda);
			jsonRestul.put("datos", tituloCondPago);
			jsonRestul.put("errorCode", 0);
			jsonRestul.put("mensaje", "OK");

		}catch(Exception e) {
			jsonRestul.put("errorCode", 1);
			jsonRestul.put("mensaje", "Error: "+e.getMessage());
			r = buildError_JSONResponse(e.getMessage());  
			return r;
		}
		r = buildOKResponse(jsonRestul.toString());
		return r;
	}
	
	
	
	@GET
	@Path("/revisarStatus")
	@Produces(MediaType.APPLICATION_JSON)
	public Response revisarStatus(@Context UriInfo ui) {
		Response r = null;
		MultivaluedMap<String, String> map = ui.getQueryParameters();		
		String id = map.getFirst("id");
		JSONObject jsonRestul = new JSONObject();
		try {			
			int idInt = Integer.parseInt(id);
			
			BeanDocumentosSDI docs = SAR_CDI_DAO.selectDocumentosSDI(idInt);
			
			jsonRestul.put("tieneFactura", Boolean.TRUE.equals(docs.getFacturasCompletas()) );
			jsonRestul.put("tienePL", Boolean.TRUE.equals(docs.getPackingListGenerado()));
			jsonRestul.put("tieneBL", Boolean.TRUE.equals(docs.getBlGenerado()));
			jsonRestul.put("tienePreBL", Boolean.TRUE.equals(docs.getPreBLGenerado()));
			jsonRestul.put("tieneOtrosDocumentos", docs.getTieneOtrosDocumentos());
			jsonRestul.put("booking", docs.getBooking());
			
			
			String leyendaCtns = "";
            if(docs.getCartons() != null && docs.getCartons() > 0) {
            	leyendaCtns = FuncionesComunesPLI.formatea(docs.getCartons()) + " CTNS PACKED IN: " +
                		FuncionesComunesPLI.formatea(docs.getPallets()) + " PALLETS " +
                		(docs.getBulks() != null && docs.getBulks() > 0 ? 
                				"+ " + FuncionesComunesPLI.formatea(docs.getBulks()) +" BULKS": "");
                        	
            }

            jsonRestul.put("pl_msgcartons", leyendaCtns);
        	
			
			jsonRestul.put("errorCode", 0);
			jsonRestul.put("mensaje", "OK");
						
		}catch(Exception e) {
			jsonRestul.put("errorCode", 1);

			jsonRestul.put("mensaje", "Error: "+e.toString());
			r = buildErrorResponse(jsonRestul);
			return r;
		}
		r = buildOKResponse(jsonRestul.toString());
		return r;
	}
	
	@POST
	@Path("/generaFactura")
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	public Response generaFactura(@FormParam("condicion") String condicion, @FormParam("numeroFact") String numeroFact,
			@FormParam("madera") Boolean isMadera, @FormParam("proveedor") String proveedor, @FormParam("id") int id,
			@FormParam("versionDocumental") int versionDocumental, @FormParam("paisOrigen") String paisOrigen,
			@FormParam("esPrimerFactura") int esPrimerFactura,@FormParam("sar") String sar,
			@Context HttpServletRequest request) {

		Response r = null;
		JSONObject jsonRestul = new JSONObject();
		try {
			BeanDocumentosSDI docBase = new BeanDocumentosSDI();
			docBase.setId(id);
			docBase.setVersionFacturas(versionDocumental);
			ArrayList<BeanFactura> listaFacturas = SAR_CDI_DAO.selectFactura(null, docBase);
			//// Generar funcion para buscar si el numero de factura ya fue utilizado
			if (SAR_CDI_DAO.nombreYaExiste(numeroFact, proveedor)) {
				throw new ServletException(
						"You can not repeat the number of an existing invoice, please change the Invoice No. and try again. ");
			}

			BeanDocumentosSDI bds = SAR_CDI_DAO.selectDocumentosSDI(id);
			if(bds!=null) {
				if(bds.getProveedor()!=null && bds.getBooking()!=null) {
					SarBO bean = new SarBO();
					bean.setProveedor(bds.getProveedor());
					bean.setBooking(bds.getBooking());
					ArrayList<SarBO> lista = daoSAR.selectSar(bean,false);
					if(lista!=null && lista.size()>0) {
						sar =  lista.get(0).getFolio().toString();
					}
				}
			}
			if(id>0 && sar!=null) {
				seMandaABorrarDocumentoAExpedienteOtherVersion(id, sar,condicion,TipoDocumentosEnum.FACTURA_PROVEEDOR.getId());
			}else {
				log.error("Problemas con datos {} , {} ",id,sar);
			}
			// Generar funcion para buscar si el numero de factura ya fue utilizado
			String path = DocumentosHelper.getInstance().dameRutaArchivos(proveedor, bds.getBooking());
			Long idUnico =  (new Date()).getTime(); 
			String fileName =numeroFact + ".pdf";
			BeanFactura factura = new BeanFactura();
			factura.setRutaArchivo(path + fileName);
			factura.setCondicionDePago(condicion);
			factura.setTieneMadera(isMadera);
			factura.setNombre(numeroFact);
			factura.setPaisOrigen(paisOrigen);
			factura.setId(id);
			HashMap<String, String> mapaDeConditions = CatalogosTablas.selectCondicionesPago();
			String conditions =condicion+" | "+mapaDeConditions.get(condicion);
			factura.setVersionDocumento(versionDocumental);
			factura.setTieneOtros(esPrimerFactura == 1 ? true : false);
			GeneraDocumentos genera = new GeneraDocumentos();
			TotalFacturaDTO totalesInvoice =genera.generaFactura(factura, versionDocumental, id, condicion,conditions, path, fileName,(esPrimerFactura == 1 ? true : false));
			UserBean usuario = (UserBean)request.getSession().getAttribute("usuario");
			String username = HistoryLogHelper.getInstance().getUserName(usuario);
			int facturaCreada = SAR_CDI_DAO.insertFactura(factura) ? 1 : 0;
			/// Aqui busco si me falta alguna condicion por facturar, si ya estan todas,
			/// marco el status
			List<String> condicionesPagoEnBooking = FuncionesComunesPLI.dameCondicionesPagoPorBooking(id);
			log.info("condicionesPagoEnBooking {} , facturas creadas {} , existe-> {} ",condicionesPagoEnBooking,(listaFacturas.size() + facturaCreada),existeEnList(condicionesPagoEnBooking,condicion) );
			if ((listaFacturas.size() + facturaCreada) <= condicionesPagoEnBooking.size() && existeEnList(condicionesPagoEnBooking,condicion) ) {
				/// Si se cumple, ya estan todas las condiciones de pago con factura, puedo
				/// cerrar el status
				BeanDocumentosSDI documentos = new BeanDocumentosSDI();
				documentos.setId(id);
				documentos.setFacturasCompletas(true);
				documentos.setVersionSDI(versionDocumental);
				documentos.setTotal(totalesInvoice.getTotal());
				documentos.setSubTotal(totalesInvoice.getSubtotal());
				documentos.setSubTotalFocs(totalesInvoice.getFocs());
				documentos.setSubTotalOthers(totalesInvoice.getOthers());
				SAR_CDI_DAO.updateDocumentosSDI(documentos);
				/*
				 * Servicio para generar archivo a SharePoint y BD Expediente
				 */ 
				if(getFlagFacturacion(proveedor)) {
					creaDocumentoSharePoint(SAR_CDI_DAO.selectSarsEnBooking(id),proveedor,TipoDocumentosEnum.FACTURA_PROVEEDOR.getId() , username,
						expedienteService.copyReturnPath(path,fileName,pathTemporal,idUnico,POS_FIJO_ID_UNICO),fileName,idUnico,conditions);
				}
			}
				
			HistoryLogBean historyLogBean = HistoryLogBean.builder()
					.tipoAccion(HistoryLogAction.GENERATE_INVOICE.id())
					.Id(id)
					.username(username).build();
			
			log.info("Datos a insertar en el history log: Accion:{}, username: {} ", historyLogBean.getTipoAccion(), historyLogBean.getUsername());
			HistoryLogServiceImpl.getInstance().saveHistoryLog(historyLogBean);

			jsonRestul.put("errorCode", 0);
			jsonRestul.put("mensaje", "PO  updated correctly.");
			jsonRestul.put("booking", bds.getBooking());
			r = buildOKResponse(jsonRestul.toString());

		} catch (Exception e) {
			// TODO Auto-generated catch block
			jsonRestul.put("errorCode", 1);
			jsonRestul.put("mensaje", e.getMessage());
			r = buildErrorResponse("Error while trying generate the invoice: " + e.getMessage());
		}
		return r;
	}
	



	private boolean existeEnList(List<String> condicionesPagoEnBooking, String condicion) {
		for(String condicionEnLista: condicionesPagoEnBooking) {
			if(condicionEnLista.equals(condicion)) {
				return true;
			}
		}
		return false;
	}



	@POST
    @Path("/cambioVersionFactura")
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    public Response cambiaNumeroVersion(@FormParam("id") Integer id, @FormParam("folio") String folio) {
        Response r = null;
        JSONObject jsonRestul = new JSONObject();
        try {
            List<BeanFactura> lista= SAR_CDI_DAO.selectFacturaXId(id);
            BeanDocumentosSDI doc = ProveedoresServicesImpl.getInstance().cambioVersionFacturaById(id);
            
            jsonRestul.put("errorCode", 0);
            jsonRestul.put("mensaje", "PO  updated correctly.");
            jsonRestul.put("booking", doc.getBooking());
            jsonRestul.put("proveedor", doc.getProveedor());
            r = buildOKResponse(jsonRestul.toString());
            
            if(!lista.isEmpty()) {
            	if(lista.size()>=1 && folio.equals("0")) {
            		for(BeanFactura fact:lista) {
            			String nombre=FilenameUtils.getName(fact.getRutaArchivo());
            			borraDocs(id,TipoDocumentosEnum.FACTURA_PROVEEDOR.getId(),nombre);
            			}
            		}else {
            			SAR sar = SAR_CDI_DAO.getSARByFolio(folio);
                    	borraAllDocs(sar.getBl()+sar.getContenedor(),Long.parseLong(""+TipoDocumentosEnum.FACTURA_PROVEEDOR.getId())); 
            		}
            	}else {
        			SAR sar = SAR_CDI_DAO.getSARByFolio(folio);
                	borraAllDocs(sar.getBl()+sar.getContenedor(),Long.parseLong(""+TipoDocumentosEnum.FACTURA_PROVEEDOR.getId())); 
            	}
        } catch (Exception e) {
            log.error("Error while trying generate the invoice: "+e.getMessage() , e.getMessage());
            r = buildErrorResponse("Error while trying generate the invoice: "+e.getMessage() );
        }
        return r;
    }
	
	@GET
	@Path("/downloadInvoce")
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Produces("application/pdf")
	public Response downloadInvoice(@Context UriInfo ui) {
		Response r = null;
		Long idUnico= (new Date()).getTime();
		MultivaluedMap<String, String> map = ui.getQueryParameters();
		String id = map.getFirst("id");
		String condicion = map.getFirst("condicion");
		HashMap<String, String> mapaDeConditions;
		String conditions ="";
		try {
			mapaDeConditions = CatalogosTablas.selectCondicionesPago();
			conditions =condicion+" - "+mapaDeConditions.get(condicion);
		} catch (ClassNotFoundException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		} catch (SQLException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		BeanFactura fact =null;
		try {
			fact = SAR_CDI_DAO.selectFacturaXId(Integer.parseInt(id), condicion);
		} catch (Exception ioE) {
			log.error("Error al intentar generar el archivo", ioE);
			r = buildErrorResponse();
		}
		/**First Download in Share Point ***/
		BeanDocumentosSDI documentosObj = null;
		try {
			documentosObj = SAR_CDI_DAO.selectDocumentosSDI(new Integer(id));
		} catch (NumberFormatException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (ServletException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		boolean flagFacturacion= getFlagFacturacion(documentosObj.getProveedor());
		try {
			FileUploadBO  fileUploadBO= flagFacturacion ? 
					getFileByIdBookingOnlyRead(id,documentosObj.getProveedor(),fact.getRutaArchivo(),TipoDocumentosEnum.FACTURA_PROVEEDOR.getId()):
						null;
			if(fileUploadBO!=null) {
				log.info("Se crea un documento con el id  ::  "+idUnico + " ->  "+pathTemporal+  File.separator +fileUploadBO.getFileName());
				File fileFromSharePoint= new File(pathTemporal+  File.separator +fileUploadBO.getFileName());
				if(fileFromSharePoint!=null && fileFromSharePoint.isFile()) { 
					ResponseBuilder response = Response.ok(fileFromSharePoint, MediaType.APPLICATION_OCTET_STREAM);
					response.header("Content-Disposition", "attachment; filename="+fileUploadBO.getFileName().replaceAll(fileUploadBO.getIdUnico()+POS_FIJO_ID_UNICO,""));
					response.header("Content-Type",fileUploadBO.getContentType());
					(new DeleteFile(fileFromSharePoint)).start();
					return response.build(); 
				}
			}
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		/**Second Download in Local folder */		
		AnexosDTO anexos=null;
		try {										
			File file = new File(fact.getRutaArchivo());
			File fileDest = new File(pathTemporal+File.separator+idUnico+POS_FIJO_ID_UNICO+file.getName());
			if(flagFacturacion) {
				if(expedienteService.copy(file,fileDest)) {
					creaDocumentoSharePoint(SAR_CDI_DAO.selectSarsEnBooking(Integer.parseInt(id)),documentosObj.getProveedor(),TipoDocumentosEnum.FACTURA_PROVEEDOR.getId() ,
							fileDest,idUnico,conditions,anexos);
				}
			}
			ResponseBuilder response = Response.ok(file, MediaType.APPLICATION_OCTET_STREAM);
			response.header("Content-Disposition", "attachment; filename=Invoice_"+fact.getCondicionDePago()+".xls");
			response.header("Content-Type","application/pdf");
			r = response.build();
		} catch (Exception ioE) {
			log.error("Error al intentar generar el archivo", ioE);
			r = buildErrorResponse();
		}
		
		return r;
	}
	



	@GET
	@Path("/dameDatosPL")
	@Produces(MediaType.APPLICATION_JSON)
	public Response dameDatosPL(@Context UriInfo ui) {
		Response r = null;
		MultivaluedMap<String, String> map = ui.getQueryParameters();
		String booking = map.getFirst("booking");
		String id = map.getFirst("id");
		JSONObject jsonRestul = new JSONObject();
		String coma = ",",CERO="0",VACIO="";
		String ND = "N.D";
		String CERO_CERO = "0.00";
		try {
			int idInt =Integer.parseInt(id);
			
			BeanDocumentosSDI documentosObj = SAR_CDI_DAO.selectDocumentosSDI(idInt);
			ArrayList<Integer> listaSars = SAR_CDI_DAO.selectSarsEnBooking(idInt);
			
			SarBO  boTot = new SarBO();
			boTot.setFolio(listaSars.get(0));
			SAR_CDI_DAO dao = new SAR_CDI_DAO();
			ArrayList<SarBO> lista =  dao.selectSar(boTot,false);
			boTot = lista.get(0);
			boTot = FuncionesComunesPLI.concentraTotalesDeFoliosEnUno(listaSars,boTot,true);
			boTot.setDetalle(FuncionesComunesPLI.filtrarSER(boTot.getDetalle()));
			boTot.setDetalleBO(FuncionesComunesPLI.filtrarBOSER(boTot.getDetalleBO()));
			boTot.setDetalleOthers(FuncionesComunesPLI.filtrarBOSER(boTot.getDetalleOthers()));
			boTot.setDetalleOtros(FuncionesComunesPLI.filtrarSER(boTot.getDetalleOtros()));
			FormatSAR format = new FormatSAR(boTot, null, true);
			boolean esGeneraPL = true;
			BeanPL pl = SAR_CDI_DAO.selectPL(idInt);
			if(pl != null && pl.getVersionDocumento() == documentosObj.getVersionPK()) {
				esGeneraPL = false;
			}
			//voy por las facturas que tiene el PKL
			ArrayList<BeanFactura> listaFacturas = SAR_CDI_DAO.selectFactura(null, documentosObj);
			StringBuffer buf = new StringBuffer();
			int cont = 0;
			for(BeanFactura f : listaFacturas ) {
				if(cont > 0) {
					buf.append(coma);
				}
				cont++;
				buf.append(f.getNombre());
			}
			FormatSARDetalleHelper formatSar = new FormatSARDetalleHelper();
			format = formatSar.setLetoniano(format);
			//Recorro los detalles para hacer el set de los cartones.
			if(format.getDetalle() != null) {
				for(FormatSARDetalle det : format.getDetalle()) {
					try {
						ProductoBean p = FuncionesComunesPLI.productos.get(det.getMaterial().toString());
						if(p != null) {
							double master = p.getMaster();
							if(master==0)
								master =1;
							double redondeo = det.getCantidadSinFormato() / master;
							if(CERO.equals(det.getCartones())  ) {
								det.setCartonesEnSAP(FormatoUtils.getInstance().roundCeiling(redondeo));
							}else {
								det.setCartonesEnSAP(Integer.parseInt(det.getCartones()));
							}
							
							
							if(UtilsString.isNullOrUndefined(det.getCubicajePKL()) || ND.equals(det.getCubicajePKL()) || CERO_CERO.equals(det.getCubicajePKL())) {
								det.setCubicajePKL(det.getVolumenProveedor());
							}
							if(UtilsString.isNullOrUndefined(det.getPesoNetoPKL()) || ND.equals(det.getPesoNetoPKL()) || CERO_CERO.equals(det.getPesoNetoPKL())) {
								det.setPesoNetoPKL(det.getPesoProveedor());
							}
						}
					}catch (Exception e) {
						log.error("Error en el formateo del objeto formatSAR:" , e);
					}
				}
			}
			if(format.getDetalleOthers() != null) {
				for(FormatSARDetalle det : format.getDetalleOthers()) {
					try {
							if(UtilsString.isNullOrUndefined(det.getCubicajePKL()) || ND.equals(det.getCubicajePKL()) || 
									CERO_CERO.equals(det.getCubicajePKL()) || VACIO.equals(det.getCubicajePKL())) {
								det.setCubicajePKL(det.getVolumenProveedor());
							}
							if(UtilsString.isNullOrUndefined(det.getPesoNetoPKL()) || ND.equals(det.getPesoNetoPKL()) || 
									CERO_CERO.equals(det.getPesoNetoPKL()) || VACIO.equals(det.getPesoNetoPKL())) {
								det.setPesoNetoPKL(det.getPesoProveedor());
							}
					}catch (Exception e) {
						log.error("Error en el formateo del objeto formatSAR:" , e);
					}
				}
			}
			
			jsonRestul.put("datos", gson.toJson(format, new TypeToken<FormatSAR>(){}.getType()).toString());
			jsonRestul.put("esGeneraPL", esGeneraPL);
			jsonRestul.put("errorCode", 0);
			jsonRestul.put("mensaje", "OK");
			jsonRestul.put("booking", booking);
			jsonRestul.put("facturas", buf.toString());
			
		}catch(Exception e) {
			jsonRestul.put("errorCode", 1);
			jsonRestul.put("mensaje", "Error: "+e.toString());
			r = buildErrorResponse(jsonRestul);
			log.error("Error al intentar generar el packing list", e.getMessage());
			return r;
		}
		r = buildOK_JSONResponse(jsonRestul);
		return r;
	}
	
	
	@POST
	@Path("/generaPL")
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	public Response generaPL(
			@FormParam("booking") String booking,
			@FormParam("id") int id,
			@FormParam("cartons") Integer cartons,
			@FormParam("pallets") Integer pallets,
			@FormParam("bulks") Integer bulks,
			@Context HttpServletRequest request) {
		
		Response r = null;
		JSONObject jsonRestul = new JSONObject();
		GregorianCalendar greg1 = new GregorianCalendar();
		int year = FuncionesComunesPLI.gregorianCalendar2int(greg1);
		year = year / 10000;
		
		try {
			BeanDocumentosSDI documentos = SAR_CDI_DAO.selectDocumentosSDI(id);
			log.info("Obtiene datos para PL");
			GeneraDocumentos genera = new GeneraDocumentos();
			String path = DocumentosHelper.getInstance().dameRutaArchivos(documentos.getProveedor(), booking);
			Long idUnico =  (new Date()).getTime();
	    	String fileName =  "PL_"+documentos.getVersionSDI()+".pdf";
			documentos.setCartons(cartons);
			documentos.setPallets(pallets);
			documentos.setBulks(bulks);
			borraDocs(id,TipoDocumentosEnum.PL.getId(),fileName);
			//////////Aqui mando a generar el archivo y enviarlo a download.truper.com//////////
			genera.generaPKL(booking,id,documentos, path, fileName);
			//////////Aqui Me falta mandar a actualizar la tabla de documentos y versiones //////////
	    	
			////Actualizo status en tablas de PL y documentos
			SAR_CDI_DAO.updateDocumentosSDI(documentos);
			BeanPL plObj = new BeanPL();
			plObj.setId(id);
			plObj.setNombre(fileName);
			plObj.setRutaArchivo(path+fileName);
			plObj.setVersionDocumento(documentos.getVersionPK());
			log.info("Modifica el SDI de los datos del documento");
			if(SAR_CDI_DAO.insertaPL(plObj)) {
				BeanDocumentosSDI tablaDocs = new BeanDocumentosSDI();
				tablaDocs.setId(id);
				tablaDocs.setPackingListGenerado(true);
				SAR_CDI_DAO.updateDocumentosSDI(tablaDocs);
				jsonRestul.put("errorCode", 0);
				jsonRestul.put("mensaje", "The information was saved properly");
				log.info("inserta PL  en la base de datos ");
				BeanDocumentosSDI documentosObj = SAR_CDI_DAO.selectDocumentosSDI(id); 
				UserBean usuario = (UserBean)request.getSession().getAttribute("usuario");
				String username = HistoryLogHelper.getInstance().getUserName(usuario);
				/*
				 * Servicio para generar archivo a SharePoint y BD Expediente
				 */
				String conditions="";
				log.info("Invoca servicio de creacion documento en sharepoint  {}- {} ",idUnico,fileName);
				if(getFlagFacturacion(documentosObj.getProveedor())) {
					creaDocumentoSharePoint(SAR_CDI_DAO.selectSarsEnBooking(id),documentosObj.getProveedor(),TipoDocumentosEnum.PL.getId(), username,
						expedienteService.copyReturnPath(path,fileName,pathTemporal,idUnico,POS_FIJO_ID_UNICO),fileName,idUnico,conditions);
				}
				
				r = buildOKResponse(jsonRestul.toString());
			}else {
				r = buildErrorResponse("Error The Information of the PL was not saved properly ");
			}
			UserBean usuario = (UserBean)request.getSession().getAttribute("usuario");
			String username = HistoryLogHelper.getInstance().getUserName(usuario);	
			HistoryLogBean historyLogBean = HistoryLogBean.builder()
					.tipoAccion(HistoryLogAction.GENERATE_PL.id())
					.Id(id)
					.username(username).build();
	
			log.info("Datos a insertar en el history log: Accion:{}, username: {} ", historyLogBean.getTipoAccion(), historyLogBean.getUsername());
			HistoryLogServiceImpl.getInstance().saveHistoryLog(historyLogBean);
			
		} catch (Exception e) {
			e.printStackTrace();
			log.error("Error al intentar generar el packing list", e.getMessage());
			r = buildErrorResponse("Error while trying generate the PL, please try again: "+e.getMessage() );
		}
		return r;
	}
	
	
	
	
	@GET
	@Path("/generaEsqueletoPL")
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Produces(MediaType.APPLICATION_OCTET_STREAM)
	public Response generaPLEsqueleto(@Context UriInfo ui) {
		Response r = null;
		GregorianCalendar greg1 = new GregorianCalendar();
		int year = FuncionesComunesPLI.gregorianCalendar2int(greg1);
		year = year / 10000;		
		try {
			MultivaluedMap<String, String> map = ui.getQueryParameters();
			String idStr = map.getFirst("id");
			int id = Integer.parseInt(idStr);
			BeanDocumentosSDI docs = SAR_CDI_DAO.selectDocumentosSDI(id);
			
			GeneraDocumentos genera = new GeneraDocumentos();

			String path = DocumentosHelper.getInstance().dameRutaArchivos(docs.getProveedor(), docs.getBooking());
	        String fileName = "Pre_PL"+docs.getVersionSDI()+".xls";
				        
			ArrayList<Integer> listaSars = SAR_CDI_DAO.selectSarsEnBooking(id);
			SarBO  boTot = new SarBO();
			boTot.setFolio(listaSars.get(0));
			SAR_CDI_DAO dao = new SAR_CDI_DAO();
			ArrayList<SarBO> lista =  dao.selectSar(boTot,false);
			boTot = lista.get(0);
			boTot = FuncionesComunesPLI.concentraTotalesDeFoliosEnUno(listaSars,boTot,false);
			genera.generaPKLEsqueleto(docs.getBooking(), id, boTot, path, fileName);
//			////Actualizo status en tablas de PL y documentos	
			File file = new File(path+File.separator+fileName);
			ResponseBuilder response = Response.ok(file, MediaType.APPLICATION_OCTET_STREAM);
			response.header("Content-Disposition", "attachment; filename=PrePL_.xls");
			response.header("Content-Type","application/pdf");
			r = response.build();
			
		} catch (Exception e) {
			log.error("Error while trying generate the PREBL, please try again: "+e.getMessage() );		
			r = buildErrorResponse("Error while trying generate the PREBL, please try again: "+e.getMessage() );
		}
		return r;
	}
	
	
	@POST
	@Path("/persisteDet")
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	public Response persisteDetalleLinea(@FormParam("po") String po,
			@FormParam("pos") Integer pos,
			@FormParam("cantidad") Integer cantidadBultos,
			@FormParam("pesoNeto") String pesoNeto,
			@FormParam("pesoBruto") String pesoBruto,
			@FormParam("volumen") String volumen,
			@FormParam("booking") String booking,
			@FormParam("folio") int folio,
			@FormParam("id") int id,
			@FormParam("esOtro") int esOtro,
			@FormParam("otherPO") String otherPO,
			@FormParam("material") String material
			) {
		
		

		
		Response r = null;
		JSONObject jsonRestul = new JSONObject();
		try {	
			SarDetalleBO det  = new SarDetalleBO();
			det.setPo(po);
			det.setPosicion(pos);
			det.setFolio(folio);
			det.setCartones(cantidadBultos);
			det.setPesoBrutoPKL(new BigDecimal(pesoBruto));
			det.setPesoNetoPKL(new BigDecimal(pesoNeto) );
			det.setCubicajePKL(new BigDecimal(volumen));
			if(esOtro > 0) {
				det.setPo(otherPO);
				if(SAR_CDI_DAO.actualizaDetalleOtrosDinamico(det)) {
					jsonRestul.put("errorCode", 0);
					jsonRestul.put("mensaje", "PO/POS  updated correctly.");
					r = buildOKResponse(jsonRestul.toString());
				}else {
					jsonRestul.put("errorCode", 1);
					jsonRestul.put("mensaje", "Error please try again");
					r = buildOKResponse(jsonRestul.toString());
				}
			}else {
				if(SAR_CDI_DAO.updateSarDetalleDinamico(det)) {
					SarBO sarBO = new SarBO();
					sarBO.setFolio(folio);
					FuncionesComunesPLI.editaDetalleEnMapa(sarBO, det);
					jsonRestul.put("errorCode", 0);
					jsonRestul.put("mensaje", "PO/POS  updated correctly.");
					r = buildOKResponse(jsonRestul.toString());
				}else {
					jsonRestul.put("errorCode", 1);
					jsonRestul.put("mensaje", "Error please try again");
					r = buildOKResponse(jsonRestul.toString());
				}
			}
			
		} catch (Exception e) {
			r = buildErrorResponse("Error while trying generate the invoice: "+e.getMessage() );
		}
		return r;
	}
	
	
	@POST
	@Path("/cambioVersionPL")
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	public Response cambioVersionPL(@FormParam("id") Integer id) {
		Response r = null;
		JSONObject jsonRestul = new JSONObject();
		try {
			BeanDocumentosSDI docs = SAR_CDI_DAO.selectDocumentosSDI(id);
			if (docs == null || docs.getVersionPK() == null) {
				jsonRestul.put("errorCode", 0);
				r = buildOKResponse(jsonRestul.toString());
				return r;
			}
			docs.setVersionPK(docs.getVersionPK()+1);
			docs.setPackingListGenerado(false);
			SAR_CDI_DAO.updateDocumentosSDI(docs);
			jsonRestul.put("errorCode", 0);
			jsonRestul.put("mensaje", "PO  updated correctly.");
			r = buildOKResponse(jsonRestul.toString());
			log.info("Se modifica la version de PL a una mas de forma correcta.");
			borraDocs(id,TipoDocumentosEnum.PL.getId(),"_PL");
		} catch (Exception e) {
			log.error("Error al intentar cambiar la versión de PL", e.getMessage());
			r = buildErrorResponse("Error while trying generate the invoice: "+e.getMessage() );
		}
		return r;
	}
	
	
	
	@GET
	@Path("/dowloadPL")
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Produces("application/pdf")
	public Response downloadPL(@Context UriInfo ui) {
		Response r = null;
		MultivaluedMap<String, String> map = ui.getQueryParameters();
		String id = map.getFirst("id");
		Long idUnico= (new Date()).getTime();
		try {
			int idInt = Integer.parseInt(id);
			BeanPL pl =  SAR_CDI_DAO.selectPL(idInt);
			if(pl == null) {
				throw new Exception("Error no existe documento de Packing list disponible para la versión solicitada");
			}else {	
				/**First Download in Share Point ***/
				try
				{
					BeanDocumentosSDI documentosObj = SAR_CDI_DAO.selectDocumentosSDI(idInt);
					FileUploadBO  fileUploadBO= getFileByIdBookingOnlyRead(id,documentosObj.getProveedor(),pl.getRutaArchivo(),TipoDocumentosEnum.PL.getId());
					if(fileUploadBO!=null) {
						File fileFromSharePoint= new File(pathTemporal+ File.separator +fileUploadBO.getFileName());
						if(fileFromSharePoint!=null && fileFromSharePoint.isFile()) {
							ResponseBuilder response = Response.ok(fileFromSharePoint, MediaType.APPLICATION_OCTET_STREAM);
							response.header("Content-Disposition", "attachment; filename="+fileUploadBO.getFileName().replaceAll(fileUploadBO.getIdUnico()+POS_FIJO_ID_UNICO,""));
							response.header("Content-Type",fileUploadBO.getContentType());	
							(new DeleteFile(fileFromSharePoint)).start();
							return response.build();
						}
					}
				}catch(Exception ex) {
					ex.printStackTrace();
				}
				/**Second Download in Local folder */
				File file = new File(pl.getRutaArchivo());
				File fileDest = new File(pathTemporal +File.separator+idUnico+POS_FIJO_ID_UNICO+file.getName());
				BeanDocumentosSDI documentosObj = null;
				try {
					documentosObj = SAR_CDI_DAO.selectDocumentosSDI(new Integer(id));
					if(getFlagFacturacion(documentosObj.getProveedor())) {
						if(expedienteService.copy(file,fileDest)) {
							String conditions="";
							AnexosDTO anexos=null;
							creaDocumentoSharePoint(SAR_CDI_DAO.selectSarsEnBooking(Integer.parseInt(id)),documentosObj.getProveedor(),TipoDocumentosEnum.PL.getId() , 
									fileDest,idUnico,conditions,anexos);
						}
					}
				} catch (NumberFormatException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (ServletException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				ResponseBuilder response = Response.ok(file, MediaType.APPLICATION_OCTET_STREAM);
				response.header("Content-Disposition", "attachment; filename=PackinList_"+pl.getVersionDocumento()+".xls");
				response.header("Content-Type","application/pdf");
				r = response.build();
			}
		} catch (Exception ioE) {
			log.error("Error al intentar generar el archivo", ioE);
			r = buildErrorResponse("Error trying to download Packing list File.");
		}
		return r;
	}
	
	
	@GET
	@Path("/dameDatosBLs")
	@Produces(MediaType.APPLICATION_JSON)
	public Response dameDatosBL(@Context UriInfo ui) {
		Response r = null;
		MultivaluedMap<String, String> map = ui.getQueryParameters();
		String id = map.getFirst("id");
		JSONObject jsonRestul = new JSONObject();
		try {
			int idInt = Integer.parseInt(id);
			
			BeanDocumentosSDI docs = SAR_CDI_DAO.selectDocumentosSDI(idInt);
			
			BeanBL preBL = SAR_CDI_DAO.selectBL(idInt, TIPOPREBL);
			BeanBL bL = SAR_CDI_DAO.selectBL(idInt,TIPOBL);
			if(preBL != null && preBL.getVersionDocumento() == docs.getVersionPreBL() ) {
				jsonRestul.put("esGeneraPreBL", false);
				jsonRestul.put("versionPreBL", preBL.getVersionDocumento());
				jsonRestul.put("nombrePreBL", preBL.getNombre());
			}else {
				jsonRestul.put("esGeneraPreBL", true);
				jsonRestul.put("versionPreBL", "");
				jsonRestul.put("nombrePreBL", "");
			}
			
			if(bL != null && bL.getVersionDocumento() == docs.getVersionBL() ) {
				jsonRestul.put("esGeneraBL", false);
				jsonRestul.put("versionBL", bL.getVersionDocumento());
				jsonRestul.put("nombreBL", bL.getNombre());
			}else {
				jsonRestul.put("esGeneraBL", true);
				jsonRestul.put("versionBL", "");
				jsonRestul.put("nombreBL", "");
			}
			
			jsonRestul.put("errorCode", 0);
			jsonRestul.put("mensaje", "OK");
			log.info("Regreso datos de BL de forma correcta.");
		}catch(Exception e) {
			jsonRestul.put("errorCode", 1);
			jsonRestul.put("mensaje", "Error: "+e.toString());
			r = buildErrorResponse(jsonRestul);					
			log.error("Error al intentar traer los datos del BL y PreBl", e.getMessage());			
			return r;
		}
		r = buildOK_JSONResponse(jsonRestul);
		return r;
	}
	
	@POST
	@Path("/generaPreBL")
	@Produces(MediaType.APPLICATION_JSON)
	public Response generaPreBL(@FormParam("id") Integer id, @Context HttpServletRequest request) {
		Response r = null;
		JSONObject jsonRestul = new JSONObject();
		GregorianCalendar greg1 = new GregorianCalendar();
		int year = FuncionesComunesPLI.gregorianCalendar2int(greg1);
		year = year / 10000;		
		try {
			BeanDocumentosSDI docs = SAR_CDI_DAO.selectDocumentosSDI(id);
			
			GeneraDocumentos genera = new GeneraDocumentos();

			String path = DocumentosHelper.getInstance().dameRutaArchivos(docs.getProveedor(), docs.getBooking());
			Long idUnico =  (new Date()).getTime();
	        String fileName = "PreBL_"+docs.getVersionSDI()+".pdf";	        
			ArrayList<Integer> listaSars = SAR_CDI_DAO.selectSarsEnBooking(id);
			SarBO  boTot = new SarBO();
			boTot.setFolio(listaSars.get(0));
			SAR_CDI_DAO dao = new SAR_CDI_DAO();
			ArrayList<SarBO> lista =  dao.selectSar(boTot,false);
			boTot = lista.get(0);
			boTot = FuncionesComunesPLI.concentraTotalesDeFoliosEnUno(listaSars,boTot,false);
			if(boTot.getDetalleOthers() != null && boTot.getDetalleOthers().size() > 0) {
				for(SarDetalleBO tmp : boTot.getDetalleOthers()) {
					boTot.getDetalleBO().add(tmp);
				}
			}
			FuncionesComunesPLI.sacaTotales(boTot,boTot.getDetalleBO() ,boTot.getDetalleOthers() );
			//////////Aqui mando a generar el archivo y enviarlo a download.truper.com//////////
			genera.generaPreBL(boTot, docs, path, fileName);
			
			//////////Aqui Me falta mandar a actualizar la tabla de documentos y versiones //////////
			BeanBL bl = new BeanBL();
			bl.setId(id);
			bl.setTipo(TIPOPREBL);
			bl.setVersionDocumento(docs.getVersionPreBL());
			bl.setNombre(fileName);
			bl.setRutaArchivo(path+fileName);
			
			if(SAR_CDI_DAO.insertaBL(bl)) {
				BeanDocumentosSDI updateDoc = new BeanDocumentosSDI();
				updateDoc.setId(id);
				updateDoc.setPreBLGenerado(true);				
				SAR_CDI_DAO.updateDocumentosSDI(updateDoc);
				jsonRestul.put("mensaje", "PreBL was generated properly");
				jsonRestul.put("errorCode", 0);
				jsonRestul.put("fileName", fileName);
				r = buildOK_JSONResponse(jsonRestul.toString());
				
				String username = HistoryLogHelper.getInstance().getUserName((UserBean)request.getSession().getAttribute("usuario"));
				/*
				 * Servicio para generar archivo a SharePoint y BD Expediente
				 */
				String conditions="";
				if(getFlagFacturacion(SAR_CDI_DAO.selectDocumentosSDI(id).getProveedor())){
					creaDocumentoSharePoint(SAR_CDI_DAO.selectSarsEnBooking(id),(SAR_CDI_DAO.selectDocumentosSDI(id)).getProveedor(),TipoDocumentosEnum.PREBL.getId(), username,
							expedienteService.copyReturnPath(path,fileName,pathTemporal,idUnico,POS_FIJO_ID_UNICO),fileName,idUnico,conditions);
				}
				
			}else {
				r = buildErrorResponse("Error The Information of the PREBL was not saved properly ");
			}
			UserBean usuario = (UserBean)request.getSession().getAttribute("usuario");
			String username = HistoryLogHelper.getInstance().getUserName(usuario);	
			HistoryLogBean historyLogBean = HistoryLogBean.builder()
					.tipoAccion(HistoryLogAction.GENERATE_PRE_BL.id())
					.Id(id)
					.username(username).build();
			
			log.info("Datos a insertar en el history log: Accion:{}, username: {} ", historyLogBean.getTipoAccion(), historyLogBean.getUsername());
			HistoryLogServiceImpl.getInstance().saveHistoryLog(historyLogBean);
			
		} catch (Exception e) {
			log.error("Error while trying generate the PREBL, please try again: "+e.getMessage() );		
			r = buildErrorResponse("Error while trying generate the PREBL, please try again: "+e.getMessage() );
		}
		return r;
	}
	
	
	@GET
	@Path("/dowloadPreBL")
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Produces("application/pdf")
	public Response downloadPREBL(@Context UriInfo ui) {
		Response r = null;
		
		MultivaluedMap<String, String> map = ui.getQueryParameters();
		String id = map.getFirst("id");
		try {
			int idInt = Integer.parseInt(id);
			BeanBL bl = SAR_CDI_DAO.selectBL(idInt,TIPOPREBL);
			/**First Download in Share Point ***/ 
			try {
				BeanDocumentosSDI documentosObj = SAR_CDI_DAO.selectDocumentosSDI(idInt); 
				FileUploadBO  fileUploadBO= getFlagFacturacion(documentosObj.getProveedor()) ?
						getFileByIdBookingOnlyRead(id,documentosObj.getProveedor(),bl.getRutaArchivo(),TipoDocumentosEnum.PREBL.getId()) : null;
				if(fileUploadBO!=null) {
					File fileFromSharePoint= new File(pathTemporal+ File.separator +fileUploadBO.getFileName());
					if(fileFromSharePoint!=null && fileFromSharePoint.isFile()) {
						ResponseBuilder response = Response.ok(fileFromSharePoint, MediaType.APPLICATION_OCTET_STREAM);
						response.header("Content-Disposition", "attachment; filename="+fileUploadBO.getFileName().replaceAll(fileUploadBO.getIdUnico()+POS_FIJO_ID_UNICO,""));
						response.header("Content-Type",fileUploadBO.getContentType());
						(new DeleteFile(fileFromSharePoint)).start();
						return response.build();
					}
				}
			}catch(Exception ex) {
				ex.printStackTrace();
			}
			/**Second Download in Local folder */
			Long idUnico= (new Date()).getTime();
			BeanDocumentosSDI documentosObj = null;
			File file = new File(bl.getRutaArchivo());
			try {
				documentosObj = SAR_CDI_DAO.selectDocumentosSDI(new Integer(id));
				File fileDest = new File(pathTemporal+File.separator+idUnico+POS_FIJO_ID_UNICO+file.getName());
				if(getFlagFacturacion(documentosObj.getProveedor())) {
					if(expedienteService.copy(file,fileDest)) {
						String conditions="";
						AnexosDTO anexos=null;
						creaDocumentoSharePoint(SAR_CDI_DAO.selectSarsEnBooking(Integer.parseInt(id)),documentosObj.getProveedor(),
								TipoDocumentosEnum.PREBL.getId() , fileDest,idUnico,conditions,anexos);
					}
				}
			} catch (NumberFormatException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (ClassNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (ServletException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			ResponseBuilder response = Response.ok(file, MediaType.APPLICATION_OCTET_STREAM);
			response.header("Content-Disposition", "attachment; filename=PreBL_"+bl.getVersionDocumento()+".xls");
			response.header("Content-Type","application/pdf");
			r = response.build();
			
		} catch (Exception ioE) {
			log.error("Error al intentar generar el archivo", ioE);
			r = buildErrorResponse("Error trying to download PreBL File.");
		}
		return r;
	}
	
	
	
	@POST
	@Path("/cambioVersionPreBL")
	@Consumes("application/x-www-form-urlencoded")
	public Response cambioVersionPreBL(@FormParam("id") Integer id) {
		Response r = null;
		JSONObject jsonRestul = new JSONObject();
		try {
			BeanDocumentosSDI docs = SAR_CDI_DAO.selectDocumentosSDI(id);
			BeanDocumentosSDI docUpdate = new BeanDocumentosSDI();
			docUpdate.setId(id);
			docUpdate.setVersionPreBL(docs.getVersionPreBL()+1);
			docUpdate.setPreBLGenerado(false);
			SAR_CDI_DAO.updateDocumentosSDI(docUpdate);			
			jsonRestul.put("errorCode", 0);
			jsonRestul.put("mensaje", "OK");
			r = buildOKResponse(jsonRestul.toString());
			borraDocs(id,TipoDocumentosEnum.PREBL.getId(),"PreBL_");
		} catch (Exception e) {
			jsonRestul.put("errorCode", 1);
			jsonRestul.put("mensaje", "The Version of the PreBL was not saved properly");
			log.error("Error while trying generate the preBl: ", e.getMessage());
			r = buildErrorResponse("Error while trying generate the preBl: "+e.getMessage() );
		}
		return r;
	}
	
	@POST
	@Path("/uploadFileBL")
	@Consumes(MediaType.MULTIPART_FORM_DATA)
	public Response uploadFileBL(
			@FormDataParam("file") InputStream uploadedInputStream,  
            @FormDataParam("file") FormDataContentDisposition fileDetail,
            @FormDataParam("id") int id,
            @FormDataParam("tipoFile") String tipo,
            @Context HttpServletRequest request) {
		Response r = null;
		JSONObject jsonRestul = new JSONObject();
		GregorianCalendar greg1 = new GregorianCalendar();
		int year = FuncionesComunesPLI.gregorianCalendar2int(greg1);
		year = year / 10000;
		if (uploadedInputStream == null || fileDetail == null) {
			log.info("["+Response.Status.BAD_REQUEST+"] - Invalid form data.");
			return Response.status(Response.Status.BAD_REQUEST).entity("Invalid form data.").build();
		}
		try {
			String name = fileDetail.getFileName();
			String[] arreglo = name.split("\\.");
			
			BeanDocumentosSDI documentosObj = SAR_CDI_DAO.selectDocumentosSDI(id); 
			
			String path = DocumentosHelper.getInstance().dameRutaArchivos(documentosObj.getProveedor(), documentosObj.getBooking());
			Long idUnico =  (new Date()).getTime();
			String fileName =  "BL_"+documentosObj.getVersionSDI()+"."+arreglo[arreglo.length-1];
			File nuevo = new File(path+fileName);
			OutputStream outputStream = new FileOutputStream(nuevo);
			IOUtils.copy(uploadedInputStream, outputStream);
			outputStream.close();
			
			BeanDocumentosSDI nuevoDoc = new BeanDocumentosSDI();
			nuevoDoc.setId(id);
			nuevoDoc.setBlGenerado(true);
			SAR_CDI_DAO.updateDocumentosSDI(nuevoDoc);
			BeanBL blUpdate = new BeanBL();
			blUpdate.setId(id);
			blUpdate.setTipo(TIPOBL);
			blUpdate.setVersionDocumento(documentosObj.getVersionBL() );
			blUpdate.setNombre(fileName);
			blUpdate.setRutaArchivo(path+fileName);
			if(SAR_CDI_DAO.insertaBL(blUpdate)) {
				jsonRestul.put("errorCode", 0);
				jsonRestul.put("mensaje", "OK, the file was successfully uploaded");
			}else {
				jsonRestul.put("errorCode", 1);
				jsonRestul.put("mensaje", "Error");
			}
			UserBean usuario = (UserBean)request.getSession().getAttribute("usuario");
			String username = HistoryLogHelper.getInstance().getUserName(usuario);
			/*
			 * Servicio para generar archivo a SharePoint y BD Expediente 3 BL
			 */
			String conditions="";
			if(getFlagFacturacion(documentosObj.getProveedor())) {
				creaDocumentoSharePoint(SAR_CDI_DAO.selectSarsEnBooking(id),documentosObj.getProveedor(),TipoDocumentosEnum.BL.getId(), username,
						expedienteService.copyReturnPath(path,fileName,pathTemporal,idUnico,POS_FIJO_ID_UNICO),fileName,idUnico,conditions);
			}
			HistoryLogBean historyLogBean = HistoryLogBean.builder()
					.tipoAccion(HistoryLogAction.GENERATE_FINAL_BL.id())
					.Id(id)
					.username(username).build();

			log.info("Datos a insertar en el history log: Accion:{}, username: {} ", historyLogBean.getTipoAccion(), historyLogBean.getUsername());
			HistoryLogServiceImpl.getInstance().saveHistoryLog(historyLogBean);
	
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			jsonRestul.put("errorCode", 1);
			jsonRestul.put("mensaje", "Error");
		}
		return r;
	}
	
	
		
	@POST
	@Path("/uploadFileOthers")
	@Consumes(MediaType.MULTIPART_FORM_DATA)
	public Response uploadFileOthers(@FormDataParam("file") InputStream uploadedInputStream,
			@FormDataParam("file") FormDataContentDisposition fileDetail, @FormDataParam("id") int id,
			@FormDataParam("tipoFile") String tipo,
			@Context HttpServletRequest request) {
		Response r = null;
		JSONObject jsonRestul = new JSONObject();
		GregorianCalendar greg1 = new GregorianCalendar();
		int year = FuncionesComunesPLI.gregorianCalendar2int(greg1);
		year = year / 10000;
		if (uploadedInputStream == null || fileDetail == null) {
			log.info("[" + Response.Status.BAD_REQUEST + "] - Invalid form data.");
			return Response.status(Response.Status.BAD_REQUEST).entity("Invalid form data.").build();
		}
		try {
			String name = fileDetail.getFileName();
			String[] arreglo = name.split("\\.");

			BeanDocumentosSDI documentosObj = SAR_CDI_DAO.selectDocumentosSDI(id);

			String path = DocumentosHelper.getInstance().dameRutaArchivos(documentosObj.getProveedor(), documentosObj.getBooking());
			Long idUnico =  (new Date()).getTime();
			String fileName =  arreglo[0]+"_"+documentosObj.getVersionSDI()+"." + arreglo[arreglo.length - 1];
			File nuevo = new File(path + fileName);
			OutputStream outputStream = new FileOutputStream(nuevo);
			IOUtils.copy(uploadedInputStream, outputStream);
			outputStream.close();

			BeanDocumentosSDI nuevoDoc = new BeanDocumentosSDI();
			nuevoDoc.setId(id);
			nuevoDoc.setTieneOtrosDocumentos(true);
			SAR_CDI_DAO.updateDocumentosSDI(nuevoDoc);

			BeanOtrosDocumentos otros = new BeanOtrosDocumentos();
			otros.setId(id);
			otros.setNombre(fileName);
			otros.setRutaArchivo(path+fileName);
			String username = HistoryLogHelper.getInstance().getUserName((UserBean)request.getSession().getAttribute("usuario"));
			
			if (SAR_CDI_DAO.insertaOtroDocumento(otros)) {
				jsonRestul.put("errorCode", 0);
				jsonRestul.put("mensaje", "OK, the file was successfully uploaded");
				/*
				 * Servicio para generar archivo a SharePoint y BD Expediente 6 Otros Proveedor
				 */
				String conditions="";
				if(getFlagFacturacion(documentosObj.getProveedor())) {
					creaDocumentoSharePoint(SAR_CDI_DAO.selectSarsEnBooking(id),documentosObj.getProveedor(),TipoDocumentosEnum.OTROS_PROVEEDOR.getId(), username,
						expedienteService.copyReturnPath(path,fileName,pathTemporal,idUnico,POS_FIJO_ID_UNICO),fileName,idUnico,conditions);
				}
			} else {
				jsonRestul.put("errorCode", 1); 
				jsonRestul.put("mensaje", "Error, please check the name of file the maximum long on the name is 50 characters and you can't duplicate name files. ");
			}
			
			r = buildOKResponse(jsonRestul.toString());
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			jsonRestul.put("errorCode", 1);
			jsonRestul.put("mensaje", "Error:  "+e.getMessage() );
			r = buildErrorResponse(e.getMessage() );
		}
		return r;
	}
	
	@POST
	@Path("/cambioVersionBL")
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	public Response cambioVersionBL(@FormParam("id") Integer id) {		
		Response r = null;
		JSONObject jsonRestul = new JSONObject();
		try {
			
			BeanDocumentosSDI documentosObj = SAR_CDI_DAO.selectDocumentosSDI(id);
			BeanDocumentosSDI nuevoDoc = new BeanDocumentosSDI();
			nuevoDoc.setId(id);
			nuevoDoc.setVersionBL(documentosObj.getVersionBL()+1);
			nuevoDoc.setBlGenerado(false);
			
			SAR_CDI_DAO.updateDocumentosSDI(nuevoDoc);
			jsonRestul.put("errorCode", 0);
			jsonRestul.put("mensaje", "OK");
			
			r = buildOKResponse(jsonRestul.toString());
			borraDocs(id,TipoDocumentosEnum.BL.getId(),"_BL");
		} catch (Exception e) {
			log.error("Error while trying generate the Bl: ", e);
			r = buildErrorResponse("Error while trying generate the Bl: "+e.getMessage() );
			jsonRestul.put("errorCode", 1);
			jsonRestul.put("mensaje", "The Version of BL was not saved properly");
		}
		return r;
	}
	
	
	

	@GET
	@Path("/dowloadBL")
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Produces("application/pdf")
	public Response dowloadBL(@Context UriInfo ui) {
		Response r = buildErrorResponse("Error there is no BL file.");
		MultivaluedMap<String, String> map = ui.getQueryParameters();
		String id = map.getFirst("id");
		try {
			int idInt = Integer.parseInt(id);
			BeanBL bl =	SAR_CDI_DAO.selectBL(idInt, TIPOBL);
			/**First Download in Share Point ***/
			try			{
				BeanDocumentosSDI documentosObj = SAR_CDI_DAO.selectDocumentosSDI(idInt);
				FileUploadBO  fileUploadBO= getFileByIdBookingOnlyRead(id,documentosObj.getProveedor(),bl.getRutaArchivo(),TipoDocumentosEnum.BL.getId());
				if(fileUploadBO!=null) {
					File fileFromSharePoint= new File(pathTemporal+  File.separator +fileUploadBO.getFileName());
					if(fileFromSharePoint!=null && fileFromSharePoint.isFile()) {
						ResponseBuilder response = Response.ok(fileFromSharePoint, MediaType.APPLICATION_OCTET_STREAM);
						response.header("Content-Disposition", "attachment; filename="+fileUploadBO.getFileName().replaceAll(fileUploadBO.getIdUnico()+POS_FIJO_ID_UNICO,""));
						response.header("Content-Type",fileUploadBO.getContentType());	
						(new DeleteFile(fileFromSharePoint)).start();
						return response.build();
					}
				}
			}catch(Exception ex)
			{
				ex.printStackTrace();
			}
			/**Second Download in Local folder */
			if(bl != null) {
				File file = new File(bl.getRutaArchivo());
				Long idUnico= (new Date()).getTime();
				BeanDocumentosSDI documentosObj = null;
				try {
					documentosObj = SAR_CDI_DAO.selectDocumentosSDI(new Integer(id));
					File fileDest = new File( pathTemporal +File.separator+idUnico+POS_FIJO_ID_UNICO+file.getName());
					if(expedienteService.copy(file,fileDest)) {
						String conditions="";
						AnexosDTO anexos=null;
						creaDocumentoSharePoint(SAR_CDI_DAO.selectSarsEnBooking(Integer.parseInt(id)),documentosObj.getProveedor(),
								TipoDocumentosEnum.BL.getId() , fileDest,idUnico,conditions,anexos);
					}
				} catch (NumberFormatException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (ServletException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				ResponseBuilder response = Response.ok(file, MediaType.APPLICATION_OCTET_STREAM);
				response.header("Content-Disposition", "attachment; filename=BL_"+bl.getVersionDocumento()+".xls");
				response.header("Content-Type","application/pdf");
				return response.build();
			}
		} catch (Exception ioE) {
			log.error("Error al intentar generar el archivo", ioE);
			r = buildErrorResponse("Error trying to download BL File.");
		}
		return r;
	}
	
	@GET
	@Path("/archivosCargados")
	@Produces(MediaType.APPLICATION_JSON)
	public Response dameArchivosCargados(@Context UriInfo ui) {
		Response r = null;
		MultivaluedMap<String, String> map = ui.getQueryParameters();
		
		String id = map.getFirst("id");				
		JSONObject jsonRestul = new JSONObject();
		try {			
			int idInt = Integer.parseInt(id);
			BeanOtrosDocumentos otros = new BeanOtrosDocumentos();
			otros.setId(idInt);
			ArrayList<BeanOtrosDocumentos> listaDocs = modificaNombre(SAR_CDI_DAO.selectOtrosDocumentos(otros));
			jsonRestul.put("files", gson.toJson(listaDocs));
			jsonRestul.put("errorCode", 0);
			jsonRestul.put("mensaje", "OK");
						
		}catch(Exception e) {
			log.error("Error al intentar generar el listado de archivos", e);
			jsonRestul.put("errorCode", 1);
			jsonRestul.put("mensaje", "Error: "+e.toString());
			r = buildErrorResponse(jsonRestul);
			return r;
		}
		r = buildOKResponse(jsonRestul.toString());		
		return r;
	}
	
	
	@GET
	@Path("/dowloadOtroDoc")
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Produces(MediaType.APPLICATION_OCTET_STREAM)
	public Response dowloadOtroDoc(@Context UriInfo ui) {
		Response r = null;
		Long idUnico= (new Date()).getTime();
		MultivaluedMap<String, String> map = ui.getQueryParameters();
		String id = map.getFirst("id");
		String nombre = map.getFirst("nombre");
		try {
			int idInt = Integer.parseInt(id);
			BeanOtrosDocumentos otroBean = new BeanOtrosDocumentos();
			otroBean.setId(idInt);
			otroBean.setNombre(nombre);
			ArrayList<BeanOtrosDocumentos> lista = SAR_CDI_DAO.selectOtrosDocumentos(otroBean);
			otroBean = lista.get(0);

			if(otroBean!=null) {
				/**First Download in Share Point ***/
				try {
					BeanDocumentosSDI documentosObj = SAR_CDI_DAO.selectDocumentosSDI(idInt);
					FileUploadBO  fileUploadBO= getFileByIdBookingOnlyRead(id,documentosObj.getProveedor(),otroBean.getRutaArchivo(),TipoDocumentosEnum.OTROS_PROVEEDOR.getId());
					if(fileUploadBO!=null) {
						File fileFromSharePoint= new File(pathTemporal+  File.separator +fileUploadBO.getFileName());
						if(fileFromSharePoint!=null && fileFromSharePoint.isFile()) {
							ResponseBuilder response = Response.ok(fileFromSharePoint, MediaType.APPLICATION_OCTET_STREAM);
							response.header("Content-Disposition", "attachment; filename="+fileUploadBO.getFileName().replaceAll(fileUploadBO.getIdUnico()+POS_FIJO_ID_UNICO,""));
							response.header("Content-Type",fileUploadBO.getContentType());	
							(new DeleteFile(fileFromSharePoint)).start();
							return response.build();
						}
					}
				}catch(Exception ex) {
					ex.printStackTrace();
				}
				/**Second Download in Local folder */
				File file = new File(otroBean.getRutaArchivo());
				BeanDocumentosSDI documentosObj = null;
				try {
					BeanOtrosDocumentos otroProveedorBean =getId(nombre,idInt);
					documentosObj = SAR_CDI_DAO.selectDocumentosSDI(new Integer(id));
					File fileDest = new File(pathTemporal+File.separator+idUnico+POS_FIJO_ID_UNICO+file.getName());
					if(expedienteService.copy(file,fileDest)) {
						String conditions="";
						AnexosDTO anexos=null;
						creaDocumentoSharePoint(SAR_CDI_DAO.selectSarsEnBooking(Integer.parseInt(id)),documentosObj.getProveedor(),TipoDocumentosEnum.OTROS_PROVEEDOR.getId() ,
								fileDest,idUnico,conditions,anexos);
					}
				} catch (NumberFormatException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (ServletException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				r = Response.ok(file, MediaType.APPLICATION_OCTET_STREAM)
						.header("Content-Disposition", "attachment; filename=\"" + file.getName() + "\"").build();
			}else {
				r = buildErrorResponse("Error there is no BL file.");
			}
			
		} catch (Exception ioE) {
			log.error("Error al intentar generar el archivo", ioE);
			r = buildErrorResponse("Error trying to download BL File.");
		}
		return r;
	}
	
	
	



	@POST
	@Path("/eliminaArchivo")
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	public Response eliminaArchivo(@FormParam("id") Integer id, @FormParam("nombre") String nombre) {
		Response r = null;
		JSONObject jsonRestul = new JSONObject();
		try {
			BeanOtrosDocumentos otros = new BeanOtrosDocumentos();
			otros.setEliminado(true);
			otros.setId(id);
			otros.setNombre(nombre);
			boolean exito = DocumentosServices.getInstance().eliminaOtroDocumento(otros);
			if (exito) {
				jsonRestul.put("errorCode", 0);
				jsonRestul.put("mensaje", "OK");
			} else {
				jsonRestul.put("errorCode", 1);
				jsonRestul.put("mensaje", "Error while trying delete the file");
			}
			r = buildOKResponse(jsonRestul.toString());
			borraDocs(id,TipoDocumentosEnum.OTROS_PROVEEDOR.getId(),nombre);
		} catch (Exception e) {
			log.error("Error while trying delete the file: ", e);
			r = buildErrorResponse("Error while trying delete the file: " + e.getMessage());
		}
		return r;
	}
	
	
	@POST
	@Path("/cierraDocumentos")
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	public Response cierraDocumentos(@FormParam("id") Integer id, @FormParam("comentario") String comentario, 
			@Context HttpServletRequest request) {		
		Response r = null;
		JSONObject jsonRestul = new JSONObject();
		try {
			
			BeanDocumentosSDI doc = new BeanDocumentosSDI();
			doc.setFechaAceptaProveedor(new Date());
			doc.setId(id);
			SAR_CDI_DAO.updateDocumentosSDI(doc);
			
			doc = SAR_CDI_DAO.selectDocumentosSDI(id);
			BeanControlSDI control = new BeanControlSDI();
			control.setBooking(doc.getBooking());
			control.setVersionSDI(doc.getVersionSDI());
			control.setProveedor(doc.getProveedor());
			control= SAR_CDI_DAO.selectControlSDI(control);
			if(control == null) {///No existe es un insert
				control = new BeanControlSDI();
				control.setBooking(doc.getBooking());
				control.setVersionSDI(doc.getVersionSDI());
				control.setProveedor(doc.getProveedor());
				control.setIdDocumentos(doc.getId());
				control.setComentariosProveedor(comentario);
				
				ArrayList<Integer> sars = SAR_CDI_DAO.selectSarsEnBooking(id);
				SarBO bo = new SarBO();
				bo.setFolio(sars.get(0));
				SAR_CDI_DAO dao = new SAR_CDI_DAO();
				ArrayList<SarBO> lista = dao.selectSar(bo,false);
				control.setAnalistaSDI(SAR_CDI_DAO.analistasSDIPorNaviera(lista.get(0).getNaviera()));
				SAR_CDI_DAO.insertaControlSDI(control);
				guardar(id,doc.getBooking(),doc.getProveedor(),comentario,"closeDoc");	
			}else {//Si ya existe, entonces es un update				
				control.setIdDocumentos(doc.getId());
				control.setFechaAceptaProveedor(new Date());
				control.setComentariosProveedor(comentario);
				control.setVersionSDI(doc.getVersionSDI());
				SAR_CDI_DAO.updateControlSDI(control);
				guardar(id,doc.getBooking(),doc.getProveedor(),comentario,"closeDoc");
			}
			registraLogDocumentos(control, DocumentosAccionEnum.DOCUMENTOS_RECIBIDOS);
			
			///Si se hace bien, entonces voy por sus sars
			ArrayList<Integer> listaSars = SAR_CDI_DAO.selectSarsEnBooking(id);
			SAR_CDI_DAO.updateSARsStatus(SarBO.STATUS_INICIO_SDI, listaSars);			
			///Si todo salio OK genero el registro en el History log
			UserBean usuario = (UserBean)request.getSession().getAttribute("usuario");
			String username = HistoryLogHelper.getInstance().getUserName(usuario);	
			HistoryLogBean historyLogBean = HistoryLogBean.builder()
					.tipoAccion(HistoryLogAction.SUPPLIER_SEND_DOCUMENTS_TO_SDI.id())
					.Id(id)
					.username(username).build();

			log.info("Datos a insertar en el history log: Accion:{}, username: {} ", historyLogBean.getTipoAccion(), historyLogBean.getUsername());
			HistoryLogServiceImpl.getInstance().saveHistoryLog(historyLogBean);
			
			jsonRestul.put("errorCode", 0);
			jsonRestul.put("mensaje", "OK");
			
			r = buildOKResponse(jsonRestul.toString());
			
		} catch (Exception e) {
			log.error("Error while trying to close documents: ", e);
			r = buildErrorResponse("Error while trying to close documents: "+e.getMessage() );
			jsonRestul.put("errorCode", 1);
			jsonRestul.put("mensaje", "Error while trying to close documents");
		}
		return r;
	}



	private void guardar(Integer id, String booking, String proveedor, String comentario,String userName) {
		List<SarBO> reporteSars =new ArrayList<SarBO>(); 
		if(getFlagFacturacion(proveedor)) {
			try {
				ArrayList<Integer> sars = SAR_CDI_DAO.selectSarsEnBooking(id);
				if(!sars.isEmpty()) {
					reporteSars= SAR_CDI_DAO.findSarByProveedorAndFolio(proveedor,sars.get(0).toString());
					if(!reporteSars.isEmpty() && reporteSars.size()==1 ) {
						for(SarBO bo:reporteSars) {
							AnexosDTO anexos= new AnexosDTO (0,bo.getSealNumber()+bo.getContenedorProveedor(),comentario,"",userName,proveedor,booking);
							Boolean v= expedienteService.enviaAnexos(anexos);
							log.info("Se guardo comentarios :: {}, --> {} , [ {} , {} , {}  :: {} ]",bo.getSealNumber()+bo.getContenedorProveedor(),comentario,"",userName,proveedor,booking,v);
						}
					}
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}



	private void registraLogDocumentos(BeanControlSDI control, DocumentosAccionEnum accion) {
		String _booking = control.getBooking();
		String _proveedor = control.getProveedor();
		ShpmntsWdocsService.getInstance().registraLogDocumentos(_booking, _proveedor, accion);
	}
	
	
	
	/**
	 * Verifica si existe un registro para la version del SAR, de no existir crea el registro 
	 * y me regresa el bean de la ultima version de documentos
	 * 
	 * Necesito por fuerza folio, proveedor, booking y version.
	 * 
	 * @param bo
	 * @return
	 * @throws ServletException 
	 * @throws ClassNotFoundException 
	 * @throws SQLException 
	 */
	private static BeanDocumentosSDI dameRegistroDocumentos(SarBO bo) throws ClassNotFoundException, ServletException, SQLException {
		
		if(bo.getBooking() == null ||  bo.getProveedor() == null) {
			throw new ServletException("Error, falta de parametros necesarios.");
		}
		bo.setVersionSDI( (bo.getVersionSDI() == null ||  bo.getVersionSDI() == 0 )? 1 : bo.getVersionSDI());
		ArrayList<BeanDocumentosSDI> documentos = SAR_CDI_DAO.selectDocumentosSDI(null, bo.getBooking(),bo.getProveedor());
		
		///Si no elementos es de 0 el insert, es decir no tiene version anterior para comparar
		///En este caso la version es 1 para todos los documentos 
		if(documentos.size() == 0) {
			
			BeanDocumentosSDI doc = new BeanDocumentosSDI();
			doc.setBlGenerado(false);
			doc.setBooking(bo.getBooking());			
			doc.setFacturasCompletas(false);
			doc.setPackingListGenerado(false);
			doc.setPreBLGenerado(false);
			doc.setProveedor(bo.getProveedor());
			doc.setTieneOtrosDocumentos(false);
			doc.setVersionSDI(VERSION_INI);///Por que es la primera version, en este punto no hay version alguna
			doc.setVersionBL(VERSION_INI);
			doc.setVersionFacturas(VERSION_INI);
			doc.setVersionPK(VERSION_INI);
			doc.setVersionPreBL(VERSION_INI);
			
			int idAuto = SAR_CDI_DAO.insertaDocumentosSDI(doc);			
			doc.setId(idAuto);
			///si es insercion se debe insertar tambien 
			SAR_CDI_DAO.insertaSarsEnBooking(bo,idAuto);
			
			SarBO sar = new SarBO();
			sar.setVersionSDI(VERSION_INI);
			bo.setVersionSDI(VERSION_INI);
			sar.setFolio(bo.getFolio());
			ArrayList<Integer> listaSARs = SAR_CDI_DAO.selectSarsEnBooking(idAuto);
			
			SAR_CDI_DAO.updateSARsVersionSDI(VERSION_INI,listaSARs);
			return doc;
		}else {
			///Si ya hay una version, debo comparar para validar algunos datos y generar un nuevo registro
			if(documentos.get(0).getVersionSDI().equals(bo.getVersionSDI()) ) {
				///Si tiene el mismo numero de version, regreso el objeto que busque ya que es el ultimo
				Integer _folio = bo.getFolio();
				if (_folio != null) {
					BeanDocumentosSDI beanDocumentosSDI = ProveedoresServicesImpl.getInstance()
							.getIdDocumentosSDIBySar(_folio);
					if (beanDocumentosSDI != null && beanDocumentosSDI.getId() != null) {
						SAR_CDI_DAO.getInstance().mergeCdiSARsEnBooking(beanDocumentosSDI.getId(), _folio);
					}
				}
				return documentos.get(0);
			}else {
				//Si no tiene la misma version inserto otra version tomando las referencias de la ultima version en tablas
				//En este caso la version dentro de CDISAR debe ser mayor por 1 de la de documentos.
				BeanDocumentosSDI docTmp = documentos.get(0);
				BeanDocumentosSDI doc = new BeanDocumentosSDI();
				doc.setBlGenerado(false);
				doc.setBooking(bo.getBooking());			
				doc.setFacturasCompletas(false);
				doc.setPackingListGenerado(false);
				doc.setPreBLGenerado(false);
				doc.setProveedor(bo.getProveedor());
				doc.setTieneOtrosDocumentos(false);
				doc.setVersionSDI(docTmp.getVersionSDI()+1);///Por que es la primera version, en este punto no hay version alguna
				doc.setVersionBL(docTmp.getVersionBL()+1);
				doc.setVersionFacturas(docTmp.getVersionFacturas()+1);
				doc.setVersionPK(docTmp.getVersionPK()+1);
				doc.setVersionPreBL(docTmp.getVersionPreBL()+1);
				
				int idAuto = SAR_CDI_DAO.insertaDocumentosSDI(doc);
				doc.setId(idAuto);
				///si es insercion se debe insertar tambien 
				SAR_CDI_DAO.insertaSarsEnBooking(bo,idAuto);
				
				return doc;
			}
		}		
	}
	
	@GET
	@Path("/dowloadFile")
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Produces(MediaType.APPLICATION_OCTET_STREAM)
	public Response dowloadFile(@Context UriInfo ui) {
		Response r = null;
		MultivaluedMap<String, String> map = ui.getQueryParameters();
		String id = map.getFirst("id");
		String nombre = map.getFirst("nombre");
		String tipo = map.getFirst("tipo");
		try {
			String rutaArchivo = null;
			BeanDocumentosSDI doc = SAR_CDI_DAO.selectDocumentosSDI(Integer.parseInt(id));
			
			if(TIPOINVOICE.equals(tipo)) {
				BeanFactura fac = SAR_CDI_DAO.selectFacturaXId(doc.getId(), nombre);
				rutaArchivo = fac.getRutaArchivo();
			}else if(TIPOPKL.equals(tipo)) {
				BeanPL pl = SAR_CDI_DAO.selectPL(doc.getId());
				rutaArchivo = pl.getRutaArchivo();
			}else if(TIPOPREBL.equals(tipo)) {
				BeanBL bl = SAR_CDI_DAO.selectBL(doc.getId(), TIPOPREBL);
				rutaArchivo = bl.getRutaArchivo();
			}else if(TIPOBL.equals(tipo)) {
				BeanBL bl = SAR_CDI_DAO.selectBL(doc.getId(), TIPOBL);
				rutaArchivo = bl.getRutaArchivo();
			}else if(TIPOOTHERS.equals(tipo)) {
				BeanOtrosDocumentos otro = new BeanOtrosDocumentos();
				otro.setId(doc.getId());
				otro.setNombre(nombre);
				ArrayList<BeanOtrosDocumentos> otros = SAR_CDI_DAO.selectOtrosDocumentos(otro);
				rutaArchivo = otros.get(0).getRutaArchivo();
			}
			
			
			
			if(rutaArchivo != null) {
				File file = new File(rutaArchivo);
				//ResponseBuilder response = Response.ok(file, MediaType.APPLICATION_OCTET_STREAM);
				r = Response.ok(file, MediaType.APPLICATION_OCTET_STREAM)
					      .header("Content-Disposition", "attachment; filename=\"" + file.getName() + "\"" )
					      .build();
			}else {
				r = buildErrorResponse("Error there is no BL file.");
			}
		} catch (Exception ioE) {
			log.error("Error al intentar generar el archivo", ioE);
			r = buildErrorResponse("Error trying to download a File.");
		}
		return r;
	}
	
	@POST
	@Path("/documentosSet")
	@Consumes(MediaType.TEXT_PLAIN)
	@Produces(MediaType.APPLICATION_JSON)
	public Response getDocumentosSet(String json) {
		BuscaDocumentoPojo buscar = gson.fromJson(json, BuscaDocumentoPojo.class);
		ArrayList<BeanDocumentoSet> respuesta;
		respuesta = DocumentosServices.getInstance().getSetDeDocumentos(buscar);
		return buildOK_JSONResponse(respuesta);
	}
	
	
	/**
	 * Va por la lista de ultimos archivos y las banderas para saber si tiene o no algun tipo de archivo
	 * 
	 * @param ui
	 * @return
	 */
	@GET
	@Path("/documentosStatus")
	@Produces(MediaType.APPLICATION_JSON)
	public Response documentosStatus(@Context UriInfo ui) {
		StatusDocumentosBean status = null;
		try {
			MultivaluedMap<String, String> map = ui.getQueryParameters();
			
			String idControl = map.getFirst("idControl");
			String booking = map.getFirst("booking");
			String proveedor = map.getFirst("proveedor");
			
			BuscaDocumentoPojo buscar = new BuscaDocumentoPojo();
			buscar.setBooking(booking);
			buscar.setProveedor(proveedor);
			ArrayList<BeanDocumentoSet> respuesta;
			respuesta = DocumentosServices.getInstance().getSetDeDocumentos(buscar);
			status = new StatusDocumentosBean();
			status.setListaDocs(respuesta);
			
			List<BeanDocumentosSDI> documentos = SAR_CDI_DAO.selectDocumentosSDI(Integer.parseInt(idControl), booking, proveedor);
			if(documentos == null || documentos.isEmpty()) {
				BeanCommonResponse response = new BeanCommonResponse();
				response.setErrorCode(-1);
				response.setMensaje("Error no hay datos para mostrar");
				return buildOK_JSONResponse(response);
			}
			BeanDocumentosSDI doc = documentos.get(0);
			if(doc.getPackingListGenerado()) {
				status.setPKL(true);
			}
			if(doc.getFacturasCompletas()) {
				status.setFacturasCompletas(true);
			}
			if(doc.getPreBLGenerado()) {
				status.setPreBl(true);
			}
			if(doc.getBlGenerado()) {
				status.setBl(true);
			}
			if(doc.getTieneOtrosDocumentos()) {
				status.setOtrosDocumentos(true);
			}
			
		} catch (NumberFormatException | ClassNotFoundException e) {
			log.error("[documentosStatus] Error",e);
			buildError_JSONResponse(e);
		}
		
		
		return buildOK_JSONResponse(status);
	}
	
	
	@POST
	@Path("/downloadFile")
	@Consumes(MediaType.TEXT_PLAIN)
	@Produces(MediaType.APPLICATION_OCTET_STREAM)
	public Response downloadFile(String dir) {
		Response r = null;
		try {
			File file = new File(URLDecoder.decode(dir, "UTF-8"));
			r = Response.ok(file, MediaType.APPLICATION_OCTET_STREAM)
					.header("Content-Disposition", "attachment; filename=\"" + file.getName() + "\"").build();
		} catch (Exception ioE) {
			log.error("Error al intentar generar el archivo", ioE);
			r = buildErrorResponse("Error trying to download File.");
		}
		return r;
	}
	
	/**
	 * 
	 * 
	 * @param booking
	 * @param proveedor
	 * @return
	 */
	@POST
	@Path("/validaCambioEnPrecios")
	@Produces(MediaType.APPLICATION_JSON)
	public Response validaCambioEnPrecios(@FormParam("booking") String booking,@FormParam("proveedor") String proveedor) {
		Response r = null;
		
		try {
			List<UpdateDataDetail> result = SarDetailServices.getInstance().updateNewPricesByInvoice(booking, proveedor);
			if(result == null) {
				throw new Exception("Error, there are no rows to update.");
			}
			if(result.size() == 0) {
				r = buildOKResponse(gson.toJson("There no changes to update."));
			}else {
				r = buildOKResponse(gson.toJson("The are:"+result.size() + ", rows updated."));
				SarDetailServices.getInstance().sendEmailPricesUpdated(result,proveedor);
				log.info("[validaCambioEnPrecios] OK resitros actualizados: "+ result.size());
			}
		} catch (Exception e) {
			log.error("Error while trying generate the PREBL, please try again: "+e.getMessage() );		
			r = buildErrorResponse("Error while trying generate the PREBL, please try again: "+e.getMessage() );
		}
		return r;
	}
	
	public static double redondeaAUnDecimal(Double d) {
		if(d == null) {
			return 0;
		}
		BigDecimal bd = new BigDecimal(d);
		return bd.setScale(1, BigDecimal.ROUND_HALF_EVEN).doubleValue();
	} 
	

	public FileUploadBO getInformatioFromFile(String pathFile,String fileName,Long idUnico) {
		File f= new File(pathFile+File.separator+idUnico+POS_FIJO_ID_UNICO+fileName);
	    String contentType;
		try {
			if(f.isFile()) {
				contentType = Files.probeContentType(f.toPath());
				Long sizeFile = Files.size(f.toPath());
			    String extent= FilenameUtils.getExtension(fileName);
			    return  FileUploadBO.builder().idUnico(idUnico).fileName(f.getName()).sizeFileInBytes(sizeFile).contentType(contentType).extent(extent) .build();
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    return null;
	}
	public FileUploadBO getInformatioFromFile(String fileName) {
		File f= new File(fileName);
	    String contentType;
		try {
			if(f.isFile()) {
				contentType = Files.probeContentType(f.toPath());
				Long sizeFile = Files.size(f.toPath());
			    String extent= FilenameUtils.getExtension(fileName);
			    log.debug("Se obtuvo documento con  exito  {}  "+fileName);
			    return  FileUploadBO.builder().idUnico(0l).fileName(f.getName()).sizeFileInBytes(sizeFile).contentType(contentType).extent(extent) .build();
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    return null;
	}
	public FileUploadBO getInformatioFromFile(File file,Long idUnico) {
	    String contentType;
		try {
			if(file.isFile()) {
				contentType = Files.probeContentType(file.toPath());
				Long sizeFile = Files.size(file.toPath());
			    String extent= FilenameUtils.getExtension(file.getName());
			    return  FileUploadBO.builder().idUnico(idUnico).fileName(file.getName()).sizeFileInBytes(sizeFile).contentType(contentType).extent(extent) .build();
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    return null;
	}
	public String getFileFromSharePoint(String container,Integer tipo,DocumentoDTO documento,String pathTemporal,String soloNombreArchivo){
		try {
			if(documento!=null) {
				String fileBase64= expedienteService.getDocumentoByIdUnico(container,tipo,"file",soloNombreArchivo);
				if(fileBase64!=null) {
			        try (FileOutputStream fos = new FileOutputStream(pathTemporal+File.separator+documento.getNombreDocumento())) {
			        	   fos.write(java.util.Base64.getDecoder().decode(fileBase64));
			        	   fos.close(); 
			        	   return pathTemporal+File.separator+documento.getNombreDocumento();
			        } catch (Exception e) {
			            e.printStackTrace();
			        }
				}
			}			
		} catch (Exception ioE) {
			log.error("Error al intentar generar el archivo", ioE);
		}
		return null;
	}
	private boolean getFlagFacturacion(String proveedor) {
		Boolean flagFacturacion = PropertiesDb.getInstance().getBoolean("srm.facturacion.activa");
		String ProvListStr = PropertiesDb.getInstance().getString("srm.facturacion.usuarios");
		
		ArrayList<String> provPermitidos = new ArrayList<String>(Arrays.asList(ProvListStr.split(";")));
		log.info("Flags en Proveedores | Expediente flagFacturacion: {} ",flagFacturacion);
		log.info("Flags en Proveedores | Expediente Proveedores {} -> {} ",provPermitidos,proveedor);
		log.info("Flags en Proveedores | Expediente conaints() {} ",provPermitidos.contains(proveedor));
		return  ( flagFacturacion || provPermitidos.contains(proveedor) );
	}
	private void creaDocumentoSharePoint(ArrayList<Integer> listaSars, String proveedor, Integer tipo, String username,
			String path,String fileName, Long idUnico,String conditions) {
		
		if(getFlagFacturacion(proveedor)) {
			String invoice=""; 
			List<SarBO> reporteSars =new ArrayList<SarBO>();
			AnexosDTO anexos = null;
			try {
				reporteSars= SAR_CDI_DAO.findSarByProveedorAndFolio(proveedor,listaSars.get(0).toString());
				if(!reporteSars.isEmpty() && reporteSars.size()==1 ) {
					log.info("Si existem datos de reportesSars {} ",reporteSars.size());
					for(SarBO bo:reporteSars) {
						FileUploadBO fileUploadBO= getInformatioFromFile(path,fileName, idUnico);
						if(fileUploadBO!=null) {
							Long    idDocumentoVacio=0l;
							Integer idProfileVacio=0;
							boolean esNuevo  = true;
							try {
								ArrayList<Integer>  listaId =SAR_CDI_DAO.selectIdBySars(listaSars.get(0));
								if(!listaId.isEmpty()) {
									BeanDocumentosSDI bds = SAR_CDI_DAO.selectDocumentosSDI(listaId.get(0));
									if(bds!=null) {
										BeanControlSDI sdi= new BeanControlSDI();
										sdi.setProveedor(proveedor);
										sdi.setBooking(bds.getBooking());
										sdi=SAR_CDI_DAO.selectControlSDI(sdi);
										if(sdi!=null && bds!=null) {
											if(sdi.getComentariosProveedor()!=null) {
												anexos= new AnexosDTO (0,bo.getSealNumber()+bo.getContenedorProveedor(),sdi.getComentariosProveedor(),"",username,proveedor,bds.getBooking());
											}
										}
									}
								}
							}catch(Exception e) {
								log.debug("Error en crear los Anexos ++");
							}
							if(fileUploadBO!=null) {
								log.info("Se genera documento para enviar a expediente :  {}",fileUploadBO.getFileName() );
								// Aqui viene la invocacion a crear el documento a expediente
							}
						}
					}
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	} 
	
	private BeanOtrosDocumentos getId(String nombre,Integer idInt) {
		BeanOtrosDocumentos otros = new BeanOtrosDocumentos();
		otros.setId(idInt);
		try {
			ArrayList<BeanOtrosDocumentos> listaDocs = SAR_CDI_DAO.selectOtrosDocumentos(otros);
			for(BeanOtrosDocumentos bean:listaDocs) {
				if(bean.getNombre().equals(nombre)) {
					return bean;
				}
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	private void creaDocumentoSharePoint(ArrayList<Integer> listaSars, String proveedor, Integer tipo, File file, Long idUnico,String conditions,AnexosDTO anexos) {
		if( getFlagFacturacion(proveedor) ) {
		
			String invoice=null;
			List<SarBO> reporteSars =new ArrayList<SarBO>(); 
			try {
				reporteSars= SAR_CDI_DAO.findSarByProveedorAndFolio(proveedor,listaSars.get(0).toString());
				if(!reporteSars.isEmpty() && reporteSars.size()==1 ) {
					for(SarBO bo:reporteSars) {
						FileUploadBO fileUploadBO= getInformatioFromFile(file,idUnico);
						if(fileUploadBO!=null) {
							log.info("Se genera documento para enviar a expediente :  {}",fileUploadBO.getFileName() );
							Long    idDocumentoVacio=0l;
							Integer idProfileVacio=0;
							boolean esNuevo  = true;
							// Aqui viene la invocacion a crear el documento a expediente 
						}
					}
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	private FileUploadBO getFileByIdBookingOnlyRead(String id,String proveedor,String fileName,Integer tipo) {
		try {
			List<SarBO> reporteSars =new ArrayList<SarBO>(); 
			ArrayList<Integer> listaSars = SAR_CDI_DAO.selectSarsEnBooking(new Integer(id));
			reporteSars= SAR_CDI_DAO.findSarByProveedorAndFolio(proveedor,listaSars.get(0).toString());
			if(!reporteSars.isEmpty() && reporteSars.size()==1 ) {
				for(SarBO bo:reporteSars) { 
					String soloNombreArchivo = FilenameUtils.getName(fileName);
					log.debug("Se manda a consultar documento con   {} ,{} , {} , {} ::  "+bo.getSealNumber()+bo.getContenedorProveedor(),tipo,"documento",soloNombreArchivo);
					DocumentoDTO documento= expedienteService.getDocumentoById(bo.getSealNumber()+bo.getContenedorProveedor(),tipo,"documento",soloNombreArchivo);
					String fileNameSaved = getFileFromSharePoint(bo.getSealNumber()+bo.getContenedorProveedor(),tipo,documento,pathTemporal,soloNombreArchivo);
					if(fileNameSaved!=null  && fileNameSaved.length()>0) {
						log.debug("Se obtuvo documento con   {} ,{} , {} , {} , {}  "+bo.getSealNumber()+bo.getContenedorProveedor(),tipo,"documento",soloNombreArchivo, fileNameSaved);
						return  getInformatioFromFile(fileNameSaved);
					}
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
  private void borraDocs(Integer id,Integer tipo,String nombre) {
        
	  	BeanDocumentosSDI documentosObj = null;
        try {
            documentosObj = SAR_CDI_DAO.selectDocumentosSDI(id);
        } catch (NumberFormatException e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
        } catch (ClassNotFoundException e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
        } catch (ServletException e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
        }
        try {
            if(documentosObj!=null) {
                List<SarBO> reporteSars =new ArrayList<SarBO>();
                List<Long>  ids =Arrays.asList(tipo.longValue());
                ArrayList<Integer> listaSars = SAR_CDI_DAO.selectSarsEnBooking(id);
                if(getFlagFacturacion(documentosObj.getProveedor())) {
	                reporteSars= SAR_CDI_DAO.findSarByProveedorAndFolio(documentosObj.getProveedor() ,listaSars.get(0).toString());
	                if(!reporteSars.isEmpty() && reporteSars.size()==1 ) {
	                    for(SarBO bo:reporteSars) {
	                        ExpedientePerfilDTO dto =expedienteService.getExpediente(bo.getSealNumber()+bo.getContenedorProveedor(),""+tipo,tipo,Arrays.asList(nombre));                        
	                        if(dto!=null) {
	                            if(dto.getDocumentos()!=null) {
	                                for(DocumentoDTO doc:dto.getDocumentos()) {
	                                    expedienteService.seBorroEnBaseDatos(doc.getId(),"proveedor");
	                                }
	                            }
	                        }
	                        
	                    }
	                }
                }
            }
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

	
	
	
	private ArrayList<BeanOtrosDocumentos> modificaNombre(ArrayList<BeanOtrosDocumentos> selectOtrosDocumentos) {
		ArrayList<BeanOtrosDocumentos> listaNueva = new ArrayList<BeanOtrosDocumentos>();
		for(BeanOtrosDocumentos bean:selectOtrosDocumentos) {
			bean.setNombre(quitaElIdUnico(bean.getNombre()));
			listaNueva.add(bean);
		}
		return listaNueva;
	}



	private String quitaElIdUnico(String nombre) {
		int posicion= nombre.lastIndexOf(POS_FIJO_ID_UNICO);
		if(posicion>0) {
			return nombre.substring(posicion+3, nombre.length());
		}
		return nombre;
	}
	
	
	
	  private void borraAllDocs(String BlContenedor, Long tipo) {
	        try {
	            expedienteService.seBorroEnBaseDatosAll(BlContenedor, tipo);
	        } catch (Exception e) {
	            // TODO Auto-generated catch block
	            e.printStackTrace();
	        }
	    }

	  private void seMandaABorrarDocumentoAExpedienteOtherVersion(Integer id, String folio,String condicion,Integer tipo) throws ClassNotFoundException {
			log.info("Se borra documentacion invoice de ID {}  -  Folio {} ",id,folio);
			List<BeanFactura> lista= daoSAR.selectFacturaXIdOtherVersion(id,condicion);
			if(!lista.isEmpty()) {
	        	if(lista.size()>=1) {
	        		for(BeanFactura fact:lista) {
	        			String nombre=FilenameUtils.getName(fact.getRutaArchivo());
	        			borraDocs(id,tipo,nombre);
	        		}
	    		} 
	    	} 
		}
}
