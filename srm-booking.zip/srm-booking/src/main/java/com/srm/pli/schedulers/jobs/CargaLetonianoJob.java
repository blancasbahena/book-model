package com.srm.pli.schedulers.jobs;

import java.io.FileNotFoundException;

import org.quartz.Job;
import org.quartz.JobExecutionContext;

import com.srm.pli.services.CatalogoService;
import com.srm.pli.utils.PropertiesDb;
import com.truper.infra.loggers.BaseLogger;

public class CargaLetonianoJob implements Job{
	
	
	private final CatalogoService catalogo = CatalogoService
			.getInstance();
	
	@Override
	public void execute(JobExecutionContext arg0)  {
		try {
			boolean flagLetoniano = PropertiesDb.getInstance().getBoolean("srm.flag.letoniano"); 
			BaseLogger.BOOKING_LOGGER.info("[flagLetoniano] {}",flagLetoniano);
			if(flagLetoniano)
			catalogo.cargaHebreo();
		} catch (FileNotFoundException e) {
			BaseLogger.BOOKING_LOGGER.error("Error al cargar descripciones letoniano  " , e );		
		} finally{
			BaseLogger.BOOKING_LOGGER.info("[CargaLetonianoJob] Fin Job");
		}
	}
}

