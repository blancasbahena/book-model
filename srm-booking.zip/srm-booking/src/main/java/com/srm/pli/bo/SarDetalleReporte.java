package com.srm.pli.bo;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SarDetalleReporte {

	private String folio;
	private String material;
	private String status;
	private String tipoEmbarque;
	private String folioConsolidado;
	private String confirmador;
	private String comprado;
	private String BU;
	private String directorBU;
	private String fechaSolicitudSAR;
	private String etdSupplier;
	private String fechaLiberacionPlanner;
	private String diasSupplierToPlanner;
	private String vencidoPlaneacion;
	private String fechaLiberacionShipping;
	private String diasPlannerToShipping;
	private String fechaPI;
	private String PO;

	private String posicion;
	private String proveedor;
	private String nombreProveedor;
	private String planner;
	private String week;
	private String etd;
	private String etdFinal;
	private String puertoOrigen;
	private String tipoContenedor;
	private String volume;
	private String variacionVolumen;
	private String peso;
	private String variacionPeso;
	private String naviera;

	private String vessel;
	private String numContenedor;
	private String booking;
	private String puertoDestino;
	private String IDA;
	private String backorder;
	private String indicadorRetraso;
	private String statusConfirmacionFinal;// Sin o con confirmacion Final
	private String diasSinConfirmacionFinal;
	private String prioridad;
	private String comentariosPlanerador;
	private String comentariosDirectorImports;
	private String comentariosBooking;

	private String nombrePlaneador;
	private String gerente;
	// private String fechaProforma;
	private String indicadorVariacionCantidades;
	private String diasETDvsSolicitudSAR;
	private String quemadoToleranciaPlanning;
	private String percentageOfCompletion;
	private String eta;
	private String voyage;
	private String groundTransportation;
	private String centro;
	private String itemCode;
	private String itemDescription;
	private String quantity;
	private String ultimaModificacionETD;
	private String ultimaETD;
	private String usuarioUltimaETD;

	private String fechaReciboBooking;
	private String fechaLibBooking;
	private String fechaSolCon;
	private String fechaSolTSR;
	private String fechaCierreTSR;
	private String fechaConfFinal;
	private String fechaProvDocs;
	private String referenceNumber;
	private String fechaGDR;
	private String referenciaContenedorProveedor;
	private String bl;

}
