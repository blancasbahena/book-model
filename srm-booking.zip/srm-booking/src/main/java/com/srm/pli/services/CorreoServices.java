package com.srm.pli.services;

import static com.srm.pli.helper.CorreoHelper.MAIL_FR_HK_NOTIFICATIONS;
import static com.srm.pli.helper.CorreoHelper.MAIL_FR_HK_PRICE_ADJUSTMENT;

import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedSet;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.srm.pli.bo.BeanAuditoriaProveedorActualizado;
import com.srm.pli.bo.SarBO;
import com.srm.pli.dao.PriceReleaseDAO;
import com.srm.pli.dao.SAR_CDI_DAO;
import com.srm.pli.dao.SarDao;
import com.srm.pli.dao.SarDetailDao;
import com.srm.pli.helper.CorreoHelper;
import com.srm.pli.utils.CorreoFormato;
import com.srm.pli.utils.CorreoUtils;
import com.srm.pli.utils.FuncionesComunesPLI;
import com.srm.pli.utils.MailUtils;
import com.srm.pli.utils.ProductoUtils;
import com.srm.pli.utils.UnidadNegocioUtils;
import com.truper.bpm.enums.TipoPosicionEnum;
import com.truper.businessEntity.BeanConfirmador;
import com.truper.businessEntity.BeanPoPosicionWithOther;
import com.truper.businessEntity.BeanPriceReleasePosicion;
import com.truper.businessEntity.CompradoresBean;
import com.truper.businessEntity.ImportacionesProveedoresBean;
import com.truper.businessEntity.PlaneadorBean;
import com.truper.businessEntity.SmallProduct;
import com.truper.businessEntity.UnidadNegocio;
import com.truper.businessEntity.UserBean;
import com.truper.utils.string.UtilsString;

public class CorreoServices {

	private static final CorreoServices instance = new CorreoServices();
	private static final Logger log = LogManager.getRootLogger();

	private CorreoServices() {
	}

	public static CorreoServices getInstance() {
		return instance;
	}

	public Set<String> getCorreosProveedor(String proveedor) {
		ImportacionesProveedoresBean bean = FuncionesComunesPLI.getProveedor(proveedor);
		String proveedorMail = bean.getEmail();
		Set<String> correos = CorreoUtils.getInstance().splitCorreos(proveedorMail);
		return correos;
	}

	/**
	 * BU Director o Unidad de negocio que es lo mismo.
	 */
	public Set<String> getCorreosDirectorBu(String celula) {
		UnidadNegocio bean = UnidadNegocioUtils.getInstance().getUnidadNegocio(celula);
		if (bean == null) {
			return null;
		}
		String contacto = bean.getMailContacto();
		Set<String> correos = CorreoUtils.getInstance().splitCorreos(contacto);
		return correos;
	}

	/**
	 * BU gerente o Responsable que es lo mismo.
	 */
	public Set<String> getCorreosGerenteBu(String celula) {
		List<CompradoresBean> responsables = UnidadNegocioUtils.getInstance().getResponsables(celula);
		if (responsables == null || responsables.isEmpty()) {
			return null;
		}
		Set<String> correos = new HashSet<String>();
		for (CompradoresBean responsable : responsables) {
			String contacto = responsable.getCorreo();
			Set<String> aux = CorreoUtils.getInstance().splitCorreos(contacto);
			if (aux == null || aux.isEmpty()) {
				continue;
			}
			correos.addAll(aux);
		}
		return correos;
	}
	
	/**
	 * Regresa el confirmador que libero el SAR, es decir la persona de planning que acepto el SAR
	 * @param celula
	 * @return
	 * @throws Exception 
	 */
	public String getConfirmadorSAR(String usuario) throws Exception {
		if(usuario == null) {
			throw new Exception("Es necesario un dato de entrada.");
		}
		UserBean beanUser = new UserBean();
		beanUser.setUserName(usuario);
		List<UserBean> listaUsuarios = SAR_CDI_DAO.dameUsuarios(beanUser);
		if(listaUsuarios == null || listaUsuarios.isEmpty()) {
			return null;
		}
		
		return listaUsuarios.get(0).getUserEmail();
	}
	
	public Map<Integer, BeanConfirmador> getConfirmadorSar(Set<Integer> sars) {
		return SarDao.getInstance().selectUsuarioApruebaPlaneacion(sars);
	}
	
	public BeanConfirmador getConfirmadorSar(Integer sar) {
		Set<Integer> temp = new HashSet<>();
		temp.add(sar);
		Map<Integer, BeanConfirmador> beans = getConfirmadorSar(temp);
		return beans == null ? null : beans.get(sar);
	}
	
	
	/**
	 * Compradores correos.
	 */
	public Set<String> getCompradoresCorreos(String celula) {
		List<CompradoresBean> compradores = UnidadNegocioUtils.getInstance().getCompradores(celula);
		if (compradores == null || compradores.isEmpty()) {
			return null;
		}
		Set<String> correos = new HashSet<String>();
		for (CompradoresBean comprador : compradores) {
			String contacto = comprador.getCorreo();
			Set<String> aux = CorreoUtils.getInstance().splitCorreos(contacto);
			if (aux == null || aux.isEmpty()) {
				continue;
			}
			correos.addAll(aux);
		}
		return correos;
	}

	/**
	 * Asistentes correos.
	 */
	public Set<String> getAsistentesCorreos(String celula) {
		List<CompradoresBean> asistentes = UnidadNegocioUtils.getInstance().getAsistentes(celula);
		if (asistentes == null || asistentes.isEmpty()) {
			return null;
		}
		Set<String> correos = new HashSet<String>();
		for (CompradoresBean asistente : asistentes) {
			String contacto = asistente.getCorreo();
			Set<String> aux = CorreoUtils.getInstance().splitCorreos(contacto);
			if (aux == null || aux.isEmpty()) {
				continue;
			}
			correos.addAll(aux);
		}
		return correos;
	}
	
	public Set<String> getCorreosGerentePlaneacion(Set<String> planeadores) {
		if (planeadores == null || planeadores.isEmpty())
			return planeadores;
		Set<String> correos = new HashSet<>();
		for (String p : planeadores) {
			if (!UtilsString.isStringValida(p))
				continue;
			PlaneadorBean planeador = FuncionesComunesPLI.planners.get(p.trim());
			if (planeador == null)
				continue;
			String correoGerente = planeador.getCorreoGerente();
			if (UtilsString.isStringValida(correoGerente))
				correos.add(correoGerente.trim());
		}
		return correos;
	}

	
	public String getGerenteFRCorreo(String proveedor) {
		String respuesta = null;
		try {
			Set<String> correos_proveedor = getCorreosProveedor(proveedor);
			Set<String> correos_gerentesFR = CorreoHelper.getInstance().getMapaGerentesFR();
			if (correos_proveedor == null || correos_gerentesFR == null || correos_proveedor.isEmpty()
					|| correos_gerentesFR.isEmpty()) {
				return respuesta;
			}
			for (String correo : correos_gerentesFR) {
				if (correo == null)
					continue;
				if (correos_proveedor.contains(correo)) {
					respuesta = correo;
					break;
				}
			}
		} catch (Exception e) {
			log.error("Valor {}", proveedor, e);
		}
		return respuesta;
	}


	public boolean enviaLiberacionPreciosEnRevision(SortedSet<BeanPriceReleasePosicion> posiciones, String proveedor) {
		try {
			Set<String> correos_set = getCorreosProveedor(proveedor);
			if (correos_set == null || correos_set.isEmpty()) {
				return false;
			}
			String[] correos = new String[correos_set.size()];
			correos_set.toArray(correos);
			String html = CorreoFormato.getHTMLLiberacionPreciosEnRevision(posiciones);
			String asunto = UtilsString.append("SAR ", posiciones.first().getFolio(), " prices were released");
			String sender = CorreoHelper.getInstance().getEmail(MAIL_FR_HK_NOTIFICATIONS);
			MailUtils.enviaCorreo(correos, null, asunto, sender, html, null);
		} catch (Exception e) {
			log.error("Proveedor: {} | posiciones: {}", proveedor, posiciones, e);
			return false;
		}
		return true;
	}
	
	public boolean enviaLiberacionPrecios(int folioSAR, String proveedor,
			SortedSet<BeanPriceReleasePosicion> posiciones, int actualizados) {
		try {
			Set<String> correos_set = getCorreosProveedor(proveedor);
			if (correos_set == null || correos_set.isEmpty()) {
				return false;
			}
			String[] correos = new String[correos_set.size()];
			correos_set.toArray(correos);
			boolean actualizado = false;
			if (actualizados > 0) {
				actualizado = true;
			} else {
				for (BeanPriceReleasePosicion p : posiciones) {
					if (p.isPrecioActualizado()) {
						actualizado = true;
						break;
					}
				}
			}
			String html = CorreoFormato.getHTMLLiberacionPrecios(folioSAR, proveedor, actualizado);
			String asunto = UtilsString.append("SAR ", folioSAR, " prices were revised.");
			String sender = CorreoHelper.getInstance().getEmail(MAIL_FR_HK_PRICE_ADJUSTMENT);
			MailUtils.enviaCorreo(correos, null, asunto, sender, html, null);
		} catch (Exception e) {
			log.error("folioSAR {} | proveedor {} | posiciones {} | actualizados {}", folioSAR, proveedor, posiciones,
					actualizados, e);
			return false;
		}
		return true;
	}
	
	public boolean enviaLiberacionPrecios(int folioSAR) {
		try {
			BeanAuditoriaProveedorActualizado bean_actualizados;
			bean_actualizados = PriceReleaseServices.getInstance().getPreciosActualizados(folioSAR);
			String proveedor = bean_actualizados.getProveedor();
			Set<String> correos_set = getCorreosProveedor(proveedor);
			if (correos_set == null || correos_set.isEmpty()) {
				return false;
			}
			String[] correos = new String[correos_set.size()];
			correos_set.toArray(correos);
			boolean actualizado = bean_actualizados.getActualizados() > 0 ? true : false;
			String html = CorreoFormato.getHTMLLiberacionPrecios(folioSAR, proveedor, actualizado);
			String asunto = UtilsString.append("SAR ", folioSAR, " prices were revised.");
			String sender = CorreoHelper.getInstance().getEmail(MAIL_FR_HK_PRICE_ADJUSTMENT);
			MailUtils.enviaCorreo(correos, null, asunto, sender, html, null);
		} catch (Exception e) {
			log.error("folio: {}", folioSAR, e);
			return false;
		}
		return true;
	}

	public boolean enviaProveedorSolicitaRevisionDePrecios(int folioSAR, String proveedor,
			SortedSet<BeanPoPosicionWithOther> posiciones, String disagreeComments) {
		try {
			Set<String> bus_set = new HashSet<>();
			Set<String> codigos_set = new HashSet<>();
			int num_posi = posiciones.size();
			int count = 0;
			int count_posiciones = 0;
			for (BeanPoPosicionWithOther p : posiciones) {
				count++;
				boolean isOther = p.getTipo().equals(TipoPosicionEnum.OTHER_ITEM);
				if (isOther && (count == num_posi && count_posiciones > 0 || count != num_posi))
					continue;
				String material = null;
				String centro = null;
				if (isOther && count_posiciones == 0) {
					SmallProduct product = SarDetailDao.getInstance().selectMaterialCentroFirst(folioSAR);
					if (product == null) {
						continue;
					} else {
						material = product.getMaterial() + "";
						centro = product.getCentro();
					}
				} else {
					material = p.getMaterial();
					centro = p.getCentro();
				}
				String bu = ProductoUtils.getInstance().getBU(material, centro);
				if (!UtilsString.isStringValida(bu) || ProductoUtils.SIN_PRODUCTO_CENTRO.equalsIgnoreCase(bu)
						|| ProductoUtils.NO_ENCONTRADO.equalsIgnoreCase(bu)) {
					log.error("folio {} | No existe BU para el material: {},  centro: {}", folioSAR, material, centro);
					continue;
				}
				if (!isOther)
					codigos_set.add(material);
				bus_set.add(bu);
				count_posiciones++;
			}
			Set<String> codigos_matriz = PriceReleaseDAO.getInstance().selectProveedorConMatriz(proveedor, codigos_set);

			boolean tiene_matriz = codigos_matriz != null && !codigos_matriz.isEmpty() ? true : false;
			Map<String, Set<String>> correos = CorreoHelper.getInstance()
					.buildCorreosProveedorSolicitaRevisionDePrecios(bus_set, tiene_matriz);
			String[] correos_to = CorreoHelper.getInstance().getCorreosArrayFrom(correos, CorreoHelper.MAIL_TO);
			String[] correos_cc = CorreoHelper.getInstance().getCorreosArrayFrom(correos, CorreoHelper.MAIL_CC);
			ImportacionesProveedoresBean supplier = FuncionesComunesPLI.getProveedor(proveedor);
			if (supplier == null) {
				return false;
			}
			String proveedor_nombre = supplier.getNombreProveedor();
			String proveedor_full = UtilsString.append(proveedor, " - ", proveedor_nombre);
			String html = CorreoFormato.getHTMLSolicitarRevisionPrecios(folioSAR, proveedor_full, posiciones,
					codigos_matriz, disagreeComments);
			String asunto = UtilsString.append("Supplier ", proveedor_full, " price update request");
			String sender = CorreoHelper.getInstance().getEmail(MAIL_FR_HK_PRICE_ADJUSTMENT);
			MailUtils.enviaCorreo(correos_to, correos_cc, asunto, sender, html, null);
		} catch (Exception e) {
			log.error("folioSAR {} | proveedor {} | posiciones {} | disagreeComments {}", folioSAR, proveedor,
					posiciones, disagreeComments, e);
		}
		return true;
	}
	
	/**
	 * @param formatoHTML
	 * @param subject
	 * @param correos
	 */
	public void enviaCorreo(String formatoHTML, String subject, String mailSender, Map<String, Set<String>> correos) {
		String[] correos_to = CorreoHelper.getInstance().getCorreosArrayFrom(correos, CorreoHelper.MAIL_TO);
		String[] correos_cc = CorreoHelper.getInstance().getCorreosArrayFrom(correos, CorreoHelper.MAIL_CC);
		MailUtils.enviaCorreo(correos_to, correos_cc, subject, mailSender, formatoHTML, null);
	}
}
