package com.srm.pli.helper;

import com.srm.pli.bo.BeanReporteSarsSinDocumentos;
import com.srm.pli.services.ShpmntsWODocsService;
import com.truper.businessEntity.BeanSarConfirmacionFinalSinDocumentos;

public class ShpmntsWODocsHelper {

	private static final ShpmntsWODocsHelper instance = new ShpmntsWODocsHelper();

	private ShpmntsWODocsHelper() {
	}

	public static ShpmntsWODocsHelper getInstance() {
		return instance;
	}

	public BeanReporteSarsSinDocumentos parseBean(BeanSarConfirmacionFinalSinDocumentos origen) {
		BeanReporteSarsSinDocumentos bean = new BeanReporteSarsSinDocumentos();
		bean.setBackorderGenerado(origen.getBackorderGenerado());
		bean.setIdaMinimo(origen.getIdaMinimo());
		bean.setFechaEtd(origen.getFechaEtd());
		bean.setFechaEta(origen.getFechaEta());
		String puerto = ShpmntsWODocsService.getInstance().getPuertoNombre(origen.getPuertoDescarga(),
				origen.isPedidoDirecto(), origen.isAereo());
		bean.setPuertoDescarga(puerto);
		bean.setProveedor(origen.getProveedor());
		bean.setProveedorNombre(origen.getProveedorNombre());
		bean.setBooking(origen.getBooking());
		bean.setFechaConfirmacionFinal(origen.getFechaConfirmacionFinal());
		bean.setDiasDesdeConfirmacionFinal(origen.getDiasDesdeConfirmacionFinal());
		return bean;
	}

}
