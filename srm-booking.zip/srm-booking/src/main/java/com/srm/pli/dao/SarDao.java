package com.srm.pli.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.srm.pli.bo.BeanFiltroSar;
import com.srm.pli.bo.SarBO;
import com.srm.pli.db.ConexionDB;
import com.truper.businessEntity.BeanConfirmador;
import com.truper.businessEntity.SAR;
import com.truper.utils.sql.UtilsSQL;
import com.truper.utils.string.UtilsString;

public class SarDao {

	private static final SarDao instance = new SarDao();
	private static final Logger log = LogManager.getRootLogger();
	public static final String CONDICION_ETD_ETDFINAL = "(CASE WHEN s.etdFinal IS NULL OR s.etdFinal < 20000101 THEN s.fechaEmbarque ELSE s.etdFinal END)";

	private SarDao() {
	}

	public static SarDao getInstance() {
		return instance;
	}

	public String fechaETD(int folio) {
		Connection con = null;
		String fecha = "";
		try {
			con = ConexionDB.dameConexion();

			String sql = "SELECT folio ," + CONDICION_ETD_ETDFINAL + " fechaETD from cdiSar s  where folio = ?";
			try (PreparedStatement pst = con.prepareStatement(sql)) {
				pst.setInt(1, folio);
				try (ResultSet rs = pst.executeQuery()) {
					if (rs.next()) {
						fecha = rs.getString("fechaETD");
					}
				}
			}
		} catch (SQLException sqle) {
			log.error("Folio: {}", folio, sqle);
			ConexionDB.renovar(con);
		} catch (Exception e) {
			log.error("Folio: {}", folio, e);
		} finally {
			ConexionDB.devolver(con);
		}
		return fecha;
	}

	public Integer selectEstatusSAR(int folioSAR) {
		Integer estatus = null;
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();
			String sql = "SELECT status FROM cdiSAR WHERE folio = ?";
			try (PreparedStatement pst = con.prepareStatement(sql)) {
				pst.setInt(1, folioSAR);
				try (ResultSet rs = pst.executeQuery()) {
					if (rs.next()) {
						estatus = rs.getInt("status");
					}
				}
			}
		} catch (SQLException sqle) {
			log.error("Folio: {}", folioSAR, sqle);
			ConexionDB.renovar(con);
		} catch (Exception e) {
			log.error("Folio: {}", folioSAR, e);
		} finally {
			ConexionDB.devolver(con);
		}
		return estatus;
	}

	public List<SarBO> selectSarsConfirmacionFinal(BeanFiltroSar filtroSar, boolean isConConfirmacionFinal) {
		List<SarBO> respuesta = null;
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();
			String query = getQuerySarsConfirmacionFinal(filtroSar, isConConfirmacionFinal);
			try (PreparedStatement pst = con.prepareStatement(query)) {
				setValuesSarsConfirmacionFinal(pst, filtroSar);
				try (ResultSet rs = pst.executeQuery()) {
					respuesta = new ArrayList<>();
					while (rs.next()) {
						SarBO tmpSAR = new SarBO();
						tmpSAR.setFolio(rs.getInt("folio"));
						tmpSAR.setProveedor(rs.getString("proveedor"));
						tmpSAR.setPuertoSalida(rs.getString("puertoSalida"));
						tmpSAR.setNaviera(rs.getInt("naviera"));
						if (rs.wasNull()) {
							tmpSAR.setNaviera(null);
						}
						tmpSAR.setFechaEmbarque(rs.getInt("fechaEmbarque"));
						tmpSAR.setConsolidado(rs.getBoolean("consolidado"));
						tmpSAR.setStatus(rs.getInt("status"));
						tmpSAR.setFechaSolicitudDeAprobacion(rs.getInt("fechaSolAprobacion"));
						if (rs.wasNull()) {
							tmpSAR.setFechaSolicitudDeAprobacion(null);
						}
						tmpSAR.setUsuarioSolicitudDeAprobacion(rs.getString("usuarioSolAprobacion"));
						tmpSAR.setFechaUltimaAprobacionRechazo(rs.getInt("fechaUltAprobRechazo"));
						tmpSAR.setUsuarioApruebaPlanning(rs.getString("usuarioApruebaPlanning"));
						tmpSAR.setUsuarioApruebaRechaza(rs.getString("usuarioApruebaRechaza"));
						tmpSAR.setTipoContenedor(rs.getInt("tipoContenedor"));
						tmpSAR.setPrioridad(rs.getInt("prioridad"));
						tmpSAR.setBarcoSugerido(rs.getString("barcoSugerido"));
						tmpSAR.setViaje(rs.getString("viaje"));
						tmpSAR.setPuertoDescarga(rs.getString("puertoDescarga"));
						tmpSAR.setContenedor(rs.getString("contenedor"));
						tmpSAR.setBooking(rs.getString("booking"));
						tmpSAR.setEtdPlanner(rs.getInt("etd"));
						tmpSAR.setEtdReal(rs.getInt("etdFinal"));
						tmpSAR.setComentarioCancelacion(rs.getString("comentarioCancelacion"));
						tmpSAR.setFolioConsolidado(rs.getInt("folioConsolidado"));
						if (rs.wasNull()) {
							tmpSAR.setFolioConsolidado(null);
						}
						tmpSAR.setEsAereo(rs.getBoolean("esAereo"));
						tmpSAR.setAvion(rs.getString("avion"));
						tmpSAR.setAerolinea(rs.getInt("aerolinea"));
						tmpSAR.setLlegadaAvion(rs.getInt("llegadaAvion"));
						if (rs.wasNull()) {
							tmpSAR.setLlegadaAvion(null);
						}

						tmpSAR.setTransporte(rs.getInt("transporte"));
						tmpSAR.setComentarioPlanner(rs.getString("comentarioPlanner"));
						tmpSAR.setComentarioShipping(rs.getString("comentarioShipping"));
						tmpSAR.setEsSinPO(rs.getBoolean("esSinPO"));
						tmpSAR.setEta(rs.getInt("eta"));

						tmpSAR.setBl(rs.getString("bl"));
						tmpSAR.setAprobadoPorCompras(rs.getBoolean("aprobadoPorCompras"));
						tmpSAR.setTipoRetraso(rs.getInt("tipoRetraso"));
						tmpSAR.setCreationDate(rs.getInt("fechaCreacion"));
						tmpSAR.setModificadoProveedor(rs.getBoolean("fueModificadoProveedor"));
						tmpSAR.setAceptadoConDiferencias(rs.getBoolean("aceptadoConDiferencias"));
						if (rs.wasNull()) {
							tmpSAR.setAceptadoConDiferencias(null);
						}
						tmpSAR.setPaisDestino(rs.getInt("paisDestino"));
						if (rs.wasNull()) {
							tmpSAR.setPaisDestino(null);
						}

						tmpSAR.setCargoAProveedor(rs.getBoolean("cargoAProveedor"));
						tmpSAR.setOtraAerolinea(rs.getString("otraAerolinea"));
						tmpSAR.setAprobadoProveedor(rs.getBoolean("aprobadoProveedor"));

						tmpSAR.setEsMultiple(rs.getBoolean("esmultiple"));
						if (rs.wasNull()) {
							tmpSAR.setEsMultiple(null);
						}
						tmpSAR.setMandante(rs.getInt("mandante"));
						if (rs.wasNull()) {
							tmpSAR.setMandante(null);
						}
						tmpSAR.setAprobadoSDI(rs.getBoolean("aprobadoSDI"));
						if (rs.wasNull()) {
							tmpSAR.setAprobadoSDI(null);
						}

						tmpSAR.setCerradoDocumentosProveedor(rs.getBoolean("cerradoDocumentosProveedor"));
						tmpSAR.setFechaCierreDocumentosProveedor(rs.getInt("fechaCierreDocumentosProveedor"));
						tmpSAR.setFechaAprobadoSDI(rs.getInt("fechaAprobadoSDI"));
						tmpSAR.setComentarioTruperBooking(rs.getString("comentarioTruperBooking"));

						tmpSAR.setFechaUltimaCorreccion(rs.getInt("fechaUltimaCorreccion"));
						tmpSAR.setUsuarioAceptoRechazoSAR(rs.getString("usuarioUltimoRechazoAceptacion"));
						tmpSAR.setRevision(rs.getInt("revision"));
						tmpSAR.setFechaUltimoRechazo(rs.getInt("fechaUltimoRechazo"));
						tmpSAR.setFecIniPlanning(rs.getLong("fecIniPlanning"));
						tmpSAR.setTinyFecIniPlanning(rs.getInt("tinyFecIniPlanning"));
						tmpSAR.setFecIniShipping(rs.getLong("fecIniShipping"));
						tmpSAR.setTinyFecIniShipping(rs.getInt("tinyFecIniShipping"));
						tmpSAR.setFecIniConsolidados(rs.getLong("fecIniConsol"));
						tmpSAR.setTinyFecIniConsolidados(rs.getInt("tinyFecIniConsol"));
						tmpSAR.setFecIniBooking(rs.getLong("fecIniBooking"));
						tmpSAR.setTinyFecIniBooking(rs.getInt("tinyFecIniBooking"));
						tmpSAR.setFecIniSDI(rs.getLong("fecIniSDI"));
						tmpSAR.setTinyFecIniSDI(rs.getInt("tinyFecIniSDI"));
						tmpSAR.setFecIniEmbarque(rs.getLong("fecIniEmbarque"));
						tmpSAR.setTinyFecIniEmbarque(rs.getInt("tinyFecIniEmbarque"));
						tmpSAR.setEsRechazadoSDI(rs.getBoolean("rechazoDocumentosSDI"));

						tmpSAR.setNombreArchivoMRP(rs.getString("archivoMRP"));
						tmpSAR.setTieneDiferenciaMRP(rs.getBoolean("diferenciaMRP"));
						tmpSAR.setCargaArchivoMRP(rs.getInt("cargaArchivoMRP"));
						if (rs.wasNull()) {
							tmpSAR.setCargaArchivoMRP(null);
						}
						tmpSAR.setNeedsAuthImpDir(rs.getBoolean("needAuthImpDir"));
						tmpSAR.setAprobadoDirImportaciones(rs.getBoolean("aprobadoDirImportaciones"));
						tmpSAR.setUserApruebaDirImportaciones(rs.getString("userApruebaDirImportaciones"));
						tmpSAR.setFechaAprobacionDirImportaciones(rs.getInt("fechaApruebaDirImportaciones"));
						tmpSAR.setCommentForImpDir(rs.getString("commentForImpDir"));
						tmpSAR.setImpDirComments(rs.getString("impDirComments"));
						tmpSAR.setAdelantoAtrasoETDImpDir(rs.getInt("adelantoAtrasoETDImpDir"));

						tmpSAR.setEtdProveedor(rs.getInt("etdProveedor"));
						if (rs.wasNull()) {
							tmpSAR.setEtdProveedor(null);
						}
						tmpSAR.setCargadoMRP(rs.getBoolean("cargadoMRP"));
						tmpSAR.setNotificacionMRP(rs.getBoolean("notificacionMRP"));
						tmpSAR.setEnRevisionConfirmFinal(rs.getBoolean("enRevisionConfirmFinal"));
						tmpSAR.setCommentRevFinalConfirm(rs.getString("commentRevFinalConfirm"));
						tmpSAR.setAceptadoRevFinalConfirm(rs.getBoolean("aceptadoRevFinalConfirm"));
						if (rs.wasNull()) {
							tmpSAR.setAceptadoRevFinalConfirm(null);
						}
						tmpSAR.setUsrAceptaRechazaRevFinal(rs.getString("usrAceptaRechazaRevFinal"));
						tmpSAR.setNumRevFinal(rs.getInt("numRevFinal"));
						Boolean aplicaBitacoraImpDir = (Boolean) rs.getObject("aplicaBitacoraImpDir");
						tmpSAR.setAplicaBitacora(aplicaBitacoraImpDir);
						Boolean bitacoraImpDirCerrada = (Boolean) rs.getObject("bitacoraImpDirCerrada");
						tmpSAR.setBitacoraImportsDirCerrada(bitacoraImpDirCerrada);
						tmpSAR.setFecCierreBitacoraImpDir(rs.getInt("fecCierreBitacoraImpDir"));
						if (rs.wasNull()) {
							tmpSAR.setFecCierreBitacoraImpDir(null);
						}
						Boolean tieneSim = (Boolean) rs.getObject("tieneSimulador");
						tmpSAR.setTieneSimulador(tieneSim);

						boolean preciosLiberados = rs.getBoolean("preciosLiberados");
						tmpSAR.setPreciosLiberados(preciosLiberados);
						boolean preciosEnRevision = rs.getBoolean("preciosEnRevision");
						tmpSAR.setPreciosEnRevision(preciosEnRevision);
						tmpSAR.setVersionSDI(rs.getInt("versionSetDocumentos"));
						respuesta.add(tmpSAR);
					}
				}
			}
		} catch (SQLException sqle) {
			log.error("Valores - filtroSar {} isConConfirmacionFinal {}", filtroSar, isConConfirmacionFinal, sqle);
			ConexionDB.renovar(con);
		} catch (Exception e) {
			log.error("Valores - filtroSar {} isConConfirmacionFinal {}", filtroSar, isConConfirmacionFinal, e);
		} finally {
			ConexionDB.devolver(con);
		}
		return respuesta;
	}

	public Map<Integer, BeanConfirmador> selectUsuarioApruebaPlaneacion(Set<Integer> sars) {
		if (sars == null || sars.isEmpty())
			return null;
		Map<Integer, BeanConfirmador> respuesta = null;
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();
			try (Statement st = con.createStatement()) {
				StringBuffer sql = new StringBuffer();
				sql.append("SELECT s.folio ");
				sql.append("       , s.usuarioapruebaplanning ");
				sql.append("       , u.useremail ");
				sql.append(" FROM   cdisar s ");
				sql.append("       LEFT JOIN cdiusers u ");
				sql.append("              ON s.usuarioapruebaplanning = u.username ");
				sql.append(" WHERE  folio IN ");
				sql.append(UtilsSQL.convierteToIN(sars));
				try (ResultSet rs = st.executeQuery(sql.toString())) {
					respuesta = new HashMap<>();
					while (rs.next()) {
						Integer folio = rs.getInt("folio");
						String usuario = rs.getString("usuarioapruebaplanning");
						String correo = rs.getString("useremail");
						BeanConfirmador bean = new BeanConfirmador(usuario, correo);
						respuesta.put(folio, bean);
					}
				}
			}
		} catch (Exception e) {
			log.error("Valores - sars {}", sars, e);
		} finally {
			ConexionDB.devolver(con);
		}
		return respuesta;
	}

	private String getQuerySarsConfirmacionFinal(BeanFiltroSar filtroSar, boolean isConConfirmacionFinal) {
		StringBuilder sql = new StringBuilder();
		sql.append("SELECT folio ");
		sql.append("       , proveedor ");
		sql.append("       , puertoSalida ");
		sql.append("       , naviera ");
		sql.append("       , fechaEmbarque ");
		sql.append("       , consolidado ");
		sql.append("       , status ");
		sql.append("       , fechaSolAprobacion ");
		sql.append("       , usuarioSolAprobacion ");
		sql.append("       , fechaUltAprobRechazo ");
		sql.append("       , usuarioApruebaPlanning ");
		sql.append("       , usuarioApruebaRechaza ");
		sql.append("       , tipoContenedor ");
		sql.append("       , prioridad ");
		sql.append("       , barcoSugerido ");
		sql.append("       , viaje ");
		sql.append("       , puertoDescarga ");
		sql.append("       , contenedor ");
		sql.append("       , booking ");
		sql.append("       , etd ");
		sql.append("       , etdFinal ");
		sql.append("       , comentarioCancelacion ");
		sql.append("       , folioConsolidado ");
		sql.append("       , transporte ");
		sql.append("       , comentarioPlanner ");
		sql.append("       , comentarioShipping ");
		sql.append("       , esSinPO ");
		sql.append("       , eta ");
		sql.append("       , bl ");
		sql.append("       , aprobadoPorCompras ");
		sql.append("       , tipoRetraso ");
		sql.append("       , fechaCreacion ");
		sql.append("       , esAereo ");
		sql.append("       , fueModificadoProveedor ");
		sql.append("       , aerolinea ");
		sql.append("       , avion ");
		sql.append("       , llegadaavion ");
		sql.append("       , aceptadoConDiferencias ");
		sql.append("       , paisDestino ");
		sql.append("       , cargoAProveedor ");
		sql.append("       , otraAerolinea ");
		sql.append("       , aprobadoProveedor ");
		sql.append("       , esmultiple ");
		sql.append("       , mandante ");
		sql.append("       , aprobadoSDI ");
		sql.append("       , cerradoDocumentosProveedor ");
		sql.append("       , fechaCierreDocumentosProveedor ");
		sql.append("       , fechaAprobadoSDI ");
		sql.append("       , comentarioTruperBooking ");
		sql.append("       , fechaUltimoRechazo ");
		sql.append("       , fechaUltimaCorreccion ");
		sql.append("       , usuarioUltimoRechazoAceptacion ");
		sql.append("       , revision ");
		sql.append("       , fecIniPlanning ");
		sql.append("       , tinyFecIniPlanning ");
		sql.append("       , fecIniShipping ");
		sql.append("       , tinyFecIniShipping ");
		sql.append("       , fecIniConsol ");
		sql.append("       , tinyFecIniConsol ");
		sql.append("       , fecIniBooking ");
		sql.append("       , tinyFecIniBooking ");
		sql.append("       , fecIniSDI ");
		sql.append("       , tinyFecIniSDI ");
		sql.append("       , fecIniEmbarque ");
		sql.append("       , tinyFecIniEmbarque ");
		sql.append("       , rechazoDocumentosSDI ");
		sql.append("       , diferenciaMRP ");
		sql.append("       , cargaArchivoMRP ");
		sql.append("       , archivoMRP ");
		sql.append("       , needAuthImpDir ");
		sql.append("       , aprobadoDirImportaciones ");
		sql.append("       , userApruebaDirImportaciones ");
		sql.append("       , fechaApruebaDirImportaciones ");
		sql.append("       , commentForImpDir ");
		sql.append("       , impDirComments ");
		sql.append("       , adelantoAtrasoETDImpDir ");
		sql.append("       , cargadoMRP ");
		sql.append("       , etdProveedor ");
		sql.append("       , notificacionMRP ");
		sql.append("       , enRevisionConfirmFinal ");
		sql.append("       , commentRevFinalConfirm ");
		sql.append("       , aceptadoRevFinalConfirm ");
		sql.append("       , usrAceptaRechazaRevFinal ");
		sql.append("       , numRevFinal ");
		sql.append("       , aplicaBitacoraImpDir ");
		sql.append("       , bitacoraImpDirCerrada ");
		sql.append("       , fecCierreBitacoraImpDir ");
		sql.append("       , tieneSimulador ");
		sql.append("       , preciosLiberados ");
		sql.append("       , versionSetDocumentos ");
		sql.append("       , preciosEnRevision ");
		sql.append(" FROM   cdisar ");
		Integer folio = filtroSar.getFolio();
		if (isConConfirmacionFinal) {
			sql.append(" WHERE aprobadoProveedor = 1 ");
			if (folio != null && folio > 0) {
				sql.append(" AND folio = ? ");
				return sql.toString();
			}
			sql.append(" AND fechaConfirmacionFinal ");
			sql.append("	BETWEEN dbo.intToDateTime(?, DEFAULT) AND dbo.intToDateTime(?, 1) ");
		} else {
			sql.append(" WHERE booking IS NOT NULL ");
			sql.append("	AND ( aprobadoproveedor IS NULL OR aprobadoproveedor = 0 ) ");
			sql.append("	AND status = ").append(SAR.STATUS_APROBADO);
			if (folio != null && folio > 0) {
				sql.append(" AND folio = ? ");
				return sql.toString();
			}
			sql.append(" AND (CASE WHEN etdFinal IS NULL OR etdFinal < 20000101 THEN fechaEmbarque ELSE etdFinal END)");
			sql.append(" BETWEEN ? AND ? ");
		}
		if (UtilsString.isStringValida(filtroSar.getProveedor())) {
			sql.append(" AND proveedor = ? ");
		}
		return sql.toString();
	}

	private void setValuesSarsConfirmacionFinal(PreparedStatement pst, BeanFiltroSar filtroSar) throws SQLException {
		int i = 0;
		Integer folio = filtroSar.getFolio();
		if (folio != null && folio > 0) {
			pst.setInt(++i, folio);
			return;
		}
		pst.setInt(++i, filtroSar.getFechaInicial());
		pst.setInt(++i, filtroSar.getFechaFinal());
		if (UtilsString.isStringValida(filtroSar.getProveedor())) {
			pst.setString(++i, filtroSar.getProveedor());
		}
	}

}
