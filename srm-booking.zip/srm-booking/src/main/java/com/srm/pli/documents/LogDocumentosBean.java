package com.srm.pli.documents;

import java.util.Date;

import com.srm.pli.enums.DocumentosAccionEnum;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class LogDocumentosBean {

	private Long id;
	private String booking;
	private String proveedor;
	private DocumentosAccionEnum accion;
	private Date fechaProveedor;
	private Date createDate;

}
