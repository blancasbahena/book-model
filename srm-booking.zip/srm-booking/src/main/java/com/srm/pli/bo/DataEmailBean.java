package com.srm.pli.bo;

import java.io.File;
import java.io.Serializable;
import java.util.Map;
import java.util.Set;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DataEmailBean implements Serializable
{
	private static final long serialVersionUID = 1L;
	private String sender;
	private String subject;
	private String cuerpoCorreo;
	private String[] correoTo;
	private String[] correoCC;
	private File file;
	Map<String, Set<String>> correosMap;
}
