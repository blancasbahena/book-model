package com.srm.pli.rest;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.srm.pli.utils.ProductoUtils;
import com.truper.businessEntity.ProductoBean;
import com.truper.infra.rs.BaseRS;
import com.truper.utils.string.UtilsString;

@Path("/producto")
public class ProductoRest extends BaseRS {

	private static final long serialVersionUID = 6562403563215525616L;
	Gson g = new GsonBuilder().serializeSpecialFloatingPointValues().create();

	@GET
	@Path("{codigo}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getProducto(@PathParam("codigo") String codigo) {
		if (UtilsString.isEmptyNullOrUndefined(codigo)) {
			return buildError_JSONResponse("Debe proporcionar un c�digo de producto");
		}
		ProductoBean p = ProductoUtils.getInstance().getProducto(codigo);
		if (p == null) {
			return buildError_JSONResponse(ProductoUtils.NO_ENCONTRADO);
		}
		return buildOK_JSONResponse(p);
	}

}
