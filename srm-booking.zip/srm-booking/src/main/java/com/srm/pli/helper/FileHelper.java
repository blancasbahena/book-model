package com.srm.pli.helper;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.srm.pli.utils.PropertiesLoader;
import com.truper.utils.string.UtilsString;


public class FileHelper {

	private static final FileHelper instance = new FileHelper();
	public static final String MAIN_DIRECTORY = PropertiesLoader.getInstance().getString("booking.directory.main");
	private static final Logger LOGGER = LogManager.getRootLogger();
	
	
	private FileHelper() {
		try {
			creaDirectorio(MAIN_DIRECTORY);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static FileHelper getInstance() {
		return instance;
	}

	public boolean creaDirectorio(String path) {
		if (path == null || path.trim().isEmpty())
			return false;
		File file = new File(path);
		if (file != null && file.exists() && file.isDirectory()) {
			return true;
		} else {
			if (file.mkdirs()) {
				return true;
			} else {
				return false;
			}
		}
	}

	/***
	 * Crea un directorio sobre al carpeta main definida en el properties
	 * booking.directory.main<br>
	 * Se debe enviar un path de carpetas iniciando con "/" y terminando sin "/".
	 * 
	 * @param path
	 *            Ejemplo "/docs/binary/fractal"
	 * @return pathFinal
	 * @author rsantiagor
	 */
	public String creaDirectorioLocal(String path) {
		if (path == null || path.trim().isEmpty() || !path.startsWith("/")) {
			return null;
		}
		String pathFinal = UtilsString.append(MAIN_DIRECTORY, path);
		boolean exito = creaDirectorio(pathFinal);
		if (exito) {
			return pathFinal;
		}
		return null;
	}
	
	/** Lee un archivo en la ruta y regrsa por linea un string
	 * 
	 * @param pathFile Ruta con el nombre del archivo a leer.
	 * @return
	 * @throws IOException 
	 */
	public ArrayList<String> leeArchivoTxt(String pathFile) throws IOException{
		LOGGER.info("Inicia lectura del archivo:" + pathFile);
		try {
			BufferedReader fileBuffer = new BufferedReader(new FileReader(pathFile));
			String line = null;
			ArrayList<String> digitalFile = new ArrayList<>(10000);
			while((line=fileBuffer.readLine())!=null){
				digitalFile.add(line);
			}
			fileBuffer.close();
			LOGGER.info("Fin lectura del archivo:" + pathFile);
			return digitalFile;
		}catch(Exception e) {
			LOGGER.error("Inicia lectura del archivo:" + pathFile);
			throw new IOException(e.toString());
		}
		
	}
	
}
