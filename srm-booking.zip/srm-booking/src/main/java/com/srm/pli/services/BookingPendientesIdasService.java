package com.srm.pli.services;

import java.util.List;
import com.srm.pli.bo.RevisionIDAVistaBean;
import com.truper.businessEntity.SARRevisionIDABean;

public interface BookingPendientesIdasService
{
	List<SARRevisionIDABean> getDatosIdasPendientes();
	List<RevisionIDAVistaBean> getInfByIdasPendientes() throws Exception;
}
