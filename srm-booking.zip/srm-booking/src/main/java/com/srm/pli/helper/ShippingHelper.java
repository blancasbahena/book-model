package com.srm.pli.helper;

import java.util.ArrayList;
import java.util.HashSet;

import com.truper.businessEntity.SARDetalle;

public class ShippingHelper {

	private static final ShippingHelper instance = new ShippingHelper();

	private ShippingHelper() {
	}

	public static ShippingHelper getInstance() {
		return instance;
	}

	public HashSet<Integer> getMateriales(ArrayList<SARDetalle> detalle) {
		if (detalle == null)
			return null;
		HashSet<Integer> materiales = new HashSet<>();
		if (detalle.isEmpty())
			return materiales;

		for (SARDetalle sarDetalle : detalle) {
			Integer material = sarDetalle.getMaterial();
			if (material == null)
				continue;
			materiales.add(material);
		}
		return materiales;
	}
}