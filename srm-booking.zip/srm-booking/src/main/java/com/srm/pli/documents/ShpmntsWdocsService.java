package com.srm.pli.documents;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import com.srm.pli.bo.BeanVistaDocumentos;
import com.srm.pli.bo.SearchParamsDocs;
import com.srm.pli.dao.ShpmntsWdocsDao;
import com.srm.pli.enums.DocumentosAccionEnum;
import com.srm.pli.enums.DocumentosEstatusEnum;

public class ShpmntsWdocsService {

	private static ShpmntsWdocsService instance = null;

	public ShpmntsWdocsService() {
	}

	public static ShpmntsWdocsService getInstance() {
		if (instance == null)
			instance = new ShpmntsWdocsService();
		return instance;
	}

	public List<BeanVistaDocumentos> getDocumentos(SearchParamsDocs search, String vista) {
		List<BeanVistaDocumentos> lista = ShpmntsWdocsDao.getInstance().getDocuments(search, vista);
		return lista;
	}

	public List<BeanVistaDocumentos> getDocumentosNuevosTardios() {
		SearchParamsDocs search = new SearchParamsDocs();
		List<BeanVistaDocumentos> lista = getDocumentos(search, DocumentosEstatusEnum.NUEVOS.name());
		Date hoy = new Date();
		List<BeanVistaDocumentos> documentos = new ArrayList<>();
		for (BeanVistaDocumentos doc : lista) {
			Date fechaAceptaProveedor = doc.getFechaAceptaProveedor();
			long horas = getDiferenciaHoras(fechaAceptaProveedor, hoy);
			if (horas > 48) {
				documentos.add(doc);
			}
		}
		return documentos;
	}

	public void registraLogDocumentos(String booking, String proveedor, DocumentosAccionEnum accion) {
		LogDocumentosBean bean = new LogDocumentosBean();
		bean.setBooking(booking);
		bean.setProveedor(proveedor);
		if (accion == DocumentosAccionEnum.DOCUMENTOS_RECIBIDOS) {
			bean.setFechaProveedor(new Date());
		} else {
			ControlSdiBean controlSdi = ShpmntsWdocsDao.getInstance().selectSdiControlSdi(booking, proveedor);
			bean.setFechaProveedor(controlSdi.getFechaAceptaProveedor());
		}
		bean.setAccion(accion);
		ShpmntsWdocsDao.getInstance().insertLogDocumentos(bean);
	}

	public IndicadoresDocumentosBean getIndicadoresMensualesDeDocumentos() {
		List<LogDocumentosBean> datos = ShpmntsWdocsDao.getInstance().selectIndicadoresMensualesDeDocumentos();
		if (datos == null)
			return null;
		int recibidos = 0;
		int rechazados = 0;
		int aprobados = 0;
		int retroalimentadosOk = 0;
		int retroalimentadosTardio = 0;
		for (LogDocumentosBean d : datos) {
			switch (d.getAccion()) {
			case DOCUMENTOS_RECIBIDOS:
				recibidos++;
				break;
			case DOCUMENTOS_RECHAZADOS:
				rechazados++;
				Date inicio = d.getFechaProveedor();
				Date fin = d.getCreateDate();
				long horas = getDiferenciaHoras(inicio, fin);
				if (horas <= 72) {
					retroalimentadosOk++;
				} else {
					retroalimentadosTardio++;
				}
				break;
			case DOCUMENTOS_APROBADOS:
				aprobados++;
				break;
			default:
				break;
			}
		}
		IndicadoresDocumentosBean bean = new IndicadoresDocumentosBean(recibidos, rechazados, aprobados,
				retroalimentadosOk, retroalimentadosTardio);
		return bean;
	}

	private long getDiferenciaHoras(Date inicio, Date fin) {
		long diff = fin.getTime() - inicio.getTime();
		return TimeUnit.HOURS.convert(diff, TimeUnit.MILLISECONDS);
	}

}