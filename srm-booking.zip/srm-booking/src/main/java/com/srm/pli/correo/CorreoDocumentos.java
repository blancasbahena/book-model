package com.srm.pli.correo;

import static com.srm.pli.helper.CorreoHelper.MAILS_REPORTE_SDI_DOCS_INDICADORES;
import static com.srm.pli.helper.CorreoHelper.MAIL_FR_HK_SYSTEM;
import static com.srm.pli.helper.CorreoHelper.MAIL_GRUPO_SDI;
import static com.srm.pli.helper.CorreoHelper.SALUDO_TODOS_ESP;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.srm.pli.bo.BeanVistaDocumentos;
import com.srm.pli.documents.IndicadoresDocumentosBean;
import com.srm.pli.documents.ShpmntsWdocsService;
import com.srm.pli.format.email.CorreoFormatoGeneral;
import com.srm.pli.helper.CorreoHelper;
import com.srm.pli.services.CorreoServices;
import com.srm.pli.utils.PropertiesDb;

public class CorreoDocumentos {

	private static CorreoDocumentos instance = null;

	private CorreoDocumentos() {

	}

	public static CorreoDocumentos getInstance() {
		if (instance == null)
			instance = new CorreoDocumentos();
		return instance;
	}

	public void mandaCorreoDocumentosNuevosTardios() {
		List<BeanVistaDocumentos> documentos = ShpmntsWdocsService.getInstance().getDocumentosNuevosTardios();
		String subject = "Documentos nuevos tardios";
		String parrafo = "Estos son los documentos con m&aacute;s de 48 horas en el pool de nuevos";
		String preview = "Documentos nuevos tardios";
		String table = CorreoDocumentosFormato.getInstance().buildTableDocumentosNuevosTardios(documentos);
		String sender = CorreoHelper.getInstance().getEmail(MAIL_FR_HK_SYSTEM);
		String to = CorreoHelper.getInstance().getEmail(MAIL_GRUPO_SDI);
		String formatoHTML = CorreoFormatoGeneral.getInstance().getFormatoFR(SALUDO_TODOS_ESP, parrafo, preview, null,
				table);
		Map<String, Set<String>> correos = new HashMap<>();
		Set<String> correosTo = new HashSet<>();
		correosTo.add(to);
		correos.put(CorreoHelper.MAIL_TO, correosTo);
		CorreoServices.getInstance().enviaCorreo(formatoHTML, subject, sender, correos);
	}

	public void mandaIndicadoresDocumentos() {
		IndicadoresDocumentosBean indicadores = ShpmntsWdocsService.getInstance().getIndicadoresMensualesDeDocumentos();
		String subject = "Indicadores de documentos";
		String parrafo = "Estos son los Indicadores mensuales acmulados de documentos";
		String preview = "Indicadores de documentos";
		String table = CorreoDocumentosFormato.getInstance().buildTableIndicadoresDocumentos(indicadores);
		String sender = CorreoHelper.getInstance().getEmail(MAIL_FR_HK_SYSTEM);
		String formatoHTML = CorreoFormatoGeneral.getInstance().getFormatoFR(SALUDO_TODOS_ESP, parrafo, preview, null,
				table);
		Map<String, Set<String>> correos = new HashMap<>();
		Set<String> to = PropertiesDb.getInstance().getStringSet(MAILS_REPORTE_SDI_DOCS_INDICADORES);
		correos.put(CorreoHelper.MAIL_TO, to);
		CorreoServices.getInstance().enviaCorreo(formatoHTML, subject, sender, correos);
	}

}
