package com.srm.pli.helper;

import java.math.BigDecimal;

import com.srm.pli.enums.RoundingMode;

/**
 * Se crea esta clase con el fin de eliminar el uso de la clase FormatSAR
 * para solo usar los datos necesarios y no la carga completa de informacion como 
 * se hace actualmente.
 * Si se requiere cargar algun mapa se solicita la carga de este en el constructor.
 * 
 * @author drodriguezv
 *
 */
public class RoundingHelper {
	private static RoundingHelper instance;
	
	private RoundingHelper() {}
	
	static {
		instance = new RoundingHelper();
	}
	
	public static RoundingHelper getInstance() {
		return instance;
	}
	
	/**
	 * Regresa un BigDecimal con la configuracion por default correspondiente a 
	 * el dato de volumen en F&R
	 * @param valor
	 * @return
	 */
	public BigDecimal getVolumenBigDecimal(Double valor) {
		if(valor == null) {
			return null;
		}
		return new BigDecimal(valor).setScale(RoundingMode.VOLUMEN.getDecimales(),
				RoundingMode.VOLUMEN.getRoundingMode());
	}
	
	/**
	 * Regresa un BigDecimal con la configuracion por default correspondiente a 
	 * el dato de volumen en F&R
	 * @param valor
	 * @return
	 */
	public BigDecimal getVolumenBigDecimal(BigDecimal valor) {
		if(valor == null) {
			return null;
		}
		return valor.setScale(RoundingMode.VOLUMEN.getDecimales(),
				RoundingMode.VOLUMEN.getRoundingMode());
	}
	
}
