package com.srm.pli.bo;

import com.truper.bpm.enums.EstatusAuditoriaEnum;

public class BeanFiltroAuditoriaVista extends BeanFiltroProveedorFolioPo {

	private EstatusAuditoriaEnum estatus;

	public EstatusAuditoriaEnum getEstatus() {
		return estatus;
	}

	public void setEstatus(EstatusAuditoriaEnum estatus) {
		this.estatus = estatus;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("BeanFiltroAuditoriaVista [getEstatus=");
		builder.append(getEstatus());
		builder.append(", toString=");
		builder.append(super.toString());
		builder.append("]");
		return builder.toString();
	}

}