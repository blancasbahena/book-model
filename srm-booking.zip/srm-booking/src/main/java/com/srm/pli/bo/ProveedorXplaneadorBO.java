package com.srm.pli.bo;

import java.util.HashSet;



public class ProveedorXplaneadorBO {
	
	private int id;
	private String idPlaneador;
	private String nombrePlaneador;
	private String proveedoresStr;
	private HashSet<String> arregloProveedores;
	
	
		
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getIdPlaneador() {
		return idPlaneador;
	}
	public void setIdPlaneador(String idPlaneador) {
		this.idPlaneador = idPlaneador;
	}
	public String getNombrePlaneador() {
		return nombrePlaneador;
	}
	public void setNombrePlaneador(String nombrePlaneador) {
		this.nombrePlaneador = nombrePlaneador;
	}
	
	public String getProveedoresStr() {
		return proveedoresStr;
	}
	public void setProveedoresStr(String proveedoresStr) {
		this.proveedoresStr = proveedoresStr;
	}
	public HashSet<String> getArregloProveedores() {
		return arregloProveedores;
	}
	public void setArregloProveedores(HashSet<String> arregloProveedores) {
		this.arregloProveedores = arregloProveedores;
	}
	

}
