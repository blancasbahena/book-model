package com.srm.pli.services;

import java.util.ArrayList;

import com.srm.pli.dao.DocumentosDao;
import com.srm.pli.dao.DocumentosSdiDao;
import com.truper.businessEntity.BeanDocumentoSet;
import com.truper.businessEntity.BeanOtrosDocumentos;
import com.truper.businessEntity.pojo.BuscaDocumentoPojo;

public class DocumentosServices {

	private static final DocumentosServices instance = new DocumentosServices();

	public DocumentosServices() {
	}

	public static DocumentosServices getInstance() {
		return instance;
	}

	public ArrayList<BeanDocumentoSet> getSetDeDocumentos(BuscaDocumentoPojo buscar) {
		ArrayList<BeanDocumentoSet> set = null;
		try {
			set = DocumentosDao.getInstance().selectSetDeDocumentos(buscar);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return set;
	}

	public boolean eliminaOtroDocumento(BeanOtrosDocumentos otro) {
		boolean resultado = false;
		int updates = DocumentosSdiDao.getInstance().updateOtrosDocumentos(otro);
		if (updates > 0) {
			resultado = true;
		}
		if(resultado) {
			Integer id = otro.getId();
			DocumentosSdiDao.getInstance().updateDisponibilidadOtrosDocumentos(id);
		}
		return resultado;
	}

}
