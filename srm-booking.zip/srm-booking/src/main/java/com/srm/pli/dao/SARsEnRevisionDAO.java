package com.srm.pli.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.srm.pli.db.ConexionDB;
import com.truper.businessEntity.SARModificado;

public class SARsEnRevisionDAO extends DAO {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5731462760867699671L;

	@Override
	public List<?> select(Object o) {
		SARModificado sar = (SARModificado)o;
		List<SARModificado> lstSarModificados = new ArrayList<SARModificado>();

		Connection con = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		DAOUtils utils = new  DAOUtils();
		
		StringBuilder select = new StringBuilder();
		if (sar.isEsConsultaParaInser()) {
			select.append("SELECT folio, etdReal, etdModificada, ");
			select.append(" comentarioProveedor, cambiosRevFinalApplied, needsAuthPlanningMgr");
			select.append(" FROM cdiSAREnRevision ");
			select.append(" WHERE 1=1");
		} else {
			select.append("SELECT r.folio, etdReal, etdModificada,");
			select.append(" comentarioProveedor, cambiosRevFinalApplied, needsAuthPlanningMgr ");
			select.append(" FROM cdiSAREnRevision r LEFT JOIN cdisar c ON c.folio = r.folio ");
			select.append(" WHERE 1=1  ");
			select.append(" AND (c.enRevisionIDA is null OR  c.enRevisionIDA = 0) ");
		}

		utils.setSelect(true);

		try {
			con = ConexionDB.dameConexion();
			if (sar.getFolio() != null) {
				if (sar.isEsConsultaParaInser()) {
					select.append(utils.ajustaColumna(" AND folio = ?"));
				} else {
					select.append(utils.ajustaColumna(" AND r.folio = ?"));
				}
			}
			if (sar.getEtd() != null) {
				select.append(utils.ajustaColumna(" AND etdReal = ?"));
			}
			if (sar.getEtdModificada() != null) {
				select.append(utils.ajustaColumna(" AND etdModificada = ?"));
			}
			if (sar.getNeedsAuthPlanningMgr() != null) {
				select.append(utils.ajustaColumna(" AND needsAuthPlanningMgr = ?"));
			}
			
			pst = con.prepareStatement(select.toString());
			int cont = 1;
			
			utils.inicializaQuery(select.toString());
			
			if (sar.getFolio() != null) {
				utils.ajustaParametro(cont++, pst, sar.getFolio(), Integer.class);
			}
			if (sar.getEtd() != null) {
				utils.ajustaParametro(cont++, pst, sar.getEtd(), Integer.class);
			}
			if (sar.getEtdModificada() != null) {
				utils.ajustaParametro(cont++, pst, sar.getEtdModificada(), Integer.class);
			}
			if (sar.getNeedsAuthPlanningMgr() != null) {
				utils.ajustaParametro(cont++, pst, sar.getNeedsAuthPlanningMgr(), Boolean.class);
			}
			rs = pst.executeQuery();
			
			while (rs.next()) {
				SARModificado temp = new SARModificado();
				temp.setFolio(rs.getInt("folio"));
				temp.setEtd(rs.getInt("etdReal"));
				temp.setEtdModificada(rs.getInt("etdModificada"));
				temp.setComentarioProveedor(rs.getString("comentarioProveedor"));
				temp.setCambiosRevFinalApplied(rs.getBoolean("cambiosRevFinalApplied"));
				temp.setNeedsAuthPlanningMgr(rs.getBoolean("needsAuthPlanningMgr"));
				lstSarModificados.add(temp);
			}
		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				BOOKING_LOGGER.error(ex.getMessage(), ex);
			}
			BOOKING_LOGGER.error(e.getMessage(), e);
		} catch (Exception e) {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				BOOKING_LOGGER.error(ex.getMessage(), ex);
			}
			BOOKING_LOGGER.error(e.getMessage(), e);
		} finally {
			try {
				rs.close();
				pst.close();
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				BOOKING_LOGGER.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
		return lstSarModificados;
	}

	@Override
	public boolean insert(Object o) {
		SARModificado sar = (SARModificado)o;
		Connection con = null;
		PreparedStatement pst = null;
		DAOUtils utilDao = new DAOUtils();
		
		StringBuilder insert = new StringBuilder("INSERT INTO cdiSAREnRevision");
		insert.append(" (folio, etdReal, etdModificada, comentarioProveedor, needsAuthPlanningMgr)");
		insert.append(" VALUES (?,?,?,?,?)");
		
		boolean exito = false;

		try {
			con = ConexionDB.dameConexion();
			pst = con.prepareStatement(insert.toString());
			int cont = 1;
			utilDao.ajustaParametro(cont++, pst, sar.getFolio(), Integer.class);
			utilDao.ajustaParametro(cont++, pst, sar.getEtd(), Integer.class);
			utilDao.ajustaParametro(cont++, pst, sar.getEtdModificada(), Integer.class);
			utilDao.ajustaParametro(cont++, pst, sar.getComentarioProveedor(), String.class);
			utilDao.ajustaParametro(cont++, pst, sar.getNeedsAuthPlanningMgr(), Boolean.class);
			
			utilDao.inicializaQuery(insert.toString());		
			
			exito = pst.executeUpdate() > 0;
			ConexionDB.devuelveConexion(con);
		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				BOOKING_LOGGER.error(ex.getMessage(), ex);
			}
			BOOKING_LOGGER.error(e.getMessage(), e);
		} catch (Exception e) {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				BOOKING_LOGGER.error(ex.getMessage(), ex);
			}
			BOOKING_LOGGER.error(e.getMessage(), e);
		} finally {
			try {
				pst.close();
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				BOOKING_LOGGER.error(sqlEx2.getMessage(), sqlEx2);
			}
		}

		return exito;
	}

	@Override
	public boolean update(Object o) {
		SARModificado sar = (SARModificado)o;
		Connection con = null;
		PreparedStatement pst = null;
		StringBuilder update = new StringBuilder();
		update.append("UPDATE  cdiSAREnRevision SET ");
		
		DAOUtils utils = new  DAOUtils();
		boolean exito = false;
		
		try {
			con = ConexionDB.dameConexion();
			if (sar.getEtd() != null) {
				update.append(utils.ajustaColumna(" etdReal = ?"));
			}
			if (sar.getEtdModificada() != null) {
				update.append(utils.ajustaColumna(" etdModificada = ?"));
			}
			if (sar.getComentarioProveedor() != null) {
				update.append(utils.ajustaColumna(" comentarioProveedor = ?"));
			}
			if (sar.getCambiosRevFinalApplied() != null) {
				update.append(utils.ajustaColumna(" cambiosRevFinalApplied = ?"));
			}
			if (sar.getNeedsAuthPlanningMgr() != null) {
				update.append(utils.ajustaColumna(" needsAuthPlanningMgr = ?"));
			}
			update.append(" WHERE folio = ?");

			int cont = 1;
			pst = con.prepareStatement(update.toString());
			
			utils.inicializaQuery(update.toString());

			if (sar.getEtd() != null) {
				agregarPs(cont++, pst, sar.getEtd(), Integer.class);
			}
			if (sar.getEtdModificada() != null) {
				agregarPs(cont++, pst, sar.getEtdModificada(), Integer.class);
			}
			if (sar.getComentarioProveedor() != null) {
				agregarPs(cont++, pst, sar.getComentarioProveedor(), String.class);
			}
			if (sar.getCambiosRevFinalApplied() != null) {
				agregarPs(cont++, pst, sar.getCambiosRevFinalApplied(), Boolean.class);
			}
			if (sar.getNeedsAuthPlanningMgr() != null) {
				agregarPs(cont++, pst, sar.getNeedsAuthPlanningMgr(), Boolean.class);
			}

			agregarPs(cont++, pst, sar.getFolio(), Integer.class);

			int resultado = pst.executeUpdate();
			exito = resultado > 0;
			pst.close();

			ConexionDB.devuelveConexion(con);

		} catch (Exception e) {
			try {
				pst.close();
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				BOOKING_LOGGER.error(ex.getMessage(), ex);
			}
			BOOKING_LOGGER.error(e.getMessage(), e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				BOOKING_LOGGER.error(sqlEx2.getMessage(), sqlEx2);
			}
		}

		return exito;
	}
	
	public boolean delete(Object o) {
		Integer folio = (Integer) o;
		Connection con = null;
		PreparedStatement pst = null;
		StringBuilder delete = new StringBuilder();
		boolean exito = false;
		try {

			delete.append("DELETE  cdiSAREnRevision");
			delete.append(" WHERE folio = ?");

			int cont = 1;
			con = ConexionDB.dameConexion();

			pst = con.prepareStatement(delete.toString());

			agregarPs(cont++, pst, folio, Integer.class);

			int resultado = pst.executeUpdate();
			exito = resultado > 0;
			pst.close();

			ConexionDB.devuelveConexion(con);

		} catch (Exception e) {
			try {
				pst.close();
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				BOOKING_LOGGER.error(ex.getMessage(), ex);
			}
			BOOKING_LOGGER.error(e.getMessage(), e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				BOOKING_LOGGER.error(sqlEx2.getMessage(), sqlEx2);
			}
		}

		return exito;
	}

}
