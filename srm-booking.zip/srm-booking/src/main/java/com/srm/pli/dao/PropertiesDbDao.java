package com.srm.pli.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.HashMap;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.srm.pli.db.ConexionDB;
import com.truper.utils.string.UtilsString;

public class PropertiesDbDao {

	private static final PropertiesDbDao instance = new PropertiesDbDao();
	private static final Logger log = LogManager.getRootLogger();

	private PropertiesDbDao() {
	}

	public static PropertiesDbDao getInstance() {
		return instance;
	}

	public Map<String, String> getProperties(String instancia) {
		Map<String, String> respuesta = null;
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();
			StringBuilder sql = new StringBuilder();
			sql.append(" SELECT llave, valor ");
			sql.append(" FROM cdiConfProperties ");
			sql.append(" WHERE instancia like ? ");
			try (PreparedStatement pst = con.prepareStatement(sql.toString())) {
				pst.setString(1, UtilsString.append("%", instancia, ";%"));
				try (ResultSet rs = pst.executeQuery()) {
					respuesta = new HashMap<>();
					log.info("Lectura de properties desde la base de datos para la instancia |{}|", instancia);
					while (rs.next()) {
						String llave = rs.getString("llave");
						String valor = rs.getString("valor");
						if (!UtilsString.isStringsValidas(llave, valor)) {
							log.error("Properties mal configurado llave |{}| valor |{}|", llave, valor);
							continue;
						}
						llave = llave.trim();
						valor = valor.trim();
						respuesta.put(llave, valor);
						log.info("llave |{}| valor |{}|", llave, valor);
					}
					log.info("Fin de lectura de properties desde la base de datos");
				}
			}
		} catch (Exception e) {
			log.error("Instancia: {}", instancia, e);
		} finally {
			ConexionDB.devolver(con);
		}
		return respuesta;
	}
}
