package com.srm.pli.helper;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;

import com.srm.pli.utils.PropertiesDb;
import com.truper.utils.string.UtilsString;

public class ReportesHelper {

	private static ReportesHelper instance = null;
	private static final String PATH_REPORTES = "documents.jasper.location";

	private ReportesHelper() {
	}

	public static ReportesHelper getInstance() {
		if (instance == null)
			instance = new ReportesHelper();
		return instance;
	}

	public String getPath() {
		String path = PropertiesDb.getInstance().getStringTrim(PATH_REPORTES);
		//path = "C:/Users/rsantiagor/GIT_oxygen/srm-bookig-reports/src/jasper/reports/";
		return path;
	}

	public InputStream getInputStream(String nombreJrxml) throws FileNotFoundException {
		String path = getPath();
		File file = new File(UtilsString.append(path, nombreJrxml));
		InputStream is = new FileInputStream(file);
		return is;
	}

}
