package com.srm.pli.dao.sql;

public class SAR_CDI_DAO_SQL {

	public static final String INSERT_CONSOLIDADO_HISTORICO;
	
	public static final String SELECT_SAR_DETALLE_POR_LLAVE;
	
	public static final String SELECT_CONTROL_SDI_VISTA_SELECTOR;

	static {
		StringBuilder sql = new StringBuilder();
		sql.append("INSERT INTO cdi_consolidadohistorico ");
		sql.append("            (id,folio,puertosalida,naviera,fechaembarque,tipocontenedor, prioridad");
		sql.append("             ,barcosugerido,viaje,puertodescarga,contenedor,booking,etdfinal ");
		sql.append("             ,transporte,comentarioconsolidado,sarsencontenedor,fechamodificacion ");
		sql.append("             ,usuariomodificacion,tiporetraso,retrasoproveedor,tipoproducto) ");
		sql.append("     VALUES ( ?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,? ) ");
		INSERT_CONSOLIDADO_HISTORICO = sql.toString();
		
		
		StringBuilder  sql_selectSarDetalleporLlave = new StringBuilder();
		sql_selectSarDetalleporLlave.append("SELECT folio, po, posicion , material , cantidad , pesoProveedor , ");
		sql_selectSarDetalleporLlave.append("volumenProveedor , centro,planeador,cantidadModificada,");
		sql_selectSarDetalleporLlave.append("pesoModificado,volumenModificado,cliente,paisOrigen,noDocumento,");
		sql_selectSarDetalleporLlave.append(" condicionPago,unidadMedida, statusMRP, tipoValidacionMRP, cantidadUnidadMedida, factorCantidadUnidadMedida ");
		sql_selectSarDetalleporLlave.append(" FROM   cdiSARDetalle ");
		sql_selectSarDetalleporLlave.append(" WHERE   folio = ? ");
		sql_selectSarDetalleporLlave.append(" AND     po = ?  ");
		sql_selectSarDetalleporLlave.append(" AND     posicion = ? ");
		
		SELECT_SAR_DETALLE_POR_LLAVE  = sql_selectSarDetalleporLlave.toString();
		
		//metodo selectControlSDIVistaSelector
		StringBuffer query = new StringBuffer();

		query.append(" SELECT a.puertoDescarga,d.esPedidoDirecto  ");
		query.append(" FROM cdisar a WITH (NOLOCK) inner join cdiDocumentosSDI b WITH (NOLOCK)  ");
		query.append(
				" ON a.booking = b.booking and a.versionSetDocumentos = b.versionSDI and a.proveedor = b.proveedor ");
		query.append(" INNER JOIN cdiControlSDI c WITH (NOLOCK) ON   ");
		query.append(" c.booking = b.booking and c.versionSDI = b.versionSDI and c.proveedor = b.proveedor  ");
		query.append(" Inner join cdisardetalle d WITH (NOLOCK) ON a.folio = d.folio ");
		query.append(" INNER join cdi_facturas f WITH (NOLOCK)  ON b.id = f.id and f.versionDocumento = b.versionFacturas ");
		query.append(" and d.condicionPago = f.condicionPago  ");
		query.append(" GROUP BY puertoDescarga, esPedidoDirecto ");
		
		SELECT_CONTROL_SDI_VISTA_SELECTOR = query.toString();
		
		
		
		
		
		
	}
	
	public static String getNullStringAsEmpty(String valor) {
		return valor == null ? "" : valor.trim();
	}
}