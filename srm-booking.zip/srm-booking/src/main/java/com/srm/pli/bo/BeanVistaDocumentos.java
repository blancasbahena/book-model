package com.srm.pli.bo;

import java.math.BigDecimal;

import org.json.JSONObject;

import com.srm.pli.utils.FormatSARBOUtils;
import com.srm.pli.utils.FuncionesComunesPLI;
import com.truper.businessEntity.BeanControlSDI;
import com.truper.utils.number.UtilsNumero;

import lombok.Getter;
import lombok.Setter;

public class BeanVistaDocumentos extends BeanControlSDI {

	private static final long serialVersionUID = 1L;
	private boolean multiplesFolios;
	private String sarsEnBooking;
	private String prioridad;
	private String bl;
	private String eta;
	private String etd;
	private String terminoPago;
	private String terminoPagoDesc;
	private String pos;
	private String dispacthMode;
	private String tipoEmbarque;
	private String pod;
	private String duePaymentTerm;
	private String naviera;
	private String blType;
	private String sar;
	private String contenedor;
	private String shippingType;
	private boolean semaforo;
	private String foliosEnBooking;
	private boolean tardio;
	private Integer diasTranscurridosRechazo;
	private Integer idaMinimo;
	private BigDecimal backorderAlArribo;
	private boolean preBL;
	@Getter
	@Setter
	private boolean pedidoDirecto;
	
	public JSONObject toJSON() {
		JSONObject json = new JSONObject();
		json.put("booking", getBooking());
		json.put("analista", getAnalistaSDI());
		json.put("comentariosProveedor", getComentariosProveedor());
		json.put("fechaAprobadoProveedor", getFechaAceptaProveedor());
		json.put("fechaAprobadoSDI", getFechaAprobadoSDI());
		json.put("proveedorClave", getProveedor());
		json.put("proveedor",
				getProveedor() + " - " + FuncionesComunesPLI.getProveedor(getProveedor()).getNombreProveedor());
		json.put("prioridad", prioridad);
		Integer _prioridad = null;
		if (UtilsNumero.isInteger(prioridad)) {
			_prioridad = Integer.valueOf(prioridad);
		}
		json.put("prioridadColor", FormatSARBOUtils.colorPrioridad(_prioridad));
		json.put("ETD", etd);
		json.put("ETA", eta);
		json.put("sarMultiples", multiplesFolios);
		json.put("arregloSARs", sarsEnBooking);
		json.put("bl", bl != null ? bl : "");
		json.put("sar", sar);
		json.put("contenedor", contenedor != null ? contenedor : "");
		json.put("po", pos);
		json.put("terminoPago", terminoPago);
		json.put("terminoPagoDesc", terminoPagoDesc);
		json.put("POD", pod);
		json.put("dispacheMode", dispacthMode);
		json.put("shppingType", shippingType);
		json.put("duePaymentTerm", duePaymentTerm);
		json.put("naviera", naviera);
		json.put("blType", blType);
		json.put("semaforo", semaforo);
		json.put("foliosInfo", foliosEnBooking);
		json.put("diasTranscurridosRechazo", getDiasTranscurridosRechazo());
		json.put("idaMinimo", getIdaMinimo());
		json.put("backorderAlArribo", getBackorderAlArribo());
		json.put("esTardio", tardio);
		json.put("havePreBL", preBL);
		json.put("isPedidoDirecto", isPedidoDirecto());
		return json;
	}

	public boolean isMultiplesFolios() {
		return multiplesFolios;
	}

	public void setMultiplesFolios(boolean multiplesFolios) {
		this.multiplesFolios = multiplesFolios;
	}

	public String getSarsEnBooking() {
		return sarsEnBooking;
	}

	public void setSarsEnBooking(String sarsEnBooking) {
		this.sarsEnBooking = sarsEnBooking;
	}

	public String getPrioridad() {
		return prioridad;
	}

	public void setPrioridad(String prioridad) {
		this.prioridad = prioridad;
	}

	public String getBl() {
		return bl;
	}

	public void setBl(String bl) {
		this.bl = bl;
	}

	public String getEta() {
		return eta;
	}

	public void setEta(String eta) {
		this.eta = eta;
	}

	public String getEtd() {
		return etd;
	}

	public void setEtd(String etd) {
		this.etd = etd;
	}

	public String getTerminoPago() {
		return terminoPago;
	}

	public void setTerminoPago(String terminoPago) {
		this.terminoPago = terminoPago;
	}

	public String getPos() {
		return pos;
	}

	public void setPos(String pos) {
		this.pos = pos;
	}

	public String getDispacthMode() {
		return dispacthMode;
	}

	public void setDispacthMode(String dispacthMode) {
		this.dispacthMode = dispacthMode;
	}

	public String getTipoEmbarque() {
		return tipoEmbarque;
	}

	public void setTipoEmbarque(String tipoEmbarque) {
		this.tipoEmbarque = tipoEmbarque;
	}

	public String getPod() {
		return pod;
	}

	public void setPod(String pod) {
		this.pod = pod;
	}

	public String getDuePaymentTerm() {
		return duePaymentTerm;
	}

	public void setDuePaymentTerm(String duePaymentTerm) {
		this.duePaymentTerm = duePaymentTerm;
	}

	public String getNaviera() {
		return naviera;
	}

	public void setNaviera(String naviera) {
		this.naviera = naviera;
	}

	public String getSar() {
		return sar;
	}

	public void setSar(String sar) {
		this.sar = sar;
	}

	public String getContenedor() {
		return contenedor;
	}

	public void setContenedor(String contenedor) {
		this.contenedor = contenedor;
	}

	public String getBlType() {
		return blType;
	}

	public void setBlType(String blType) {
		this.blType = blType;
	}

	public String getShippingType() {
		return shippingType;
	}

	public void setShippingType(String shippingType) {
		this.shippingType = shippingType;
	}

	public String getTerminoPagoDesc() {
		return terminoPagoDesc;
	}

	public void setTerminoPagoDesc(String terminoPagoDesc) {
		this.terminoPagoDesc = terminoPagoDesc;
	}

	public boolean isSemaforo() {
		return semaforo;
	}

	public void setSemaforo(boolean semaforo) {
		this.semaforo = semaforo;
	}

	public String getFoliosEnBooking() {
		return foliosEnBooking;
	}

	public void setFoliosEnBooking(String foliosEnBooking) {
		this.foliosEnBooking = foliosEnBooking;
	}

	public boolean isTardio() {
		return tardio;
	}

	public void setTardio(boolean tardio) {
		this.tardio = tardio;
	}

	public Integer getDiasTranscurridosRechazo() {
		return diasTranscurridosRechazo;
	}

	public void setDiasTranscurridosRechazo(Integer diasTranscurridosRechazo) {
		this.diasTranscurridosRechazo = diasTranscurridosRechazo;
	}

	public Integer getIdaMinimo() {
		return idaMinimo;
	}

	public void setIdaMinimo(Integer idaMinimo) {
		this.idaMinimo = idaMinimo;
	}

	public BigDecimal getBackorderAlArribo() {
		return backorderAlArribo;
	}

	public void setBackorderAlArribo(BigDecimal backorderAlArribo) {
		this.backorderAlArribo = backorderAlArribo;
	}

	public boolean isPreBL() {
		return preBL;
	}

	public void setPreBL(boolean preBL) {
		this.preBL = preBL;
	}
	
}
