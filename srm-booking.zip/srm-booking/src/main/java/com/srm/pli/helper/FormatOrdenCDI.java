package com.srm.pli.helper;

import java.math.BigDecimal;

import org.apache.commons.lang3.StringEscapeUtils;

import com.srm.pli.bo.OrdenCdiBO;
import com.srm.pli.utils.FuncionesComunesPLI;
import com.truper.businessEntity.ContenedorCDI;
import com.truper.businessEntity.ProductoBean;

import lombok.Getter;
import lombok.Setter;

public class FormatOrdenCDI {
	
	private String orden;
	private String posicion;
	private String material;
	private String centro;
	private String codigo;
	private BigDecimal cantidad;
	private double remanente;
	private double peso;
	private String volumen;
	private String pesoRemanente;
	private String volumenRemanente;
	private String planeador;
	private int fechaUltimaConfirmacion;
	private String fechaUltimaConfirmacionFormat;
	private String fechaProforma;
	private String precioUnitario;
	private String moneda;
	private Integer contenedor;
	private String contenedorObj;
	private String unidadMedida;
	private String condicionPago;
	private Boolean tieneCambioETD;
	private Integer fechaETDActual;
	private Integer fechaETDNew;
	private Integer master;
	private Boolean bloqueadaRedFlag;
	private BigDecimal cantidadUnidadMedida;
	private BigDecimal factorCantidadUnidadMedida;
	@Getter @Setter
	private String fabrica;
	@Getter @Setter
	private String fabricaDescripcion;
	@Getter @Setter
	private String descripcionComplementoFactura;
	
	public FormatOrdenCDI(OrdenCdiBO orden) {
		FuncionesComunesPLI.cargaContenedores(false);
		this.orden = orden.getOrden();
		posicion = orden.getPosicion();
		
		ProductoBean p = FuncionesComunesPLI.productos.get(orden.getMaterial());
		String desc = "";
		if(p != null){
			desc = StringEscapeUtils.escapeHtml3(p.getClave() + " " + p.getDescription());
		}
		
		
		if(desc.equals(" ")) {
			desc = StringEscapeUtils.escapeHtml3(p.getClave() + " " + p.getDescripcion());
		}
		
		
		material = orden.getMaterial() + " " + desc;
		centro = orden.getCentro();
		codigo = orden.getMaterial();
		cantidad = orden.getCantidad();
		remanente = orden.getRemanente();
		peso = new BigDecimal(orden.getPeso()).setScale(2, BigDecimal.ROUND_HALF_EVEN).doubleValue();
		volumen = FuncionesComunesPLI.formatea(orden.getVolumen(), 2);
		pesoRemanente = FuncionesComunesPLI.formatea(orden.getPesoRemanente(), 2);
		volumenRemanente = FuncionesComunesPLI.formatea(orden.getVolumenRemanente(), 2);
		planeador = orden.getPlaneador();
		fechaUltimaConfirmacion = (orden.getFechaUltimaConfirmacion());
		fechaUltimaConfirmacionFormat = FuncionesComunesPLI.formateaFecha(orden.getFechaUltimaConfirmacion());
		fechaProforma = FuncionesComunesPLI.formateaFecha(orden.getFechaProforma());
		precioUnitario = FuncionesComunesPLI.formatea(orden.getPrecioUnitario().doubleValue(), 6);
		moneda = orden.getMoneda();
		contenedor = orden.getContenedor() ;
		
		cantidadUnidadMedida = orden.getCantidadUnidadMedida();
		factorCantidadUnidadMedida = orden.getFactorCantidadUnidadMedida();
		descripcionComplementoFactura = orden.getDescripcionComplementoFactura();
		
		ContenedorCDI contObj = FuncionesComunesPLI.mapaContenedores.get(orden.getContenedor());
		String contenedorTmp = "N.D";
		if(contObj != null){
			contenedorTmp = contObj.getNombre();
		}
		contenedorObj = contenedorTmp ;
		
		unidadMedida = orden.getUnidadMedida();
		condicionPago = orden.getCondicionPago();
		
		tieneCambioETD = orden.getTieneCambioETD();
		fechaETDActual = orden.getEtdActual();
		fechaETDNew    = orden.getEtdSugerido();
		master = orden.getMaster() == 0 ? 1 : orden.getMaster();
		bloqueadaRedFlag = orden.getRedFlagOn() == null ? false : orden.getRedFlagOn();
		setFabrica(orden.getFabrica());
		setFabricaDescripcion(orden.getFabricaDescripcion());
	}

	/**
	 * @return the orden
	 */
	public String getOrden() {
		return orden;
	}

	/**
	 * @param orden the orden to set
	 */
	public void setOrden(String orden) {
		this.orden = orden;
	}

	/**
	 * @return the posicion
	 */
	public String getPosicion() {
		return posicion;
	}

	/**
	 * @param posicion the posicion to set
	 */
	public void setPosicion(String posicion) {
		this.posicion = posicion;
	}

	/**
	 * @return the material
	 */
	public String getMaterial() {
		return material;
	}

	/**
	 * @param material the material to set
	 */
	public void setMaterial(String material) {
		this.material = material;
	}

	/**
	 * @return the centro
	 */
	public String getCentro() {
		return centro;
	}

	/**
	 * @param centro the centro to set
	 */
	public void setCentro(String centro) {
		this.centro = centro;
	}

	/**
	 * @return the codigo
	 */
	public String getCodigo() {
		return codigo;
	}

	/**
	 * @param codigo the codigo to set
	 */
	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	/**
	 * @return the cantidad
	 */
	public BigDecimal getCantidad() {
		return cantidad;
	}

	/**
	 * @param cantidad the cantidad to set
	 */
	public void setCantidad(BigDecimal cantidad) {
		this.cantidad = cantidad;
	}

	/**
	 * @return the remanente
	 */
	public double getRemanente() {
		return remanente;
	}

	/**
	 * @param remanente the remanente to set
	 */
	public void setRemanente(double remanente) {
		this.remanente = remanente;
	}

	/**
	 * @return the peso
	 */
	public double getPeso() {
		return peso;
	}

	/**
	 * @param peso the peso to set
	 */
	public void setPeso(double peso) {
		this.peso = peso;
	}

	/**
	 * @return the volumen
	 */
	public String getVolumen() {
		return volumen;
	}

	/**
	 * @param volumen the volumen to set
	 */
	public void setVolumen(String volumen) {
		this.volumen = volumen;
	}

	/**
	 * @return the pesoRemanente
	 */
	public String getPesoRemanente() {
		return pesoRemanente;
	}

	/**
	 * @param pesoRemanente the pesoRemanente to set
	 */
	public void setPesoRemanente(String pesoRemanente) {
		this.pesoRemanente = pesoRemanente;
	}

	/**
	 * @return the volumenRemanente
	 */
	public String getVolumenRemanente() {
		return volumenRemanente;
	}

	/**
	 * @param volumenRemanente the volumenRemanente to set
	 */
	public void setVolumenRemanente(String volumenRemanente) {
		this.volumenRemanente = volumenRemanente;
	}

	/**
	 * @return the planeador
	 */
	public String getPlaneador() {
		return planeador;
	}

	/**
	 * @param planeador the planeador to set
	 */
	public void setPlaneador(String planeador) {
		this.planeador = planeador;
	}

	/**
	 * @return the fechaUltimaConfirmacion
	 */
	public int getFechaUltimaConfirmacion() {
		return fechaUltimaConfirmacion;
	}

	/**
	 * @param fechaUltimaConfirmacion the fechaUltimaConfirmacion to set
	 */
	public void setFechaUltimaConfirmacion(int fechaUltimaConfirmacion) {
		this.fechaUltimaConfirmacion = fechaUltimaConfirmacion;
	}

	/**
	 * @return the fechaProforma
	 */
	public String getFechaProforma() {
		return fechaProforma;
	}

	/**
	 * @param fechaProforma the fechaProforma to set
	 */
	public void setFechaProforma(String fechaProforma) {
		this.fechaProforma = fechaProforma;
	}

	/**
	 * @return the precioUnitario
	 */
	public String getPrecioUnitario() {
		return precioUnitario;
	}

	/**
	 * @param precioUnitario the precioUnitario to set
	 */
	public void setPrecioUnitario(String precioUnitario) {
		this.precioUnitario = precioUnitario;
	}

	/**
	 * @return the moneda
	 */
	public String getMoneda() {
		return moneda;
	}

	/**
	 * @param moneda the moneda to set
	 */
	public void setMoneda(String moneda) {
		this.moneda = moneda;
	}

	/**
	 * @return the contenedor
	 */
	public Integer getContenedor() {
		return contenedor;
	}

	/**
	 * @param contenedor the contenedor to set
	 */
	public void setContenedor(Integer contenedor) {
		this.contenedor = contenedor;
	}

	/**
	 * @return the contenedorObj
	 */
	public String getContenedorObj() {
		return contenedorObj;
	}

	/**
	 * @param contenedorObj the contenedorObj to set
	 */
	public void setContenedorObj(String contenedorObj) {
		this.contenedorObj = contenedorObj;
	}

	/**
	 * @return the unidadMedida
	 */
	public String getUnidadMedida() {
		return unidadMedida;
	}

	/**
	 * @param unidadMedida the unidadMedida to set
	 */
	public void setUnidadMedida(String unidadMedida) {
		this.unidadMedida = unidadMedida;
	}

	/**
	 * @return the condicionPago
	 */
	public String getCondicionPago() {
		return condicionPago;
	}

	/**
	 * @param condicionPago the condicionPago to set
	 */
	public void setCondicionPago(String condicionPago) {
		this.condicionPago = condicionPago;
	}

	public String getFechaUltimaConfirmacionFormat() {
		return fechaUltimaConfirmacionFormat;
	}

	public void setFechaUltimaConfirmacionFormat(
			String fechaUltimaConfirmacionFormat) {
		this.fechaUltimaConfirmacionFormat = fechaUltimaConfirmacionFormat;
	}

	public Boolean getTieneCambioETD() {
		return tieneCambioETD;
	}

	public void setTieneCambioETD(Boolean tieneCambioETD) {
		this.tieneCambioETD = tieneCambioETD;
	}

	public Integer getFechaETDActual() {
		return fechaETDActual;
	}

	public void setFechaETDActual(Integer fechaETDActual) {
		this.fechaETDActual = fechaETDActual;
	}

	public Integer getFechaETDNew() {
		return fechaETDNew;
	}

	public void setFechaETDNew(Integer fechaETDNew) {
		this.fechaETDNew = fechaETDNew;
	}

	/**
	 * @return the master
	 */
	public Integer getMaster() {
		return master;
	}

	/**
	 * @param master the master to set
	 */
	public void setMaster(Integer master) {
		this.master = master;
	}

	/**
	 * @return the bloqueadaRedFlag
	 */
	public Boolean getBloqueadaRedFlag() {
		return bloqueadaRedFlag;
	}

	/**
	 * @param bloqueadaRedFlag the bloqueadaRedFlag to set
	 */
	public void setBloqueadaRedFlag(Boolean bloqueadaRedFlag) {
		this.bloqueadaRedFlag = bloqueadaRedFlag;
	}

	public BigDecimal getCantidadUnidadMedida() {
		return cantidadUnidadMedida;
	}

	public void setCantidadUnidadMedida(BigDecimal cantidadUnidadMedida) {
		this.cantidadUnidadMedida = cantidadUnidadMedida;
	}

	public BigDecimal getFactorCantidadUnidadMedida() {
		return factorCantidadUnidadMedida;
	}

	public void setFactorCantidadUnidadMedida(BigDecimal factorCantidadUnidadMedida) {
		this.factorCantidadUnidadMedida = factorCantidadUnidadMedida;
	}

    
}
