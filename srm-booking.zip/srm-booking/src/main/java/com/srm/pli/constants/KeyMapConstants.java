package com.srm.pli.constants;

public class KeyMapConstants {
	public static final String BOOKING_IN_BD = "searchBookingInBD";

}