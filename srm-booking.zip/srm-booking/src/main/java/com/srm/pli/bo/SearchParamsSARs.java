package com.srm.pli.bo;

import java.io.Serializable;

import com.srm.pli.utils.FuncionesComunesPLI;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SearchParamsSARs implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 4400727538847985271L;
	private String folioType;
	private Integer folio;
	private Integer etdFrom;
	private Integer etdTo;
	private String etaFrom;
	private String etaTo;
	private String creationDateFrom;
	private String creationDateTo;
	private String po;
	private Integer material;
	private String proveedor;
	private String puertoOrigen;
	private String puertoDestino;
	private Integer naviera;
	private String booking;
	private String contenedor;
	private Integer prioridad;
	private String statusSAR;
	private String viaje;
	private String barco;
	private String checkOutPolicy;
	private Boolean bloqueado;
	private Integer type;
	private Integer selectDate;
	private String analyst;
	///Agrego esta variable si el POD es dinamico, es decir va por todos los puertos
	///de descarga sean directos, normales incluso aereos
	private String PODDinamico;
	private Integer planningAppDateFrom;
	private Integer planningAppDateTo;
	private Integer shippingAppDateFrom;
	private Integer shippingAppDateTo;
	private String cdiTSR;
	private String compensatioQuota;
	/**
	 * Agrego este metodo para poder modificar dependendo la vista 
	 * los datos del objeto search
	 * 
	 * @param search
	 * @return
	 */
	public void reacomodaDatosBusqueda() {
		if(this.getSelectDate() != null) {
			switch(this.getSelectDate()) {
				///Cuando seleccione fecha de creacion, este es defult tambien.
				case 0:
					this.setCreationDateFrom(this.getCreationDateFrom());
					this.setCreationDateTo(this.getCreationDateTo());
					
					break;
				case 1:
					this.setEtdFrom(FuncionesComunesPLI.formateaFecha(this.getCreationDateFrom()));
					this.setEtdTo(FuncionesComunesPLI.formateaFecha(this.getCreationDateTo()));
					this.setCreationDateFrom(null);
					this.setCreationDateTo(null);
					break;
				case 2:
					this.setEtaFrom(this.getCreationDateFrom());
					this.setEtaTo(this.getCreationDateTo());
					this.setCreationDateFrom(null);
					this.setCreationDateTo(null);
					break;
				case 3:
					this.setPlanningAppDateFrom(FuncionesComunesPLI.formateaFecha(this.getCreationDateFrom()));
					this.setPlanningAppDateTo(FuncionesComunesPLI.formateaFecha(this.getCreationDateTo()));
					this.setCreationDateFrom(null);
					this.setCreationDateTo(null);
					break;
				case 4:
					this.setShippingAppDateFrom(FuncionesComunesPLI.formateaFecha(this.getCreationDateFrom()));
					this.setShippingAppDateTo(FuncionesComunesPLI.formateaFecha(this.getCreationDateTo()));
					this.setCreationDateFrom(null);
					this.setCreationDateTo(null);
					break;
				default:
					this.setCreationDateFrom(this.getCreationDateFrom());
					this.setCreationDateTo(this.getCreationDateTo());
					break;
			}
			
		}
//		return search;
	}
	
	
	
	public String getFolioType() {
		return folioType;
	}
	public void setFolioType(String folioType) {
		this.folioType = folioType;
	}
	public Integer getFolio() {
		return folio;
	}
	public void setFolio(Integer folio) {
		this.folio = folio;
	}
	public String getEtaFrom() {
		return etaFrom;
	}
	public void setEtaFrom(String etaFrom) {
		this.etaFrom = etaFrom;
	}
	public String getEtaTo() {
		return etaTo;
	}
	public void setEtaTo(String etaTo) {
		this.etaTo = etaTo;
	}
	public String getCreationDateFrom() {
		return creationDateFrom;
	}
	public void setCreationDateFrom(String creationDateFrom) {
		this.creationDateFrom = creationDateFrom;
	}
	public String getCreationDateTo() {
		return creationDateTo;
	}
	public void setCreationDateTo(String creationDateTo) {
		this.creationDateTo = creationDateTo;
	}
	public String getPo() {
		return po;
	}
	public void setPo(String po) {
		this.po = po;
	}
	public Integer getMaterial() {
		return material;
	}
	public void setMaterial(Integer material) {
		this.material = material;
	}
	public String getProveedor() {
		return proveedor;
	}
	public void setProveedor(String proveedor) {
		this.proveedor = proveedor;
	}
	public String getPuertoOrigen() {
		return puertoOrigen;
	}
	public void setPuertoOrigen(String puertoOrigen) {
		this.puertoOrigen = puertoOrigen;
	}
	public String getPuertoDestino() {
		return puertoDestino;
	}
	public void setPuertoDestino(String puertoDestino) {
		this.puertoDestino = puertoDestino;
	}
	public Integer getNaviera() {
		return naviera;
	}
	public void setNaviera(Integer naviera) {
		this.naviera = naviera;
	}
	public String getBooking() {
		return booking;
	}
	public void setBooking(String booking) {
		this.booking = booking;
	}
	public String getContenedor() {
		return contenedor;
	}
	public void setContenedor(String contenedor) {
		this.contenedor = contenedor;
	}
	public Integer getPrioridad() {
		return prioridad;
	}
	public void setPrioridad(Integer prioridad) {
		this.prioridad = prioridad;
	}
	public String getStatusSAR() {
		return statusSAR;
	}
	public void setStatusSAR(String statusSAR) {
		this.statusSAR = statusSAR;
	}
	public String getViaje() {
		return viaje;
	}
	public void setViaje(String viaje) {
		this.viaje = viaje;
	}
	public String getBarco() {
		return barco;
	}
	public void setBarco(String barco) {
		this.barco = barco;
	}
	public String getCheckOutPolicy() {
		return checkOutPolicy;
	}
	public void setCheckOutPolicy(String checkOutPolicy) {
		this.checkOutPolicy = checkOutPolicy;
	}
	public Integer getType() {
		return type;
	}
	public void setType(Integer type) {
		this.type = type;
	}
	public String getAnalyst() {
		return analyst;
	}
	public void setAnalyst(String analyst) {
		this.analyst = analyst;
	}
	public Boolean getBloqueado() {
		return bloqueado;
	}
	public void setBloqueado(Boolean bloqueado) {
		this.bloqueado = bloqueado;
	}
	public Integer getEtdFrom() {
		return etdFrom;
	}
	public void setEtdFrom(Integer etdFrom) {
		this.etdFrom = etdFrom;
	}
	public Integer getEtdTo() {
		return etdTo;
	}
	public void setEtdTo(Integer etdTo) {
		this.etdTo = etdTo;
	}
	public String getPODDinamico() {
		return PODDinamico;
	}
	public void setPODDinamico(String pODDinamico) {
		PODDinamico = pODDinamico;
	}
	public Integer getSelectDate() {
		return selectDate;
	}
	public void setSelectDate(Integer selectDate) {
		this.selectDate = selectDate;
	}



	public Integer getPlanningAppDateFrom() {
		return planningAppDateFrom;
	}



	public void setPlanningAppDateFrom(Integer planningAppDateFrom) {
		this.planningAppDateFrom = planningAppDateFrom;
	}



	public Integer getPlanningAppDateTo() {
		return planningAppDateTo;
	}



	public void setPlanningAppDateTo(Integer planningAppDateTo) {
		this.planningAppDateTo = planningAppDateTo;
	}



	public Integer getShippingAppDateFrom() {
		return shippingAppDateFrom;
	}



	public void setShippingAppDateFrom(Integer shippingAppDateFrom) {
		this.shippingAppDateFrom = shippingAppDateFrom;
	}



	public Integer getShippingAppDateTo() {
		return shippingAppDateTo;
	}



	public void setShippingAppDateTo(Integer shippingAppDateTo) {
		this.shippingAppDateTo = shippingAppDateTo;
	}
	
}
