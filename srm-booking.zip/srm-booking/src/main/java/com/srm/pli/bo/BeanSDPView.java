package com.srm.pli.bo;

import com.truper.businessEntity.BeanSDP;

public class BeanSDPView extends BeanSDP{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String statusSar;
	private String porcentaje;
	private String ETD;
	private String ETA;
	private String ShippingPort;
	private String POD;
	private String carrier;
	private String vessel;
	private String contenedor;
	private String booking;
	private String folioVista;
	
	private String montoDiario;
	private String montoMaximo;
	private String diasFromETD;


	
	public BeanSDPView(BeanSDP sdp) {
		this.setMontoMax(sdp.getMontoMax());
		this.setMontoTotal(sdp.getMontoTotal());
		this.setFolio(sdp.getFolio());
		this.setFechaIngreso(sdp.getFechaIngreso());
		this.setFolioConsolidado(sdp.getFolioConsolidado());
	}
	
	public BeanSDPView() {
		
	}	
	public String getStatusSar() {
		return statusSar;
	}
	public void setStatusSar(String statusSar) {
		this.statusSar = statusSar;
	}
	public String getPorcentaje() {
		return porcentaje;
	}
	public void setPorcentaje(String porcentaje) {
		this.porcentaje = porcentaje;
	}
	public String getETD() {
		return ETD;
	}
	public void setETD(String eTD) {
		ETD = eTD;
	}
	public String getETA() {
		return ETA;
	}
	public void setETA(String eTA) {
		ETA = eTA;
	}
	public String getShippingPort() {
		return ShippingPort;
	}
	public void setShippingPort(String shippingPort) {
		ShippingPort = shippingPort;
	}
	public String getPOD() {
		return POD;
	}
	public void setPOD(String pOD) {
		POD = pOD;
	}
	public String getCarrier() {
		return carrier;
	}
	public void setCarrier(String carrier) {
		this.carrier = carrier;
	}
	public String getVessel() {
		return vessel;
	}
	public void setVessel(String vessel) {
		this.vessel = vessel;
	}
	public String getContenedor() {
		return contenedor;
	}
	public void setContenedor(String contenedor) {
		this.contenedor = contenedor;
	}
	public String getBooking() {
		return booking;
	}
	public void setBooking(String booking) {
		this.booking = booking;
	}
	public String getFolioVista() {
		return folioVista;
	}
	public void setFolioVista(String folioVista) {
		this.folioVista = folioVista;
	}

	public String getMontoDiario() {
		return montoDiario;
	}

	public void setMontoDiario(String montoDiario) {
		this.montoDiario = montoDiario;
	}

	public String getMontoMaximo() {
		return montoMaximo;
	}

	public void setMontoMaximo(String montoMaximo) {
		this.montoMaximo = montoMaximo;
	}

	public String getDiasFromETD() {
		return diasFromETD;
	}

	public void setDiasFromETD(String diasFromETD) {
		this.diasFromETD = diasFromETD;
	}


	
}
