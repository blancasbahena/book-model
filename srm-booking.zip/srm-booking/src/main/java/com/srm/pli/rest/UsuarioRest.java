package com.srm.pli.rest;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.truper.businessEntity.UserBean;
import com.truper.infra.rs.BaseRS;

@Path("/usuario")
public class UsuarioRest extends BaseRS {

	private static final long serialVersionUID = 6562403563215525616L;
	Gson g = new GsonBuilder().serializeSpecialFloatingPointValues().create();

	@Context
	private HttpServletRequest request;
	
	@GET
	@Path("{usuario}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getUsuario() {
		UserBean user = getUser();
		if (user == null) {
			return buildError_JSONResponse("Error al buscar el usuario.");
		}
		return buildOK_JSONResponse(user);
	}

	
	private UserBean getUser() {
		HttpSession session = request.getSession(false);
		if (session == null)
			return null;
		UserBean usuario = (UserBean) session.getAttribute("usuario");
		return usuario;
	}
	
}
