package com.srm.pli.rest;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.srm.pli.services.ControlPreciosService;
import com.truper.businessEntity.BeanControlPrecios;
import com.truper.businessEntity.BeanMatricesAuditoriaUpdate;
import com.truper.infra.rs.BaseRS;

@Path("/controlPrecios")
public class ControlPreciosServiceRest extends BaseRS {

	private static final long serialVersionUID = 7926631150083183540L;
	private static Gson g = new GsonBuilder().serializeSpecialFloatingPointValues().create();

	@POST
	@Path("/guardar")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response guardar(String guardar) {
		log.info("Llamado a guardar");
		Response r = null;
		try {
			HashSet<BeanControlPrecios> informacion = new HashSet<>();
			setHashSet(guardar, informacion);
			if (informacion.isEmpty()) {
				return buildOK_JSONResponse("La lista recibida est\u00E1 vacia");
			}
			ControlPreciosService.getInstance().procesaInformacionDeTel(informacion);
			r = buildOK_JSONResponse("Informacion procesada con exito");
		} catch (Exception e) {
			log.error("[matrizInsert] Error con datos: [" + guardar + "] " + e.getMessage());
			r = buildError_JSONResponse(e.getMessage());
		}
		return r;
	}
	
	@POST
	@Path("/update")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response update(String update) {
		log.info("Llamado al metodo update");
		Response r = null;
		try {
			ArrayList<BeanMatricesAuditoriaUpdate> lista = new ArrayList<>();
			setArrayList(update, lista);
			if (lista.isEmpty()) {
				return buildOK_JSONResponse("La lista recibida est\u00E1 vacia");
			}
			StringBuffer buf = ControlPreciosService.getInstance().procesaSolicitudTELUpdate(lista);
			r = buildOK_JSONResponse("Informacion procesada con exito: "+(buf != null ? buf.toString() : "" ));
		} catch (Exception e) {
			log.error("[update] Error con datos: [" + update + "] " + e.getMessage());
			r = buildError_JSONResponse(e.getMessage());
		}
		return r;
	}

	@SuppressWarnings("unchecked")
	private static void setHashSet(String origen, HashSet<BeanControlPrecios> c) {
		Type tipo = new TypeToken<HashSet<BeanControlPrecios>>() {
		}.getType();
		c.addAll((Collection<? extends BeanControlPrecios>) g.fromJson(origen, tipo));
	}
	
	@SuppressWarnings("unchecked")
	private static void setArrayList(String origen, ArrayList<BeanMatricesAuditoriaUpdate> c) {
		Type tipo = new TypeToken<ArrayList<BeanMatricesAuditoriaUpdate>>() {
		}.getType();
		c.addAll((Collection<? extends BeanMatricesAuditoriaUpdate>) g.fromJson(origen, tipo));
	}
}