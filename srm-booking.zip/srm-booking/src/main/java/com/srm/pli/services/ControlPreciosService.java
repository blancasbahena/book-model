package com.srm.pli.services;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.srm.pli.dao.MatricesDAO;
import com.truper.businessEntity.BeanControlPrecios;
import com.truper.businessEntity.BeanMatricesAuditoriaUpdate;
import com.truper.utils.string.UtilsString;

public class ControlPreciosService {

	private static final ControlPreciosService instance = new ControlPreciosService();
	private static final Logger LOGGER = LogManager.getRootLogger();
	private static final String SEPARADOR_MATRIZ = ",";
	private static final String MATRIZ_FIRMADA = "3";
	private static final String MATRIZ_REFERENCIAL = "4";

	private ControlPreciosService() {
	}

	public static ControlPreciosService getInstance() {
		return instance;
	}

	public void procesaInformacionDeTel(HashSet<BeanControlPrecios> informacion) {
		try {
			LOGGER.info("[procesaInformacionDeTel] Se procesar\u00E1\n\t"
					+ StringUtils.join(informacion, "\n\t"));
			boolean isConMatriz = isConMatriz(informacion);
			if (isConMatriz) {
				procesaParaMatriz(informacion);
			} else {
				procesaParaAuditoria(informacion);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public boolean procesaParaMatriz(HashSet<BeanControlPrecios> informacion) {
		for (BeanControlPrecios tmp : informacion) {
			MatricesDAO.getInstance().generaRegistroMatriz(tmp);
		}
		return false;
	}

	public boolean procesaParaAuditoria(HashSet<BeanControlPrecios> informacion) {
		System.out.println("ProcesaParaAuditoria");
		AuditoriaService.getInstance().guardaNuevasOrdenes(informacion);
		return false;
	}

	private boolean isConMatriz(HashSet<BeanControlPrecios> informacion) {
		if (informacion == null || informacion.isEmpty())
			return false;
		for (BeanControlPrecios bean : informacion) {
			if (bean == null)
				continue;
			String documentosRequeridos = bean.getDocumentosRequeridos();
			if (UtilsString.isEmptyNullOrUndefined(documentosRequeridos))
				continue;
			String[] split = documentosRequeridos.trim().split(SEPARADOR_MATRIZ);
			List<String> documentos = Arrays.asList(split);
			if (documentos.contains(MATRIZ_FIRMADA) || documentos.contains(MATRIZ_REFERENCIAL)) {
				return true;
			}
		}
		return false;
	}
	
	private boolean isConMatriz(BeanMatricesAuditoriaUpdate informacion) {
		if (informacion == null ) {
			return false;
		}
		
		String documentosRequeridos = informacion.getDocumentosRequeridos();
		if (UtilsString.isEmptyNullOrUndefined(documentosRequeridos)) {
			return false;
		}
		String[] split = documentosRequeridos.trim().split(SEPARADOR_MATRIZ);
		List<String> documentos = Arrays.asList(split);
		if (documentos.contains(MATRIZ_FIRMADA) || documentos.contains(MATRIZ_REFERENCIAL)) {
			return true;
		}
		
		return false;
	}
	
	
	public StringBuffer procesaSolicitudTELUpdate(ArrayList<BeanMatricesAuditoriaUpdate> informacion) {
		StringBuffer buf = new StringBuffer();
		try {
			LOGGER.info("[procesaSolicitudTELUpdate]  Inicia");
			Integer resultado = 0;
			for(BeanMatricesAuditoriaUpdate tmp : informacion) {
				LOGGER.info("[procesaSolicitudTELUpdate] data to:" + tmp.toString());
				boolean isConMatriz = isConMatriz(tmp);
				if (isConMatriz) {
					resultado = MatricesDAO.getInstance().updateFromTELMatrix(tmp.getPo(), tmp.getPosicion(), tmp.getEtd());
					if(resultado == null) {
						return buf.append("Error, PO:").append(tmp.getPo()).append(", pos:").append(tmp.getPosicion()).append("Fail on update.");
					}else {
						buf.append("UPDATE Matriz, PO:").append(tmp.getPo()).append(", pos:").append(tmp.getPosicion()).append(", ");
						buf.append(resultado).append(" rows updated.");
						return buf;
					}
				} else {
					resultado = MatricesDAO.getInstance().updateFromTELAuditoria(tmp.getPo(), tmp.getPosicion(), tmp.getEtd());
					if(resultado == null) {
						return buf.append("Error, PO:").append(tmp.getPo()).append(", pos:").append(tmp.getPosicion()).append("Fail on update.");
					}else {
						buf.append("UPDATE Auditoria, PO:").append(tmp.getPo()).append(", pos:").append(tmp.getPosicion()).append(", ");
						buf.append(resultado).append(" rows updated.");
						return buf;
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			return buf.append(e.getMessage());
		}
		return buf;
	}
	
}
