package com.srm.pli.helper;

import org.apache.commons.lang3.StringEscapeUtils;

import com.srm.pli.bo.SarBO;
import com.srm.pli.utils.FuncionesComunesPLI;
import com.truper.businessEntity.SAR;
import com.truper.businessEntity.SARConsolidadosHistorico;

public class FormatSARConsolHist {
	private Integer folioRaw;
	private String folio;
	private String puertoDescarga;
	private String puertoDescargaNum;
	private String puertoSalida;
	private String puertoSalidaNum;
	private String naviera;
	private Integer navieraNum;
	private String fechaEmbarque;
	private String tipoContenedor;
	private Integer tipoContenedorNum;
	private Integer prioridad;
	private String etd;
	private String etdReal;
	private String barcoSugerido;
	private String viaje;
	private String contenedor;
	private String booking;
	private Integer transporte;
	private String comentarioConsol;
	private String peso;
	private String volumen;
	private String POsEnConsolidado;
	private String usuarioModf;
	private String fechaModf;
	private String proveedorRetraso;
	private String tipoRetraso;
	private String tipoProd;
	private String backOrderPron;
	private String colorPrioridad;
	
	public FormatSARConsolHist(){}

	public FormatSARConsolHist(SARConsolidadosHistorico hist){
		FuncionesComunesPLI.cargaPuertosDestino(false);
		FuncionesComunesPLI.cargaPuertosOrigen(false);
		FuncionesComunesPLI.cargaNavieras(false);
		FuncionesComunesPLI.cargaContenedores(false);
		folioRaw = hist.getFolio();
		folio = "C"+hist.getFolio();
		puertoDescarga = StringEscapeUtils.unescapeJson(FuncionesComunesPLI.mapaPuertosDestino.get(hist.getPuertoDescarga()).getNombre());
		puertoDescargaNum = hist.getPuertoDescarga();
		puertoSalida = FuncionesComunesPLI.mapaPuertosOrigen.get(hist.getPuertoSalida()).getNombre();
		puertoSalidaNum = hist.getPuertoSalida();
		naviera = hist.getNaviera() != null ? FuncionesComunesPLI.mapaNavieras.get(hist.getNaviera()).getNombre() : null;
		navieraNum = hist.getNaviera();
		fechaEmbarque = FuncionesComunesPLI.formateaFechaYYYYMMDD(hist.getFechaEmbarque());
		//status = StringEscapeUtils.escapeHtml(dameLeyendaStatus(ingles));
		tipoContenedor = hist.getTipoContenedor() != null && !"".equals(hist.getTipoContenedor())? FuncionesComunesPLI.mapaContenedores.get(hist.getTipoContenedor()).getNombre() : ""; 
		tipoContenedorNum = hist.getTipoContenedor();
		prioridad = hist.getPrioridad();
//		etd = Inicio.formateaFechaYYYYMMDD(etdPlanner);
		etdReal = FuncionesComunesPLI.formateaFechaYYYYMMDD(hist.getEtdReal());
		barcoSugerido = StringEscapeUtils.escapeHtml3(hist.getBarcoSugerido());
		viaje = StringEscapeUtils.escapeHtml3(hist.getViaje());
		contenedor = StringEscapeUtils.escapeHtml3(hist.getContenedor());
		booking = hist.getBooking();
		transporte = hist.getTransporte();
		comentarioConsol =StringEscapeUtils.escapeHtml3(hist.getComentarioConsol());
		peso = FuncionesComunesPLI.formatea(hist.getPeso());
		volumen = FuncionesComunesPLI.formatea(hist.getVolumen(),2);
		POsEnConsolidado = hist.getPOsEnConsolidado();
		usuarioModf = StringEscapeUtils.escapeHtml3(hist.getUsuarioMof());
		fechaModf = FuncionesComunesPLI.formateaFechaYYYYMMDD(hist.getFechaModficacion());
		proveedorRetraso = hist.getRetrasoProveedor() != null && !"0".equals(hist.getRetrasoProveedor()) ? hist.getRetrasoProveedor() : "N.D";
		String retrasoTipo = "N.D";
		if(hist.getTipoRetraso() == SarBO.SIN_RETRASO ){
			retrasoTipo = "No Delay";
		}else{
			if(hist.getTipoRetraso() == SarBO.RETRASO_PLAN_DE_EMBARQUES ){
				retrasoTipo = "Plan de Embarques";
			}else{
				if(hist.getTipoRetraso() == SarBO.RETRASO_PROVEEDOR ){
					retrasoTipo = "Suppler delay";
				}else{
					retrasoTipo = "Truper delay";
				}
			}
		}
		tipoRetraso =  retrasoTipo ;
		tipoProd = hist.getTipoProducto() != null ? hist.getTipoProducto() : "N.D";
		
		backOrderPron =  hist.getBackorderPronosticadoTot()!= null ? FuncionesComunesPLI.formatea(hist.getBackorderPronosticadoTot().doubleValue(), 2) : "0";
		colorPrioridad = prioridad == 1 ? SAR.COLOR_BLANCO  : (prioridad == 2  ? SAR.COLOR_ROJO : SAR.COLOR_MORADO );
	}

	/**
	 * @return the folioRaw
	 */
	public Integer getFolioRaw() {
		return folioRaw;
	}

	/**
	 * @param folioRaw the folioRaw to set
	 */
	public void setFolioRaw(Integer folioRaw) {
		this.folioRaw = folioRaw;
	}

	/**
	 * @return the folio
	 */
	public String getFolio() {
		return folio;
	}

	/**
	 * @param folio the folio to set
	 */
	public void setFolio(String folio) {
		this.folio = folio;
	}

	/**
	 * @return the puertoDescarga
	 */
	public String getPuertoDescarga() {
		return puertoDescarga;
	}

	/**
	 * @param puertoDescarga the puertoDescarga to set
	 */
	public void setPuertoDescarga(String puertoDescarga) {
		this.puertoDescarga = puertoDescarga;
	}

	/**
	 * @return the puertoDescargaNum
	 */
	public String getPuertoDescargaNum() {
		return puertoDescargaNum;
	}

	/**
	 * @param puertoDescargaNum the puertoDescargaNum to set
	 */
	public void setPuertoDescargaNum(String puertoDescargaNum) {
		this.puertoDescargaNum = puertoDescargaNum;
	}

	/**
	 * @return the puertoSalida
	 */
	public String getPuertoSalida() {
		return puertoSalida;
	}

	/**
	 * @param puertoSalida the puertoSalida to set
	 */
	public void setPuertoSalida(String puertoSalida) {
		this.puertoSalida = puertoSalida;
	}

	/**
	 * @return the puertoSalidaNum
	 */
	public String getPuertoSalidaNum() {
		return puertoSalidaNum;
	}

	/**
	 * @param puertoSalidaNum the puertoSalidaNum to set
	 */
	public void setPuertoSalidaNum(String puertoSalidaNum) {
		this.puertoSalidaNum = puertoSalidaNum;
	}

	/**
	 * @return the naviera
	 */
	public String getNaviera() {
		return naviera;
	}

	/**
	 * @param naviera the naviera to set
	 */
	public void setNaviera(String naviera) {
		this.naviera = naviera;
	}

	/**
	 * @return the navieraNum
	 */
	public Integer getNavieraNum() {
		return navieraNum;
	}

	/**
	 * @param navieraNum the navieraNum to set
	 */
	public void setNavieraNum(Integer navieraNum) {
		this.navieraNum = navieraNum;
	}

	/**
	 * @return the fechaEmbarque
	 */
	public String getFechaEmbarque() {
		return fechaEmbarque;
	}

	/**
	 * @param fechaEmbarque the fechaEmbarque to set
	 */
	public void setFechaEmbarque(String fechaEmbarque) {
		this.fechaEmbarque = fechaEmbarque;
	}

	/**
	 * @return the tipoContenedor
	 */
	public String getTipoContenedor() {
		return tipoContenedor;
	}

	/**
	 * @param tipoContenedor the tipoContenedor to set
	 */
	public void setTipoContenedor(String tipoContenedor) {
		this.tipoContenedor = tipoContenedor;
	}

	/**
	 * @return the tipoContenedorNum
	 */
	public Integer getTipoContenedorNum() {
		return tipoContenedorNum;
	}

	/**
	 * @param tipoContenedorNum the tipoContenedorNum to set
	 */
	public void setTipoContenedorNum(Integer tipoContenedorNum) {
		this.tipoContenedorNum = tipoContenedorNum;
	}

	/**
	 * @return the prioridad
	 */
	public Integer getPrioridad() {
		return prioridad;
	}

	/**
	 * @param prioridad the prioridad to set
	 */
	public void setPrioridad(Integer prioridad) {
		this.prioridad = prioridad;
	}

	/**
	 * @return the etd
	 */
	public String getEtd() {
		return etd;
	}

	/**
	 * @param etd the etd to set
	 */
	public void setEtd(String etd) {
		this.etd = etd;
	}

	/**
	 * @return the etdReal
	 */
	public String getEtdReal() {
		return etdReal;
	}

	/**
	 * @param etdReal the etdReal to set
	 */
	public void setEtdReal(String etdReal) {
		this.etdReal = etdReal;
	}

	/**
	 * @return the barcoSugerido
	 */
	public String getBarcoSugerido() {
		return barcoSugerido;
	}

	/**
	 * @param barcoSugerido the barcoSugerido to set
	 */
	public void setBarcoSugerido(String barcoSugerido) {
		this.barcoSugerido = barcoSugerido;
	}

	/**
	 * @return the viaje
	 */
	public String getViaje() {
		return viaje;
	}

	/**
	 * @param viaje the viaje to set
	 */
	public void setViaje(String viaje) {
		this.viaje = viaje;
	}

	/**
	 * @return the contenedor
	 */
	public String getContenedor() {
		return contenedor;
	}

	/**
	 * @param contenedor the contenedor to set
	 */
	public void setContenedor(String contenedor) {
		this.contenedor = contenedor;
	}

	/**
	 * @return the booking
	 */
	public String getBooking() {
		return booking;
	}

	/**
	 * @param booking the booking to set
	 */
	public void setBooking(String booking) {
		this.booking = booking;
	}

	/**
	 * @return the transporte
	 */
	public Integer getTransporte() {
		return transporte;
	}

	/**
	 * @param transporte the transporte to set
	 */
	public void setTransporte(Integer transporte) {
		this.transporte = transporte;
	}

	/**
	 * @return the comentarioConsol
	 */
	public String getComentarioConsol() {
		return comentarioConsol;
	}

	/**
	 * @param comentarioConsol the comentarioConsol to set
	 */
	public void setComentarioConsol(String comentarioConsol) {
		this.comentarioConsol = comentarioConsol;
	}

	/**
	 * @return the peso
	 */
	public String getPeso() {
		return peso;
	}

	/**
	 * @param peso the peso to set
	 */
	public void setPeso(String peso) {
		this.peso = peso;
	}

	/**
	 * @return the volumen
	 */
	public String getVolumen() {
		return volumen;
	}

	/**
	 * @param volumen the volumen to set
	 */
	public void setVolumen(String volumen) {
		this.volumen = volumen;
	}

	/**
	 * @return the pOsEnConsolidado
	 */
	public String getPOsEnConsolidado() {
		return POsEnConsolidado;
	}

	/**
	 * @param pOsEnConsolidado the pOsEnConsolidado to set
	 */
	public void setPOsEnConsolidado(String pOsEnConsolidado) {
		POsEnConsolidado = pOsEnConsolidado;
	}

	/**
	 * @return the usuarioModf
	 */
	public String getUsuarioModf() {
		return usuarioModf;
	}

	/**
	 * @param usuarioModf the usuarioModf to set
	 */
	public void setUsuarioModf(String usuarioModf) {
		this.usuarioModf = usuarioModf;
	}

	/**
	 * @return the fechaModf
	 */
	public String getFechaModf() {
		return fechaModf;
	}

	/**
	 * @param fechaModf the fechaModf to set
	 */
	public void setFechaModf(String fechaModf) {
		this.fechaModf = fechaModf;
	}

	/**
	 * @return the proveedorRetraso
	 */
	public String getProveedorRetraso() {
		return proveedorRetraso;
	}

	/**
	 * @param proveedorRetraso the proveedorRetraso to set
	 */
	public void setProveedorRetraso(String proveedorRetraso) {
		this.proveedorRetraso = proveedorRetraso;
	}

	/**
	 * @return the tipoRetraso
	 */
	public String getTipoRetraso() {
		return tipoRetraso;
	}

	/**
	 * @param tipoRetraso the tipoRetraso to set
	 */
	public void setTipoRetraso(String tipoRetraso) {
		this.tipoRetraso = tipoRetraso;
	}

	/**
	 * @return the tipoProd
	 */
	public String getTipoProd() {
		return tipoProd;
	}

	/**
	 * @param tipoProd the tipoProd to set
	 */
	public void setTipoProd(String tipoProd) {
		this.tipoProd = tipoProd;
	}

	/**
	 * @return the backOrderPron
	 */
	public String getBackOrderPron() {
		return backOrderPron;
	}

	/**
	 * @param backOrderPron the backOrderPron to set
	 */
	public void setBackOrderPron(String backOrderPron) {
		this.backOrderPron = backOrderPron;
	}

	/**
	 * @return the colorPrioridad
	 */
	public String getColorPrioridad() {
		return colorPrioridad;
	}

	/**
	 * @param colorPrioridad the colorPrioridad to set
	 */
	public void setColorPrioridad(String colorPrioridad) {
		this.colorPrioridad = colorPrioridad;
	}

}
