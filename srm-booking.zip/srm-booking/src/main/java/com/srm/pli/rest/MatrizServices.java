package com.srm.pli.rest;

import java.io.File;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.srm.pli.process.GeneraReportesMatriz;
import com.truper.infra.loggers.BaseLogger;
import com.truper.infra.rs.BaseRS;


@Path("/matrizServices")
public class MatrizServices extends BaseRS{
	
	private static final long serialVersionUID = -3295258570394852215L;
	private static Gson gson = new GsonBuilder()
			.serializeSpecialFloatingPointValues().create();
	
	
	@GET
	@Path("/downloadFile") 
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Produces(MediaType.APPLICATION_OCTET_STREAM) 
	public Response downloadFile(@Context UriInfo ui) { 
		Response r = null; 
		File file = null;
		try {
			MultivaluedMap<String, String> map = ui.getQueryParameters();
			String inicio = map.getFirst("inicio");
			String fin = map.getFirst("fin");
			String tipo = map.getFirst("tipoBusca");
			String po = map.getFirst("po");
			String supplier = map.getFirst("supplier");
			
			
			file = GeneraReportesMatriz.getInstance().generaReportesMatriz(inicio, fin,tipo,po,supplier); 
			r = Response.ok(file, MediaType.APPLICATION_OCTET_STREAM)
					.header("Content-Disposition", "attachment;filename=ejemplo.xls").build();
		} catch (Exception ioE) {
			BaseLogger.BOOKING_LOGGER.error("Error al intentar generar el archivo", ioE); 
			r = buildErrorResponse("Error trying to download File."); 
		}
		file = null;
		return r; 
	} 
	
	
	
	@GET
	@Path("/generaReporte")
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Produces(MediaType.APPLICATION_OCTET_STREAM)
	public Response generaReporte(@Context UriInfo ui) {
		Response r = null;
		MultivaluedMap<String, String> map = ui.getQueryParameters();
		String inicio = map.getFirst("inicio");
		String fin = map.getFirst("fin");
		try {
				File file = new File("C://FormatoMOI.xlsx");
				r = Response.ok(file, MediaType.APPLICATION_OCTET_STREAM)
					      .header("Content-Disposition", "attachment; filename=\"" + "FormatoMOI.xlsx" + "\"" )
					      .build();
			
		} catch (Exception ioE) {
			BaseLogger.BOOKING_LOGGER.error("Error al intentar generar el archivo", ioE);
			r = buildErrorResponse("Error trying to download BL File.");
		}
		return r;
	}
	
}
