package com.srm.pli.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import javax.servlet.ServletException;

import com.srm.pli.bo.SearchParamsSDP;
import com.srm.pli.db.ConexionDB;
import com.truper.businessEntity.BeanSDP;
import com.truper.businessEntity.BeanSDPAcciones;
import com.truper.businessEntity.BeanSDPDetalle;
import com.truper.utils.date.EnumFechas;
import com.truper.utils.date.UtilsFechas;

public class SDP_DAO extends DAO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public static final int STATUS_NUEVO = 0;
	public static final int STATUS_CONDONADOS = 1;
	public static final int STATUS_APLICADOS = 2;
	public static final int STATUS_EN_REVISION = 3;
	public static final int RECARGA_DATOS = 1;
	
	@Override
	public List<?> select(Object o) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean insert(Object o) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean update(Object o) {
		// TODO Auto-generated method stub
		return false;
	}

	public static ArrayList<BeanSDPAcciones> selectSDPAcciones(Date date) throws ServletException {
		ArrayList<BeanSDPAcciones> acciones = new ArrayList<>();
		Connection con = null;
		// Date date = new Date();
		try {
			con = ConexionDB.dameConexion();
			int dateInt = UtilsFechas.setConvierteFechaToInt(date, EnumFechas.FORMATO_YYYYMMDD);
			ResultSet rs = null;
			StringBuffer query = new StringBuffer();
			Statement st = con.createStatement();

			query.append("SELECT folio,fechaAccion,accion ");
			query.append(" FROM CDI_SDP_ACCIONES");
			query.append(" WHERE CONVERT(VARCHAR(8),fechaAccion,112)=").append(dateInt);

			rs = st.executeQuery(query.toString());
			while (rs.next()) {
				BeanSDPAcciones result = new BeanSDPAcciones();
				result.setFolio(rs.getInt("folio"));
				result.setFechaAccion(rs.getDate("fechaAccion"));
				result.setAccion(rs.getString("accion"));
				acciones.add(result);
			}
			rs.close();
			st.close();
			ConexionDB.devuelveConexion(con);

		} catch (Exception sqlE) {
			try {
				BOOKING_LOGGER.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception sqlEx2) {
				BOOKING_LOGGER.error(sqlEx2.getMessage(), sqlEx2);
			}
			throw new ServletException("Error al generar el select de sdp_acciones");
		}
		return acciones;
	}

	
	
	
	public static boolean insertSDPAcciones(List<BeanSDPAcciones> datosInsertar) throws ServletException {
		Connection con = null;
		Statement st = null;
		boolean exito = false;
		try {
			con = ConexionDB.dameConexion();
			st = con.createStatement();
			for (BeanSDPAcciones tmp : datosInsertar) {
				StringBuffer insert = new  StringBuffer();
				insert.append("INSERT INTO cdi_sdp_acciones (folio,fechaaccion,accion) values(");
				insert.append(tmp.getFolio());
				insert.append(",");
				insert.append("GETDATE()");
				insert.append(",");
				insert.append("'").append(tmp.getAccion()).append("')");
				st.addBatch(insert.toString());
			}
			st.executeBatch();
			// exito = st.executeUpdate(insert) == 1;
			st.close();
			ConexionDB.devuelveConexion(con);

		} catch (Exception e) {
			// e.printStackTrace();
			try {
				st.close();
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				BOOKING_LOGGER.error(ex.getMessage(), ex);
			}
			BOOKING_LOGGER.error(e.getMessage(), e);
			throw new ServletException(e);
		}
		return exito;
	}
	
	
	public static ArrayList<BeanSDP> selectSDP(SearchParamsSDP search) throws ServletException {
		ArrayList<BeanSDP> acciones = new ArrayList<>();
		Connection con = null;
		DAOUtils utils = new DAOUtils();
		// Date date = new Date();
		try {
			con = ConexionDB.dameConexion();

			ResultSet rs = null;
			// PreparedStatement pst = null;
			StringBuffer query = new StringBuffer();
			Statement st = con.createStatement();
			
			query.append("SELECT a.folio,a.status,a.montoTotal,a.montoMax,");
			query.append(" a.fechaIngreso,a.recargaDatos,a.folioConsolidado  ");
			query.append(" FROM CDI_SDP a , cdiSAR b ");
			query.append(" WHERE a.folio = b.folio");
			query.append("  AND  EXISTS (SELECT sd.folio FROM cdi_sdp_detalle sd WHERE sd.folio = a.folio ) ");
			
			if(search.getFolio() != null) {
				query.append(" AND a.folio = ").append(search.getFolio());
			}

			if(search.getStatus() != null) {
				query.append(" AND a.status = ").append(search.getStatus());
			}
			
			if(search.getFechaIngresoIni() != null && search.getFechaIngresoFin() != null) {
				query.append(" AND CONVERT(VARCHAR(8),a.fechaIngreso,112)>=").append(search.getFechaIngresoIni());
				query.append( " AND CONVERT(VARCHAR(8),a.fechaIngreso,112)<=").append(search.getFechaIngresoFin());
			}	
			
			if(search.getFolioConsolidado() != null) {
				query.append(" AND a.folioConsolidado = ").append(search.getFolioConsolidado());
			}
			
			if(search.getProveedor() != null) {
				query.append(" AND b.proveedor = '").append(search.getProveedor()).append("' ");
			}
			
			if(search.getPo() != null) {
				query.append(" and a.folio = (select top (1) c.folio from cdisardetalle c where c.folio = a.folio and po = '");
				query.append(search.getPo()).append("') ");
				
			}
			
			
			query.append( " order by fechaIngreso asc ");
			
			
			rs = st.executeQuery(query.toString());
			while (rs.next()) {
				BeanSDP result = new BeanSDP();
				result.setFolio(rs.getInt("folio"));
				result.setStatus(rs.getInt("status"));
				result.setMontoTotal(rs.getDouble("montoTotal"));
				result.setMontoMax(rs.getDouble("montoMax"));
				result.setFechaIngreso(rs.getDate("fechaIngreso"));
				result.setRecargaDatos(rs.getBoolean("recargaDatos"));
				result.setFolioConsolidado(rs.getInt("folioConsolidado"));
				acciones.add(result);
			}
			rs.close();
			st.close();
			// pst.close();
			ConexionDB.devuelveConexion(con);

		} catch (Exception sqlE) {
			try {
				BOOKING_LOGGER.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception sqlEx2) {
				BOOKING_LOGGER.error(sqlEx2.getMessage(), sqlEx2);
			}
			throw new ServletException("Error al generar el select de selectSDP: "+sqlE.getMessage());
		}
		return acciones;
	}
	
	
	
	public static ArrayList<BeanSDP> selectSDPPendienes() throws ServletException {
		ArrayList<BeanSDP> acciones = new ArrayList<>();
		Connection con = null;
//		DAOUtils utils = new DAOUtils();
		// Date date = new Date();
		try {
			con = ConexionDB.dameConexion();

			ResultSet rs = null;
			// PreparedStatement pst = null;
			StringBuffer query = new StringBuffer();
			Statement st = con.createStatement();
			
			query.append("SELECT folio,status,montoTotal,montoMax,");
			query.append(" fechaIngreso,recargaDatos,folioConsolidado  ");
			query.append(" FROM CDI_SDP");
			query.append(" WHERE recargaDatos = 1");
			
			rs = st.executeQuery(query.toString());
			while (rs.next()) {
				BeanSDP result = new BeanSDP();
				result.setFolio(rs.getInt("folio"));
				result.setStatus(rs.getInt("status"));
				result.setMontoTotal(rs.getDouble("montoTotal"));
				result.setMontoMax(rs.getDouble("montoMax"));
				result.setFechaIngreso(rs.getDate("fechaIngreso"));
				result.setRecargaDatos(rs.getBoolean("recargaDatos"));
				result.setFolioConsolidado(rs.getInt("folioConsolidado"));
				acciones.add(result);
			}
			rs.close();
			st.close();
			// pst.close();
			ConexionDB.devuelveConexion(con);

		} catch (Exception sqlE) {
			try {
				BOOKING_LOGGER.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception sqlEx2) {
				BOOKING_LOGGER.error(sqlEx2.getMessage(), sqlEx2);
			}
			throw new ServletException("Error al generar el select de selectSDP: "+sqlE.getMessage());
		}
		return acciones;
	}
	
	
	
	public static boolean actualizaTablaSDP(BeanSDP sdp) throws ServletException {		
		Connection con = null;
		PreparedStatement ps = null;			
		DAOUtils utilDao = new DAOUtils();
		
		StringBuilder sql = new StringBuilder();
		sql.append(" MERGE cdi_SDP as [target]  ");
		sql.append(" USING (SELECT ?  folio  ");
		sql.append("              , ? status ");
		sql.append("              , ? folioconsolidado) AS [source]  ");
		sql.append(" ON [target].folio = [source].folio  ");
		sql.append(" WHEN matched THEN ");
		sql.append(" UPDATE SET [target].status = [source].status  ");
		sql.append(" , [target].recargadatos = ?  ");
		sql.append("  , [target].folioconsolidado = [source].folioconsolidado  ");
		sql.append(" WHEN NOT matched THEN  ");
		sql.append(" INSERT (folio  ");
		sql.append(" , status ");
		sql.append(" , fechaIngreso ");
		sql.append(" , recargadatos ");
		sql.append("  , folioconsolidado)  ");
		sql.append(" VALUES ( [source].folio ");
		sql.append("  , ? ");
		sql.append(" , GETDATE()  ");
		sql.append(" , ?  ");
		sql.append(" , [source].folioconsolidado); ");
				
		boolean exito = false;

		try {
			con = ConexionDB.dameConexion();
			
			ps = con.prepareStatement(sql.toString());
			int cont = 1;
			ps.setInt(cont++, sdp.getFolio());			
			ps.setInt(cont++, STATUS_NUEVO);
//			ps.setInt(cont++, sdp.getFolioConsolidado() );
			utilDao.ajustaParametro(cont++, ps, sdp.getFolioConsolidado(), Integer.class);
			ps.setInt(cont++, RECARGA_DATOS);
			ps.setInt(cont++, STATUS_NUEVO);
			ps.setInt(cont++, RECARGA_DATOS);
						
			exito = ps.executeUpdate() > 0;
			ps.close();
			ConexionDB.devuelveConexion(con);
		} catch (Exception e) {
			e.printStackTrace();
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				BOOKING_LOGGER.error("[insertaReferenceNumber] Error "+ex.getMessage(), ex);
			}
			BOOKING_LOGGER.error("[insertaReferenceNumber] Error "+e.getMessage(), e);
			throw new ServletException(e);
		} 

		return exito;
	}
	
	
	public static boolean insertSDPDetalle(List<BeanSDPDetalle> datosInsertar) throws ServletException {
		Connection con = null;
		Statement st = null;
		
		boolean exito = false;

		try {
			con = ConexionDB.dameConexion();
			st = con.createStatement();
			for (BeanSDPDetalle tmp : datosInsertar) {
				StringBuffer insert = new  StringBuffer(); 
				
				insert.append("INSERT INTO cdi_sdp_detalle (folio,po,pos,cantidad,validar,precio,");
				insert.append(" montoMax,monto,codigo,fechaProforma) values( "); 
				insert.append(tmp.getFolio());
				insert.append(",");
				insert.append("'").append(tmp.getPo()).append("'");
				insert.append(",");
				insert.append(tmp.getPosicion());
				insert.append(",");
				insert.append(tmp.getCantidad());
				insert.append(",");
				insert.append(tmp.isValidar() ? "1" : "0");
				insert.append(",");
				insert.append(tmp.getPrecio());
				insert.append(",");
				insert.append(tmp.getMontoMax());
				insert.append(",");
				insert.append(tmp.getMonto());
				insert.append(",");
				insert.append(tmp.getCodigo());
				insert.append(",");
				insert.append(tmp.getFechaProforma());
				insert.append(")");
				st.addBatch(insert.toString());
				BOOKING_LOGGER.info("Inserto dato de SDP:"+insert);
			}
			st.executeBatch();
			st.close();
			ConexionDB.devuelveConexion(con);
			BOOKING_LOGGER.info("Inserto dato de SDP batch: ok");
		} catch (Exception e) {
			// e.printStackTrace();
			try {
				st.close();
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				BOOKING_LOGGER.error(ex.getMessage(), ex);
			}
			BOOKING_LOGGER.error(e.getMessage(), e);
			throw new ServletException(e);
		}
		return exito;
	}
	
	
	public static boolean deleteDetallesSDP(int folio ) throws ServletException {
		Connection con = null;
		boolean resultado = false;
		try {
			con = ConexionDB.dameConexion();
			StringBuffer query = new StringBuffer();
			Statement st = con.createStatement();

			query.append("DELETE FROM  CDI_SDP_DETALLE ");			
			query.append(" WHERE folio = ").append(folio);

			resultado = st.executeUpdate(query.toString()) > 0;
			
			st.close();
			// pst.close();
			ConexionDB.devuelveConexion(con);

		} catch (Exception sqlE) {
			try {
				BOOKING_LOGGER.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception sqlEx2) {
				BOOKING_LOGGER.error(sqlEx2.getMessage(), sqlEx2);
			}
			throw new ServletException("Error al generar el select de sdp_acciones");
		}
		return resultado;
	}
	
	
	
	public static ArrayList<BeanSDPDetalle> selectSDPDetalle(int folio) throws ServletException {
		ArrayList<BeanSDPDetalle> acciones = new ArrayList<>();
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();

			ResultSet rs = null;
			StringBuffer query = new StringBuffer();
			Statement st = con.createStatement();
			
			query.append("SELECT   folio, po, pos, cantidad, validar, ");
			query.append(" precio, montoMax, monto, codigo,fechaProforma ");
			query.append(" FROM  cdi_SDP_Detalle ");
			query.append(" WHERE folio = ").append(folio);
				
			rs = st.executeQuery(query.toString());
			while (rs.next()) {
				BeanSDPDetalle result = new BeanSDPDetalle();
				result.setFolio(rs.getInt("folio"));
				result.setPo(rs.getString("po"));
				result.setPosicion(rs.getInt("pos"));
				result.setCantidad(rs.getInt("cantidad"));
				result.setValidar(rs.getBoolean("validar"));
				result.setPrecio(rs.getDouble("precio"));
				result.setMontoMax(rs.getDouble("montoMax"));
				result.setMonto(rs.getDouble("monto"));
				result.setCodigo(rs.getString("codigo"));
				result.setFechaProforma(rs.getInt("fechaProforma"));
				
				acciones.add(result);
			}
			rs.close();
			st.close();
			ConexionDB.devuelveConexion(con);

		} catch (Exception sqlE) {
			try {
				BOOKING_LOGGER.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception sqlEx2) {
				BOOKING_LOGGER.error(sqlEx2.getMessage(), sqlEx2);
			}
			throw new ServletException("Error al generar el select de selectSDPDetalle: "+sqlE.getMessage());
		}
		return acciones;
	}
	
	
	
	public static boolean updateSDP(BeanSDP bean) throws ServletException {
		Connection con = null;
		PreparedStatement pst = null;	
		StringBuffer query = new StringBuffer();
		DAOUtils utilDao = new DAOUtils();
		
		query.append("UPDATE CDI_SDP SET  ");
		query.append(" montoTotal = ?, montoMax = ?,");
		query.append(" recargaDatos = ?, folioConsolidado= ?");		
		query.append(" WHERE folio = ?");
		
		boolean exito = false;			
		
		try {
			con = ConexionDB.dameConexion();
			pst = con.prepareStatement(query.toString());
			int cont = 1;
			pst.setDouble(cont++,bean.getMontoTotal() );
			pst.setDouble(cont++,bean.getMontoMax() );
			utilDao.ajustaParametro(cont++, pst, bean.isRecargaDatos(), Boolean.class);
			utilDao.ajustaParametro(cont++, pst, bean.getFolioConsolidado(), Integer.class);
			utilDao.ajustaParametro(cont++, pst, bean.getFolio(), Integer.class);

			
			exito = pst.executeUpdate() > 0;

			ConexionDB.devuelveConexion(con);
		
		} catch (Exception e) {
//			e.printStackTrace();
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				BOOKING_LOGGER.error("[updateSDP] Error: "+ex.getMessage(), ex);
			}
			BOOKING_LOGGER.error("[updateSDP] Error: "+e.getMessage(), e);
			throw new ServletException(e);
		}

		return exito;
	}
	
	
	public static boolean updateSDPCambiaStatus(BeanSDP bean) throws ServletException {
		Connection con = null;
		PreparedStatement pst = null;	
		StringBuffer query = new StringBuffer();
		DAOUtils utilDao = new DAOUtils();
		
		query.append("UPDATE CDI_SDP SET  status = ? , montoTotal = ?,etd=?");
		query.append(" WHERE folio = ?");
		
		boolean exito = false;			
		
		try {
			con = ConexionDB.dameConexion();
			pst = con.prepareStatement(query.toString());
			int cont = 1;
			
			utilDao.ajustaParametro(cont++, pst, bean.getStatus(), Integer.class);
//			utilDao.ajustaParametro(cont++, pst, bean.getMontoTotal(), Double.class);
			pst.setDouble(cont++,bean.getMontoTotal() );
			utilDao.ajustaParametro(cont++, pst, bean.getEtdNoFormato(), Integer.class);
			utilDao.ajustaParametro(cont++, pst, bean.getFolio(), Integer.class);
			
			exito = pst.executeUpdate() > 0;

			ConexionDB.devuelveConexion(con);
		
		} catch (Exception e) {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				BOOKING_LOGGER.error("[updateSDPCambiaStatus] Error: "+ex.getMessage(), ex);
			}
			BOOKING_LOGGER.error("[updateSDPCambiaStatus] Error: "+e.getMessage(), e);
			throw new ServletException(e);
		}

		return exito;
	}
	
	
	public static void main(String[] args) {
		System.out.println("ini");
		GregorianCalendar gc = new GregorianCalendar();
		System.out.println("********" + gc.getTimeInMillis() / 1000);
		// try {
		// //dameHistoricoRevisionesSAR(120);
		// CdiBloqueosBean blo = new CdiBloqueosBean();
		// blo.setDato("12345");
		// blo.setFechaBloqueo(20150202);
		// //blo.setFechaDesBloqueo(201346);
		// blo.setStatus(true);
		// blo.setTipo("SAR");
		// blo.setUsuario("yo");
		//
		// //insertaCDIBloqueos(blo);
		// dameBloqueos();
		// } catch (SQLException e) {
		// BOOKING_LOGGER.error(e.getMessage(),e);
		// } catch (ClassNotFoundException e) {
		// BOOKING_LOGGER.error(e.getMessage(),e);
		// }

		long tiempoMil = 1519067314561L;
		Date d = new Date(tiempoMil);
		System.out.println(new SimpleDateFormat("yyyyMMdd HH:mm:ss").format(d));

		System.out.println("fin");
	}

}
