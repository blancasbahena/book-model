package com.srm.pli.rest;

import java.util.List;
import java.util.Map.Entry;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.json.JSONArray;
import org.json.JSONObject;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.srm.pli.bo.BeanTSR;
import com.srm.pli.bo.HistoryLogBean;
import com.srm.pli.bo.SarBO;
import com.srm.pli.bo.SearchParamsSARs;
import com.srm.pli.constants.DataConstants;
import com.srm.pli.dao.SAR_CDI_DAO;
import com.srm.pli.dao.TroubleShootingDAO;
import com.srm.pli.enums.HistoryLogAction;
import com.srm.pli.helper.HistoryLogHelper;
import com.srm.pli.services.CorreosTSRService;
import com.srm.pli.services.impl.HistoryLogServiceImpl;
import com.srm.pli.utils.FuncionesComunesPLI;
import com.srm.pli.utils.Utilerias;
import com.truper.businessEntity.ImportacionesProveedoresBean;
import com.truper.businessEntity.Naviera;
import com.truper.businessEntity.UserBean;
import com.truper.infra.rs.BaseRS;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Path("/tsrServices")
public class CDITSRServices extends BaseRS{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 5510274518833919606L;

	private static Gson gson = new GsonBuilder()
			.serializeSpecialFloatingPointValues().create();
	@Context
	private HttpServletRequest request;
	
	@POST
	@Path("/nuevos")
	@Produces(MediaType.APPLICATION_JSON)
	public Response registrarTSR(
			@FormParam("folio") Integer folio,
			@FormParam("refNumber") String refNumber,
			@FormParam("carrier") Integer carrier,
			@FormParam("carrierName") String carrierName,
			@FormParam("issueDesc") String issueDesc) {
		
		Response r = null;
		JSONObject jsonRestul = new JSONObject();
		
		try {
			
			log.info("Registrar TSR para folio " +folio);
			BeanTSR beanRegistro = TroubleShootingDAO.dameDatosReferenciaCDI_TSR(folio);
			
			if(beanRegistro == null) {
				beanRegistro = new BeanTSR();
			}
			
			beanRegistro.setFolio(folio);
			beanRegistro.setReferenceNumber(refNumber);
			beanRegistro.setCarrier(carrier);
			beanRegistro.setCarrierContactName(carrierName);
			beanRegistro.setIssueDescription(issueDesc);
			
			BeanTSR filtro = new BeanTSR();
			filtro.setFolio(folio);
			
			List<BeanTSR> registrosTSR = TroubleShootingDAO.dameTSRRegistros(filtro, true);
			if(registrosTSR != null && registrosTSR.size() > 0) {

				jsonRestul.put("errorCode", 1);
				jsonRestul.put("mensaje", "A TSR has been already created today");
				
			} else {
				boolean resultadoInsert = TroubleShootingDAO.agregarRegistroTSR(beanRegistro, getUser().getUserName());
			
				if(resultadoInsert) {
					//Guarda SAR History Log
					String username = HistoryLogHelper.getInstance().getUserName(getUser());	
					HistoryLogBean historyLogBean = HistoryLogBean.builder()
							.tipoAccion(HistoryLogAction.SAR_WITH_TSR.id())
							.folio(folio)
							.sarType(DataConstants.SAR_TYPE)
							.comentarios(DataConstants.SAR_COMMENTS_HISTORY_LOG)
							.username(username).build();

					log.info("Datos a insertar en el history log: Accion:{}, username: {} ", historyLogBean.getTipoAccion(), historyLogBean.getUsername());
					HistoryLogServiceImpl.getInstance().saveHistoryLogComments(historyLogBean);
				}
				
				ImportacionesProveedoresBean proveedor = FuncionesComunesPLI.getProveedor(getUser().getUserName());
				CorreosTSRService.getInstance().mailCreacionTSR(beanRegistro, proveedor.getEmail());
				
				jsonRestul.put("errorCode", resultadoInsert ? 0 : 1);
				jsonRestul.put("mensaje", "OK");
				
			}
			
		}catch(Exception e) {
			jsonRestul.put("errorCode", 1);

			jsonRestul.put("mensaje", "Error: "+e.getMessage());
			r = buildError_JSONResponse(e.getMessage());  
			return r;
		}
		
		r = buildOKResponse(jsonRestul.toString());
		return r;
	}
	
	@GET
	@Path("/navieras")
	@Produces(MediaType.APPLICATION_JSON)
	public Response obtenerCatalogoNavieras() {
		
		Response r = null;
		JSONArray jsonNavieras = new JSONArray();
		
		for (Entry<Integer, Naviera> entry : FuncionesComunesPLI.mapaNavieras.entrySet()) {
			Naviera nav = entry.getValue();
			jsonNavieras.put(gson.toJson(nav));
		}
		
		r = buildOKResponse(jsonNavieras.toString());
		return r;
	}
	
	@POST
	@Path("/finalizados")
	@Produces(MediaType.APPLICATION_JSON)
	public Response procesarTSR(
			@FormParam("folio") Integer folio,
			@FormParam("approval") Boolean approval,
			@FormParam("comments") String comments) {

		Response r = null;
		JSONObject jsonRestul = new JSONObject();
		
		try {
			
			log.info("Cerrar TSR para folio " +folio +" - " +(approval ? "Aprobado" : "Rechazado"));
			
			boolean resultadoInsert = TroubleShootingDAO.cerrarRegistroTSR(
					folio, approval, comments, getUser().getUserName());
		
			//Guarda SAR History Log
			FuncionesComunesPLI.guardaSARHistoryLog(HistoryLogAction.TSR_CLOSED.id(), folio, getUser().getUserName(), null, "F", comments);
		
			SearchParamsSARs params = new SearchParamsSARs();
			params.setFolio(folio);
			List<SarBO> folios = SAR_CDI_DAO.buscaSARs(params);
			SarBO folioData = folios.get(0);
			
			ImportacionesProveedoresBean proveedor = FuncionesComunesPLI.getProveedor(folioData.getProveedor());
			String toMailRespuesta = proveedor.getEmail();
			
			CorreosTSRService.getInstance().mailCierreTSR(folio, approval, comments, toMailRespuesta);
			
			
			
			jsonRestul.put("errorCode", resultadoInsert ? 0 : 1);
			jsonRestul.put("mensaje", "OK");
			
		}catch(Exception e) {
			jsonRestul.put("errorCode", 1);

			jsonRestul.put("mensaje", "Error: "+e.getMessage());
			r = buildError_JSONResponse(e.getMessage());  
			return r;
		}
		
		r = buildOKResponse(jsonRestul.toString());
		return r;
	}

	@POST
	@Path("/tsrs/{folio}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response obtenerInfoTSR(@PathParam("folio") Integer folio) {
		
		Response r = null;
		BeanTSR filtro = new BeanTSR();
		filtro.setFolio(folio);
		
		try {
			
			List<BeanTSR> registrosTSR = TroubleShootingDAO.dameTSRRegistros(filtro, false);
			BeanTSR tsr = registrosTSR.get(0);
			String jsonTSR = gson.toJson(tsr);
			JsonParser parser = new JsonParser();
			JsonObject jsonObject = parser.parse(jsonTSR).getAsJsonObject();
			
			Naviera naviera = FuncionesComunesPLI.mapaNavieras.get(tsr.getCarrier());
			jsonObject.addProperty("nombreNaviera", naviera != null ? naviera.getNombre() : "");
			String fechaFormat = "";
			
			if(tsr.getETD() != null && tsr.getETD() > 0) {
				fechaFormat = Utilerias.fechaInt2Jquery(tsr.getETD());
				
			}
			jsonObject.addProperty("etdFormat", fechaFormat);
			r = buildOKResponse(jsonObject.toString());
			
		} catch (Exception e) {
			
			JSONObject jsonRestul = new JSONObject();
			jsonRestul .put("errorCode", 1);
			jsonRestul.put("mensaje", "Error: "+e.getMessage());
			r = buildError_JSONResponse(e.getMessage());  
			
			log.info("Error al consultar TSR de folio: " +folio);
		}
		
		
		return r;
	}

	private UserBean getUser() {
		HttpSession session = request.getSession(false);
		if (session == null)
			return null;
		UserBean usuario = (UserBean) session.getAttribute("usuario");
		return usuario;
	}
	
}
