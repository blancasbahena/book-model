package com.srm.pli.bo;

public class ReporteCambiosETDBooking {
	private String folio;
	private String sarType;
	private String folioCompleto;
	private String proveedor;
	private String nombreProveedor;
	private String pos;
	private String planner;
	private String etd;
	private String etdAnterior;
	private String daysInBooking;
	private String shippingApprovalDate;
	private String week;
	private String poStatus;
	private String minimumIDA;
	private String forecastedBO;
	private String container;
	private String booking;
	private String carrier;
	
	public String getFolio() {
		return folio;
	}
	public String getSarType() {
		return sarType;
	}
	public void setSarType(String sarType) {
		this.sarType = sarType;
	}
	public String getFolioCompleto() {
		return folioCompleto;
	}
	public void setFolioCompleto(String folioCompleto) {
		this.folioCompleto = folioCompleto;
	}
	public void setFolio(String folio) {
		this.folio = folio;
	}
	public String getProveedor() {
		return proveedor;
	}
	public void setProveedor(String proveedor) {
		this.proveedor = proveedor;
	}
	public String getNombreProveedor() {
		return nombreProveedor;
	}
	public void setNombreProveedor(String nombreProveedor) {
		this.nombreProveedor = nombreProveedor;
	}
	public String getPos() {
		return pos;
	}
	public void setPos(String pos) {
		this.pos = pos;
	}
	public String getPlanner() {
		return planner;
	}
	public void setPlanner(String planner) {
		this.planner = planner;
	}
	public String getEtd() {
		return etd;
	}
	public void setEtd(String etd) {
		this.etd = etd;
	}
	public String getEtdAnterior() {
		return etdAnterior;
	}
	public void setEtdAnterior(String etdAnterior) {
		this.etdAnterior = etdAnterior;
	}
	public String getDaysInBooking() {
		return daysInBooking;
	}
	public void setDaysInBooking(String daysInBooking) {
		this.daysInBooking = daysInBooking;
	}
	public String getShippingApprovalDate() {
		return shippingApprovalDate;
	}
	public void setShippingApprovalDate(String shippingApprovalDate) {
		this.shippingApprovalDate = shippingApprovalDate;
	}
	public String getWeek() {
		return week;
	}
	public void setWeek(String week) {
		this.week = week;
	}
	public String getPoStatus() {
		return poStatus;
	}
	public void setPoStatus(String poStatus) {
		this.poStatus = poStatus;
	}
	public String getMinimumIDA() {
		return minimumIDA;
	}
	public void setMinimumIDA(String minimumIDA) {
		this.minimumIDA = minimumIDA;
	}
	public String getForecastedBO() {
		return forecastedBO;
	}
	public void setForecastedBO(String forecastedBO) {
		this.forecastedBO = forecastedBO;
	}
	public String getContainer() {
		return container;
	}
	public void setContainer(String container) {
		this.container = container;
	}
	public String getBooking() {
		return booking;
	}
	public void setBooking(String booking) {
		this.booking = booking;
	}
	public String getCarrier() {
		return carrier;
	}
	public void setCarrier(String carrier) {
		this.carrier = carrier;
	}
}
