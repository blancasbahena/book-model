package com.srm.pli.rest;

import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;
import javax.ws.rs.core.StreamingOutput;
import javax.ws.rs.core.UriInfo;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.srm.pli.dao.SAR_CDI_DAO;
import com.srm.pli.helper.FormatSeguimientoPOsSinSAR;
import com.srm.pli.services.impl.SeguimientoPOsSinSARServiceImpl;
import com.srm.pli.services.impl.SeguimientoSARsSinContenedorServiceImpl;
import com.sun.jersey.core.header.FormDataContentDisposition;
import com.sun.jersey.multipart.FormDataParam;
import com.truper.businessEntity.SeguimientoPOsSinSARBean;
import com.truper.businessEntity.UserBean;
import com.truper.businessEntity.UserProfileBean;
import com.truper.helper.jr.JasperServices;
import com.truper.infra.loggers.BaseLogger;
import com.truper.infra.rs.BaseRS;

import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

@Path("/shipmentsWithBO")
public class ShipmentsWithBORestService extends BaseRS{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -3295258570394852215L;
	private static Gson gson = new GsonBuilder()
			.serializeSpecialFloatingPointValues().create();
	 
	@POST
	@Path("/uploadFile")
	@Consumes(MediaType.MULTIPART_FORM_DATA)
	public Response uploadFile(
			@FormDataParam("file") InputStream uploadedInputStream,  
            @FormDataParam("file") FormDataContentDisposition fileDetail,
            @FormDataParam("user") String user,
            @FormDataParam("tipoFile") String tipo) {
		Response r = null;
		UserBean usuario = new UserBean();
		usuario.setUserName(user);
		try {
			List<UserBean> lstUsrs = SAR_CDI_DAO.dameUsuarios(usuario);
			if (lstUsrs != null && !lstUsrs.isEmpty()) {
				usuario = lstUsrs.get(0);
				List<UserProfileBean> lstProfiles = SAR_CDI_DAO.consultaPerfilUsuario(usuario);
				if (lstProfiles != null && !lstProfiles.isEmpty()) {
					UserProfileBean perfil = lstProfiles.get(0);
					if (!perfil.isSegPOsSinSARUpload()) {
						BaseLogger.REST_LOGGER.info("["+Response.Status.UNAUTHORIZED+"] - Insufficient privileges.");
						return Response.status(Response.Status.UNAUTHORIZED).entity("Insufficient privileges.").build();
					}
				}
			}
		} catch (ServletException e) {
			BaseLogger.BOOKING_LOGGER.error(e.getMessage(), e);
		}
		
		if (uploadedInputStream == null || fileDetail == null) {
			BaseLogger.REST_LOGGER.info("["+Response.Status.BAD_REQUEST+"] - Invalid form data.");
			return Response.status(Response.Status.BAD_REQUEST).entity("Invalid form data.").build();
		}
		
		String fileName = fileDetail.getFileName();
		
		if(!fileName.endsWith(".xls")) {
			String output = "The file " + fileName + " must be .XLS (Excel 97-2003).";
			return buildErrorResponse(output);
		}
		
		boolean uploaded = false;
		
		if ("PO".equals(tipo)) {
			SeguimientoPOsSinSARServiceImpl segPOsSinSAR = new SeguimientoPOsSinSARServiceImpl();
			uploaded = segPOsSinSAR.uploadFile(uploadedInputStream, fileName, user);
		} else if ("SAR".equals(tipo)) {
			SeguimientoSARsSinContenedorServiceImpl segSARsSinContenedor = new SeguimientoSARsSinContenedorServiceImpl();
			uploaded = segSARsSinContenedor.uploadFile(uploadedInputStream, fileName, user);
		} else {
			BaseLogger.REST_LOGGER.info("["+Response.Status.BAD_REQUEST+"] - Invalid type.");
			return Response.status(Response.Status.BAD_REQUEST).entity("Invalid type.").build();
		}
		
		if (uploaded) {
			String output = "File " + fileName + " was successfully uploaded.";
			r = buildOKResponse(output);
		} else {
			String output = "Error while trying to upload the file " + fileName + ".";
			r = buildErrorResponse(output);
		}
		
		return r;
	}
	
	@GET
	@Path("/POsSinSAR")
	@Produces(MediaType.APPLICATION_JSON)
	public Response damePOsSinSAR(@Context UriInfo ui) {
		Response r = null;
		MultivaluedMap<String, String> map = ui.getQueryParameters();
		String user = map.getFirst("user");
		String po = map.getFirst("po");
		String supplier = map.getFirst("supplier");
		String openClosed = map.getFirst("openClosed");
		String from = map.getFirst("from");
		String to = map.getFirst("to");
		
		SeguimientoPOsSinSARBean bean = new SeguimientoPOsSinSARBean();
		bean.setModificationUser(user);
		bean.setPo(po);
		bean.setSupplier(supplier);
		from = from.replaceAll("-", "");
		to = to.replaceAll("-", "");
		int iFrom = Integer.parseInt(from);
		int iTo = Integer.valueOf(to) + 1;
		bean.setFrom(iFrom * 100);
		bean.setTo(iTo * 100);
		
		SeguimientoPOsSinSARServiceImpl segPOsSinSAR = new SeguimientoPOsSinSARServiceImpl();
		List<SeguimientoPOsSinSARBean> lstPOsSinSAR = segPOsSinSAR.consultaPOsSinSAR(bean);
		List<FormatSeguimientoPOsSinSAR> lstFmtPOsSinSAR = new ArrayList<FormatSeguimientoPOsSinSAR>();
		for (SeguimientoPOsSinSARBean tmp : lstPOsSinSAR) {
			boolean verSoloAbiertos = "open".equals(openClosed) && tmp.getStatus() != null && (tmp.getStatus() == 1 || tmp.getStatus() == 2);
			boolean verSoloCerrados = "closed".equals(openClosed) && (tmp.getStatus() == null || tmp.getStatus() == -1 || tmp.getStatus() == 3);
			if (verSoloAbiertos || verSoloCerrados) {
				continue;
			}
			FormatSeguimientoPOsSinSAR format = new FormatSeguimientoPOsSinSAR(tmp);
			lstFmtPOsSinSAR.add(format);
		}
		
		String jsonResult = gson.toJson(lstFmtPOsSinSAR, new TypeToken<ArrayList<FormatSeguimientoPOsSinSAR>>(){}.getType());
		r = buildOK_JSONResponse(jsonResult);
		return r;
	}
	
	@GET
	@Path("/downloadFilePOsSinSAR")
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Produces(MediaType.APPLICATION_OCTET_STREAM)
	public Response downloadPOsSinSAR(@Context UriInfo ui) {
		Response r = null;
		MultivaluedMap<String, String> map = ui.getQueryParameters();
		String user = map.getFirst("user");
		String po = map.getFirst("po");
		String supplier = map.getFirst("supplier");
		String openClosed = map.getFirst("openClosed");
		String from = map.getFirst("from");
		String to = map.getFirst("to");
		
		SeguimientoPOsSinSARBean bean = new SeguimientoPOsSinSARBean();
		bean.setModificationUser(user);
		bean.setPo(po);
		bean.setSupplier(supplier);
		from = from.replaceAll("-", "");
		to = to.replaceAll("-", "");
		int iFrom = Integer.parseInt(from);
		int iTo = Integer.valueOf(to) + 1;
		bean.setFrom(iFrom * 100);
		bean.setTo(iTo * 100);
		
		SeguimientoPOsSinSARServiceImpl segPOsSinSAR = new SeguimientoPOsSinSARServiceImpl();
		List<SeguimientoPOsSinSARBean> lstPOsSinSAR = segPOsSinSAR.consultaPOsSinSAR(bean);
		List<FormatSeguimientoPOsSinSAR> lstFmtPOsSinSAR = new ArrayList<FormatSeguimientoPOsSinSAR>();
		for (SeguimientoPOsSinSARBean tmp : lstPOsSinSAR) {
			boolean verSoloAbiertos = "open".equals(openClosed) && tmp.getStatus() != null && (tmp.getStatus() == 1 || tmp.getStatus() == 2);
			boolean verSoloCerrados = "closed".equals(openClosed) && (tmp.getStatus() == null || tmp.getStatus() == -1 || tmp.getStatus() == 3);
			if (verSoloAbiertos || verSoloCerrados) {
				continue;
			}
			FormatSeguimientoPOsSinSAR format = new FormatSeguimientoPOsSinSAR(tmp);
			lstFmtPOsSinSAR.add(format);
		}
		
		try {
			InputStream isPOsSinSARReport = getClass().getClassLoader().getResourceAsStream("posWithoutSARReport.jrxml");
	        JRDataSource jrdatasource = new JRBeanCollectionDataSource(lstFmtPOsSinSAR);
	        JasperServices js = new JasperServices(isPOsSinSARReport, jrdatasource, null);
	        
	        final byte[] bytes = js.getReportByteArray(JasperServices.XLS_TYPE);
	        
			StreamingOutput fileStream =  new StreamingOutput() {
				@Override
				public void write(OutputStream arg0) throws WebApplicationException {
		            BufferedOutputStream bus = new BufferedOutputStream(arg0);
		            try {
		                bus.write(bytes);
		            } catch (Exception e) {
		            	throw new WebApplicationException(e, buildErrorResponse());
		            }
		        }
			};
	        
	        ResponseBuilder response = Response.ok(fileStream, MediaType.APPLICATION_OCTET_STREAM);
			response.header("Content-Disposition", "attachment; filename=POsWithoutSARReport.xls");
			response.header("Content-Type","application/vnd.ms-excel");
			response.header("Content-Length", bytes.length);
			r = response.build();
		} catch (JRException jrE) {
			BaseLogger.BOOKING_LOGGER.error("Error al intentar generar el reporte con JASPER", jrE);
			r = buildErrorResponse();
		} catch (IOException ioE) {
			BaseLogger.BOOKING_LOGGER.error("Error al intentar generar el archivo", ioE);
			r = buildErrorResponse();
		}
		
		return r;
	}
	
	@POST
	@Path("/updatePOsSinSAR")
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	public Response updatePOsSinSAR(@FormParam("po") String po,
			@FormParam("mes") Integer mes,
			@FormParam("shipmentOnTime") Integer shipmentOnTime,
			@FormParam("comments") String comments,
			@FormParam("folio") Integer folio,
			@FormParam("status") Integer status,
			@FormParam("user") String user) {
		Response r = null;
		SeguimientoPOsSinSARBean bean = new SeguimientoPOsSinSARBean();
		bean.setPo(po);
		bean.setMes(mes);
		bean.setOnTime(shipmentOnTime);
		bean.setComments(comments);
		bean.setFolio(folio);
		bean.setStatus(status);
		bean.setModificationUser(user);
		
		SeguimientoPOsSinSARServiceImpl segPOsSinSAR = new SeguimientoPOsSinSARServiceImpl();
		boolean updated = segPOsSinSAR.actualizaPOsSinSAR(bean);
		
		if (updated) {
			r = buildOKResponse("PO " + po + " updated correctly.");
		} else {
			r = buildErrorResponse("Error while trying to update de PO: " + po);
		}
		
		return r;
	}
	
	@GET
	@Path("/SARsSinContenedor")
	@Produces(MediaType.APPLICATION_JSON)
	public Response dameSARsSinContenedor(@Context UriInfo ui) {
		Response r = null;
		MultivaluedMap<String, String> map = ui.getQueryParameters();
		String user = map.getFirst("user");
		String folio = map.getFirst("folio");
		String po = map.getFirst("po");
		String supplier = map.getFirst("supplier");
		String openClosed = map.getFirst("openClosed");
		String from = map.getFirst("from");
		String to = map.getFirst("to");
		
		SeguimientoPOsSinSARBean bean = new SeguimientoPOsSinSARBean();
		bean.setModificationUser(user);
		Integer iFolio = folio == null || "".equals(folio) ? null : Integer.valueOf(folio);
		bean.setFolio(iFolio);
		bean.setPo(po);
		bean.setSupplier(supplier);
		from = from.replaceAll("-", "");
		to = to.replaceAll("-", "");
		int iFrom = Integer.valueOf(from);
		int iTo = Integer.valueOf(to) + 1;
		bean.setFrom(iFrom * 100);
		bean.setTo(iTo * 100);
		
		SeguimientoSARsSinContenedorServiceImpl segSARsSinContenedor = new SeguimientoSARsSinContenedorServiceImpl();
		List<SeguimientoPOsSinSARBean> lstSARsSinContenedor = segSARsSinContenedor.consultaSARsSinContenedor(bean);
		List<FormatSeguimientoPOsSinSAR> lstFmtSARsSinConenedor = new ArrayList<FormatSeguimientoPOsSinSAR>();
		for (SeguimientoPOsSinSARBean tmp : lstSARsSinContenedor) {
			if ("open".equals(openClosed) && tmp.getStatus() != null && tmp.getStatus() == 2) {
				continue;
			}
			if ("closed".equals(openClosed) && (tmp.getStatus() == null || tmp.getStatus() == -1 || tmp.getStatus() == 1)) {
				continue;
			}
			FormatSeguimientoPOsSinSAR format = new FormatSeguimientoPOsSinSAR(tmp);
			lstFmtSARsSinConenedor.add(format);
		}
		String jsonResult = gson.toJson(lstFmtSARsSinConenedor, new TypeToken<ArrayList<FormatSeguimientoPOsSinSAR>>(){}.getType());
		r = buildOK_JSONResponse(jsonResult);
		return r;
	}
	
	@GET
	@Path("/downloadFileSARsSinContenedor")
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Produces(MediaType.APPLICATION_OCTET_STREAM)
	public Response downloadSARsSinContenedor(@Context UriInfo ui) {
		Response r = null;
		MultivaluedMap<String, String> map = ui.getQueryParameters();
		String user = map.getFirst("user");
		String folio = map.getFirst("folio");
		String po = map.getFirst("po");
		String supplier = map.getFirst("supplier");
		String openClosed = map.getFirst("openClosed");
		String from = map.getFirst("from");
		String to = map.getFirst("to");
		
		SeguimientoPOsSinSARBean bean = new SeguimientoPOsSinSARBean();
		bean.setModificationUser(user);
		Integer iFolio = folio == null || "".equals(folio) ? null : Integer.valueOf(folio);
		bean.setFolio(iFolio);
		bean.setPo(po);
		bean.setSupplier(supplier);
		from = from.replaceAll("-", "");
		to = to.replaceAll("-", "");
		int iFrom = Integer.valueOf(from);
		int iTo = Integer.valueOf(to) + 1;
		bean.setFrom(iFrom * 100);
		bean.setTo(iTo * 100);
		
		SeguimientoSARsSinContenedorServiceImpl segSARsSinContenedor = new SeguimientoSARsSinContenedorServiceImpl();
		List<SeguimientoPOsSinSARBean> lstSARsSinContenedor = segSARsSinContenedor.consultaSARsSinContenedor(bean);
		List<FormatSeguimientoPOsSinSAR> lstFmtSARsSinConenedor = new ArrayList<FormatSeguimientoPOsSinSAR>();
		for (SeguimientoPOsSinSARBean tmp : lstSARsSinContenedor) {
			boolean verSoloAbiertos = "open".equals(openClosed) && tmp.getStatus() != null && tmp.getStatus() == 2;
			boolean verSoloCerrados = "closed".equals(openClosed) && (tmp.getStatus() == null || tmp.getStatus() == -1 || tmp.getStatus() == 1);
			if (verSoloAbiertos || verSoloCerrados) {
				continue;
			}
			FormatSeguimientoPOsSinSAR format = new FormatSeguimientoPOsSinSAR(tmp);
			lstFmtSARsSinConenedor.add(format);
		}
		try {
			InputStream isSARsSinContenedorReport = getClass().getClassLoader().getResourceAsStream("sarsWithoutContainerReport.jrxml");
	        JRDataSource jrdatasource = new JRBeanCollectionDataSource(lstFmtSARsSinConenedor);
	        JasperServices js = new JasperServices(isSARsSinContenedorReport, jrdatasource, null);
	        
	        final byte[] bytes = js.getReportByteArray(JasperServices.XLS_TYPE);
	        
			StreamingOutput fileStream =  new StreamingOutput() {
				@Override
				public void write(OutputStream arg0) throws WebApplicationException {
		            BufferedOutputStream bus = new BufferedOutputStream(arg0);
		            try {
		                bus.write(bytes);
		            } catch (Exception e) {
		            	throw new WebApplicationException(e, buildErrorResponse());
		            }
		        }
			};
	        
	        ResponseBuilder response = Response.ok(fileStream, MediaType.APPLICATION_OCTET_STREAM);
			response.header("Content-Disposition", "attachment; filename=SARsWithoutContainerReport.xls");
			response.header("Content-Type","application/vnd.ms-excel");
			response.header("Content-Length", bytes.length);
			r = response.build();
		} catch (JRException jrE) {
			BaseLogger.BOOKING_LOGGER.error("Error al intentar generar el reporte con JASPER", jrE);
			r = buildErrorResponse();
		} catch (IOException ioE) {
			BaseLogger.BOOKING_LOGGER.error("Error al intentar generar el archivo", ioE);
			r = buildErrorResponse();
		}
		
		return r;
	}
	
	@POST
	@Path("/updateSARsSinContenedor")
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	public Response updateSARsSinContenedor(@FormParam("folio") Integer folio,
			@FormParam("booking") String booking,
			@FormParam("container") String container,
			@FormParam("comments") String comments,
			@FormParam("status") Integer status,
			@FormParam("user") String user) {
		Response r = null;
		SeguimientoPOsSinSARBean bean = new SeguimientoPOsSinSARBean();
		bean.setFolio(folio);
		bean.setBooking(booking);
		bean.setContainer(container);
		bean.setComments(comments);
		bean.setStatus(status);
		bean.setModificationUser(user);
		
		SeguimientoSARsSinContenedorServiceImpl segPOsSinSAR = new SeguimientoSARsSinContenedorServiceImpl();
		boolean updated = segPOsSinSAR.actualizaSARsSinContenedor(bean);
		
		if (updated) {
			r = buildOKResponse("SAR " + folio + " updated correctly.");
		} else {
			r = buildErrorResponse("Error while trying to update the SAR: " + folio);
		}
		
		return r;
	}
}
