package com.srm.pli.helper;


public class FormateaBeanAerolinea {
	
	private String clave;
	private String nombre;
	private boolean pagaTruper;
	
	
	/**
	 * Metodo para formatear en json y mandarlo a la vista
	 * 
	 * @param bean
	 */
	public void format( ){
//		clave 	= String.valueOf(bean.getClave());
//		nombre 	= bean.getNombre();
//		pagaTruper = 
	}
	
	
	public String getClave(){
		return clave;
	}
	
	public String getNombre(){
		return nombre;
	}
	
	public boolean isPagaTruper(){
		return pagaTruper;
	}
	
	

//	public JSONObject toJSON() {
//		JSONObject json = new JSONObject();
//		try{
//			json.put("clave", clave);
//			json.put("nombre", StringEscapeUtils.escapeHtml(nombre));
//			json.put("pagaTruper", pagaTruper);
//			
//		}catch(JSONException je){}
//		return json;
//	}
	
}
