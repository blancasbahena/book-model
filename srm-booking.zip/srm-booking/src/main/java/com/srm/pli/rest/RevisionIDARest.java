package com.srm.pli.rest;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.srm.fungandrui.parcelmobi.models.DocumentosProveedorModel;
import com.srm.fungandrui.sc.service.SarService;
import com.srm.fungandrui.sc.service.SarServiceImpl;
import com.srm.pli.bo.BeanRespuestaIDAValidation;
import com.srm.pli.bo.BitacoraVistaBean;
import com.srm.pli.bo.RevisionIDAVistaBean;
import com.srm.pli.bo.SarBO;
import com.srm.pli.dao.BitacoraIDADAO;
import com.srm.pli.dao.Cdi_dao_documents;
import com.srm.pli.dao.SAR_CDI_DAO;
import com.srm.pli.helper.PlannerHelper;
import com.srm.pli.helper.UsuarioHelper;
import com.srm.pli.services.BitacoraIDAService;
import com.srm.pli.services.RevisionIDAService;
import com.srm.pli.utils.FuncionesComunesPLI;
import com.srm.pli.utils.PoSerializer;
import com.srm.pli.utils.UtilsSarSQL;
import com.truper.bpm.enums.ErrorValidacionEtdEta;
import com.truper.businessEntity.BeanCommonResponse;
import com.truper.businessEntity.BeanRespuestaEtdEta;
import com.truper.businessEntity.BitacoraIDABean;
import com.truper.businessEntity.SARRevisionIDABean;
import com.truper.businessEntity.UserBean;
import com.truper.infra.rs.BaseRS;
import com.truper.utils.date.EnumFechas;
import com.truper.utils.date.UtilsFechas;
import com.truper.utils.string.UtilsString;

@Path("/revisionIDAs")
public class RevisionIDARest extends BaseRS {

	SAR_CDI_DAO dao = new SAR_CDI_DAO();

	private static final long serialVersionUID = 5394059842158283958L;
	Gson g = new GsonBuilder()
			.registerTypeAdapter(ErrorValidacionEtdEta.class, new PoSerializer.ErrorValidacionEtdEtaSerializer())
			.serializeSpecialFloatingPointValues().setDateFormat(EnumFechas.FORMATO_YYYY_MM_DD.to()).create();
	private static final Logger log = LogManager.getRootLogger();
	public boolean isHighVol = false;
	public static final String SAR_IN_IDA_REVISION = "SAR in IDA Revision";
	public static final String SAR_ACCEPTED_WITH_IDA_REVISION = "SAR accepted in IDA Revision";
	public static final String SAR_REJECTED_WITH_IDA_REVISION = "SAR rejected in IDA Revision";

	@Autowired
	SarService service = new SarServiceImpl();

	@Context
	private HttpServletRequest request;

	@POST
	@Path("/validaIDAs")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getValidaIDAs(@FormParam("etdNueva") String etdNueva, @FormParam("etdAnterior") String etdAnterior,
			@FormParam("folio") String folio, @FormParam("esLCL") String esLCL) {
		Set<BeanRespuestaEtdEta> respuesta = null;
		try {
			Date etdNueva_d = UtilsFechas.setConvierteFechaToDate(etdNueva, EnumFechas.FORMATO_YYYY_MM_DD_SLASH);
			Integer etdNueva_i = UtilsFechas.setConvierteFechaToInt(etdNueva_d, EnumFechas.FORMATO_YYYYMMDD);
			Integer folio_i = Integer.valueOf(folio);
			
			respuesta = RevisionIDAService.getInstance().validaEtdEta(folio_i, etdNueva_i);
			log.info("[validaIDAs] Folio: {} etdNueva: {} Respuesta: {}", folio, etdNueva, respuesta);
		} catch (Exception e) {
			BeanCommonResponse r = new BeanCommonResponse();
			r.setErrorCode(1);
			r.setMensaje(e.toString());
			log.error(e);
			return buildErrorResponse(g.toJson(r));
		}
		return buildOKResponse(g.toJson(respuesta));
	}
	
	@POST
	@Path("/validaIDAsConsolidado")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getValidaIDAsConsolidado(@FormParam("etdNueva") String etdNueva,
			@FormParam("etdAnterior")  String etdAnterior,
			@FormParam("folio")  String folio,
			@FormParam("listaFolios")  String listaFolios) {
		BeanRespuestaIDAValidation result = null;
		try {
			Date d = UtilsFechas.setConvierteFechaToDate(etdNueva, EnumFechas.FORMATO_YYYY_MM_DD_SLASH);
			
			result = RevisionIDAService.getInstance().debeMandarseAVistaGerente_CC(Integer.parseInt(folio), 
					UtilsFechas.setConvierteFechaToInt(d, EnumFechas.FORMATO_YYYYMMDD),listaFolios);
			log.info("[validaIDAsConsolidado] Folio: {} etdNueva: {} Respuesta: {}", folio, etdNueva, result);
			log.info("[validaIDAsConsolidado] Response Gson: {}", g.toJson(result));
		} catch (Exception e) {
			BeanCommonResponse r = new BeanCommonResponse();
			r.setErrorCode(1);
			r.setMensaje(e.toString());
			log.error(e);
			return buildErrorResponse(g.toJson(r));
		}
		return buildOKResponse(g.toJson(result));
	}
	
	
	@POST
	@Path("/generaRegistroIDA")
	@Produces(MediaType.APPLICATION_JSON)
	public Response generaRegistroIDA(@FormParam("etdNueva") String etdNueva,@FormParam("etdAnterior")  String etdAnterior,
			@FormParam("folio")  String folio ,@FormParam("esLCL")  String esLCL,@FormParam("folioConsolidado")  String folioConsolidado, 
			@FormParam("origenDeVista") String origenDeVista) {
		BeanCommonResponse r = new BeanCommonResponse();
		String sTrue = "true";
		etdNueva = etdNueva.replace("-", "/");
		try {
			
			UserBean usuario = null;
			HttpSession sesion = request.getSession(false);
			if( sesion != null) {
				usuario = (UserBean) sesion.getAttribute("usuario");
			}else {
				throw new Exception("Sesion finalizada");
			}
			
			SARRevisionIDABean bean = new SARRevisionIDABean();
			if(folioConsolidado != null && !"".equals(folioConsolidado)) {
				bean.setCc(Integer.parseInt(folioConsolidado));
			}
			if("".equals(folioConsolidado)) {
				if(sTrue.equals(esLCL)) {
					bean.setCc(1);
				}else {
					bean.setCc(0);
				}
			}
			
			Date d =UtilsFechas.setConvierteFechaToDate(etdNueva, EnumFechas.FORMATO_YYYY_MM_DD_SLASH);
			bean.setETDNuevo(UtilsFechas.setConvierteFechaToInt(d, EnumFechas.FORMATO_YYYYMMDD));
			bean.setFolio(Integer.parseInt(folio));
			bean.setTipo(sTrue.equals(esLCL) ? true : false);
			bean.setOrigenDeVista(origenDeVista);
			bean.setUserName(getUser().getUserName());
			RevisionIDAService.getInstance().doGeneracionRegistroRevisionIDA(bean);
			
			r.setErrorCode(0);
			r.setMensaje("OK");
			log.info("[generaRegistroIDA] etdNueva:"+etdNueva + "_EtdAnterior:"+etdAnterior+ "_Folio:"
					+folio+ "_esLCL:"+esLCL+ "_folioConsolidado:"+folioConsolidado+"_user:"+getUserToString());
			
			// Guarda SAR History Log
			FuncionesComunesPLI.guardaSARHistoryLog(dao.findActionHistoryByAction(SAR_IN_IDA_REVISION), Integer.parseInt(folio), usuario.getUserName(), null, bean.getCc() > 0 ? "C" : "F", null);
						
			
		} catch (Exception e) {
			r.setErrorCode(1);
			r.setMensaje(e.toString());
			log.error("[generaRegistroIDA] etdNueva:"+etdNueva + "_EtdAnterior:"+etdAnterior+ "_Folio:"+folio
					+ "_esLCL:"+esLCL+ "_folioConsolidado:"+folioConsolidado+"_user:"+getUserToString(),e);
			return buildErrorResponse(g.toJson(r));
		}
		return buildOKResponse(g.toJson(r));
	}
	
	@POST
	@Path("/dameRevisionesPorAceptar")
	@Produces(MediaType.APPLICATION_JSON)
	public Response dameRevisionesPorAceptar(@FormParam("highVolumeIDA") String highVolume) {
		JSONObject obj = new JSONObject();
		List<RevisionIDAVistaBean> lista = null;
		try {
			lista = (ArrayList<RevisionIDAVistaBean>) RevisionIDAService.getInstance().dameSarsEnrvisionAbiertos(getUser());
			
			
			//lssd alto volumen  -- // 
			isHighVol = "true".equals(highVolume);
			if (isHighVol) {
				lista= service.listHighVolSarBOIDA((ArrayList<RevisionIDAVistaBean>) lista);
			}
			
			obj.put("lista",lista );
			HashMap<String, String> mapaPlaneadores = new HashMap<>();
			for(RevisionIDAVistaBean tmp : lista) {
				if(tmp.getPlannerCode() == null) {
					continue;
				}
				if(!mapaPlaneadores.containsKey(tmp.getPlannerName())){
					mapaPlaneadores.put(tmp.getPlannerName(), tmp.getPlannerCode());
				}else {
					String valores = mapaPlaneadores.get(tmp.getPlannerName());
					if(!valores.contains(tmp.getPlannerCode())) {
						mapaPlaneadores.put(tmp.getPlannerName(), mapaPlaneadores.get(tmp.getPlannerName())+","+tmp.getPlannerCode());
					}
				}
			}
			obj.put("planners", mapaPlaneadores);
			log.info("[dameRevisionesPorAceptar] OK");
		} catch (Exception e) {
			BeanCommonResponse r = new BeanCommonResponse();
			r.setErrorCode(1);
			r.setMensaje(e.toString());
			log.error(e);
			return buildErrorResponse(g.toJson(r));
		}
		return buildOK_JSONResponse(obj);
	}
	
	@POST
	@Path("/dameDetalle")
	@Produces(MediaType.APPLICATION_JSON)
	public Response dameDetalle(@FormParam("folio") int folio,@FormParam("esConsol") boolean esConsol) {
		String result = null;
		try {
			if(esConsol) {
				result = RevisionIDAService.getInstance().dameDetalleCDISARConsol(folio);
			}else {
				result = RevisionIDAService.getInstance().dameDetalleCDISAR(folio);
			}
		}catch (Exception e) {
			BeanCommonResponse r = new BeanCommonResponse();
			r.setErrorCode(1);
			r.setMensaje(e.toString());
			log.error(e);
			return buildErrorResponse(g.toJson(r));
		}
		return buildOKResponse(result);
	}
	
	
	@POST
	@Path("/generaRechazo")
	@Produces(MediaType.APPLICATION_JSON)
	public Response generaRechazo(@FormParam("folio") Integer folio,@FormParam("mensaje")  String mensaje,@FormParam("esCC")  Integer esCC) {
		BeanCommonResponse r = new BeanCommonResponse();
		try {
			
			UserBean usuario = null;
			HttpSession sesion = request.getSession(false);
			if( sesion != null){
				usuario = (UserBean) sesion.getAttribute("usuario");
			}else {
				throw new Exception("Sesion finalizada");
			}
			
			if(folio.compareTo(esCC) == 0) {//Si es Consolidado o en la tabla de Full
				RevisionIDAService.getInstance().doRechazoGerenteCC(folio, esCC, mensaje,getUser().getUserName());
			}else {
				RevisionIDAService.getInstance().doRechazoGerente(folio, esCC, mensaje,getUser().getUserName());	
			}
			
			// Guarda SAR History Log
			FuncionesComunesPLI.guardaSARHistoryLog(dao.findActionHistoryByAction(SAR_REJECTED_WITH_IDA_REVISION), folio, usuario.getUserName(), null, esCC > 0 ? "C" : "F", mensaje);
						
			
			r.setErrorCode(0);
			r.setMensaje("OK");
			log.info("[generaRechazo] folio:"+folio+"_mensaje:"+mensaje+"_esCC:"+esCC+"_user:"+getUserToString());
		} catch (Exception e) {
			r.setErrorCode(1);
			r.setMensaje(e.toString());
			log.error("[generaRechazo] folio:"+folio+"_mensaje:"+mensaje+"_esCC:"+esCC+"_user:"+getUserToString(),e);
			return buildErrorResponse(g.toJson(r));
		}
		return buildOKResponse(g.toJson(r));
	}
	
	@POST
	@Path("/generaAceptacion")
	@Produces(MediaType.APPLICATION_JSON)
	public Response generaAceptacion(@FormParam("folio") Integer folio,@FormParam("mensaje")  String mensaje,@FormParam("esCC")  Integer esCC) {
		BeanCommonResponse r = new BeanCommonResponse();
		try {
			boolean esConsolidado = folio.compareTo(esCC) == 0;
			
			UserBean usuario = null;
			HttpSession sesion = request.getSession(false);
			if( sesion != null) {
				usuario = (UserBean) sesion.getAttribute("usuario");
			}else {
				throw new Exception("Sesion finalizada");
			}
				
			if(esConsolidado) {
				RevisionIDAService.getInstance().doAcceptacionCC(folio, esCC,mensaje,getUser().getUserName());
			}else {
				RevisionIDAService.getInstance().doAcceptacion(folio, esCC, mensaje,getUser().getUserName());
			}
			
			// Guarda SAR History Log
			FuncionesComunesPLI.guardaSARHistoryLog(dao.findActionHistoryByAction(SAR_ACCEPTED_WITH_IDA_REVISION), folio, usuario.getUserName(), null, esCC > 0 ? "C" : "F", mensaje);
			
			r.setErrorCode(0);
			r.setMensaje("OK");
			log.info("[generaAceptacion] folio:"+folio+"_mensaje:"+mensaje+"_esCC:"+esCC+"_user:"+getUserToString());
		} catch (Exception e) {
			r.setErrorCode(1);
			r.setMensaje(e.toString());
			log.error("[generaAceptacion] folio:"+folio+"_mensaje:"+mensaje+"_esCC:"+esCC+"_user:"+getUserToString(),e);
			return buildErrorResponse(g.toJson(r));
		}
		return buildOKResponse(g.toJson(r));
	}
	
	
	@POST
	@Path("/dameFechaValida")
	@Produces(MediaType.APPLICATION_JSON)
	public Response generaAceptacion(@FormParam("folio") Integer folio,@FormParam("esCC")  Integer esCC) {
		SARRevisionIDABean r = new SARRevisionIDABean();
		try {
			r =  RevisionIDAService.getInstance().dameFechaValida(folio, esCC);
			log.info("[dameFechaValida] folio:"+folio+"_esCC:"+esCC+"_user:"+getUserToString());
		} catch (Exception e) {
			log.error("[dameFechaValida] folio:"+folio+"_esCC:"+esCC+"_user:"+getUserToString(),e);
			return buildErrorResponse(g.toJson(r));
		}
		return buildOKResponse(g.toJson(r));
	}
	
	@POST
	@Path("/generaRegistroIDAConsol")
	@Produces(MediaType.APPLICATION_JSON)
	public Response generaRegistroIDAConsol(@FormParam("etdNueva") String etdNueva,
			@FormParam("etdAnterior")  String etdAnterior,
			@FormParam("folio")  String folio,
			@FormParam("listaFolios")  String listaFolios) {
		BeanCommonResponse r = new BeanCommonResponse();
		try {
			Date d = UtilsFechas.setConvierteFechaToDate(etdNueva, EnumFechas.FORMATO_YYYY_MM_DD_SLASH);
			RevisionIDAService.getInstance().doGeneracionRegistroRevisionIDAConsol(Integer.parseInt(folio), 
					UtilsFechas.setConvierteFechaToInt(d, EnumFechas.FORMATO_YYYYMMDD), listaFolios);
			r.setErrorCode(0);
			r.setMensaje("OK");
			log.info("[validaIDAs] OK");
		} catch (Exception e) {
			r.setErrorCode(1);
			r.setMensaje(e.toString());
			log.error(e);
			return buildErrorResponse(g.toJson(r));
		}
		return buildOKResponse(g.toJson(r));
	}
	
	
	/**
	 * Regresa el filtro de tipo de SAR por perfil de usuario.
	 * 
	 * 
	 * 
	 * @param listaOrigen
	 * @return
	 * @throws Exception 
	 */
	private List<BitacoraVistaBean> filtroSarDirectoVsNormal(List<BitacoraVistaBean> listaOrigen) throws Exception{
		UserBean user = getUser();
		if(listaOrigen == null || listaOrigen.isEmpty() || UsuarioHelper.getInstance().veSarsDirectosYNormales(user)) {
			return listaOrigen; 
		}
		
		List<BitacoraVistaBean> nuevaLista = new ArrayList<>();
		List<SarBO> listaBoSinCC = new ArrayList<>();
		Map<Integer, BitacoraVistaBean> mapaSinCC = new HashMap<>();
		Set<BitacoraVistaBean> setCC = new HashSet<>();
		for(BitacoraVistaBean bean : listaOrigen) {
			if(bean.getFolio() == bean.getFolioCC()) {
				setCC.add(bean);
				continue;
			}
			SarBO bo = new SarBO();
			bo.setFolio(bean.getFolio());
			listaBoSinCC.add(bo);
			mapaSinCC.put(bean.getFolio(),bean );
		}
		
		listaBoSinCC = PlannerHelper.getInstance().filtraPorTipoSAR(listaBoSinCC, user);
		
		if(UsuarioHelper.getInstance().veSoloSARsDirectos(user)) {
			for(SarBO bo : listaBoSinCC) {
				nuevaLista.add(mapaSinCC.get(bo.getFolio()));
			}
		}else {
			for(SarBO bo : listaBoSinCC) {
				nuevaLista.add(mapaSinCC.get(bo.getFolio()));
			}
			//ahora agrego las CC
			for(BitacoraVistaBean bean : setCC) {
				nuevaLista.add(bean);
			}
		}
		
		return nuevaLista;
	}
	
	
	@POST
	@Path("/dameBitacorasAbiertas")
	@Produces(MediaType.APPLICATION_JSON)
	public Response dameBitacorasAbiertas() {
		List<BitacoraVistaBean> lista = null;
		try {
			lista = BitacoraIDAService.getInstance().selectBitacorasOpen();
			lista = filtroSarDirectoVsNormal(lista);
			log.info("[dameRevisionesPorAceptar] OK");
		} catch (Exception e) {
			BeanCommonResponse r = new BeanCommonResponse();
			r.setErrorCode(1);
			r.setMensaje(e.toString());
			log.error(e);
			return buildErrorResponse(g.toJson(r));
		}
		return buildOKResponse(g.toJson(lista));
	}
	
	@POST
	@Path("/dameChat")
	@Produces(MediaType.APPLICATION_JSON)
	public Response dameChat(@FormParam("folio") Integer folio,@FormParam("folioCC") Integer folioCC) {
		List<BitacoraIDABean> lista = null;
		try {
			UserBean user = getUser();
			String userSesion = user.getUserName();
			BitacoraIDABean idaBean = new BitacoraIDABean();
			idaBean.setFolio(folio);
			idaBean.setFolioCC(folioCC); 
			lista = BitacoraIDADAO.getInstance().selectBitacoraMensajes(idaBean);
			for(BitacoraIDABean tmp : lista) {
				if(tmp.getUserName().equals(userSesion)) {
					tmp.setLocal(true);
				}else {
					tmp.setLocal(false);
				}
			}
			log.info("[dameRevisionesPorAceptar] OK");
		} catch (Exception e) {
			BeanCommonResponse r = new BeanCommonResponse();
			r.setErrorCode(1);
			r.setMensaje(e.toString());
			log.error(e);
			return buildErrorResponse(g.toJson(r));
		}
		return buildOKResponse(g.toJson(lista));
	}
	
	@POST
	@Path("/guardaMensajeBitacora")
	@Produces(MediaType.APPLICATION_JSON)
	public Response guardaMensajeBitacora(@FormParam("folio") Integer folio,
			@FormParam("folioCC") Integer folioCC,@FormParam("mensaje") String mensaje) {
		BeanCommonResponse r = new BeanCommonResponse();
		try {
			UserBean userBean = getUser();
			BitacoraIDAService.getInstance().insertaBitacora(folio, folioCC, mensaje,userBean.getUserName());
			r.setErrorCode(0);
			r.setMensaje("OK");
			log.info("[guardaMensajeBitacora] OK, folio:"+folio+",folioCC:"+folioCC+",mensaje:"+mensaje);
		} catch (Exception e) {
			r.setErrorCode(1);
			r.setMensaje(e.toString());
			log.error(e);
			return buildErrorResponse(g.toJson(r));
		}
		return buildOKResponse(g.toJson(r));
	}
	
	@POST
	@Path("/cierraBitacora")
	@Produces(MediaType.APPLICATION_JSON)
	public Response cierraBitacora(@FormParam("folio") Integer folio,
			@FormParam("folioCC") Integer folioCC) {
		BeanCommonResponse r = new BeanCommonResponse();
		try {
			UserBean userBean = getUser();
			BitacoraIDAService.getInstance().cierraBitacora(folio, folioCC,userBean.getUserName());
			r.setErrorCode(0);
			r.setMensaje("OK");
			log.info("[guardaMensajeBitacora] OK, folio:"+folio+",folioCC:"+folioCC+",usuario:"+userBean.getUserName());
		} catch (Exception e) {
			r.setErrorCode(1);
			r.setMensaje(e.toString());
			log.error(e);
			return buildErrorResponse(g.toJson(r));
		}
		return buildOKResponse(g.toJson(r));
	}
	
	private UserBean getUser() {
		HttpSession session = request.getSession(false);
		if (session == null)
			return null;
		UserBean usuario = (UserBean) session.getAttribute("usuario");
		return usuario;
	}
	
	private String getUserToString() {
		UserBean user = getUser();
		if (user == null)
			return "null";
		return UtilsString.append("#", user.getIdUser(), " ", user.getUserName());
	}

	@POST
	@Path("/documentosBookingSupplier")
	@Produces(MediaType.APPLICATION_JSON)
	public Response documentosBookingSupplier(@FormParam("folio") String folio, @FormParam("booking") String booking,
			@FormParam("proveedor") String proveedor) {
		List<DocumentosProveedorModel> model = new ArrayList<DocumentosProveedorModel>();

		try {
			if (booking.equalsIgnoreCase("") || proveedor.equalsIgnoreCase("")) {
				SarBO sar = UtilsSarSQL.getSar(folio, false);

				if (sar != null) {
					booking = sar.getBooking();
					proveedor = sar.getProveedor();
				}
			}
			model = Cdi_dao_documents.getInstance().getDocumentsByBookingSupplier(booking, proveedor);

		} catch (ServletException e2) {
			log.error(e2.getMessage(), e2);
			return buildErrorResponse(g.toJson(e2));
		}

		return buildOKResponse(g.toJson(model));
	}

}
