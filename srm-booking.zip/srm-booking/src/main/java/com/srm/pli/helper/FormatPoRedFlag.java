package com.srm.pli.helper;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.srm.pli.dao.SAR_CDI_DAO;
import com.srm.pli.utils.FuncionesComunesPLI;
import com.truper.businessEntity.PoRedFlag;
import com.truper.businessEntity.SARDetalle;
import com.truper.businessEntity.UserBean;

public class FormatPoRedFlag {
	private Integer id;
	private String po;
	private String fechaCreacion;
	private String cveProveedor;
	private String nombreProveedor;
	private String comentarioProveedor;
	private String fechaRespuesta;
	private String cvePlanningExecutive;
	private String nombrePlanningExecutive;
	private String comentarioPlanningExecutive;
	private List<FormatPoRedFlagDetalle> detalle;
	public static final Logger LOGGER = LogManager.getRootLogger();
	
	public FormatPoRedFlag(PoRedFlag rfb) {
		id = rfb.getId();
		po = rfb.getPo().trim();
		fechaCreacion = FuncionesComunesPLI.formateaFecha(rfb.getFechaCreacion());
		cveProveedor = rfb.getUsuarioBloquea();
		String cveProveedor = rfb.getUsuarioBloquea().substring(1);
		String supplier = FuncionesComunesPLI.getProveedor(cveProveedor) != null ? FuncionesComunesPLI
				.getProveedor(cveProveedor).getNombreProveedor() : "-";
		nombreProveedor = supplier;
		comentarioProveedor = rfb.getComentarioProveedor() == null ? "N.D." : rfb.getComentarioProveedor();
		fechaRespuesta = rfb.getFechaRespuesta() == 0 ? "N.D." : FuncionesComunesPLI.formateaFecha(rfb.getFechaRespuesta());
		cvePlanningExecutive = rfb.getUsuarioRespuesta() == null ? "N.D." : rfb.getUsuarioRespuesta();
		UserBean userTmp = new UserBean();
		userTmp.setUserName(rfb.getUsuarioRespuesta());
		List<UserBean> userLst;
		try {
			userLst = SAR_CDI_DAO.dameUsuarios(userTmp);
			String nombrePlaneador = userLst == null || userLst.size() == 0 ? "N.D." : userLst.get(0) == null ? "N.D." : userLst.get(0).getRealName();
			nombrePlanningExecutive = nombrePlaneador;
		} catch (ServletException e) {
			LOGGER.error(e.getMessage(), e);
			e.printStackTrace();
		}
		
		comentarioPlanningExecutive = rfb.getComentarioPlaneador() == null ? "N.D." : rfb.getComentarioPlaneador();
		if (rfb.getPoRedFlagDetalle() != null) {
			detalle = new ArrayList<FormatPoRedFlagDetalle>();
			for (SARDetalle det : rfb.getPoRedFlagDetalle()) {
				FormatPoRedFlagDetalle formatDetalle = new FormatPoRedFlagDetalle(det);
				detalle.add(formatDetalle);
			}
		}
	}
	/**
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}
	/**
	 * @return the po
	 */
	public String getPo() {
		return po;
	}
	/**
	 * @param po the po to set
	 */
	public void setPo(String po) {
		this.po = po;
	}
	/**
	 * @return the fechaCreacion
	 */
	public String getFechaCreacion() {
		return fechaCreacion;
	}
	/**
	 * @param fechaCreacion the fechaCreacion to set
	 */
	public void setFechaCreacion(String fechaCreacion) {
		this.fechaCreacion = fechaCreacion;
	}
	/**
	 * @return the cveProveedor
	 */
	public String getCveProveedor() {
		return cveProveedor;
	}
	/**
	 * @param cveProveedor the cveProveedor to set
	 */
	public void setCveProveedor(String cveProveedor) {
		this.cveProveedor = cveProveedor;
	}
	/**
	 * @return the nombreProveedor
	 */
	public String getNombreProveedor() {
		return nombreProveedor;
	}
	/**
	 * @param nombreProveedor the nombreProveedor to set
	 */
	public void setNombreProveedor(String nombreProveedor) {
		this.nombreProveedor = nombreProveedor;
	}
	/**
	 * @return the comentarioProveedor
	 */
	public String getComentarioProveedor() {
		return comentarioProveedor;
	}
	/**
	 * @param comentarioProveedor the comentarioProveedor to set
	 */
	public void setComentarioProveedor(String comentarioProveedor) {
		this.comentarioProveedor = comentarioProveedor;
	}
	/**
	 * @return the fechaRespuesta
	 */
	public String getFechaRespuesta() {
		return fechaRespuesta;
	}
	/**
	 * @param fechaRespuesta the fechaRespuesta to set
	 */
	public void setFechaRespuesta(String fechaRespuesta) {
		this.fechaRespuesta = fechaRespuesta;
	}
	/**
	 * @return the cvePlanningExecutive
	 */
	public String getCvePlanningExecutive() {
		return cvePlanningExecutive;
	}
	/**
	 * @param cvePlanningExecutive the cvePlanningExecutive to set
	 */
	public void setCvePlanningExecutive(String cvePlanningExecutive) {
		this.cvePlanningExecutive = cvePlanningExecutive;
	}
	/**
	 * @return the nombrePlanningExecutive
	 */
	public String getNombrePlanningExecutive() {
		return nombrePlanningExecutive;
	}
	/**
	 * @param nombrePlanningExecutive the nombrePlanningExecutive to set
	 */
	public void setNombrePlanningExecutive(String nombrePlanningExecutive) {
		this.nombrePlanningExecutive = nombrePlanningExecutive;
	}
	/**
	 * @return the comentarioPlanningExecutive
	 */
	public String getComentarioPlanningExecutive() {
		return comentarioPlanningExecutive;
	}
	/**
	 * @param comentarioPlanningExecutive the comentarioPlanningExecutive to set
	 */
	public void setComentarioPlanningExecutive(String comentarioPlanningExecutive) {
		this.comentarioPlanningExecutive = comentarioPlanningExecutive;
	}
	
}
