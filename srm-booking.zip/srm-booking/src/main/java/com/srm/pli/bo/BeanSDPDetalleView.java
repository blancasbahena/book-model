package com.srm.pli.bo;

import com.truper.businessEntity.BeanSDPDetalle;

public class BeanSDPDetalleView extends BeanSDPDetalle{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String item;
	private String descripcion;
	private String centro;
	private String planner;
	private String peso;
	private String volumen;	
	private String montoDiario;
	private String montoMaximo;
	private String cantidadView;
	private String precioView;
	
	public BeanSDPDetalleView(BeanSDPDetalle sdp) {		
		this.setFolio(sdp.getFolio());
		this.setCantidad(sdp.getCantidad());
		this.setCodigo(sdp.getCodigo());
		this.setMonto(sdp.getMonto());
		this.setMontoMax(sdp.getMontoMax());
		this.setPo(sdp.getPo());
		this.setPosicion(sdp.getPosicion());
		this.setPrecio(sdp.getPrecio());
		this.setValidar(sdp.isValidar());
	}
	
	public BeanSDPDetalleView() {
		
	}

	public String getItem() {
		return item;
	}

	public void setItem(String item) {
		this.item = item;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public String getCentro() {
		return centro;
	}

	public void setCentro(String centro) {
		this.centro = centro;
	}

	public String getPlanner() {
		return planner;
	}

	public void setPlanner(String planner) {
		this.planner = planner;
	}

	public String getPeso() {
		return peso;
	}

	public void setPeso(String peso) {
		this.peso = peso;
	}

	public String getVolumen() {
		return volumen;
	}

	public void setVolumen(String volumen) {
		this.volumen = volumen;
	}

	public String getMontoDiario() {
		return montoDiario;
	}

	public void setMontoDiario(String montoDiario) {
		this.montoDiario = montoDiario;
	}

	public String getMontoMaximo() {
		return montoMaximo;
	}

	public void setMontoMaximo(String montoMaximo) {
		this.montoMaximo = montoMaximo;
	}

	public String getCantidadView() {
		return cantidadView;
	}

	public void setCantidadView(String cantidadView) {
		this.cantidadView = cantidadView;
	}

	public String getPrecioView() {
		return precioView;
	}

	public void setPrecioView(String precioView) {
		this.precioView = precioView;
	}
	
}