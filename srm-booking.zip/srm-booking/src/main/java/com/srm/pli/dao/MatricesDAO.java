package com.srm.pli.dao;

import static com.srm.pli.dao.sql.Matrices_DAO_SQL.SELECT_AUTORIZADO_SDI;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.srm.fungandrui.facturacion.dto.ReporteProcesoSifeDTO;
import com.srm.pli.bo.BeanFiltroMatriz;
import com.srm.pli.bo.BeanMatrizCabecera;
import com.srm.pli.bo.BeanMatrizDetalles;
import com.srm.pli.constants.ConsultasConstants;
import com.srm.pli.db.ConexionDB;
import com.srm.pli.helper.MatricesHelper;
import com.truper.bpm.enums.StatusControlMatricesEnum;
import com.truper.businessEntity.BeanControlPrecios;
import com.truper.businessEntity.BeanLetoniano;
import com.truper.businessEntity.BeanXdias;
import com.truper.utils.date.UtilsFechas;
import com.truper.utils.sql.UtilsSQL;

public class MatricesDAO{
	
	private static MatricesDAO instance;
	private static final Logger log = LogManager.getRootLogger();
	
	
	private MatricesDAO() {
		
	}
	
	public static MatricesDAO getInstance() {
		if (instance == null) {
			instance = new MatricesDAO();
		}
		return instance;
	}
	
	public List<BeanMatrizCabecera> selectRegistrosMatriz(BeanFiltroMatriz filtro){
		Connection con = null;
		ArrayList<BeanMatrizCabecera> lista = new ArrayList<>();
		try {
			con = ConexionDB.dameConexion();
			String in = " IN  ";
			if("general".equals(filtro.getStatus())) {
				in +=UtilsSQL.convierteToIN(MatricesHelper.getInstance().dameStatusParaMostrarseEnMatriz());
			}else if("PPL".equals(filtro.getStatus())) {
				HashSet<String> status = new HashSet<>();
				status.add(StatusControlMatricesEnum.NEW.id());
				in +=UtilsSQL.convierteToIN(status);
			}else if("REL".equals(filtro.getStatus())) {
				in +=UtilsSQL.convierteToIN(MatricesHelper.getInstance().dameStatusAceptadosReportes());
			}else if("REJ".equals(filtro.getStatus())) {
				in +=UtilsSQL.convierteToIN(MatricesHelper.getInstance().dameStatusRechazados());
			}
			  

			ResultSet rs = null;
			PreparedStatement ps = null;
			StringBuffer query = new StringBuffer();
			Statement st = con.createStatement();

			String condicion = "";
			if(filtro.getProveedor() != null) {
				condicion += " AND proveedor = '" + filtro.getProveedor() + "'";
			}
			if(filtro.getPo() != null) {
				condicion += " AND po = '" + filtro.getPo() + "'";
			}
			if(filtro.isOnlyBackLog() ) {
				condicion += " AND isbacklog = 1 ";
			}
			
			if(filtro.getLogFin() != null &&  filtro.getLogIni() != null) {
				condicion += " AND DATEADD(day,DATEDIFF(day,0,fechaInsert),0)  BETWEEN  ? AND ?  ";
			}
			
			if(filtro.getModIni() != null &&  filtro.getModFin() != null) {
				condicion += " AND DATEADD(day,DATEDIFF(day,0,fechaModificacion),0)  BETWEEN  ? AND ?  ";
			}
			
			
			query.append("SELECT ORIGEN.*,xdias.dias FROM cdiControlMatrices as ORIGEN INNER JOIN ");
			query.append(" (SELECT * FROM ( ");
			query.append(" SELECT ROW_NUMBER() OVER (PARTITION BY  po,CONVERT(VARCHAR(8),fechainsert,112) ORDER BY etd ASC) numero_agrupado, ");
			query.append(" po, posicion,etd,isbacklog,proveedor,CONVERT(VARCHAR(8),fechainsert,112) as fechaInsert,CONVERT(VARCHAR(8),fechaModificacion,112) as fechaModificacion");
			query.append(" FROM   cdiControlMatrices ");
			query.append(" WHERE  status ").append(in);
			query.append(" GROUP BY   po,posicion,etd,isbacklog,proveedor,CONVERT(VARCHAR(8),fechainsert,112), CONVERT(VARCHAR(8),fechaModificacion,112) ) filas_numero ");
			query.append(" WHERE filas_numero.numero_agrupado = 1 ");
			query.append(condicion);
			query.append(") ETD_MINIMA ON ");
			query.append(" ORIGEN.po = ETD_MINIMA.po AND ORIGEN.posicion = ETD_MINIMA.posicion AND  CONVERT(VARCHAR(8),ORIGEN.fechaInsert,112)  = ETD_MINIMA.fechaInsert ");
			query.append("LEFT JOIN cdiPoMatricesXDias  xdias ON ORIGEN.po = xdias.po AND CONVERT(VARCHAR(8),ORIGEN.fechaInsert,112)  = xdias.date_matrices ");
			
			ps = con.prepareStatement(query.toString());
			
			int cont = 1;
			if(filtro.getLogFin() != null &&  filtro.getLogIni() != null) {
				ps.setDate(cont++, UtilsFechas.setConvierteFechaToSQLDate(filtro.getLogIni()));
				ps.setDate(cont++, UtilsFechas.setConvierteFechaToSQLDate(filtro.getLogFin()));
			}
			
			if(filtro.getModIni() != null &&  filtro.getModFin() != null) {
				ps.setDate(cont++, UtilsFechas.setConvierteFechaToSQLDate(filtro.getModIni()));
				ps.setDate(cont++, UtilsFechas.setConvierteFechaToSQLDate(filtro.getModFin()));
			}
			
			rs = ps.executeQuery();
			while (rs.next()) {
				BeanMatrizCabecera result = new BeanMatrizCabecera();
				result.setFechaInsert(rs.getTimestamp("fechaInsert"));
				result.setPo(rs.getString("po"));
				result.setMaterial(rs.getInt("material"));
				result.setCentro(rs.getString("centro"));
				result.setEtd(rs.getInt("ETD"));
				result.setProveedor(rs.getString("proveedor"));
				result.setBacklog(rs.getBoolean("isBacklog"));
				result.setFechaBacklog(rs.getTimestamp("fechaBacklog"));
				result.setDocumentosRequeridos(rs.getString("documentosRequeridos"));
				result.setFechaModificacion(rs.getTimestamp("fechaModificacion"));
				result.setComentario(rs.getString("comentario"));
				String status = rs.getString("status");
				result.setStatus(MatricesHelper.getInstance().dameEnumById(status));
				result.setxDias(rs.getInt("dias"));
				
				lista.add(result);
			}
			rs.close();
			st.close();
			ps.close(); 
			ConexionDB.devuelveConexion(con);

		} catch (Exception sqlE) {
			try {
				log.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
		return lista;
		
		
	}
	
	public List<ReporteProcesoSifeDTO> selectRegistrosSife(String diasRestantes){
		Connection con = null;
		ArrayList<ReporteProcesoSifeDTO> lista = new ArrayList<>();
		try {
			con = ConexionDB.dameConexion();
			ResultSet rs = null;
			PreparedStatement ps = null; 
			String query =ConsultasConstants.CONSULTA_REGISTROS_SIFE.toString();
			query = query.replace("srm.facturacion.sife.dias", diasRestantes); 
			ps = con.prepareStatement(query );
			rs = ps.executeQuery();
			while (rs.next()) {
				String auxkey = rs.getString("auxkey");
				String folio  = rs.getString("sar");
				String numeroParceMobil= rs.getString("numeroParceMobil");
				ReporteProcesoSifeDTO result =   
					new  ReporteProcesoSifeDTO(
						folio!=null? folio:"",
						rs.getString("diaFacturacion")!=null? rs.getString("diaFacturacion") :"",
						rs.getString("turnoDeentrega")!=null? rs.getString("turnoDeentrega") :"",
						rs.getString("numeroFactura")!=null? rs.getString("numeroFactura"):"",
						rs.getString("FolioSIFE")!=null?rs.getString("FolioSIFE") :"",
						rs.getString("numeroProveedor")!=null?rs.getString("numeroProveedor"):"",
						rs.getString("nombreProveedor")!=null?rs.getString("nombreProveedor"):"",
						rs.getString("numeroDocumentoSap")!=null?rs.getString("numeroDocumentoSap"):"",
						numeroParceMobil!=null?numeroParceMobil:"",
						rs.getString("FolioSIFE43")!=null?rs.getString("FolioSIFE43"):"",
						rs.getString("importeUsd")!=null?rs.getString("importeUsd"):"",
						"",
						rs.getString("fechaSife")!=null?rs.getString("fechaSife"):"");
				if(isHandlingByFacturaPM(folio,auxkey)) {
					result.setAuxkey("numeroParceMobil with handling");
				}
				lista.add(result);
			}
			rs.close();
			ps.close();
			ConexionDB.devuelveConexion(con);

		} catch (Exception sqlE) {
			try {
				log.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
		return lista;
		
		
	}
	public boolean isHandlingByFacturaPM(String folio,String auxkey){
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			conn = ConexionDB.dameConexion();
			String sql = ConsultasConstants.CONSULTA_REGISTROS_SIFE_HANDLING.toString();
			try {
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, Integer.parseInt(folio));
				rs = pstmt.executeQuery();
				while (rs.next()) { 
					String handling = rs.getString("handling");
					if(handling.contains(auxkey)) {
						return  true;
					}
					else if(auxkey.contains(handling)) {
						return true;
					}
				}
				
			} catch (SQLException eSQL) {
				log.error(getClass().getName() + eSQL.toString());
				ConexionDB.renovar(conn);
			}
		} catch (Exception e) {
			log.error(getClass().getName() + e.toString());
		} finally {
			try {
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				pstmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 
			ConexionDB.devolver(conn);
		}
		return false;
	} 
	
	public List<BeanMatrizDetalles> selectDetalles( String po , int fechaInsert){
		Connection con = null;
		ArrayList<BeanMatrizDetalles> lista = new ArrayList<>();
		try {
			con = ConexionDB.dameConexion();
			  

			ResultSet rs = null;
			StringBuffer query = new StringBuffer();
			Statement st = con.createStatement();

			query.append("SELECT fechaInsert, po, posicion, material, " );
			query.append(" centro, cantidad, ETD, proveedor, isBacklog, fechaBacklog, documentosRequeridos, fechaModificacion, comentario, status ");
			query.append("FROM   cdiControlMatrices  ");
			query.append("WHERE po ='").append(po).append("'");
			query.append("AND CONVERT(VARCHAR(8),fechaInsert,112) =").append(fechaInsert);

			rs = st.executeQuery(query.toString());
			while (rs.next()) {
				BeanMatrizDetalles result = new BeanMatrizDetalles();
				result.setFechaInsert(rs.getTimestamp("fechaInsert"));
				result.setPo(rs.getString("po"));
				result.setPosicion(rs.getInt("posicion"));
				result.setMaterial(rs.getInt("material"));
				result.setCentro(rs.getString("centro"));
				result.setCantidad(rs.getInt("cantidad"));
				result.setFecha(rs.getInt("ETD"));
				result.setProveedor(rs.getString("proveedor"));
				result.setBacklog(rs.getBoolean("isBacklog"));
				result.setFechaBacklog(rs.getTimestamp("fechaBacklog"));
				result.setDocumentosRequeridos(rs.getString("documentosRequeridos"));
				result.setFechaModificacion(rs.getTimestamp("fechaModificacion"));
				result.setComentario(rs.getString("comentario"));
				String status = rs.getString("status");
				result.setStatus(MatricesHelper.getInstance().dameEnumById(status));
				lista.add(result);
			}
			rs.close();
			st.close();
			ConexionDB.devuelveConexion(con);

		} catch (Exception sqlE) {
			try {
				log.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
		return lista;
		
		
	}
	
	
	
	public boolean generaRegistroMatriz(BeanControlPrecios beanControl) {		
		Connection con = null;
		PreparedStatement ps = null;
		StringBuilder sql = new StringBuilder();
		
		sql.append("MERGE cdicontrolmatrices as [target] ");
		sql.append(" USING ( SELECT  ");
		sql.append("  ? po  ");
		sql.append(" , ? posicion ");
		sql.append(" , ? material ");
		sql.append(" , ? centro ");
		sql.append(" , ? cantidad ");
		sql.append(" , ? etd ");
		sql.append(" , ? proveedor ");
		sql.append(" , ? documentosRequeridos ");
		sql.append(" , '").append(StatusControlMatricesEnum.NEW.id()).append("' status ");
		sql.append(" , ? precioUnitario ");
		sql.append(") AS [source]   ");
		sql.append(" ON CONVERT(varchar, GETDATE(),112) = CONVERT(varchar, [target].fechaInsert ,112)  ");
		sql.append("  AND [source].po = [target].po ");
		sql.append("  AND [source].posicion = [target].posicion ");
		sql.append(" WHEN matched THEN  ");
		sql.append(" UPDATE SET [target].status = [source].status ");
		sql.append(" ,[target].material = [source].material ");
		sql.append(" ,[target].centro = [source].centro ");
		sql.append(" ,[target].cantidad = [source].cantidad ");
		sql.append(" ,[target].etd = [source].etd ");
		sql.append(" ,[target].proveedor = [source].proveedor ");
		sql.append(" ,[target].isBacklog = NULL ");
		sql.append(" ,[target].fechaBacklog = NULL ");
		sql.append(" ,[target].documentosRequeridos = [source].documentosRequeridos ");
		sql.append(" ,[target].fechamodificacion = NULL ");
		sql.append(" ,[target].comentario = NULL ");
		sql.append(" ,[target].fechaLastUpdate = GETDATE() ");
		sql.append(" ,[target].precioUnitario = [source].precioUnitario ");
		sql.append(" WHEN NOT matched THEN ");
		sql.append(" INSERT (fechaInsert  ");
		sql.append(" , po  ");
		sql.append(" , posicion ");
		sql.append(" ,material ");
		sql.append(" ,centro ");
		sql.append(" ,cantidad ");
		sql.append(" ,etd ");
		sql.append(" ,proveedor ");
		sql.append(" ,documentosRequeridos ");
		sql.append(" ,status ");
		sql.append(" ,precioUnitario ) ");
		sql.append(" VALUES ( GETDATE() ");
		sql.append(" ,[source].po ");
		sql.append(" ,[source].posicion ");
		sql.append(" ,[source].material ");
		sql.append(" ,[source].centro ");
		sql.append(" ,[source].cantidad ");
		sql.append(" ,[source].etd ");
		sql.append(" ,[source].proveedor ");
		sql.append(" ,[source].documentosRequeridos ");
		sql.append(" ,[source].status ");
		sql.append(" ,[source].precioUnitario ");
		sql.append(" ); ");
		
		boolean exito = false;

		try {
			con = ConexionDB.dameConexion();
			
			ps = con.prepareStatement(sql.toString());
			int cont = 1;
			ps.setString(cont++, beanControl.getPo());
			ps.setInt(cont++, beanControl.getPosicion());
			ps.setInt(cont++, beanControl.getMaterial());
			ps.setString(cont++, beanControl.getCentro());
			ps.setInt(cont++, beanControl.getCantidad());
			ps.setInt(cont++, beanControl.getFecha());
			ps.setString(cont++, beanControl.getProveedor());
			ps.setString(cont++, beanControl.getDocumentosRequeridos());
			ps.setDouble(cont++, beanControl.getPrecioUnitario() != null ? beanControl.getPrecioUnitario().doubleValue() : 0);
			
			exito = ps.executeUpdate() > 0;
			ps.close();
			ConexionDB.devuelveConexion(con);
			log.info("[generaRegistroMatriz]" + 
			(exito ? "Se realizo una modificacion para la PO/pos:" : "NO se realizo una modificacion para la PO/pos:")
			+beanControl.getPo()+"/"+beanControl.getPosicion());
			
		} catch (Exception e) {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error("[generaRegistroMatriz] Error "+ex.getMessage(), ex);
			}
			log.error("[generaRegistroMatriz] Error "+e.getMessage(), e);
		}
		return exito;
	}
	
	
	public boolean marcaPOBacklog(String po, Date fechaInsert, String comentario) throws Exception {		
		Connection con = null;
		PreparedStatement ps = null;
		
		StringBuilder sql = new StringBuilder();

		sql.append("UPDATE  cdiControlMatrices SET isBacklog = 1 , fechaBacklog = GETDATE(), fechaModificacion = GETDATE(),");
		sql.append("comentario = ? ");
		sql.append(" WHERE po = ? AND DATEADD(day,DATEDIFF(day,0,fechaInsert),0)  = ? ");
		
		boolean exito = false;

		try {
			con = ConexionDB.dameConexion();
			
			ps = con.prepareStatement(sql.toString());
			int cont = 1;
			ps.setString(cont++, comentario);
			ps.setString(cont++, po);
			ps.setDate(cont++, UtilsFechas.setConvierteFechaToSQLDate(fechaInsert));
						
			exito = ps.executeUpdate() > 0;
			ps.close();
			ConexionDB.devuelveConexion(con);
		} catch (Exception e) {
			e.printStackTrace();
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error("[updateControlMatriz] Error "+ex.getMessage(), ex);
			}
			log.error("[updateControlMatriz] Error "+e.getMessage(), e);
			throw new Exception(e);
		} 

		return exito;
	}
	
	public  boolean updateControlMatriz(String po, Date fechaInsert, String comentario, String status) throws Exception {
		Connection con = null;
		PreparedStatement ps = null;
		
		StringBuilder sql = new StringBuilder();

		sql.append("UPDATE  cdiControlMatrices SET status = ? , ");
		sql.append("fechaModificacion = GETDATE(), comentario = CONCAT(comentario, ' | ', ?) ");
		sql.append(" WHERE po = ? AND DATEADD(day,DATEDIFF(day,0,fechaInsert),0) = ? ");
				
		boolean exito = false;

		try {
			con = ConexionDB.dameConexion();
			
			ps = con.prepareStatement(sql.toString());
			int cont = 1;
			ps.setString(cont++, status);
			ps.setString(cont++, comentario);
			ps.setString(cont++, po);
			ps.setDate(cont++, UtilsFechas.setConvierteFechaToSQLDate(fechaInsert));
						
			exito = ps.executeUpdate() > 0;
			ps.close();
			ConexionDB.devuelveConexion(con);
		} catch (Exception e) {
			e.printStackTrace();
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error("[updateControlMatriz] Error "+ex.getMessage(), ex);
			}
			log.error("[updateControlMatriz] Error "+e.getMessage(), e);
			throw new Exception(e);
		} 

		return exito;
	}
	
	public boolean insertXDias(String po, int dias, int dateInsert, int edtInsert) throws Exception {
		Connection con = null;
		PreparedStatement ps = null;

		boolean exito = false;

		try {
			con = ConexionDB.dameConexion();
			StringBuilder sql = new StringBuilder();
			sql.append("MERGE INTO cdipomatricesxdias AS [target] ");
			sql.append(" using (SELECT ? po ");
			sql.append("              , ? dias ");
			sql.append("              , ? date_matrices ");
			sql.append("              , ? etd_matrices) AS [source] ");
			sql.append(" ON [target].po = [source].po ");
			sql.append("   AND [target].date_matrices = [source].date_matrices ");
			sql.append(" WHEN matched THEN ");
			sql.append("  UPDATE SET [target].dias = [source].dias ");
			sql.append("             , [target].etd_matrices = [source].etd_matrices ");
			sql.append("             , [target].create_date = Getdate() ");
			sql.append(" WHEN NOT matched THEN ");
			sql.append("  INSERT (po ");
			sql.append("          , dias ");
			sql.append("          , date_matrices ");
			sql.append("          , etd_matrices) ");
			sql.append("  VALUES ([source].po ");
			sql.append("          , [source].dias ");
			sql.append("          , [source].date_matrices ");
			sql.append("          , [source].etd_matrices);");

			ps = con.prepareStatement(sql.toString());
			int cont = 1;
			ps.setString(cont++, po);
			ps.setInt(cont++, dias);
			ps.setInt(cont++, (dateInsert));
			ps.setInt(cont++, edtInsert);

			exito = ps.executeUpdate() > 0;
			ps.close();
		} catch (Exception e) {
			log.error("[insertXDias] Error {}", e.getMessage(), e);
			throw new Exception(e);
		} finally {
			ConexionDB.devolver(con);
		}
		return exito;
	}
	
	/**
	 * Regresa los registros que cumplen con el criterio de 
	 * HOY + Dias = ETD
	 * Para mandar un recordatorio
	 * 
	 * @return
	 */
	public List<BeanXdias> posConRecordatorioXDias(){
		Connection con = null;
		ArrayList<BeanXdias> lista = new ArrayList<>();
		try {
			con = ConexionDB.dameConexion();
			ResultSet rs = null;
			StringBuffer query = new StringBuffer();
			Statement st = con.createStatement();

			query.append("SELECT a.po,a.dias,a.date_matrices,a.etd_matrices,a.create_date " );
			query.append(" from cdiPoMatricesXDias a, cdiPoMatricesXDias b ");
			query.append(" WHERE a.po=b.po  ");
			query.append(" AND a.date_matrices = b.date_matrices ");
			query.append(" AND DATEDIFF(DAY, DATEADD(day,DATEDIFF(day,(a.dias),  ");
			query.append(" CONVERT(smalldatetime,CAST(a.etd_matrices AS varchar))),0), GETDATE()) = 0  ");
			
			rs = st.executeQuery(query.toString());
			while (rs.next()) {
				BeanXdias result = new BeanXdias();
				result.setCreateDate(rs.getTimestamp("create_date"));
				result.setDias(rs.getInt("dias"));
				result.setEtd(UtilsFechas.setConvierteFechaIntToDate(rs.getInt("etd_matrices")) );
				result.setMatrices(UtilsFechas.setConvierteFechaIntToDate(rs.getInt("date_matrices")));
				result.setPo(rs.getString("po"));
				lista.add(result);
			}
			rs.close();
			st.close();
			ConexionDB.devuelveConexion(con);

		} catch (Exception sqlE) {
			try {
				log.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
		return lista;
	}
	
	public boolean selectAutorizadoSdi(Integer folio) {
		boolean respuesta = false;
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();
			try (PreparedStatement pst = con.prepareStatement(SELECT_AUTORIZADO_SDI)) {
				pst.setInt(1, folio);
				try (ResultSet rs = pst.executeQuery()) {
					if (rs.next()) {
						respuesta = rs.getBoolean("aprobado");
					}
				}
			}
		} catch (SQLException sqle) {
			sqle.printStackTrace();
			log.error(sqle);
			ConexionDB.renovar(con);
		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
		} finally {
			ConexionDB.devolver(con);
		}
		return respuesta;
	}  
	
	
	public Integer updateFromTELMatrix(String po, int posicion, int nuevaETD) {
		Integer num_insert = null;
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();
			StringBuilder sql = new StringBuilder();
			sql = new StringBuilder();				
			sql.append("UPDATE cdiControlMatrices set etd = ? ");
			sql.append("WHERE po = ?  ");			
			
			try (PreparedStatement pst = con.prepareStatement(sql.toString());) {
				int i = 1;
				pst.setInt(i++, nuevaETD);
				pst.setString(i++, po);
				num_insert = pst.executeUpdate();
			}
		} catch (SQLException sqle) {
			log.error("[updateFromTELMatrix] Error: po: [{}], posicion [{}] , nuevaETD [{}] ",po,posicion,nuevaETD , sqle);
		} catch (Exception e) {
			log.error("[updateFromTELMatrix] Error: po: [{}], posicion [{}] , nuevaETD [{}] ",po,posicion,nuevaETD ,e);
		} finally {
			ConexionDB.devolver(con);
		}
		return num_insert;
	}
	
	public Integer updateFromTELAuditoria(String po, int posicion, int nuevaETD) {
		Integer num_insert = null;
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();
			StringBuilder sql = new StringBuilder();
			sql = new StringBuilder();				
			sql.append("UPDATE cdiauditoria SET fecha = ? ");
			sql.append(" WHERE  po = ?   ");

			try (PreparedStatement pst = con.prepareStatement(sql.toString());) {
				int i = 1;
				pst.setInt(i++, nuevaETD);
				pst.setString(i++, po);
				num_insert = pst.executeUpdate();
			}
		} catch (SQLException sqle) {
			sqle.printStackTrace();
			log.error("[updateFromTELAuditoria] Error: po: [{}], posicion [{}] , nuevaETD [{}] ",po,posicion,nuevaETD , sqle);
			ConexionDB.renovar(con);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("[updateFromTELAuditoria] Error: po: [{}], posicion [{}] , nuevaETD [{}] ",po,posicion,nuevaETD ,e);
		} finally {
			ConexionDB.devolver(con);
		}
		return num_insert;
	}
	
}
