package com.srm.pli.bo;

import java.io.Serializable;

import com.truper.infra.businessEntities.BaseBusinessEntity;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class BeanPlanners extends BaseBusinessEntity  implements Serializable {

	private static final long serialVersionUID = -6821330090939929662L;
	
	private String idPlaneador;
	private String nombre;
	private String [] correos;
	private String gerente;
	private String correoGerente;
	private String identificadorPlaneador;
	private String identificadorGerente;
	
	/** Valor control de Puertos por Confirmador */
	private String status;
	
}

