package com.srm.pli.services;

import com.srm.app.response.vo.ResponseEmbarqueDirectosVO;
import com.srm.pli.bo.ParametrosIndexBean;

public interface EmbarquesDirectosService
{
	ResponseEmbarqueDirectosVO getInformacionToBuildExcelWithSAR(ParametrosIndexBean parametrosIndexBean);
}
