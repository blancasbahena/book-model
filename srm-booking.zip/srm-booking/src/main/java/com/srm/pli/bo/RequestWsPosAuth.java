package com.srm.pli.bo;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.ResourceBundle;

import javax.validation.constraints.NotBlank;

import org.apache.commons.lang3.StringEscapeUtils;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.jfree.util.Log;

import com.srm.pli.dao.SAR_CDI_DAO;
import com.srm.pli.helper.FormatSAR;
import com.srm.pli.helper.FormatSARHelper;
import com.srm.pli.utils.Constantes;
import com.srm.pli.utils.FuncionesComunesPLI;
import com.srm.pli.utils.PropertiesDb;
import com.truper.businessEntity.BeanTiposDeCambio;
import com.truper.businessEntity.ContenedorCDI;
import com.truper.businessEntity.ProductoBean;
import com.truper.businessEntity.SAR;
import com.truper.businessEntity.SARDetalle;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import lombok.extern.slf4j.Slf4j;


@Getter
@Setter
public class RequestWsPosAuth implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String password;
	private String username;
	private String token;

		
}
