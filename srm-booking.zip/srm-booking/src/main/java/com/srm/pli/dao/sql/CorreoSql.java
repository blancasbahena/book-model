package com.srm.pli.dao.sql;

public class CorreoSql {

	public static final String SELECT_CORREOS_TIPO;

	static {
		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT DISTINCT correo ");
		sql.append(" FROM   cdiCorreos ");
		sql.append(" WHERE  tipo = ? ");
		SELECT_CORREOS_TIPO = sql.toString();
	}

}
