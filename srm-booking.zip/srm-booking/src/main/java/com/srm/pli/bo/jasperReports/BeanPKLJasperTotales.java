package com.srm.pli.bo.jasperReports;

import java.util.ArrayList;

import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

public class BeanPKLJasperTotales {
	private ArrayList<BeanPKLJasperDetalles> detalles;
	private String madera;
	private String paisOrigen;
	private String cantidad;
	private String cartones;
	private String pesoNeto;
	private String pesoBruto;
	private String volumen;
	private String contenedor;
	
	public void setDetalles(ArrayList<BeanPKLJasperDetalles> detalles) {
		this.detalles = detalles;
	}
	
	public JRDataSource getDetalles() {
		return new JRBeanCollectionDataSource(detalles);
	}

	public String getMadera() {
		return madera;
	}

	public void setMadera(String madera) {
		this.madera = madera;
	}

	public String getPaisOrigen() {
		return paisOrigen;
	}

	public void setPaisOrigen(String paisOrigen) {
		this.paisOrigen = paisOrigen;
	}

	public String getCantidad() {
		return cantidad;
	}

	public void setCantidad(String cantidad) {
		this.cantidad = cantidad;
	}

	public String getCartones() {
		return cartones;
	}

	public void setCartones(String cartones) {
		this.cartones = cartones;
	}

	public String getPesoNeto() {
		return pesoNeto;
	}

	public void setPesoNeto(String pesoNeto) {
		this.pesoNeto = pesoNeto;
	}

	public String getPesoBruto() {
		return pesoBruto;
	}

	public void setPesoBruto(String pesoBruto) {
		this.pesoBruto = pesoBruto;
	}

	public String getVolumen() {
		return volumen;
	}

	public void setVolumen(String volumen) {
		this.volumen = volumen;
	}

	public String getContenedor() {
		return contenedor;
	}

	public void setContenedor(String contenedor) {
		this.contenedor = contenedor;
	}
	

	
}
