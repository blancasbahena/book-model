package com.srm.pli.helper;

import com.srm.pli.utils.FuncionesComunesPLI;
import com.truper.businessEntity.CDIDocumentosBean;

public class FormatCdiDocumento{

	
	private Integer 	sar;
	private String  	numero;
	private Integer 	fecha;
	private Boolean 	esGenerado;
	private String  	pos;
	private String  	tipo;
	private Double 		packagesAmpara;
	private Boolean  	embarcaMadera;
	private String  	observaciones;
	private String  	representanteLegal;
	private Double 		version;
	private String 		ruta;
	private String 		nombreArch;
	private Integer		tipoMoneda;
	private String		nombreUsuario;
	private Integer		fechaCreacion;
	private Boolean		aprobadoSDI;
	private Integer		fechaUpdate;
	private String 		usuarioUpdate;
	private Integer		prioridad;
	private String		fechaCrea;
	private String		rutaArch;
	private String		comentarioRechazo;
	private String		usuarioRechazo;
	private Integer		fechaRechazo;
	private Double		fechaRechazoLong;	
	
	public  FormatCdiDocumento(CDIDocumentosBean bean) {
		
		sar = bean.getSar();
		numero = bean.getNumero();
		fecha	= bean.getFecha();	
		esGenerado = bean.getEsGenerado();
		pos= bean.getPos();
		tipo= bean.getTipo();
		packagesAmpara= bean.getPackagesAmpara();
		embarcaMadera= bean.getEmbarcaMadera();
		observaciones= bean.getObservaciones();
		representanteLegal= bean.getRepresentanteLegal();
		version= bean.getVersion();
		ruta= bean.getRuta();
		tipoMoneda= bean.getTipoMoneda();
		nombreUsuario= bean.getNombreUsuario();		
		nombreArch= bean.getEsGenerado() ? bean.getNombreArch() : bean.getNombreUsuario();
		fechaCreacion= bean.getFechaCreacion();
		aprobadoSDI= bean.esAprobadoSDI();
		fechaUpdate= bean.getFechaUpdate();
		usuarioUpdate= bean.getUsuarioUpdate();
		prioridad= bean.getPrioridad();
		fechaCrea= FuncionesComunesPLI.formateaFecha(fechaCreacion);
		comentarioRechazo = bean.getComentarioRechazo();
		usuarioRechazo = bean.getUsuarioRechazo();
		fechaRechazo = bean.getFechaRechazo();
		//rutaArch= bean.get
		
		String rutaApache = "";
		String tmp = ruta.substring(4);
		tmp = tmp.replace("\\\\", "/");
		tmp = tmp.replace("\\", "/");
		rutaApache+="http://"+tmp+bean.getNombreArch();
		
		rutaArch=rutaApache;
		
	}




	public Integer getSar() {
		return sar;
	}
	public void setSar(Integer sar) {
		this.sar = sar;
	}
	public String getNumero() {
		return numero;
	}
	public void setNumero(String numero) {
		this.numero = numero;
	}
	public Integer getFecha() {
		return fecha;
	}
	public void setFecha(Integer fecha) {
		this.fecha = fecha;
	}
	public Boolean getEsGenerado() {
		return esGenerado;
	}
	public void setEsGenerado(Boolean esGenerado) {
		this.esGenerado = esGenerado;
	}
	public String getPos() {
		return pos;
	}
	public void setPos(String pos) {
		this.pos = pos;
	}
	public String getTipo() {
		return tipo;
	}
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	public Double getPackagesAmpara() {
		return packagesAmpara;
	}
	public void setPackagesAmpara(Double packagesAmpara) {
		this.packagesAmpara = packagesAmpara;
	}
	public Boolean getEmbarcaMadera() {
		return embarcaMadera;
	}
	public void setEmbarcaMadera(Boolean embarcaMadera) {
		this.embarcaMadera = embarcaMadera;
	}
	public String getObservaciones() {
		return observaciones;
	}
	public void setObservaciones(String observaciones) {
		this.observaciones = observaciones;
	}
	public String getRepresentanteLegal() {
		return representanteLegal;
	}
	public void setRepresentanteLegal(String representanteLegal) {
		this.representanteLegal = representanteLegal;
	}
	public Double getVersion() {
		return version;
	}
	public void setVersion(Double version) {
		this.version = version;
	}
	public String getRuta() {
		return ruta;
	}
	public void setRuta(String ruta) {
		this.ruta = ruta;
	}
	public String getNombreArch() {
		return nombreArch;
	}
	public void setNombreArch(String nombreArch) {
		this.nombreArch = nombreArch;
	}
	public Integer getTipoMoneda() {
		return tipoMoneda;
	}
	public void setTipoMoneda(Integer tipoMoneda) {
		this.tipoMoneda = tipoMoneda;
	}
	public String getNombreUsuario() {
		return nombreUsuario;
	}
	public void setNombreUsuario(String nombreUsuario) {
		this.nombreUsuario = nombreUsuario;
	}
	public Integer getFechaCreacion() {
		return fechaCreacion;
	}
	public void setFechaCreacion(Integer fechaCreacion) {
		this.fechaCreacion = fechaCreacion;
	}
	public Boolean getAprobadoSDI() {
		return aprobadoSDI;
	}
	public void setAprobadoSDI(Boolean aprobadoSDI) {
		this.aprobadoSDI = aprobadoSDI;
	}
	public Integer getFechaUpdate() {
		return fechaUpdate;
	}
	public void setFechaUpdate(Integer fechaUpdate) {
		this.fechaUpdate = fechaUpdate;
	}
	public String getUsuarioUpdate() {
		return usuarioUpdate;
	}
	public void setUsuarioUpdate(String usuarioUpdate) {
		this.usuarioUpdate = usuarioUpdate;
	}
	public Integer getPrioridad() {
		return prioridad;
	}
	public void setPrioridad(Integer prioridad) {
		this.prioridad = prioridad;
	}
	public String getFechaCrea() {
		return fechaCrea;
	}
	public void setFechaCrea(String fechaCrea) {
		this.fechaCrea = fechaCrea;
	}
	public String getRutaArch() {
		return rutaArch;
	}
	public void setRutaArch(String rutaArch) {
		this.rutaArch = rutaArch;
	}
	public String getComentarioRechazo() {
		return comentarioRechazo;
	}
	public void setComentarioRechazo(String comentarioRechazo) {
		this.comentarioRechazo = comentarioRechazo;
	}
	public String getUsuarioRechazo() {
		return usuarioRechazo;
	}
	public void setUsuarioRechazo(String usuarioRechazo) {
		this.usuarioRechazo = usuarioRechazo;
	}
	public Integer getFechaRechazo() {
		return fechaRechazo;
	}
	public void setFechaRechazo(Integer fechaRechazo) {
		this.fechaRechazo = fechaRechazo;
	}
	public Double getFechaRechazoLong() {
		return fechaRechazoLong;
	}
	public void setFechaRechazoLong(Double fechaRechazoLong) {
		this.fechaRechazoLong = fechaRechazoLong;
	}		
	
}
