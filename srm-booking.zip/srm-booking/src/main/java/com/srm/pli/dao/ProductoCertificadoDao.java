package com.srm.pli.dao;

import static com.srm.pli.dao.sql.ProductoCertificadoSql.SELECT_PRODUCTOS_CERTIFICADO;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashSet;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.srm.pli.db.ConexionDB;
import com.truper.utils.sql.UtilsSQL;

public class ProductoCertificadoDao {

	private static final ProductoCertificadoDao instance = new ProductoCertificadoDao();
	private static final Logger LOGGER = LogManager.getRootLogger();

	private ProductoCertificadoDao() {
	}

	public static ProductoCertificadoDao getInstance() {
		return instance;
	}

	public HashSet<Integer> selectProductoCertificado(HashSet<Integer> materiales) {
		if (materiales == null || materiales.isEmpty())
			return null;

		HashSet<Integer> respuesta = null;
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();
			try (Statement pst = con.createStatement()) {
				String in = UtilsSQL.convierteToIN(materiales);
				String query = SELECT_PRODUCTOS_CERTIFICADO.replace("binaryFractal", in);
				try (ResultSet rs = pst.executeQuery(query)) {
					respuesta = new HashSet<>();
					while (rs.next()) {
						Integer material = rs.getInt("material");
						respuesta.add(material);
					}
				}
			}
		} catch (SQLException sqle) {
			sqle.printStackTrace();
			LOGGER.error(sqle);
			ConexionDB.renovar(con);
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error(e);
		} finally {
			ConexionDB.devolver(con);
		}
		return respuesta;
	}

}
