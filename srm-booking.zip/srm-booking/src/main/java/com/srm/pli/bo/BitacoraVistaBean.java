package com.srm.pli.bo;

import com.truper.businessEntity.BitacoraIDAStatusBean;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class BitacoraVistaBean extends BitacoraIDAStatusBean {
	private static final long serialVersionUID = 6987646759490082970L;
	private String lastUser;
	private String lastModification;
	private String folioVista;
	private boolean directo;
	private String nombreUserLast;
}