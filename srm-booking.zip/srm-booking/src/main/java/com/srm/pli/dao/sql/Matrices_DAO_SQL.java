package com.srm.pli.dao.sql;

public class Matrices_DAO_SQL {
	
	public static final String SELECT_AUTORIZADO_SDI;
	
	static {
		StringBuilder sql = new StringBuilder();
		sql.append("SELECT c.aprobado ");
		sql.append(" FROM   cdisar s WITH (NOLOCK) ");
		sql.append("       LEFT JOIN cdidocumentossdi d WITH (NOLOCK)  ");
		sql.append("              ON s.proveedor = d.proveedor ");
		sql.append("                 AND s.booking = d.booking ");
		sql.append("                 AND s.versionsetdocumentos = d.versionsdi ");
		sql.append("       LEFT JOIN cdicontrolsdi c WITH (NOLOCK) ");
		sql.append("              ON d.id = c.iddocumentos ");
		sql.append(" WHERE  s.folio = ? ");
		SELECT_AUTORIZADO_SDI = sql.toString();
	}

}
