package com.srm.pli.schedulers.jobs;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import com.srm.pli.services.CdiNotificationBuilderServices;
import com.srm.pli.utils.PropertiesDb;

import lombok.extern.log4j.Log4j2;

@Log4j2
public class ReleasedSarsByPlanningAndShippingJob implements Job {

	@Override
	public void execute(JobExecutionContext context) throws JobExecutionException {
		log.info("Inicia job ReleasedSarsByPlanningAndShippingJob");
		try {
			if (PropertiesDb.getInstance().getBoolean("job.releasedSarsByPlanningAndShipping.activo")) {
				CdiNotificationBuilderServices.getInstance().releasedSARsByPlanningAndShipping();
			} else {
				log.info("job ReleasedSarsByPlanningAndShippingJob NO activo");
			}
		} catch (Exception e) {
			JobExecutionException e2 = new JobExecutionException (e);
			e2.setRefireImmediately (false); // para descartar el Job y seguir con el siguiente
			throw e2;
		}finally{
			log.info("Termina job ReleasedSarsByPlanningAndShippingJob");
		}
	}

}
