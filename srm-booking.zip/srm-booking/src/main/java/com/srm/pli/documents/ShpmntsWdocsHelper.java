package com.srm.pli.documents;

import com.srm.pli.bo.SearchParamsDocs;
import com.truper.utils.string.UtilsString;

public class ShpmntsWdocsHelper {

	private static ShpmntsWdocsHelper instance = null;

	private ShpmntsWdocsHelper() {
	}

	public static ShpmntsWdocsHelper getInstance() {
		if (instance == null)
			instance = new ShpmntsWdocsHelper();
		return instance;
	}

	public boolean isFiltroValidoParaBuscarEnTodos(SearchParamsDocs filtro) {
		if (isValorIntegerValido(filtro.getFolio()))
			return true;
		if (UtilsString.isStringValida(filtro.getProveedor()))
			return true;
		if (UtilsString.isStringValida(filtro.getPo()))
			return true;
		if (UtilsString.isStringValida(filtro.getBl()))
			return true;
		if (UtilsString.isStringValida(filtro.getBooking()))
			return true;
		if (UtilsString.isStringValida(filtro.getInvoice()))
			return true;
		if (UtilsString.isStringValida(filtro.getContenedor()))
			return true;
		return false;
	}

	private boolean isValorIntegerValido(Integer valor) {
		return valor != null && valor.intValue() > 0;
	}

}
