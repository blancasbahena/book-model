package com.srm.pli.db;

import java.util.GregorianCalendar;

import com.srm.pli.utils.Utilerias;

/**Class to represent a query string and the processing time it took to execute it.
 * 
 * @author Alejandro B. Salazar
 *	@since June 16, 2006
 */
public class TransactionData {
	public static final boolean STATEMENT_OPENED = false;
	public static final boolean STATEMENT_CLOSED = true;
	public static final boolean CONN_CLOSED_STARTED = true, CONN_CLOSED_NOT_STARTED = false;
	public static final boolean CONN_CLOSED_ENDED = true, CONN_CLOSED_NOT_ENDED = false;
	public static final boolean COMMIT_STARTED = true, COMMIT_NOT_STARTED = false;
	public static final boolean COMMIT_ENDED = true, COMMIT_NOT_ENDED = false;
	public static final boolean ROLLBACK_STARTED = true, ROLLBACK_NOT_STARTED = false;
	public static final boolean ROLLBACK_ENDED = true, ROLLBACK_NOT_ENDED = false;
	public static final boolean AUTOCOMMIT_STARTED = true, AUTOCOMMIT_NOT_STARTED = false;
	public static final boolean AUTOCOMMIT_ENDED = true, AUTOCOMMIT_NOT_ENDED = false;
	public static final boolean AUTOCOMMIT = true, NO_AUTOCOMMIT = false;
	
	private String sql = null;
	private GregorianCalendar startTime = null;
	private GregorianCalendar endTime = null;
	private boolean statementClosed = false;
	private boolean[] connClosed = new boolean[]{CONN_CLOSED_NOT_STARTED, CONN_CLOSED_NOT_ENDED};	//started, ended
	private boolean[] commit = new boolean[]{COMMIT_NOT_STARTED, COMMIT_NOT_ENDED};						//started, ended
	private boolean[] rollback = new boolean[]{ROLLBACK_NOT_STARTED, ROLLBACK_NOT_ENDED};				//started, ended
	private boolean[] autoCommit = new boolean[]{AUTOCOMMIT_NOT_STARTED, AUTOCOMMIT_NOT_ENDED};		//started, ended
	private boolean autoCommitTo = AUTOCOMMIT;
	
	/**Constructor to initialize a query string representation.*/
	public TransactionData(){
		super();
	}
	
	/**Method that returns the query string for this transaction representation.<br>
	 * @return the query string for this transaction representation.
	 */
	public String getQueryString(){
		return sql;
	}
	
	/**Method that sets the query string for this transaction representation.<br>
	 * @param sql the query string to set for this transaction representation.
	 */
	public void setQueryString(String sql){
		this.sql = sql;
	}
	
	/**Method that retrieves a GregorianCalendar representing the start time of the last execution. Null
	 * if not even 1 time executed.
	 * @return The start time of the last execution.
	 */
	public GregorianCalendar getStartTime(){
		return startTime;
	}
	
	/**Method that registers an starting process time for the query transaction represented by this object
	 * in the last transaction.<br>
	 * If <tt>startTime == null</tt> the starting process time is set to new GregorianCalendar().
	 * 
	 * @param startTime The time to set for this query transaction representation.
	 */
	public void setStartTime(GregorianCalendar startTime){
		if(startTime==null){
			this.startTime = new GregorianCalendar();
		}else{
			this.startTime = startTime;
		}
		this.endTime = null;
	}
	
	/**Method that retrieves a GregorianCalendar representing the end time of the last execution, null if
	 * not finished yet.
	 * @return The end time of the last execution.
	 */
	public GregorianCalendar getEndTime(){
		return endTime;
	}
	
	/**Method that registers an ending process time for the query transaction represented by this object
	 * in the last transaction.<br>
	 * If <tt>endTime == null</tt> the ending process time is set to new GregorianCalendar().
	 * 
	 * @param endTime The time to set for this query transaction representation.
	 */
	public void setEndTime(GregorianCalendar endTime){
		if(endTime==null){
			this.endTime = new GregorianCalendar();
		}else{
			this.endTime = endTime;
		}
	}
	
	public void setStatementClosed(boolean status){	statementClosed = status;	}
	public boolean isStatementClosed(){					return statementClosed;		}
	
	public void setConnectionClosedStarted(boolean status){	connClosed[0] = status;	if(connClosed[0]){ connClosed[1]=false; }	}
	public void setConnectionClosedEnded(boolean status){		connClosed[1] = status;		}
	public boolean isConnectionClosedStarted(){	return connClosed[0];			}
	public boolean isConnectionClosedEnded(){		return connClosed[1];			}
	
	public void setCommitStarted(boolean status){	commit[0] = status;	if(commit[0]){ commit[1]=false; }	}
	public void setCommitEnded(boolean status){		commit[1] = status;		}
	public boolean isCommitStarted(){	return commit[0];			}
	public boolean isCommitEnded(){		return commit[1];			}
	
	public void setRollbackStarted(boolean status){		rollback[0] = status;	if(rollback[0]){ rollback[1]=false; }	}
	public void setRollbackEnded(boolean status){		rollback[1] = status;		}
	public boolean isRollbackStarted(){		return rollback[0];			}
	public boolean isRollbackEnded(){		return rollback[1];			}
	
	public void setAutocommitStarted(boolean status){		autoCommit[0] = status;		if(autoCommit[0]){ autoCommit[1]=false; }	}
	public void setAutocommitEnded(boolean status){			autoCommit[1] = status;		}
	public boolean isAutocommitStarted(){		return autoCommit[0];			}
	public boolean isAutocommitEnded(){			return autoCommit[1];			}
	
	public void setAutocommitTo(boolean type){	autoCommitTo = type;	}
	public boolean isAutocommit(){	return autoCommitTo;		}
	
	/**Method to return the execution time of this transaction.
	 * @return the execution time.
	 */
	public String getTextInterval(){
		if(startTime==null){
			return "What the hell";
		}else if(endTime==null){
			return "La transaccion lleva: " + Utilerias.formatTime(new GregorianCalendar().getTimeInMillis()-startTime.getTimeInMillis());
		}else{
			return "La transaccion duro: " + Utilerias.formatTime(endTime.getTimeInMillis()-startTime.getTimeInMillis());
		}
	}
	
	public Long getInterval(){
		if(startTime==null){
			return null;
		}else if(endTime==null){
			return new GregorianCalendar().getTimeInMillis()-startTime.getTimeInMillis();
		}else{
			return endTime.getTimeInMillis()-startTime.getTimeInMillis();
		}
	}
	
	/**Method that returns an String with the name(s) of the table(s) involved in this query string
	 * representation.<br>
	 * @return a String with name(s) of table(s) involved in this query string.
	 */
	public String getTableInvolved(){
		String lowerCaseSQL = sql.toLowerCase();
		boolean selectType = lowerCaseSQL.indexOf("select")!=-1;
		boolean insertType = lowerCaseSQL.indexOf("insert")!=-1;
		boolean updateType = lowerCaseSQL.indexOf("update")!=-1;
		boolean deleteType = lowerCaseSQL.indexOf("delete")!=-1;
		
		String table = null;
		
		if(insertType || updateType || deleteType || selectType){
			String subSql = "";
			if(insertType){
				subSql = sql.substring(lowerCaseSQL.indexOf("into") + 4).trim();
			}else if(updateType){
				subSql = sql.substring(lowerCaseSQL.indexOf("update") + 6).trim();
			}else if(deleteType){
				if(lowerCaseSQL.indexOf("from")!=-1){
					subSql = sql.substring(lowerCaseSQL.indexOf("from") + 4).trim();
				}else{
					subSql = sql.substring(lowerCaseSQL.indexOf("delete") + 6).trim();
				}
			}else{// if(selectType){
				subSql = sql.substring(lowerCaseSQL.indexOf("from") + 4).trim();
			}

			//looking for the first space after the table name
			int spaceIndex = subSql.indexOf(" ");
			//if not found, then table name is the last thing on this subQuery
			if(spaceIndex==-1){
				table = subSql.substring(0);
			}else{
				table = subSql.substring(0, spaceIndex).trim();
			}
		}else{
			table = sql;
		}
		
		return table;
	}
	
	/**Method used to reset the flags for a fresh new status logging.*/
	public void cleanFlags(){
		statementClosed = false;
		connClosed[0] = CONN_CLOSED_NOT_STARTED;	connClosed[1] = CONN_CLOSED_NOT_ENDED;
		commit[0] = COMMIT_NOT_STARTED;				commit[1] = COMMIT_NOT_ENDED;
		rollback[0] = ROLLBACK_NOT_STARTED;			rollback[1] = ROLLBACK_NOT_ENDED;
		autoCommit[0] = AUTOCOMMIT_NOT_STARTED;	autoCommit[1] = AUTOCOMMIT_NOT_ENDED;
		autoCommitTo = AUTOCOMMIT;
	}
	
	/**Method that resets this object for new data*/
	public void reset(){
		sql = null;
		startTime = null;
		endTime = null;
	}
	
}
