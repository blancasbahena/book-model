package com.srm.pli.dao;
import static com.srm.fungandrui.cdi.queries.CdiSarQuery.PENDING_UPDATESUPPLIER_ByBOOKING;
import static com.srm.pli.dao.sql.SAR_CDI_DAO_SQL.INSERT_CONSOLIDADO_HISTORICO;
import static com.srm.pli.dao.sql.SAR_CDI_DAO_SQL.SELECT_CONTROL_SDI_VISTA_SELECTOR;
import static com.srm.pli.dao.sql.SAR_CDI_DAO_SQL.SELECT_SAR_DETALLE_POR_LLAVE;
import static com.srm.pli.dao.sql.SAR_CDI_DAO_SQL.getNullStringAsEmpty;
import static com.srm.pli.dao.sql.SarDetailDaoSql.UPDATE_SAR_DETAIL_ITEMS_DIRECTOS;
import static com.srm.pli.dao.sql.SarDetailDaoSql.SELECT_FACTURA_BY_ID_AND_CONDITION;
import static com.srm.fungandrui.trafico.queries.ConsolidadosSQL.ALL_CONSOLIDATED_COMPLETE;	
import static com.srm.fungandrui.trafico.queries.ConsolidadosSQL.VALIDATE_DOCUMENTS_CONSOLIDADOS;	
import static com.srm.fungandrui.trafico.queries.ConsolidadosSQL.GET_CONSOLIDADOS;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.sql.Types;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

import javax.servlet.ServletException;
import javax.servlet.http.HttpSession;

import com.srm.fungandrui.cdi.queries.CdiSarQuery;	
import com.srm.fungandrui.facturacion.models.ControlEmbarqueModel;	
import com.srm.fungandrui.facturacion.queries.QueriresFacturacionSQL;
import com.srm.fungandrui.lineamientos.dto.GrdLineamientosAccionesDto;
import com.srm.fungandrui.parcelmobi.models.RequestUpdateSupplierModel;
import com.srm.fungandrui.sc.model.ResetBean;
import com.srm.fungandrui.sc.model.ResetVO;
import com.srm.fungandrui.trafico.models.TraficoConsolVO;
import com.srm.pli.bo.BeanArregloPuertosDestino;
import com.srm.pli.bo.BeanSendDocumentsTEL;
import com.srm.pli.bo.BeanVistaDocumentos;
import com.srm.pli.bo.CdiDocumentBO;
import com.srm.pli.bo.FasesSARBO;
import com.srm.pli.bo.OrdenCdiBO;
import com.srm.pli.bo.ProveedorXplaneadorBO;
import com.srm.pli.bo.ReporteCambiosETDBooking;
import com.srm.pli.bo.SarBO;
import com.srm.pli.bo.SarConsolBO;
import com.srm.pli.bo.SarDetalleBO;
import com.srm.pli.bo.SarDetalleReporte;
import com.srm.pli.bo.SarRMChat_BO;
import com.srm.pli.bo.SarRM_BO;
import com.srm.pli.bo.SearchParamsDocs;
import com.srm.pli.bo.SearchParamsSARs;
import com.srm.pli.constants.ConsultasConstants;
import com.srm.pli.db.ConexionDB;
import com.srm.pli.helper.MetaSqlQuery;
import com.srm.pli.helper.PriceReleaseHelper;
import com.srm.pli.servlet.Proveedores;
import com.srm.pli.utils.DateUtils;
import com.srm.pli.utils.FuncionesComunesPLI;
import com.srm.pli.utils.PropertiesLoader;
import com.srm.pli.utils.SarsUtils;
import com.srm.pli.utils.TelServiceClient;
import com.srm.pli.utils.Utilerias;
import com.srm.pli.utils.UtilsSQL;
import com.truper.businessEntity.BeanBL;
import com.truper.businessEntity.BeanControlSDI;
import com.truper.businessEntity.BeanDocumentosSDI;
import com.truper.businessEntity.BeanFactura;
import com.truper.businessEntity.BeanItinerarioNaviera;
import com.truper.businessEntity.BeanMRPData;
import com.truper.businessEntity.BeanNotificaciones;
import com.truper.businessEntity.BeanNotificacionesDetalleOrden;
import com.truper.businessEntity.BeanOtrosDocumentos;
import com.truper.businessEntity.BeanPL;
import com.truper.businessEntity.BeanPuerto;
import com.truper.businessEntity.BeanSarChat;
import com.truper.businessEntity.BeanValidacionesCambioPassword;
import com.truper.businessEntity.CDIDatosFacturaBean;
import com.truper.businessEntity.CdiBloqueosBean;
import com.truper.businessEntity.CdiCatManagers;
import com.truper.businessEntity.CdiHistoricoRevisionBean;
import com.truper.businessEntity.CdiManagersPlanners;
import com.truper.businessEntity.DtoConsultaSar;
import com.truper.businessEntity.ImportacionesProveedoresBean;
import com.truper.businessEntity.Naviera;
import com.truper.businessEntity.OrdenCDIIncompletaEnSAR;
import com.truper.businessEntity.PoRedFlag;
import com.truper.businessEntity.ProductoBean;
import com.truper.businessEntity.ReferenceNumberBean;
import com.truper.businessEntity.RevisionGDR;
import com.truper.businessEntity.SAR;
import com.truper.businessEntity.SARConsolidados;
import com.truper.businessEntity.SARConsolidadosHistorico;
import com.truper.businessEntity.SARDetalle;
import com.truper.businessEntity.SARDetalleModificado;
import com.truper.businessEntity.SARDetalleSimulador;
import com.truper.businessEntity.SARHistoricoBooking;
import com.truper.businessEntity.SARHistoryLogBean;
import com.truper.businessEntity.SARModificado;
import com.truper.businessEntity.UserBean;
import com.truper.businessEntity.UserProfileBean;
import com.truper.businessEntity.UsuarioBean;
import com.truper.trafico.ConsolidacionFolioDetalleDTO;	
import com.truper.trafico.ConsolidacionFolioDto;
import com.truper.utils.date.UtilsFechas;
import com.truper.utils.number.UtilsNumero;
import com.truper.utils.string.UtilsString;

import lombok.Getter;
import lombok.extern.log4j.Log4j2;

@Getter
@Log4j2
public class SAR_CDI_DAO extends DAO {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2188051538989146333L;

	private static SAR_CDI_DAO instance = null;
	
	private static final String CONTROL_REFERENCE = new StringBuilder("	SELECT ")
	.append("		s.folio, ")
	.append("		s.status, ")
	.append("		s.needAuthImpDir, ")
	.append("		s.aprobadoDirImportaciones,")
	.append("		s.aprobadoConfMngr,")
	.append("		s.consolidado,")
	.append("		s.folioConsolidado,")
	.append("		s.booking,")
	.append("		s.enRevisionConfirmFinal,")
	.append("		s.fechaConfirmacionFinal,")
	.append("		s.aprobadoProveedor,")
	.append("		s.versionSetDocumentos,")
	.append("		c.booking  as bookingCont,")
	.append("		c.proveedor, ")
	.append("		ISNULL(c.aprobado, 0) as aprobado, ")
	.append("		ISNULL(r.folio, 0) as folioRefNum,")
	.append("		r.referenceNumber , s.preciosRevisados ")
	.append("	FROM cdiSAR s WITH (NOLOCK) ")
	.append("		LEFT JOIN cdiControlSDI c WITH (NOLOCK) ")
	.append("			ON s.versionSetDocumentos = c.versionSDI ")
	.append("			AND s.booking = c.booking ")
	.append("			AND s.proveedor = c.proveedor  ")
	.append("		LEFT JOIN cdiReferenceNumber r WITH (NOLOCK)  ON s.folio = r.folio").toString();
	
	private static final StringBuilder select_sar = new StringBuilder
			       ("SELECT sar.folio, sar.proveedor, sar.puertoSalida, ")
			.append(" sar.naviera, sar.fechaEmbarque, sar.consolidado, sar.status, " + " sar.fechaSolAprobacion,   ")
			.append(" sar.usuarioSolAprobacion, sar.fechaUltAprobRechazo, ")
			.append( " sar.usuarioApruebaPlanning, sar.usuarioApruebaRechaza, sar.tipoContenedor, ")
			.append(" sar.prioridad,   ")
			.append(" sar.barcoSugerido, sar.viaje, sar.puertoDescarga, ")
			.append(" sar.contenedor, sar.booking, sar.etd, sar.etdFinal,sar.etdFinalModificada, ")
			.append(" sar.comentarioCancelacion, sar.folioConsolidado, sar.transporte, ")
			.append(" sar.comentarioPlanner, sar.comentarioShipping, sar.esSinPO, ")
			.append(" sar.eta, sar.bl, sar.aprobadoPorCompras, sar.tipoRetraso, ")
			.append(" sar.fechaCreacion, sar.esAereo, ")
			.append(" sar.fueModificadoProveedor, sar.aerolinea, sar.avion, ")
			.append(" sar.llegadaavion, sar.aceptadoConDiferencias, sar.paisDestino, ")
			.append(" sar.cargoAProveedor, ")
			.append(" sar.otraAerolinea, sar.aprobadoProveedor, sar.esmultiple, ")
			.append(" sar.mandante, sar.aprobadoSDI, sar.cerradoDocumentosProveedor,")
			.append(" sar.fechaCierreDocumentosProveedor, sar.fechaAprobadoSDI, ")
			.append(" sar.comentarioTruperBooking, sar.fechaUltimoRechazo,  ")
			.append(" sar.fechaUltimaCorreccion, sar.usuarioUltimoRechazoAceptacion, ")
			.append(" sar.revision, sar.fecIniPlanning, sar.tinyFecIniPlanning, ")
			.append(" sar.fecIniShipping, sar.tinyFecIniShipping, sar.fecIniConsol, ")
			.append(" sar.tinyFecIniConsol, sar.fecIniBooking, sar.tinyFecIniBooking, ")
			.append(" sar.fecIniSDI, sar.tinyFecIniSDI, sar.fecIniEmbarque, ")
			.append(" sar.tinyFecIniEmbarque, sar.rechazoDocumentosSDI, sar.diferenciaMRP, ")
			.append(" sar.cargaArchivoMRP, sar.archivoMRP, ")
			.append(" sar.needAuthImpDir, sar.aprobadoDirImportaciones, ")
			.append(" sar.userApruebaDirImportaciones, sar.fechaApruebaDirImportaciones, ")
			.append(" sar.commentForImpDir, ")
			.append(" sar.impDirComments, sar.adelantoAtrasoETDImpDir, sar.cargadoMRP, ")
			.append(" sar.etdProveedor, sar.notificacionMRP, sar.enRevisionConfirmFinal, ")
			.append(" sar.commentRevFinalConfirm, sar.aceptadoRevFinalConfirm, ")
			.append("sar.usrAceptaRechazaRevFinal, sar.numRevFinal, sar.aplicaBitacoraImpDir, ")
			.append(" sar.bitacoraImpDirCerrada, sar.fecCierreBitacoraImpDir, ")
			.append("sar.tieneSimulador, sar.preciosLiberados, sar.versionSetDocumentos, ")
			.append("sar.preciosEnRevision, sar.enrevisionIDA, ")
			.append(" sar.bitacoraIDA, sar.bitacoraIDACerrada, ")
			.append(" sar.fechaConfirmacionFinal ,")
			.append(" sar.bookingUpdateSupplier ,")
			.append(" sar.carrierUpdateSupplier ,")
			.append(" sar.dateETDFinalUpdateSupplier ,")
			.append(" sar.dateUpdateSupplier, ")
			.append(" sar.goods_ready_date goodsReadyDate, ")
			.append(" sar.goods_are_ready goodsAreReady, ")
			.append(" sar.isRechazado,")
			.append(" sar.gdrEnRevision gdrEnRevision,")
			.append(" sar.referenciaContenedorProveedor referenciaContenedorProveedor,")
			.append(" sar.tinyFechIniProfileApproved,")
			.append(" sar.guideline,")
			.append(" sar.approvedConfirmationManager,")
			.append(" sar.approvedSrManager,")
			.append(" sar.approvedDirector, ")
			.append(" sar.approvedOverStock, ")
			.append(" sar.commentProfiles, ")
			.append(" sar.releaseRequirementsBC, ")
			.append(" sar.aprobadoConfMngr, sar.userApruebaConfMngr, sar.fechaApruebaConfMngr, sar.commentForConfMngr, ")
			.append(" sar.fecIniConfMngr, sar.tinyFecIniConfMngr, sar.confMngrComments, ")
			.append(" sar.messageGRDrechazo, sar.messageGRDaprobacion, sar.approvalGRDlineacion, sar.statusAnteriorGRD ")
			.append(" FROM cdiSAR sar")
			.append(" WHERE   1=1   ");

	private static final StringBuilder SELECT_MANAGERS = new StringBuilder (" SELECT id, userName ")
		.append(" FROM cdiCatManagers WITH (NOLOCK) ")
		.append(" WHERE active = 1   ");
	
	private static final StringBuilder SELECT_PLANNERS_BY_MANAGER = new StringBuilder (" SELECT idPlanner ")
			.append(" FROM cdiManagersPlanners WITH (NOLOCK) ")
			.append(" WHERE idManager = ?   ");
	
	private static final StringBuilder SELECT_SAR_SEND_DOCUMENTS_TEL = new StringBuilder (" SELECT sr.folio, cdi.aprobado, sr.contenedor, sr.booking, fc.nombre numeroFactura ")
			.append(" FROM cdiDocumentosSDI  sdi  inner join cdi_facturas fc on  sdi.id =  fc.id inner join cdisar sr  on     sdi.booking = sr.booking ")
			.append(" and    sdi.proveedor = sr.proveedor ")
			.append("  inner join cdiControlSDI cdi  on     cdi.booking = sr.booking and    cdi.proveedor = sr.proveedor ")
			.append(" where  sr.folio = ? and  sdi.versionFacturas in (select max(versionFacturas) from cdiDocumentosSDI r where  r.booking = sr.booking and r.proveedor = sr.proveedor) ")
			.append(" and  fc.versionDocumento  in (select max(versionDocumento) from cdi_facturas r where  sdi.id =  r.id) ");
			
			
			
	
	public static SAR_CDI_DAO getInstance() {
		if (instance == null) {
			instance = new SAR_CDI_DAO();
		}
		return instance;
	}

	/**
	 * 
	 * @param user  parametros de busqueda
	 * @param todos bandera para obtener todos los usuarios
	 * @return
	 * @throws ServletException
	 */
	public static List<UserBean> dameUsuarios(UserBean user) throws ServletException {
		List<UserBean> lstUsers = new ArrayList<UserBean>();
		Connection con = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		DAOUtils utils = new DAOUtils();

		StringBuilder select = new StringBuilder();
		select.append("SELECT id, userName, pwd, lastPwdChangeDate, changePwd,");
		select.append(" realName, userEmail, userProfile, active, userType,");
		select.append(" creationDate, creationUser");
		select.append(" FROM cdiUsers WHERE 1=1");

		utils.setSelect(true);

		try {
			con = ConexionDB.dameConexion();
			if (user != null) {
				String userName = user.getUserName() == null ? "" : user.getUserName();
				if (!"*".equals(userName)) {
					select.append(utils.ajustaColumna(" AND userName = ?"));
				}
				if (user.getUserProfile() != null) {
					select.append(utils.ajustaColumna(" AND userProfile = ?"));
				}
				if (user.isActive() != null) {
					select.append(utils.ajustaColumna(" AND active = ?"));
				}
				if (user.getUserType() != null) {
					select.append(utils.ajustaColumna(" AND userType = ?"));
				}
			}
			pst = con.prepareStatement(select.toString());
			int cont = 1;

			utils.inicializaQuery(select.toString());
			if (user != null) {
				String userName = user.getUserName() == null ? "" : user.getUserName();
				if (!"*".equals(userName)) {
					utils.ajustaParametro(cont++, pst, userName, String.class);
				}
				if (user.getUserProfile() != null) {
					utils.ajustaParametro(cont++, pst, user.getUserProfile(), Integer.class);
				}
				if (user.isActive() != null) {
					utils.ajustaParametro(cont++, pst, user.isActive(), Boolean.class);
				}
				if (user.getUserType() != null) {
					utils.ajustaParametro(cont++, pst, user.getUserType(), Integer.class);
				}
			}
			rs = pst.executeQuery();

			while (rs.next()) {
				UserBean userBean = new UserBean();
				userBean.setIdUser(rs.getInt("id"));
				userBean.setUserName(rs.getString("userName"));
				userBean.setPwd(rs.getString("pwd"));
				userBean.setLastPwdChangeDate(rs.getInt("lastPwdChangeDate"));
				userBean.setCambiarPwd(rs.getBoolean("changePwd"));
				userBean.setRealName(rs.getString("realName"));
				userBean.setUserEmail(rs.getString("userEmail"));
				userBean.setUserProfile(rs.getInt("userProfile"));
				userBean.setActive(rs.getBoolean("active"));
				userBean.setUserType(rs.getInt("userType"));
				userBean.setCreationDate(rs.getLong("creationDate"));
				userBean.setCreationUser(rs.getString("creationUser"));
				lstUsers.add(userBean);
			}
			rs.close();
			pst.close();
		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
				throw new ServletException(ex);
			}
			log.error(e.getMessage(), e);
			throw new ServletException(e);
		} catch (Exception e) {
			e.printStackTrace();
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
				throw new ServletException(ex);
			}
			log.error(e.getMessage(), e);
			throw new ServletException(e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
				throw new ServletException(sqlEx2);
			}
		}
		return lstUsers;
	}

	public static List<UserProfileBean> consultaPerfilUsuario(UserBean user) throws ServletException {
		List<UserProfileBean> lstResult = new ArrayList<UserProfileBean>();
		Connection con = null;
		DAOUtils utils = new DAOUtils();

		StringBuffer query = new StringBuffer();
		query.append("SELECT id, profileName, accessLevel, isSearch, isPlanner,");
		query.append(" isShipping, isBooking,isConsolidationMgr, isImportsDirector,");
		query.append(" editImportsDirector, isMRPMgr, isSupplier, changeProfile,");
		query.append(" readOnly, createUsers, changeOtherPwd, segPOsSinSAR,");
		query.append(" segPOsSinSARSeeAll, segPOsSinSARUploadFile,");
		query.append(" segPOsSinSAREditComments, segPOsSinSAREditStatus,");
		query.append(" isPlanningMgr, sarsSinDocumentos,sarsConDocumentos,");
		query.append(" isAnalistaDocs,isSDP,priceRelease,sinConfirmacionFinal");
		query.append(" ,isManager, isDirector, isAuditoria,ismatriz ");
		query.append(" ,readOnlyShipping, readOnlyBooking, readOnlySarsConDocumentos,veSARDirectos,veSARNormales ");
		query.append(" ,bloqueoDocumentos,revokeFinalConfirmation, daysETDBySupplierBatch,veRequisitosImportacion ");
		query.append(" ,facturacion,entregaATraficoyCXP ");
		query.append(" ,veTruper,veComercio, vePagoFactura, gerenteSrCoberturaI, directorCoberturaI, gerenteConfirmacion");
		query.append(" ,isConfirmationManager, veSettingPOD, vePlannersAssignation, GRDgerenteConfirmacion, GRDgerenteConfirmacionSr, ");
		query.append(" GRDgerenteConfirmacionBO, GRDOnHold ,dcontrolbuyers,dcontrolplanning,dcontrolcanceled,dcontrolclosed");
		query.append(" FROM cdiUserProfiles where 1=1 ");

		utils.setSelect(true);

		try {
			con = ConexionDB.dameConexion();
			if (user.getUserProfile() != null) {
				query.append(utils.ajustaColumna(" and id = ?"));
			}
			try (PreparedStatement pst = con.prepareStatement(query.toString())) {
				int cont = 1;
				utils.inicializaQuery(query.toString());
				if (user.getUserProfile() != null) {
					utils.ajustaParametro(cont++, pst, user.getUserProfile(), Integer.class);
				}
				try (ResultSet rs = pst.executeQuery()) {
					while (rs.next()) {
						UserProfileBean resultado = new UserProfileBean();
						resultado.setIdProfile(rs.getInt("id"));
						resultado.setProfileName(rs.getString("profileName"));
						resultado.setAccessLevel(rs.getInt("accessLevel"));
						resultado.setSearch(rs.getBoolean("isSearch"));
						resultado.setPlanner(rs.getBoolean("isPlanner"));
						resultado.setPlanningMgr(rs.getBoolean("isPlanningMgr"));
						resultado.setShipping(rs.getBoolean("isShipping"));
						resultado.setBooking(rs.getBoolean("isBooking"));
						resultado.setConsolidationMgr(rs.getBoolean("isConsolidationMgr"));
						resultado.setImportsDirector(rs.getBoolean("isImportsDirector"));
						resultado.setEditImportsDirector(rs.getBoolean("editImportsDirector"));
						resultado.setMrpMgr(rs.getBoolean("isMRPMgr"));
						resultado.setSupplier(rs.getBoolean("isSupplier"));
						resultado.setChangeProfile(rs.getBoolean("changeProfile"));
						resultado.setReadOnly(rs.getBoolean("readOnly"));
						resultado.setCreateUsers(rs.getBoolean("createUsers"));
						resultado.setChangeOtherPwd(rs.getBoolean("changeOtherPwd"));
						resultado.setSegPOsSinSAR(rs.getBoolean("segPOsSinSAR"));
						resultado.setSegPOsSinSARAll(rs.getBoolean("segPOsSinSARSeeAll"));
						resultado.setSegPOsSinSARUpload(rs.getBoolean("segPOsSinSARUploadFile"));
						resultado.setSegPOsSinSAREditComments(rs.getBoolean("segPOsSinSAREditComments"));
						resultado.setSegPOsSinSAREditStatus(rs.getBoolean("segPOsSinSAREditStatus"));
						resultado.setSarsSinDocumentos(rs.getBoolean("sarsSinDocumentos"));
						resultado.setSarsConDocumentos(rs.getBoolean("sarsConDocumentos"));
						resultado.setAnalistaSDI(rs.getBoolean("isAnalistaDocs"));
						resultado.setSDP(rs.getBoolean("isSDP"));
						resultado.setPriceRelease(rs.getBoolean("priceRelease"));
						resultado.setManager(rs.getBoolean("isManager"));
						resultado.setDirector(rs.getBoolean("isDirector"));
						resultado.setSinConfirmacionFinal(rs.getBoolean("sinConfirmacionFinal"));
						resultado.setAuditoria(rs.getBoolean("isAuditoria"));
						resultado.setMatriz(rs.getBoolean("ismatriz"));
						resultado.setReadOnlyShipping(rs.getBoolean("readOnlyShipping"));
						resultado.setReadOnlyBooking(rs.getBoolean("readOnlyBooking"));
						resultado.setReadOnlySarsConDocumentos(rs.getBoolean("readOnlySarsConDocumentos"));
						resultado.setVeSARDirecto(rs.getBoolean("veSARDirectos"));
						resultado.setVeSARNormal(rs.getBoolean("veSARNormales"));
						resultado.setBloqueoDocumentos(rs.getBoolean("bloqueoDocumentos"));
						resultado.setRevokeFinalConfirmation(rs.getBoolean("revokeFinalConfirmation"));
						resultado.setDaysETDBySupplierBatch(rs.getBoolean("daysETDBySupplierBatch"));
						resultado.setFacturacion(rs.getBoolean("facturacion"));	
						resultado.setEntregaATraficoyCXP(rs.getBoolean("entregaATraficoyCXP"));						
						resultado.setVePagoFactura(rs.getBoolean("vePagofactura"));
						resultado.setVeRequisitosImportacion(rs.getBoolean("veRequisitosImportacion"));
						resultado.setVeTruper(rs.getBoolean("veTruper"));
						resultado.setVeComercio(rs.getBoolean("veComercio"));
						resultado.setGerenteSrCoberturaI(rs.getBoolean("gerenteSrCoberturaI"));
						resultado.setDirectorCoberturaI(rs.getBoolean("directorCoberturaI"));
						resultado.setGerenteConfirmacion(rs.getBoolean("gerenteConfirmacion"));
						resultado.setConfirmationManager(rs.getBoolean("isConfirmationManager"));
						resultado.setVeSettingPOD(rs.getBoolean("veSettingPOD"));
						resultado.setVePlannersAssignation(rs.getBoolean("vePlannersAssignation"));
						resultado.setGerenteConfirmacionGDR(rs.getBoolean("GRDgerenteConfirmacion"));
						resultado.setGerenteConfirmacionSrGDR(rs.getBoolean("GRDgerenteConfirmacionSr"));
						resultado.setGerenteConfirmacionBOGDR(rs.getBoolean("GRDgerenteConfirmacionBO"));
						resultado.setGerenteOnHoldGDR(rs.getBoolean("GRDOnHold"));
						resultado.setDcontrolbuyers(rs.getBoolean("dcontrolbuyers"));
						resultado.setDcontrolplanning(rs.getBoolean("dcontrolplanning"));
						resultado.setDcontrolcanceled(rs.getBoolean("dcontrolcanceled"));
						resultado.setDcontrolclosed(rs.getBoolean("dcontrolclosed"));
						lstResult.add(resultado);
					}
				}
			}
		} catch (SQLException e) {
			log.error("Valores {}", user, e);
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			throw new ServletException(e);
		} catch (Exception e) {
			log.error("Valores {}", user, e);
			throw new ServletException(e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
		return lstResult;
	}

	public static HashSet<String> dameBUsUsuario(int user_id) {
		HashSet<String> respuesta = null;
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();
			try (PreparedStatement pst = con.prepareStatement("SELECT BU FROM cdiUserBU WHERE user_id = ?")) {
				pst.setInt(1, user_id);
				try (ResultSet rs = pst.executeQuery()) {
					respuesta = new HashSet<>();
					while (rs.next()) {
						respuesta.add(rs.getString("BU"));
					}
				}
			}
		} catch (SQLException sqle) {
			sqle.printStackTrace();
			ConexionDB.renovar(con);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			ConexionDB.devolver(con);
		}
		return respuesta;
	}
	
	public static Set<String> dameFabricasUsuario(int user_id) {
		Set<String> respuesta = null;
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();
			try (PreparedStatement pst = con.prepareStatement("SELECT fabrica FROM cdiUserFabrica WHERE user_id = ?")) {
				pst.setInt(1, user_id);
				try (ResultSet rs = pst.executeQuery()) {
					respuesta = new HashSet<>();
					while (rs.next()) {
						respuesta.add(rs.getString("fabrica"));
					}
				}
			}
		} catch (Exception e) {
			log.error("#dameFabricasUsuario", e);
		} finally {
			ConexionDB.devolver(con);
		}
		return respuesta;
	}

	public static Map<Integer, String> dameTiposUsuario() throws ServletException {
		Map<Integer, String> mapaTiposUsuario = new HashMap<Integer, String>();
		Connection con = null;
		PreparedStatement pst = null;
		ResultSet rs = null;

		StringBuffer query = new StringBuffer();
		query.append("SELECT id, descripcion");
		query.append(" FROM cdiUserTypes");

		try {
			con = ConexionDB.dameConexion();
			pst = con.prepareStatement(query.toString());
			rs = pst.executeQuery();

			while (rs.next()) {
				mapaTiposUsuario.put(rs.getInt("id"), rs.getString("descripcion"));
			}

			rs.close();
			pst.close();
			ConexionDB.devuelveConexion(con);
		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
				throw new ServletException(ex);
			}
			log.error(e.getMessage(), e);
			throw new ServletException(e);
		} catch (Exception e) {
			e.printStackTrace();
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
				throw new ServletException(ex);
			}
			log.error(e.getMessage(), e);
			throw new ServletException(e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
				throw new ServletException(sqlEx2);
			}
		}
		return mapaTiposUsuario;
	}

	public static Set<String> damePasswordsBlackList() throws ServletException {
		Set<String> setPasswordsBlackList = new HashSet<String>();
		Connection con = null;
		PreparedStatement pst = null;
		ResultSet rs = null;

		StringBuffer query = new StringBuffer();
		query.append("SELECT password");
		query.append(" FROM cdiPasswordsBlackList");
		query.append(" WHERE active = 1");

		try {
			con = ConexionDB.dameConexion();
			pst = con.prepareStatement(query.toString());
			rs = pst.executeQuery();

			while (rs.next()) {
				setPasswordsBlackList.add(rs.getString("password"));
			}

			rs.close();
			pst.close();
			ConexionDB.devuelveConexion(con);
		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
				throw new ServletException(ex);
			}
			log.error(e.getMessage(), e);
			throw new ServletException(e);
		} catch (Exception e) {
			e.printStackTrace();
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
				throw new ServletException(ex);
			}
			log.error(e.getMessage(), e);
			throw new ServletException(e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
				throw new ServletException(sqlEx2);
			}
		}
		return setPasswordsBlackList;
	}

	public static Set<String> dameUltimosPasswords(String user) throws ServletException {
		Set<String> setLastPasswords = new HashSet<String>();
		Connection con = null;
		PreparedStatement pst = null;
		ResultSet rs = null;

		StringBuffer query = new StringBuffer();
		String lastPasswords = PropertiesLoader.getInstance().getString("srm.password.lastPasswords");
		query.append("SELECT TOP " + lastPasswords + "pwd");
		query.append(" FROM cdiPasswordsHistory");
		query.append(" where userName = ?");
		query.append(" order by creationDate desc");

		try {
			con = ConexionDB.dameConexion();
			pst = con.prepareStatement(query.toString());
			pst.setString(1, user);
			rs = pst.executeQuery();

			while (rs.next()) {
				setLastPasswords.add(rs.getString("pwd"));
			}

			rs.close();
			pst.close();
			ConexionDB.devuelveConexion(con);
		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
				throw new ServletException(ex);
			}
			log.error(e.getMessage(), e);
			throw new ServletException(e);
		} catch (Exception e) {
			e.printStackTrace();
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
				throw new ServletException(ex);
			}
			log.error(e.getMessage(), e);
			throw new ServletException(e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
				throw new ServletException(sqlEx2);
			}
		}
		return setLastPasswords;
	}

	public static boolean insertaUsuario(UserBean user) throws ServletException {
		boolean exito = false;
		Connection con = null;
		PreparedStatement pst = null;
		DAOUtils utilDao = new DAOUtils();

		StringBuffer insert = new StringBuffer();
		insert.append("INSERT INTO cdiUsers (userName, pwd, lastPwdChangeDate, changePwd,");
		insert.append(" realName, userEmail, userProfile, active, userType, creationDate, creationUser)");
		insert.append(" VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

		try {
			con = ConexionDB.dameConexion();
			pst = con.prepareStatement(insert.toString());
			int cont = 1;
			utilDao.ajustaParametro(cont++, pst, user.getUserName(), String.class);
			utilDao.ajustaParametro(cont++, pst, user.getPwd(), String.class);
			utilDao.ajustaParametro(cont++, pst, user.getLastPwdChangeDate(), Integer.class);
			utilDao.ajustaParametro(cont++, pst, user.getCambiarPwd(), Boolean.class);
			utilDao.ajustaParametro(cont++, pst, user.getRealName(), String.class);
			utilDao.ajustaParametro(cont++, pst, user.getUserEmail(), String.class);
			utilDao.ajustaParametro(cont++, pst, user.getUserProfile(), Integer.class);
			utilDao.ajustaParametro(cont++, pst, true, Boolean.class);
			utilDao.ajustaParametro(cont++, pst, user.getUserType(), Integer.class);
			utilDao.ajustaParametro(cont++, pst, System.currentTimeMillis(), Long.class);
			utilDao.ajustaParametro(cont++, pst, user.getCreationUser(), String.class);

			utilDao.inicializaQuery(insert.toString());

			exito = pst.executeUpdate() > 0;

			ConexionDB.devuelveConexion(con);
		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
				throw new ServletException(ex);
			}
			log.error(e.getMessage(), e);
			throw new ServletException(e);
		} catch (Exception e) {
			e.printStackTrace();
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
				throw new ServletException(ex);
			}
			log.error(e.getMessage(), e);
			throw new ServletException(e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
				throw new ServletException(sqlEx2);
			}
		}
		return exito;
	}

	public static boolean actualizaUsuario(UserBean user) throws ServletException {
		boolean exito = false;
		Connection con = null;
		PreparedStatement pst = null;
		DAOUtils utilDao = new DAOUtils();

		try {
			con = ConexionDB.dameConexion();

			StringBuffer queryUpdate = new StringBuffer();
			queryUpdate.append("UPDATE cdiUsers set");

			if (user.getRealName() != null) {
				queryUpdate.append(utilDao.ajustaColumna(" realName = ?"));
			}
			if (user.getUserEmail() != null) {
				queryUpdate.append(utilDao.ajustaColumna(" userEmail = ?"));
			}
			if (user.getUserProfile() != null) {
				queryUpdate.append(utilDao.ajustaColumna(" userProfile = ?"));
			}
			if (user.getUserType() != null) {
				queryUpdate.append(utilDao.ajustaColumna(" userType = ?"));
			}
			if (user.getPwd() != null) {
				queryUpdate.append(utilDao.ajustaColumna(" pwd = ?"));
			}
			if (user.getLastPwdChangeDate() != null) {
				queryUpdate.append(utilDao.ajustaColumna(" lastPwdChangeDate = ?"));
			}
			if (user.getCambiarPwd() != null) {
				queryUpdate.append(utilDao.ajustaColumna(" changePwd = ?"));
			}
			if (user.getCreationDate() != null) {
				queryUpdate.append(utilDao.ajustaColumna(" creationDate = ?"));
			}
			if (user.getCreationUser() != null) {
				queryUpdate.append(utilDao.ajustaColumna(" creationUser = ?"));
			}

			queryUpdate.append(" where userName  = ? ");

			pst = con.prepareStatement(queryUpdate.toString());

			int cont = 1;

			if (user.getRealName() != null) {
				utilDao.ajustaParametro(cont++, pst, user.getRealName(), String.class);
			}
			if (user.getUserEmail() != null) {
				utilDao.ajustaParametro(cont++, pst, user.getUserEmail(), String.class);
			}
			if (user.getUserProfile() != null) {
				utilDao.ajustaParametro(cont++, pst, user.getUserProfile(), Integer.class);
			}
			if (user.getUserType() != null) {
				utilDao.ajustaParametro(cont++, pst, user.getUserType(), Integer.class);
			}
			if (user.getPwd() != null) {
				utilDao.ajustaParametro(cont++, pst, user.getPwd(), String.class);
			}
			if (user.getLastPwdChangeDate() != null) {
				utilDao.ajustaParametro(cont++, pst, user.getLastPwdChangeDate(), Integer.class);
			}
			if (user.getCambiarPwd() != null) {
				utilDao.ajustaParametro(cont++, pst, user.getCambiarPwd(), Boolean.class);
			}
			if (user.getCreationDate() != null) {
				utilDao.ajustaParametro(cont++, pst, user.getCreationDate(), Long.class);
			}
			if (user.getCreationUser() != null) {
				utilDao.ajustaParametro(cont++, pst, user.getCreationUser(), String.class);
			}

			utilDao.ajustaParametro(cont++, pst, user.getUserName(), String.class);

			utilDao.inicializaQuery(queryUpdate.toString());

			exito = pst.executeUpdate() > 0;
			ConexionDB.devuelveConexion(con);
		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
				throw new ServletException(ex);
			}
			log.error(e.getMessage(), e);
			throw new ServletException(e);
		} catch (Exception e) {
			e.printStackTrace();
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
				throw new ServletException(ex);
			}
			log.error(e.getMessage(), e);
			throw new ServletException(e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
				throw new ServletException(sqlEx2);
			}
		}
		return exito;
	}

	public static boolean actualizaBloqueoUsuario(UserBean user) throws ServletException {
		boolean exito = false;
		Connection con = null;
		PreparedStatement pst = null;

		try {
			con = ConexionDB.dameConexion();

			StringBuffer queryUpdate = new StringBuffer();
			queryUpdate.append("UPDATE cdiUsers SET active = ? ");
			queryUpdate.append(" where userName  = ? ");
			pst = con.prepareStatement(queryUpdate.toString());
			int cont = 1;
			pst.setBoolean(cont, user.isActive());
			pst.setString(++cont, user.getUserName());

			exito = pst.executeUpdate() > 0;
			pst.close();
		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
				throw new ServletException(ex);
			}
			log.error(e.getMessage(), e);
			throw new ServletException(e);
		} catch (Exception e) {
			e.printStackTrace();
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
				throw new ServletException(ex);
			}
			log.error(e.getMessage(), e);
			throw new ServletException(e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
				throw new ServletException(sqlEx2);
			}
		}
		return exito;
	}

	public static boolean insertaHistoricoPwd(UserBean user) throws ServletException {
		boolean exito = false;
		Connection con = null;
		PreparedStatement pst = null;

		StringBuffer queryPasswordsHistory = new StringBuffer();
		queryPasswordsHistory.append("INSERT INTO cdiPasswordsHistory (userName, pwd, creationDate)");
		queryPasswordsHistory.append(" VALUES (?, ?, ?)");

		try {
			con = ConexionDB.dameConexion();
			pst = con.prepareStatement(queryPasswordsHistory.toString());
			pst.setString(1, user.getUserName());
			pst.setString(2, user.getPwd());
			pst.setInt(3, FuncionesComunesPLI.gregorianCalendar2int(new GregorianCalendar()));
			exito = pst.executeUpdate() != 0;
			pst.close();
			ConexionDB.devuelveConexion(con);
		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
				throw new ServletException(ex);
			}
			log.error(e.getMessage(), e);
			throw new ServletException(e);
		} catch (Exception e) {
			e.printStackTrace();
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
				throw new ServletException(ex);
			}
			log.error(e.getMessage(), e);
			throw new ServletException(e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
				throw new ServletException(sqlEx2);
			}
		}
		return exito;
	}

	/**
	 * Metodo que Registra cambio de password en BD
	 * 
	 * @param bean
	 * @return boolean
	 */
	public static boolean registraTokenCambioPwdEnBD(BeanValidacionesCambioPassword bean) throws ServletException {
		boolean exito = false;
		Connection con = null;
		PreparedStatement pst = null;

		StringBuffer query = new StringBuffer();
		query.append("INSERT INTO cdiTokensCambioPwd (userName, token, creationDate, used)");
		query.append(" VALUES (?, ?, ?, ?)");

		try {
			con = ConexionDB.dameConexion();
			pst = con.prepareStatement(query.toString());
			pst.setString(1, bean.getUser());
			pst.setString(2, bean.getToken());
			pst.setLong(3, new Date().getTime());
			pst.setBoolean(4, bean.isUsado());
			exito = pst.executeUpdate() != 0;
			pst.close();
			ConexionDB.devuelveConexion(con);
		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
				throw new ServletException(ex);
			}
			log.error(e.getMessage(), e);
			throw new ServletException(e);
		} catch (Exception e) {
			e.printStackTrace();
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
				throw new ServletException(ex);
			}
			log.error(e.getMessage(), e);
			throw new ServletException(e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
				throw new ServletException(sqlEx2);
			}
		}
		return exito;
	}

	public static BeanValidacionesCambioPassword ultimoTokenCambioPwdEnBD(String userName) throws ServletException {
		Connection con = null;
		PreparedStatement pst = null;
		ResultSet rs = null;

		BeanValidacionesCambioPassword bean = null;

		StringBuffer query = new StringBuffer();
		query.append("SELECT userName, Token, creationDate, used from cdiTokensCambioPwd");
		query.append(" WHERE userName = ? and creationDate = (");
		query.append(" SELECT MAX(creationDate) from cdiTokensCambioPwd WHERE userName = ?)");

		try {
			con = ConexionDB.dameConexion();
			pst = con.prepareStatement(query.toString());
			pst.setString(1, userName);
			pst.setString(2, userName);
			rs = pst.executeQuery();
			if (rs.next()) {
				bean = new BeanValidacionesCambioPassword();
				bean.setUser(rs.getString("userName"));
				bean.setToken(rs.getString("token"));
				bean.setCreationDate(rs.getLong("creationDate"));
				bean.setUsado(rs.getBoolean("used"));
			}
			pst.close();
			ConexionDB.devuelveConexion(con);
		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
				throw new ServletException(ex);
			}
			log.error(e.getMessage(), e);
			throw new ServletException(e);
		} catch (Exception e) {
			e.printStackTrace();
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
				throw new ServletException(ex);
			}
			log.error(e.getMessage(), e);
			throw new ServletException(e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
				throw new ServletException(sqlEx2);
			}
		}
		return bean;
	}

	public static boolean updateTokenCambioPwdEnBD(BeanValidacionesCambioPassword bean) throws ServletException {
		Connection con = null;
		PreparedStatement pst = null;
		boolean exito = false;

		StringBuffer query = new StringBuffer();
		query.append("UPDATE cdiTokensCambioPwd");
		query.append(" SET used = 1");
		query.append(" WHERE userName = ? AND token = ?");

		try {
			con = ConexionDB.dameConexion();
			pst = con.prepareStatement(query.toString());
			pst.setString(1, bean.getUser());
			pst.setString(2, bean.getToken());
			exito = pst.executeUpdate() != 0;
			pst.close();
			ConexionDB.devuelveConexion(con);
		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
				throw new ServletException(ex);
			}
			log.error(e.getMessage(), e);
			throw new ServletException(e);
		} catch (Exception e) {
			e.printStackTrace();
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
				throw new ServletException(ex);
			}
			log.error(e.getMessage(), e);
			throw new ServletException(e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
				throw new ServletException(sqlEx2);
			}
		}
		return exito;
	}

	public static List<Integer> dameSARsEnCC(Integer folio) {
		Connection con = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		StringBuilder select = new StringBuilder();
		select.append("SELECT folio FROM cdiSAR WHERE folioConsolidado = ?");
		List<Integer> foliosAConsultar = new ArrayList<Integer>();
		try {
			con = ConexionDB.dameConexion();
			pst = con.prepareStatement(select.toString());
			pst.setInt(1, folio);
			rs = pst.executeQuery();

			while (rs.next()) {
				foliosAConsultar.add(rs.getInt("folio"));
			}
			rs.close();
			pst.close();
		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} catch (Exception e) {
			e.printStackTrace();
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
		return foliosAConsultar;
	}

	public static HashMap<Integer, ArrayList<SarDetalleBO>> cargaDetalle(String folio, boolean consolidado) {
		Connection con = null;
		Statement st = null;
		ResultSet rs = null;
		String select = null;
		HashMap<Integer, ArrayList<SarDetalleBO>> temp = new HashMap<Integer, ArrayList<SarDetalleBO>>();

		try {
			con = ConexionDB.dameConexion();
			st = con.createStatement();
			ArrayList<Integer> foliosAConsultar = new ArrayList<Integer>();

			if (consolidado) {
				select = "SELECT folio FROM cdiSAR WHERE folioConsolidado = " + folio;
				rs = st.executeQuery(select);

				while (rs.next()) {
					foliosAConsultar.add(rs.getInt("folio"));
				}
			} else {
				foliosAConsultar.add(Integer.parseInt(folio));
			}

			select = "SELECT folio, po, posicion, material, centro, cantidad, pesoProveedor, volumenProveedor, "
					+ "planeador,cliente, fechaProforma, esPedidoDirecto " + "FROM cdiSARDetalle WHERE folio IN (";

			for (int f : foliosAConsultar) {
				select += f + ",";
			}
			select = select.substring(0, select.length() - 1);
			select += ")";

			rs = st.executeQuery(select);
			while (rs.next()) {
				int folioBD = rs.getInt("folio");
				String po = rs.getString("po").trim();
				int posicion = rs.getInt("posicion");
				int material = rs.getInt("material");
				int cantidad = rs.getInt("cantidad");
				String centro = rs.getString("centro");
				centro = centro != null ? centro.trim() : "";
				String planeador = rs.getString("planeador");
				planeador = planeador != null ? planeador.trim() : "";
				double peso = rs.getDouble("pesoProveedor");
				double vol = rs.getDouble("volumenProveedor");
				String cliente = rs.getString("cliente");
				int fechaProforma = rs.getInt("fechaProforma");
				boolean pedidoDirecto = rs.getBoolean("esPedidoDirecto");

				SarDetalleBO det = new SarDetalleBO(folioBD, po, posicion, material, cantidad, centro, planeador,
						cliente);
				det.setPesoProveedor(peso);
				det.setVolumenProveedor(vol);
				det.setFechaProforma(fechaProforma);
				det.setPedidoDirecto(pedidoDirecto);

				ArrayList<SarDetalleBO> lista = temp.get(folioBD);
				if (lista == null) {
					lista = new ArrayList<SarDetalleBO>();
					temp.put(folioBD, lista);
				}
				lista.add(det);
			}

			ConexionDB.devuelveConexion(con);

		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} catch (Exception e) {
			e.printStackTrace();
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}

		return temp;
	}

	public static HashMap<Integer, ArrayList<SarDetalleBO>> cargaDetalleCancelado(String folio, boolean consolidado) {
		Connection con = null;
		Statement st = null;
		ResultSet rs = null;
		String select = null;
		HashMap<Integer, ArrayList<SarDetalleBO>> temp = new HashMap<Integer, ArrayList<SarDetalleBO>>();

		try {
			con = ConexionDB.dameConexion();
			st = con.createStatement();
			ArrayList<Integer> foliosAConsultar = new ArrayList<Integer>();

			if (consolidado) {
				select = "SELECT folio FROM cdiSAR WHERE folioConsolidado = " + folio;
				rs = st.executeQuery(select);

				while (rs.next()) {
					foliosAConsultar.add(rs.getInt("folio"));
				}
			} else {
				foliosAConsultar.add(Integer.parseInt(folio));
			}

			select = "SELECT folio, po, posicion, material, centro, cantidad, pesoProveedor, volumenProveedor, "
					+ "planeador,cliente, fechaProforma, esPedidoDirecto, almacen "
					+ "FROM cdiSARDetalleRechazados WHERE folio IN (";

			for (int f : foliosAConsultar) {
				select += f + ",";
			}
			select = select.substring(0, select.length() - 1);
			select += ")";

			rs = st.executeQuery(select);
			while (rs.next()) {
				int folioBD = rs.getInt("folio");
				String po = rs.getString("po").trim();
				int posicion = rs.getInt("posicion");
				int material = rs.getInt("material");
				int cantidad = rs.getInt("cantidad");
				String centro = rs.getString("centro");
				centro = centro != null ? centro.trim() : "";
				String planeador = rs.getString("planeador");
				planeador = planeador != null ? planeador.trim() : "";
				double peso = rs.getDouble("pesoProveedor");
				double vol = rs.getDouble("volumenProveedor");
				String cliente = rs.getString("cliente");
				int fechaProforma = rs.getInt("fechaProforma");
				boolean pedidoDirecto = rs.getBoolean("esPedidoDirecto");
				String almacen = rs.getString("almacen");

				SarDetalleBO det = new SarDetalleBO(folioBD, po, posicion, material, cantidad, centro, planeador,
						cliente);
				det.setPesoProveedor(peso);
				det.setVolumenProveedor(vol);
				det.setFechaProforma(fechaProforma);
				det.setPedidoDirecto(pedidoDirecto);
				det.setAlmacen(almacen);

				ArrayList<SarDetalleBO> lista = temp.get(folioBD);
				if (lista == null) {
					lista = new ArrayList<SarDetalleBO>();
					temp.put(folioBD, lista);
				}
				lista.add(det);
			}

			ConexionDB.devuelveConexion(con);

		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} catch (Exception e) {
			e.printStackTrace();
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}

		return temp;
	}

	public static void cargaPreciosPO(HashMap<String, SarDetalleBO> detallesBD) {
		Connection con = null;
		Statement st = null;
		ResultSet rs = null;
		HashMap<String, BigDecimal> precios = new HashMap<String, BigDecimal>();

		String select = "SELECT numeroOrden, posicion, precioUnitario FROM ImportacionesDetalleOrden WHERE ";
		for (SarDetalleBO det : detallesBD.values()) {
			select += "(numeroOrden = '" + det.getPo() + "' AND posicion = " + det.getPosicion() + ") OR ";
		}

		select = select.substring(0, select.length() - 4);

		try {
			con = ConexionDB.dameConexion();
			st = con.createStatement();
			rs = st.executeQuery(select);

			while (rs.next()) {
				precios.put(rs.getString("numeroOrden").trim() + "|" + rs.getInt("posicion"),
						rs.getBigDecimal("precioUnitario"));
			}

			for (SarDetalleBO det : detallesBD.values()) {
				BigDecimal precio = precios.get(det.getPo() + "|" + det.getPosicion());
				if (precio != null) {
					det.setPrecioUnitarioPO(precio);
				}
			}

			ConexionDB.devuelveConexion(con);

		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} catch (Exception e) {
			e.printStackTrace();
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
	}

	public static void resetSupplier(int folio) {
		Connection con = null;

		try {
			con = ConexionDB.dameConexion();

			PreparedStatement pst = null;
			StringBuffer query = new StringBuffer();

			query.append(" update cdisar ");
			query.append(" set  ");
			query.append(" bookingUpdateSupplier = NULL ,");
			query.append(" carrierUpdateSupplier = 0 , ");
			query.append(" dateETDFinalUpdateSupplier = NULL ");
			query.append(" where folio = ? ");

			pst = con.prepareStatement(query.toString());

			pst.setInt(1, folio);
			pst.executeUpdate();
			pst.close();
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		} finally {
			ConexionDB.devolver(con);
		}
	}

	/**
	 * 
	 * Metodo generico para consultar los registros correspondientes a la tabla de
	 * DCISAR
	 * 
	 * @param bean
	 * @return
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 */
	public ArrayList<SarBO> selectSar(SarBO bean, boolean isHighVolume) throws SQLException, ClassNotFoundException {

		ArrayList<SarBO> listaSAR = new ArrayList<SarBO>();
		DAOUtils utils = new DAOUtils();
		Connection con = null;

		try {
			con = ConexionDB.dameConexion();

			ResultSet rs = null;
			PreparedStatement pst = null;
			StringBuffer query = new StringBuffer(select_sar);
			String AsSar = "sar.";
			String tableSar = "sar";

			/// Si es select debo marcar el bean utils como tal para que no ponga las comas
			utils.setSelect(true);

			if (bean.isRequestSupplier()) {
				query.append(utils.ajustaColumna(" AND  sar.bookingUpdateSupplier is not null "));
			}

			if (bean.getTieneTSRAbiertos() != null) {
				if (bean.getTieneTSRAbiertos()) {
					query.append(
							" AND sar.folio IN (SELECT folio FROM cdiTsrReport WHERE folio = sar.folio AND pendiente = 1) ");
				} else if (!bean.getTieneTSRAbiertos()) {
					query.append(
							" AND sar.folio IN (SELECT folio FROM cdiTsrReport WHERE folio = sar.folio AND pendiente = 0) ");
				}
			}

			if (bean.getContenedor() != null) {
				query.append(utils.ajustaColumna(" AND  sar.contenedor = ? "));
			}
			if (bean.getFolio() != null || (bean.getListaPos() != null && !bean.getListaPos().isEmpty())) {
				if(bean.getListaPos() == null) {
					query.append(utils.ajustaColumna(" AND  sar.folio = ? "));
				}else {
					query.append(utils.ajustaColumna(" AND  sar.folio IN(SELECT folio FROM cdiSarDetalle sarDetalle where sarDetalle.po = ? ) "));
				}
			}
			if (bean.getFechaEmbarque() != null) {
				if (bean.getFechaEmbarqueIni() != null && bean.getFechaEmbarqueFin() != null) {
					query.append(utils.ajustaColumna(" AND  sar.fechaEmbarque BETWEEN  ? AND  ? "));
				} else {
					if (bean.getFechaEmbarqueIni() != null) {
						query.append(utils.ajustaColumna(" AND  sar.fechaEmbarque >=  ? "));
					} else {
						query.append(utils.ajustaColumna(" AND  sar.fechaEmbarque = ? "));
					}
				}
			}
			// /Si la bandera dice que incluye ya consolidados, los agrego
			if (bean.getConsolidado() != null) {
				if ((bean.getIncluyeSarConsol() == null || !bean.getIncluyeSarConsol())) {
					query.append(utils.ajustaColumna("AND sar.folioconsolidado is null "));
				}
			}

			if (bean.getBarcoSugerido() != null) {
				query.append(utils.ajustaColumna(" AND  sar.barcoSugerido = ? "));
			}
			if (bean.getFiltroBooking() != null) {
				if (bean.getFiltroBooking() == 1 || bean.getFiltroBooking() == 3) {
					query.append(utils.ajustaColumna(" AND  sar.booking is NULL "));
				} else if (bean.getFiltroBooking() == 2) {
					query.append(utils.ajustaColumna(" AND  sar.booking is not NULL "));
				}
			}
			if (bean.getBooking() != null ||(bean.getBooking() != null && bean.getFiltroBooking() == 2)) {
				query.append(utils.ajustaColumna(" AND  sar.booking = ? "));
			}
			if (bean.getConsolidado() != null) {
				query.append(utils.ajustaColumna(" AND  sar.consolidado = ? "));
			}

			if (bean.getEtdPlanner() != null) {
				query.append(utils.ajustaColumna(" AND  sar.etd = ? "));
			}
			if (bean.getEtdReal() != null) {
				query.append(utils.ajustaColumna(" AND  sar.etdFinal = ? "));
			}
			if (bean.getFechaSolicitudDeAprobacion() != null) {
				query.append(utils.ajustaColumna(" AND  sar.fechaSolAprobacion = ? "));
			}
			if (bean.getFechaUltimaAprobacionRechazo() != null) {
				query.append(utils.ajustaColumna(" AND  sar.fechaUltAprobRechazo = ? "));
			}
			if (bean.getNaviera() != null) {
				query.append(utils.ajustaColumna(" AND  sar.naviera = ? "));
			}
			if (bean.getPrioridad() != null) {
				query.append(utils.ajustaColumna(" AND  sar.prioridad = ? "));
			}
			if (bean.getProveedor() != null) {
				query.append(utils.ajustaColumna(" AND  sar.proveedor = ? "));
			}
			if (bean.getPuertoDescarga() != null) {
				query.append(utils.ajustaColumna(" AND  sar.puertoDescarga = ? "));
			}
			if (bean.getPuertoSalida() != null) {
				query.append(utils.ajustaColumna(" AND  sar.puertoSalida = ? "));
			}
			if (bean.getStatus() != null) {
				query.append(utils.ajustaColumna(" AND  sar.status = ? "));
			}
			String intervaloEstatus = bean.getIntervaloEstatus();
			if (intervaloEstatus != null) {
				query.append(" ").append(intervaloEstatus).append(" ");
			}
			if (bean.getTipoContenedor() != null) {
				query.append(utils.ajustaColumna(" AND  sar.tipoContenedor = ? "));
			}
			if (bean.getUsuarioApruebaPlanning() != null) {
				query.append(utils.ajustaColumna(" AND  sar.usuarioApruebaPlanning = ? "));
			}
			if (bean.getUsuarioApruebaRechaza() != null) {
				query.append(utils.ajustaColumna(" AND  sar.usuarioApruebaRechaza = ? "));
			}
			if (bean.getUsuarioSolicitudDeAprobacion() != null) {
				query.append(utils.ajustaColumna(" AND  sar.usuarioSolAprobacion = ? "));
			}
			if (bean.getViaje() != null) {
				query.append(utils.ajustaColumna(" AND  sar.viaje = ? "));
			}
			if (bean.getComentarioCancelacion() != null) {
				query.append(utils.ajustaColumna(" AND  sar.comentarioCancelacion = ? "));
			}
			if (bean.getFolioConsolidado() != null) {
				query.append(utils.ajustaColumna(" AND  sar.folioConsolidado = ? "));
			}
			if (bean.getConcatenado() != null) {
				query.append(utils.ajustaColumna(" AND  concat(folioConsolidado ,folio )=  ?"));
			}

			if (bean.getTransporte() != null) {
				query.append(utils.ajustaColumna(" AND  sar.transporte = ? "));
			}
			if (bean.getEsSinPO() != null) {
				query.append(utils.ajustaColumna(" AND sar.esSinPO = ? "));
			}
			if (bean.getAprobadoPorCompras() != null) {
				query.append(utils.ajustaColumna(" AND sar.aprobadoPorCompras = ? "));
			}
			if (bean.getTipoRetraso() != null) {
				query.append(utils.ajustaColumna(" AND sar.tipoRetraso = ? "));
			}
			if (bean.esAereo() != null) {
				query.append(utils.ajustaColumna(" AND sar.esAereo = ? "));
			}
			if (bean.esModificadoProveedor() != null) {
				query.append(utils.ajustaColumna(" AND sar.fueModificadoProveedor = ? "));
			}

			if (bean.esAprobadoSDI() != null) {
				query.append(utils.ajustaColumna(" AND sar.aprobadoSDI = ? "));
			}

			if (bean.getMandante() != null) {
				query.append(utils.ajustaColumna(" AND sar.mandante = ? "));
			}

			if (bean.getCerradoDocumentosProveedor() != null) {
				query.append(utils.ajustaColumna(" AND sar.cerradoDocumentosProveedor = ? "));
			}

			// /Parte de logica para validar si es un null
			if (bean.getNuloEnAprobadoSDI() != null && bean.getNuloEnAprobadoSDI()) {
				query.append(utils.ajustaColumna(" AND sar.aprobadoSDI IS NULL OR  sar.aprobadoSDI = 0"));
			}

			if (bean.esAceptadoConDiferencias() != null && !bean.esAceptadoConDiferencias()) {
				query.append(utils.ajustaColumna(
						" AND (sar.aceptadoConDiferencias = ? OR " + AsSar + "aceptadoConDiferencias IS NULL)"));
			}

			if (bean.getNeedsAuthImpDir() != null) {
				query.append(utils.ajustaColumna(" AND sar.needAuthImpDir = ?"));
			}

			if (bean.getAprobadoDirImportaciones() != null) {
				query.append(utils.ajustaColumna(" AND sar.aprobadoDirImportaciones = ?"));
			}
			
			if( bean.getAprobadoConfMngr() != null ) {
				query.append(utils.ajustaColumna(" AND sar.aprobadoConfMngr = ?"));
			}

			if (bean.getTieneDiferenciaMRP() != null) {
				query.append(utils.ajustaColumna(" AND sar.diferenciaMRP = ?"));
			}

			if (bean.getCargadoMRP() != null) {
				query.append(utils.ajustaColumna(" AND sar.cargadoMRP = ?"));
			}

			if (bean.getNotificacionMRP() != null) {
				query.append(utils.ajustaColumna(" AND sar.notificacionMRP = ?"));
			}

			if (bean.getEnRevisionConfirmFinal() != null) {
				query.append(utils.ajustaColumna(" AND sar.enRevisionConfirmFinal = ?"));
			}

			if (bean.getAplicaBitacora() != null) {
				query.append(utils.ajustaColumna(" AND sar.aplicaBitacoraImpDir = ?"));
			}

			if (bean.getBitacoraImportsDirCerrada() != null) {
				query.append(utils.ajustaColumna(" AND bitacoraImpDirCerrada = ?"));
			}

			if (bean.getTinyFechIniProfileApproved() != null) {
				query.append(" ADN tinyFechIniProfileApproved = ? ");
			}
			if (bean.getGuideline() != null) {
				query.append(" AND guideline = ? ");
			}
			if (bean.getApprovedConfirmationManager() != null){
				query.append(" AND approvedConfirmationManager = ? ");
			}
			if (bean.getApprovedSrManager() != null){
				query.append(" AND approvedSrManager = ? ");
			}
			if (bean.getApprovedDirector() != null){
				query.append(" AND approvedDirector = ? ");
			}
			
			if (bean.getApprovedOverStock() != null){
				query.append(" AND approvedOverStock = ? ");
			}

			if (bean.getCommentProfiles() != null){
				query.append(" AND commentProfiles = ? ");
			}

			if (bean.getReleaseRequirementsBC() != null){
				query.append(" AND releaseRequirementsBC = ? ");
			}

			if (bean.getFecCierreLogImpDirIni() != null && bean.getFecCierreLogImpDirFin() != null) {
				query.append(utils.ajustaColumna(" AND sar.tinyFecIniImpDir BETWEEN ? AND ? "));
			}
			
			if (bean.getPreciosLiberados() != null) {
				query.append(utils.ajustaColumna(" AND sar.preciosLiberados = ?"));
			}
			

			if (isHighVolume) {

				query.append(" and( select distinct tel.altovol from ");
				query.append(" cdiSARDetalle det inner join ");
				query.append(TelServiceClient.linkedServer_TEL);
				query.append("[productos] tel on det.material = tel.codigo ");
				query.append(" where det.folio=sar.folio ");
				query.append(" and tel.altovol ='AV'  ");
				query.append(" )is not null  ");

			}

			// esta condicion siempre debe ir al final
			if (!bean.isRequestSupplier() && bean.getIntervalosFechaCreacion() != null) {
				query.append(bean.getIntervalosFechaCreacion());
			}
			
			if (!bean.isRequestSupplier() && bean.getIntervalosFechaEmbarcacion() != null) {	
					query.append(bean.getIntervalosFechaEmbarcacion());	
			}	
			pst = con.prepareStatement(query.toString());

			int cont = 1;

			utils.inicializaQuery(query.toString());

			if (bean.getContenedor() != null) {
				utils.ajustaParametro(cont++, pst, bean.getContenedor(), String.class);
			}
			if (bean.getFolio() != null || (bean.getListaPos() != null && !bean.getListaPos().isEmpty())) {
				if(bean.getListaPos() == null) {
					utils.ajustaParametro(cont++, pst, bean.getFolio(), Integer.class);
				}else {
					utils.ajustaParametro(cont++, pst, bean.getListaPos().get(0), String.class);
				}
			}
			if (bean.getFechaEmbarque() != null) {
				if (bean.getFechaEmbarqueIni() != null && bean.getFechaEmbarqueFin() != null) {
					utils.ajustaParametro(cont++, pst, bean.getFechaEmbarqueIni(), Integer.class);
					utils.ajustaParametro(cont++, pst, bean.getFechaEmbarqueFin(), Integer.class);
				} else {
					if (bean.getFechaEmbarqueIni() != null) {
						utils.ajustaParametro(cont++, pst, bean.getFechaEmbarqueIni(), Integer.class);
					} else {
						utils.ajustaParametro(cont++, pst, bean.getFechaEmbarque(), Integer.class);
					}
				}
			}
			if (bean.getBarcoSugerido() != null) {
				utils.ajustaParametro(cont++, pst, bean.getBarcoSugerido(), String.class);
			}
			if (bean.getBooking() != null) {
				utils.ajustaParametro(cont++, pst, bean.getBooking(), String.class);
			}
			if (bean.getConsolidado() != null) {
				utils.ajustaParametro(cont++, pst, bean.getConsolidado(), Boolean.class);
			}
			if (bean.getEtdPlanner() != null) {
				utils.ajustaParametro(cont++, pst, bean.getEtdPlanner(), Integer.class);
			}
			if (bean.getEtdReal() != null) {
				utils.ajustaParametro(cont++, pst, bean.getEtdReal(), Integer.class);
			}
			if (bean.getFechaSolicitudDeAprobacion() != null) {
				utils.ajustaParametro(cont++, pst, bean.getFechaSolicitudDeAprobacion(), Integer.class);
			}
			if (bean.getFechaUltimaAprobacionRechazo() != null) {
				utils.ajustaParametro(cont++, pst, bean.getFechaUltimaAprobacionRechazo(), Integer.class);
			}
			if (bean.getNaviera() != null) {
				utils.ajustaParametro(cont++, pst, bean.getNaviera(), Integer.class);
			}
			if (bean.getPrioridad() != null) {
				utils.ajustaParametro(cont++, pst, bean.getPrioridad(), Integer.class);
			}
			if (bean.getProveedor() != null) {
				utils.ajustaParametro(cont++, pst, bean.getProveedor(), String.class);
			}
			if (bean.getPuertoDescarga() != null) {
				utils.ajustaParametro(cont++, pst, bean.getPuertoDescarga(), String.class);
			}
			if (bean.getPuertoSalida() != null) {
				utils.ajustaParametro(cont++, pst, bean.getPuertoSalida(), String.class);
			}
			if (bean.getStatus() != null) {
				utils.ajustaParametro(cont++, pst, bean.getStatus(), Integer.class);
			}
			if (bean.getTipoContenedor() != null) {
				utils.ajustaParametro(cont++, pst, bean.getTipoContenedor(), Integer.class);
			}
			if (bean.getUsuarioApruebaPlanning() != null) {
				utils.ajustaParametro(cont++, pst, bean.getUsuarioApruebaPlanning(), String.class);
			}
			if (bean.getUsuarioApruebaRechaza() != null) {
				utils.ajustaParametro(cont++, pst, bean.getUsuarioApruebaRechaza(), String.class);
			}
			if (bean.getUsuarioSolicitudDeAprobacion() != null) {
				utils.ajustaParametro(cont++, pst, bean.getUsuarioSolicitudDeAprobacion(), String.class);
			}
			if (bean.getViaje() != null) {
				utils.ajustaParametro(cont++, pst, bean.getViaje(), String.class);
			}
			if (bean.getComentarioCancelacion() != null) {
				utils.ajustaParametro(cont++, pst, bean.getComentarioCancelacion(), String.class);
			}
			if (bean.getFolioConsolidado() != null) {
				utils.ajustaParametro(cont++, pst, bean.getFolioConsolidado(), Integer.class);
			}
			if (bean.getConcatenado() != null) {
				utils.ajustaParametro(cont++, pst, bean.getConcatenado(), String.class);
			}
			if (bean.getTransporte() != null) {
				utils.ajustaParametro(cont++, pst, bean.getTransporte(), Integer.class);
			}
			if (bean.getEsSinPO() != null) {
				utils.ajustaParametro(cont++, pst, bean.getEsSinPO(), Boolean.class);
			}
			if (bean.getAprobadoPorCompras() != null) {
				utils.ajustaParametro(cont++, pst, bean.getAprobadoPorCompras(), Boolean.class);
			}
			if (bean.getTipoRetraso() != null) {
				utils.ajustaParametro(cont++, pst, bean.getTipoRetraso(), Integer.class);
			}
			if (bean.esAereo() != null) {
				utils.ajustaParametro(cont++, pst, bean.esAereo(), Boolean.class);
			}
			if (bean.esModificadoProveedor() != null) {
				utils.ajustaParametro(cont++, pst, bean.esModificadoProveedor(), Boolean.class);
			}

			if (bean.esAprobadoSDI() != null) {
				utils.ajustaParametro(cont++, pst, bean.esAprobadoSDI(), Boolean.class);
			}
			if (bean.getMandante() != null) {
				utils.ajustaParametro(cont++, pst, bean.getMandante(), Integer.class);
			}
			if (bean.getCerradoDocumentosProveedor() != null) {
				utils.ajustaParametro(cont++, pst, bean.getCerradoDocumentosProveedor(), Boolean.class);
			}
			if (bean.esAceptadoConDiferencias() != null && !bean.esAceptadoConDiferencias()) {
				utils.ajustaParametro(cont++, pst, bean.esAceptadoConDiferencias(), Boolean.class);
			}
			if (bean.getNeedsAuthImpDir() != null) {
				utils.ajustaParametro(cont++, pst, bean.getNeedsAuthImpDir(), Boolean.class);
			}
			if (bean.getAprobadoDirImportaciones() != null) {
				utils.ajustaParametro(cont++, pst, bean.getAprobadoDirImportaciones(), Boolean.class);
			}
			if( bean.getAprobadoConfMngr() != null ) {
				utils.ajustaParametro(cont++, pst, bean.getAprobadoConfMngr(), Boolean.class );
			}
			if (bean.getTieneDiferenciaMRP() != null) {
				utils.ajustaParametro(cont++, pst, bean.getTieneDiferenciaMRP(), Boolean.class);
			}
			if (bean.getCargadoMRP() != null) {
				utils.ajustaParametro(cont++, pst, bean.getCargadoMRP(), Boolean.class);
			}
			if (bean.getNotificacionMRP() != null) {
				utils.ajustaParametro(cont++, pst, bean.getNotificacionMRP(), Boolean.class);
			}
			if (bean.getEnRevisionConfirmFinal() != null) {
				utils.ajustaParametro(cont++, pst, bean.getEnRevisionConfirmFinal(), Boolean.class);
			}
			if (bean.getAplicaBitacora() != null) {
				utils.ajustaParametro(cont++, pst, bean.getAplicaBitacora(), Boolean.class);
			}
			if (bean.getBitacoraImportsDirCerrada() != null) {
				utils.ajustaParametro(cont++, pst, bean.getBitacoraImportsDirCerrada(), Boolean.class);
			}

			if (bean.getTinyFechIniProfileApproved() != null) {
				utils.ajustaParametro(cont++, pst, bean.getTinyFechIniProfileApproved(), Integer.class);
			}
			if (bean.getGuideline() != null) {
				utils.ajustaParametro(cont++, pst, bean.getGuideline(), Integer.class);
			}
			if (bean.getApprovedConfirmationManager() != null){
				utils.ajustaParametro(cont++, pst, bean.getApprovedConfirmationManager(), Boolean.class);
			}
			if (bean.getApprovedSrManager() != null){
					utils.ajustaParametro(cont++, pst, bean.getApprovedSrManager(), Boolean.class);
			}
			if (bean.getApprovedDirector() != null){
				utils.ajustaParametro(cont++, pst, bean.getApprovedDirector(), Boolean.class);
			}
			
			if (bean.getApprovedOverStock() != null){
				utils.ajustaParametro(cont++, pst, bean.getApprovedOverStock(), Boolean.class);
			}

			if (bean.getCommentProfiles() != null){
				utils.ajustaParametro(cont++, pst, bean.getCommentProfiles(), String.class);
			}

			if (bean.getReleaseRequirementsBC() != null){
				utils.ajustaParametro(cont++, pst, bean.getReleaseRequirementsBC(), Boolean.class);
			}

			if (bean.getFecCierreLogImpDirIni() != null && bean.getFecCierreLogImpDirFin() != null) {
				utils.ajustaParametro(cont++, pst, bean.getFecCierreLogImpDirIni(), Integer.class);
				utils.ajustaParametro(cont++, pst, bean.getFecCierreLogImpDirFin(), Integer.class);
			}

			if (bean.isAprobadoPorCompras() != null) {
				utils.ajustaParametro(cont++, pst, bean.getAplicaBitacora(), Boolean.class);
			}

			rs = pst.executeQuery();

			while (rs.next()) {

				SarBO tmpSAR = new SarBO();
				tmpSAR.setFolio(rs.getInt("folio"));
				tmpSAR.setProveedor(rs.getString("proveedor"));
				tmpSAR.setPuertoSalida(rs.getString("puertoSalida"));
				tmpSAR.setNaviera(rs.getInt("naviera"));
				if (rs.wasNull()) {
					tmpSAR.setNaviera(null);
				}
				tmpSAR.setFechaEmbarque(rs.getInt("fechaEmbarque"));
				tmpSAR.setConsolidado(rs.getBoolean("consolidado"));
				tmpSAR.setStatus(rs.getInt("status"));
				tmpSAR.setFechaSolicitudDeAprobacion(rs.getInt("fechaSolAprobacion"));
				if (rs.wasNull()) {
					tmpSAR.setFechaSolicitudDeAprobacion(null);
				}
				tmpSAR.setUsuarioSolicitudDeAprobacion(rs.getString("usuarioSolAprobacion"));
				tmpSAR.setFechaUltimaAprobacionRechazo(rs.getInt("fechaUltAprobRechazo"));
				tmpSAR.setUsuarioApruebaPlanning(rs.getString("usuarioApruebaPlanning"));
				tmpSAR.setUsuarioApruebaRechaza(rs.getString("usuarioApruebaRechaza"));
				tmpSAR.setTipoContenedor(rs.getInt("tipoContenedor"));
				tmpSAR.setPrioridad(rs.getInt("prioridad"));
				tmpSAR.setBarcoSugerido(rs.getString("barcoSugerido"));
				tmpSAR.setViaje(rs.getString("viaje"));
				tmpSAR.setPuertoDescarga(rs.getString("puertoDescarga"));
				tmpSAR.setContenedor(rs.getString("contenedor"));
				tmpSAR.setBooking(rs.getString("booking"));
				tmpSAR.setEtdPlanner(rs.getInt("etd"));
				tmpSAR.setEtdReal(rs.getInt("etdFinal"));
				tmpSAR.setEtdModificada(rs.getInt("etdFinalModificada"));
				tmpSAR.setComentarioCancelacion(rs.getString("comentarioCancelacion"));
				tmpSAR.setFolioConsolidado(rs.getInt("folioConsolidado"));
				if (rs.wasNull()) {
					tmpSAR.setFolioConsolidado(null);
				}
				tmpSAR.setEsAereo(rs.getBoolean("esAereo"));
				tmpSAR.setAvion(rs.getString("avion"));
				tmpSAR.setAerolinea(rs.getInt("aerolinea"));
				tmpSAR.setLlegadaAvion(rs.getInt("llegadaAvion"));
				if (rs.wasNull()) {
					tmpSAR.setLlegadaAvion(null);
				}

				tmpSAR.setTransporte(rs.getInt("transporte"));
				tmpSAR.setComentarioPlanner(rs.getString("comentarioPlanner"));
				tmpSAR.setComentarioShipping(rs.getString("comentarioShipping"));
				tmpSAR.setEsSinPO(rs.getBoolean("esSinPO"));
				tmpSAR.setEta(rs.getInt("eta"));

				tmpSAR.setBl(rs.getString("bl"));
				tmpSAR.setAprobadoPorCompras(rs.getBoolean("aprobadoPorCompras"));
				tmpSAR.setTipoRetraso(rs.getInt("tipoRetraso"));
				tmpSAR.setCreationDate(rs.getInt("fechaCreacion"));
				tmpSAR.setModificadoProveedor(rs.getBoolean("fueModificadoProveedor"));
				tmpSAR.setAceptadoConDiferencias(rs.getBoolean("aceptadoConDiferencias"));
				if (rs.wasNull()) {
					tmpSAR.setAceptadoConDiferencias(null);
				}
				tmpSAR.setPaisDestino(rs.getInt("paisDestino"));
				if (rs.wasNull()) {
					tmpSAR.setPaisDestino(null);
				}

				tmpSAR.setCargoAProveedor(rs.getBoolean("cargoAProveedor"));
				tmpSAR.setOtraAerolinea(rs.getString("otraAerolinea"));
				tmpSAR.setAprobadoProveedor(rs.getBoolean("aprobadoProveedor"));

				tmpSAR.setEsMultiple(rs.getBoolean("esmultiple"));
				if (rs.wasNull()) {
					tmpSAR.setEsMultiple(null);
				}
				tmpSAR.setMandante(rs.getInt("mandante"));
				if (rs.wasNull()) {
					tmpSAR.setMandante(null);
				}
				tmpSAR.setAprobadoSDI(rs.getBoolean("aprobadoSDI"));
				if (rs.wasNull()) {
					tmpSAR.setAprobadoSDI(null);
				}

				tmpSAR.setCerradoDocumentosProveedor(rs.getBoolean("cerradoDocumentosProveedor"));
				tmpSAR.setFechaCierreDocumentosProveedor(rs.getInt("fechaCierreDocumentosProveedor"));
				tmpSAR.setFechaAprobadoSDI(rs.getInt("fechaAprobadoSDI"));
				tmpSAR.setComentarioTruperBooking(rs.getString("comentarioTruperBooking"));

				tmpSAR.setFechaUltimaCorreccion(rs.getInt("fechaUltimaCorreccion"));
				tmpSAR.setUsuarioAceptoRechazoSAR(rs.getString("usuarioUltimoRechazoAceptacion"));
				tmpSAR.setRevision(rs.getInt("revision"));
				tmpSAR.setFechaUltimoRechazo(rs.getInt("fechaUltimoRechazo"));
				tmpSAR.setFecIniPlanning(rs.getLong("fecIniPlanning"));
				tmpSAR.setTinyFecIniPlanning(rs.getInt("tinyFecIniPlanning"));
				tmpSAR.setFecIniShipping(rs.getLong("fecIniShipping"));
				tmpSAR.setTinyFecIniShipping(rs.getInt("tinyFecIniShipping"));
				tmpSAR.setFecIniConsolidados(rs.getLong("fecIniConsol"));
				tmpSAR.setTinyFecIniConsolidados(rs.getInt("tinyFecIniConsol"));
				tmpSAR.setFecIniBooking(rs.getLong("fecIniBooking"));
				tmpSAR.setTinyFecIniBooking(rs.getInt("tinyFecIniBooking"));
				tmpSAR.setFecIniSDI(rs.getLong("fecIniSDI"));
				tmpSAR.setTinyFecIniSDI(rs.getInt("tinyFecIniSDI"));
				tmpSAR.setFecIniEmbarque(rs.getLong("fecIniEmbarque"));
				tmpSAR.setTinyFecIniEmbarque(rs.getInt("tinyFecIniEmbarque"));
				tmpSAR.setEsRechazadoSDI(rs.getBoolean("rechazoDocumentosSDI"));

				tmpSAR.setNombreArchivoMRP(rs.getString("archivoMRP"));
				tmpSAR.setTieneDiferenciaMRP(rs.getBoolean("diferenciaMRP"));
				tmpSAR.setCargaArchivoMRP(rs.getInt("cargaArchivoMRP"));
				if (rs.wasNull()) {
					tmpSAR.setCargaArchivoMRP(null);
				}
				tmpSAR.setNeedsAuthImpDir(rs.getBoolean("needAuthImpDir"));
				tmpSAR.setAprobadoDirImportaciones(rs.getBoolean("aprobadoDirImportaciones"));
				tmpSAR.setUserApruebaDirImportaciones(rs.getString("userApruebaDirImportaciones"));
				tmpSAR.setFechaAprobacionDirImportaciones(rs.getInt("fechaApruebaDirImportaciones"));
				tmpSAR.setCommentForImpDir(rs.getString("commentForImpDir"));
				tmpSAR.setImpDirComments(rs.getString("impDirComments"));
				
				tmpSAR.setAprobadoConfMngr(rs.getBoolean("aprobadoConfMngr"));
				tmpSAR.setUserApruebaConfMngr(rs.getString("userApruebaConfMngr"));
				tmpSAR.setFechaApruebaConfMngr(rs.getInt("fechaApruebaConfMngr"));
				tmpSAR.setCommentForConfMngr(rs.getString("commentForConfMngr"));
				tmpSAR.setFecIniConfMngr(rs.getLong("fecIniConfMngr"));		
				tmpSAR.setTinyFecIniConfMngr(rs.getInt("tinyFecIniConfMngr"));
				tmpSAR.setConfMngrComments("confMngrComments");
			
				tmpSAR.setAdelantoAtrasoETDImpDir(rs.getInt("adelantoAtrasoETDImpDir"));

				tmpSAR.setEtdProveedor(rs.getInt("etdProveedor"));
				if (rs.wasNull()) {
					tmpSAR.setEtdProveedor(null);
				}
				tmpSAR.setCargadoMRP(rs.getBoolean("cargadoMRP"));
				tmpSAR.setNotificacionMRP(rs.getBoolean("notificacionMRP"));
				tmpSAR.setEnRevisionConfirmFinal(rs.getBoolean("enRevisionConfirmFinal"));
				tmpSAR.setCommentRevFinalConfirm(rs.getString("commentRevFinalConfirm"));
				tmpSAR.setAceptadoRevFinalConfirm(rs.getBoolean("aceptadoRevFinalConfirm"));
				if (rs.wasNull()) {
					tmpSAR.setAceptadoRevFinalConfirm(null);
				}
				tmpSAR.setUsrAceptaRechazaRevFinal(rs.getString("usrAceptaRechazaRevFinal"));
				tmpSAR.setNumRevFinal(rs.getInt("numRevFinal"));
				Boolean aplicaBitacoraImpDir = (Boolean) rs.getObject("aplicaBitacoraImpDir");
				tmpSAR.setAplicaBitacora(aplicaBitacoraImpDir);
				Boolean bitacoraImpDirCerrada = (Boolean) rs.getObject("bitacoraImpDirCerrada");
				tmpSAR.setBitacoraImportsDirCerrada(bitacoraImpDirCerrada);
				tmpSAR.setFecCierreBitacoraImpDir(rs.getInt("fecCierreBitacoraImpDir"));
				if (rs.wasNull()) {
					tmpSAR.setFecCierreBitacoraImpDir(null);
				}
				Boolean tieneSim = (Boolean) rs.getObject("tieneSimulador");
				tmpSAR.setTieneSimulador(tieneSim);

				boolean preciosLiberados = rs.getBoolean("preciosLiberados");
				tmpSAR.setPreciosLiberados(preciosLiberados);
				boolean preciosEnRevision = rs.getBoolean("preciosEnRevision");
				tmpSAR.setPreciosEnRevision(preciosEnRevision);
				tmpSAR.setVersionSDI(rs.getInt("versionSetDocumentos"));
				tmpSAR.setEnRevicionIDA(rs.getBoolean("enrevisionIDA"));
				tmpSAR.setBitacoraIDA(rs.getBoolean("bitacoraIDA"));
				tmpSAR.setBitacoraIDACerrada(rs.getBoolean("bitacoraIDACerrada"));

				Timestamp ts = rs.getTimestamp("fechaConfirmacionFinal");
				Date date = ts != null ? new Date(ts.getTime()) : null;
				tmpSAR.setFechaConfirmacionFinal(date);

				tmpSAR.setBookingUpdateSupplier(rs.getString("bookingUpdateSupplier"));
				tmpSAR.setCarrierUpdateSupplier(rs.getInt("carrierUpdateSupplier"));
				tmpSAR.setDateETDFinalUpdateSupplier(rs.getDate("dateETDFinalUpdateSupplier"));
				tmpSAR.setDateUpdateSupplier(rs.getDate("dateUpdateSupplier"));
				
				Boolean goodsAreReady = rs.getBoolean("goodsAreReady");
				Date goodsReadyDate = rs.getDate("goodsReadyDate");
				Boolean gdrEnRevision = rs.getBoolean("gdrEnRevision");
						
				if(goodsReadyDate!=null) {
					tmpSAR.setGoodsReadyDate(goodsReadyDate);
					DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
					String goodsReadyDateStr =dateFormat.format(goodsReadyDate);
					tmpSAR.setGoodsReadyDateStr(goodsReadyDateStr);
				}else {
					tmpSAR.setGoodsReadyDate(new Date());
					tmpSAR.setGoodsReadyDateStr("");
				}
				tmpSAR.setGoodsAreReady(goodsAreReady);
				tmpSAR.setGdrEnRevision(gdrEnRevision);
				tmpSAR.setReferenciaContenedorProveedor(rs.getString("referenciaContenedorProveedor"));
				
				tmpSAR.setEsRechazado(rs.getBoolean("isRechazado"));
				tmpSAR.setTinyFechIniProfileApproved(rs.getInt("tinyFechIniProfileApproved"));
				tmpSAR.setGuideline(rs.getInt("guideline"));
				tmpSAR.setApprovedConfirmationManager(rs.getBoolean("approvedConfirmationManager"));
				tmpSAR.setApprovedSrManager(rs.getBoolean("approvedSrManager"));
				tmpSAR.setApprovedDirector(rs.getBoolean("approvedDirector"));
				tmpSAR.setApprovedOverStock(rs.getBoolean("approvedOverStock"));
				tmpSAR.setCommentProfiles(rs.getString("commentProfiles"));
				tmpSAR.setReleaseRequirementsBC(rs.getBoolean("releaseRequirementsBC"));
				
				tmpSAR.setMessageGRDrechazo(rs.getString("messageGRDrechazo"));
				tmpSAR.setMessageGRDaprobacion(rs.getString("messageGRDaprobacion"));
				tmpSAR.setApprovalGRDlineacion(rs.getBoolean("approvalGRDlineacion"));
				tmpSAR.setStatusAnteriorGRD(rs.getInt("statusAnteriorGRD"));
				listaSAR.add(tmpSAR);
			}
			rs.close();
			pst.close();
			ConexionDB.devuelveConexion(con);

		} catch (SQLException sqlE) {
			try {
				log.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
			throw sqlE;
		} catch (IOException ioE) {
			try {
				log.error(ioE.getMessage(), ioE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception ioE2) {
				log.error(ioE2.getMessage(), ioE2);
			}
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}

		return listaSAR;
	}
	
	
/**	
 * 	
 * Metodo generico para consultar los registros correspondientes a la tabla de	
 * DCISAR	
 * 	
 * @param bean	
 * @return	
 * @throws SQLException	
 * @throws ClassNotFoundException	
 */	
public static ArrayList<SarBO> findSarByProveedorAndFolio(String proveedor,String folio) throws SQLException, ClassNotFoundException {	
	ArrayList<SarBO> listaSAR = new ArrayList<SarBO>();	
	Connection con = null;	
	try {	
		con = ConexionDB.dameConexion();	
		ResultSet rs = null;	
		PreparedStatement pst =  con.prepareStatement(CdiSarQuery.SAR_BY_PROVEEDOR_AND_FOLIO.	
				replaceAll("PROVEEDOR", proveedor).	
				replaceAll("FOLIO", folio));	
		rs = pst.executeQuery();	
		while (rs.next()) {	
			SarBO tmpSAR = new SarBO();	
			tmpSAR.setContenedorProveedor(rs.getString("contenedorProveedor"));	
			tmpSAR.setSealNumber(rs.getString("sealNumber"));	
			listaSAR.add(tmpSAR);	
		}	
		rs.close();	
		pst.close();	
		ConexionDB.devuelveConexion(con);	
	} catch (SQLException sqlE) {	
		try {	
			log.error(sqlE.getMessage(), sqlE);	
			ConexionDB.renuevaConexion(con);	
		} catch (Exception sqlEx2) {	
			log.error(sqlEx2.getMessage(), sqlEx2);	
		}	
		throw sqlE;	
	} finally {	
		try {	
			ConexionDB.devuelveConexion(con);	
		} catch (Exception sqlEx2) {	
			log.error(sqlEx2.getMessage(), sqlEx2);	
		}	
	}	
	return listaSAR;	
}	

	/**
	 * @deprecated Se reemplazó por el método
	 *             {@link SarDao #selectSarsConfirmacionFinal(com.srm.pli.bo.BeanFiltroSar, boolean)}
	 * @param bean
	 * @param esSinConfFinal
	 * @return
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 */
	public ArrayList<SarBO> selectVistaSinConfFinal(SarBO bean, boolean esSinConfFinal)
			throws SQLException, ClassNotFoundException {

		ArrayList<SarBO> listaSAR = new ArrayList<SarBO>();
		DAOUtils utils = new DAOUtils();
		Connection con = null;

		try {
			con = ConexionDB.dameConexion();

			ResultSet rs = null;
			PreparedStatement pst = null;
			StringBuffer query = new StringBuffer();

			query.append(
					" SELECT     folio, proveedor, puertoSalida, naviera, fechaEmbarque, consolidado, status, fechaSolAprobacion,   ");
			query.append(
					" usuarioSolAprobacion, fechaUltAprobRechazo, usuarioApruebaPlanning, usuarioApruebaRechaza, tipoContenedor, prioridad, ");
			query.append(
					" barcoSugerido, viaje, puertoDescarga, contenedor, booking, etd,etdFinal, comentarioCancelacion,folioConsolidado,transporte, ");
			query.append(
					" comentarioPlanner, comentarioShipping, esSinPO, eta, bl, aprobadoPorCompras, tipoRetraso, fechaCreacion, esAereo, ");
			query.append(
					" fueModificadoProveedor, aerolinea, avion, llegadaavion, aceptadoConDiferencias, paisDestino, cargoAProveedor, ");
			query.append(
					" otraAerolinea,aprobadoProveedor,esmultiple,mandante, aprobadoSDI,cerradoDocumentosProveedor,");
			query.append(
					" fechaCierreDocumentosProveedor,fechaAprobadoSDI, comentarioTruperBooking,fechaUltimoRechazo,  ");
			query.append(
					" fechaUltimaCorreccion, usuarioUltimoRechazoAceptacion, revision, fecIniPlanning, tinyFecIniPlanning, ");
			query.append(
					" fecIniShipping, tinyFecIniShipping, fecIniConsol, tinyFecIniConsol, fecIniBooking, tinyFecIniBooking, ");
			query.append(
					" fecIniSDI, tinyFecIniSDI, fecIniEmbarque, tinyFecIniEmbarque,rechazoDocumentosSDI,diferenciaMRP, cargaArchivoMRP, archivoMRP, ");
			query.append(
					" needAuthImpDir, aprobadoDirImportaciones, userApruebaDirImportaciones, fechaApruebaDirImportaciones, commentForImpDir, ");
			query.append(
					" impDirComments, adelantoAtrasoETDImpDir, cargadoMRP, etdProveedor, notificacionMRP, enRevisionConfirmFinal, ");
			query.append(
					" commentRevFinalConfirm, aceptadoRevFinalConfirm, usrAceptaRechazaRevFinal, numRevFinal, aplicaBitacoraImpDir, ");
			query.append(
					" bitacoraImpDirCerrada, fecCierreBitacoraImpDir,tieneSimulador,preciosLiberados,versionSetDocumentos,preciosEnRevision,fechaConfirmacionFinal, ");
			query.append(" bitacoraIDA,bitacoraIDACerrada ");
			query.append(" FROM cdiSAR ");
			if (esSinConfFinal) {
				query.append(" WHERE   booking IS NOT NULL   ");
				query.append(" AND (aprobadoProveedor is null or aprobadoProveedor = 0)   ");
			} else {
				query.append(
						" WHERE   aprobadoProveedor = 1 AND fechaConfirmacionFinal IS NOT NULL AND fechaConfirmacionFinal >= DATEADD( month, -3, GETDATE() ) ");
			}

			/// Si es select debo marcar el bean utils como tal para que no ponga las comas
			utils.setSelect(true);

			if (bean.getContenedor() != null) {
				query.append(utils.ajustaColumna(" AND  contenedor = ? "));
			}
			if (bean.getFolio() != null) {
				query.append(utils.ajustaColumna(" AND  folio = ? "));
			}
			if (bean.getFechaEmbarque() != null) {
				if (bean.getFechaEmbarqueIni() != null && bean.getFechaEmbarqueFin() != null) {
					query.append(utils.ajustaColumna(" AND  fechaEmbarque BETWEEN  ? AND  ? "));
				} else {
					if (bean.getFechaEmbarqueIni() != null) {
						query.append(utils.ajustaColumna(" AND  fechaEmbarque >=  ? "));
					} else {
						query.append(utils.ajustaColumna(" AND  fechaEmbarque = ? "));
					}
				}
			}
			// /Si la bandera dice que incluye ya consolidados, los agrego
			if (bean.getConsolidado() != null) {
				if ((bean.getIncluyeSarConsol() == null || !bean.getIncluyeSarConsol())) {
					query.append(utils.ajustaColumna("AND folioconsolidado is null "));
				}
			}

			if (bean.getBarcoSugerido() != null) {
				query.append(utils.ajustaColumna(" AND  barcoSugerido = ? "));
			}
			if (bean.getFiltroBooking() != null) {
				if (bean.getFiltroBooking() == 1 || bean.getFiltroBooking() == 3) {
					query.append(utils.ajustaColumna(" AND  booking is NULL "));
				} else if (bean.getFiltroBooking() == 2) {
					query.append(utils.ajustaColumna(" AND  booking is not NULL "));
				}
			}
			if (bean.getBooking() != null && bean.getFiltroBooking() == 2) {
				query.append(utils.ajustaColumna(" AND  booking = ? "));
			}
			if (bean.getConsolidado() != null) {
				query.append(utils.ajustaColumna(" AND  consolidado = ? "));
			}

			if (bean.getEtdPlanner() != null) {
				query.append(utils.ajustaColumna(" AND  etd = ? "));
			}
			if (bean.getEtdReal() != null) {
				query.append(utils.ajustaColumna(" AND  etdFinal = ? "));
			}
			if (bean.getFechaSolicitudDeAprobacion() != null) {
				query.append(utils.ajustaColumna(" AND  fechaSolAprobacion = ? "));
			}
			if (bean.getFechaUltimaAprobacionRechazo() != null) {
				query.append(utils.ajustaColumna(" AND  fechaUltAprobRechazo = ? "));
			}
			if (bean.getNaviera() != null) {
				query.append(utils.ajustaColumna(" AND  naviera = ? "));
			}
			if (bean.getPrioridad() != null) {
				query.append(utils.ajustaColumna(" AND  prioridad = ? "));
			}
			if (bean.getProveedor() != null) {
				query.append(utils.ajustaColumna(" AND  proveedor = ? "));
			}
			if (bean.getPuertoDescarga() != null) {
				query.append(utils.ajustaColumna(" AND  puertoDescarga = ? "));
			}
			if (bean.getPuertoSalida() != null) {
				query.append(utils.ajustaColumna(" AND  puertoSalida = ? "));
			}
			if (bean.getStatus() != null) {
				query.append(utils.ajustaColumna(" AND  status = ? "));
			}
			if (bean.getTipoContenedor() != null) {
				query.append(utils.ajustaColumna(" AND  tipoContenedor = ? "));
			}
			if (bean.getUsuarioApruebaPlanning() != null) {
				query.append(utils.ajustaColumna(" AND usuarioApruebaPlanning = ? "));
			}
			if (bean.getUsuarioApruebaRechaza() != null) {
				query.append(utils.ajustaColumna(" AND  usuarioApruebaRechaza = ? "));
			}
			if (bean.getUsuarioSolicitudDeAprobacion() != null) {
				query.append(utils.ajustaColumna(" AND  usuarioSolAprobacion = ? "));
			}
			if (bean.getViaje() != null) {
				query.append(utils.ajustaColumna(" AND  viaje = ? "));
			}
			if (bean.getComentarioCancelacion() != null) {
				query.append(utils.ajustaColumna(" AND  comentarioCancelacion = ? "));
			}
			if (bean.getFolioConsolidado() != null) {
				query.append(utils.ajustaColumna(" AND  folioConsolidado = ? "));
			}

			if (bean.getTransporte() != null) {
				query.append(utils.ajustaColumna(" AND  transporte = ? "));
			}
			if (bean.getEsSinPO() != null) {
				query.append(utils.ajustaColumna(" AND esSinPO = ? "));
			}
			if (bean.getAprobadoPorCompras() != null) {
				query.append(utils.ajustaColumna(" AND aprobadoPorCompras = ? "));
			}
			if (bean.getTipoRetraso() != null) {
				query.append(utils.ajustaColumna(" AND tipoRetraso = ? "));
			}
			if (bean.esAereo() != null) {
				query.append(utils.ajustaColumna(" AND esAereo = ? "));
			}
			if (bean.esModificadoProveedor() != null) {
				query.append(utils.ajustaColumna(" AND fueModificadoProveedor = ? "));
			}

			if (bean.esAprobadoSDI() != null) {
				query.append(utils.ajustaColumna(" AND aprobadoSDI = ? "));
			}

			if (bean.getMandante() != null) {
				query.append(utils.ajustaColumna(" AND mandante = ? "));
			}

			if (bean.getCerradoDocumentosProveedor() != null) {
				query.append(utils.ajustaColumna(" AND cerradoDocumentosProveedor = ? "));
			}

			// /Parte de logica para validar si es un null
			if (bean.getNuloEnAprobadoSDI() != null && bean.getNuloEnAprobadoSDI()) {
				query.append(utils.ajustaColumna(" AND aprobadoSDI IS NULL OR  aprobadoSDI = 0"));
			}

			if (bean.esAceptadoConDiferencias() != null && !bean.esAceptadoConDiferencias()) {
				query.append(
						utils.ajustaColumna(" AND (aceptadoConDiferencias = ? OR aceptadoConDiferencias IS NULL)"));
			}

			if (bean.getNeedsAuthImpDir() != null) {
				query.append(utils.ajustaColumna(" AND needAuthImpDir = ?"));
			}

			if (bean.getAprobadoDirImportaciones() != null) {
				query.append(utils.ajustaColumna(" AND aprobadoDirImportaciones = ?"));
			}

			if (bean.getTieneDiferenciaMRP() != null) {
				query.append(utils.ajustaColumna(" AND diferenciaMRP = ?"));
			}

			if (bean.getCargadoMRP() != null) {
				query.append(utils.ajustaColumna(" AND cargadoMRP = ?"));
			}

			if (bean.getNotificacionMRP() != null) {
				query.append(utils.ajustaColumna(" AND notificacionMRP = ?"));
			}

			if (bean.getEnRevisionConfirmFinal() != null) {
				query.append(utils.ajustaColumna(" AND enRevisionConfirmFinal = ?"));
			}

			if (bean.getAplicaBitacora() != null) {
				query.append(utils.ajustaColumna(" AND aplicaBitacoraImpDir = ?"));
			}

			if (bean.getBitacoraImportsDirCerrada() != null) {
				query.append(utils.ajustaColumna(" AND bitacoraImpDirCerrada = ?"));
			}

			if (bean.getFecCierreLogImpDirIni() != null && bean.getFecCierreLogImpDirFin() != null) {
				query.append(utils.ajustaColumna(" AND tinyFecIniImpDir BETWEEN ? AND ? "));
			}

			if (bean.getPreciosLiberados() != null) {
				query.append(utils.ajustaColumna(" AND preciosLiberados = ?"));
			}

			// esta condicion siempre debe ir al final
			if (bean.getIntervalosFechaCreacion() != null) {
				query.append(bean.getIntervalosFechaCreacion());
			}

			pst = con.prepareStatement(query.toString());

			int cont = 1;

			utils.inicializaQuery(query.toString());

			if (bean.getContenedor() != null) {
				utils.ajustaParametro(cont++, pst, bean.getContenedor(), String.class);
			}
			if (bean.getFolio() != null) {
				utils.ajustaParametro(cont++, pst, bean.getFolio(), Integer.class);
			}
			if (bean.getFechaEmbarque() != null) {
				if (bean.getFechaEmbarqueIni() != null && bean.getFechaEmbarqueFin() != null) {
					utils.ajustaParametro(cont++, pst, bean.getFechaEmbarqueIni(), Integer.class);
					utils.ajustaParametro(cont++, pst, bean.getFechaEmbarqueFin(), Integer.class);
				} else {
					if (bean.getFechaEmbarqueIni() != null) {
						utils.ajustaParametro(cont++, pst, bean.getFechaEmbarqueIni(), Integer.class);
					} else {
						utils.ajustaParametro(cont++, pst, bean.getFechaEmbarque(), Integer.class);
					}
				}
			}
			if (bean.getBarcoSugerido() != null) {
				utils.ajustaParametro(cont++, pst, bean.getBarcoSugerido(), String.class);
			}
			if (bean.getBooking() != null) {
				utils.ajustaParametro(cont++, pst, bean.getBooking(), String.class);
			}
			if (bean.getConsolidado() != null) {
				utils.ajustaParametro(cont++, pst, bean.getConsolidado(), Boolean.class);
			}
			if (bean.getEtdPlanner() != null) {
				utils.ajustaParametro(cont++, pst, bean.getEtdPlanner(), Integer.class);
			}
			if (bean.getEtdReal() != null) {
				utils.ajustaParametro(cont++, pst, bean.getEtdReal(), Integer.class);
			}
			if (bean.getFechaSolicitudDeAprobacion() != null) {
				utils.ajustaParametro(cont++, pst, bean.getFechaSolicitudDeAprobacion(), Integer.class);
			}
			if (bean.getFechaUltimaAprobacionRechazo() != null) {
				utils.ajustaParametro(cont++, pst, bean.getFechaUltimaAprobacionRechazo(), Integer.class);
			}
			if (bean.getNaviera() != null) {
				utils.ajustaParametro(cont++, pst, bean.getNaviera(), Integer.class);
			}
			if (bean.getPrioridad() != null) {
				utils.ajustaParametro(cont++, pst, bean.getPrioridad(), Integer.class);
			}
			if (bean.getProveedor() != null) {
				utils.ajustaParametro(cont++, pst, bean.getProveedor(), String.class);
			}
			if (bean.getPuertoDescarga() != null) {
				utils.ajustaParametro(cont++, pst, bean.getPuertoDescarga(), String.class);
			}
			if (bean.getPuertoSalida() != null) {
				utils.ajustaParametro(cont++, pst, bean.getPuertoSalida(), String.class);
			}
			if (bean.getStatus() != null) {
				utils.ajustaParametro(cont++, pst, bean.getStatus(), Integer.class);
			}
			if (bean.getTipoContenedor() != null) {
				utils.ajustaParametro(cont++, pst, bean.getTipoContenedor(), Integer.class);
			}
			if (bean.getUsuarioApruebaPlanning() != null) {
				utils.ajustaParametro(cont++, pst, bean.getUsuarioApruebaPlanning(), String.class);
			}
			if (bean.getUsuarioApruebaRechaza() != null) {
				utils.ajustaParametro(cont++, pst, bean.getUsuarioApruebaRechaza(), String.class);
			}
			if (bean.getUsuarioSolicitudDeAprobacion() != null) {
				utils.ajustaParametro(cont++, pst, bean.getUsuarioSolicitudDeAprobacion(), String.class);
			}
			if (bean.getViaje() != null) {
				utils.ajustaParametro(cont++, pst, bean.getViaje(), String.class);
			}
			if (bean.getComentarioCancelacion() != null) {
				utils.ajustaParametro(cont++, pst, bean.getComentarioCancelacion(), String.class);
			}
			if (bean.getFolioConsolidado() != null) {
				utils.ajustaParametro(cont++, pst, bean.getFolioConsolidado(), Integer.class);
			}
			if (bean.getTransporte() != null) {
				utils.ajustaParametro(cont++, pst, bean.getTransporte(), Integer.class);
			}
			if (bean.getEsSinPO() != null) {
				utils.ajustaParametro(cont++, pst, bean.getEsSinPO(), Boolean.class);
			}
			if (bean.getAprobadoPorCompras() != null) {
				utils.ajustaParametro(cont++, pst, bean.getAprobadoPorCompras(), Boolean.class);
			}
			if (bean.getTipoRetraso() != null) {
				utils.ajustaParametro(cont++, pst, bean.getTipoRetraso(), Integer.class);
			}
			if (bean.esAereo() != null) {
				utils.ajustaParametro(cont++, pst, bean.esAereo(), Boolean.class);
			}
			if (bean.esModificadoProveedor() != null) {
				utils.ajustaParametro(cont++, pst, bean.esModificadoProveedor(), Boolean.class);
			}

			if (bean.esAprobadoSDI() != null) {
				utils.ajustaParametro(cont++, pst, bean.esAprobadoSDI(), Boolean.class);
			}
			if (bean.getMandante() != null) {
				utils.ajustaParametro(cont++, pst, bean.getMandante(), Integer.class);
			}
			if (bean.getCerradoDocumentosProveedor() != null) {
				utils.ajustaParametro(cont++, pst, bean.getCerradoDocumentosProveedor(), Boolean.class);
			}
			if (bean.esAceptadoConDiferencias() != null && !bean.esAceptadoConDiferencias()) {
				utils.ajustaParametro(cont++, pst, bean.esAceptadoConDiferencias(), Boolean.class);
			}
			if (bean.getNeedsAuthImpDir() != null) {
				utils.ajustaParametro(cont++, pst, bean.getNeedsAuthImpDir(), Boolean.class);
			}
			if (bean.getAprobadoDirImportaciones() != null) {
				utils.ajustaParametro(cont++, pst, bean.getAprobadoDirImportaciones(), Boolean.class);
			}
			if (bean.getTieneDiferenciaMRP() != null) {
				utils.ajustaParametro(cont++, pst, bean.getTieneDiferenciaMRP(), Boolean.class);
			}
			if (bean.getCargadoMRP() != null) {
				utils.ajustaParametro(cont++, pst, bean.getCargadoMRP(), Boolean.class);
			}
			if (bean.getNotificacionMRP() != null) {
				utils.ajustaParametro(cont++, pst, bean.getNotificacionMRP(), Boolean.class);
			}
			if (bean.getEnRevisionConfirmFinal() != null) {
				utils.ajustaParametro(cont++, pst, bean.getEnRevisionConfirmFinal(), Boolean.class);
			}
			if (bean.getAplicaBitacora() != null) {
				utils.ajustaParametro(cont++, pst, bean.getAplicaBitacora(), Boolean.class);
			}
			if (bean.getBitacoraImportsDirCerrada() != null) {
				utils.ajustaParametro(cont++, pst, bean.getBitacoraImportsDirCerrada(), Boolean.class);
			}
			if (bean.getFecCierreLogImpDirIni() != null && bean.getFecCierreLogImpDirFin() != null) {
				utils.ajustaParametro(cont++, pst, bean.getFecCierreLogImpDirIni(), Integer.class);
				utils.ajustaParametro(cont++, pst, bean.getFecCierreLogImpDirFin(), Integer.class);
			}

			if (bean.isAprobadoPorCompras() != null) {
				utils.ajustaParametro(cont++, pst, bean.getAplicaBitacora(), Boolean.class);
			}

			rs = pst.executeQuery();

			while (rs.next()) {

				SarBO tmpSAR = new SarBO();
				tmpSAR.setFolio(rs.getInt("folio"));
				tmpSAR.setProveedor(rs.getString("proveedor"));
				tmpSAR.setPuertoSalida(rs.getString("puertoSalida"));
				tmpSAR.setNaviera(rs.getInt("naviera"));
				if (rs.wasNull()) {
					tmpSAR.setNaviera(null);
				}
				tmpSAR.setFechaEmbarque(rs.getInt("fechaEmbarque"));
				tmpSAR.setConsolidado(rs.getBoolean("consolidado"));
				tmpSAR.setStatus(rs.getInt("status"));
				tmpSAR.setFechaSolicitudDeAprobacion(rs.getInt("fechaSolAprobacion"));
				if (rs.wasNull()) {
					tmpSAR.setFechaSolicitudDeAprobacion(null);
				}
				tmpSAR.setUsuarioSolicitudDeAprobacion(rs.getString("usuarioSolAprobacion"));
				tmpSAR.setFechaUltimaAprobacionRechazo(rs.getInt("fechaUltAprobRechazo"));
				tmpSAR.setUsuarioApruebaPlanning(rs.getString("usuarioApruebaPlanning"));
				tmpSAR.setUsuarioApruebaRechaza(rs.getString("usuarioApruebaRechaza"));
				tmpSAR.setTipoContenedor(rs.getInt("tipoContenedor"));
				tmpSAR.setPrioridad(rs.getInt("prioridad"));
				tmpSAR.setBarcoSugerido(rs.getString("barcoSugerido"));
				tmpSAR.setViaje(rs.getString("viaje"));
				tmpSAR.setPuertoDescarga(rs.getString("puertoDescarga"));
				tmpSAR.setContenedor(rs.getString("contenedor"));
				tmpSAR.setBooking(rs.getString("booking"));
				tmpSAR.setEtdPlanner(rs.getInt("etd"));
				tmpSAR.setEtdReal(rs.getInt("etdFinal"));
				tmpSAR.setComentarioCancelacion(rs.getString("comentarioCancelacion"));
				tmpSAR.setFolioConsolidado(rs.getInt("folioConsolidado"));
				if (rs.wasNull()) {
					tmpSAR.setFolioConsolidado(null);
				}
				tmpSAR.setEsAereo(rs.getBoolean("esAereo"));
				tmpSAR.setAvion(rs.getString("avion"));
				tmpSAR.setAerolinea(rs.getInt("aerolinea"));
				tmpSAR.setLlegadaAvion(rs.getInt("llegadaAvion"));
				if (rs.wasNull()) {
					tmpSAR.setLlegadaAvion(null);
				}

				tmpSAR.setTransporte(rs.getInt("transporte"));
				tmpSAR.setComentarioPlanner(rs.getString("comentarioPlanner"));
				tmpSAR.setComentarioShipping(rs.getString("comentarioShipping"));
				tmpSAR.setEsSinPO(rs.getBoolean("esSinPO"));
				tmpSAR.setEta(rs.getInt("eta"));

				tmpSAR.setBl(rs.getString("bl"));
				tmpSAR.setAprobadoPorCompras(rs.getBoolean("aprobadoPorCompras"));
				tmpSAR.setTipoRetraso(rs.getInt("tipoRetraso"));
				tmpSAR.setCreationDate(rs.getInt("fechaCreacion"));
				tmpSAR.setModificadoProveedor(rs.getBoolean("fueModificadoProveedor"));
				tmpSAR.setAceptadoConDiferencias(rs.getBoolean("aceptadoConDiferencias"));
				if (rs.wasNull()) {
					tmpSAR.setAceptadoConDiferencias(null);
				}
				tmpSAR.setPaisDestino(rs.getInt("paisDestino"));
				if (rs.wasNull()) {
					tmpSAR.setPaisDestino(null);
				}

				tmpSAR.setCargoAProveedor(rs.getBoolean("cargoAProveedor"));
				tmpSAR.setOtraAerolinea(rs.getString("otraAerolinea"));
				tmpSAR.setAprobadoProveedor(rs.getBoolean("aprobadoProveedor"));

				tmpSAR.setEsMultiple(rs.getBoolean("esmultiple"));
				if (rs.wasNull()) {
					tmpSAR.setEsMultiple(null);
				}
				tmpSAR.setMandante(rs.getInt("mandante"));
				if (rs.wasNull()) {
					tmpSAR.setMandante(null);
				}
				tmpSAR.setAprobadoSDI(rs.getBoolean("aprobadoSDI"));
				if (rs.wasNull()) {
					tmpSAR.setAprobadoSDI(null);
				}

				tmpSAR.setCerradoDocumentosProveedor(rs.getBoolean("cerradoDocumentosProveedor"));
				tmpSAR.setFechaCierreDocumentosProveedor(rs.getInt("fechaCierreDocumentosProveedor"));
				tmpSAR.setFechaAprobadoSDI(rs.getInt("fechaAprobadoSDI"));
				tmpSAR.setComentarioTruperBooking(rs.getString("comentarioTruperBooking"));

				tmpSAR.setFechaUltimaCorreccion(rs.getInt("fechaUltimaCorreccion"));
				tmpSAR.setUsuarioAceptoRechazoSAR(rs.getString("usuarioUltimoRechazoAceptacion"));
				tmpSAR.setRevision(rs.getInt("revision"));
				tmpSAR.setFechaUltimoRechazo(rs.getInt("fechaUltimoRechazo"));
				tmpSAR.setFecIniPlanning(rs.getLong("fecIniPlanning"));
				tmpSAR.setTinyFecIniPlanning(rs.getInt("tinyFecIniPlanning"));
				tmpSAR.setFecIniShipping(rs.getLong("fecIniShipping"));
				tmpSAR.setTinyFecIniShipping(rs.getInt("tinyFecIniShipping"));
				tmpSAR.setFecIniConsolidados(rs.getLong("fecIniConsol"));
				tmpSAR.setTinyFecIniConsolidados(rs.getInt("tinyFecIniConsol"));
				tmpSAR.setFecIniBooking(rs.getLong("fecIniBooking"));
				tmpSAR.setTinyFecIniBooking(rs.getInt("tinyFecIniBooking"));
				tmpSAR.setFecIniSDI(rs.getLong("fecIniSDI"));
				tmpSAR.setTinyFecIniSDI(rs.getInt("tinyFecIniSDI"));
				tmpSAR.setFecIniEmbarque(rs.getLong("fecIniEmbarque"));
				tmpSAR.setTinyFecIniEmbarque(rs.getInt("tinyFecIniEmbarque"));
				tmpSAR.setEsRechazadoSDI(rs.getBoolean("rechazoDocumentosSDI"));

				tmpSAR.setNombreArchivoMRP(rs.getString("archivoMRP"));
				tmpSAR.setTieneDiferenciaMRP(rs.getBoolean("diferenciaMRP"));
				tmpSAR.setCargaArchivoMRP(rs.getInt("cargaArchivoMRP"));
				if (rs.wasNull()) {
					tmpSAR.setCargaArchivoMRP(null);
				}
				tmpSAR.setNeedsAuthImpDir(rs.getBoolean("needAuthImpDir"));
				tmpSAR.setAprobadoDirImportaciones(rs.getBoolean("aprobadoDirImportaciones"));
				tmpSAR.setUserApruebaDirImportaciones(rs.getString("userApruebaDirImportaciones"));
				tmpSAR.setFechaAprobacionDirImportaciones(rs.getInt("fechaApruebaDirImportaciones"));
				tmpSAR.setCommentForImpDir(rs.getString("commentForImpDir"));
				tmpSAR.setImpDirComments(rs.getString("impDirComments"));
				tmpSAR.setAdelantoAtrasoETDImpDir(rs.getInt("adelantoAtrasoETDImpDir"));

				tmpSAR.setEtdProveedor(rs.getInt("etdProveedor"));
				if (rs.wasNull()) {
					tmpSAR.setEtdProveedor(null);
				}
				tmpSAR.setCargadoMRP(rs.getBoolean("cargadoMRP"));
				tmpSAR.setNotificacionMRP(rs.getBoolean("notificacionMRP"));
				tmpSAR.setEnRevisionConfirmFinal(rs.getBoolean("enRevisionConfirmFinal"));
				tmpSAR.setCommentRevFinalConfirm(rs.getString("commentRevFinalConfirm"));
				tmpSAR.setAceptadoRevFinalConfirm(rs.getBoolean("aceptadoRevFinalConfirm"));
				if (rs.wasNull()) {
					tmpSAR.setAceptadoRevFinalConfirm(null);
				}
				tmpSAR.setUsrAceptaRechazaRevFinal(rs.getString("usrAceptaRechazaRevFinal"));
				tmpSAR.setNumRevFinal(rs.getInt("numRevFinal"));
				Boolean aplicaBitacoraImpDir = (Boolean) rs.getObject("aplicaBitacoraImpDir");
				tmpSAR.setAplicaBitacora(aplicaBitacoraImpDir);
				Boolean bitacoraImpDirCerrada = (Boolean) rs.getObject("bitacoraImpDirCerrada");
				tmpSAR.setBitacoraImportsDirCerrada(bitacoraImpDirCerrada);
				tmpSAR.setFecCierreBitacoraImpDir(rs.getInt("fecCierreBitacoraImpDir"));
				if (rs.wasNull()) {
					tmpSAR.setFecCierreBitacoraImpDir(null);
				}
				Boolean tieneSim = (Boolean) rs.getObject("tieneSimulador");
				tmpSAR.setTieneSimulador(tieneSim);

				boolean preciosLiberados = rs.getBoolean("preciosLiberados");
				tmpSAR.setPreciosLiberados(preciosLiberados);
				boolean preciosEnRevision = rs.getBoolean("preciosEnRevision");
				tmpSAR.setPreciosEnRevision(preciosEnRevision);
				tmpSAR.setVersionSDI(rs.getInt("versionSetDocumentos"));
				tmpSAR.setBitacoraIDA(rs.getBoolean("bitacoraIDA"));
				tmpSAR.setBitacoraIDACerrada(rs.getBoolean("bitacoraIDACerrada"));

				listaSAR.add(tmpSAR);
			}
			rs.close();
			pst.close();
			ConexionDB.devuelveConexion(con);

		} catch (SQLException sqlE) {
			try {
				log.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
			throw sqlE;
		} catch (IOException ioE) {
			try {
				log.error(ioE.getMessage(), ioE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception ioE2) {
				log.error(ioE2.getMessage(), ioE2);
			}
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}

		return listaSAR;
	}

	/**
	 * 
	 * Remplazara el metodo normal de busqueda de SARs
	 * 
	 * 
	 * @param bean
	 * @return
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 */
	public static ArrayList<SarBO> selectSarDinamico(SarBO bean) throws SQLException, ClassNotFoundException {

		ArrayList<SarBO> listaSAR = new ArrayList<SarBO>();
		DAOUtils utils = new DAOUtils();
		Connection con = null;

		try {
			con = ConexionDB.dameConexion();

			ResultSet rs = null;
			PreparedStatement pst = null;
			StringBuffer query = new StringBuffer();

			query.append(
					" SELECT     folio, proveedor, puertoSalida, naviera, fechaEmbarque, consolidado, status, fechaSolAprobacion,   ");
			query.append(
					" usuarioSolAprobacion, fechaUltAprobRechazo, usuarioApruebaPlanning, usuarioApruebaRechaza, tipoContenedor, prioridad, ");
			query.append(
					" barcoSugerido, viaje, puertoDescarga, contenedor, booking, etd,etdFinal, comentarioCancelacion,folioConsolidado,transporte, ");
			query.append(
					" comentarioPlanner, comentarioShipping, esSinPO, eta, bl, aprobadoPorCompras, tipoRetraso, fechaCreacion, esAereo, ");
			query.append(
					" fueModificadoProveedor, aerolinea, avion, llegadaavion, aceptadoConDiferencias, paisDestino, cargoAProveedor, ");
			query.append(
					" otraAerolinea,aprobadoProveedor,esmultiple,mandante, aprobadoSDI,cerradoDocumentosProveedor,");
			query.append(
					" fechaCierreDocumentosProveedor,fechaAprobadoSDI, comentarioTruperBooking,fechaUltimoRechazo,  ");
			query.append(
					" fechaUltimaCorreccion, usuarioUltimoRechazoAceptacion, revision, fecIniPlanning, tinyFecIniPlanning, ");
			query.append(
					" fecIniShipping, tinyFecIniShipping, fecIniConsol, tinyFecIniConsol, fecIniBooking, tinyFecIniBooking, ");
			query.append(
					" fecIniSDI, tinyFecIniSDI, fecIniEmbarque, tinyFecIniEmbarque,rechazoDocumentosSDI,diferenciaMRP, cargaArchivoMRP, archivoMRP, ");
			query.append(
					" needAuthImpDir, aprobadoDirImportaciones, userApruebaDirImportaciones, fechaApruebaDirImportaciones, commentForImpDir, ");
			query.append(
					" impDirComments, adelantoAtrasoETDImpDir, cargadoMRP, etdProveedor, notificacionMRP, enRevisionConfirmFinal, ");
			query.append(
					" commentRevFinalConfirm, aceptadoRevFinalConfirm, usrAceptaRechazaRevFinal, numRevFinal, aplicaBitacoraImpDir, ");
			query.append(
					" bitacoraImpDirCerrada, fecCierreBitacoraImpDir,tieneSimulador,preciosLiberados,versionSetDocumentos,enrevisionIDA, ");
			query.append(" bitacoraIDA, bitacoraIDACerrada, ");
			query.append(" aprobadoConfMngr, userApruebaConfMngr, fechaApruebaConfMngr, commentForConfMngr, fecIniConfMngr, tinyFecIniConfMngr, confMngrComments ");
			query.append(" FROM cdiSAR ");
			query.append(" WHERE   1=1   ");

			/// Si es select debo marcar el bean utils como tal para que no ponga las comas
			utils.setSelect(true);

			if (bean.getSarsABuscar() != null) {
				query.append(utils.ajustaColumna(" AND  folio in ( " + bean.getSarsABuscar() + ") "));
			}
			if (bean.getContenedor() != null) {
				query.append(utils.ajustaColumna(" AND  contenedor = ? "));
			}
			if (bean.getFolio() != null) {
				query.append(utils.ajustaColumna(" AND  folio = ? "));
			}
			if (bean.getFechaEmbarque() != null) {
				if (bean.getFechaEmbarqueIni() != null && bean.getFechaEmbarqueFin() != null) {
					query.append(utils.ajustaColumna(" AND  fechaEmbarque BETWEEN  ? AND  ? "));
				} else {
					if (bean.getFechaEmbarqueIni() != null) {
						query.append(utils.ajustaColumna(" AND  fechaEmbarque >=  ? "));
					} else {
						query.append(utils.ajustaColumna(" AND  fechaEmbarque = ? "));
					}
				}
			}
			// /Si la bandera dice que incluye ya consolidados, los agrego
			if (bean.getConsolidado() != null) {
				if ((bean.getIncluyeSarConsol() == null || !bean.getIncluyeSarConsol())) {
					query.append(utils.ajustaColumna("AND folioconsolidado is null "));
				}
			}

			if (bean.getBarcoSugerido() != null) {
				query.append(utils.ajustaColumna(" AND  barcoSugerido = ? "));
			}
			if (bean.getFiltroBooking() != null) {
				if (bean.getFiltroBooking() == 1 || bean.getFiltroBooking() == 3) {
					query.append(utils.ajustaColumna(" AND  booking is NULL "));
				} else if (bean.getFiltroBooking() == 2) {
					query.append(utils.ajustaColumna(" AND  booking is not NULL "));
				}
			}
			if (bean.getBooking() != null && bean.getFiltroBooking() == 2) {
				query.append(utils.ajustaColumna(" AND  booking = ? "));
			}
			if (bean.getConsolidado() != null) {
				query.append(utils.ajustaColumna(" AND  consolidado = ? "));
			}

			if (bean.getEtdPlanner() != null) {
				query.append(utils.ajustaColumna(" AND  etd = ? "));
			}
			if (bean.getEtdReal() != null) {
				query.append(utils.ajustaColumna(" AND  etdFinal = ? "));
			}
			if (bean.getFechaSolicitudDeAprobacion() != null) {
				query.append(utils.ajustaColumna(" AND  fechaSolAprobacion = ? "));
			}
			if (bean.getFechaUltimaAprobacionRechazo() != null) {
				query.append(utils.ajustaColumna(" AND  fechaUltAprobRechazo = ? "));
			}
			if (bean.getNaviera() != null) {
				query.append(utils.ajustaColumna(" AND  naviera = ? "));
			}
			if (bean.getPrioridad() != null) {
				query.append(utils.ajustaColumna(" AND  prioridad = ? "));
			}
			if (bean.getProveedor() != null) {
				query.append(utils.ajustaColumna(" AND  proveedor = ? "));
			}
			if (bean.getPuertoDescarga() != null) {
				query.append(utils.ajustaColumna(" AND  puertoDescarga = ? "));
			}
			if (bean.getPuertoSalida() != null) {
				query.append(utils.ajustaColumna(" AND  puertoSalida = ? "));
			}
			if (bean.getStatus() != null) {
				query.append(utils.ajustaColumna(" AND  status = ? "));
			}
			if (bean.getTipoContenedor() != null) {
				query.append(utils.ajustaColumna(" AND  tipoContenedor = ? "));
			}
			if (bean.getUsuarioApruebaPlanning() != null) {
				query.append(utils.ajustaColumna(" AND usuarioApruebaPlanning = ? "));
			}
			if (bean.getUsuarioApruebaRechaza() != null) {
				query.append(utils.ajustaColumna(" AND  usuarioApruebaRechaza = ? "));
			}
			if (bean.getUsuarioSolicitudDeAprobacion() != null) {
				query.append(utils.ajustaColumna(" AND  usuarioSolAprobacion = ? "));
			}
			if (bean.getViaje() != null) {
				query.append(utils.ajustaColumna(" AND  viaje = ? "));
			}
			if (bean.getComentarioCancelacion() != null) {
				query.append(utils.ajustaColumna(" AND  comentarioCancelacion = ? "));
			}
			if (bean.getFolioConsolidado() != null) {
				query.append(utils.ajustaColumna(" AND  folioConsolidado = ? "));
			}

			if (bean.getTransporte() != null) {
				query.append(utils.ajustaColumna(" AND  transporte = ? "));
			}
			if (bean.getEsSinPO() != null) {
				query.append(utils.ajustaColumna(" AND esSinPO = ? "));
			}
			if (bean.getAprobadoPorCompras() != null) {
				query.append(utils.ajustaColumna(" AND aprobadoPorCompras = ? "));
			}
			if (bean.getTipoRetraso() != null) {
				query.append(utils.ajustaColumna(" AND tipoRetraso = ? "));
			}
			if (bean.esAereo() != null) {
				query.append(utils.ajustaColumna(" AND esAereo = ? "));
			}
			if (bean.esModificadoProveedor() != null) {
				query.append(utils.ajustaColumna(" AND fueModificadoProveedor = ? "));
			}

			if (bean.esAprobadoSDI() != null) {
				query.append(utils.ajustaColumna(" AND aprobadoSDI = ? "));
			}

			if (bean.getMandante() != null) {
				query.append(utils.ajustaColumna(" AND mandante = ? "));
			}

			if (bean.getCerradoDocumentosProveedor() != null) {
				query.append(utils.ajustaColumna(" AND cerradoDocumentosProveedor = ? "));
			}

			// /Parte de logica para validar si es un null
			if (bean.getNuloEnAprobadoSDI() != null && bean.getNuloEnAprobadoSDI()) {
				query.append(utils.ajustaColumna(" AND aprobadoSDI IS NULL OR  aprobadoSDI = 0"));
			}

			if (bean.esAceptadoConDiferencias() != null && !bean.esAceptadoConDiferencias()) {
				query.append(
						utils.ajustaColumna(" AND (aceptadoConDiferencias = ? OR aceptadoConDiferencias IS NULL)"));
			}

			if (bean.getNeedsAuthImpDir() != null) {
				query.append(utils.ajustaColumna(" AND needAuthImpDir = ?"));
			}

			if (bean.getAprobadoDirImportaciones() != null) {
				query.append(utils.ajustaColumna(" AND aprobadoDirImportaciones = ?"));
			}

			if (bean.getTieneDiferenciaMRP() != null) {
				query.append(utils.ajustaColumna(" AND diferenciaMRP = ?"));
			}

			if (bean.getCargadoMRP() != null) {
				query.append(utils.ajustaColumna(" AND cargadoMRP = ?"));
			}

			if (bean.getNotificacionMRP() != null) {
				query.append(utils.ajustaColumna(" AND notificacionMRP = ?"));
			}

			if (bean.getEnRevisionConfirmFinal() != null) {
				query.append(utils.ajustaColumna(" AND enRevisionConfirmFinal = ?"));
			}

			if (bean.getAplicaBitacora() != null) {
				query.append(utils.ajustaColumna(" AND aplicaBitacoraImpDir = ?"));
			}

			if (bean.getBitacoraImportsDirCerrada() != null) {
				query.append(utils.ajustaColumna(" AND bitacoraImpDirCerrada = ?"));
			}

			if (bean.getFecCierreLogImpDirIni() != null && bean.getFecCierreLogImpDirFin() != null) {
				query.append(utils.ajustaColumna(" AND tinyFecIniImpDir BETWEEN ? AND ? "));
			}

			if (bean.getPreciosLiberados() != null) {
				query.append(utils.ajustaColumna(" AND preciosLiberados = ?"));
			}

			if( bean.getAprobadoConfMngr() != null ) {
				query.append(utils.ajustaColumna(" AND aprobadoConfMngr = ?"));
			}
			
			// esta condicion siempre debe ir al final
			if (bean.getIntervalosFechaCreacion() != null) {
				query.append(bean.getIntervalosFechaCreacion());
			}

			pst = con.prepareStatement(query.toString());

			int cont = 1;

			utils.inicializaQuery(query.toString());

			if (bean.getContenedor() != null) {
				utils.ajustaParametro(cont++, pst, bean.getContenedor(), String.class);
			}
			if (bean.getFolio() != null) {
				utils.ajustaParametro(cont++, pst, bean.getFolio(), Integer.class);
			}
			if (bean.getFechaEmbarque() != null) {
				if (bean.getFechaEmbarqueIni() != null && bean.getFechaEmbarqueFin() != null) {
					utils.ajustaParametro(cont++, pst, bean.getFechaEmbarqueIni(), Integer.class);
					utils.ajustaParametro(cont++, pst, bean.getFechaEmbarqueFin(), Integer.class);
				} else {
					if (bean.getFechaEmbarqueIni() != null) {
						utils.ajustaParametro(cont++, pst, bean.getFechaEmbarqueIni(), Integer.class);
					} else {
						utils.ajustaParametro(cont++, pst, bean.getFechaEmbarque(), Integer.class);
					}
				}
			}
			if (bean.getBarcoSugerido() != null) {
				utils.ajustaParametro(cont++, pst, bean.getBarcoSugerido(), String.class);
			}
			if (bean.getBooking() != null) {
				utils.ajustaParametro(cont++, pst, bean.getBooking(), String.class);
			}
			if (bean.getConsolidado() != null) {
				utils.ajustaParametro(cont++, pst, bean.getConsolidado(), Boolean.class);
			}
			if (bean.getEtdPlanner() != null) {
				utils.ajustaParametro(cont++, pst, bean.getEtdPlanner(), Integer.class);
			}
			if (bean.getEtdReal() != null) {
				utils.ajustaParametro(cont++, pst, bean.getEtdReal(), Integer.class);
			}
			if (bean.getFechaSolicitudDeAprobacion() != null) {
				utils.ajustaParametro(cont++, pst, bean.getFechaSolicitudDeAprobacion(), Integer.class);
			}
			if (bean.getFechaUltimaAprobacionRechazo() != null) {
				utils.ajustaParametro(cont++, pst, bean.getFechaUltimaAprobacionRechazo(), Integer.class);
			}
			if (bean.getNaviera() != null) {
				utils.ajustaParametro(cont++, pst, bean.getNaviera(), Integer.class);
			}
			if (bean.getPrioridad() != null) {
				utils.ajustaParametro(cont++, pst, bean.getPrioridad(), Integer.class);
			}
			if (bean.getProveedor() != null) {
				utils.ajustaParametro(cont++, pst, bean.getProveedor(), String.class);
			}
			if (bean.getPuertoDescarga() != null) {
				utils.ajustaParametro(cont++, pst, bean.getPuertoDescarga(), Integer.class);
			}
			if (bean.getPuertoSalida() != null) {
				utils.ajustaParametro(cont++, pst, bean.getPuertoSalida(), Integer.class);
			}
			if (bean.getStatus() != null) {
				utils.ajustaParametro(cont++, pst, bean.getStatus(), Integer.class);
			}
			if (bean.getTipoContenedor() != null) {
				utils.ajustaParametro(cont++, pst, bean.getTipoContenedor(), Integer.class);
			}
			if (bean.getUsuarioApruebaPlanning() != null) {
				utils.ajustaParametro(cont++, pst, bean.getUsuarioApruebaPlanning(), String.class);
			}
			if (bean.getUsuarioApruebaRechaza() != null) {
				utils.ajustaParametro(cont++, pst, bean.getUsuarioApruebaRechaza(), String.class);
			}
			if (bean.getUsuarioSolicitudDeAprobacion() != null) {
				utils.ajustaParametro(cont++, pst, bean.getUsuarioSolicitudDeAprobacion(), String.class);
			}
			if (bean.getViaje() != null) {
				utils.ajustaParametro(cont++, pst, bean.getViaje(), String.class);
			}
			if (bean.getComentarioCancelacion() != null) {
				utils.ajustaParametro(cont++, pst, bean.getComentarioCancelacion(), String.class);
			}
			if (bean.getFolioConsolidado() != null) {
				utils.ajustaParametro(cont++, pst, bean.getFolioConsolidado(), Integer.class);
			}
			if (bean.getTransporte() != null) {
				utils.ajustaParametro(cont++, pst, bean.getTransporte(), Integer.class);
			}
			if (bean.getEsSinPO() != null) {
				utils.ajustaParametro(cont++, pst, bean.getEsSinPO(), Boolean.class);
			}
			if (bean.getAprobadoPorCompras() != null) {
				utils.ajustaParametro(cont++, pst, bean.getAprobadoPorCompras(), Boolean.class);
			}
			if (bean.getTipoRetraso() != null) {
				utils.ajustaParametro(cont++, pst, bean.getTipoRetraso(), Integer.class);
			}
			if (bean.esAereo() != null) {
				utils.ajustaParametro(cont++, pst, bean.esAereo(), Boolean.class);
			}
			if (bean.esModificadoProveedor() != null) {
				utils.ajustaParametro(cont++, pst, bean.esModificadoProveedor(), Boolean.class);
			}

			if (bean.esAprobadoSDI() != null) {
				utils.ajustaParametro(cont++, pst, bean.esAprobadoSDI(), Boolean.class);
			}
			if (bean.getMandante() != null) {
				utils.ajustaParametro(cont++, pst, bean.getMandante(), Integer.class);
			}
			if (bean.getCerradoDocumentosProveedor() != null) {
				utils.ajustaParametro(cont++, pst, bean.getCerradoDocumentosProveedor(), Boolean.class);
			}
			if (bean.esAceptadoConDiferencias() != null && !bean.esAceptadoConDiferencias()) {
				utils.ajustaParametro(cont++, pst, bean.esAceptadoConDiferencias(), Boolean.class);
			}
			if (bean.getNeedsAuthImpDir() != null) {
				utils.ajustaParametro(cont++, pst, bean.getNeedsAuthImpDir(), Boolean.class);
			}
			if (bean.getAprobadoDirImportaciones() != null) {
				utils.ajustaParametro(cont++, pst, bean.getAprobadoDirImportaciones(), Boolean.class);
			}
			if( bean.getAprobadoConfMngr() != null ) {
				utils.ajustaParametro(cont++, pst, bean.getAprobadoConfMngr(), Boolean.class);
			}
			if (bean.getTieneDiferenciaMRP() != null) {
				utils.ajustaParametro(cont++, pst, bean.getTieneDiferenciaMRP(), Boolean.class);
			}
			if (bean.getCargadoMRP() != null) {
				utils.ajustaParametro(cont++, pst, bean.getCargadoMRP(), Boolean.class);
			}
			if (bean.getNotificacionMRP() != null) {
				utils.ajustaParametro(cont++, pst, bean.getNotificacionMRP(), Boolean.class);
			}
			if (bean.getEnRevisionConfirmFinal() != null) {
				utils.ajustaParametro(cont++, pst, bean.getEnRevisionConfirmFinal(), Boolean.class);
			}
			if (bean.getAplicaBitacora() != null) {
				utils.ajustaParametro(cont++, pst, bean.getAplicaBitacora(), Boolean.class);
			}
			if (bean.getBitacoraImportsDirCerrada() != null) {
				utils.ajustaParametro(cont++, pst, bean.getBitacoraImportsDirCerrada(), Boolean.class);
			}
			if (bean.getFecCierreLogImpDirIni() != null && bean.getFecCierreLogImpDirFin() != null) {
				utils.ajustaParametro(cont++, pst, bean.getFecCierreLogImpDirIni(), Integer.class);
				utils.ajustaParametro(cont++, pst, bean.getFecCierreLogImpDirFin(), Integer.class);
			}

			if (bean.isAprobadoPorCompras() != null) {
				utils.ajustaParametro(cont++, pst, bean.getAplicaBitacora(), Boolean.class);
			}

			rs = pst.executeQuery();

			while (rs.next()) {

				SarBO tmpSAR = new SarBO();
				tmpSAR.setFolio(rs.getInt("folio"));
				tmpSAR.setProveedor(rs.getString("proveedor"));
				tmpSAR.setPuertoSalida(rs.getString("puertoSalida"));
				tmpSAR.setNaviera(rs.getInt("naviera"));
				if (rs.wasNull()) {
					tmpSAR.setNaviera(null);
				}
				tmpSAR.setFechaEmbarque(rs.getInt("fechaEmbarque"));
				tmpSAR.setConsolidado(rs.getBoolean("consolidado"));
				tmpSAR.setStatus(rs.getInt("status"));
				tmpSAR.setFechaSolicitudDeAprobacion(rs.getInt("fechaSolAprobacion"));
				if (rs.wasNull()) {
					tmpSAR.setFechaSolicitudDeAprobacion(null);
				}
				tmpSAR.setUsuarioSolicitudDeAprobacion(rs.getString("usuarioSolAprobacion"));
				tmpSAR.setFechaUltimaAprobacionRechazo(rs.getInt("fechaUltAprobRechazo"));
				tmpSAR.setUsuarioApruebaPlanning(rs.getString("usuarioApruebaPlanning"));
				tmpSAR.setUsuarioApruebaRechaza(rs.getString("usuarioApruebaRechaza"));
				tmpSAR.setTipoContenedor(rs.getInt("tipoContenedor"));
				tmpSAR.setPrioridad(rs.getInt("prioridad"));
				tmpSAR.setBarcoSugerido(rs.getString("barcoSugerido"));
				tmpSAR.setViaje(rs.getString("viaje"));
				tmpSAR.setPuertoDescarga(rs.getString("puertoDescarga"));
				tmpSAR.setContenedor(rs.getString("contenedor"));
				tmpSAR.setBooking(rs.getString("booking"));
				tmpSAR.setEtdPlanner(rs.getInt("etd"));
				tmpSAR.setEtdReal(rs.getInt("etdFinal"));
				tmpSAR.setComentarioCancelacion(rs.getString("comentarioCancelacion"));
				tmpSAR.setFolioConsolidado(rs.getInt("folioConsolidado"));
				if (rs.wasNull()) {
					tmpSAR.setFolioConsolidado(null);
				}
				tmpSAR.setEsAereo(rs.getBoolean("esAereo"));
				tmpSAR.setAvion(rs.getString("avion"));
				tmpSAR.setAerolinea(rs.getInt("aerolinea"));
				tmpSAR.setLlegadaAvion(rs.getInt("llegadaAvion"));
				if (rs.wasNull()) {
					tmpSAR.setLlegadaAvion(null);
				}

				tmpSAR.setTransporte(rs.getInt("transporte"));
				tmpSAR.setComentarioPlanner(rs.getString("comentarioPlanner"));
				tmpSAR.setComentarioShipping(rs.getString("comentarioShipping"));
				tmpSAR.setEsSinPO(rs.getBoolean("esSinPO"));
				tmpSAR.setEta(rs.getInt("eta"));

				tmpSAR.setBl(rs.getString("bl"));
				tmpSAR.setAprobadoPorCompras(rs.getBoolean("aprobadoPorCompras"));
				tmpSAR.setTipoRetraso(rs.getInt("tipoRetraso"));
				tmpSAR.setCreationDate(rs.getInt("fechaCreacion"));
				tmpSAR.setModificadoProveedor(rs.getBoolean("fueModificadoProveedor"));
				tmpSAR.setAceptadoConDiferencias(rs.getBoolean("aceptadoConDiferencias"));
				if (rs.wasNull()) {
					tmpSAR.setAceptadoConDiferencias(null);
				}
				tmpSAR.setPaisDestino(rs.getInt("paisDestino"));
				if (rs.wasNull()) {
					tmpSAR.setPaisDestino(null);
				}

				tmpSAR.setCargoAProveedor(rs.getBoolean("cargoAProveedor"));
				tmpSAR.setOtraAerolinea(rs.getString("otraAerolinea"));
				tmpSAR.setAprobadoProveedor(rs.getBoolean("aprobadoProveedor"));

				tmpSAR.setEsMultiple(rs.getBoolean("esmultiple"));
				if (rs.wasNull()) {
					tmpSAR.setEsMultiple(null);
				}
				tmpSAR.setMandante(rs.getInt("mandante"));
				if (rs.wasNull()) {
					tmpSAR.setMandante(null);
				}
				tmpSAR.setAprobadoSDI(rs.getBoolean("aprobadoSDI"));
				if (rs.wasNull()) {
					tmpSAR.setAprobadoSDI(null);
				}

				tmpSAR.setCerradoDocumentosProveedor(rs.getBoolean("cerradoDocumentosProveedor"));
				tmpSAR.setFechaCierreDocumentosProveedor(rs.getInt("fechaCierreDocumentosProveedor"));
				tmpSAR.setFechaAprobadoSDI(rs.getInt("fechaAprobadoSDI"));
				tmpSAR.setComentarioTruperBooking(rs.getString("comentarioTruperBooking"));

				tmpSAR.setFechaUltimaCorreccion(rs.getInt("fechaUltimaCorreccion"));
				tmpSAR.setUsuarioAceptoRechazoSAR(rs.getString("usuarioUltimoRechazoAceptacion"));
				tmpSAR.setRevision(rs.getInt("revision"));
				tmpSAR.setFechaUltimoRechazo(rs.getInt("fechaUltimoRechazo"));
				tmpSAR.setFecIniPlanning(rs.getLong("fecIniPlanning"));
				tmpSAR.setTinyFecIniPlanning(rs.getInt("tinyFecIniPlanning"));
				tmpSAR.setFecIniShipping(rs.getLong("fecIniShipping"));
				tmpSAR.setTinyFecIniShipping(rs.getInt("tinyFecIniShipping"));
				tmpSAR.setFecIniConsolidados(rs.getLong("fecIniConsol"));
				tmpSAR.setTinyFecIniConsolidados(rs.getInt("tinyFecIniConsol"));
				tmpSAR.setFecIniBooking(rs.getLong("fecIniBooking"));
				tmpSAR.setTinyFecIniBooking(rs.getInt("tinyFecIniBooking"));
				tmpSAR.setFecIniSDI(rs.getLong("fecIniSDI"));
				tmpSAR.setTinyFecIniSDI(rs.getInt("tinyFecIniSDI"));
				tmpSAR.setFecIniEmbarque(rs.getLong("fecIniEmbarque"));
				tmpSAR.setTinyFecIniEmbarque(rs.getInt("tinyFecIniEmbarque"));
				tmpSAR.setEsRechazadoSDI(rs.getBoolean("rechazoDocumentosSDI"));

				tmpSAR.setNombreArchivoMRP(rs.getString("archivoMRP"));
				tmpSAR.setTieneDiferenciaMRP(rs.getBoolean("diferenciaMRP"));
				tmpSAR.setCargaArchivoMRP(rs.getInt("cargaArchivoMRP"));
				if (rs.wasNull()) {
					tmpSAR.setCargaArchivoMRP(null);
				}
				tmpSAR.setNeedsAuthImpDir(rs.getBoolean("needAuthImpDir"));
				tmpSAR.setAprobadoDirImportaciones(rs.getBoolean("aprobadoDirImportaciones"));
				tmpSAR.setUserApruebaDirImportaciones(rs.getString("userApruebaDirImportaciones"));
				tmpSAR.setFechaAprobacionDirImportaciones(rs.getInt("fechaApruebaDirImportaciones"));
				tmpSAR.setCommentForImpDir(rs.getString("commentForImpDir"));
				tmpSAR.setImpDirComments(rs.getString("impDirComments"));
				
				tmpSAR.setAprobadoConfMngr(rs.getBoolean("aprobadoConfMngr"));
				tmpSAR.setUserApruebaConfMngr(rs.getString("userApruebaConfMngr"));
				tmpSAR.setFechaApruebaConfMngr(rs.getInt("fechaApruebaConfMngr"));
				tmpSAR.setCommentForConfMngr(rs.getString("commentForConfMngr"));
				tmpSAR.setFecIniConfMngr(rs.getLong("fecIniConfMngr"));
				tmpSAR.setTinyFecIniConfMngr(rs.getInt("tinyFecIniConfMngr"));
				tmpSAR.setConfMngrComments("confMngrComments");
				
				tmpSAR.setAdelantoAtrasoETDImpDir(rs.getInt("adelantoAtrasoETDImpDir"));

				tmpSAR.setEtdProveedor(rs.getInt("etdProveedor"));
				if (rs.wasNull()) {
					tmpSAR.setEtdProveedor(null);
				}
				tmpSAR.setCargadoMRP(rs.getBoolean("cargadoMRP"));
				tmpSAR.setNotificacionMRP(rs.getBoolean("notificacionMRP"));
				tmpSAR.setEnRevisionConfirmFinal(rs.getBoolean("enRevisionConfirmFinal"));
				tmpSAR.setCommentRevFinalConfirm(rs.getString("commentRevFinalConfirm"));
				tmpSAR.setAceptadoRevFinalConfirm(rs.getBoolean("aceptadoRevFinalConfirm"));
				if (rs.wasNull()) {
					tmpSAR.setAceptadoRevFinalConfirm(null);
				}
				tmpSAR.setUsrAceptaRechazaRevFinal(rs.getString("usrAceptaRechazaRevFinal"));
				tmpSAR.setNumRevFinal(rs.getInt("numRevFinal"));
				Boolean aplicaBitacoraImpDir = (Boolean) rs.getObject("aplicaBitacoraImpDir");
				tmpSAR.setAplicaBitacora(aplicaBitacoraImpDir);
				Boolean bitacoraImpDirCerrada = (Boolean) rs.getObject("bitacoraImpDirCerrada");
				tmpSAR.setBitacoraImportsDirCerrada(bitacoraImpDirCerrada);
				tmpSAR.setFecCierreBitacoraImpDir(rs.getInt("fecCierreBitacoraImpDir"));
				if (rs.wasNull()) {
					tmpSAR.setFecCierreBitacoraImpDir(null);
				}
				Boolean tieneSim = (Boolean) rs.getObject("tieneSimulador");
				tmpSAR.setTieneSimulador(tieneSim);

				Boolean preciosLiberados = (Boolean) rs.getObject("preciosLiberados");
				tmpSAR.setPreciosLiberados(preciosLiberados);
				tmpSAR.setVersionSDI(rs.getInt("versionSetDocumentos"));
				tmpSAR.setEnRevicionIDA(rs.getBoolean("enrevisionIDA"));
				tmpSAR.setBitacoraIDA(rs.getBoolean("bitacoraIDA"));
				tmpSAR.setBitacoraIDACerrada(rs.getBoolean("bitacoraIDACerrada"));

				listaSAR.add(tmpSAR);
			}
			rs.close();
			pst.close();
			ConexionDB.devuelveConexion(con);

		} catch (SQLException sqlE) {
			try {
				log.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
			throw sqlE;
		} catch (IOException ioE) {
			try {
				log.error(ioE.getMessage(), ioE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception ioE2) {
				log.error(ioE2.getMessage(), ioE2);
			}
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}

		return listaSAR;
	}

	public static boolean eliminaPosicion(int folio, String po, int posicion) {
		Connection con = null;
		Statement st = null;
		int res = 0;
		try {
			con = ConexionDB.dameConexion();
			st = con.createStatement();

			String delete = "DELETE FROM cdiSARDetalle WHERE folio = " + folio + " AND po = '" + po
					+ "' AND posicion = " + posicion;
			res = st.executeUpdate(delete);
			
			ConexionDB.devuelveConexion(con);
			log.info("[Eliminar posicion] OK!! SAR: " + folio + " po::" + po + " pos " + posicion);
		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				log.error("[Eliminar posicion] Error SAR: " + folio + " po::" + po + " pos " + posicion + " causa::"
						+ ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
			log.error("[Eliminar posicion] Error SAR: " + folio + " po::" + po + " pos " + posicion + " causa::"
					+ e.getMessage(), e);
		} catch (Exception e) {
			e.printStackTrace();
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}

		return (res > 0);
	}
	
	public static Integer  getCdisarsenbooking(Integer folio) {
		Connection con = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		StringBuilder select = new StringBuilder();
		select.append("select id from cdisarsenbooking where  SAR =  ?");
		Integer  idCdisarsenbooking = 0;
		try {
			con = ConexionDB.dameConexion();
			pst = con.prepareStatement(select.toString());
			pst.setInt(1, folio);
			rs = pst.executeQuery();

			while (rs.next()) {
				idCdisarsenbooking= rs.getInt("id");
			}
			rs.close();
			pst.close();
		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} catch (Exception e) {
			e.printStackTrace();
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
		return idCdisarsenbooking;
	}
	
	

	public static SarBO insertaNuevoSAR(String proveedor, int tipoContenedor, boolean esSinPO, int status) {
		Connection con = null;
		Statement st = null;
		ResultSet rs = null;

		int folioGenerado = -1;
		int fechaCreacion = 0;

		try {
			GregorianCalendar hoyInt = new GregorianCalendar();
			String insert = "INSERT INTO cdiSAR (proveedor, status, fechaCreacion) VALUES (" + proveedor + ", " + status
					+ "," + FuncionesComunesPLI.gregorianCalendar2int(hoyInt) + ")";

			con = ConexionDB.dameConexion();
			st = con.createStatement();
			st.execute(insert);

			rs = st.executeQuery("SELECT TOP (1) folio, fechaCreacion FROM dbo.cdiSAR ORDER BY folio DESC");
			while (rs.next()) {
				folioGenerado = rs.getInt("folio");
				fechaCreacion = rs.getInt("fechaCreacion");
			}

			ConexionDB.devuelveConexion(con);

		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} catch (Exception e) {
			e.printStackTrace();
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}

		SarBO newSar = new SarBO(folioGenerado, proveedor, null);
		newSar.setCreationDate(fechaCreacion);
		return newSar;
	}

	/**
	 * MEtodo que me ayuda a generar un nuevo sar, para los sars que no tienen una
	 * PO, pero se puede utilizar para cualquier tipo de nuevo sar.
	 * 
	 * @param bean
	 * @return
	 */
	public static int insertaNuevoSARBean(SarBO bean) {
		Connection con = null;
		Statement st = null;
		ResultSet rs = null;

		int folioGenerado = -1;
		GregorianCalendar hoyInt = new GregorianCalendar();
		try {
			String insert = "INSERT INTO cdiSAR (proveedor, status, tipoContenedor, consolidado,esSinPO,puertoSalida,fechaEmbarque,fechaCreacion) "
					+ " VALUES ('" + bean.getProveedor() + "', " + bean.getStatus() + ", " + bean.getTipoContenedor()
					+ "," + (bean.getConsolidado() ? 1 : 0) + "," + (bean.getEsSinPO() ? 1 : 0) + ","
					+ bean.getPuertoSalida() + "," + bean.getFechaEmbarque() + ","
					+ FuncionesComunesPLI.gregorianCalendar2int(hoyInt) + ")";

			con = ConexionDB.dameConexion();
			st = con.createStatement();
			st.execute(insert);

			rs = st.executeQuery("SELECT TOP (1) folio FROM cdiSAR ORDER BY folio DESC");
			while (rs.next()) {
				folioGenerado = rs.getInt("folio");
			}

			ConexionDB.devuelveConexion(con);

		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} catch (Exception e) {
			e.printStackTrace();
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}

		return folioGenerado;
	}

	public boolean updateFolio(SarBO base, UserBean usuario) throws SQLException, ClassNotFoundException {

		Connection con = null;
		boolean result = false;

		try {
			con = ConexionDB.dameConexion();

			PreparedStatement pst = null;
			StringBuffer query = new StringBuffer();

			query.append(" update cdiSAR ");
			query.append(" set ");

			if (base.getEsAereo() != null) {
				query.append(" esAereo = ?,");
			}
			if (base.getProveedor() != null) {
				query.append(" proveedor = ?, ");
			}
			if (base.getPuertoSalida() != null) {
				query.append(" puertoSalida = ?, ");
			}
			if (base.getNaviera() != null) {
				query.append(" naviera = ?, ");
			}
			if (base.getFechaEmbarque() != null) {
				query.append(" fechaEmbarque = ?, ");
			}
			if (base.getConsolidado() != null) {
				query.append(" consolidado = ?, ");
			}
			if (base.getFechaSolicitudDeAprobacion() != null) {
				query.append(" fechaSolAprobacion = ?, ");
			}
			if (base.getUsuarioSolicitudDeAprobacion() != null) {
				query.append(" usuarioSolAprobacion = ?, ");
			}
			if (base.getFechaUltimaAprobacionRechazo() != null) {
				query.append("  fechaUltAprobRechazo = ?, ");
			}
			if (base.getUsuarioApruebaPlanning() != null) {
				query.append(" usuarioApruebaPlanning = ?, ");
			}
			if (base.getUsuarioApruebaRechaza() != null) {
				query.append(" usuarioApruebaRechaza = ?, ");
			}
			if (base.getTipoContenedor() != null) {
				query.append(" tipoContenedor = ?, ");
			}
			if (base.getPrioridad() != null) {
				query.append(" prioridad  = ?, ");
			}
			if (base.getViaje() != null) {
				query.append(" viaje = ?, ");
			}
			if (base.getPuertoDescarga() != null) {
				query.append(" puertoDescarga = ?, ");
			}
			if (base.getContenedor() != null) {
				query.append(" contenedor = ?, ");
			}
			if (base.getFolioConsolidado() != null) {
				query.append(" folioConsolidado = ?, ");
			}
			if (base.getBooking() != null) {
				query.append(" booking = ").append( UtilsSQL.getInstance().clearStringsSQL() ).append( ", ");
			}
			if (base.getEtdPlanner() != null) {
				query.append(" etd = ?, ");
			}
			if (base.getEtdReal() != null) {
				query.append(" etdFinal = ?, ");
			}
			if (base.getBarcoSugerido() != null) {
				query.append(" barcoSugerido = ?, ");
			}
			if (base.getTransporte() != null) {
				query.append(" transporte = ?, ");
			}
			if (base.getComentarioPlanner() != null) {
				query.append(" comentarioPlanner = ?, ");
			}
			if (base.getComentarioShipping() != null) {
				query.append(" comentarioShipping = ?, ");
			}
			if (base.getBl() != null) {
				query.append(" BL = ?, ");
			}
			if (base.getFechaBl() != null) {
				query.append(" fechaBL = ?, ");
			}
			if (base.getEta() != null) {
				query.append(" eta = ?, ");
			}
			if (base.getComentarioTruperBooking() != null) {
				query.append(" comentarioTruperBooking = ?, ");
			}
			if (base.getAprobadoPorCompras() != null) {
				query.append(" aprobadoPorCompras = ?, ");
			}
			if (base.getTipoRetraso() != null) {
				query.append(" tipoRetraso = ?, ");
			}
			if (base.esModificadoProveedor() != null) {
				query.append(" fueModificadoProveedor = ?, ");
			}
			if (base.getAprobadoProveedor() != null) {
				query.append(" aprobadoProveedor = ?, ");
			}
			if (base.getAerolinea() != null) {
				query.append(" aerolinea = ?, ");
			}
			if (base.getAvion() != null) {
				query.append(" avion = ?, ");
			}
			if (base.getPaisDestino() != null && base.getPaisDestino()>0) {
				query.append(" paisdestino = ?, ");
			}
			if (base.getLlegadaAvion() != null) {
				query.append(" llegadaavion = ?, ");
			}
			if (base.esAprobadoSDI() != null) {
				query.append(" aprobadoSDI = ?, ");
			}
			if (base.getFecIniPlanning() != null) {
				query.append(" fecIniPlanning = ?, ");
			}
			if (base.getTinyFecIniPlanning() != null) {
				query.append(" TinyFecIniPlanning = ?, ");
			}
			if (base.getFecIniImpDir() != null) {
				query.append(" fecIniImpDir = ?, ");
			}
			if (base.getTinyFecIniImpDir() != null) {
				query.append(" TinyFecIniImpDir = ?, ");
			}
			if (base.getFecIniShipping() != null) {
				query.append(" fecIniShipping = ?, ");
			}
			if (base.getTinyFecIniShipping() != null) {
				query.append(" TinyFecIniShipping = ?, ");
			}
			if (base.getFecIniConsolidados() != null) {
				query.append(" fecIniConsol = ?, ");
			}
			if (base.getTinyFecIniConsolidados() != null) {
				query.append(" TinyFecIniConsol = ?, ");
			}
			if (base.getFecIniBooking() != null) {
				query.append(" fecIniBooking = ?, ");
			}
			if (base.getTinyFecIniBooking() != null) {
				query.append(" TinyFecIniBooking = ?, ");
			}
			if (base.getFecIniSDI() != null) {
				query.append(" fecIniSDI = ?, ");
			}
			if (base.getTinyFecIniSDI() != null) {
				query.append(" TinyFecIniSDI = ?, ");
			}
			if (base.getFecIniEmbarque() != null) {
				query.append(" fecIniEmbarque = ?, ");
			}
			if (base.getTinyFecIniEmbarque() != null) {
				query.append(" tinyFecIniEmbarque = ?, ");
			}

			if (base.getEsRechazadoSDI() != null) {
				query.append(" rechazoDocumentosSDI = ?, ");
			}

			if (base.getNeedsAuthImpDir() != null) {
				query.append(" needAuthImpDir = ?, ");
			}

			if (base.getAprobadoDirImportaciones() != null) {
				query.append(" aprobadoDirImportaciones = ?, ");
			}

			if( base.getAprobadoConfMngr() != null ) {
				query.append(" aprobadoConfMngr = ?, ");
			}
			
			if (base.getUserApruebaDirImportaciones() != null) {
				query.append(" userApruebaDirImportaciones = ?, ");
			}
			
			if( base.getUserApruebaConfMngr() != null ) {
				query.append(" userApruebaConfMngr = ?, ");
			}
			
			if( base.getFechaApruebaConfMngr() != null ) {
				query.append(" fechaApruebaConfMngr = ?, ");
			}
			
			if( base.getCommentForConfMngr() != null ) {
				query.append(" commentForConfMngr = ?, ");
			}
			
			if( base.getFecIniConfMngr() != null ) {
				query.append(" fecIniConfMngr = ?, ");
			}
			
			if( base.getTinyFecIniConfMngr() != null ) {
				query.append(" tinyFecIniConfMngr = ?, ");
			}
			
			if( base.getConfMngrComments() != null ) {
				query.append(" confMngrComments = ?, ");
			}
			
			if (base.getFechaAprobacionDirImportaciones() != null) {
				query.append(" fechaApruebaDirImportaciones = ?, ");
			}

			if (base.getCommentForImpDir() != null) {
				query.append(" commentForImpDir = ?, ");
			}

			if (base.getImpDirComments() != null) {
				query.append(" impDirComments = ?, ");
			}

			if (base.getAdelantoAtrasoETDImpDir() != null) {
				query.append(" adelantoAtrasoETDImpDir = ?, ");
			}

			if (base.getCargadoMRP() != null) {
				query.append(" cargadoMRP = ?, ");
			}

			if (base.getEnRevisionConfirmFinal() != null) {
				query.append(" enRevisionConfirmFinal = ?, ");
			}

			if (base.getCommentRevFinalConfirm() != null) {
				query.append(" commentRevFinalConfirm = ?, ");
			}

			if (base.getAceptadoRevFinalConfirm() != null) {
				query.append(" aceptadoRevFinalConfirm = ?, ");
			}

			if (base.getUsrAceptaRechazaRevFinal() != null) {
				query.append(" usrAceptaRechazaRevFinal = ?, ");
			}

			if (base.getNumRevFinal() != null) {
				query.append(" numRevFinal = ?, ");
			}

			if (base.getAplicaBitacora() != null) {
				query.append(" aplicaBitacoraImpDir = ?, ");
			}

			if (base.getBitacoraImportsDirCerrada() != null) {
				query.append(" bitacoraImpDirCerrada = ?, ");
			}

			if (base.getFecCierreBitacoraImpDir() != null) {
				query.append(" fecCierreBitacoraImpDir = ?, ");
			}

			if (base.getDisagreeComments() != null) {
				query.append(" disagreeComments = ?, ");
			}

			if (base.getPreciosLiberados() != null) {
				query.append(" preciosLiberados = ?, ");
			}

			if (base.getPreciosEnRevision() != null) {
				query.append(" preciosEnRevision = ?, ");
			}

			if (base.getPreciosRevisados() != null) {
				query.append(" preciosRevisados = ?, ");
			}

			if (base.getContenedorProveedor() != null) {
				query.append(" contenedorProveedor = ?, ");
			}
			if (base.getSealNumber() != null) {
				query.append(" sealNumber = ?, ");
			}
			if (base.getComentarioCancelacion() != null) {
				query.append(" comentarioCancelacion = ?, ");
			}
			if (base.isCierraConfirmacionFinal()) {
				query.append(" fechaConfirmacionFinal = GETDATE(), ");
			}
			if (base.getTinyFechIniProfileApproved() != null) {
				query.append(" tinyFechIniProfileApproved = ?, ");
			}
			if (base.getGuideline() != null) {
				query.append(" guideline = ?, ");
			}
			if(base.getCommentProfiles() != null){
				query.append(" commentProfiles = ?, ");
			}
			if(base.getReleaseRequirementsBC() != null){
				query.append(" releaseRequirementsBC = ?, ");
			}
			if(base.getApprovedConfirmationManager() != null){
				query.append(" approvedConfirmationManager = ?, ");
			}
			if(base.getApprovedSrManager() != null){
				query.append(" approvedSrManager = ?, ");
			}
			if(base.getApprovedDirector() != null){
				query.append(" approvedDirector = ?, ");
			}
			if(base.getApprovedOverStock() != null){
				query.append(" approvedOverStock = ?, ");
			}
			

			// Ojo aqui incluyo logica para quitar una ","
			// si es que estatus no es el ultimo registro siempre dejar ", "
			// coma y espacio para ser 2 lugares
			boolean statusIsLast = false;
			if (base.getStatus() != null) {
				statusIsLast = true;
				query.append(" status = ? ");
			}
			if (!statusIsLast) {
				query = query.delete(query.length() - 2, query.length());
			}

			if (base.getBookingUpdateSupplier() != null
					|| (base.getResetUpdateSupplier() != null && base.getResetUpdateSupplier())) {
				query.append(" , bookingUpdateSupplier = ? ");
			}
			if (base.getCarrierUpdateSupplier() != 0
					|| (base.getResetUpdateSupplier() != null && base.getResetUpdateSupplier())) {
				query.append("   , carrierUpdateSupplier = ? ");
			}
			if (base.getDateETDFinalUpdateSupplier() != null
					|| (base.getResetUpdateSupplier() != null && base.getResetUpdateSupplier())) {
				query.append(" , dateETDFinalUpdateSupplier = ? ");
			}
			if (base.getEsRechazado() != null) {
				query.append(", isRechazado = ? ");
			}

			query.append(" where folio  = ? ");

			pst = con.prepareStatement(query.toString());

			int cont = 1;

			if (base.getEsAereo() != null) {
				agregarPs(cont++, pst, base.getEsAereo(), Boolean.class);
			}
			if (base.getProveedor() != null) {
				agregarPs(cont++, pst, base.getProveedor(), String.class);
			}
			if (base.getPuertoSalida() != null) {
				agregarPs(cont++, pst, base.getPuertoSalida(), String.class);
			}
			if (base.getNaviera() != null) {
				agregarPs(cont++, pst, base.getNaviera(), Integer.class);
			}
			if (base.getFechaEmbarque() != null) {
				agregarPs(cont++, pst, base.getFechaEmbarque(), Integer.class);
			}
			if (base.getConsolidado() != null) {
				agregarPs(cont++, pst, base.getConsolidado(), Boolean.class);
			}
			if (base.getFechaSolicitudDeAprobacion() != null) {
				agregarPs(cont++, pst, base.getFechaSolicitudDeAprobacion(), Integer.class);
			}
			if (base.getUsuarioSolicitudDeAprobacion() != null) {
				agregarPs(cont++, pst, base.getUsuarioSolicitudDeAprobacion(), String.class);
			}
			if (base.getFechaUltimaAprobacionRechazo() != null) {
				agregarPs(cont++, pst, base.getFechaUltimaAprobacionRechazo(), Integer.class);
			}
			if (base.getUsuarioApruebaPlanning() != null) {
				agregarPs(cont++, pst, base.getUsuarioApruebaPlanning(), String.class);
			}
			if (base.getUsuarioApruebaRechaza() != null) {
				agregarPs(cont++, pst, base.getUsuarioApruebaRechaza(), String.class);
			}
			if (base.getTipoContenedor() != null) {
				agregarPs(cont++, pst, base.getTipoContenedor(), Integer.class);
			}
			if (base.getPrioridad() != null) {
				agregarPs(cont++, pst, base.getPrioridad(), Integer.class);
			}
			if (base.getViaje() != null) {
				agregarPs(cont++, pst, base.getViaje(), String.class);
			}
			if (base.getPuertoDescarga() != null) {
				agregarPs(cont++, pst, base.getPuertoDescarga(), String.class);
			}
			if (base.getContenedor() != null) {
				agregarPs(cont++, pst, base.getContenedor(), String.class);
			}
			if (base.getFolioConsolidado() != null) {
				agregarPs(cont++, pst, base.getFolioConsolidado(), Integer.class);
			}
			if (base.getBooking() != null) {
				agregarPs(cont++, pst, base.getBooking().trim(), String.class);
			}
			if (base.getEtdPlanner() != null) {
				agregarPs(cont++, pst, base.getEtdPlanner(), Integer.class);
			}
			if (base.getEtdReal() != null) {
				agregarPs(cont++, pst, base.getEtdReal(), Integer.class);
			}
			if (base.getBarcoSugerido() != null) {
				agregarPs(cont++, pst, base.getBarcoSugerido(), String.class);
			}
			if (base.getTransporte() != null) {
				agregarPs(cont++, pst, base.getTransporte(), Integer.class);
			}
			if (base.getComentarioPlanner() != null) {
				agregarPs(cont++, pst, base.getComentarioPlanner(), String.class);
			}
			if (base.getComentarioShipping() != null) {
				agregarPs(cont++, pst, base.getComentarioShipping(), String.class);
			}
			if (base.getBl() != null) {
				agregarPs(cont++, pst, base.getBl(), String.class);
			}
			if (base.getFechaBl() != null) {
				agregarPs(cont++, pst, base.getFechaBl(), Integer.class);
			}
			if (base.getEta() != null) {
				agregarPs(cont++, pst, base.getEta(), Integer.class);
			}
			if (base.getComentarioTruperBooking() != null) {
				agregarPs(cont++, pst, base.getComentarioTruperBooking(), String.class);
			}
			if (base.getAprobadoPorCompras() != null) {
				agregarPs(cont++, pst, base.getAprobadoPorCompras(), Boolean.class);
			}
			if (base.getTipoRetraso() != null) {
				agregarPs(cont++, pst, base.getTipoRetraso(), Integer.class);
			}
			if (base.esModificadoProveedor() != null) {
				agregarPs(cont++, pst, base.esModificadoProveedor(), Boolean.class);
			}
			if (base.getAprobadoProveedor() != null) {
				agregarPs(cont++, pst, base.getAprobadoProveedor(), Boolean.class);
			}
			if (base.getAerolinea() != null) {
				agregarPs(cont++, pst, base.getAerolinea(), Integer.class);
			}
			if (base.getAvion() != null) {
				agregarPs(cont++, pst, base.getAvion(), String.class);
			}
			if (base.getPaisDestino() != null && base.getPaisDestino()>0) {
				agregarPs(cont++, pst, base.getPaisDestino(), Integer.class);
			}
			if (base.getLlegadaAvion() != null) {
				agregarPs(cont++, pst, base.getLlegadaAvion(), Integer.class);
			}
			if (base.esAprobadoSDI() != null) {
				agregarPs(cont++, pst, base.esAprobadoSDI(), Boolean.class);
			}
			if (base.getFecIniPlanning() != null) {
				agregarPs(cont++, pst, base.getFecIniPlanning(), Long.class);
			}
			if (base.getTinyFecIniPlanning() != null) {
				agregarPs(cont++, pst, base.getTinyFecIniPlanning(), Integer.class);
			}
			if (base.getFecIniImpDir() != null) {
				agregarPs(cont++, pst, base.getFecIniImpDir(), Long.class);
			}
			if (base.getTinyFecIniImpDir() != null) {
				agregarPs(cont++, pst, base.getTinyFecIniImpDir(), Integer.class);
			}
			if (base.getFecIniShipping() != null) {
				agregarPs(cont++, pst, base.getFecIniShipping(), Long.class);
			}
			if (base.getTinyFecIniShipping() != null) {
				agregarPs(cont++, pst, base.getTinyFecIniShipping(), Integer.class);
			}
			if (base.getFecIniConsolidados() != null) {
				agregarPs(cont++, pst, base.getFecIniConsolidados(), Long.class);
			}
			if (base.getTinyFecIniConsolidados() != null) {
				agregarPs(cont++, pst, base.getTinyFecIniConsolidados(), Integer.class);
			}
			if (base.getFecIniBooking() != null) {
				agregarPs(cont++, pst, base.getFecIniBooking(), Long.class);
			}
			if (base.getTinyFecIniBooking() != null) {
				agregarPs(cont++, pst, base.getTinyFecIniBooking(), Integer.class);
			}
			if (base.getFecIniSDI() != null) {
				agregarPs(cont++, pst, base.getFecIniSDI(), Long.class);
			}
			if (base.getTinyFecIniSDI() != null) {
				agregarPs(cont++, pst, base.getTinyFecIniSDI(), Integer.class);
			}
			if (base.getFecIniEmbarque() != null) {
				agregarPs(cont++, pst, base.getFecIniEmbarque(), Long.class);
			}
			if (base.getTinyFecIniEmbarque() != null) {
				agregarPs(cont++, pst, base.getTinyFecIniEmbarque(), Integer.class);
			}
			if (base.getEsRechazadoSDI() != null) {
				agregarPs(cont++, pst, base.getEsRechazadoSDI(), Boolean.class);
			}
			if (base.getNeedsAuthImpDir() != null) {
				agregarPs(cont++, pst, base.getNeedsAuthImpDir(), Boolean.class);
			}
			if (base.getAprobadoDirImportaciones() != null) {
				agregarPs(cont++, pst, base.getAprobadoDirImportaciones(), Boolean.class);
			}
			if( base.getAprobadoConfMngr() != null ) {
				agregarPs(cont++, pst, base.getAprobadoConfMngr(), Boolean.class);
			}
			if (base.getUserApruebaDirImportaciones() != null) {
				agregarPs(cont++, pst, base.getUserApruebaDirImportaciones(), String.class);
			}
			if( base.getUserApruebaConfMngr() != null ) {
				agregarPs(cont++, pst, base.getUserApruebaConfMngr(), String.class);
			}
			if( base.getFechaApruebaConfMngr() != null ) {
				agregarPs(cont++, pst, base.getFechaApruebaConfMngr(), Integer.class);
			}
			if( base.getCommentForConfMngr() != null ) {
				agregarPs(cont++, pst, base.getCommentForConfMngr(), String.class);
			}
			if( base.getFecIniConfMngr() != null ) {
				agregarPs(cont++, pst, base.getFecIniConfMngr(), Long.class);
			}
			if( base.getTinyFecIniConfMngr() != null ) {
				agregarPs(cont++, pst, base.getTinyFecIniConfMngr(), Integer.class);
			}
			if( base.getConfMngrComments() != null ) {
				agregarPs(cont++, pst, base.getConfMngrComments(), String.class);
			}
			if (base.getFechaAprobacionDirImportaciones() != null) {
				agregarPs(cont++, pst, base.getFechaAprobacionDirImportaciones(), Integer.class);
			}
			if (base.getCommentForImpDir() != null) {
				agregarPs(cont++, pst, base.getCommentForImpDir(), String.class);
			}
			if (base.getImpDirComments() != null) {
				agregarPs(cont++, pst, base.getImpDirComments(), String.class);
			}
			if (base.getAdelantoAtrasoETDImpDir() != null) {
				agregarPs(cont++, pst, base.getAdelantoAtrasoETDImpDir(), Integer.class);
			}
			if (base.getCargadoMRP() != null) {
				agregarPs(cont++, pst, base.getCargadoMRP(), Boolean.class);
			}
			if (base.getEnRevisionConfirmFinal() != null) {
				agregarPs(cont++, pst, base.getEnRevisionConfirmFinal(), Boolean.class);
			}
			if (base.getCommentRevFinalConfirm() != null) {
				agregarPs(cont++, pst, base.getCommentRevFinalConfirm(), String.class);
			}
			if (base.getAceptadoRevFinalConfirm() != null) {
				agregarPs(cont++, pst, base.getAceptadoRevFinalConfirm(), Boolean.class);
			}
			if (base.getUsrAceptaRechazaRevFinal() != null) {
				agregarPs(cont++, pst, base.getUsrAceptaRechazaRevFinal(), String.class);
			}
			if (base.getNumRevFinal() != null) {
				agregarPs(cont++, pst, base.getNumRevFinal(), Integer.class);
			}
			if (base.getAplicaBitacora() != null) {
				agregarPs(cont++, pst, base.getAplicaBitacora(), Boolean.class);
			}
			if (base.getBitacoraImportsDirCerrada() != null) {
				agregarPs(cont++, pst, base.getBitacoraImportsDirCerrada(), Boolean.class);
			}
			if (base.getFecCierreBitacoraImpDir() != null) {
				agregarPs(cont++, pst, base.getFecCierreBitacoraImpDir(), Integer.class);
			}
			if (base.getDisagreeComments() != null) {
				agregarPs(cont++, pst, base.getDisagreeComments(), String.class);
			}
			if (base.getPreciosLiberados() != null) {
				agregarPs(cont++, pst, base.getPreciosLiberados(), Boolean.class);
			}
			if (base.getPreciosEnRevision() != null) {
				agregarPs(cont++, pst, base.getPreciosEnRevision(), Boolean.class);
			}
			if (base.getPreciosRevisados() != null) {
				agregarPs(cont++, pst, base.getPreciosRevisados(), Boolean.class);
			}
			if (base.getContenedorProveedor() != null) {
				agregarPs(cont++, pst, base.getContenedorProveedor(), String.class);
			}

			if (base.getSealNumber() != null) {
				agregarPs(cont++, pst, base.getSealNumber(), String.class);
			}
			// este campo siempre
			if (base.getComentarioCancelacion() != null) {
				agregarPs(cont++, pst, base.getComentarioCancelacion(), String.class);
			}
			if (base.getTinyFechIniProfileApproved() != null) {
				agregarPs(cont++, pst, base.getTinyFechIniProfileApproved(), Integer.class);
			}
			if (base.getGuideline() != null) {
				agregarPs(cont++, pst, base.getGuideline(), Integer.class);
			}
			
			if(base.getCommentProfiles() != null){
				agregarPs(cont++, pst, base.getCommentProfiles(), String.class);
			}
			if(base.getReleaseRequirementsBC() != null){
				agregarPs(cont++, pst, base.getReleaseRequirementsBC(), Boolean.class);
			}
			if(base.getApprovedConfirmationManager() != null){
				agregarPs(cont++, pst, base.getApprovedConfirmationManager(), Boolean.class);
			}
			if(base.getApprovedSrManager() != null){
				agregarPs(cont++, pst, base.getApprovedSrManager(), Boolean.class);
			}
			if(base.getApprovedDirector() != null){
				agregarPs(cont++, pst, base.getApprovedDirector(), Boolean.class);
			}
			
			if(base.getApprovedOverStock() != null){
				agregarPs(cont++, pst, base.getApprovedOverStock(), Boolean.class);
			}
			
			// ojo siempre hay que enviar el status
			if (base.getStatus() != null) {
				agregarPs(cont++, pst, base.getStatus(), Integer.class);
			}

			if (base.getBookingUpdateSupplier() != null
					|| (base.getResetUpdateSupplier() != null && base.getResetUpdateSupplier())) {
				agregarPs(cont++, pst, base.getBookingUpdateSupplier(), String.class);
			}

			if (base.getCarrierUpdateSupplier() != 0
					|| (base.getResetUpdateSupplier() != null && base.getResetUpdateSupplier())) {
				agregarPs(cont++, pst, base.getCarrierUpdateSupplier(), Integer.class);
			}

			if (base.getDateETDFinalUpdateSupplier() != null
					|| (base.getResetUpdateSupplier() != null && base.getResetUpdateSupplier())) {
				agregarPs(cont++, pst, base.getDateETDFinalUpdateSupplier(), Integer.class);
			}
			if (base.getEsRechazado() != null
					|| (base.getEsRechazado() != null && base.getEsRechazado())) {
				agregarPs(cont++, pst, base.getEsRechazado(), Boolean.class);
			}

			agregarPs(cont++, pst, base.getFolio(), Integer.class);

			int resultado = pst.executeUpdate();

			pst.close();

			ConexionDB.devuelveConexion(con);
			if (resultado > 0) {
				result = resultado > 0 ? true : false; 
			}
		} catch (SQLException sqlE) {
			try {
				con.rollback();
				log.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(con);
				throw new SQLException(sqlE);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
			throw sqlE;
		} catch (IOException ioE) {
			try {
				con.rollback();
				log.error(ioE.getMessage(), ioE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception ioE2) {
				log.error(ioE2.getMessage(), ioE2);
			}
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}

		return result;
	}

	public void mergeUltimaETD(SarBO sar, SARConsolidados sarConsol, UserBean user) {
		SarDetalleReporte sarDetalleReporte = SarsUtils.getInstance().getDataForLastETD(sar, sarConsol);
		Connection con = null;

		try {
			if (sarDetalleReporte != null) {

				StringBuilder sql = new StringBuilder();

				sql.append("   MERGE cdiSarUltimaETD AS [target]  ");
				sql.append("   USING (SELECT  ? folio, ");
				sql.append("                  ? etd ,  ");
				sql.append("			      ? usernameEtd ) AS [source]   ");
				sql.append("   ON [target].folio = [source].folio   ");
				sql.append("   WHEN MATCHED AND [target].etd <> [source].etd  ");
				sql.append("   THEN ");
				sql.append(
						"   update set [target].etd =[source].[etd]  , [target].[usernameEtd] = [source].[usernameEtd]	, [target].[modifyDate]	 = GETDATE() ");
				sql.append("   WHEN not matched  ");
				sql.append("   THEN  ");
				sql.append("   INSERT ([folio] , [etd], [usernameEtd])  ");
				sql.append("   VALUES([source].[folio] ,[source].[etd], [source].[usernameEtd]);   ");

				con = ConexionDB.dameConexion();

				PreparedStatement ps = con.prepareStatement(sql.toString());
				ps.setString(1, sarDetalleReporte.getFolio());

				ps.setString(2, sarDetalleReporte.getUltimaETD());
				ps.setString(3, user.getUserName());
				ps.executeUpdate();

				con.close();
			}
		} catch (Exception e) {
			log.error(e.toString(), e);
		} finally {
			ConexionDB.devolver(con);
		}

	}

	public void getSarUltimaETD(SarDetalleReporte sarDR) {
		Connection con = null;
		ResultSet rs = null;
		PreparedStatement pst = null;
		String folio = UtilsNumero.isInteger(sarDR.getFolioConsolidado()) ? sarDR.getFolioConsolidado()
				: sarDR.getFolio().substring(1);

		if (!UtilsNumero.isInteger(folio))
			return;

		try {
			StringBuilder sql = new StringBuilder();
			sql.append(" SELECT  sar.folio , sar.etd , sar.usernameEtd FROM  [cdiSarUltimaETD]  sar  ");
			sql.append(" WHERE sar.folio =  ?  ");

			con = ConexionDB.dameConexion();
			pst = con.prepareStatement(sql.toString());
			pst.setInt(1, Integer.parseInt(folio));
			rs = pst.executeQuery();

			while (rs.next()) {
				sarDR.setUltimaETD(DateUtils.getInstance().getDateToString(rs.getDate("etd"), "YYYY-MM-dd", Locale.US));
				sarDR.setUsuarioUltimaETD(rs.getString("usernameEtd"));
			}

			con.close();

		} catch (Exception e) {
			log.error(e.toString(), e);
		} finally {
			ConexionDB.devolver(con);
		}

	}

	public ResetBean noResetBookings(List<String> bookings) {
		Connection con = null;
		ResultSet rs = null;
		Statement st = null;

		ResetBean resetBean = new ResetBean();
		List<ResetVO> actualizados = new ArrayList<ResetVO>();
		List<ResetVO> noActualizados = new ArrayList<ResetVO>();
		List<String> bookingsEncontrados = new ArrayList<String>();
		List<String> bookingsNoEncontrados = new ArrayList<String>();

		try {
			StringBuilder sql = new StringBuilder();
			sql.append("  select   distinct sar.folio ,  sarInB.sar , sar.booking  from [cdiSARsEnBooking] sarInB   ");
			sql.append("  right join [cdiSAR] sar on    sarInB.sar = sar.folio ");
			sql.append("  where  sar.booking in  ");
			sql.append(UtilsSQL.convierteToIN(bookings));

			con = ConexionDB.dameConexion();
			st = con.createStatement();
			rs = st.executeQuery(sql.toString());

			System.out.println(sql.toString());

			while (rs.next()) {
				bookingsEncontrados.add(rs.getString("booking"));
				String sar = rs.getString("sar");
				if (UtilsString.isStringValida(sar)) {
					ResetVO noActualizado = new ResetVO();
					noActualizado.setFolio(rs.getInt("folio"));
					noActualizado.setBooking(rs.getString("booking"));
					noActualizados.add(noActualizado);
				} else {
					ResetVO actualizado = new ResetVO();
					actualizado.setFolio(rs.getInt("folio"));
					actualizado.setBooking(rs.getString("booking"));
					actualizados.add(actualizado);
				}
			}

			for (String booking : bookings) {
				if (!bookingsEncontrados.contains(booking)) {
					bookingsNoEncontrados.add(booking);
				}
			}

			resetBean.setActualizados(actualizados);
			resetBean.setNoActualizados(noActualizados);
			resetBean.setNoEncontrados(bookingsNoEncontrados);
			ConexionDB.devuelveConexion(con);
			con.close();

		} catch (Exception e) {
			log.error(e.toString(), e);
		} finally {
			ConexionDB.devolver(con);
		}
		return resetBean;
	}

	public void resetBookings(List<String> bookings) {
		Connection con = null;
		Statement st = null;

		try {
			StringBuilder sql = new StringBuilder();

			sql.append(" update sar set sar.booking = '' , contenedor = ''  ");
			sql.append("  from cdiSar sar   ");
			sql.append("  left join [cdiSARsEnBooking] sarIB  ");
			sql.append("  on  sar.folio =  sarIB.sar  ");
			sql.append("  where sarIB.sar is null  ");
			sql.append("  and sar.booking in ");

			sql.append(UtilsSQL.convierteToIN(bookings));

			con = ConexionDB.dameConexion();
			st = con.createStatement();

			st.executeUpdate(sql.toString());
			ConexionDB.devuelveConexion(con);

			con.close();

		} catch (Exception e) {
			log.error(e.toString(), e);
		} finally {
			ConexionDB.devolver(con);
		}

	}

	/**
	 * Metodo para hacer el select de detalle por PO o por Folio
	 * 
	 * @deprecated usar el metodo
	 *             {@link SAR_CDI_DAO #selectSarDetalleDinamico(SarDetalleBO)}
	 * @param bean
	 * @return
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 */
	public ArrayList<SarDetalleBO> selectSarDetalle(SarDetalleBO bean) throws ClassNotFoundException {

		ArrayList<SarDetalleBO> listaSAR = new ArrayList<SarDetalleBO>();

		Connection con = null;

		try {
			con = ConexionDB.dameConexion();

			ResultSet rs = null;
			PreparedStatement pst = null;
			StringBuffer query = new StringBuffer();

			query.append(
					"SELECT folio, po, posicion , material , cantidad , pesoProveedor , volumenProveedor , centro,planeador,cantidadModificada,"
							+ "pesoModificado,volumenModificado,cliente,fechaProforma,paisOrigen,noDocumento,cartones,cantidadXcarton,pesoneto,pesobruto,cubicaje,pallet,cartonxpallet, ");
			query.append(
					" unidadMedida,condicionPago,moneda,preciounitario, esPedidoDirecto,tieneDiferenciaMRP, statusMRP, tipoValidacionMRP, almacen ");
			query.append(" FROM   cdiSARDetalle ");
			if (bean.getFolio() != null) {
				query.append(" WHERE   folio = ?   ");
			} else {
				query.append(" WHERE   po like  '%" + bean.getPo() + "%'   ");
			}

			query.append(" ORDER BY PO DESC");

			pst = con.prepareStatement(query.toString());
			if (bean.getFolio() != null) {
				pst.setInt(1, bean.getFolio());
			}

			rs = pst.executeQuery();

			while (rs.next()) {

				SarDetalleBO tmpSAR = new SarDetalleBO();
				tmpSAR.setPo(rs.getString("po").trim());
				tmpSAR.setPosicion(rs.getInt("posicion"));
				tmpSAR.setMaterial(rs.getInt("material"));
				tmpSAR.setCantidad(rs.getInt("cantidad"));
				tmpSAR.setPesoProveedor(rs.getDouble("pesoProveedor"));
				tmpSAR.setVolumenProveedor(rs.getDouble("volumenProveedor"));
				tmpSAR.setFolio(rs.getInt("folio"));
				tmpSAR.setCentro(rs.getString("centro"));
				tmpSAR.setPlaneador(rs.getString("planeador"));
				tmpSAR.setTieneDiferenciasMRP(rs.getBoolean("tieneDiferenciaMRP"));
				tmpSAR.setNumeroDoc(rs.getString("noDocumento"));
				if (rs.wasNull()) {
					tmpSAR.setNumeroDoc(null);
				}

				tmpSAR.setCantidadModificada(rs.getInt("cantidadModificada"));
				if (rs.wasNull()) {
					tmpSAR.setCantidadModificada(null);
				}
				tmpSAR.setPesoModificado(rs.getDouble("pesoModificado"));
				if (rs.wasNull()) {
					tmpSAR.setPesoModificado(null);
				}
				tmpSAR.setVolumenModificado(rs.getDouble("volumenModificado"));
				if (rs.wasNull()) {
					tmpSAR.setVolumenModificado(null);
				}
				tmpSAR.setCliente(rs.getString("cliente"));
				tmpSAR.setFechaProforma(rs.getInt("fechaProforma"));
				tmpSAR.setPaisOrigen(rs.getInt("paisOrigen"));
				if (rs.wasNull()) {
					tmpSAR.setPaisOrigen(null);
				}

				tmpSAR.setCartones(rs.getInt("cartones"));
				tmpSAR.setCantidadXCarton(rs.getInt("cantidadXcarton"));
				tmpSAR.setPesoNetoPKL(rs.getBigDecimal("pesoneto"));
				tmpSAR.setPesoBrutoPKL(rs.getBigDecimal("pesobruto"));
				tmpSAR.setCubicajePKL(rs.getBigDecimal("cubicaje"));
				tmpSAR.setPallet(rs.getInt("pallet"));
				tmpSAR.setCartonXPallet(rs.getInt("cartonxpallet"));
				tmpSAR.setUnidaMedida(rs.getString("unidadMedida"));
				tmpSAR.setCondicionPago(rs.getString("condicionPago"));
				tmpSAR.setMoneda(rs.getString("moneda"));
				BigDecimal precioUnitario = rs.getBigDecimal("preciounitario");
				if (rs.wasNull()) {
					precioUnitario = null;
				}
				tmpSAR.setPrecioUnitario(precioUnitario);
				tmpSAR.setPedidoDirecto(rs.getBoolean("esPedidoDirecto"));
				tmpSAR.setStatusMRP(rs.getInt("statusMRP"));
				if (rs.wasNull()) {
					tmpSAR.setStatusMRP(null);
				}
				tmpSAR.setTipoValidacionMRP(rs.getInt("tipoValidacionMRP"));
				tmpSAR.setAlmacen(rs.getString("almacen"));
				listaSAR.add(tmpSAR);
			}
			rs.close();
			pst.close();
			ConexionDB.devuelveConexion(con);

		} catch (SQLException sqlE) {
			try {
				log.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}

		return listaSAR;
	}

	/**
	 * 
	 * Metodo dinamico para seleccionar el detalle
	 * 
	 * @param bean
	 * @return
	 * @throws ClassNotFoundException
	 */
	public static ArrayList<SarDetalleBO> selectSarDetalleDinamico(SarDetalleBO bean) throws ClassNotFoundException {

		ArrayList<SarDetalleBO> listaSAR = new ArrayList<SarDetalleBO>();

		Connection con = null;
		DAOUtils utils = new DAOUtils();
		try {
			con = ConexionDB.dameConexion();

			ResultSet rs = null;
			PreparedStatement pst = null;
			StringBuffer query = new StringBuffer();
			utils.setSelect(true);

			query.append("SELECT folio, po, posicion , material , cantidad , pesoProveedor , volumenProveedor , ");
			query.append(
					" centro,planeador,cantidadModificada,pesoModificado,volumenModificado,cliente,fechaProforma, ");
			query.append(
					" paisOrigen,noDocumento,cartones,cantidadXcarton,pesoneto,pesobruto,cubicaje,pallet,cartonxpallet, ");
			query.append(" unidadMedida,condicionPago,moneda,preciounitario, esPedidoDirecto, ");
			query.append("tieneDiferenciaMRP, statusMRP, tipoValidacionMRP, cantidadUnidadMedida ");
			query.append(" FROM   cdiSARDetalle WHERE 1=1");

			if (bean.getFolio() != null) {
				query.append(" AND   folio = ?   ");
			}
			if (bean.getPo() != null) {
				query.append(" AND   po =  ?   ");
			}
			if (bean.getPosicion() != null) {
				query.append(" AND   posicion =  ?   ");
			}
			
			if (bean.getCondicionPago() != null) {	
				query.append(" AND   condicionPago =  ?   ");	
			}	


			query.append(" ORDER BY PO DESC");

			pst = con.prepareStatement(query.toString());
			int cont = 1;
			if (bean.getFolio() != null) {
				pst.setInt(cont++, bean.getFolio());
			}
			if (bean.getPo() != null) {
				pst.setString(cont++, bean.getPo());
			}
			if (bean.getPosicion() != null) {
				pst.setInt(cont++, bean.getPosicion());
			}
			if (bean.getCondicionPago() != null) {	
			pst.setString(cont++, bean.getCondicionPago());	
			}			

			rs = pst.executeQuery();

			while (rs.next()) {

				SarDetalleBO tmpSAR = new SarDetalleBO();
				tmpSAR.setPo(rs.getString("po").trim());
				tmpSAR.setPosicion(rs.getInt("posicion"));
				tmpSAR.setMaterial(rs.getInt("material"));
				tmpSAR.setCantidad(rs.getInt("cantidad"));
				tmpSAR.setPesoProveedor(rs.getDouble("pesoProveedor"));
				tmpSAR.setVolumenProveedor(rs.getDouble("volumenProveedor"));
				tmpSAR.setFolio(rs.getInt("folio"));
				tmpSAR.setCentro(rs.getString("centro"));
				tmpSAR.setPlaneador(rs.getString("planeador"));
				tmpSAR.setTieneDiferenciasMRP(rs.getBoolean("tieneDiferenciaMRP"));
				tmpSAR.setNumeroDoc(rs.getString("noDocumento"));
				if (rs.wasNull()) {
					tmpSAR.setNumeroDoc(null);
				}

				tmpSAR.setCantidadModificada(rs.getInt("cantidadModificada"));
				if (rs.wasNull()) {
					tmpSAR.setCantidadModificada(null);
				}
				tmpSAR.setPesoModificado(rs.getDouble("pesoModificado"));
				if (rs.wasNull()) {
					tmpSAR.setPesoModificado(null);
				}
				tmpSAR.setVolumenModificado(rs.getDouble("volumenModificado"));
				if (rs.wasNull()) {
					tmpSAR.setVolumenModificado(null);
				}
				tmpSAR.setCliente(rs.getString("cliente"));
				tmpSAR.setFechaProforma(rs.getInt("fechaProforma"));
				tmpSAR.setPaisOrigen(rs.getInt("paisOrigen"));
				if (rs.wasNull()) {
					tmpSAR.setPaisOrigen(null);
				}

				tmpSAR.setCartones(rs.getInt("cartones"));
				tmpSAR.setCantidadXCarton(rs.getInt("cantidadXcarton"));
				tmpSAR.setPesoNetoPKL(rs.getBigDecimal("pesoneto"));
				tmpSAR.setPesoBrutoPKL(rs.getBigDecimal("pesobruto"));
				tmpSAR.setCubicajePKL(rs.getBigDecimal("cubicaje"));
				tmpSAR.setPallet(rs.getInt("pallet"));
				tmpSAR.setCartonXPallet(rs.getInt("cartonxpallet"));
				tmpSAR.setUnidaMedida(rs.getString("unidadMedida"));
				tmpSAR.setCondicionPago(rs.getString("condicionPago"));
				tmpSAR.setMoneda(rs.getString("moneda"));
				BigDecimal precioUnitario = rs.getBigDecimal("preciounitario");
				if (rs.wasNull()) {
					precioUnitario = null;
				}
				tmpSAR.setPrecioUnitario(precioUnitario);
				tmpSAR.setPedidoDirecto(rs.getBoolean("esPedidoDirecto"));
				tmpSAR.setStatusMRP(rs.getInt("statusMRP"));
				if (rs.wasNull()) {
					tmpSAR.setStatusMRP(null);
				}
				tmpSAR.setTipoValidacionMRP(rs.getInt("tipoValidacionMRP"));
				tmpSAR.setCantidadUnidadMedida(rs.getBigDecimal("cantidadUnidadMedida"));
				listaSAR.add(tmpSAR);
			}
			rs.close();
			pst.close();
			ConexionDB.devuelveConexion(con);

		} catch (SQLException sqlE) {
			try {
				log.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
		return listaSAR;
	}

	/**
	 * Metodo para hacer el select de detalle de SARs cancelados por PO o por Folio
	 * 
	 * @param bean
	 * @return
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 */
	public ArrayList<SarDetalleBO> selectSarDetalleRechazados(SarDetalleBO bean)
			throws SQLException, ClassNotFoundException {

		ArrayList<SarDetalleBO> listaSAR = new ArrayList<SarDetalleBO>();

		Connection con = null;

		try {
			con = ConexionDB.dameConexion();

			ResultSet rs = null;
			PreparedStatement pst = null;
			StringBuffer query = new StringBuffer();

			query.append(
					"SELECT folio, po, posicion , material , cantidad , pesoProveedor , volumenProveedor , centro,planeador,cantidadModificada,"
							+ "pesoModificado,volumenModificado,cliente,fechaProforma,paisOrigen,noDocumento,cartones,cantidadXcarton,pesoneto,pesobruto,cubicaje,pallet,cartonxpallet, ");
			query.append(
					" unidadMedida,condicionPago,moneda,preciounitario, esPedidoDirecto,tieneDiferenciaMRP, statusMRP, tipoValidacionMRP, ");
			query.append("almacen ");
			query.append(" FROM   cdiSARDetalleRechazados ");
			if (bean.getFolio() != null) {
				query.append(" WHERE   folio = ?   ");
			} else {
				query.append(" WHERE   po like  '%" + bean.getPo() + "%'   ");
			}

			query.append(" ORDER BY PO DESC");

			pst = con.prepareStatement(query.toString());
			if (bean.getFolio() != null) {
				pst.setInt(1, bean.getFolio());
			}

			rs = pst.executeQuery();

			while (rs.next()) {

				SarDetalleBO tmpSAR = new SarDetalleBO();
				tmpSAR.setPo(rs.getString("po").trim());
				tmpSAR.setPosicion(rs.getInt("posicion"));
				tmpSAR.setMaterial(rs.getInt("material"));
				tmpSAR.setCantidad(rs.getInt("cantidad"));
				tmpSAR.setPesoProveedor(rs.getDouble("pesoProveedor"));
				tmpSAR.setVolumenProveedor(rs.getDouble("volumenProveedor"));
				tmpSAR.setFolio(rs.getInt("folio"));
				tmpSAR.setCentro(rs.getString("centro"));
				tmpSAR.setPlaneador(rs.getString("planeador"));

				tmpSAR.setNumeroDoc(rs.getString("noDocumento"));
				if (rs.wasNull()) {
					tmpSAR.setNumeroDoc(null);
				}

				tmpSAR.setCantidadModificada(rs.getInt("cantidadModificada"));
				if (rs.wasNull()) {
					tmpSAR.setCantidadModificada(null);
				}
				tmpSAR.setPesoModificado(rs.getDouble("pesoModificado"));
				if (rs.wasNull()) {
					tmpSAR.setPesoModificado(null);
				}
				tmpSAR.setVolumenModificado(rs.getDouble("volumenModificado"));
				if (rs.wasNull()) {
					tmpSAR.setVolumenModificado(null);
				}
				tmpSAR.setCliente(rs.getString("cliente"));
				tmpSAR.setFechaProforma(rs.getInt("fechaProforma"));
				tmpSAR.setPaisOrigen(rs.getInt("paisOrigen"));
				if (rs.wasNull()) {
					tmpSAR.setPaisOrigen(null);
				}

				tmpSAR.setCartones(rs.getInt("cartones"));
				tmpSAR.setCantidadXCarton(rs.getInt("cantidadXcarton"));
				tmpSAR.setPesoNetoPKL(rs.getBigDecimal("pesoneto"));
				tmpSAR.setPesoBrutoPKL(rs.getBigDecimal("pesobruto"));
				tmpSAR.setCubicajePKL(rs.getBigDecimal("cubicaje"));
				tmpSAR.setPallet(rs.getInt("pallet"));
				tmpSAR.setCartonXPallet(rs.getInt("cartonxpallet"));
				tmpSAR.setUnidaMedida(rs.getString("unidadMedida"));
				tmpSAR.setCondicionPago(rs.getString("condicionPago"));
				tmpSAR.setMoneda(rs.getString("moneda"));
				BigDecimal precioUnitario = rs.getBigDecimal("preciounitario");
				if (rs.wasNull()) {
					precioUnitario = null;
				}
				tmpSAR.setPrecioUnitario(precioUnitario);
				tmpSAR.setPedidoDirecto(rs.getBoolean("esPedidoDirecto"));
				tmpSAR.setStatusMRP(rs.getInt("statusMRP"));
				if (rs.wasNull()) {
					tmpSAR.setStatusMRP(null);
				}
				tmpSAR.setTipoValidacionMRP(rs.getInt("tipoValidacionMRP"));
				tmpSAR.setAlmacen(rs.getString("almacen"));

				listaSAR.add(tmpSAR);
			}
			rs.close();
			pst.close();
			ConexionDB.devuelveConexion(con);

		} catch (SQLException sqlE) {
			try {
				log.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
			throw sqlE;
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}

		return listaSAR;
	}

	public static void cargaSARsBD(HashMap<Integer, SarBO> sarsBD, HashMap<String, SarDetalleBO> detallesBD,
			String proveedor, boolean perfilCompras, HashMap<String, SarDetalleBO> detallesBDRechazados,
			HashMap<String, SarDetalleBO> detallesOtrosBD) {

		Connection con = null;
		Statement st = null;
		ResultSet rs = null;

		HashSet<Integer> folios = new HashSet<Integer>();
		HashSet<Integer> foliosRechazados = new HashSet<Integer>();

		StringBuffer selectSARs = new StringBuffer();
		selectSARs.append(
				"SELECT folio, proveedor, puertoSalida, naviera, fechaEmbarque, consolidado, status, fechaSolAprobacion, usuarioSolAprobacion, ");
		selectSARs.append(
				" fechaUltAprobRechazo, usuarioApruebaRechaza, tipoContenedor, prioridad, barcoSugerido, viaje, puertoDescarga, contenedor, booking, ");
		selectSARs.append(" etd,etdfinal, comentarioCancelacion, aprobadoPorCompras, fechaCreacion,esmultiple,");
		selectSARs.append(
				" mandante,paisDestino,esAereo,bl,folioconsolidado,diferenciaMRP, cargaArchivoMRP,preciosLiberados , aprobadoProveedor, obs_reject, gdrEnRevision, referenciaContenedorProveedor");
		selectSARs.append(" FROM cdiSAR ");

		if (perfilCompras) {
			String status = UtilsString.append(SarBO.STATUS_ESPERA_APROBACION_PLANEACION, ",",
					SarBO.STATUS_ESPERA_APROBACION_SHIPPING, ",", SarBO.STATUS_APROBADO, ",",
					SarBO.STATUS_EN_REVISION_PRECIOS);
			selectSARs.append(" WHERE status IN (");
			selectSARs.append(status);
			selectSARs.append(") AND aprobadoPorCompras IS NULL ");
		} else {
			selectSARs.append(" WHERE proveedor = '"); 
			selectSARs.append(proveedor);
			selectSARs.append("' AND status <> "); 
			selectSARs.append(SarBO.STATUS_CANCELADO);
		}
		selectSARs.append(" ORDER BY folio");

		StringBuilder selectDetalles = new StringBuilder("SELECT folio, po, posicion, material, centro, planeador,cantidad, pesoProveedor, volumenProveedor, precioUnitario, ");
			selectDetalles.append( "cliente, fechaProforma, cantidadModificada, pesoModificado,tieneDiferenciaMRP,");
			selectDetalles.append( " volumenModificado,nodocumento, paisorigen,cartones, cantidadXCarton, pesoNeto, ");
			selectDetalles.append( "PesoBruto, cubicaje, pallet, cartonXPallet,unidadMedida, condicionPago, moneda, esPedidoDirecto, almacen, cantidadUnidadMedida, factorCantidadUnidadMedida, fabrica " );
			selectDetalles.append( " FROM cdiSARDetalle WHERE folio IN (" );

		String selectDetallesRechazados = "SELECT folio, po, posicion, material, centro, planeador,cantidad, pesoProveedor, volumenProveedor, precioUnitario, "
				+ "cliente, fechaProforma, almacen FROM cdiSARDetalleRechazados WHERE folio IN (";

		String selectDetallesOtros = "select folio, po, poOtherItem, posicion, descripcion, cantidad, pesoProveedor, volumenProveedor"
				+ " , precioUnitario, condicionPago, unidadMedida from cdiSARDetalleOthers where folio IN (";

		try {
			con = ConexionDB.dameConexion();
			st = con.createStatement();
			rs = st.executeQuery(selectSARs.toString());

			while (rs.next()) {
				SarBO sar = null;
				int iTipoContenedor = rs.getInt("tipoContenedor");

				if (perfilCompras) {
					sar = new SarBO(rs.getInt("folio"), rs.getString("proveedor"),
							iTipoContenedor == 0 ? null : iTipoContenedor);
				} else {
					sar = new SarBO(rs.getInt("folio"), proveedor, iTipoContenedor == 0 ? null : iTipoContenedor);
				}

				sar.setPuertoSalida(rs.getString("puertoSalida"));
				sar.setNaviera(rs.getInt("naviera"));
				sar.setFechaEmbarque(rs.getInt("fechaEmbarque"));
				sar.setConsolidado(rs.getBoolean("consolidado"));
				sar.setStatus(rs.getInt("status"));
				sar.setFechaSolicitudDeAprobacion(rs.getInt("fechaSolAprobacion"));
				sar.setUsuarioSolicitudDeAprobacion(rs.getString("usuarioSolAprobacion"));
				sar.setFechaUltimaAprobacionRechazo(rs.getInt("fechaUltAprobRechazo"));
				sar.setUsuarioApruebaRechaza(rs.getString("usuarioApruebaRechaza"));
				sar.setPrioridad(rs.getInt("prioridad"));
				sar.setBarcoSugerido(rs.getString("barcoSugerido"));
				sar.setViaje(rs.getString("viaje"));
				sar.setPuertoDescarga(rs.getString("puertoDescarga"));
				sar.setContenedor(rs.getString("contenedor"));
				sar.setBooking(rs.getString("booking"));
				sar.setBl(rs.getString("bl"));
				if (rs.wasNull()) {
					sar.setBl(null);
				}

				sar.setEtdPlanner(rs.getInt("etd"));
				sar.setEtdReal(rs.getInt("etdfinal"));

				sar.setComentarioCancelacion(rs.getString("comentarioCancelacion"));
				sar.setCreationDate(rs.getInt("fechaCreacion"));
				sar.setEsMultiple(rs.getBoolean("esmultiple"));
				sar.setEsAereo(rs.getBoolean("esAereo"));
				if (rs.wasNull()) {
					sar.setEsMultiple(null);
				}
				sar.setMandante(rs.getInt("mandante"));
				if (rs.wasNull()) {
					sar.setMandante(null);
				}
				sar.setPaisDestino(rs.getInt("paisDestino"));

				if (sar.getStatus() == SarBO.STATUS_CANCELADO) {
					foliosRechazados.add(sar.getFolio());
				} else {
					folios.add(sar.getFolio());
				}
				sar.setFolioConsolidado(rs.getInt("folioconsolidado"));
				if (rs.wasNull()) {
					sar.setFolioConsolidado(null);
				}
				sar.setTieneDiferenciaMRP(rs.getBoolean("diferenciaMRP"));

				sar.setCargaArchivoMRP(rs.getInt("cargaArchivoMRP"));
				if (rs.wasNull()) {
					sar.setCargaArchivoMRP(null);
				}
				sar.setPreciosLiberados(rs.getBoolean("preciosLiberados"));

				sar.setAprobadoProveedor(rs.getBoolean("aprobadoProveedor"));
				sar.setGdrEnRevision(rs.getBoolean("gdrEnRevision"));
				sar.setObs_reject(rs.getString("obs_reject"));
				sar.setReferenciaContenedorProveedor(rs.getString("referenciaContenedorProveedor"));
				sarsBD.put(sar.getFolio(), sar);
			}

			if (folios.size() > 0) {
				for (int folio : folios) {
					selectDetalles.append(  folio + "," );
					selectDetallesOtros += folio + ",";
				}

				selectDetalles.deleteCharAt( selectDetalles.length() - 1);
				selectDetalles.append( ")");

				selectDetallesOtros = selectDetallesOtros.substring(0, selectDetallesOtros.length() - 1);
				selectDetallesOtros += ")";

				rs = st.executeQuery(selectDetalles.toString());
				while (rs.next()) {
					SarDetalleBO detalle = new SarDetalleBO(rs.getInt("folio"), rs.getString("po").trim(),
							rs.getInt("posicion"), rs.getInt("material"), rs.getInt("cantidad"), rs.getString("centro"),
							rs.getString("planeador"), rs.getString("cliente"));

					detalle.setPesoProveedor(rs.getDouble("pesoProveedor"));
					detalle.setVolumenProveedor(rs.getDouble("volumenProveedor"));
					BigDecimal precioUnitario = rs.getBigDecimal("precioUnitario");
					if (rs.wasNull()) {
						precioUnitario = null;
					}
					detalle.setPrecioUnitario(precioUnitario);
					detalle.setFechaProforma(rs.getInt("fechaProforma"));
					detalle.setNumeroDoc(rs.getString("nodocumento"));
					if (rs.wasNull()) {
						detalle.setNumeroDoc(null);
					}
					detalle.setPaisOrigen(rs.getInt("paisorigen"));
					if (rs.wasNull()) {
						detalle.setPaisOrigen(null);
					}

					detalle.setCartones(rs.getInt("cartones"));
					detalle.setCartonXPallet(rs.getInt("cartonXPallet"));
					detalle.setPesoNetoPKL(rs.getBigDecimal("pesoNeto"));
					detalle.setPesoBrutoPKL(rs.getBigDecimal("PesoBruto"));
					detalle.setCubicajePKL(rs.getBigDecimal("cubicaje"));
					detalle.setPallet(rs.getInt("pallet"));
					detalle.setCantidadXCarton(rs.getInt("cantidadXCarton"));
					detalle.setUnidaMedida(rs.getString("unidadMedida"));
					detalle.setCondicionPago(rs.getString("condicionPago"));
					detalle.setMoneda(rs.getString("moneda"));
					detalle.setPedidoDirecto(rs.getBoolean("esPedidoDirecto"));
					detalle.setTieneDiferenciasMRP(rs.getBoolean("tieneDiferenciaMRP"));
					detalle.setAlmacen(rs.getString("almacen"));
					detalle.setCantidadUnidadMedida(rs.getBigDecimal("cantidadUnidadMedida"));
					detalle.setFactorCantidadUnidadMedida(rs.getBigDecimal("factorCantidadUnidadMedida"));
					detallesBD.put(detalle.getFolio() + "|" + detalle.getPo() + "|" + detalle.getPosicion(), detalle);
					detalle.setFabrica(rs.getInt("fabrica"));
				}

				rs = st.executeQuery(selectDetallesOtros);
				while (rs.next()) {
					SarDetalleBO detalleOthers = new SarDetalleBO();
					detalleOthers.setFolio(rs.getInt("folio"));
					detalleOthers.setPo(rs.getString("po").trim());
					detalleOthers.setPosicion(rs.getInt("posicion"));
					detalleOthers.setCantidad(rs.getInt("cantidad"));
					detalleOthers.setPesoProveedor(rs.getDouble("pesoProveedor"));
					detalleOthers.setVolumenProveedor(rs.getDouble("volumenProveedor"));
					detalleOthers.setDescripcion(rs.getString("descripcion"));
					detalleOthers.setPoOtherItem(rs.getString("poOtherItem"));
					detalleOthers.setPrecioUnitario(rs.getBigDecimal("precioUnitario"));
					detalleOthers.setPoOtherItemCondicionPago("condicionPago");
					detalleOthers.setUnidaMedida(rs.getString("unidadMedida"));
					detalleOthers
							.setPagadero(PriceReleaseHelper.getInstance().isOtherItemWithPago(detalleOthers.getPo()));
					detallesOtrosBD.put(
							detalleOthers.getFolio() + "|" + detalleOthers.getPo() + "|" + detalleOthers.getPosicion(),
							detalleOthers);
				}
			}

			if (foliosRechazados.size() > 0) {
				for (int folio : foliosRechazados) {
					selectDetallesRechazados += folio + ",";
				}

				selectDetallesRechazados = selectDetallesRechazados.substring(0, selectDetallesRechazados.length() - 1);
				selectDetallesRechazados += ")";

				rs = st.executeQuery(selectDetallesRechazados);
				while (rs.next()) {
					SarDetalleBO detalle = new SarDetalleBO(rs.getInt("folio"), rs.getString("po").trim(),
							rs.getInt("posicion"), rs.getInt("material"), rs.getInt("cantidad"), rs.getString("centro"),
							rs.getString("planeador"), rs.getString("cliente"));

					detalle.setPesoProveedor(rs.getDouble("pesoProveedor"));
					detalle.setVolumenProveedor(rs.getDouble("volumenProveedor"));
					detalle.setPrecioUnitario(rs.getBigDecimal("precioUnitario"));
					detalle.setFechaProforma(rs.getInt("fechaProforma"));
					detalle.setAlmacen(rs.getString("almacen"));

					detallesBDRechazados.put(detalle.getFolio() + "|" + detalle.getPo() + "|" + detalle.getPosicion(),
							detalle);
				}
			}

			ConexionDB.devuelveConexion(con);

		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} catch (Exception e) {
			e.printStackTrace();
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}

		for (SarDetalleBO detalle : detallesBD.values()) {
			SarBO sar = sarsBD.get(detalle.getFolio());
			if (sar != null) {
				sar.addDetalle(detalle);
			}
		}

		for (SarDetalleBO detalleOthers : detallesOtrosBD.values()) {
			SarBO sar = sarsBD.get(detalleOthers.getFolio());
			if (sar != null) {
				sar.addDetalleOthers(detalleOthers);
			}
		}

		for (SarDetalleBO detalle : detallesBDRechazados.values()) {
			SarBO sar = sarsBD.get(detalle.getFolio());
			if (sar != null) {
				sar.addDetalle(detalle);
			}
		}
	}

	/**
	 * metodo que regresa los materiales con su sar, que esten en algun estatus este
	 * metodo lo uso para poder filtrar por celula
	 * 
	 * @param celda
	 * @param status
	 * @return
	 * @deprecated
	 */
	public static ArrayList<String[]> dameSARXCelula(String celda, int status) {
		Connection con = null;
		Statement st = null;
		ResultSet rs = null;

		if (celda == null) {
			return null;
		}

		ArrayList<String[]> materiales = new ArrayList<String[]>();

		String selectSARs = "select material,sar.folio from cdisar sar ," + "  cdisardetalle det where status = "
				+ status + " and det.folio = sar.folio";

		try {
			con = ConexionDB.dameConexion();
			st = con.createStatement();
			rs = st.executeQuery(selectSARs);

			String mat = "", sar = "";
			while (rs.next()) {

				mat = rs.getString(1);
				sar = rs.getString(2);
				String[] tmp = { mat, sar };

				materiales.add(tmp);
			}

			ConexionDB.devuelveConexion(con);

		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} catch (Exception e) {
			e.printStackTrace();
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
		return materiales;
	}

	/**
	 * 
	 * Metodo que utilizo para traer el dia de proforma de la tabla de
	 * importacionesDetalleOrden
	 * 
	 * @param beanDetalle
	 * @return día de proforma
	 * @deprecated
	 */
	public static Integer dameFechaProformaXOrden(SarDetalleBO beanDetalle) {
		Connection con = null;
		Statement st = null;
		ResultSet rs = null;
		Integer resultado = null;

		String selectSARs = "select fechaproforma from importacionesdetalleorden " + " where numeroorden = '"
				+ beanDetalle.getPo().trim() + "' " + " and posicion =   " + beanDetalle.getPosicion() + "";

		try {
			con = ConexionDB.dameConexion();
			st = con.createStatement();
			rs = st.executeQuery(selectSARs);

			while (rs.next()) {

				resultado = rs.getInt("fechaproforma");
			}

			ConexionDB.devuelveConexion(con);

		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} catch (Exception e) {
			e.printStackTrace();
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
		return resultado;
	}

	public static ArrayList<Integer> dameFoliosBD(String proveedor) {
		ArrayList<Integer> foliosBD = new ArrayList<Integer>();
		Connection con = null;
		Statement st = null;
		ResultSet rs = null;

		String select = "SELECT folio FROM cdiSAR WHERE proveedor = '" + proveedor
				+ "' AND status = 0 ORDER BY folio desc";

		try {
			con = ConexionDB.dameConexion();
			st = con.createStatement();
			rs = st.executeQuery(select);

			while (rs.next()) {
				foliosBD.add(rs.getInt("folio"));
			}

			ConexionDB.devuelveConexion(con);

		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} catch (Exception e) {
			e.printStackTrace();
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}

		return foliosBD;
	}

	public static boolean actualizaDetalle(int folio, String po, int posicion, int cantidad, double peso,
			double volumen, double precio, Boolean isDiferenciaMRp) {
		Connection con = null;
		PreparedStatement pst = null;
		StringBuffer update = new StringBuffer();
		update.append("UPDATE cdiSARDetalle SET cantidad = ?, ").append("pesoProveedor = ?, volumenProveedor = ? ");
		if (isDiferenciaMRp != null) {
			update.append(" ,tieneDiferenciaMRP = ? , statusMRP = 3 ");
		}
		update.append("WHERE folio = ").append(folio).append(" AND po = ").append(po).append(" AND posicion = ")
				.append(posicion);

		boolean exito = false;

		try {
			con = ConexionDB.dameConexion();
			pst = con.prepareStatement(update.toString());

			pst.setInt(1, cantidad);
			pst.setDouble(2, peso);
			pst.setDouble(3, volumen);
			if (isDiferenciaMRp != null) {
				pst.setBoolean(4, isDiferenciaMRp);
			}

			exito = pst.executeUpdate() == 1;

			ConexionDB.devuelveConexion(con);

		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} catch (Exception e) {
			e.printStackTrace();
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}

		return exito;
	}

	public static boolean actualizaDetalleRechazados(int folio, String po, int posicion, int cantidad, double peso,
			double volumen, double precio, Boolean isDiferenciaMRp) {
		Connection con = null;
		PreparedStatement pst = null;
		StringBuffer update = new StringBuffer();
		update.append("UPDATE cdiSARDetalleRechazados SET cantidad = ?, ")
				.append("pesoProveedor = ?, volumenProveedor = ? ");
		if (isDiferenciaMRp != null) {
			update.append(" ,tieneDiferenciaMRP = ? , statusMRP = 3 ");
		}
		update.append("WHERE folio = ").append(folio).append(" AND po = ").append(po).append(" AND posicion = ")
				.append(posicion);

		boolean exito = false;

		try {
			con = ConexionDB.dameConexion();
			pst = con.prepareStatement(update.toString());

			pst.setInt(1, cantidad);
			pst.setDouble(2, peso);
			pst.setDouble(3, volumen);
			if (isDiferenciaMRp != null) {
				pst.setBoolean(4, isDiferenciaMRp);
			}

			exito = pst.executeUpdate() == 1;

			ConexionDB.devuelveConexion(con);

		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} catch (Exception e) {
			e.printStackTrace();
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}

		return exito;
	}

	/**
	 * Metodo que utilizo para cuando un proveedor modifica lo que viene en el sar
	 * ya embarcado, agrego valores a los campos de modificados no todo los valores
	 * que ya existen
	 * 
	 * @param folio
	 * @param po
	 * @param posicion
	 * @param cantidad
	 * @param peso
	 * @param volumen
	 * @return
	 * 
	 * @deprecated
	 */
	public static boolean actualizaDetalleProveedor(int folio, String po, int posicion, int cantidad, double peso,
			double volumen) {
		Connection con = null;
		PreparedStatement pst = null;
		String update = "UPDATE cdiSARDetalle SET cantidadModificada = ?, pesoModificado = ?, volumenModificado = ? WHERE folio = "
				+ folio + " AND po = " + po + " AND posicion = " + posicion;
		boolean exito = false;

		try {
			con = ConexionDB.dameConexion();
			pst = con.prepareStatement(update);

			pst.setInt(1, cantidad);
			pst.setDouble(2, peso);
			pst.setDouble(3, volumen);
			exito = pst.executeUpdate() == 1;
			ConexionDB.devuelveConexion(con);
		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} catch (Exception e) {
			e.printStackTrace();
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}

		return exito;
	}

	/**
	 * 
	 * Metodo que se usa para hacer la consulta a la tabla de sarConsolidados
	 * 
	 * @param bean
	 * @return
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 */
	public ArrayList<SarConsolBO> selectSarConsolidado(SarConsolBO bean, boolean isHighVolume)
			throws SQLException, ClassNotFoundException {

		ArrayList<SarConsolBO> listaSAR = new ArrayList<SarConsolBO>();

		Connection con = null;

		try {
			con = ConexionDB.dameConexion();

			ResultSet rs = null;
			PreparedStatement pst = null;
			StringBuffer query = new StringBuffer();
			query.append("SELECT  consol.folio,  consol.puertoSalida, ");
			query.append(" consol.naviera,  consol.fechaEmbarque,  consol.status, ");
			query.append(" consol.tipoContenedor,  consol.prioridad, ");
			query.append(" consol.barcoSugerido,  consol.viaje, ");
			query.append(" consol.puertoDescarga,  consol.contenedor,  consol.booking, ");
			query.append(" consol.eta, consol.etdfinal,  consol.transporte, ");
			query.append(" consol.comentarioConsolidado,  consol.paisdestino,  consol.tipoProducto, ");
			query.append(" consol.tipoRetraso,  consol.retrasoProveedor, ");
			query.append(" consol.comentarioTruperBooking,  consol.esDesbloqueado, ");
			query.append(" consol.fecIniEmbarque,  consol.tinyFecIniEmbarque, ");
			query.append(" consol.revision, consol.enrevisionIDA, consol.bitacoraIDA, consol.bitacoraIDACerrada ");
			query.append(" FROM cdiSARConsolidados consol ");
			query.append(" WHERE 1=1 ");

			if (bean.getContenedor() != null) {
				query.append(" AND   consol.contenedor = ? ");
			}
			if (bean.getFolio() != null) {
				query.append(" AND   consol.folio = ? ");
			}

			if (bean.getFechaEmbarque() != null) {
				if (bean.getFechaEmbarqueIni() != null && bean.getFechaEmbarqueFin() != null) {
					query.append(" AND   consol.fechaEmbarque BETWEEN  ? AND  ? ");
				} else {
					if (bean.getFechaEmbarqueIni() != null) {
						query.append(" AND   consol.fechaEmbarque >=  ? ");
					} else {
						query.append(" AND   consol.fechaEmbarque = ? ");
					}
				}
			}

			if (bean.getBarcoSugerido() != null) {
				query.append(" AND   consol.barcoSugerido = ? ");
			}
			if (bean.getFiltroBooking() != null) {
				if (bean.getFiltroBooking() == 1 || bean.getFiltroBooking() == 3) {
					query.append(" AND   consol.booking is NULL ");
				} else if (bean.getFiltroBooking() == 2) {
					query.append(" AND   consol.booking is not NULL ");
				}
			}
			if (bean.getBooking() != null && bean.getFiltroBooking() == 2) {
				query.append(" AND   consol.booking like ? ");
			}
			if (bean.getEta() != null) {
				query.append(" AND   consol.eta = ? ");
			}
			if (bean.getEtdReal() != null) {
				query.append(" AND   consol.etdfinal = ? ");
			}
			if (bean.getNaviera() != null) {
				query.append(" AND   consol.naviera = ? ");
			}
			if (bean.getPrioridad() != null) {
				query.append(" AND   consol.prioridad = ? ");
			}
			if (bean.getPuertoDescarga() != null) {
				query.append(" AND  puertoDescarga = ? ");
			}
			if (bean.getPuertoSalida() != null) {
				query.append(" AND   consol.puertoSalida = ? ");
			}
			if (bean.getSarHistory() != null) {
				if (bean.getSarHistory()) {
					query.append(" AND  consol.status >= 5 AND  consol.fecIniEmbarque >= ?");
				} else {
					if (bean.getStatus() != null) {
						query.append(" AND   consol.status = ? ");
					}
				}
			} else {
				if (bean.getStatus() != null) {
					query.append(" AND   consol.status = ? ");
				}
			}
			if (bean.getTipoContenedor() != null) {
				query.append(" AND   consol.tipoContenedor = ? ");
			}
			if (bean.getViaje() != null) {
				query.append(" AND   consol.viaje = ? ");
			}
			if (bean.getTransporte() != null) {
				query.append(" AND   consol.transporte = ? ");
			}
			//// Si es diferente de null y es falso o true aqui aplico una logica diferente
			// TODO validar una forma de automatizar esta parte si mando false que
			if (bean.getEsDesbloqueado() != null) {
				if (bean.getEsDesbloqueado()) {
					query.append(" AND  esDesbloqueado = ? ");
				} else {
					/// Si es falso, tambien busco por los null ya que los considero como falsos
					query.append(" AND (  consol.esDesbloqueado = ? OR " + " consol.esDesbloqueado is null )");
				}
			}

			if (isHighVolume) {

				query.append(" and (  ");
				query.append("  select distinct tel.altovol from cdiSAR sar  ");
				query.append("  inner join cdiSARDetalle det on sar.folio = det.folio ");
				query.append("  inner join ");
				query.append(TelServiceClient.linkedServer_TEL);
				query.append("[productos] tel on det.material = tel.codigo ");
				query.append("  where sar.folioConsolidado =  consol.folio  ");
				query.append("  and tel.altovol ='AV'  ");
				query.append("  ) is not null  ");

			}

			// esta condicion siempre debe ir al final
			if (bean.getIntervalosFechaCreacion() != null) {
				query.append(bean.getIntervalosFechaCreacion());
			}

			query.append(" ORDER BY  consol.fechacreacion DESC ");

			pst = con.prepareStatement(query.toString());

			int cont = 1;
			if (bean.getContenedor() != null) {
				pst.setString(cont++, bean.getContenedor());
			}
			if (bean.getFolio() != null) {
				pst.setInt(cont++, bean.getFolio());
			}
			if (bean.getFechaEmbarque() != null) {
				if (bean.getFechaEmbarqueIni() != null && bean.getFechaEmbarqueFin() != null) {
					pst.setInt(cont++, bean.getFechaEmbarqueIni());
					pst.setInt(cont++, bean.getFechaEmbarqueFin());
				} else {
					if (bean.getFechaEmbarqueIni() != null) {
						pst.setInt(cont++, bean.getFechaEmbarqueIni());
					} else {
						pst.setInt(cont++, bean.getFechaEmbarque());
					}
				}
			}

			if (bean.getBarcoSugerido() != null) {
				pst.setString(cont++, bean.getBarcoSugerido());
			}
			if (bean.getBooking() != null) {
				pst.setString(cont++, "%" + bean.getBooking() + "%");
			}
			if (bean.getEta() != null) {
				pst.setInt(cont++, bean.getEta());
			}
			if (bean.getEtdReal() != null) {
				pst.setInt(cont++, bean.getEtdReal());
			}
			if (bean.getNaviera() != null) {
				pst.setInt(cont++, bean.getNaviera());
			}
			if (bean.getPrioridad() != null) {
				pst.setInt(cont++, bean.getPrioridad());
			}
			if (bean.getPuertoDescarga() != null) {
				pst.setString(cont++, bean.getPuertoDescarga());
			}
			if (bean.getPuertoSalida() != null) {
				pst.setString(cont++, bean.getPuertoSalida());
			}
			if (bean.getSarHistory() != null) {
				if (bean.getSarHistory()) {
					pst.setInt(cont++, bean.getTinyFecIniEmbarque());
				} else {
					if (bean.getStatus() != null) {
						pst.setInt(cont++, bean.getStatus());
					}
				}
			} else {
				if (bean.getStatus() != null) {
					pst.setInt(cont++, bean.getStatus());
				}
			}
			if (bean.getTipoContenedor() != null) {
				pst.setInt(cont++, bean.getTipoContenedor());
			}
			if (bean.getViaje() != null) {
				pst.setString(cont++, bean.getViaje());
			}
			if (bean.getTransporte() != null) {
				pst.setInt(cont++, bean.getTransporte());
			}

			if (bean.getEsDesbloqueado() != null) {
				pst.setBoolean(cont++, bean.getEsDesbloqueado());
			}

			rs = pst.executeQuery();

			while (rs.next()) {
				SarConsolBO tmpSAR = new SarConsolBO();
				tmpSAR.setFolio(rs.getInt("folio"));
				tmpSAR.setPuertoSalida(rs.getString("puertoSalida"));
				tmpSAR.setNaviera(rs.getInt("naviera"));
				if (rs.wasNull()) {
					tmpSAR.setNaviera(null);
				}
				tmpSAR.setFechaEmbarque(rs.getInt("fechaEmbarque"));
				tmpSAR.setStatus(rs.getInt("status"));
				tmpSAR.setTipoContenedor(rs.getInt("tipoContenedor"));
				tmpSAR.setPrioridad(rs.getInt("prioridad"));
				tmpSAR.setBarcoSugerido(rs.getString("barcoSugerido"));
				tmpSAR.setViaje(rs.getString("viaje"));
				tmpSAR.setPuertoDescarga(rs.getString("puertoDescarga"));
				tmpSAR.setContenedor(rs.getString("contenedor"));
				tmpSAR.setBooking(rs.getString("booking"));
				tmpSAR.setEta(rs.getInt("eta"));
				tmpSAR.setEtdReal(rs.getInt("etdfinal"));
				tmpSAR.setTransporte(rs.getInt("transporte"));
				tmpSAR.setComentarioConsol(rs.getString("comentarioConsolidado"));
				tmpSAR.setBooking(rs.getString("booking"));
				tmpSAR.setComentarioTruperBooking(rs.getString("comentarioTruperBooking"));
				if (rs.wasNull()) {
					tmpSAR.setBooking(null);
				}
				tmpSAR.setPaisDestino(rs.getInt("paisdestino"));
				if (rs.wasNull()) {
					tmpSAR.setPaisDestino(null);
				}

				tmpSAR.setTipoProducto(rs.getString("tipoProducto"));
				tmpSAR.setTipoRetraso(rs.getInt("tipoRetraso"));
				tmpSAR.setRetrasoProveedor(rs.getString("retrasoProveedor"));
				tmpSAR.setEsDesbloqueado(rs.getBoolean("esDesbloqueado"));
				if (rs.wasNull()) {
					tmpSAR.setEsDesbloqueado(null);
				}
				tmpSAR.setFecIniEmbarque(rs.getLong("fecIniEmbarque"));
				tmpSAR.setTinyFecIniEmbarque(rs.getInt("tinyFecIniEmbarque"));

				tmpSAR.setRevision(rs.getInt("revision"));
				if (rs.wasNull()) {
					tmpSAR.setRevision(null);
				}
				tmpSAR.setRevisionIDA(rs.getBoolean("enrevisionIDA"));
				tmpSAR.setBitacoraIDA(rs.getBoolean("bitacoraIDA"));
				tmpSAR.setBitacoraIDACerrada(rs.getBoolean("bitacoraIDACerrada"));

				listaSAR.add(tmpSAR);
			}
			rs.close();
			pst.close();
			ConexionDB.devuelveConexion(con);

		} catch (SQLException sqlE) {
			try {
				log.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
			throw sqlE;
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}

		return listaSAR;
	}

	/**
	 * Tratar de usar mejor el metodo "updateSarsInConsol"
	 * 
	 * @param folio
	 * @param status
	 * @param paisDestino
	 * @return
	 */
	@Deprecated
	public static boolean cambiaStatusSAR(int folio, int status, Integer paisDestino) {
		Connection con = null;
		Statement st = null;
		String update = "UPDATE cdiSAR SET status = " + status;
		if (paisDestino != null) {
			update += ", paisdestino = " + paisDestino;
		}

		update += " WHERE folio = " + folio;
		boolean exito = false;

		try {
			con = ConexionDB.dameConexion();
			st = con.createStatement();

			exito = st.executeUpdate(update) == 1;

			ConexionDB.devuelveConexion(con);

		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} catch (Exception e) {
			e.printStackTrace();
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}

		return exito;
	}

	/**
	 * Metodo que se utiliza para actualizar de una sola vez todos los SARs que
	 * estan dentro de un consolidado Este metodo podria empezar a utilizarse en
	 * lugar del metodo "cambiaStatusSAR"
	 * 
	 * @param folioConsol
	 * @param status
	 * @param paisDestino
	 * @return
	 */
	public static boolean updateSarsInConsol(int folioConsol, Integer status, Integer paisDestino) {
		Connection con = null;
		Statement st = null;
		String update = "UPDATE cdiSAR SET ";
		boolean bandera = false;
		if (status != null) {
			update += " status =" + status;
			bandera = true;
		}

		if (paisDestino != null) {
			if (bandera) {
				update += ", ";
			}
			update += " paisdestino = " + paisDestino;
		}

		update += " WHERE folioConsolidado = " + folioConsol;
		boolean exito = false;

		try {
			con = ConexionDB.dameConexion();
			st = con.createStatement();

			exito = st.executeUpdate(update) == 1;

			ConexionDB.devuelveConexion(con);

		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} catch (Exception e) {
			e.printStackTrace();
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}

		return exito;
	}

	public static boolean insertaDetalle(SarDetalleBO detalle, Integer contenedor) {
		Connection con = null;
		Statement st = null;
		StringBuilder insert = new StringBuilder( "INSERT INTO cdiSARDetalle (folio, po, posicion, material, cantidad, pesoProveedor, volumenProveedor, centro, precioUnitario, " );
			insert.append( "planeador, cliente, fechaProforma, unidadMedida ,condicionPago,moneda,esPedidoDirecto,tieneDiferenciaMRP,statusMRP,almacen,cantidadUnidadMedida,factorCantidadUnidadMedida,fabrica,descripcionComplementoFactura) VALUES (");
			insert.append( detalle.getFolio() );
			insert.append( ", '" );
			insert.append( detalle.getPo() ); 
			insert.append( "', " );
			insert.append( detalle.getPosicion() );
			insert.append( ", " );
			insert.append( detalle.getMaterial() );
			insert.append( ", " ); 
			insert.append( detalle.getCantidad() ); 
			insert.append( "," );
			insert.append( detalle.getPesoProveedor() );
			insert.append( ", " );
			insert.append( detalle.getVolumenProveedor() );
			insert.append( ", '" );
			insert.append( detalle.getCentro() );
			insert.append( "', " );
			insert.append( detalle.getPrecioUnitario() );
			insert.append( ",'" );
			insert.append( detalle.getPlaneador() );
			insert.append( "','" );
			insert.append( detalle.getCliente() );
			insert.append( "'," );
			insert.append( detalle.getFechaProforma() );
			insert.append( "," );
			
			if( detalle.getUnidaMedida() != null  ) {
				insert.append( "'" );
				insert.append( detalle.getUnidaMedida() );
				insert.append(  "'," );
			}else {
				insert.append( "''," );
			}
			
			if( detalle.getCondicionPago() != null  ) {
				insert.append( "'" );
				insert.append( detalle.getCondicionPago() );
				insert.append( "'," );
			}else {
				insert.append( "''," );
			}
			
			if( detalle.getMoneda() != null   ) {
				insert.append( "'" );
				insert.append( detalle.getMoneda() );
				insert.append( "'," );
			}else {
				insert.append( "''," );
			}
			
			if( detalle.isPedidoDirecto() ) {
				insert.append( 1 );
				insert.append( "," );
			}else {
				insert.append( 0 );
				insert.append( "," );
			}
			if( detalle.isTieneDiferenciasMRP()  ) {
				insert.append( 1 );
				insert.append( "," );
			}else {
				insert.append( 0 );
				insert.append( "," );
			}
			
			if( detalle.isTieneDiferenciasMRP() ) {
				insert.append( 3 );
				insert.append( "," );
			}else {
				insert.append( "NULL," );
			}
			
			if(detalle.getAlmacen() != null && !detalle.getAlmacen().equals("")) {	
				insert.append( detalle.getAlmacen() ); 	
				insert.append( "," );	
			}else{	
				insert.append( "NULL," );	
			}	
		
			
			insert.append( detalle.getCantidadUnidadMedida() ); 
			insert.append( "," );
			insert.append( detalle.getFactorCantidadUnidadMedida() );
			insert.append( "," );
			insert.append( detalle.getFabrica() );		
			insert.append( "," );	
			if(detalle.getDescripcionComplementoFactura() != null && !detalle.getDescripcionComplementoFactura().equals("")) {	
				insert.append( "'" );	
				insert.append( detalle.getDescripcionComplementoFactura() ); 	
				insert.append( "'" );	
			}else{	
				insert.append( "NULL" );	
			}
			insert.append( ")" );
		boolean exito = false;

		try {
			con = ConexionDB.dameConexion();
			st = con.createStatement();
			exito = st.executeUpdate(insert.toString()) == 1;

			if (contenedor != null) {
				String update = "UPDATE cdiSAR SET tipoContenedor = " + contenedor + " WHERE folio = "
						+ detalle.getFolio();

				exito = exito && st.executeUpdate(update) == 1;
			}

			ConexionDB.devuelveConexion(con);

		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} catch (Exception e) {
			e.printStackTrace();
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}

		return exito;
	}

	public static boolean apruebaSAR(int folio, int status, String puertoOrigen, int fechaEmbarque, boolean esAereo,
			boolean cargoAProveedor, int aerolinea, String otraAerolinea, int contenedor, Boolean importado,
			long fecIniPlanning, int tinyFecIniPlanning, boolean diferenciaMRP, boolean request_cambio,
			String disagreeComments,boolean goodsAreReady,Date goodsReadyDate) {		
		Connection con = null;
		PreparedStatement pst = null;
		StringBuilder sb = new StringBuilder();
		sb.append("UPDATE cdiSAR SET ");
		sb.append("status = ?, ");
		sb.append("puertoSalida = ?, ");
		sb.append("fechaEmbarque = ?, ");
		sb.append("esAereo = ?, ");
		sb.append("cargoAProveedor = ?, ");
		sb.append("aerolinea = ?, ");
		sb.append("otraAerolinea = ?, ");
		sb.append("tipoContenedor = ?, ");
		sb.append("consolidado = ?, ");
		if (request_cambio) {
			sb.append("fecIniPlanning = NULL, ");
			sb.append("tinyFecIniPlanning = NULL, ");
		} else {
			sb.append("fecIniPlanning = ?, ");
			sb.append("tinyFecIniPlanning = ?, ");
		}
		sb.append("diferenciaMRP = ?, ");
		sb.append("etdProveedor = ? ");
		if (request_cambio) {
			sb.append(" ,fechaInicioLiberacionPrecios = GETDATE() ");
		} else {
			sb.append(" ,fechaInicioLiberacionPrecios = NULL ");
		}
		
		
		if(status == SarBO.STATUS_EN_REVISION_PRECIOS) {	
			sb.append(" , preciosEnRevision = 1 ");	
		}	
	
		
		
		if (UtilsString.isStringValida(disagreeComments)) {
			if (disagreeComments.length() > 100) {
				disagreeComments = disagreeComments.substring(0, 100);
			}
			sb.append(" ,disagreeComments = '").append(disagreeComments).append("'");
		}
		sb.append(",goods_are_ready = ? ");
		sb.append(",goods_ready_date = ? ");
		sb.append("WHERE folio = ? ");
		String update = sb.toString();
		boolean exito = false;
		int cont = 1;
		try {
			con = ConexionDB.dameConexion();
			pst = con.prepareStatement(update);
			pst.setInt(cont++, status);
			pst.setString(cont++, puertoOrigen);
			pst.setInt(cont++, fechaEmbarque);
			pst.setBoolean(cont++, esAereo);
			pst.setBoolean(cont++, cargoAProveedor);

			if (cargoAProveedor) {
				pst.setInt(cont++, aerolinea);
				if (aerolinea == -1) {
					pst.setString(cont++, otraAerolinea);
				} else {
					pst.setNull(cont++, java.sql.Types.VARCHAR);
				}
			} else {
				pst.setNull(cont++, java.sql.Types.INTEGER);
				pst.setNull(cont++, java.sql.Types.VARCHAR);
			}

			pst.setInt(cont++, contenedor);
			pst.setBoolean(cont++, contenedor == SarBO.LCL);
			if (!request_cambio) {
				pst.setLong(cont++, fecIniPlanning);
				pst.setInt(cont++, tinyFecIniPlanning);
			}
			pst.setBoolean(cont++, diferenciaMRP);

			pst.setInt(cont++, fechaEmbarque);

			pst.setBoolean(cont++,goodsAreReady);
			if(goodsReadyDate!=null) {
				pst.setDate(cont++,new java.sql.Date(goodsReadyDate.getTime()));
			}else {
				pst.setNull(cont++, java.sql.Types.DATE);
			}
			pst.setInt(cont++, folio);

			exito = pst.executeUpdate() == 1;
			ConexionDB.devuelveConexion(con);

		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} catch (Exception e) {
			e.printStackTrace();
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
		return exito;
	}

	/**
	 * @deprecated No se encontró referencia a este método.
	 * @param folioSAR
	 * @param sesion
	 * @param proveedor
	 */
	@SuppressWarnings("unchecked")
	public static void registraOrdenesNoCompletas(int folioSAR, HttpSession sesion, String proveedor) {
		Connection con = null;
		Statement st = null;
		ResultSet rs = null;
		String select = "SELECT folio, po, posicion, cantidad FROM cdiSARDetalle WHERE folio = " + folioSAR;
		HashMap<String, OrdenCdiBO> mapaOrdenes = (HashMap<String, OrdenCdiBO>) sesion.getAttribute("mapaOrdenes");
		ArrayList<OrdenCDIIncompletaEnSAR> ordenes = new ArrayList<OrdenCDIIncompletaEnSAR>();

		try {
			con = ConexionDB.dameConexion();
			st = con.createStatement();
			rs = st.executeQuery(select);

			while (rs.next()) {
				String po = rs.getString("po").trim();
				int posicion = rs.getInt("posicion");
				int cantidadSAR = rs.getInt("cantidad");

				OrdenCdiBO orden = mapaOrdenes.get(po + "|" + posicion);
				if (orden != null && orden.getCantidad().intValue() != cantidadSAR) {
					OrdenCDIIncompletaEnSAR ordenInc = new OrdenCDIIncompletaEnSAR(folioSAR, po, posicion, proveedor);
					ordenInc.setCantidadOrden(orden.getCantidad().intValue());
					ordenInc.setCantidadSAR(cantidadSAR);
					ordenes.add(ordenInc);
				}
			}

			st.close();

			if (ordenes.size() > 0) {
				GregorianCalendar hoy = new GregorianCalendar();
				String insert = "INSERT INTO cdiOrdenesIncompletasEnSAR (po, posicion, proveedor, sar, cantidadPO, cantidadSAR, fecha) VALUES (?,?,?,?,?,?,?)";
				PreparedStatement pst = con.prepareStatement(insert);

				for (OrdenCDIIncompletaEnSAR orden : ordenes) {
					pst.setString(1, orden.getPo());
					pst.setInt(2, orden.getPosicion());
					pst.setString(3, orden.getProveedor());
					pst.setInt(4, orden.getFolio());
					pst.setInt(5, orden.getCantidadOrden());
					pst.setInt(6, orden.getCantidadSAR());
					pst.setInt(7, FuncionesComunesPLI.gregorianCalendar2int(hoy));

					pst.executeUpdate();
				}

				pst.close();
			}

			ConexionDB.devuelveConexion(con);

		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} catch (Exception e) {
			e.printStackTrace();
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
	}

	public static boolean borraSAR(int folio) {
		Connection con = null;
		Statement st = null;
		String delete = "DELETE FROM cdiSARDetalle WHERE folio = " + folio;
		boolean exito = false;

		try {
			con = ConexionDB.dameConexion();
			st = con.createStatement();

			st.executeUpdate(delete); // Borrando detalles
			
			Integer  id =getCdisarsenbooking(folio);
			
			String deleteCdisarsenbooking = "DELETE FROM cdisarsenbooking where  SAR =  " + folio ;
			st.executeUpdate(deleteCdisarsenbooking);
			
			String deleteCdiDocumentosSDI = "DELETE FROM cdiDocumentosSDI WHERE id = " + id ;
			st.executeUpdate(deleteCdiDocumentosSDI);
			

			delete = "DELETE FROM cdiSAR WHERE folio = " + folio;
			exito = st.executeUpdate(delete) == 1; // borrando SAR

			log.info("[Eliminar SAR ] OK!! SAR::" + folio);
		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				log.error("[Eliminar SAR ] OK!! SAR::" + folio + " " + ex.getMessage(), ex);
			}
			log.error("[Eliminar SAR ] OK!! SAR::" + folio + " " + e.getMessage(), e);
		} catch (Exception e) {
			e.printStackTrace();
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error("[Eliminar detalle del SAR ] OK!! SAR::" + folio + " " + ex.getMessage(), ex);
			}
			log.error("[Eliminar detalle del SAR ] OK!! SAR::" + folio + " " + e.getMessage(), e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
		return exito;
	}

	public static String insertaNuevoSARConsolidado(SARConsolidados base) throws Exception {
		Connection con = null;
		PreparedStatement pst = null;
		String folio = "";
		try {
			GregorianCalendar hoyInt = new GregorianCalendar();
			String insert = "INSERT INTO cdiSARConsolidados ( puertoSalida, naviera, fechaEmbarque, status, tipoContenedor, "
					+ "prioridad, barcoSugerido, viaje, puertoDescarga, contenedor, booking, eta ,etdfinal, transporte,comentarioConsolidado,fechaCreacion,tipoProducto)"
					+ "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

			con = ConexionDB.dameConexion();
			pst = con.prepareStatement(insert.toString(), Statement.RETURN_GENERATED_KEYS);
			int cont = 1;

			agregarPs(cont++, pst, base.getPuertoSalida(), String.class);
			agregarPs(cont++, pst, base.getNaviera(), Integer.class);
			agregarPs(cont++, pst, base.getFechaEmbarque(), Integer.class);
			agregarPs(cont++, pst, base.getStatus(), Integer.class);
			agregarPs(cont++, pst, base.getTipoContenedor(), Integer.class);
			agregarPs(cont++, pst, base.getPrioridad(), Integer.class);
			agregarPs(cont++, pst, base.getBarcoSugerido(), String.class);
			agregarPs(cont++, pst, base.getViaje(), String.class);
			agregarPs(cont++, pst, base.getPuertoDescarga(), String.class);
			agregarPs(cont++, pst, base.getContenedor(), String.class);
			agregarPs(cont++, pst, base.getBooking(), String.class);
			agregarPs(cont++, pst, base.getEta(), Integer.class);
			agregarPs(cont++, pst, base.getEtdReal(), Integer.class);
			agregarPs(cont++, pst, base.getTransporte(), Integer.class);
			agregarPs(cont++, pst, base.getComentarioConsol(), String.class);
			agregarPs(cont++, pst, FuncionesComunesPLI.gregorianCalendar2int(hoyInt), Integer.class);
			agregarPs(cont++, pst, base.getTipoProducto(), String.class);
			pst.executeUpdate();

			ResultSet keys = pst.getGeneratedKeys();

			while (keys.next()) {
				folio = keys.getString(1);
			}

			ConexionDB.devuelveConexion(con);

		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
			throw e;
		} catch (Exception e) {
			e.printStackTrace();
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
			throw e;
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}

		return folio;
	}

	public boolean updateSARConsolidado(SARConsolidados base, UserBean usuario)
			throws SQLException, ClassNotFoundException {

		Connection con = null;
		boolean result = false;

		try {
			con = ConexionDB.dameConexion();

			PreparedStatement pst = null;
			StringBuffer query = new StringBuffer();

			query.append("UPDATE cdiSARConsolidados  set  ");

			if (base.getPuertoSalida() != null) {
				query.append(" puertoSalida = ?, ");
			}
			if (base.getNaviera() != null) {
				query.append(" naviera = ?, ");
			}
			if (base.getFechaEmbarque() != null) {
				query.append(" fechaEmbarque = ?, ");
			}
			if (base.getStatus() != null) {
				query.append(" status = ?, ");
			}
			if (base.getTipoContenedor() != null) {
				query.append(" tipoContenedor  = ?, ");
			}
			if (base.getPrioridad() != null) {
				query.append(" prioridad  = ?, ");
			}
			if (base.getBarcoSugerido() != null) {
				query.append("  barcoSugerido = ?, ");
			}
			if (base.getViaje() != null) {
				query.append(" viaje = ?, ");
			}
			if (base.getPuertoDescarga() != null) {
				query.append(" puertoDescarga = ?, ");
			}
			if (base.getContenedor() != null) {
				query.append(" contenedor = ?, ");
			}
			if (base.getBooking() != null) {
				query.append(" booking = ?, ");
			}
			if (base.getEta() != null) {
				query.append(" eta = ?, ");
			}
			if (base.getEtdReal() != null) {
				query.append(" etdfinal = ?, ");
			}
			if (base.getComentarioConsol() != null) {
				query.append(" comentarioConsolidado = ?, ");
			}
			if (base.getComentarioTruperBooking() != null) {
				query.append(" comentarioTruperBooking = ?, ");
			}
			if (base.getPaisDestino() != null) {
				query.append(" paisdestino = ?, ");
			}

			if (base.getTipoProducto() != null) {
				query.append("  tipoProducto = ?, ");
			}
			if (base.getTipoRetraso() != null) {
				query.append(" tipoRetraso = ?, ");
			}
			if (base.getRetrasoProveedor() != null) {
				query.append(" retrasoProveedor = ?, ");
			}
			if (base.getEsDesbloqueado() != null) {
				query.append(" esDesbloqueado = ?, ");
			}
			if (base.getFecIniEmbarque() != null) {
				query.append(" fecIniEmbarque = ?, ");
			}
			if (base.getTinyFecIniEmbarque() != null) {
				query.append(" tinyFecIniEmbarque = ?, ");
			}

			if (base.getRevision() != null) {
				query.append(" revision = ?, ");
			}

			boolean isLast = false;
			if (base.getTransporte() != null) {
				isLast = true;
				query.append(" transporte = ? ");
			}

			if (!isLast) {
				query = query.delete(query.length() - 2, query.length());
			}

			query.append(" where folio  = ? ");

			pst = con.prepareStatement(query.toString());

			int cont = 1;

			if (base.getPuertoSalida() != null) {
				agregarPs(cont++, pst, base.getPuertoSalida(), String.class);
			}
			if (base.getNaviera() != null) {
				agregarPs(cont++, pst, base.getNaviera(), Integer.class);
			}
			if (base.getFechaEmbarque() != null) {
				agregarPs(cont++, pst, base.getFechaEmbarque(), Integer.class);
			}
			if (base.getStatus() != null) {
				agregarPs(cont++, pst, base.getStatus(), Integer.class);
			}
			if (base.getTipoContenedor() != null) {
				agregarPs(cont++, pst, base.getTipoContenedor(), Integer.class);
			}
			if (base.getPrioridad() != null) {
				agregarPs(cont++, pst, base.getPrioridad(), Integer.class);
			}
			if (base.getBarcoSugerido() != null) {
				agregarPs(cont++, pst, base.getBarcoSugerido(), String.class);
			}
			if (base.getViaje() != null) {
				agregarPs(cont++, pst, base.getViaje(), String.class);
			}
			if (base.getPuertoDescarga() != null) {
				agregarPs(cont++, pst, base.getPuertoDescarga(), String.class);
			}
			if (base.getContenedor() != null) {
				agregarPs(cont++, pst, base.getContenedor(), String.class);
			}
			if (base.getBooking() != null) {
				agregarPs(cont++, pst, base.getBooking(), String.class);
			}
			if (base.getEta() != null) {
				agregarPs(cont++, pst, base.getEta(), Integer.class);
			}
			if (base.getEtdReal() != null) {
				agregarPs(cont++, pst, base.getEtdReal(), Integer.class);
			}
			if (base.getComentarioConsol() != null) {
				agregarPs(cont++, pst, base.getComentarioConsol(), String.class);
			}
			if (base.getComentarioTruperBooking() != null) {
				agregarPs(cont++, pst, base.getComentarioTruperBooking(), String.class);
			}
			if (base.getPaisDestino() != null) {
				agregarPs(cont++, pst, base.getPaisDestino(), Integer.class);
			}
			if (base.getTipoProducto() != null) {
				agregarPs(cont++, pst, base.getTipoProducto(), String.class);
			}
			if (base.getTipoRetraso() != null) {
				agregarPs(cont++, pst, base.getTipoRetraso(), Integer.class);
			}
			if (base.getRetrasoProveedor() != null) {
				agregarPs(cont++, pst, base.getRetrasoProveedor(), String.class);
			}
			if (base.getEsDesbloqueado() != null) {
				agregarPs(cont++, pst, base.getEsDesbloqueado(), Boolean.class);
			}
			if (base.getFecIniEmbarque() != null) {
				agregarPs(cont++, pst, base.getFecIniEmbarque(), Long.class);
			}
			if (base.getTinyFecIniEmbarque() != null) {
				agregarPs(cont++, pst, base.getTinyFecIniEmbarque(), Integer.class);
			}

			if (base.getRevision() != null) {
				agregarPs(cont++, pst, base.getRevision(), Integer.class);
			}

			if (base.getTransporte() != null) {
				agregarPs(cont++, pst, base.getTransporte(), Integer.class);
			}

			agregarPs(cont++, pst, base.getFolio(), Integer.class);

			int resultado = pst.executeUpdate();
			result = (resultado > 0);
			pst.close();

			ConexionDB.devuelveConexion(con);

		} catch (SQLException sqlE) {
			try {
				con.rollback();
				log.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
			throw sqlE;
		} catch (IOException ioE) {
			try {
				con.rollback();
				log.error(ioE.getMessage(), ioE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception ioE2) {
				log.error(ioE2.getMessage(), ioE2);
			}
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}

		return result;
	}

	public static boolean updateSarEnConsolidados(String listaSARs, String folio) {
		Connection con = null;
		Statement st = null;
		String update = "UPDATE cdiSAR SET folioConsolidado = " + folio + " WHERE folio in( " + listaSARs + ")";
		boolean exito = false;

		try {
			con = ConexionDB.dameConexion();
			st = con.createStatement();

			exito = (st.executeUpdate(update) > 0);

			ConexionDB.devuelveConexion(con);

		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} catch (Exception e) {
			e.printStackTrace();
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}

		return exito;
	}

	public static boolean borraConsolidado(int folio) {
		Connection con = null;
		Statement st = null;
		String delete = "";
		boolean exito = false;

		try {
			con = ConexionDB.dameConexion();
			st = con.createStatement();

			delete = "DELETE FROM cdiSARConsolidados WHERE folio = " + folio;
			exito = st.executeUpdate(delete) == 1;

			ConexionDB.devuelveConexion(con);

		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} catch (Exception e) {
			e.printStackTrace();
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}

		return exito;
	}

	/**
	 * Metodo que me ayuda a saber el detalle de todos los folios o SAR que yo el
	 * envio en la variable detalles, pero con las restricciones del bean regreso
	 * una lista con los SARs correspondientes.
	 * 
	 * @param detalles
	 * @param bean
	 * @return
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 */
	public ArrayList<SarBO> selectSar(String detalles, SarBO bean) throws SQLException, ClassNotFoundException {

		ArrayList<SarBO> listaSAR = new ArrayList<SarBO>();

		Connection con = null;
		if (detalles == null || "".equals(detalles)) {
			return listaSAR;
		}

		try {
			con = ConexionDB.dameConexion();

			ResultSet rs = null;
			PreparedStatement pst = null;
			StringBuffer query = new StringBuffer();

			query.append(
					"SELECT     folio, proveedor, puertoSalida, naviera, fechaEmbarque, consolidado, status, fechaSolAprobacion,   ");
			query.append(
					" usuarioSolAprobacion, fechaUltAprobRechazo, usuarioApruebaRechaza, tipoContenedor, prioridad, ");
			query.append(
					" barcoSugerido, viaje, puertoDescarga, contenedor, booking, etd,etdFinal, comentarioCancelacion,folioConsolidado,transporte,"
							+ "comentarioPlanner,comentarioShipping,esSinPO,eta, fechaCreacion ");
			query.append(" FROM         cdiSAR ");
			query.append(" WHERE   1=1   ");

			if (bean.getContenedor() != null) {
				query.append(" AND  contenedor = ? ");
			}
			if (detalles != null || !"".equals(detalles)) {
				query.append(" AND  folio in (" + detalles + ")");
			}
			if (bean.getFechaEmbarque() != null) {
				if (bean.getFechaEmbarqueIni() != null && bean.getFechaEmbarqueFin() != null) {
					query.append(" AND  fechaEmbarque BETWEEN  ? AND  ? ");
				} else {
					if (bean.getFechaEmbarqueIni() != null) {
						query.append(" AND  fechaEmbarque >=  ? ");
					} else {
						query.append(" AND  fechaEmbarque = ? ");
					}
				}
			}
			// /Si la bandera dice que incluye ya consolidados, los agrego
			if (bean.getConsolidado() != null) {
				if ((bean.getIncluyeSarConsol() == null || !bean.getIncluyeSarConsol())) {
					query.append("AND folioconsolidado is null ");
				}

			}

			if (bean.getBarcoSugerido() != null) {
				query.append(" AND  barcoSugerido = ? ");
			}
			if (bean.getBooking() != null) {
				query.append(" AND  booking = ? ");
			}
			if (bean.getConsolidado() != null) {
				query.append(" AND  consolidado = ? ");
			}
			if (bean.getEtdPlanner() != null) {
				query.append(" AND  etd = ? ");
			}
			if (bean.getEtdReal() != null) {
				query.append(" AND  etdfinal = ? ");
			}
			if (bean.getFechaSolicitudDeAprobacion() != null) {
				query.append(" AND  fechaSolAprobacion = ? ");
			}
			if (bean.getFechaUltimaAprobacionRechazo() != null) {
				query.append(" AND  fechaUltAprobRechazo = ? ");
			}
			if (bean.getNaviera() != null) {
				query.append(" AND  naviera = ? ");
			}
			if (bean.getPrioridad() != null) {
				query.append(" AND  prioridad = ? ");
			}
			if (bean.getProveedor() != null) {
				query.append(" AND  proveedor = ? ");
			}
			if (bean.getPuertoDescarga() != null) {
				query.append(" AND  puertoDescarga = ? ");
			}
			if (bean.getPuertoSalida() != null) {
				query.append(" AND  puertoSalida = ? ");
			}
			if (bean.getStatus() != null) {
				query.append(" AND  status = ? ");
			}
			if (bean.getTipoContenedor() != null) {
				query.append(" AND  tipoContenedor = ? ");
			}
			if (bean.getUsuarioApruebaRechaza() != null) {
				query.append(" AND  usuarioApruebaRechaza = ? ");
			}
			if (bean.getUsuarioSolicitudDeAprobacion() != null) {
				query.append(" AND  usuarioSolAprobacion = ? ");
			}
			if (bean.getViaje() != null) {
				query.append(" AND  viaje = ? ");
			}
			if (bean.getComentarioCancelacion() != null) {
				query.append(" AND  comentarioCancelacion = ? ");
			}
			if (bean.getFolioConsolidado() != null) {
				query.append(" AND  folioConsolidado = ? ");
			}

			pst = con.prepareStatement(query.toString());

			int cont = 1;
			if (bean.getContenedor() != null) {
				pst.setString(cont++, bean.getContenedor());
			}

			if (bean.getFechaEmbarque() != null) {
				if (bean.getFechaEmbarqueIni() != null && bean.getFechaEmbarqueFin() != null) {
					pst.setInt(cont++, bean.getFechaEmbarqueIni());
					pst.setInt(cont++, bean.getFechaEmbarqueFin());
				} else {
					if (bean.getFechaEmbarqueIni() != null) {
						pst.setInt(cont++, bean.getFechaEmbarqueIni());
					} else {
						pst.setInt(cont++, bean.getFechaEmbarque());
					}
				}
			}
			if (bean.getBarcoSugerido() != null) {
				pst.setString(cont++, bean.getBarcoSugerido());
			}
			if (bean.getBooking() != null) {
				pst.setString(cont++, bean.getBooking());
			}
			if (bean.getConsolidado() != null) {
				pst.setBoolean(cont++, bean.getConsolidado());
			}
			if (bean.getEtdPlanner() != null) {
				pst.setInt(cont++, bean.getEtdPlanner());
			}
			if (bean.getEtdReal() != null) {
				pst.setInt(cont++, bean.getEtdReal());
			}
			if (bean.getFechaSolicitudDeAprobacion() != null) {
				pst.setInt(cont++, bean.getFechaSolicitudDeAprobacion());
			}
			if (bean.getFechaUltimaAprobacionRechazo() != null) {
				pst.setInt(cont++, bean.getFechaUltimaAprobacionRechazo());
			}
			if (bean.getNaviera() != null) {
				pst.setInt(cont++, bean.getNaviera());
			}
			if (bean.getPrioridad() != null) {
				pst.setInt(cont++, bean.getPrioridad());
			}
			if (bean.getProveedor() != null) {
				pst.setString(cont++, bean.getProveedor());
			}

			if (bean.getPuertoDescarga() != null) {
				pst.setString(cont++, bean.getPuertoDescarga());
			}
			if (bean.getPuertoSalida() != null) {
				pst.setString(cont++, bean.getPuertoSalida());
			}
			if (bean.getStatus() != null) {
				pst.setInt(cont++, bean.getStatus());
			}
			if (bean.getTipoContenedor() != null) {
				pst.setInt(cont++, bean.getTipoContenedor());
			}
			if (bean.getUsuarioApruebaRechaza() != null) {
				pst.setString(cont++, bean.getUsuarioApruebaRechaza());
			}
			if (bean.getUsuarioSolicitudDeAprobacion() != null) {
				pst.setString(cont++, bean.getUsuarioSolicitudDeAprobacion());
			}
			if (bean.getViaje() != null) {
				pst.setString(cont++, bean.getViaje());
			}
			if (bean.getComentarioCancelacion() != null) {
				pst.setString(cont++, bean.getComentarioCancelacion());
			}
			if (bean.getFolioConsolidado() != null) {
				pst.setInt(cont++, bean.getFolioConsolidado());
			}

			rs = pst.executeQuery();

			while (rs.next()) {

				SarBO tmpSAR = new SarBO();
				tmpSAR.setFolio(rs.getInt("folio"));
				tmpSAR.setProveedor(rs.getString("proveedor"));
				tmpSAR.setPuertoSalida(rs.getString("puertoSalida"));
				tmpSAR.setNaviera(rs.getInt("naviera"));
				if (rs.wasNull()) {
					tmpSAR.setNaviera(null);
				}
				tmpSAR.setFechaEmbarque(rs.getInt("fechaEmbarque"));
				tmpSAR.setConsolidado(rs.getBoolean("consolidado"));
				tmpSAR.setStatus(rs.getInt("status"));
				tmpSAR.setFechaSolicitudDeAprobacion(rs.getInt("fechaSolAprobacion"));
				tmpSAR.setUsuarioSolicitudDeAprobacion(rs.getString("usuarioSolAprobacion"));
				tmpSAR.setFechaUltimaAprobacionRechazo(rs.getInt("fechaUltAprobRechazo"));
				tmpSAR.setUsuarioApruebaRechaza(rs.getString("usuarioApruebaRechaza"));
				tmpSAR.setTipoContenedor(rs.getInt("tipoContenedor"));
				tmpSAR.setPrioridad(rs.getInt("prioridad"));
				tmpSAR.setBarcoSugerido(rs.getString("barcoSugerido"));
				tmpSAR.setViaje(rs.getString("viaje"));
				tmpSAR.setPuertoDescarga(rs.getString("puertoDescarga"));
				tmpSAR.setContenedor(rs.getString("contenedor"));
				tmpSAR.setBooking(rs.getString("booking"));
				tmpSAR.setEtdPlanner(rs.getInt("etd"));
				tmpSAR.setEtdReal(rs.getInt("etdfinal"));
				tmpSAR.setComentarioCancelacion(rs.getString("comentarioCancelacion"));
				tmpSAR.setFolioConsolidado(rs.getInt("folioConsolidado"));
				if (rs.wasNull()) {
					tmpSAR.setFolioConsolidado(null);
				}

				tmpSAR.setTransporte(rs.getInt("transporte"));
				tmpSAR.setComentarioPlanner(rs.getString("comentarioPlanner"));
				tmpSAR.setComentarioShipping(rs.getString("comentarioShipping"));
				tmpSAR.setEsSinPO(rs.getBoolean("esSinPO"));
				tmpSAR.setEta(rs.getInt("eta"));
				tmpSAR.setCreationDate(rs.getInt("fechaCreacion"));

				listaSAR.add(tmpSAR);
			}
			rs.close();
			pst.close();
			ConexionDB.devuelveConexion(con);

		} catch (SQLException sqlE) {
			try {
				log.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
			throw sqlE;
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}

		return listaSAR;
	}

	public ArrayList<SARHistoricoBooking> selectSarHistorico(SARHistoricoBooking bean)
			throws SQLException, ClassNotFoundException {

		ArrayList<SARHistoricoBooking> listaSAR = new ArrayList<SARHistoricoBooking>();

		Connection con = null;

		try {
			con = ConexionDB.dameConexion();

			ResultSet rs = null;
			StringBuffer query = new StringBuffer();
			Statement st = null;

			query.append(
					"SELECT     folio, tipoSar, booking, barcoSugerido, fechaEtd, contenedor, usuario, usuarioString,");
			query.append(
					" fechaRegistro,fechaRegistroLong,comentario,eta,viaje,naviera, puertoOrigen, puertoDestino,tipocontenedor ");
			query.append(" FROM   cdiHistoricosBooking ");
			query.append(" WHERE   folio =  " + bean.getFolio());
			query.append(" AND   tipoSAR =  '" + bean.getTipoSar() + "'");
			query.append(" ORDER BY   fechaRegistroLong desc");

			st = con.createStatement();
			rs = st.executeQuery(query.toString());

			while (rs.next()) {
				SARHistoricoBooking tmpSAR = new SARHistoricoBooking();
				tmpSAR.setBarcoSugerido(rs.getString("barcoSugerido"));
				tmpSAR.setBooking(rs.getString("booking"));
				tmpSAR.setContenedor(rs.getString("contenedor"));
				tmpSAR.setEtd(rs.getInt("fechaEtd"));
				tmpSAR.setFolio(rs.getInt("folio"));
				tmpSAR.setTipoSar(rs.getString("tipoSar"));
				tmpSAR.setUsuario(rs.getString("usuario"));
				tmpSAR.setUsuarioString(rs.getString("usuarioString"));
				tmpSAR.setFechaRegistro(rs.getInt("fechaRegistro"));
				tmpSAR.setFechaLong(rs.getDouble("fechaRegistroLong"));
				tmpSAR.setComentarioTruperBooking(rs.getString("comentario"));
				tmpSAR.setEta(rs.getInt("eta"));
				tmpSAR.setViaje(rs.getString("viaje"));
				tmpSAR.setNaviera(rs.getInt("naviera"));
				tmpSAR.setPuertoOrigen(rs.getString("puertoOrigen"));
				tmpSAR.setPuertoDestino(rs.getString("puertoDestino"));
				tmpSAR.setTipoContenedor(rs.getInt("tipocontenedor"));
				listaSAR.add(tmpSAR);
			}
			rs.close();
			ConexionDB.devuelveConexion(con);

		} catch (SQLException sqlE) {
			try {
				log.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
			throw sqlE;
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}

		return listaSAR;
	}

	public SARHistoricoBooking selectUltimoHistorico(SARHistoricoBooking bean)
			throws SQLException, ClassNotFoundException {

		SARHistoricoBooking result = new SARHistoricoBooking();

		Connection con = null;

		try {
			con = ConexionDB.dameConexion();

			ResultSet rs = null;
			StringBuffer query = new StringBuffer();
			Statement st = null;

			query.append(
					"SELECT  top(1) folio, tipoSar, booking, barcoSugerido, fechaEtd, contenedor, usuario, usuarioString,"
							+ "fechaRegistro,fechaRegistroLong,comentario,eta,viaje,naviera, puertoOrigen, puertoDestino, tipocontenedor ");
			query.append(" FROM   cdiHistoricosBooking ");
			query.append(" WHERE   folio =  " + bean.getFolio());
			query.append(" AND     tipoSAR =  '" + bean.getTipoSar() + "'");
			query.append(" ORDER BY   fechaRegistroLong desc");

			st = con.createStatement();
			rs = st.executeQuery(query.toString());

			while (rs.next()) {
				result.setBarcoSugerido(rs.getString("barcoSugerido"));
				result.setBooking(rs.getString("booking"));
				result.setContenedor(rs.getString("contenedor"));
				result.setEtd(rs.getInt("fechaEtd"));
				result.setFolio(rs.getInt("folio"));
				result.setTipoSar(rs.getString("tipoSar"));
				result.setUsuario(rs.getString("usuario"));
				result.setUsuarioString(rs.getString("usuarioString"));
				result.setFechaRegistro(rs.getInt("fechaRegistro"));
				result.setFechaLong(rs.getDouble("fechaRegistroLong"));
				result.setComentarioTruperBooking(rs.getString("comentario"));
				result.setEta(rs.getInt("eta"));
				result.setViaje(rs.getString("viaje"));
				result.setNaviera(rs.getInt("naviera"));
				result.setPuertoOrigen(rs.getString("puertoOrigen"));
				result.setPuertoDestino(rs.getString("puertoDestino"));
				result.setTipoContenedor(rs.getInt("tipocontenedor"));
			}
			rs.close();
			ConexionDB.devuelveConexion(con);

		} catch (SQLException sqlE) {
			try {
				log.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
			throw sqlE;
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}

		return result;
	}

	public static boolean insertaHistorico(SARHistoricoBooking detalle) {
		Connection con = null;
		Statement st = null;
		StringBuffer insert = new StringBuffer();
		insert.append("INSERT INTO cdiHistoricosBooking (  folio, tipoSar, booking, barcoSugerido, ");
		insert.append(" fechaEtd, contenedor, usuario, usuarioString, fechaRegistro, ");
		insert.append(" fechaRegistroLong,viaje,eta,comentario,naviera, puertoOrigen, ");
		insert.append(" puertoDestino,tipocontenedor ) VALUES ( ");
		insert.append(detalle.getFolio()).append(", '").append(detalle.getTipoSar()).append("', '");
		insert.append(detalle.getBooking()).append("', '").append(detalle.getBarcoSugerido());
		insert.append("', ").append(detalle.getEtd()).append(",'");
		insert.append(detalle.getContenedor()).append("', '").append(detalle.getUsuario());
		insert.append("', '").append(detalle.getUsuarioString()).append("',");
		insert.append(detalle.getFechaRegistro()).append(",").append(detalle.getFechaLong()).append(",").append("'");
		insert.append(detalle.getViaje()).append("',").append(detalle.getEta()).append(",").append("'");
		insert.append((detalle.getComentarioTruperBooking() != null ? detalle.getComentarioTruperBooking() : ""));
		insert.append("'");
		insert.append(",");
		insert.append(detalle.getNaviera());
		insert.append(",'");
		insert.append(detalle.getPuertoOrigen());
		insert.append("','");
		insert.append(detalle.getPuertoDestino());
		insert.append("',");
		insert.append(detalle.getTipoContenedor());
		insert.append(")");

		boolean exito = false;

		try {
			con = ConexionDB.dameConexion();
			st = con.createStatement();
			exito = st.executeUpdate(insert.toString()) == 1;

			ConexionDB.devuelveConexion(con);

		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} catch (Exception e) {
			e.printStackTrace();
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}

		return exito;
	}

	public ArrayList<SARConsolidadosHistorico> selectConsolidadoHistorico(SARConsolidadosHistorico bean)
			throws SQLException, ClassNotFoundException {

		ArrayList<SARConsolidadosHistorico> listaSAR = new ArrayList<SARConsolidadosHistorico>();

		Connection con = null;

		try {
			con = ConexionDB.dameConexion();

			ResultSet rs = null;
			StringBuffer query = new StringBuffer();
			Statement st = null;

			query.append(
					"SELECT     id, folio, puertoSalida, naviera, fechaEmbarque, tipoContenedor, prioridad, barcoSugerido, viaje,  ");
			query.append(" puertoDescarga, contenedor, booking, etdFinal, transporte,  ");
			query.append(" comentarioConsolidado, sarsEnContenedor,fechaModificacion, ");
			query.append(" usuarioModificacion,retrasoProveedor,tipoProducto,tipoRetraso ");
			query.append(" FROM    cdi_consolidadoHistorico ");
			query.append(" WHERE   folio = " + bean.getFolio());
			query.append(" ORDER BY id desc ");

			st = con.createStatement();
			rs = st.executeQuery(query.toString());

			while (rs.next()) {
				SARConsolidadosHistorico tmp = new SARConsolidadosHistorico();
				tmp.setId(rs.getInt("id"));
				tmp.setFolio(rs.getInt("folio"));
				tmp.setPuertoSalida(rs.getString("puertoSalida"));
				tmp.setNaviera(rs.getInt("naviera"));
				tmp.setFechaEmbarque(rs.getInt("fechaEmbarque"));
				tmp.setTipoContenedor(rs.getInt("tipoContenedor"));
				tmp.setPrioridad(rs.getInt("prioridad"));
				tmp.setBarcoSugerido(rs.getString("barcoSugerido"));
				tmp.setViaje(rs.getString("viaje"));
				tmp.setPuertoDescarga(rs.getString("puertoDescarga"));
				tmp.setContenedor(rs.getString("contenedor"));
				tmp.setBooking(rs.getString("booking"));
				tmp.setEtdReal(rs.getInt("etdFinal"));
				tmp.setTransporte(rs.getInt("transporte"));
				tmp.setComentarioConsol(rs.getString("comentarioConsolidado"));
				tmp.setPOsEnConsolidado(rs.getString("sarsEnContenedor"));
				tmp.setFechaModficacion(rs.getInt("fechaModificacion"));
				tmp.setUsuarioMof(rs.getString("usuarioModificacion"));
				tmp.setRetrasoProveedor(rs.getString("retrasoProveedor"));
				tmp.setTipoProducto(rs.getString("tipoProducto"));
				tmp.setTipoRetraso(rs.getInt("tipoRetraso"));

				listaSAR.add(tmp);
			}
			rs.close();
			ConexionDB.devuelveConexion(con);

		} catch (SQLException sqlE) {
			try {
				log.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
			throw sqlE;
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}

		return listaSAR;
	}

	public static boolean insertaHistorico(SARConsolidadosHistorico detalle) {
		boolean exito = false;
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();
			try (PreparedStatement ps = con.prepareStatement(INSERT_CONSOLIDADO_HISTORICO);) {
				int r = 1;
				ps.setInt(r, detalle.getId());
				ps.setInt(++r, detalle.getFolio());
				ps.setString(++r, detalle.getPuertoSalida());
				ps.setInt(++r, detalle.getNaviera());
				ps.setInt(++r, detalle.getFechaEmbarque());
				ps.setInt(++r, detalle.getTipoContenedor());
				ps.setInt(++r, detalle.getPrioridad());
				ps.setString(++r, getNullStringAsEmpty(detalle.getBarcoSugerido()));
				ps.setString(++r, getNullStringAsEmpty(detalle.getViaje()));
				ps.setString(++r, detalle.getPuertoDescarga());
				ps.setString(++r, getNullStringAsEmpty(detalle.getContenedor()));
				ps.setString(++r, getNullStringAsEmpty(detalle.getBooking()));
				ps.setInt(++r, detalle.getEtdReal());
				ps.setInt(++r, detalle.getTransporte());
				ps.setString(++r, getNullStringAsEmpty(detalle.getComentarioConsol()));
				ps.setString(++r, getNullStringAsEmpty(detalle.getPOsEnConsolidado()));
				ps.setInt(++r, detalle.getFechaModficacion());
				ps.setString(++r, getNullStringAsEmpty(detalle.getUsuarioMof()));
				ps.setInt(++r, detalle.getTipoRetraso() == null ? 0 : detalle.getTipoRetraso());
				ps.setString(++r, getNullStringAsEmpty(detalle.getRetrasoProveedor()));
				ps.setString(++r, getNullStringAsEmpty(detalle.getTipoProducto()));

				StringBuilder log_text = new StringBuilder("[INSERTANDO HISTORICO DE CONSOLIDACION SAR: ");
				log_text.append(detalle.getFolio()).append("]");
				log_text.append("\n SQL: ").append(INSERT_CONSOLIDADO_HISTORICO);
				log_text.append("\n Bean: ").append(detalle);
				log.info(log_text.toString());

				exito = ps.executeUpdate() == 1;
			}
		} catch (SQLException sqle) {
			sqle.printStackTrace();
			log.error(sqle.getMessage(), sqle);
			ConexionDB.renovar(con);
		} catch (Exception e) {
			e.printStackTrace();
			log.error(e.getMessage(), e);
		} finally {
			ConexionDB.devolver(con);
		}
		return exito;
	}

	/**
	 * Metodo que consulta la tabla importacionesdetalleorden
	 * 
	 * @param po
	 * @param posicion
	 * @return
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 * @deprecated
	 */
	public static BeanNotificacionesDetalleOrden selectNotificaionDetalle(String po, int posicion)
			throws SQLException, ClassNotFoundException {

		BeanNotificacionesDetalleOrden listaSAR = new BeanNotificacionesDetalleOrden();

		Connection con = null;

		try {
			con = ConexionDB.dameConexion();

			ResultSet rs = null;
			StringBuffer query = new StringBuffer();
			Statement st = null;

			query.append(" select numeroorden,posicion,material,cantidad,fechaproforma,planeador ");
			query.append(" , ordencerrada from importacionesdetalleorden ");
			query.append(" where numeroorden = '").append(po.trim()).append("'");
			query.append(" and posicion =  ").append(posicion);

			st = con.createStatement();
			rs = st.executeQuery(query.toString());

			while (rs.next()) {
				listaSAR.setNumeroorden(rs.getString("numeroorden"));
				listaSAR.setPosicion(rs.getInt("posicion"));
				listaSAR.setMaterial(rs.getString("material"));
				listaSAR.setCantidad(rs.getInt("cantidad"));
				listaSAR.setFechaProforma(rs.getInt("fechaproforma"));
				listaSAR.setPlaneador(rs.getString("planeador"));
				listaSAR.setOrdenCerrada(rs.getString("ordencerrada"));

			}
			rs.close();
			ConexionDB.devuelveConexion(con);

		} catch (SQLException sqlE) {
			try {
				log.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
			throw sqlE;
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}

		return listaSAR;
	}

	/**
	 * Hace el select dinamico a la tabla de Importacionesnotificaciones en tel,
	 * metodo que utilizo para PLI y sus consultas a estas tablas.
	 * 
	 * @param bean
	 * @return Arraylist de BeanNotificaciones
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 * @deprecated
	 */
	public static ArrayList<BeanNotificaciones> selectImportacionesNotificaciones(BeanNotificaciones bean)
			throws SQLException, ClassNotFoundException {

		ArrayList<BeanNotificaciones> lista = new ArrayList<BeanNotificaciones>();
		Connection con = null;

		try {
			con = ConexionDB.dameConexion();

			ResultSet rs = null;
			StringBuffer query = new StringBuffer();
			Statement st = null;

			query.append(
					" SELECT id, numeroOrden, posicion, fecha, cantidad, documentos, contenedor, estado, diaSeguimiento, diaDeCaptura, ");
			query.append(" esCI, numOrdenSecundaria, tipoConf, sar, eta, adelantoAtraso ");
			query.append(" FROM            ImportacionesNotificaciones");
			query.append(" where 1=1  ");

			if (bean.getNumeroOrden() != null) {
				query.append(" and numeroorden =  " + bean.getNumeroOrden().trim());
			}
			if (bean.getPosicion() != null) {
				query.append(" and posicion = " + bean.getPosicion());
			}
			if (bean.getCantidad() != null) {
				query.append(" and cantidad = " + bean.getCantidad());
			}
			st = con.createStatement();
			rs = st.executeQuery(query.toString());

			while (rs.next()) {
				BeanNotificaciones tmp = new BeanNotificaciones();
				tmp.setNumeroOrden(rs.getString("numeroOrden"));
				tmp.setPosicion(rs.getInt("posicion"));
				tmp.setFecha(rs.getInt("fecha"));
				tmp.setCantidad(rs.getInt("cantidad"));
				tmp.setDocumentos(rs.getString("documentos"));
				tmp.setContenedor(rs.getString("contenedor"));
				tmp.setEstado(rs.getBoolean("estado"));
				tmp.setDiaSeguimiento(rs.getInt("diaSeguimiento"));
				if (rs.wasNull()) {
					tmp.setDiaSeguimiento(null);
				}
				tmp.setDiaDeCaptura(rs.getInt("diaDeCaptura"));
				if (rs.wasNull()) {
					tmp.setDiaDeCaptura(null);
				}
				tmp.setEsCI(rs.getBoolean("esCI"));
				if (rs.wasNull()) {
					tmp.setEsCI(null);
				}
				tmp.setNumOrdenSecundaria(rs.getInt("numOrdenSecundaria"));
				if (rs.wasNull()) {
					tmp.setNumOrdenSecundaria(null);
				}
				tmp.setTipoConf(rs.getString("tipoConf"));
				tmp.setSar(rs.getString("sar"));
				tmp.setEta(rs.getInt("eta"));
				tmp.setAdelantoAtraso(rs.getString("adelantoAtraso"));

				lista.add(tmp);
			}
			rs.close();

			ConexionDB.devuelveConexion(con);

		} catch (SQLException sqlE) {
			try {
				log.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
			throw sqlE;
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}

		return lista;
	}

	/**
	 * 
	 * @param bean
	 * @return
	 * @deprecated
	 */
	public static boolean insertaNotificacion(BeanNotificaciones bean) {
		Connection con = null;
		Statement st = null;
		String insert = "INSERT INTO ImportacionesNotificaciones ( numeroOrden, posicion, fecha, cantidad, documentos, contenedor, "
				+ "estado, diaSeguimiento, diaDeCaptura,  esCI,numOrdenSecundaria, tipoConf, sar, eta, adelantoAtraso ) VALUES ( '"
				+ bean.getNumeroOrden().trim() + "'," + bean.getPosicion() + "," + bean.getFecha() + ","
				+ bean.getCantidad() + ","
				+ (bean.getDocumentos() != null ? "'" + bean.getDocumentos() + "'," : "null,")
				+ (bean.getContenedor() != null ? "'" + bean.getContenedor() + "'," : "null,")
				+ (bean.isEstado() ? 1 : 0) + "," + bean.getDiaSeguimiento() + ","
				+ (bean.isEstado() ? (bean.isEstado() ? Utilerias.gregorianCalendar2int(new GregorianCalendar())
						: bean.getDiaDeCaptura()) : null)
				+ "," + (bean.getEsCI() != null ? (bean.getEsCI() ? 1 : 0) : "null") + ","
				+ (bean.getNumOrdenSecundaria() != null ? "'" + bean.getNumOrdenSecundaria() + "'," : "null,")
				+ (bean.getTipoConf() != null ? "'" + bean.getTipoConf() + "'," : "null,")
				+ (bean.getSar() != null ? "'" + bean.getSar() + "'," : " null,") + bean.getEta() + ","
				+ (bean.getAdelantoAtraso() != null ? "'" + bean.getAdelantoAtraso() + "'" : "null") + " )";

		boolean exito = false;

		try {
			con = ConexionDB.dameConexion();
			st = con.createStatement();
			exito = st.executeUpdate(insert) == 1;

			ConexionDB.devuelveConexion(con);

		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} catch (Exception e) {
			e.printStackTrace();
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
		return exito;
	}

	public static void actualizaFolioEnBD(SarBO sar) {
		Connection con = null;
		Statement st = null;
		String update = "UPDATE cdiSAR SET tipoContenedor = " + sar.getTipoContenedor() + " WHERE folio = "
				+ sar.getFolio();

		try {
			con = ConexionDB.dameConexion();
			st = con.createStatement();

			st.executeUpdate(update);

			ConexionDB.devuelveConexion(con);

		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} catch (Exception e) {
			e.printStackTrace();
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
	}

	/**
	 * 
	 * @param bean
	 * @return
	 * @deprecated
	 */
	public static boolean updateNotificaciones(BeanNotificaciones bean) {
		Connection con = null;
		Statement st = null;
		String update = "UPDATE ImportacionesNotificaciones SET diaDeCaptura = "
				+ (bean.isEstado() ? Utilerias.gregorianCalendar2int(new GregorianCalendar()) : bean.getDiaDeCaptura())
				+ ",estado=" + (bean.isEstado() ? 1 : 0) + " "
				+ (bean.getSar() != null ? " ,sar = '" + bean.getSar() + "'" : "") + " "
				+ (bean.getContenedor() != null ? " ,contenedor = '" + bean.getContenedor() + "'" : "")
				+ " WHERE numeroOrden = " + bean.getNumeroOrden().trim() + " and posicion = " + bean.getPosicion()
				+ " and cantidad = " + bean.getCantidad()
				+ " and id = (select max(id)  from importacionesNotificaciones b where b.numeroorden = "
				+ bean.getNumeroOrden().trim() + " and b.posicion = " + bean.getPosicion() + " and cantidad = "
				+ bean.getCantidad() + " )";

		boolean exito = false;

		try {
			con = ConexionDB.dameConexion();
			st = con.createStatement();

			exito = (st.executeUpdate(update) > 0);

			ConexionDB.devuelveConexion(con);

		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} catch (Exception e) {
			e.printStackTrace();
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}

		return exito;
	}

	public int selectLastDetail(int folio) throws SQLException, ClassNotFoundException {

		Connection con = null;
		int result = 0;
		try {
			con = ConexionDB.dameConexion();

			ResultSet rs = null;
			Statement st = null;
			StringBuffer query = new StringBuffer();

			query.append("SELECT max(posicion ) ");
			query.append(" FROM   cdiSARDetalle ");
			query.append(" WHERE   folio = " + folio);

			st = con.createStatement();

			rs = st.executeQuery(query.toString());

			while (rs.next()) {
				result = rs.getInt(1);
			}
			rs.close();
			st.close();
			ConexionDB.devuelveConexion(con);

		} catch (SQLException sqlE) {
			try {
				log.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
			throw sqlE;
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}

		return result;
	}

	public static boolean insertaDetalleSinPO(SarDetalleBO detalle) {
		Connection con = null;
		Statement st = null;
		String insert = "INSERT INTO cdiSARDetalle (folio,material,po, posicion, cantidad, pesoProveedor, volumenProveedor) VALUES ("
				+ detalle.getFolio() + ", " + detalle.getMaterial() + ",''," + detalle.getPosicion() + ", "
				+ detalle.getCantidad() + "," + detalle.getPesoProveedor() + ", " + detalle.getVolumenProveedor() + ")";

		boolean exito = false;

		try {
			con = ConexionDB.dameConexion();
			st = con.createStatement();
			exito = st.executeUpdate(insert) == 1;

			ConexionDB.devuelveConexion(con);

		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} catch (Exception e) {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}

		return exito;
	}

	public static boolean esAprobadoPorShipping(int folio) {
		Connection con = null;
		Statement st = null;
		ResultSet rs = null;
		int status = 0;

		try {
			con = ConexionDB.dameConexion();
			st = con.createStatement();
			String select = "SELECT status FROM cdiSAR WHERE folio = " + folio;
			rs = st.executeQuery(select);

			while (rs.next()) {
				status = rs.getInt("status");
				break;
			}

			ConexionDB.devuelveConexion(con);

		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} catch (Exception e) {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}

		return status == SarBO.STATUS_APROBADO;
	}

	public static void cargaPoliticaPenalizacionProveedores(boolean recarga) {
		if (Proveedores.diasPenalizacionProveedores == null || recarga) {
			HashMap<String, Integer> temp = new HashMap<String, Integer>();

			Connection con = null;
			Statement st = null;
			ResultSet rs = null;

			try {
				con = ConexionDB.dameConexion();
				st = con.createStatement();
				String select = "SELECT proveedor, diasParaEmbarque FROM cdiPoliticaPenalizacionEmbarque";
				rs = st.executeQuery(select);

				while (rs.next()) {
					String prov = rs.getString("proveedor").trim();
					int dias = rs.getInt("diasParaEmbarque");

					temp.put(prov, dias);
				}

				ConexionDB.devuelveConexion(con);

				Proveedores.diasPenalizacionProveedores = temp;

			} catch (SQLException e) {
				try {
					ConexionDB.renuevaConexion(con);
				} catch (Exception ex) {
					log.error(ex.getMessage(), ex);
				}
				log.error(e.getMessage(), e);
			} catch (Exception e) {
				try {
					ConexionDB.devuelveConexion(con);
				} catch (Exception ex) {
					log.error(ex.getMessage(), ex);
				}
				log.error(e.getMessage(), e);
			} finally {
				try {
					ConexionDB.devuelveConexion(con);
				} catch (Exception sqlEx2) {
					log.error(sqlEx2.getMessage(), sqlEx2);
				}
			}
		}
	}

	public static boolean actualizaDetallePais(int folio, String po, String posicion, int pais) {
		Connection con = null;
		PreparedStatement pst = null;

		if (pais == -1) {
			return false;
		}

		String update = "UPDATE cdiSARDetalle SET paisOrigen = ? WHERE folio = " + folio;

		if (posicion != null) {
			update += " AND posicion = " + posicion;
		}
		if (po != null) {
			po = po.trim();
			update += " AND po = " + po;
		}

		boolean exito = false;

		try {
			con = ConexionDB.dameConexion();
			pst = con.prepareStatement(update);

			pst.setInt(1, pais);

			exito = pst.executeUpdate() >= 1;

			ConexionDB.devuelveConexion(con);

		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} catch (Exception e) {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}

		return exito;
	}

	/**
	 * Este metodo lo estoy remplazando por una llamada a un WS a TEL
	 * 
	 * @return
	 * @deprecated
	 */
	public static HashMap<String, String> dameTiposMoneda() {

		HashMap<String, String> temp = new HashMap<String, String>();

		Connection con = null;
		Statement st = null;
		ResultSet rs = null;

		try {
			con = ConexionDB.dameConexion();
			st = con.createStatement();
			String select = "select DISTINCT(moneda) as moneda from importacionesdetalleorden"
					+ " where moneda is not null " + " and moneda <> ''";
			rs = st.executeQuery(select);

			while (rs.next()) {
				String moneda = rs.getString("moneda").trim();
				temp.put(moneda, moneda);
			}
		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} catch (Exception e) {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
		return temp;
	}

	/**
	 * Metodo que me ayuda a listar todos los documentos CDI que se encuentran en
	 * las tablas
	 * 
	 * @param bean
	 * @return
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 */
	public static ArrayList<CdiDocumentBO> selectDocumentosFact(CdiDocumentBO bean)
			throws SQLException, ClassNotFoundException {

		ArrayList<CdiDocumentBO> lista = new ArrayList<CdiDocumentBO>();

		Connection con = null;

		try {
			con = ConexionDB.dameConexion();

			ResultSet rs = null;
			StringBuffer query = new StringBuffer();
			Statement st = null;

			query.append("SELECT  sar, numero, fecha, esGenerado, pos, tipo, packagesAmpara,nombreUser,");
			query.append("embarcaMadera, observaciones, representanteLegal, version,ruta,nombrearch,fechacreacion,");
			query.append("aprobadoSDI,prioridad,userUpdate,dateUpdate,comentarioRechazo,usuarioRechazo, ");
			query.append(" fechaRechazo, fechaRechazoLong ");
			query.append(" FROM   cdiDocumentos ");
			query.append(" WHERE   sar =  " + bean.getSar());
			query.append(" ORDER BY version desc");

			st = con.createStatement();
			rs = st.executeQuery(query.toString());

			while (rs.next()) {
				CdiDocumentBO result = new CdiDocumentBO();
				result.setEmbarcaMadera(rs.getBoolean("embarcaMadera"));
				result.setEsGenerado(rs.getBoolean("esGenerado"));
				result.setFecha(rs.getInt("fecha"));
				result.setNumero(rs.getString("numero"));
				result.setObservaciones(rs.getString("observaciones"));
				result.setPackagesAmpara(rs.getDouble("packagesAmpara"));
				result.setPos(rs.getString("pos"));
				result.setRepresentanteLegal(rs.getString("representanteLegal"));
				result.setSar(rs.getInt("sar"));
				result.setTipo(rs.getString("tipo"));
				result.setVersion(rs.getDouble("version"));
				result.setRuta(rs.getString("ruta"));
				result.setNombreArch(rs.getString("nombrearch"));
				result.setFechaCreacion(rs.getInt("fechacreacion"));
				result.setNombreUsuario(rs.getString("nombreUser"));
				result.setAprobadoSDI(rs.getBoolean("aprobadoSDI"));
				if (rs.wasNull()) {
					result.setAprobadoSDI(null);
				}
				result.setPrioridad(rs.getInt("prioridad"));
				result.setUsuarioUpdate(rs.getString("userUpdate"));
				result.setFechaUpdate(rs.getInt("dateUpdate"));

				result.setComentarioRechazo(rs.getString("comentarioRechazo"));
				result.setUsuarioRechazo(rs.getString("usuarioRechazo"));
				result.setFechaRechazo(rs.getInt("fechaRechazo"));
				result.setFechaRechazoLong(rs.getDouble("fechaRechazoLong"));

				lista.add(new CdiDocumentBO(result));
			}
			rs.close();
			ConexionDB.devuelveConexion(con);

		} catch (SQLException sqlE) {
			try {
				log.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
			throw sqlE;
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}

		return lista;
	}

	public static ArrayList<CDIDatosFacturaBean> selectDatosCDI(CDIDatosFacturaBean bean)
			throws SQLException, ClassNotFoundException {

		ArrayList<CDIDatosFacturaBean> lista = new ArrayList<CDIDatosFacturaBean>();

		Connection con = null;

		try {
			con = ConexionDB.dameConexion();

			ResultSet rs = null;
			StringBuffer query = new StringBuffer();
			Statement st = null;

			query.append(
					"SELECT  sar, numero,po,  tipo, item, code, descripcion, cantidad, unidadMedida, pu, monto,cartones,");
			query.append(" cantidadXcarton,pesoneto,pesobruto,cubicaje,pallet,cartonxpallet");
			query.append(" FROM   cdiDatosFactura ");
			query.append(" WHERE   sar =  " + bean.getSar());
			query.append(" AND     numero =  '" + bean.getNumero() + "'");
			query.append(" AND     tipo =  '" + bean.getTipo() + "'");

			st = con.createStatement();
			rs = st.executeQuery(query.toString());

			while (rs.next()) {
				CDIDatosFacturaBean result = new CDIDatosFacturaBean();

				result.setSar(rs.getInt("sar"));
				result.setNumero(rs.getString("numero"));
				result.setTipo(rs.getString("tipo"));
				result.setItem(rs.getString("item"));
				result.setCode(rs.getString("code"));
				result.setDescripcion(rs.getString("descripcion"));
				result.setUnidadMedida(rs.getString("unidadMedida"));
				result.setPu(rs.getDouble("pu"));
				result.setCantidad(rs.getInt("cantidad"));
				result.setMonto(rs.getDouble("monto"));
				result.setPo(rs.getString("po"));

				result.setCartones(rs.getInt("cartones"));
				result.setCantidadXCarton(rs.getInt("cantidadXcarton"));
				result.setPesoNetoPKL(rs.getBigDecimal("pesoneto"));
				result.setPesoBrutoPKL(rs.getBigDecimal("pesobruto"));
				result.setCubicajePKL(rs.getBigDecimal("cubicaje"));
				result.setPallet(rs.getInt("pallet"));
				result.setCartonXPallet(rs.getInt("cartonxpallet"));

				lista.add(result);
			}
			rs.close();
			ConexionDB.devuelveConexion(con);

		} catch (SQLException sqlE) {
			try {
				log.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
			throw sqlE;
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}

		return lista;
	}

	/**
	 * @deprecated
	 * @param doc
	 * @return
	 */
	public static boolean updateDocumentosCDI(CdiDocumentBO doc) {
		Connection con = null;
		Statement st = null;
		String insert = "UPDATE  cdiDocumentos SET ruta='" + doc.getRuta() + "',nombreArch='" + doc.getNombreArch()
				+ "' ";

		insert += " WHERE sar=" + doc.getSar() + " and numero='" + doc.getNumero() + "' and  version="
				+ doc.getVersion();

		boolean exito = false;

		try {
			con = ConexionDB.dameConexion();
			st = con.createStatement();
			exito = st.executeUpdate(insert) == 1;

			ConexionDB.devuelveConexion(con);

		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} catch (Exception e) {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}

		return exito;
	}

	/**
	 * Nuevo metodo para generar la acutalizacion de esta tabla, aun no esta
	 * terminado, se tiene que validar que todos los campos esten dentro del update.
	 * 
	 * @param doc
	 * @return
	 */
	public static boolean updateDimamicoDocumentosCDI(CdiDocumentBO doc) {
		Connection con = null;
		Statement st = null;
		StringBuffer insert = new StringBuffer();

		insert.append("UPDATE  cdiDocumentos SET ");
		insert.append(" sar = ").append(doc.getSar());// Linea para no validar la coma

		if (doc.getFechaUpdate() != null) {
			insert.append(" ,dateUpdate = ").append(doc.getFechaUpdate());
		}
		if (doc.getUsuarioUpdate() != null) {
			insert.append(" ,userUpdate = ").append("'").append(doc.getUsuarioUpdate()).append("'");
		}
		if (doc.esAprobadoSDI() != null) {
			insert.append(" ,aprobadoSDI = ").append(doc.esAprobadoSDI() ? 1 : 0);
		}
		if (doc.getPrioridad() != null) {
			insert.append(" ,prioridad = ").append(doc.getPrioridad());
		}
		if (doc.getComentarioRechazo() != null) {
			insert.append(" ,comentarioRechazo = '").append(doc.getComentarioRechazo()).append("'");
		}
		if (doc.getUsuarioRechazo() != null) {
			insert.append(" ,usuarioRechazo = '").append(doc.getUsuarioRechazo()).append("'");
		}
		if (doc.getFechaRechazo() != null) {
			insert.append(" ,fechaRechazo = ").append(doc.getFechaRechazo());
		}
		if (doc.getFechaRechazoLong() != null) {
			insert.append(" ,fechaRechazoLong = ").append(doc.getFechaRechazoLong());
		}

		insert.append(" WHERE sar = ").append(doc.getSar());
		insert.append(" and numero = ").append("'").append(doc.getNumero()).append("'");
		insert.append(" and version = ").append(doc.getVersion());

		boolean exito = false;

		try {
			con = ConexionDB.dameConexion();
			st = con.createStatement();
			exito = st.executeUpdate(insert.toString()) == 1;

			ConexionDB.devuelveConexion(con);

		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} catch (Exception e) {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}

		return exito;
	}

	public static boolean insertaDocumentosCDI(CdiDocumentBO doc) throws ServletException {
		Connection con = null;
		Statement st = null;
		String insert = "INSERT INTO cdiDocumentos ( ";

		if (doc.getSar() != null) {
			insert += "sar ";
		}
		if (doc.getNumero() != null) {
			insert += ",numero";
		}
		if (doc.getFecha() != null) {
			insert += ",fecha";
		}
		if (doc.getEsGenerado() != null) {
			insert += ",esGenerado";
		}
		if (doc.getPos() != null) {
			insert += ",pos";
		}
		if (doc.getTipo() != null) {
			insert += ",tipo";
		}
		if (doc.getPackagesAmpara() != null) {
			insert += ",packagesAmpara";
		}
		if (doc.getEmbarcaMadera() != null) {
			insert += ",embarcaMadera";
		}
		if (doc.getObservaciones() != null) {
			insert += ",observaciones";
		}
		if (doc.getRepresentanteLegal() != null) {
			insert += ",representanteLegal";
		}
		if (doc.getVersion() != null) {
			insert += ",version";
		}
		if (doc.getRuta() != null) {
			insert += ",ruta";
		}
		if (doc.getNombreArch() != null) {
			insert += ",nombreArch";
		}
		if (doc.getNombreUsuario() != null) {
			insert += ",nombreUser";
		}
		if (doc.getFechaCreacion() != null) {
			insert += ",fechaCreacion";
		}

		insert += ") VALUES ( ";

		if (doc.getSar() != null) {
			insert += doc.getSar();
		}
		if (doc.getNumero() != null) {
			insert += ",'" + doc.getNumero() + "'";
		}
		if (doc.getFecha() != null) {
			insert += "," + doc.getFecha();
		}
		if (doc.getEsGenerado() != null) {
			if (doc.getEsGenerado()) {
				insert += ",1";
			} else {
				insert += ",0";
			}
		}
		if (doc.getPos() != null) {
			insert += ",'" + doc.getPos() + "'";
		}
		if (doc.getTipo() != null) {
			insert += ",'" + doc.getTipo() + "'";
		}
		if (doc.getPackagesAmpara() != null) {
			insert += "," + doc.getPackagesAmpara();
		}
		if (doc.getEmbarcaMadera() != null) {
			if (doc.getEmbarcaMadera()) {
				insert += ",1";
			} else {
				insert += ",0";
			}
		}
		if (doc.getObservaciones() != null) {
			insert += ",'" + doc.getObservaciones() + "'";
		}
		if (doc.getRepresentanteLegal() != null) {
			insert += ",'" + doc.getRepresentanteLegal() + "'";
		}
		if (doc.getVersion() != null) {
			insert += "," + doc.getVersion();
		}
		if (doc.getRuta() != null) {
			insert += ",'" + doc.getRuta() + "'";
		}
		if (doc.getNombreArch() != null) {
			insert += ",'" + doc.getNombreArch() + "'";
		}
		if (doc.getNombreUsuario() != null) {
			insert += ",'" + doc.getNombreUsuario() + "'";
		}
		if (doc.getFechaCreacion() != null) {
			insert += "," + doc.getFechaCreacion();
		}
		insert += ") ";

		boolean exito = false;

		try {
			con = ConexionDB.dameConexion();
			st = con.createStatement();
			exito = st.executeUpdate(insert) == 1;

			ConexionDB.devuelveConexion(con);
			log.info("Se agrega documento sar:" + doc.getSar() + " SQL:::" + insert);
		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
				throw new ServletException(ex);
			}
			log.error(e.getMessage(), e);
		} catch (Exception e) {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.info("[insertaDocumentosCDI] Error al tratar de insertar un documento para el SQL:" + insert + "--> "
					+ e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}

		return exito;
	}

	public static boolean insertaDatosCDI(CDIDatosFacturaBean fact) {
		Connection con = null;
		Statement st = null;
		String insert = "INSERT INTO cdiDatosFactura ( ";
		if (fact.getSar() != null) {
			insert += "sar ";
		}
		if (fact.getNumero() != null) {
			insert += ",numero";
		}
		if (fact.getPo() != null) {
			insert += ",po";
		}
		if (fact.getTipo() != null) {
			insert += ",tipo";
		}
		if (fact.getItem() != null) {
			insert += ",item";
		}
		if (fact.getCode() != null) {
			insert += ",code";
		}
		if (fact.getDescripcion() != null) {
			insert += ",descripcion";
		}
		if (fact.getUnidadMedida() != null) {
			insert += ",unidadMedida";
		}
		if (fact.getCantidad() != null) {
			insert += ",cantidad";
		}
		if (fact.getPu() != null) {
			insert += ",pu";
		}
		if (fact.getMonto() != null) {
			insert += ",monto";
		}

		if (fact.getCartones() != null) {
			insert += ",cartones";
		}
		if (fact.getCantidadXCarton() != null) {
			insert += ",cantidadXcarton";
		}
		if (fact.getPesoNetoPKL() != null) {
			insert += ",pesoNeto";
		}
		if (fact.getPesoBrutoPKL() != null) {
			insert += ",pesoBruto";
		}
		if (fact.getCubicajePKL() != null) {
			insert += ",cubicaje";
		}
		if (fact.getPallet() != null) {
			insert += ",pallet";
		}
		if (fact.getCartonXPallet() != null) {
			insert += ",cartonXpallet";
		}

		insert += ") VALUES ( ";

		if (fact.getSar() != null) {
			insert += fact.getSar();
		}
		if (fact.getNumero() != null) {
			insert += "," + "'" + fact.getNumero() + "'";
		}
		if (fact.getPo() != null) {
			insert += ",'" + fact.getPo() + "'";
		}
		if (fact.getTipo() != null) {
			insert += ",'" + fact.getTipo() + "'";
		}
		if (fact.getItem() != null) {
			insert += ",'" + fact.getItem() + "'";
		}
		if (fact.getCode() != null) {
			insert += ",'" + fact.getCode() + "'";
		}
		if (fact.getDescripcion() != null) {
			insert += ",'" + fact.getDescripcion() + "'";
		}
		if (fact.getUnidadMedida() != null) {
			insert += ",'" + fact.getUnidadMedida() + "'";
		}
		if (fact.getCantidad() != null) {
			insert += "," + fact.getCantidad();
		}
		if (fact.getPu() != null) {
			insert += ",'" + fact.getPu() + "'";
		}
		if (fact.getMonto() != null) {
			insert += "," + fact.getMonto();
		}

		if (fact.getCartones() != null) {
			insert += "," + fact.getCartones();
		}
		if (fact.getCantidadXCarton() != null) {
			insert += "," + fact.getCantidadXCarton();
		}
		if (fact.getPesoNetoPKL() != null) {
			insert += "," + fact.getPesoNetoPKL();
		}
		if (fact.getPesoBrutoPKL() != null) {
			insert += "," + fact.getPesoBrutoPKL();
		}
		if (fact.getCubicajePKL() != null) {
			insert += "," + fact.getCubicajePKL();
		}
		if (fact.getPallet() != null) {
			insert += "," + fact.getPallet();
		}
		if (fact.getCartonXPallet() != null) {
			insert += "," + fact.getCartonXPallet();
		}

		insert += ") ";

		boolean exito = false;

		try {
			con = ConexionDB.dameConexion();
			st = con.createStatement();
			exito = st.executeUpdate(insert) == 1;

			ConexionDB.devuelveConexion(con);

		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} catch (Exception e) {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}

		return exito;
	}

	/**
	 * metodo que voy utilizar solo para actualizar el detalle de a que documento
	 * factura esta relacionado este detalle
	 * 
	 * @param po
	 * @param pos
	 * @param folio
	 * @param doc
	 * @return
	 */
	public static boolean updateSarDetalle(String po, int pos, String folio, String doc) {
		Connection con = null;
		Statement st = null;
		String update = "UPDATE cdiSARDetalle SET noDocumento = " + (doc == null ? "NULL" : ("'" + doc + "'"))
				+ " WHERE folio = " + folio + " AND po = '" + po + "' " + " AND posicion = " + pos;
		boolean exito = false;

		try {
			con = ConexionDB.dameConexion();
			st = con.createStatement();

			exito = (st.executeUpdate(update) > 0);

			ConexionDB.devuelveConexion(con);

		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error("Error al tratar de actualizar una linea de detalle con el SQL: " + update + " error-->"
					+ e.getMessage(), e);
		} catch (Exception e) {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}

		return exito;
	}

	/**
	 * Metodo que voy a utilizar para actualizar los datos del packing list pero al
	 * ser dinamico se puede utilizar para actualizar cualquier campo de la tabla
	 * solo tenemos que ir ingresando cada columna
	 * 
	 * @param detalle
	 * @return
	 * @throws ServletException
	 */
	public static boolean updateSarDetalleDinamico(SarDetalleBO detalle) throws ServletException {
		Connection con = null;
		Statement st = null;
		String update = "UPDATE cdiSARDetalle SET ";

		if (detalle.getCartones() != null) {
			update += " cartones = " + detalle.getCartones() + ",";
		}
		if (detalle.getCantidadXCarton() != null) {
			update += " cantidadXCarton = " + detalle.getCantidadXCarton() + ",";
		}
		if (detalle.getPesoNetoPKL() != null) {
			update += " pesoNeto = " + detalle.getPesoNetoPKL() + ",";
		}
		if (detalle.getPesoBrutoPKL() != null) {
			update += " PesoBruto =" + detalle.getPesoBrutoPKL() + ",";
		}
		if (detalle.getCubicajePKL() != null) {
			update += " cubicaje = " + detalle.getCubicajePKL() + ",";
		}
		if (detalle.getPallet() != null) {
			update += " pallet = " + detalle.getPallet() + ",";
		}
		if (detalle.getCartonXPallet() != null) {
			update += " cartonXPallet = " + detalle.getCartonXPallet() + ",";
		}
		if (detalle.getStatusMRP() != null) {
			update += " statusMRP = " + detalle.getStatusMRP() + ",";
		}
		if (detalle.getTipoValidacionMRP() != null) {
			update += " tipoValidacionMRP = " + detalle.getTipoValidacionMRP() + ",";
		}
		// //quito la ultima coma para que funcione todo ok
		update = update.substring(0, update.length() - 1);

		update += " WHERE folio = " + detalle.getFolio();
		update += " AND po = '" + detalle.getPo() + "' ";
		update += " AND posicion = " + detalle.getPosicion();
		boolean exito = false;

		try {
			con = ConexionDB.dameConexion();
			st = con.createStatement();

			exito = (st.executeUpdate(update) > 0);

			ConexionDB.devuelveConexion(con);

		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
			throw new ServletException(e);
		} catch (Exception e) {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}

		return exito;
	}

	public static boolean cacelaSAR(SarBO beanSAR, UserBean usuario, String vista) {
		Connection con = null;
		Statement st = null;
		boolean exito = false;

		StringBuffer queryInsert = new StringBuffer();

		queryInsert.append("INSERT INTO cdiSARDetalleRechazados (");
		queryInsert.append("folio, po, posicion, material, centro, cantidad, pesoProveedor, ");
		queryInsert.append("volumenProveedor, precioUnitario, planeador, cantidadModificada, pesoModificado,");
		queryInsert.append("volumenModificado, cliente, unidadMedida, condicionPago, moneda, fechaProforma, ");
		queryInsert.append("paisOrigen, noDocumento, cartones, cantidadXCarton, pesoNeto, PesoBruto,");
		queryInsert.append("cubicaje, pallet, cartonXPallet, esPedidoDirecto, tieneDiferenciaMRP, statusMRP, ");
		queryInsert.append("almacen)");
		queryInsert.append(" SELECT ");
		queryInsert.append("folio, po, posicion, material, centro, cantidad, pesoProveedor, ");
		queryInsert.append("volumenProveedor, precioUnitario, planeador, cantidadModificada, pesoModificado,");
		queryInsert.append("volumenModificado, cliente, unidadMedida, condicionPago, moneda, fechaProforma, ");
		queryInsert.append("paisOrigen, noDocumento, cartones, cantidadXCarton, pesoNeto, PesoBruto,");
		queryInsert.append("cubicaje, pallet, cartonXPallet, esPedidoDirecto, tieneDiferenciaMRP, statusMRP, ");
		queryInsert.append("almacen ");
		queryInsert.append(" FROM cdiSARDetalle WHERE folio = ");
		queryInsert.append(beanSAR.getFolio());

		try {
			SAR_CDI_DAO dao = new SAR_CDI_DAO();

			if (beanSAR.getDetalleBO() == null || beanSAR.getDetalleBO().size() == 0) {
				if (dao.updateFolio(beanSAR, usuario)) {
					exito = true;
					log.error("[Se cambia status a cancelado sin detalle] OK!! SAR:: " + beanSAR.getFolio()
							+ ", en la vista de " + vista + ".");
				} else {
					exito = false;
					log.error("[Se cambia status a cancelado sin detalle] Error!! SAR:: " + beanSAR.getFolio()
							+ ", en la vista de " + vista + ".");
				}
			} else {
				con = ConexionDB.dameConexion();
				st = con.createStatement();
				int res = st.executeUpdate(queryInsert.toString());
				queryInsert = new StringBuffer();
				if (res > 0) {

					if (dao.updateFolio(beanSAR, usuario)) {
						try {
							queryInsert.append("DELETE FROM cdiSARDetalle WHERE folio = ");
							queryInsert.append(beanSAR.getFolio());
							exito = st.executeUpdate(queryInsert.toString()) > 0;
							log.info("Borrando Detalles {}" ,beanSAR.getFolio());
						}catch(Exception e) {
							log.error("Error Borrando Detalles {}" ,e);}
						/////// Se borra detalle de Detalle en revision
						try {
							queryInsert = new StringBuffer();
							queryInsert.append("DELETE FROM cdiSARDetalleEnRevision WHERE folio = ");
							queryInsert.append(beanSAR.getFolio());
							st.executeUpdate(queryInsert.toString());
							log.info("Borrando DetallesEnRevision {}" ,beanSAR.getFolio());
						}catch(Exception e) {
							log.error("Error Borrando DetallesEnRevision {}" ,e);}
						try {
							/////// Se borra registro de Detalle en revision
							queryInsert = new StringBuffer();
							queryInsert.append("DELETE FROM cdiSAREnRevision WHERE folio = ");
							queryInsert.append(beanSAR.getFolio());
							log.info("Borrando SarEnRevision {}" ,beanSAR.getFolio());
							st.executeUpdate(queryInsert.toString());
						}catch(Exception e) {
							log.error("Error Borrando SarEnRevision {}" ,e);}
					}else {
						log.info("Problemas al modificar a cancelado :: " + beanSAR.getFolio() + ", en la vista de "
								+ vista + ".");
					}
				}

				ConexionDB.devuelveConexion(con);
				log.info("[Borrando Detalle por cancelacion] OK!! SAR:: " + beanSAR.getFolio() + ", en la vista de "
						+ vista + ".");
			}

		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				log.error("[Borrando Detalle por cancelacion] Error SAR:: " + beanSAR.getFolio() + ", en la vista de "
						+ vista + ". causa: " + ex.getMessage(), ex);
			}
			log.error("[Borrando Detalle por cancelacion] Error SAR:: " + beanSAR.getFolio() + ", en la vista de "
					+ vista + ". causa: " + e.getMessage(), e);
		} catch (Exception e) {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error("[Borrando Detalle por cancelacion] Error SAR:: " + beanSAR.getFolio() + ", en la vista de "
						+ vista + ". causa: " + ex.getMessage(), ex);
			}
			log.error("[Borrando Detalle por cancelacion] Error SAR:: " + beanSAR.getFolio() + ", en la vista de "
					+ vista + ". causa: " + e.getMessage(), e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}

		return exito;
	}

	public static boolean aceptaSARConDiferencias(String folio) {
		Connection con = null;
		Statement st = null;
		String update = "UPDATE cdiSAR SET aceptadoConDiferencias = 1 WHERE folio = " + folio;
		boolean exito = false;

		try {
			con = ConexionDB.dameConexion();
			st = con.createStatement();

			exito = (st.executeUpdate(update) > 0);

			ConexionDB.devuelveConexion(con);

		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} catch (Exception e) {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}

		return exito;
	}

	public static boolean insertaSARModificado(SARModificado sar) throws ServletException {
		Connection con = null;
		Statement st = null;
		String insert = "INSERT INTO cdiSarModificado (folio, etdReal, etdModificada)" + " VALUES (" + sar.getFolio()
				+ ", '" + sar.getEtd() + "', " + sar.getEtdModificada() + ")";

		boolean exito = false;

		try {
			con = ConexionDB.dameConexion();
			st = con.createStatement();
			exito = st.executeUpdate(insert) == 1;
			ConexionDB.devuelveConexion(con);

		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} catch (Exception e) {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
			throw new ServletException(e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}

		return exito;
	}

	public static boolean updateSARModificado(SARModificado sar) throws ServletException {
		Connection con = null;
		PreparedStatement pst = null;
		StringBuffer insert = new StringBuffer();
		boolean exito = false;
		try {

			insert.append("UPDATE  cdiSarModificado SET ");

			if (sar.getEtd() != null) {
				insert.append(" etdReal = ?,");
			}
			if (sar.getEtdModificada() != null) {
				insert.append(" etdModificada = ?,");
			}
			// quito la ultima coma
			insert = insert.delete(insert.length() - 1, insert.length());

			insert.append(" WHERE  ");
			insert.append(" folio = ?");

			int cont = 1;
			con = ConexionDB.dameConexion();

			pst = con.prepareStatement(insert.toString());

			if (sar.getEtd() != null) {
				agregarPs(cont++, pst, sar.getEtd(), Integer.class);
			}
			if (sar.getEtdModificada() != null) {
				agregarPs(cont++, pst, sar.getEtdModificada(), Integer.class);
			}

			agregarPs(cont++, pst, sar.getFolio(), Integer.class);

			int resultado = pst.executeUpdate();
			exito = resultado > 0;
			pst.close();

			ConexionDB.devuelveConexion(con);

		} catch (Exception e) {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
			throw new ServletException(e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}

		return exito;
	}

	public static SARModificado selectSARModificado(SARModificado sar) {

		SARModificado temp = null;

		Connection con = null;
		Statement st = null;
		ResultSet rs = null;

		try {
			con = ConexionDB.dameConexion();
			st = con.createStatement();
			String select = "SELECT folio, etdReal, etdModificada";
			select += " FROM cdisarmodificado ";
			select += " WHERE folio = " + sar.getFolio();

			rs = st.executeQuery(select);

			while (rs.next()) {
				temp = new SARModificado();
				temp.setFolio(rs.getInt("folio"));
				temp.setEtd(rs.getInt("etdReal"));
				temp.setEtdModificada(rs.getInt("etdModificada"));
			}

			ConexionDB.devuelveConexion(con);

		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} catch (Exception e) {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
		return temp;
	}

	/**
	 * Metodo que me ayuda a insertar un registro en la tabla de detalleModificado.
	 * Solo me importa la llave y los valores viejos y nuevos
	 * 
	 * @param detalle
	 * @return
	 * @throws ServletException
	 */
	public static boolean insertaDetalleModificado(SARDetalleModificado detalle) throws ServletException {
		Connection con = null;
		Statement st = null;
		String insert = "INSERT INTO cdiSarDetalleModificado (folio, po, posicion, material, cantidad, pesoProveedor, volumenProveedor,cantidadModificada, pesoModificado, "
				+ "volumenModificado) VALUES (" + detalle.getFolio() + ", '" + detalle.getPo() + "', "
				+ detalle.getPosicion() + ", " + detalle.getMaterial() + ", " + detalle.getCantidad() + ","
				+ detalle.getPesoProveedor() + ", " + detalle.getVolumenProveedor() + ", '"
				+ detalle.getCantidadModificada() + "', " + detalle.getPesoModificado() + ","
				+ detalle.getVolumenModificado() + ")";

		boolean exito = false;

		try {
			con = ConexionDB.dameConexion();
			st = con.createStatement();
			exito = st.executeUpdate(insert) == 1;
			ConexionDB.devuelveConexion(con);

		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} catch (Exception e) {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
			throw new ServletException(e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}

		return exito;
	}

	/**
	 * Metodo que me ayuda a actualizar un detalle modificado
	 * 
	 * @param det
	 * @return
	 * @throws ServletException
	 */
	public static boolean updateDetalleModificado(SARDetalleModificado det) throws ServletException {
		Connection con = null;
		PreparedStatement pst = null;
		StringBuffer insert = new StringBuffer();
		boolean exito = false;
		try {

			insert.append("UPDATE  cdiSarDetalleModificado SET ");

			if (det.getCantidad() != null) {
				insert.append(" cantidad = ?,");
			}
			if (det.getPesoProveedor() != null) {
				insert.append(" pesoProveedor = ?,");
			}
			if (det.getVolumenProveedor() != null) {
				insert.append(" volumenProveedor = ?,");
			}
			if (det.getCantidadModificada() != null) {
				insert.append(" cantidadModificada = ?,");
			}
			if (det.getPesoModificado() != null) {
				insert.append(" pesoModificado = ?,");
			}
			if (det.getVolumenModificado() != null) {
				insert.append(" volumenModificado = ?,");
			}
			// quito la ultima coma
			insert = insert.delete(insert.length() - 1, insert.length());

			insert.append(" WHERE  ");

			insert.append(" folio = ?");
			insert.append(" AND po = ?");
			insert.append(" AND posicion = ?");

			int cont = 1;
			con = ConexionDB.dameConexion();

			pst = con.prepareStatement(insert.toString());

			if (det.getCantidad() != null) {
				agregarPs(cont++, pst, det.getCantidad(), Integer.class);
			}
			if (det.getPesoProveedor() != null) {
				agregarPs(cont++, pst, new BigDecimal(det.getPesoProveedor()).setScale(2, BigDecimal.ROUND_UP),
						BigDecimal.class);
			}
			if (det.getVolumenProveedor() != null) {
				agregarPs(cont++, pst, new BigDecimal(det.getVolumenProveedor()).setScale(2, BigDecimal.ROUND_UP),
						BigDecimal.class);
			}
			if (det.getCantidadModificada() != null) {
				agregarPs(cont++, pst, det.getCantidadModificada(), Integer.class);
			}
			if (det.getPesoModificado() != null) {
				agregarPs(cont++, pst, new BigDecimal(det.getPesoModificado()).setScale(2, BigDecimal.ROUND_UP),
						BigDecimal.class);
			}
			if (det.getVolumenModificado() != null) {
				agregarPs(cont++, pst, new BigDecimal(det.getVolumenModificado()).setScale(2, BigDecimal.ROUND_UP),
						BigDecimal.class);
			}

			agregarPs(cont++, pst, det.getFolio(), Integer.class);
			agregarPs(cont++, pst, det.getPo(), String.class);
			agregarPs(cont++, pst, det.getPosicion(), Integer.class);

			int resultado = pst.executeUpdate();
			exito = resultado > 0;
			pst.close();

			ConexionDB.devuelveConexion(con);

		} catch (Exception e) {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
			throw new ServletException(e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}

		return exito;
	}

	public static SARDetalleModificado selectDetalleModificado(SARDetalleModificado det) {

		SARDetalleModificado temp = null;

		Connection con = null;
		Statement st = null;
		ResultSet rs = null;

		try {
			con = ConexionDB.dameConexion();
			st = con.createStatement();
			String select = "SELECT folio, po,posicion,material,cantidad,pesoProveedor,volumenProveedor,";
			select += " cantidadModificada,pesoModificado,volumenModificado ";
			select += " FROM cdisardetallemodificado ";
			select += " WHERE   folio = " + det.getFolio();
			if (det.getPo() != null) {
				select += " AND po = " + det.getPo();
			}
			if (det.getPosicion() != null) {
				select += " AND   posicion = " + det.getPosicion();
			}

			rs = st.executeQuery(select);

			while (rs.next()) {
				temp = new SARDetalleModificado();
				temp.setFolio(rs.getInt("folio"));
				temp.setCantidadModificada(rs.getInt("cantidadModificada"));
				temp.setCantidad(rs.getInt("cantidad"));
				temp.setMaterial(rs.getInt("material"));
				temp.setPesoModificado(rs.getDouble("pesoModificado"));
				temp.setPesoProveedor(rs.getDouble("pesoProveedor"));
				temp.setPo(rs.getString("po"));
				temp.setPosicion(rs.getInt("posicion"));
				temp.setVolumenModificado(rs.getDouble("volumenModificado"));
				temp.setVolumenProveedor(rs.getDouble("volumenProveedor"));

			}
		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} catch (Exception e) {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
		return temp;
	}

	public static List<SARDetalleModificado> selectDetalleEliminados(int folio) {

		List<SARDetalleModificado> lstDetMod = new ArrayList<SARDetalleModificado>();

		Connection con = null;
		Statement st = null;
		ResultSet rs = null;

		try {
			con = ConexionDB.dameConexion();
			st = con.createStatement();
			String select = "select detM.folio, detM.po, detM.posicion,"
					+ " detM.material, detM.cantidad, detM.cantidadModificada,"
					+ " detM.pesoProveedor, detM.pesoModificado," + " detM.volumenProveedor, detM.volumenModificado"
					+ " from cdiSarDetalleModificado detM" + " left join cdiSARDetalle det on detM.folio = det.folio"
					+ " and detM.po = det.po and detM.posicion = det.posicion"
					+ " where det.folio is NULL and det.po is null and det.posicion is null" + " and detM.folio = "
					+ folio;

			rs = st.executeQuery(select);

			while (rs.next()) {
				SARDetalleModificado temp = new SARDetalleModificado();
				temp.setFolio(rs.getInt("folio"));
				temp.setCantidadModificada(rs.getInt("cantidadModificada"));
				temp.setCantidad(rs.getInt("cantidad"));
				temp.setMaterial(rs.getInt("material"));
				temp.setPesoModificado(rs.getDouble("pesoModificado"));
				temp.setPesoProveedor(rs.getDouble("pesoProveedor"));
				temp.setPo(rs.getString("po"));
				temp.setPosicion(rs.getInt("posicion"));
				temp.setVolumenModificado(rs.getDouble("volumenModificado"));
				temp.setVolumenProveedor(rs.getDouble("volumenProveedor"));
				lstDetMod.add(temp);
			}

			ConexionDB.devuelveConexion(con);

		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} catch (Exception e) {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
		return lstDetMod;
	}

	public static SarDetalleBO selectSarDetallePorLLave(SarDetalleBO bean) throws SQLException, ClassNotFoundException {
		Connection con = null;
		SarDetalleBO tmpSAR = null;
		try {
			con = ConexionDB.dameConexion();

			ResultSet rs = null;
			PreparedStatement pst = null;
			pst = con.prepareStatement(SELECT_SAR_DETALLE_POR_LLAVE);

			pst.setInt(1, bean.getFolio());
			pst.setString(2, bean.getPo());
			pst.setInt(3, bean.getPosicion());

			rs = pst.executeQuery();

			while (rs.next()) {

				tmpSAR = new SarDetalleBO();
				tmpSAR.setPo(rs.getString("po"));
				tmpSAR.setPosicion(rs.getInt("posicion"));
				tmpSAR.setMaterial(rs.getInt("material"));
				tmpSAR.setCantidad(rs.getInt("cantidad"));
				tmpSAR.setPesoProveedor(rs.getDouble("pesoProveedor"));
				tmpSAR.setVolumenProveedor(rs.getDouble("volumenProveedor"));
				tmpSAR.setFolio(rs.getInt("folio"));
				tmpSAR.setCentro(rs.getString("centro"));
				tmpSAR.setPlaneador(rs.getString("planeador"));

				tmpSAR.setNumeroDoc(rs.getString("noDocumento"));
				if (rs.wasNull()) {
					tmpSAR.setNumeroDoc(null);
				}

				tmpSAR.setCantidadModificada(rs.getInt("cantidadModificada"));
				if (rs.wasNull()) {
					tmpSAR.setCantidadModificada(null);
				}
				tmpSAR.setPesoModificado(rs.getDouble("pesoModificado"));
				if (rs.wasNull()) {
					tmpSAR.setPesoModificado(null);
				}
				tmpSAR.setVolumenModificado(rs.getDouble("volumenModificado"));
				if (rs.wasNull()) {
					tmpSAR.setVolumenModificado(null);
				}
				tmpSAR.setCliente(rs.getString("cliente"));
				tmpSAR.setPaisOrigen(rs.getInt("paisOrigen"));
				if (rs.wasNull()) {
					tmpSAR.setPaisOrigen(null);
				}

				tmpSAR.setUnidaMedida(rs.getString("unidadMedida"));
				tmpSAR.setCondicionPago(rs.getString("condicionPago"));
				tmpSAR.setStatusMRP(rs.getInt("statusMRP"));
				if (rs.wasNull()) {
					tmpSAR.setStatusMRP(null);
				}
				tmpSAR.setTipoValidacionMRP(rs.getInt("tipoValidacionMRP"));
				
				tmpSAR.setCantidadUnidadMedida(rs.getBigDecimal("cantidadUnidadMedida"));
				tmpSAR.setFactorCantidadUnidadMedida(rs.getBigDecimal("factorCantidadUnidadMedida"));
			}
			rs.close();
			pst.close();
			ConexionDB.devuelveConexion(con);

		} catch (SQLException sqlE) {
			try {
				log.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
			throw sqlE;
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}

		return tmpSAR;
	}

	public static SarDetalleBO selectSarDetalleRechazadosPorLLave(SarDetalleBO bean)
			throws SQLException, ClassNotFoundException {
		Connection con = null;
		SarDetalleBO tmpSAR = null;
		try {
			con = ConexionDB.dameConexion();

			ResultSet rs = null;
			PreparedStatement pst = null;
			StringBuffer query = new StringBuffer();

			query.append("SELECT folio, po, posicion , material , cantidad , pesoProveedor , ");
			query.append("volumenProveedor , centro,planeador,cantidadModificada,");
			query.append("pesoModificado,volumenModificado,cliente,paisOrigen,noDocumento,");
			query.append(" condicionPago,unidadMedida, statusMRP, tipoValidacionMRP ");
			query.append(" FROM   cdiSARDetalleRechazados ");
			query.append(" WHERE   folio = ? ");
			query.append(" AND     po = ?  ");
			query.append(" AND     posicion = ? ");

			pst = con.prepareStatement(query.toString());

			pst.setInt(1, bean.getFolio());
			pst.setString(2, bean.getPo());
			pst.setInt(3, bean.getPosicion());

			rs = pst.executeQuery();

			while (rs.next()) {

				tmpSAR = new SarDetalleBO();
				tmpSAR.setPo(rs.getString("po"));
				tmpSAR.setPosicion(rs.getInt("posicion"));
				tmpSAR.setMaterial(rs.getInt("material"));
				tmpSAR.setCantidad(rs.getInt("cantidad"));
				tmpSAR.setPesoProveedor(rs.getDouble("pesoProveedor"));
				tmpSAR.setVolumenProveedor(rs.getDouble("volumenProveedor"));
				tmpSAR.setFolio(rs.getInt("folio"));
				tmpSAR.setCentro(rs.getString("centro"));
				tmpSAR.setPlaneador(rs.getString("planeador"));

				tmpSAR.setNumeroDoc(rs.getString("noDocumento"));
				if (rs.wasNull()) {
					tmpSAR.setNumeroDoc(null);
				}

				tmpSAR.setCantidadModificada(rs.getInt("cantidadModificada"));
				if (rs.wasNull()) {
					tmpSAR.setCantidadModificada(null);
				}
				tmpSAR.setPesoModificado(rs.getDouble("pesoModificado"));
				if (rs.wasNull()) {
					tmpSAR.setPesoModificado(null);
				}
				tmpSAR.setVolumenModificado(rs.getDouble("volumenModificado"));
				if (rs.wasNull()) {
					tmpSAR.setVolumenModificado(null);
				}
				tmpSAR.setCliente(rs.getString("cliente"));
				tmpSAR.setPaisOrigen(rs.getInt("paisOrigen"));
				if (rs.wasNull()) {
					tmpSAR.setPaisOrigen(null);
				}

				tmpSAR.setUnidaMedida(rs.getString("unidadMedida"));
				tmpSAR.setCondicionPago(rs.getString("condicionPago"));
				tmpSAR.setStatusMRP(rs.getInt("statusMRP"));
				if (rs.wasNull()) {
					tmpSAR.setStatusMRP(null);
				}
				tmpSAR.setTipoValidacionMRP(rs.getInt("tipoValidacionMRP"));
			}
			rs.close();
			pst.close();
			ConexionDB.devuelveConexion(con);

		} catch (SQLException sqlE) {
			try {
				log.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
			throw sqlE;
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}

		return tmpSAR;
	}

	/**
	 * Metodo que actualiza los campos para marcar que varios sar estan englobados
	 * en un solo set de archivos o documentos para lo que es SDI
	 * 
	 * @param base
	 * @param folios
	 * @return
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 */
	public static boolean updateSARMultiple(SarBO base, Integer[] folios) throws SQLException, ClassNotFoundException {

		Connection con = null;
		boolean result = false;
		if (folios == null) {
			return false;
		}

		try {
			con = ConexionDB.dameConexion();

			PreparedStatement pst = null;
			StringBuffer query = new StringBuffer();

			query.append(" update cdiSAR ");
			query.append(" set ");

			if (base.esMultiple() != null) {
				query.append(" esmultiple = ?,");
			}
			if (base.getMandante() != null) {
				query.append(" mandante = ?");
			}

			query.append(" where folio  in (  ");

			boolean flag = true;
			for (int i = 0; i < folios.length; i++) {
				if (flag) {
					flag = false;
				} else {
					query.append(",");
				}
				query.append("?");
			}

			query.append(" )  ");

			pst = con.prepareStatement(query.toString());

			int cont = 1;

			if (base.esMultiple() != null) {
				agregarPs(cont++, pst, base.esMultiple(), Boolean.class);
			}
			if (base.getMandante() != null) {
				agregarPs(cont++, pst, base.getMandante(), Integer.class);
			}

			for (int i = 0; i < folios.length; i++) {
				agregarPs(cont++, pst, folios[i], Integer.class);
			}

			result = pst.executeUpdate() > 0;

			pst.close();

			ConexionDB.devuelveConexion(con);

		} catch (SQLException sqlE) {
			try {
				con.rollback();
				log.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
			throw sqlE;
		} catch (IOException ioE) {
			try {
				con.rollback();
				log.error(ioE.getMessage(), ioE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception ioE2) {
				log.error(ioE2.getMessage(), ioE2);
			}
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}

		return result;
	}

	@Override
	public List<?> select(Object o) {
		return null;
	}

	@Override
	public boolean insert(Object o) {
		return false;
	}

	@Override
	public boolean update(Object o) {
		return false;
	}

	public static void cambiaEstado(int folioSar, int codigoEstado) throws SQLException, ClassNotFoundException {
		String s = "";
		if (SarBO.STATUS_DOCUMENTOS_SDI == codigoEstado) {
			GregorianCalendar gc = new GregorianCalendar();
			long fecTimeStamp = gc.getTimeInMillis() / 1000;
			int fecFormatoTruper = FuncionesComunesPLI.gregorianCalendar2int(gc);
			s = "update cdiSar set status = ?,cerradoDocumentosProveedor = 1, fecIniSDI=" + fecTimeStamp
					+ ", tinyFecIniSDI=" + fecFormatoTruper + " where folio = ? ";
		} else {
			s = "update cdiSar set status = ?,cerradoDocumentosProveedor = 1  where folio = ? ";
		}
		Connection c = null;
		try {
			c = ConexionDB.dameConexion();
			PreparedStatement ps = c.prepareStatement(s);
			ps.setInt(1, codigoEstado);
			ps.setInt(2, folioSar);
			ps.execute();
			ConexionDB.devuelveConexion(c);
		} catch (SQLException sqlE) {
			try {
				c.rollback();
				log.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(c);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
			throw sqlE;
		} finally {
			try {
				ConexionDB.devuelveConexion(c);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}

	}

	public static void guardaFechaAceptacionProveedor(int folioSar, int fechaFormatoTruper)
			throws SQLException, ClassNotFoundException {
		String s = "update cdiSar set fechaCierreDocumentosProveedor = ? where folio = ? ";
		Connection c = null;
		try {
			c = ConexionDB.dameConexion();
			PreparedStatement ps = c.prepareStatement(s);
			ps.setInt(1, fechaFormatoTruper);
			ps.setInt(2, folioSar);
			ps.execute();
			ConexionDB.devuelveConexion(c);
		} catch (SQLException sqlE) {
			try {
				c.rollback();
				log.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(c);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
			throw sqlE;
		} finally {
			try {
				ConexionDB.devuelveConexion(c);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
	}

	public static void guardaFechaAceptacionDocumentos(int folioSar, int fechaFormatoTruper)
			throws SQLException, ClassNotFoundException {
		String s = "update cdiSar set fechaAprobadoSDI = ? where folio = ? ";
		Connection c = null;
		try {
			c = ConexionDB.dameConexion();
			PreparedStatement ps = c.prepareStatement(s);
			ps.setInt(1, fechaFormatoTruper);
			ps.setInt(2, folioSar);
			ps.execute();
			ConexionDB.devuelveConexion(c);
		} catch (SQLException sqlE) {
			try {
				c.rollback();
				log.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(c);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
			throw sqlE;
		} finally {
			try {
				ConexionDB.devuelveConexion(c);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
	}

	public static void updateFechaEta(int folioSar, int fechaFormatoTruper)
			throws SQLException, ClassNotFoundException {
		String s = "update cdiSar set eta = ? where folio = ? ";
		Connection c = null;
		try {
			c = ConexionDB.dameConexion();
			PreparedStatement ps = c.prepareStatement(s);
			ps.setInt(1, fechaFormatoTruper);
			ps.setInt(2, folioSar);
			ps.execute();
			ConexionDB.devuelveConexion(c);
		} catch (SQLException sqlE) {
			try {
				c.rollback();
				log.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(c);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
			throw sqlE;
		} finally {
			try {
				ConexionDB.devuelveConexion(c);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
	}

	public static void updateFechaEtaConsol(int folioSar, int fechaFormatoTruper)
			throws SQLException, ClassNotFoundException {
		String s = "update cdiSarConsolidados set eta = ? where folio = ? ";
		Connection c = null;
		try {
			c = ConexionDB.dameConexion();
			PreparedStatement ps = c.prepareStatement(s);
			ps.setInt(1, fechaFormatoTruper);
			ps.setInt(2, folioSar);
			ps.execute();
			String s2 = "update cdiSar set eta = ? where folioConsolidado = ? ";
			PreparedStatement ps2 = c.prepareStatement(s2);
			ps2.setInt(1, fechaFormatoTruper);
			ps2.setInt(2, folioSar);
			ps2.execute();
			ConexionDB.devuelveConexion(c);
		} catch (SQLException sqlE) {
			try {
				c.rollback();
				log.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(c);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
			throw sqlE;
		} finally {
			try {
				ConexionDB.devuelveConexion(c);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
	}

	public boolean updateFechaEtd(int folioSar, int fechaFormatoTruper, UserBean usuario)
			throws SQLException, ClassNotFoundException {
		
		boolean etdActualizado = false;
		SarBO sar = new SarBO();
		sar.setFolio(folioSar);
		sar.setEtdReal(fechaFormatoTruper);

		int etdFinal = 0;
		String select = "select etdFinal from cdiSar where folio = ?";
		Connection c = null;
		try {
			c = ConexionDB.dameConexion();
			PreparedStatement ps = c.prepareStatement(select);
			ps.setInt(1, folioSar);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				etdFinal = rs.getInt("etdFinal");
			}
			StringBuffer s = new StringBuffer();
			s.append("update cdiSar set");
			if (etdFinal > 0) {
				s.append(" etdFinal = ?");
			} else {
				s.append(" fechaEmbarque = ?");
			}
			s.append(" where folio = ? ");
			ps = c.prepareStatement(s.toString());
			ps.setInt(1, fechaFormatoTruper);
			ps.setInt(2, folioSar);
			etdActualizado = ps.executeUpdate() > 0 ? true : false;
			ConexionDB.devuelveConexion(c);

		} catch (SQLException sqlE) {
			try {
				c.rollback();
				log.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(c);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
			throw sqlE;
		} finally {
			try {
				ConexionDB.devuelveConexion(c);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
		return etdActualizado;
	}

	public static void updateFechaEtdConsol(int folioSar, int fechaFormatoTruper, UserBean usuario)
			throws SQLException, ClassNotFoundException {
		SARConsolidados sarConsol = new SarConsolBO();
		sarConsol.setFolio(folioSar);
		sarConsol.setEtdReal(fechaFormatoTruper);

		int etdFinal = 0;
		String select = "select etdFinal from cdiSarConsolidados where folio = ?";
		Connection c = null;
		try {
			c = ConexionDB.dameConexion();
			c.setAutoCommit(false);
			PreparedStatement ps = c.prepareStatement(select);
			ps.setInt(1, folioSar);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				etdFinal = rs.getInt("etdFinal");
			}
			rs.close();
			ps.close();

			StringBuffer s = new StringBuffer();
			s.append("update cdiSarConsolidados set");
			if (etdFinal > 0) {
				s.append(" etdFinal = ?");
			} else {
				s.append(" fechaEmbarque = ?");
			}
			s.append(" where folio = ? ");
			ps = c.prepareStatement(s.toString());
			ps.setInt(1, fechaFormatoTruper);
			ps.setInt(2, folioSar);
			ps.execute();

			rs.close();
			ps.close();

			StringBuffer s2 = new StringBuffer();
			s2.append("update cdiSar set");
			if (etdFinal > 0) {
				s.append(" etdFinal = ?");
			} else {
				s.append(" fechaEmbarque = ?");
			}
			s2.append(" where folioConsolidado = ? ");
			ps = c.prepareStatement(s2.toString());
			ps.setInt(1, fechaFormatoTruper);
			ps.setInt(2, folioSar);
			ps.execute();

			rs.close();
			ps.close();

			ConexionDB.devuelveConexion(c);

			

		} catch (SQLException sqlE) {
			try {
				c.rollback();
				log.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(c);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
			throw sqlE;
		} finally {
			try {
				ConexionDB.devuelveConexion(c);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
	}

	public static void updateTipoTransporte(int folio, int tipoTransporte) throws SQLException, ClassNotFoundException {
		String s = "update cdiSar set transporte = ? where folio = ? ";
		Connection c = null;
		try {
			c = ConexionDB.dameConexion();
			PreparedStatement ps = c.prepareStatement(s);
			ps.setInt(1, tipoTransporte);
			ps.setInt(2, folio);
			ps.execute();
			ConexionDB.devuelveConexion(c);
		} catch (SQLException sqlE) {
			try {
				c.rollback();
				log.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(c);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
			throw sqlE;
		} finally {
			try {
				ConexionDB.devuelveConexion(c);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
	}

	public static void updateTipoTransporteConsol(int folio, int tipoTransporte)
			throws SQLException, ClassNotFoundException {
		String s = "update cdiSarConsolidados set transporte = ? where folio = ? ";
		Connection c = null;
		try {
			c = ConexionDB.dameConexion();
			PreparedStatement ps = c.prepareStatement(s);
			ps.setInt(1, tipoTransporte);
			ps.setInt(2, folio);
			ps.execute();
			String s2 = "update cdiSar set transporte = ? where folioConsolidado = ? ";
			PreparedStatement ps2 = c.prepareStatement(s2);
			ps2.setInt(1, tipoTransporte);
			ps2.setInt(2, folio);
			ps2.execute();
			ConexionDB.devuelveConexion(c);
		} catch (SQLException sqlE) {
			try {
				c.rollback();
				log.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(c);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
			throw sqlE;
		} finally {
			try {
				ConexionDB.devuelveConexion(c);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
	}

	/**
	 * Metodo que me trae la referencia de SAR con sus ultimas versiones de
	 * documentos y separo por validados y por validar, Agrego al mapa el nombre
	 * "condicionesPago" aqui voy a mandar las condiciones de pago de los detalles.
	 * 
	 * Nota: Aqui lo que importa es que llene el objeto SAR con el folio, no que
	 * tenga los 3 documentos Por que puede cambiar dependiendo el queryque tenga o
	 * no todos los documentos
	 * 
	 * @param validados
	 * @return
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	public static HashMap<String, Object> dameFoliosConDocumentos(boolean validados, String condicionPago,
			String factura) throws ServletException, ClassNotFoundException {
		HashMap<String, Object> mapa = new HashMap<String, Object>();
		HashSet<String> condiciones = new HashSet<String>();
		Connection con = null;
		try {
			String s = " select max(t1.version) as version, t1.sar,t1.tipo, ";
			s += " t2.status,t2.aprobadoSDI, t3.folio, t3.condicionPago, t2.folioconsolidado ";
			s += " from cdidocumentos t1, cdisar t2, cdisardetalle t3 ";
			s += " where t1.sar = t2.folio ";
			s += " and t3.folio = t2.folio ";
			s += " and t2.status = " + SarBO.STATUS_DOCUMENTOS_SDI;
			if (validados) {
				s += " and t2.aprobadoSDI = 1 ";
			} else {
				s += " and ( t2.aprobadoSDI is null or t2.aprobadoSDI = 0) ";
			}

			if (condicionPago != null && !"".equals(condicionPago)) {
				s += " and t3.condicionPago = '" + condicionPago.trim() + "' ";
			}

			if (factura != null && !"".equals(factura)) {
				s += " and t1.numero like '%" + factura.trim() + "%' ";
			}
			s += " group by t1.sar,t1.tipo,t2.status,t2.aprobadoSDI,t3.folio,t3.condicionPago,t2.folioconsolidado ";

			Statement st = null;
			ResultSet rs = null;
			con = ConexionDB.dameConexion();
			st = con.createStatement();
			rs = st.executeQuery(s);
			String cond = "";
			SarBO sarTmp = null;
			while (rs.next()) {

				cond = rs.getString("condicionPago");
				if (cond != null && !"".equals(cond)) {
					condiciones.add(cond);
				}
				int folio = rs.getInt("sar");
				if (folio != 0) {
					if (!mapa.containsKey(folio)) {
						sarTmp = new SarBO();
						sarTmp.setFolio(folio);
						sarTmp.setFolioConsolidado(rs.getInt("folioconsolidado"));
						if (rs.wasNull()) {
							sarTmp.setFolioConsolidado(null);
						}
						mapa.put(folio + "", sarTmp);
					}
				}
			}
			if (condicionPago == null && factura == null) {
				mapa.put("condicionesPago", condiciones);
			}

			ConexionDB.devuelveConexion(con);
		} catch (SQLException e) {
			log.error(e.getMessage(), e);
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			throw new ServletException(e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
		return mapa;
	}

	/**
	 * @deprecated
	 * @param dto
	 * @return
	 */
	public static Map<String, Object> dameParametrosDeBusqueda(DtoConsultaSar dto) {
		MetaSqlQuery meta = new MetaSqlQuery();
		StringBuilder sb = new StringBuilder();
		Map<String, Object> mapaRespuesta = new HashMap<String, Object>();
		if (dto.conFiltrosDeConsulta()) {
			boolean addAnd = true;
			int index = 1;
			sb.append(" where 1=1 ");
			if (dto.getFolio() != null && !"null".equals(dto.getFolio())) {
				if (addAnd) {
					sb.append("and ");
				}
				sb.append("s.folio = ? ");
				meta.addDataQuery(index++, dto.getFolio());
			}
			if (dto.getPo() != null && !"null".equals(dto.getPo())) {
				if (addAnd) {
					sb.append("and ");
				}
				addAnd = true;
				sb.append("sd.po = ? ");
				meta.addDataQuery(index++, dto.getPo());
			}
			if (dto.getMaterial() != null && !"null".equals(dto.getMaterial())) {
				if (addAnd) {
					sb.append("and ");
				}
				addAnd = true;
				sb.append("sd.material = ? ");
				meta.addDataQuery(index++, dto.getMaterial());
			}
			if (dto.getStatus() != null && !"null".equals(dto.getStatus())) {
				if (addAnd) {
					sb.append("and ");
				}
				addAnd = true;
				sb.append("s.status = ? ");
				meta.addDataQuery(index++, dto.getStatus());
			}
			if (dto.getPuertoOrigen() != null && !"null".equals(dto.getPuertoOrigen())
					&& !"0".equals(dto.getPuertoOrigen())) {
				if (addAnd) {
					sb.append("and ");
				}
				addAnd = true;
				sb.append("s.puertoSalida = ? ");
				meta.addDataQuery(index++, dto.getPuertoOrigen());
			}
			if (dto.getPuertoDestino() != null && !"null".equals(dto.getPuertoDestino())
					&& !"0".equals(dto.getPuertoDestino())) {
				if (addAnd) {
					sb.append("and ");
				}
				addAnd = true;
				sb.append("s.puertoDescarga = ? ");
				meta.addDataQuery(index++, dto.getPuertoDestino());
			}
			if (dto.getNaviera() != null && !"null".equals(dto.getNaviera()) && !"0".equals(dto.getNaviera())) {
				if (addAnd) {
					sb.append("and ");
				}
				addAnd = true;
				sb.append("s.naviera = ? ");
				meta.addDataQuery(index++, dto.getNaviera());
			}
			if (dto.getBarco() != null && !"null".equals(dto.getBarco())) {
				if (addAnd) {
					sb.append("and ");
				}
				addAnd = true;
				sb.append("s.barcoSugerido = ? ");
				meta.addDataQuery(index++, dto.getBarco());
			}
			if (dto.getEta1() != null && !"null".equals(dto.getEta1())) {
				Integer fechaFormato = FuncionesComunesPLI.formateaFechaSeparador(dto.getEta1());
				if (addAnd) {
					sb.append("and ");
				}
				addAnd = true;
				sb.append("s.eta >= ? ");
				meta.addDataQuery(index++, fechaFormato);
			}
			if (dto.getEta2() != null && !"null".equals(dto.getEta2())) {
				Integer fechaFormato = FuncionesComunesPLI.formateaFechaSeparador(dto.getEta2());
				if (addAnd) {
					sb.append("and ");
				}
				addAnd = true;
				sb.append("s.eta <= ? ");
				meta.addDataQuery(index++, fechaFormato);
			}
			if (dto.getEtd1() != null && !"null".equals(dto.getEtd1())) {
				Integer fechaFormato = FuncionesComunesPLI.formateaFechaSeparador(dto.getEtd1());
				if (addAnd) {
					sb.append("and ");
				}
				addAnd = true;
				sb.append("s.etdFinal >= ? ");
				meta.addDataQuery(index++, fechaFormato);
			}
			if (dto.getEtd2() != null && !"null".equals(dto.getEtd2())) {
				Integer fechaFormato = FuncionesComunesPLI.formateaFechaSeparador(dto.getEtd2());
				if (addAnd) {
					sb.append("and ");
				}
				addAnd = true;
				sb.append("s.etdFinal <= ? ");
				meta.addDataQuery(index++, fechaFormato);
			}

			if (dto.getFechaCreacion1() != null && !"null".equals(dto.getFechaCreacion1())) {
				Integer fechaFormato = FuncionesComunesPLI.formateaFechaSeparador(dto.getFechaCreacion1());
				if (addAnd) {
					sb.append("and ");
				}
				addAnd = true;
				sb.append("s.fechaCreacion >= ? ");
				meta.addDataQuery(index++, fechaFormato);
			}
			if (dto.getFechaCreacion2() != null && !"null".equals(dto.getFechaCreacion2())) {
				Integer fechaFormato = FuncionesComunesPLI.formateaFechaSeparador(dto.getFechaCreacion2());
				if (addAnd) {
					sb.append("and ");
				}
				addAnd = true;
				sb.append("s.fechaCreacion <= ? ");
				meta.addDataQuery(index++, fechaFormato);
			}

			if (dto.getPrioridad() != null && !"null".equals(dto.getPrioridad()) && !"0".equals(dto.getPrioridad())) {
				if (addAnd) {
					sb.append("and ");
				}
				addAnd = true;
				sb.append("s.prioridad = ? ");
				meta.addDataQuery(index++, dto.getPrioridad());
			}
			if (dto.getBookingSeach() != null && !"null".equals(dto.getBookingSeach())) {
				if (addAnd) {
					sb.append("and ");
				}
				addAnd = true;
				sb.append("s.booking = ? ");
				meta.addDataQuery(index++, dto.getBookingSeach());
			}
			if (dto.getContenedorSeach() != null && !"null".equals(dto.getContenedorSeach())) {
				if (addAnd) {
					sb.append("and ");
				}
				addAnd = true;
				sb.append("s.contenedor = ? ");
				meta.addDataQuery(index++, dto.getContenedorSeach());
			}
			if (dto.getViajeSeach() != null && !"null".equals(dto.getEtd2())) {
				if (addAnd) {
					sb.append("and ");
				}
				addAnd = true;
				sb.append("s.viaje = ? ");
				meta.addDataQuery(index++, dto.getViajeSeach());
			}
			if (dto.getProveedorSeach() != null && !"null".equals(dto.getProveedorSeach())) {
				if (addAnd) {
					sb.append("and ");
				}
				addAnd = true;
				sb.append("s.proveedor = ?  ");
				meta.addDataQuery(index++, dto.getProveedorSeach());
			}
		}
		mapaRespuesta.put("meta", meta);
		mapaRespuesta.put("parametros", sb);
		return mapaRespuesta;
	}

	/**
	 * @deprecated
	 * @param dto
	 * @return
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 */
	public static List<int[]> buscaFoliosValidos(DtoConsultaSar dto) throws SQLException, ClassNotFoundException {
		MetaSqlQuery meta = new MetaSqlQuery();
		StringBuilder sb = new StringBuilder();
		sb.append("select distinct ");
		sb.append("s.folio as folioSar, ");
		sb.append("sc.folio as folioConsolidado ");
		sb.append("from cdiSarDetalle sd ");
		sb.append("right join cdiSar s on s.folio = sd.folio ");
		sb.append("left join cdiSarConsolidados sc on sc.folio = s.folioConsolidado ");
		if (dto.conFiltrosDeConsulta()) {
			boolean filtroSar = (dto.esConsultaAmbos() || dto.esConsultaSar());
			boolean filtroConsol = (dto.esConsultaAmbos() || dto.esConsultaConsol());
			boolean ambos = dto.esConsultaAmbos();
			boolean addAnd = true;
			int index = 1;
			sb.append("where 1=1 ");
			if (dto.getFolio() != null) {
				if (addAnd) {
					sb.append("and ");
				}

				if (filtroSar) {
					if (ambos) {
						sb.append("(");
					}
					sb.append("s.folio = ? ");
					meta.addDataQuery(index++, dto.getFolio());
				}
				if (filtroConsol) {
					if (ambos) {
						sb.append(" or ");
					}
					sb.append("sc.folio = ? ");
					meta.addDataQuery(index++, dto.getFolio());
					if (ambos) {
						sb.append(") ");
					}
				}
			}
			if (dto.getPo() != null) {
				if (addAnd) {
					sb.append("and ");
				}
				addAnd = true;
				sb.append("sd.po = ? ");
				meta.addDataQuery(index++, dto.getPo());
			}
			if (dto.getMaterial() != null) {
				if (addAnd) {
					sb.append("and ");
				}
				addAnd = true;
				sb.append("sd.material = ? ");
				meta.addDataQuery(index++, dto.getMaterial());
			}
			if (dto.getStatus() != null) {
				if (addAnd) {
					sb.append("and ");
				}
				addAnd = true;
				if (filtroSar) {
					if (ambos) {
						sb.append("(");
					}
					sb.append("s.status = ? ");
					meta.addDataQuery(index++, dto.getStatus());
				}
				if (filtroConsol) {
					if (ambos) {
						sb.append(" or ");
					}
					sb.append("sc.status = ? ");
					meta.addDataQuery(index++, dto.getStatus());
					if (ambos) {
						sb.append(") ");
					}
				}
			}
			if (dto.getPuertoOrigen() != null) {
				if (addAnd) {
					sb.append("and ");
				}
				addAnd = true;
				if (filtroSar) {
					if (ambos) {
						sb.append("(");
					}
					sb.append("s.puertoSalida = ? ");
					meta.addDataQuery(index++, dto.getPuertoOrigen());
				}
				if (filtroConsol) {
					if (ambos) {
						sb.append(" or ");
					}

					sb.append("sc.puertoSalida = ? ");
					meta.addDataQuery(index++, dto.getPuertoOrigen());
					if (ambos) {
						sb.append(") ");
					}
				}
			}
			if (dto.getPuertoDestino() != null) {
				if (addAnd) {
					sb.append("and ");
				}
				addAnd = true;
				if (filtroSar) {
					if (ambos) {
						sb.append("(");
					}
					sb.append("s.puertoDescarga = ? ");
					meta.addDataQuery(index++, dto.getPuertoDestino());
				}
				if (filtroConsol) {
					if (ambos) {
						sb.append(" or ");
					}
					sb.append("sc.puertoDescarga = ? ");
					meta.addDataQuery(index++, dto.getPuertoDestino());
					if (ambos) {
						sb.append(") ");
					}
				}
			}
			if (dto.getNaviera() != null) {
				if (addAnd) {
					sb.append("and ");
				}
				addAnd = true;
				if (filtroSar) {
					if (ambos) {
						sb.append("(");
					}
					sb.append("s.naviera = ? ");
					meta.addDataQuery(index++, dto.getNaviera());
				}
				if (filtroConsol) {
					if (ambos) {
						sb.append(" or ");
					}
					sb.append("sc.naviera = ? ");
					meta.addDataQuery(index++, dto.getNaviera());
					if (ambos) {
						sb.append(") ");
					}
				}
			}
			if (dto.getBarco() != null) {
				if (addAnd) {
					sb.append("and ");
				}
				addAnd = true;
				if (filtroSar) {
					if (ambos) {
						sb.append("(");
					}
					sb.append("s.barcoSugerido = ? ");
					meta.addDataQuery(index++, dto.getBarco());
				}
				if (filtroConsol) {
					if (ambos) {
						sb.append(" or ");
					}
					sb.append("sc.barcoSugerido = ? ");
					meta.addDataQuery(index++, dto.getBarco());
					if (ambos) {
						sb.append(") ");
					}
				}
			}
			if (dto.getEta1() != null) {
				Integer fechaFormato = FuncionesComunesPLI.formateaFechaSeparador(dto.getEta1());
				if (addAnd) {
					sb.append("and ");
				}
				addAnd = true;
				if (filtroSar) {
					if (ambos) {
						sb.append("(");
					}
					sb.append("s.eta >= ? ");

					meta.addDataQuery(index++, fechaFormato);
				}
				if (filtroConsol) {
					if (ambos) {
						sb.append(" or ");
					}
					sb.append("sc.eta >= ? ");
					meta.addDataQuery(index++, fechaFormato);
					if (ambos) {
						sb.append(") ");
					}
				}
			}
			if (dto.getEta2() != null) {
				Integer fechaFormato = FuncionesComunesPLI.formateaFechaSeparador(dto.getEta2());
				if (addAnd) {
					sb.append("and ");
				}
				addAnd = true;
				if (filtroSar) {
					if (ambos) {
						sb.append("(");
					}
					sb.append("s.eta <= ? ");
					meta.addDataQuery(index++, fechaFormato);
				}
				if (filtroConsol) {
					if (ambos) {
						sb.append(" or ");
					}
					sb.append("sc.eta <= ? ");
					meta.addDataQuery(index++, fechaFormato);
					if (ambos) {
						sb.append(") ");
					}
				}
			}
			if (dto.getEtd1() != null) {
				Integer fechaFormato = FuncionesComunesPLI.formateaFechaSeparador(dto.getEtd1());
				if (addAnd) {
					sb.append("and ");
				}
				addAnd = true;
				if (filtroSar) {
					if (ambos) {
						sb.append("(");
					}
					sb.append("s.etdFinal >= ? ");

					meta.addDataQuery(index++, fechaFormato);
				}
				if (filtroConsol) {
					if (ambos) {
						sb.append(" or ");
					}
					sb.append("sc.etdFinal >= ? ");
					meta.addDataQuery(index++, fechaFormato);
					if (ambos) {
						sb.append(") ");
					}
				}
			}
			if (dto.getEtd2() != null) {
				Integer fechaFormato = FuncionesComunesPLI.formateaFechaSeparador(dto.getEtd2());
				if (addAnd) {
					sb.append("and ");
				}
				addAnd = true;
				if (filtroSar) {
					if (ambos) {
						sb.append("(");
					}
					sb.append("s.etdFinal <= ? ");
					meta.addDataQuery(index++, fechaFormato);
				}
				if (filtroConsol) {
					if (ambos) {
						sb.append(" or ");
					}
					sb.append("sc.etdFinal <= ? ");
					meta.addDataQuery(index++, fechaFormato);
					if (ambos) {
						sb.append(") ");
					}
				}
			}
			if (dto.getPrioridad() != null) {
				if (addAnd) {
					sb.append("and ");
				}
				addAnd = true;
				if (filtroSar) {
					if (ambos) {
						sb.append("(");
					}
					sb.append("s.prioridad = ? ");
					meta.addDataQuery(index++, dto.getPrioridad());
				}
				if (filtroConsol) {
					if (ambos) {
						sb.append(" or ");
					}
					sb.append("sc.prioridad = ? ");
					meta.addDataQuery(index++, dto.getPrioridad());
					if (ambos) {
						sb.append(") ");
					}
				}
			}
			if (dto.getBookingSeach() != null) {
				if (addAnd) {
					sb.append("and ");
				}
				addAnd = true;
				if (filtroSar) {
					if (ambos) {
						sb.append("(");
					}
					sb.append("s.booking = ? ");
					meta.addDataQuery(index++, dto.getBookingSeach());
				}
				if (filtroConsol) {
					if (ambos) {
						sb.append(" or ");
					}
					sb.append("sc.booking = ? ");
					meta.addDataQuery(index++, dto.getBookingSeach());
					if (ambos) {
						sb.append(") ");
					}
				}
			}
			if (dto.getContenedorSeach() != null) {
				if (addAnd) {
					sb.append("and ");
				}
				addAnd = true;
				if (filtroSar) {
					if (ambos) {
						sb.append("(");
					}
					sb.append("s.contenedor = ? ");
					meta.addDataQuery(index++, dto.getContenedorSeach());
				}
				if (filtroConsol) {
					if (ambos) {
						sb.append(" or ");
					}
					sb.append("sc.contenedor = ? ");
					meta.addDataQuery(index++, dto.getContenedorSeach());
					if (ambos) {
						sb.append(") ");
					}
				}
			}
			if (dto.getViajeSeach() != null) {
				if (addAnd) {
					sb.append("and ");
				}
				addAnd = true;
				if (filtroSar) {
					if (ambos) {
						sb.append("(");
					}
					sb.append("s.viaje = ? ");
					meta.addDataQuery(index++, dto.getViajeSeach());
				}
				if (filtroConsol) {
					if (ambos) {
						sb.append(" or ");
					}
					sb.append("sc.viaje = ? ");
					meta.addDataQuery(index++, dto.getViajeSeach());
					if (ambos) {
						sb.append(") ");
					}
				}
			}
			if (dto.getProveedorSeach() != null) {
				if (addAnd) {
					sb.append("and ");
				}
				addAnd = true;
				if (filtroSar) {
					if (ambos) {
						sb.append("(");
					}
					sb.append("s.proveedor = ? ) ");
					meta.addDataQuery(index++, dto.getProveedorSeach());
				}
			}
		}
		String query = sb.toString();
		Connection c = null;
		List<int[]> listaInt = new ArrayList<int[]>();

		try {
			c = ConexionDB.dameConexion();
			PreparedStatement ps = c.prepareStatement(query);
			meta.addParamsToPreparedStatement(ps);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				int folioSar = rs.getInt(1);
				int folioConsol = rs.getInt(2);
				int[] arreI = { folioSar, folioConsol };
				if (dto.esConsultaConsol() && folioConsol != 0) {
					listaInt.add(arreI);
				} else if (dto.esConsultaSar()) {
					listaInt.add(arreI);
				} else if (dto.esConsultaAmbos()) {
					listaInt.add(arreI);
				}
			}
			ConexionDB.devuelveConexion(c);
		} catch (SQLException sqlE) {
			try {
				log.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(c);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		} finally {
			try {
				ConexionDB.devuelveConexion(c);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
		return listaInt;
	}

	/**
	 * @deprecated
	 * @param dto
	 * @return
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 */
	public static List<SarBO> buscaSARs(DtoConsultaSar dto) throws SQLException, ClassNotFoundException {
		boolean filtroSar = (dto.esConsultaAmbos() || dto.esConsultaSar());
		boolean filtroConsol = (dto.esConsultaAmbos() || dto.esConsultaConsol());
		boolean ambos = dto.esConsultaAmbos();

		Map<String, Object> mapaParametros = dameParametrosDeBusqueda(dto);
		MetaSqlQuery meta = (MetaSqlQuery) mapaParametros.get("meta");
		StringBuilder params = (StringBuilder) mapaParametros.get("parametros");

		StringBuilder sbS = new StringBuilder();
		sbS.append("SELECT distinct s.folio, s.proveedor, s.status, s.fechaEmbarque, ");
		sbS.append("s.puertoSalida, s.naviera, s.tipoContenedor, s.prioridad, ");
		sbS.append("s.puertoDescarga, s.barcoSugerido, s.viaje, s.contenedor, s.folioconsolidado, ");
		sbS.append("s.booking, s.etdFinal, s.transporte, s.fechaCreacion,");
		sbS.append("s.folioConsolidado, s.consolidado, s.esAereo,");
		sbS.append("s.fechaCierreDocumentosProveedor, s.eta, s.revision,");
		sbS.append("s.aprobadoProveedor, s.aprobadoSDI,");
		sbS.append("s.cerradoDocumentosProveedor, s.fechaAprobadoSDI,");
		sbS.append("s.fecIniPlanning, s.tinyFecIniPlanning,");
		sbS.append("s.fecIniShipping, s.tinyFecIniShipping, s.fecIniConsol,");
		sbS.append("s.tinyFecIniConsol, s.fecIniBooking, s.tinyFecIniBooking,");
		sbS.append("s.fecIniSDI, s.tinyFecIniSDI, s.fecIniEmbarque, s.tinyFecIniEmbarque,");
		sbS.append("s.diferenciaMRP, s.cargadoMRP");
		sbS.append(" FROM cdiSAR s left join cdiSarDetalle sd on s.folio = sd.folio");
		sbS.append(params);

		String querySars = sbS.toString();
		Connection c = null;
		List<SarBO> result = new ArrayList<SarBO>();
		List<SarBO> resultA = new ArrayList<SarBO>();
		List<SarBO> resultB = new ArrayList<SarBO>();

		try {
			c = ConexionDB.dameConexion();
			PreparedStatement psSars = c.prepareStatement(querySars);

			StringBuilder sbC = new StringBuilder();
			sbC.append("SELECT distinct s.folio, s.status, s.fechaEmbarque, ");
			sbC.append("s.puertoSalida, s.naviera, s.tipoContenedor, s.prioridad, ");
			sbC.append("s.puertoDescarga, s.barcoSugerido, s.viaje, s.contenedor, ");
			sbC.append("s.booking, s.etdFinal, s.transporte, s.eta, s.fecIniEmbarque, ");
			sbC.append("s.tinyFecIniEmbarque, s.revision");
			sbC.append(" FROM cdiSARConsolidados s left join cdiSarDetalle sd on s.folio = sd.folio");
			sbC.append(params);

			String queryConsol = sbC.toString();
			PreparedStatement psConsols = c.prepareStatement(queryConsol);

			if (filtroSar) {
				if (dto.conFiltrosDeConsulta()) {
					meta.addParamsToPreparedStatement(psSars);
				}
				ResultSet rsS = psSars.executeQuery();
				while (rsS.next()) {
					int etdBooking = rsS.getInt("etdFinal");
					int etd = rsS.getInt("fechaEmbarque");
					if (etdBooking > 0) {
						etd = etdBooking;
					}
					int folioReg = rsS.getInt("folio");
					String proveedor = rsS.getString("proveedor");
					int statusReg = rsS.getInt("status");
					String puertoSalida = rsS.getString("puertoSalida");
					int navieraReg = rsS.getInt("naviera");
					int prioridadReg = rsS.getInt("prioridad");
					String puertoDescarga = rsS.getString("puertoDescarga");
					String barcoReg = rsS.getString("barcoSugerido");
					String viaje = rsS.getString("viaje");
					String contenedor = rsS.getString("contenedor");
					String booking = rsS.getString("booking");
					int transporte = rsS.getInt("transporte");
					int tipoContenedor = rsS.getInt("tipoContenedor");
					int revision = rsS.getInt("revision");
					int fechaCreacion = rsS.getInt("fechaCreacion");
					int folioConsol = rsS.getInt("folioConsolidado");
					boolean esAereo = rsS.getBoolean("esAereo");
					Integer consolidado = rsS.getInt("consolidado");
					if (rsS.wasNull()) {
						consolidado = null;
					}
					Integer folioconsolidado = rsS.getInt("folioconsolidado");
					if (rsS.wasNull()) {
						folioconsolidado = null;
					}
					int eta = rsS.getInt("eta");
					int fechaCierreDocumentosProveedor = rsS.getInt("fechaCierreDocumentosProveedor");
					boolean aprobadoProveedor = rsS.getBoolean("aprobadoProveedor");
					boolean aprobadoSDI = rsS.getBoolean("aprobadoSDI");
					boolean cerradoDocumentosProveedor = rsS.getBoolean("cerradoDocumentosProveedor");
					int fechaAprobadoSDI = rsS.getInt("fechaAprobadoSDI");
					long fecIniPlanning = rsS.getLong("fecIniPlanning");
					int tinyFecIniPlanning = rsS.getInt("tinyFecIniPlanning");
					long fecIniShipping = rsS.getLong("fecIniShipping");
					int tinyFecIniShipping = rsS.getInt("tinyFecIniShipping");
					long fecIniConsol = rsS.getLong("fecIniConsol");
					int tinyFecIniConsol = rsS.getInt("tinyFecIniConsol");
					long fecIniBooking = rsS.getLong("fecIniBooking");
					int tinyFecIniBooking = rsS.getInt("tinyFecIniBooking");
					long fecIniSDI = rsS.getLong("fecIniSDI");
					int tinyFecIniSDI = rsS.getInt("tinyFecIniSDI");
					long fecIniEmbarque = rsS.getLong("fecIniEmbarque");
					int tinyFecIniEmbarque = rsS.getInt("tinyFecIniEmbarque");
					Boolean diferenciaMRP = rsS.getBoolean("diferenciaMRP");
					Boolean cargadoMRP = (Boolean) rsS.getObject("cargadoMRP");
					SarBO sar = new SarBO(folioReg, proveedor, tipoContenedor);
					sar.setStatus(statusReg);
					sar.setPuertoOrigen(puertoSalida);
					sar.setNaviera(navieraReg);
					sar.setPrioridad(prioridadReg);
					sar.setPuertoDescarga(puertoDescarga);
					sar.setBarcoSugerido(barcoReg);
					sar.setViaje(viaje);
					sar.setContenedor(contenedor);
					sar.setBooking(booking);
					sar.setTransporte(transporte);
					sar.setFechaEmbarque(etd);
					sar.setCreationDate(fechaCreacion);
					sar.setFolioConsolidado(folioConsol);
					sar.setEsAereo(esAereo);
					sar.setFechaCierreDocumentosProveedor(fechaCierreDocumentosProveedor);
					sar.setAprobadoProveedor(aprobadoProveedor);
					sar.setAprobadoSDI(aprobadoSDI);
					sar.setCerradoDocumentosProveedor(cerradoDocumentosProveedor);
					sar.setFechaAprobadoSDI(fechaAprobadoSDI);
					sar.setEta(eta);
					sar.setRevision(revision);
					sar.setTipoContenedor(rsS.getInt("tipoContenedor"));
					sar.setFolioConsolidado(folioconsolidado);
					sar.setConsolidado((consolidado != null && consolidado > 0) ? true : false);
					if (statusReg >= SarBO.STATUS_ESPERA_APROBACION_SHIPPING && statusReg != SarBO.STATUS_CANCELADO
							&& statusReg != SarBO.STATUS_RECHAZADO) {
						FuncionesComunesPLI.esCorrectoFull(sar, "/srm_booking");
					}
					sar.setFecIniPlanning(fecIniPlanning);
					sar.setTinyFecIniPlanning(tinyFecIniPlanning);
					sar.setFecIniShipping(fecIniShipping);
					sar.setTinyFecIniShipping(tinyFecIniShipping);
					sar.setFecIniConsolidados(fecIniConsol);
					sar.setTinyFecIniConsolidados(tinyFecIniConsol);
					sar.setFecIniBooking(fecIniBooking);
					sar.setTinyFecIniBooking(tinyFecIniBooking);
					sar.setFecIniSDI(fecIniSDI);
					sar.setTinyFecIniSDI(tinyFecIniSDI);
					sar.setFecIniEmbarque(fecIniEmbarque);
					sar.setTinyFecIniEmbarque(tinyFecIniEmbarque);
					sar.setTieneDiferenciaMRP(diferenciaMRP);
					sar.setCargadoMRP(cargadoMRP);
					resultA.add(sar);
				}
			}
			if (filtroConsol) {
				if (dto.conFiltrosDeConsulta()) {
					meta.addParamsToPreparedStatement(psConsols);
				}
				ResultSet rsC = psConsols.executeQuery();
				while (rsC.next()) {
					int etdBooking = rsC.getInt("etdFinal");
					int etd = rsC.getInt("fechaEmbarque");
					if (etdBooking > 0) {
						etd = etdBooking;
					}
					int folioReg = rsC.getInt("folio");
					int statusReg = rsC.getInt("status");
					String puertoSalida = rsC.getString("puertoSalida");
					int navieraReg = rsC.getInt("naviera");
					int prioridadReg = rsC.getInt("prioridad");
					String puertoDescarga = rsC.getString("puertoDescarga");
					String barcoReg = rsC.getString("barcoSugerido");
					String viaje = rsC.getString("viaje");
					String contenedor = rsC.getString("contenedor");
					String booking = rsC.getString("booking");
					int transporte = rsC.getInt("transporte");
					int tipoContenedor = rsC.getInt("tipoContenedor");
					int eta = rsC.getInt("eta");
					long fecIniEmbarque = rsC.getLong("fecIniEmbarque");
					int tinyFecIniEmbarque = rsC.getInt("tinyFecIniEmbarque");
					SarBO sar = new SarBO();
					sar.setFolio(folioReg);
					sar.setTipoContenedor(tipoContenedor);
					sar.setStatus(statusReg);
					sar.setPuertoOrigen(puertoSalida);
					sar.setNaviera(navieraReg);
					sar.setPrioridad(prioridadReg);
					sar.setPuertoDescarga(puertoDescarga);
					sar.setBarcoSugerido(barcoReg);
					sar.setViaje(viaje);
					sar.setContenedor(contenedor);
					sar.setBooking(booking);
					sar.setTransporte(transporte);
					sar.setFechaEmbarque(etd);
					sar.setConsolidado(true);
					sar.setFolioConsolidado(folioReg);/// cambio este -1 por el numero de consolidado, para distingir
					sar.setEta(eta);
					sar.setFecIniEmbarque(fecIniEmbarque);
					sar.setTinyFecIniEmbarque(tinyFecIniEmbarque);
					if (statusReg >= SarBO.STATUS_ESPERA_APROBACION_SHIPPING && statusReg != SarBO.STATUS_CANCELADO
							&& statusReg != SarBO.STATUS_RECHAZADO) {
						FuncionesComunesPLI.esCorrectoFull(sar, "/srm_booking");
					}
					sar.setRevision(rsC.getInt("revision"));
					if (rsC.wasNull()) {
						sar.setRevision(null);
					}
					resultB.add(sar);
				}
			}
			ConexionDB.devuelveConexion(c);
		} catch (SQLException sqlE) {
			try {
				log.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(c);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		} finally {
			try {
				ConexionDB.devuelveConexion(c);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}

		if (ambos) {
			result.addAll(resultA);
			result.addAll(resultB);
		} else if (filtroSar) {
			result.addAll(resultA);
		} else if (filtroConsol) {
			result.addAll(resultB);
		}
		return result;
	}

	public static List<SarBO> buscaSARs(SearchParamsSARs params) throws SQLException, ClassNotFoundException {
		DAOUtils utils = new DAOUtils();
		List<SarBO> result = new ArrayList<SarBO>();
		Connection con = null;

		try {
			con = ConexionDB.dameConexion();
			ResultSet rs = null;
			PreparedStatement pst = null;
			StringBuilder query = new StringBuilder();
			query.append("SELECT distinct s.folio, s.proveedor, s.status, s.fechaEmbarque, ");
			query.append("s.puertoSalida, s.naviera, s.tipoContenedor, s.prioridad, s.tipoRetraso, ");
			query.append("s.puertoDescarga, s.barcoSugerido, s.viaje, s.contenedor, s.folioconsolidado, ");
			query.append("s.booking, s.BL, s.etdFinal, s.transporte, s.fechaCreacion,");
			query.append("s.folioConsolidado, s.consolidado, s.esAereo,");
			query.append("s.fechaCierreDocumentosProveedor, s.eta, s.revision,");
			query.append("s.aprobadoProveedor, s.aprobadoSDI,");
			query.append("s.cerradoDocumentosProveedor, s.fechaAprobadoSDI,");
			query.append("s.tieneFacturaArch, s.tieneBLArch, s.tienePackingListArch,");
			query.append("s.fecIniPlanning, s.tinyFecIniPlanning,");
			query.append("s.fecIniShipping, s.tinyFecIniShipping, s.fecIniConsol,");
			query.append("s.tinyFecIniConsol, s.fecIniBooking, s.tinyFecIniBooking,");
			query.append("s.fecIniSDI, s.tinyFecIniSDI, s.fecIniEmbarque, s.tinyFecIniEmbarque,");
			query.append("s.needAuthImpDir, s.aprobadoDirImportaciones, s.userApruebaDirImportaciones,");
			query.append("s.fechaApruebaDirImportaciones, s.commentForImpDir,");
			query.append("s.impDirComments, s.adelantoAtrasoETDImpDir,");
			query.append("s.diferenciaMRP, s.cargadoMRP, s.aplicaBitacoraImpDir,");
			query.append(
					"s.bitacoraImpDirCerrada, s.fecCierreBitacoraImpDir, s.numRevFinal,s.versionSetDocumentos,s.enrevisionIDA,");
			query.append("s.bitacoraIDA,s.bitacoraIDACerrada,ida.aceptado,ida.ETDnuevo, ");
			query.append("s.preciosRevisados, s.preciosEnRevision, s.preciosLiberados,s.goods_ready_date,s.goods_are_ready, s.gdrEnRevision, ");
			query.append("f.numero_factura_pm pm, f.procesadosife sife, ");	
			query.append("f.folioSife, CONCAT('19:',f.mensaje_sife_19 , '/ 43:', f.mensaje_sife_43) as statusSIFE , ");			
			query.append("s.referenciaContenedorProveedor, s.aprobadoConfMngr");
			query.append(" FROM cdiSAR s");
			query.append(" LEFT JOIN cdiSarDetalle sd ON s.folio = sd.folio");
			query.append(" LEFT JOIN cdiSarDetalleRechazados sdr ON s.folio = sdr.folio");
			query.append(
					" LEFT JOIN cdiDocumentosSDI docs ON s.versionSetDocumentos = docs.versionSDI and s.booking = docs.booking and s.proveedor = docs.proveedor");
			query.append(" LEFT JOIN CDISAR_IDA_REVISION ida ON ida.folio = s.folio and ida.esCC = s.consolidado ");
			query.append(
					" LEFT JOIN cdiControlSDI c ON s.versionSetDocumentos = c.versionSDI AND s.booking = c.booking AND s.proveedor = c.proveedor ");
			query.append(" LEFT JOIN cdiReferenceNumber r ON s.folio = r.folio ");
			query.append(" LEFT JOIN facturacion f ON f.sar = s.folio and f.numero_factura_pm = (SELECT MAX(numero_factura_pm) from facturacion where sar = s.folio) ");
			query.append(" WHERE 1=1");

			utils.setSelect(true);

			if (params.getCdiTSR() != null) {
				if (params.getCdiTSR().equals("1")) {
					query.append(
							" AND s.folio IN (SELECT folio FROM cdiTsrReport WHERE folio = s.folio AND pendiente = 1) ");
				} else if (params.getCdiTSR().equals("2")) {
					query.append(
							" AND s.folio IN (SELECT folio FROM cdiTsrReport WHERE folio = s.folio AND pendiente = 0) ");
				}
			}

			if (params.getFolio() != null && !"null".equals(params.getFolio())) {
				query.append(utils.ajustaColumna(" AND s.folio = ?"));
			}
			if (params.getPo() != null && !"null".equals(params.getPo())) {
				query.append(utils.ajustaColumna(" AND sd.po = ?"));
			}
			if (params.getMaterial() != null && !"null".equals(params.getMaterial())) {
				query.append(utils.ajustaColumna(" AND sd.material = ?"));
			}
			if (params.getStatusSAR() != null && !"null".equals(params.getStatusSAR())
					&& !"-99".equals(params.getStatusSAR())) {
				switch (Integer.valueOf(params.getStatusSAR())) {
				case 0:
					query.append(" AND s.status = 0");
					break;
				case 1:
					query.append(" AND s.status = 8");
					break;
				case 2:
					query.append(" AND s.status = 1");
					break;
				case 3:
					query.append(" AND s.status = 2  AND (( s.needAuthImpDir = 1 AND s.aprobadoDirImportaciones = 0))");
					break;
				case 4:
					query.append(" AND ((s.status = 2 AND s.needAuthImpDir = 0) OR ");
					query.append(" (s.status = 2 AND s.needAuthImpDir = 1 AND s.aprobadoDirImportaciones = 1))");
					break;
				case 5:
					query.append(" AND s.status = 3 AND (s.folioConsolidado is NULL OR s.folioConsolidado = 0)");
					query.append(" AND s.tipoContenedor = " + SarBO.LCL);
					break;
				case 6:

					query.append(" AND ((ISNULL(consolidado, 0) = 0 AND s.status = 3  ) OR ");
					query.append(" (consolidado = 1 AND s.status = 3 AND s.folioConsolidado is NOT NULL)) ");
					query.append(" AND ISNULL(r.folio, 0) = 0 AND s.booking IS NULL ");

					break;
				case 7:
					query.append(" AND s.status = 3 AND s.booking IS NULL AND r.folio IS NOT NULL ");
					break;
				case 8:
					query.append(" AND s.status = 3 AND s.booking IS NOT NULL ");
					query.append(" AND ISNULL(s.enRevisionConfirmFinal, 0) = 0 ");
					query.append(" AND s.fechaConfirmacionFinal IS NULL ");
					break;
				case 9:
					query.append(" AND s.enRevisionConfirmFinal = 1 ");
					query.append(" AND s.fechaConfirmacionFinal IS NULL ");
					break;
				case 10:
					query.append(" AND s.fechaConfirmacionFinal IS NOT NULL AND s.aprobadoProveedor = 1 ");
					query.append(" AND ISNULL(c.aprobado, 0) = 0 ");
					break;
				case 11:
					query.append(" AND s.status = 9 AND ISNULL(c.aprobado, 0) = 0 ");

					break;
				case 12:
					query.append(" AND s.status = 5 ");
					break;
				case 13:
					query.append(" AND s.status = 9 AND c.aprobado = 1 ");
					break;
				case 14:
					query.append(" AND s.status = 4 ");
					break;
				case 15:
					query.append(" AND s.status = 7 ");
					break;
				default:
					break;
				}
			}
			if (params.getPuertoOrigen() != null && !"-1".equals(params.getPuertoOrigen())) {
				query.append(utils.ajustaColumna(" AND s.puertoSalida = ? "));
			}
			if (params.getPuertoDestino() != null && !"-1".equals(params.getPuertoDestino())) {
				query.append(utils.ajustaColumna(" AND s.puertoDescarga = ? "));
			}
			if (params.getNaviera() != null && params.getNaviera() != -1) {
				query.append(utils.ajustaColumna(" AND s.naviera = ? "));
			}
			if (params.getBarco() != null && !"null".equals(params.getBarco())) {
				query.append(utils.ajustaColumna(" AND s.barcoSugerido = ? "));
			}
			if (params.getEtaFrom() != null && !"null".equals(params.getEtaFrom())) {
				query.append(utils.ajustaColumna(" AND s.eta >= ? "));
			}
			if (params.getEtaTo() != null && !"null".equals(params.getEtaTo())) {
				query.append(utils.ajustaColumna(" AND s.eta <= ? "));
			}
			if (params.getEtdFrom() != null && !"null".equals(params.getEtdFrom())) {
				query.append(utils.ajustaColumna(" AND s.etdFinal >= ? "));
			}
			if (params.getEtdTo() != null && !"null".equals(params.getEtdTo())) {
				query.append(utils.ajustaColumna(" AND s.etdFinal <= ? "));
			}

			if (params.getPlanningAppDateFrom() != null) {
				query.append(utils.ajustaColumna(" AND s.tinyFecIniShipping >= ? "));
			}
			if (params.getPlanningAppDateTo() != null) {
				query.append(utils.ajustaColumna(" AND s.tinyFecIniShipping <= ? "));
			}
			if (params.getShippingAppDateFrom() != null) {
				query.append(utils.ajustaColumna(
						" AND ((s.consolidado = 1 AND s.tinyfeciniconsol >= ? ) OR ((s.consolidado IS  NULL OR s.consolidado = 0) AND s.tinyFecIniBooking >= ?) ) "));
			}
			if (params.getShippingAppDateTo() != null) {
				query.append(utils.ajustaColumna(
						"  AND ((s.consolidado = 1 AND s.tinyfeciniconsol <= ? ) OR ((s.consolidado IS  NULL OR s.consolidado = 0) AND s.tinyFecIniBooking <= ?) ) "));
			}
			if (params.getCreationDateFrom() != null && !"null".equals(params.getCreationDateFrom())) {
				query.append(utils.ajustaColumna(" AND s.fechaCreacion >= ? "));
			}
			if (params.getCreationDateTo() != null && !"null".equals(params.getCreationDateTo())) {
				query.append(utils.ajustaColumna(" AND s.fechaCreacion <= ? "));
			}
			if (params.getPrioridad() != null && params.getPrioridad() != -1) {
				query.append(utils.ajustaColumna(" AND s.prioridad = ? "));
			}
			if (params.getBooking() != null && !"null".equals(params.getBooking())) {
				query.append(utils.ajustaColumna(" AND s.booking = ? "));
			}
			if (params.getContenedor() != null && !"null".equals(params.getContenedor())) {
				query.append(utils.ajustaColumna(" AND s.contenedor = ? "));
			}
			if (params.getViaje() != null && !"null".equals(params.getViaje())) {
				query.append(utils.ajustaColumna(" AND s.viaje = ? "));
			}
			if (params.getProveedor() != null && !"null".equals(params.getProveedor())) {
				query.append(utils.ajustaColumna(" AND s.proveedor = ?  "));
			}

			pst = con.prepareStatement(query.toString());
			int cont = 1;
			utils.inicializaQuery(query.toString());

			if (params.getFolio() != null && !"null".equals(params.getFolio())) {
				utils.ajustaParametro(cont++, pst, params.getFolio(), Integer.class);
			}
			if (params.getPo() != null && !"null".equals(params.getPo())) {
				utils.ajustaParametro(cont++, pst, params.getPo(), String.class);
			}
			if (params.getMaterial() != null && !"null".equals(params.getMaterial())) {
				utils.ajustaParametro(cont++, pst, params.getMaterial(), Integer.class);
			}
			if (params.getPuertoOrigen() != null && !"-1".equals(params.getPuertoOrigen())) {
				utils.ajustaParametro(cont++, pst, params.getPuertoOrigen(), String.class);
			}
			if (params.getPuertoDestino() != null && !"-1".equals(params.getPuertoDestino())) {
				utils.ajustaParametro(cont++, pst, params.getPuertoDestino(), String.class);
			}
			if (params.getNaviera() != null && params.getNaviera() != -1) {
				utils.ajustaParametro(cont++, pst, params.getNaviera(), Integer.class);
			}
			if (params.getBarco() != null && !"null".equals(params.getBarco())) {
				utils.ajustaParametro(cont++, pst, params.getBarco(), String.class);
			}
			if (params.getEtaFrom() != null && !"null".equals(params.getEtaFrom())) {
				Integer fechaFormato = FuncionesComunesPLI.formateaFechaSeparador(params.getEtaFrom());
				utils.ajustaParametro(cont++, pst, fechaFormato, Integer.class);
			}
			if (params.getEtaTo() != null && !"null".equals(params.getEtaTo())) {
				Integer fechaFormato = FuncionesComunesPLI.formateaFechaSeparador(params.getEtaTo());
				utils.ajustaParametro(cont++, pst, fechaFormato, Integer.class);
			}
			if (params.getEtdFrom() != null) {
				utils.ajustaParametro(cont++, pst, params.getEtdFrom(), Integer.class);
			}
			if (params.getEtdTo() != null) {
				utils.ajustaParametro(cont++, pst, params.getEtdTo(), Integer.class);
			}

			if (params.getPlanningAppDateFrom() != null) {

				utils.ajustaParametro(cont++, pst, params.getPlanningAppDateFrom(), Integer.class);
			}
			if (params.getPlanningAppDateTo() != null) {
				utils.ajustaParametro(cont++, pst, params.getPlanningAppDateTo(), Integer.class);
			}
			if (params.getShippingAppDateFrom() != null) {
				utils.ajustaParametro(cont++, pst, params.getShippingAppDateFrom(), Integer.class);
				utils.ajustaParametro(cont++, pst, params.getShippingAppDateFrom(), Integer.class);
			}
			if (params.getShippingAppDateTo() != null) {
				utils.ajustaParametro(cont++, pst, params.getShippingAppDateTo(), Integer.class);
				utils.ajustaParametro(cont++, pst, params.getShippingAppDateTo(), Integer.class);
			}

			if (params.getCreationDateFrom() != null && !"null".equals(params.getCreationDateFrom())) {
				Integer fechaFormato = FuncionesComunesPLI.formateaFechaSeparador(params.getCreationDateFrom());
				utils.ajustaParametro(cont++, pst, fechaFormato, Integer.class);
			}
			if (params.getCreationDateTo() != null && !"null".equals(params.getCreationDateTo())) {
				Integer fechaFormato = FuncionesComunesPLI.formateaFechaSeparador(params.getCreationDateTo());
				utils.ajustaParametro(cont++, pst, fechaFormato, Integer.class);
			}
			if (params.getPrioridad() != null && params.getPrioridad() != -1) {
				utils.ajustaParametro(cont++, pst, params.getPrioridad(), Integer.class);
			}
			if (params.getBooking() != null && !"null".equals(params.getBooking())) {
				utils.ajustaParametro(cont++, pst, params.getBooking(), String.class);
			}
			if (params.getContenedor() != null && !"null".equals(params.getContenedor())) {
				utils.ajustaParametro(cont++, pst, params.getContenedor(), String.class);
			}
			if (params.getViaje() != null && !"null".equals(params.getViaje())) {
				utils.ajustaParametro(cont++, pst, params.getViaje(), String.class);
			}
			if (params.getProveedor() != null && !"null".equals(params.getProveedor())) {
				utils.ajustaParametro(cont++, pst, params.getProveedor(), String.class);
			}

			rs = pst.executeQuery();
			while (rs.next()) {
				int etdBooking = rs.getInt("etdFinal");
				int etd = rs.getInt("fechaEmbarque");
				if (etdBooking > 0) {
					etd = etdBooking;
				}
				int folioReg = rs.getInt("folio");
				String proveedor = rs.getString("proveedor");
				int statusReg = rs.getInt("status");
				String puertoSalida = rs.getString("puertoSalida");
				int navieraReg = rs.getInt("naviera");
				int prioridadReg = rs.getInt("prioridad");
				String puertoDescarga = rs.getString("puertoDescarga");
				String barcoReg = rs.getString("barcoSugerido");
				String viaje = rs.getString("viaje");
				String contenedor = rs.getString("contenedor");
				String booking = rs.getString("booking");
				String bl = rs.getString("BL");
				int transporte = rs.getInt("transporte");
				int tipoContenedor = rs.getInt("tipoContenedor");
				int revision = rs.getInt("revision");
				int fechaCreacion = rs.getInt("fechaCreacion");
				int folioConsol = rs.getInt("folioConsolidado");
				boolean esAereo = rs.getBoolean("esAereo");
				Integer consolidado = rs.getInt("consolidado");
				if (rs.wasNull()) {
					consolidado = null;
				}
				Integer folioconsolidado = rs.getInt("folioconsolidado");
				if (rs.wasNull()) {
					folioconsolidado = null;
				}
				int eta = rs.getInt("eta");
				int fechaCierreDocumentosProveedor = rs.getInt("fechaCierreDocumentosProveedor");
				boolean aprobadoProveedor = rs.getBoolean("aprobadoProveedor");
				boolean aprobadoSDI = rs.getBoolean("aprobadoSDI");
				boolean cerradoDocumentosProveedor = rs.getBoolean("cerradoDocumentosProveedor");
				Boolean tieneFactura = (Boolean) rs.getObject("tieneFacturaArch");
				Boolean tieneBL = (Boolean) rs.getObject("tieneBLArch");
				Boolean tienePKL = (Boolean) rs.getObject("tienePackingListArch");
				int fechaAprobadoSDI = rs.getInt("fechaAprobadoSDI");
				long fecIniPlanning = rs.getLong("fecIniPlanning");
				int tinyFecIniPlanning = rs.getInt("tinyFecIniPlanning");
				long fecIniShipping = rs.getLong("fecIniShipping");
				int tinyFecIniShipping = rs.getInt("tinyFecIniShipping");
				long fecIniConsol = rs.getLong("fecIniConsol");
				int tinyFecIniConsol = rs.getInt("tinyFecIniConsol");
				long fecIniBooking = rs.getLong("fecIniBooking");
				int tinyFecIniBooking = rs.getInt("tinyFecIniBooking");
				long fecIniSDI = rs.getLong("fecIniSDI");
				int tinyFecIniSDI = rs.getInt("tinyFecIniSDI");
				long fecIniEmbarque = rs.getLong("fecIniEmbarque");
				int tinyFecIniEmbarque = rs.getInt("tinyFecIniEmbarque");
				Boolean needAuthImpDir = rs.getBoolean("needAuthImpDir");
				Boolean aprobadoDirImportaciones = rs.getBoolean("aprobadoDirImportaciones");
				String userApruebaDirImportaciones = rs.getString("userApruebaDirImportaciones");
				Integer fechaApruebaDirImportaciones = rs.getInt("fechaApruebaDirImportaciones");
				String commentForImpDir = rs.getString("commentForImpDir");
				String impDirComments = rs.getString("impDirComments");
				Integer adelantoAtrasoETDImpDir = rs.getInt("adelantoAtrasoETDImpDir");
				Boolean diferenciaMRP = rs.getBoolean("diferenciaMRP");
				Boolean cargadoMRP = (Boolean) rs.getObject("cargadoMRP");
				Integer versionSetDocumentos = rs.getInt("versionSetDocumentos");
				if (rs.wasNull()) {
					versionSetDocumentos = null;
				}
				Boolean aplicaBitacoraImpDir = (Boolean) rs.getObject("aplicaBitacoraImpDir");
				Boolean bitacoraImpDirCerrada = (Boolean) rs.getObject("bitacoraImpDirCerrada");
				Integer fecCierreBitacoraImpDir = rs.getInt("fecCierreBitacoraImpDir");
				if (rs.wasNull()) {
					fecCierreBitacoraImpDir = null;
				}
				Integer numRevFinal = rs.getInt("numRevFinal");
				
				Boolean goodsAreReady = rs.getBoolean("goods_are_ready");
				Date goodsReadyDate  = rs.getDate("goods_ready_date");
				Boolean gdrEnRevision = rs.getBoolean("gdrEnRevision");
				Integer tipoRetraso = rs.getInt("tipoRetraso");
				
				Boolean aprobadoConfMngr = rs.getBoolean("aprobadoConfMngr");
				

				SarBO sar = new SarBO(folioReg, proveedor, tipoContenedor);
				sar.setStatus(statusReg);
				sar.setPuertoOrigen(puertoSalida);
				sar.setNaviera(navieraReg);
				sar.setPrioridad(prioridadReg);
				sar.setPuertoDescarga(puertoDescarga);
				sar.setBarcoSugerido(barcoReg);
				sar.setViaje(viaje);
				sar.setContenedor(contenedor);
				sar.setBooking(booking);
				sar.setBl(bl);
				sar.setTransporte(transporte);
				sar.setFechaEmbarque(etd);
				sar.setCreationDate(fechaCreacion);
				sar.setFolioConsolidado(folioConsol);
				sar.setEsAereo(esAereo);
				sar.setFechaCierreDocumentosProveedor(fechaCierreDocumentosProveedor);
				sar.setAprobadoProveedor(aprobadoProveedor);
				sar.setAprobadoSDI(aprobadoSDI);
				sar.setCerradoDocumentosProveedor(cerradoDocumentosProveedor);
				sar.setFechaAprobadoSDI(fechaAprobadoSDI);
				sar.setTieneFacura(tieneFactura);
				sar.setTieneBL(tieneBL);
				sar.setTienePackingList(tienePKL);
				sar.setEta(eta);
				if(goodsReadyDate!=null) {
					sar.setGoodsReadyDate(goodsReadyDate);
					DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
					String goodsReadyDateStr =dateFormat.format(goodsReadyDate);
					sar.setGoodsReadyDateStr(goodsReadyDateStr);
				}else {
					sar.setGoodsReadyDate(new Date());
					sar.setGoodsReadyDateStr("");
				}
				sar.setGoodsAreReady(goodsAreReady);
				sar.setGdrEnRevision(gdrEnRevision);
				sar.setRevision(revision);
				sar.setFolioConsolidado(folioconsolidado);
				sar.setConsolidado((consolidado != null && consolidado > 0) ? true : false);
				if (statusReg >= SarBO.STATUS_ESPERA_APROBACION_SHIPPING && statusReg != SarBO.STATUS_CANCELADO
						&& statusReg != SarBO.STATUS_RECHAZADO) {
					FuncionesComunesPLI.esCorrectoFull(sar, "/srm_booking");
				}
				sar.setFecIniPlanning(fecIniPlanning);
				sar.setTinyFecIniPlanning(tinyFecIniPlanning);
				sar.setFecIniShipping(fecIniShipping);
				sar.setTinyFecIniShipping(tinyFecIniShipping);
				sar.setFecIniConsolidados(fecIniConsol);
				sar.setTinyFecIniConsolidados(tinyFecIniConsol);
				sar.setFecIniBooking(fecIniBooking);
				sar.setTinyFecIniBooking(tinyFecIniBooking);
				sar.setFecIniSDI(fecIniSDI);
				sar.setTinyFecIniSDI(tinyFecIniSDI);
				sar.setFecIniEmbarque(fecIniEmbarque);
				sar.setTinyFecIniEmbarque(tinyFecIniEmbarque);
				sar.setNeedsAuthImpDir(needAuthImpDir);
				sar.setAprobadoDirImportaciones(aprobadoDirImportaciones);
				sar.setUserApruebaDirImportaciones(userApruebaDirImportaciones);
				sar.setFechaAprobacionDirImportaciones(fechaApruebaDirImportaciones);
				sar.setCommentForImpDir(commentForImpDir);
				sar.setImpDirComments(impDirComments);
				sar.setAdelantoAtrasoETDImpDir(adelantoAtrasoETDImpDir);
				sar.setTieneDiferenciaMRP(diferenciaMRP);
				sar.setCargadoMRP(cargadoMRP);
				sar.setAplicaBitacora(aplicaBitacoraImpDir);
				sar.setBitacoraImportsDirCerrada(bitacoraImpDirCerrada);
				sar.setFecCierreBitacoraImpDir(fecCierreBitacoraImpDir);
				sar.setNumRevFinal(numRevFinal);
				sar.setVersionSDI(versionSetDocumentos);
				sar.setEnRevicionIDA(rs.getBoolean("enrevisionIDA"));
				sar.setBitacoraIDA(rs.getBoolean("bitacoraIDA"));
				sar.setBitacoraIDACerrada(rs.getBoolean("bitacoraIDACerrada"));
				sar.setNuevaFechaETD_IDA(rs.getInt("ETDnuevo"));
				sar.setPreciosRevisados(rs.getBoolean("preciosRevisados"));
				sar.setPreciosEnRevision(rs.getBoolean("preciosEnRevision"));
				sar.setPreciosLiberados(rs.getBoolean("preciosLiberados"));
				sar.setReferenciaContenedorProveedor((rs.getString("referenciaContenedorProveedor") != null) ? rs.getString("referenciaContenedorProveedor") : "-");
				sar.setPm(rs.getString("pm") != null && !rs.getString("pm").equals(""));	
				sar.setSife(rs.getBoolean("sife"));	
				sar.setStatusSife(rs.getString("statusSIFE"));
				sar.setTipoRetraso(tipoRetraso);
				sar.setAprobadoConfMngr(aprobadoConfMngr);
				result.add(sar);
			}
			rs.close();
			pst.close();
			ConexionDB.devuelveConexion(con);
		} catch (SQLException sqlE) {
			try {
				log.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		} catch (IOException ioE) {
			try {
				log.error(ioE.getMessage(), ioE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception ioE2) {
				log.error(ioE2.getMessage(), ioE2);
			}
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
		return result;
	}

	public static List<SarBO> buscaSARsConsol(SearchParamsSARs params) throws SQLException, ClassNotFoundException {
		DAOUtils utils = new DAOUtils();
		List<SarBO> result = new ArrayList<SarBO>();
		Connection con = null;

		try {
			con = ConexionDB.dameConexion();
			ResultSet rs = null;
			PreparedStatement pst = null;
			StringBuilder query = new StringBuilder();
			StringBuilder filtroDet = new StringBuilder();
			query.append("select distinct cc.folio, cc.status, cc.fechaEmbarque,");
			query.append(" cc.puertoSalida, cc.naviera, cc.tipoContenedor, cc.prioridad,");
			query.append(" cc.puertoDescarga, cc.barcoSugerido, cc.viaje, cc.contenedor,");
			query.append(" cc.booking, cc.BL, cc.etdFinal, cc.transporte, cc.eta, cc.fecIniEmbarque,");
			query.append(
					" cc.tinyFecIniEmbarque, cc.revision, cc.tieneFacturaArch, cc.tieneBLArch, cc.tienePackingListArch");
			query.append(" from cdiSarConsolidados cc INNER JOIN (");
			query.append(
					" SELECT distinct sar.folioConsolidado, sar.status, sar.booking, sar.proveedor from cdiSAR sar");
			query.append(" LEFT JOIN cdiSARDetalle det ON sar.folio = det.folio");
			query.append(" WHERE (sar.status = 3 OR sar.status = 5) AND sar.folioconsolidado > 0");
			query.append(" &");
			query.append(") c");
			query.append(" ON cc.folio = c.folioConsolidado");
			query.append(" WHERE 1=1 ");

			utils.setSelect(true);

			if (params.getCdiTSR() != null) {
				if (params.getCdiTSR().equals("1")) {
					query.append(" AND sar.folio IN (SELECT folio FROM cdiTsrReport ");
					query.append("WHERE folio = sar.folio AND pendiente = 1) ");
				} else if (params.getCdiTSR().equals("2")) {
					query.append(" AND sar.folio IN (SELECT folio FROM cdiTsrReport ");
					query.append("WHERE folio = sar.folio AND pendiente = 0) ");
				}
			}

			if (params.getFolio() != null && !"null".equals(params.getFolio())) {
				query.append(utils.ajustaColumna(" AND cc.folio = ?"));
			}
			if (params.getPo() != null && !"null".equals(params.getPo())) {
				filtroDet.append(utils.ajustaColumna(" AND det.po = ?"));
			}
			if (params.getMaterial() != null && !"null".equals(params.getMaterial())) {
				filtroDet.append(utils.ajustaColumna(" AND det.material = ?"));
			}
			if (params.getStatusSAR() != null && !"null".equals(params.getStatusSAR())
					&& !"-99".equals(params.getStatusSAR())) {
				switch (Integer.valueOf(params.getStatusSAR())) {
				case 5:
					query.append(" AND c.status = 3");
					break;
				case 7:
					query.append(" AND c.status = 5");
					break;
				case 9:
					query.append(" AND c.status = 3 AND (cc.booking IS NOT NULL OR cc.booking <> '')");
					query.append(
							" AND (cc.tieneFacturaArch IS NULL OR cc.tieneBLArch IS NULL OR cc.tienePackingListArch IS NULL)");
					break;
				default:
					query.append(" AND c.status = 0");
					break;
				}
			}
			if (params.getPuertoOrigen() != null && !"-1".equals(params.getPuertoOrigen())) {
				query.append(utils.ajustaColumna(" AND cc.puertoSalida = ? "));
			}
			if (params.getPuertoDestino() != null && !"-1".equals(params.getPuertoDestino())) {
				query.append(utils.ajustaColumna(" AND cc.puertoDescarga = ? "));
			}
			if (params.getNaviera() != null && params.getNaviera() != -1) {
				query.append(utils.ajustaColumna(" AND cc.naviera = ? "));
			}
			if (params.getBarco() != null && !"null".equals(params.getBarco())) {
				query.append(utils.ajustaColumna(" AND cc.barcoSugerido = ? "));
			}
			if (params.getEtaFrom() != null && !"null".equals(params.getEtaFrom())) {
				query.append(utils.ajustaColumna(" AND cc.eta >= ? "));
			}
			if (params.getEtaTo() != null && !"null".equals(params.getEtaTo())) {
				query.append(utils.ajustaColumna(" AND cc.eta <= ? "));
			}
			if (params.getEtdFrom() != null && !"null".equals(params.getEtdFrom())) {
				query.append(utils.ajustaColumna(" AND cc.etdFinal >= ? "));
			}
			if (params.getEtdTo() != null && !"null".equals(params.getEtdTo())) {
				query.append(utils.ajustaColumna(" AND cc.etdFinal <= ? "));
			}
			if (params.getCreationDateFrom() != null && !"null".equals(params.getCreationDateFrom())) {
				query.append(utils.ajustaColumna(" AND cc.fechaCreacion >= ? "));
			}
			if (params.getCreationDateTo() != null && !"null".equals(params.getCreationDateTo())) {
				query.append(utils.ajustaColumna(" AND cc.fechaCreacion <= ? "));
			}
			if (params.getPrioridad() != null && params.getPrioridad() != -1) {
				query.append(utils.ajustaColumna(" AND cc.prioridad = ? "));
			}
			if (params.getBooking() != null && !"null".equals(params.getBooking())) {
				query.append(utils.ajustaColumna(" AND c.booking = ? "));
			}
			if (params.getContenedor() != null && !"null".equals(params.getContenedor())) {
				query.append(utils.ajustaColumna(" AND cc.contenedor = ? "));
			}
			if (params.getViaje() != null && !"null".equals(params.getViaje())) {
				query.append(utils.ajustaColumna(" AND cc.viaje = ? "));
			}
			if (params.getProveedor() != null && !"null".equals(params.getProveedor())) {
				query.append(utils.ajustaColumna(" AND c.proveedor = ?  "));
			}
			if (params.getBloqueado() != null) {
				query.append(utils.ajustaColumna(" AND esDesbloqueado = ? "));
			}
			query.replace(query.indexOf("&"), query.indexOf("&") + 1, filtroDet.toString());

			pst = con.prepareStatement(query.toString());
			int cont = 1;
			utils.inicializaQuery(query.toString());

			if (params.getPo() != null && !"null".equals(params.getPo())) {
				utils.ajustaParametro(cont++, pst, params.getPo(), String.class);
			}
			if (params.getMaterial() != null && !"null".equals(params.getMaterial())) {
				utils.ajustaParametro(cont++, pst, params.getMaterial(), Integer.class);
			}
			if (params.getFolio() != null && !"null".equals(params.getFolio())) {
				utils.ajustaParametro(cont++, pst, params.getFolio(), Integer.class);
			}
			if (params.getPuertoOrigen() != null && !"-1".equals(params.getPuertoOrigen())) {
				utils.ajustaParametro(cont++, pst, params.getPuertoOrigen(), String.class);
			}
			if (params.getPuertoDestino() != null && !"-1".equals(params.getPuertoDestino())) {
				utils.ajustaParametro(cont++, pst, params.getPuertoDestino(), String.class);
			}
			if (params.getNaviera() != null && params.getNaviera() != -1) {
				utils.ajustaParametro(cont++, pst, params.getNaviera(), Integer.class);
			}
			if (params.getBarco() != null && !"null".equals(params.getBarco())) {
				utils.ajustaParametro(cont++, pst, params.getBarco(), String.class);
			}
			if (params.getEtaFrom() != null && !"null".equals(params.getEtaFrom())) {
				Integer fechaFormato = FuncionesComunesPLI.formateaFechaSeparador(params.getEtaFrom());
				utils.ajustaParametro(cont++, pst, fechaFormato, Integer.class);
			}
			if (params.getEtaTo() != null && !"null".equals(params.getEtaTo())) {
				Integer fechaFormato = FuncionesComunesPLI.formateaFechaSeparador(params.getEtaTo());
				utils.ajustaParametro(cont++, pst, fechaFormato, Integer.class);
			}
			if (params.getEtdFrom() != null) {
				utils.ajustaParametro(cont++, pst, params.getEtdFrom(), Integer.class);
			}
			if (params.getEtdTo() != null) {
				utils.ajustaParametro(cont++, pst, params.getEtdTo(), Integer.class);
			}
			if (params.getCreationDateFrom() != null && !"null".equals(params.getCreationDateFrom())) {
				Integer fechaFormato = FuncionesComunesPLI.formateaFechaSeparador(params.getCreationDateFrom());
				utils.ajustaParametro(cont++, pst, fechaFormato, Integer.class);
			}
			if (params.getCreationDateTo() != null && !"null".equals(params.getCreationDateTo())) {
				Integer fechaFormato = FuncionesComunesPLI.formateaFechaSeparador(params.getCreationDateTo());
				utils.ajustaParametro(cont++, pst, fechaFormato, Integer.class);
			}
			if (params.getPrioridad() != null && params.getPrioridad() != -1) {
				utils.ajustaParametro(cont++, pst, params.getPrioridad(), Integer.class);
			}
			if (params.getBooking() != null && !"null".equals(params.getBooking())) {
				utils.ajustaParametro(cont++, pst, params.getBooking(), String.class);
			}
			if (params.getContenedor() != null && !"null".equals(params.getContenedor())) {
				utils.ajustaParametro(cont++, pst, params.getContenedor(), String.class);
			}
			if (params.getViaje() != null && !"null".equals(params.getViaje())) {
				utils.ajustaParametro(cont++, pst, params.getViaje(), String.class);
			}
			if (params.getProveedor() != null && !"null".equals(params.getProveedor())) {
				utils.ajustaParametro(cont++, pst, params.getProveedor(), String.class);
			}
			if (params.getBloqueado() != null) {
				utils.ajustaParametro(cont++, pst, params.getBloqueado(), Boolean.class);
			}
			rs = pst.executeQuery();
			while (rs.next()) {
				int etdBooking = rs.getInt("etdFinal");
				int etd = rs.getInt("fechaEmbarque");
				if (etdBooking > 0) {
					etd = etdBooking;
				}
				int folioReg = rs.getInt("folio");
				int statusReg = rs.getInt("status");
				String puertoSalida = rs.getString("puertoSalida");
				int navieraReg = rs.getInt("naviera");
				int prioridadReg = rs.getInt("prioridad");
				String puertoDescarga = rs.getString("puertoDescarga");
				String barcoReg = rs.getString("barcoSugerido");
				String viaje = rs.getString("viaje");
				String contenedor = rs.getString("contenedor");
				String booking = rs.getString("booking");
				String BL = rs.getString("bl");
				int transporte = rs.getInt("transporte");
				int tipoContenedor = rs.getInt("tipoContenedor");
				int eta = rs.getInt("eta");
				long fecIniEmbarque = rs.getLong("fecIniEmbarque");
				int tinyFecIniEmbarque = rs.getInt("tinyFecIniEmbarque");
				Boolean tieneFactura = (Boolean) rs.getObject("tieneFacturaArch");
				Boolean tieneBL = (Boolean) rs.getObject("tieneBLArch");
				Boolean tienePKL = (Boolean) rs.getObject("tienePackingListArch");

				SarBO sar = new SarBO();
				sar.setFolio(folioReg);
				sar.setTipoContenedor(tipoContenedor);
				sar.setStatus(statusReg);
				sar.setPuertoOrigen(puertoSalida);
				sar.setNaviera(navieraReg);
				sar.setPrioridad(prioridadReg);
				sar.setPuertoDescarga(puertoDescarga);
				sar.setBarcoSugerido(barcoReg);
				sar.setViaje(viaje);
				sar.setContenedor(contenedor);
				sar.setBooking(booking);
				sar.setBl(BL);
				sar.setTransporte(transporte);
				sar.setFechaEmbarque(etd);
				sar.setConsolidado(true);
				sar.setFolioConsolidado(folioReg);/// cambio este -1 por el numero de consolidado, para distingir
				sar.setEta(eta);
				sar.setFecIniEmbarque(fecIniEmbarque);
				sar.setTinyFecIniEmbarque(tinyFecIniEmbarque);
				sar.setTieneFacura(tieneFactura);
				sar.setTieneBL(tieneBL);
				sar.setTienePackingList(tienePKL);
				if (statusReg >= SarBO.STATUS_ESPERA_APROBACION_SHIPPING && statusReg != SarBO.STATUS_CANCELADO
						&& statusReg != SarBO.STATUS_RECHAZADO) {
					FuncionesComunesPLI.esCorrectoFull(sar, "/srm_booking");
				}
				sar.setRevision(rs.getInt("revision"));
				if (rs.wasNull()) {
					sar.setRevision(null);
				}
				result.add(sar);
			}
			rs.close();
			pst.close();
			ConexionDB.devuelveConexion(con);
		} catch (SQLException sqlE) {
			try {
				log.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		} catch (IOException ioE) {
			try {
				log.error(ioE.getMessage(), ioE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception ioE2) {
				log.error(ioE2.getMessage(), ioE2);
			}
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
		return result;
	}

	public void updateSarsFromConsol(int folioConsol) throws SQLException, ClassNotFoundException {
		StringBuilder sb = new StringBuilder();
		sb.append("update cdiSar set ");
		sb.append("puertoSalida = sc.puertoSalida, ");
		sb.append("naviera = sc.naviera, ");
		sb.append("fechaEmbarque = sc.fechaEmbarque, ");
		sb.append("tipoContenedor = sc.tipoContenedor, ");
		sb.append("barcoSugerido = sc.barcoSugerido, ");
		sb.append("viaje = sc.viaje, ");
		sb.append("puertoDescarga = sc.puertoDescarga, ");
		sb.append("contenedor = sc.contenedor, ");
		sb.append("eta = sc.eta, ");
		sb.append("etdfinal = sc.etdfinal, ");
		sb.append("paisdestino = sc.paisdestino, ");
		sb.append("transporte = sc.transporte ");
		sb.append("from (select puertoSalida,naviera,fechaEmbarque,status,tipoContenedor, ");
		sb.append("prioridad,barcoSugerido,viaje,puertoDescarga,contenedor, ");
		sb.append("booking,eta,etdfinal,comentarioConsolidado,comentarioTruperBooking, ");
		sb.append("paisdestino,tipoProducto,tipoRetraso,retrasoProveedor,transporte ");
		sb.append("from cdiSarConsolidados where folio = ?) sc ");
		sb.append("where folioconsolidado = ? ");
		String query = sb.toString();
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();
			PreparedStatement ps = con.prepareStatement(query);
			ps.setInt(1, folioConsol);
			ps.setInt(2, folioConsol);
			ps.executeUpdate();
			ConexionDB.devuelveConexion(con);
		} catch (SQLException sqlE) {
			try {
				log.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
	}

	/**
	 * Nuevo metodo para hacer updates a la vista de SAR este funciona dinamicamente
	 * 
	 * @param SAR     objeto que contiene todos los datos a actualizar
	 * @param usuario String del nobre de usuario para loggear
	 * 
	 * @return regresa un int con el numero de registros modificados
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 */
	public int updateSAR(SarBO base, UserBean usuario) throws SQLException, ClassNotFoundException {
		Connection con = null;
		int resultado = 0;
		DAOUtils utils = new DAOUtils();
		try {
			con = ConexionDB.dameConexion();

			PreparedStatement pst = null;
			StringBuffer query = new StringBuffer();

			query.append(" update cdiSAR ");
			query.append(" set ");

			if (base.getEsAereo() != null) {
				query.append(utils.ajustaColumna(" esAereo = ?"));
			}
			if (base.getProveedor() != null) {
				query.append(utils.ajustaColumna(" proveedor = ?"));
			}
			if (base.getPuertoSalida() != null) {
				query.append(utils.ajustaColumna(" puertoSalida = ?"));
			}
			if (base.getNaviera() != null) {
				query.append(utils.ajustaColumna(" naviera = ?"));
			}
			if (base.getFechaEmbarque() != null) {
				query.append(utils.ajustaColumna(" fechaEmbarque = ?"));
			}
			if (base.getConsolidado() != null) {
				query.append(utils.ajustaColumna(" consolidado = ?"));
			}
			if (base.getFechaSolicitudDeAprobacion() != null) {
				query.append(utils.ajustaColumna(" fechaSolAprobacion = ?"));
			}
			if (base.getUsuarioSolicitudDeAprobacion() != null) {
				query.append(utils.ajustaColumna(" usuarioSolAprobacion = ?"));
			}
			if (base.getFechaUltimaAprobacionRechazo() != null) {
				query.append(utils.ajustaColumna(" fechaUltAprobRechazo = ?"));
			}
			if (base.getUsuarioApruebaRechaza() != null) {
				query.append(utils.ajustaColumna(" usuarioApruebaRechaza = ?"));
			}
			if (base.getTipoContenedor() != null) {
				query.append(utils.ajustaColumna(" tipoContenedor = ?"));
			}
			if (base.getPrioridad() != null) {
				query.append(utils.ajustaColumna(" prioridad = ?"));
			}
			if (base.getViaje() != null) {
				query.append(utils.ajustaColumna(" viaje = ?"));
			}
			if (base.getPuertoDescarga() != null) {
				query.append(utils.ajustaColumna(" puertoDescarga = ?"));
			}
			if (base.getContenedor() != null) {
				query.append(utils.ajustaColumna(" contenedor = ?"));
			}
			if (base.getFolioConsolidado() != null) {
				query.append(utils.ajustaColumna(" folioConsolidado = ?"));
			}
			if (base.getBooking() != null) {
				query.append( utils.ajustaColumna(String.valueOf( " booking = ").concat(  UtilsSQL.getInstance().clearStringsSQL()) ));
			}
			if (base.getEtdPlanner() != null) {
				query.append(utils.ajustaColumna(" etd = ?"));
			}
			if (base.getEtdReal() != null) {
				query.append(utils.ajustaColumna(" etdFinal = ?"));
			}
			if (base.getEtdModificada() != null) {
				query.append(utils.ajustaColumna(" etdFinalModificada = ?"));
			}
			if (base.getBarcoSugerido() != null) {
				query.append(utils.ajustaColumna(" barcoSugerido = ?"));
			}
			if (base.getTransporte() != null) {
				query.append(utils.ajustaColumna(" transporte = ?"));
			}
			if (base.getComentarioPlanner() != null) {
				query.append(utils.ajustaColumna(" comentarioPlanner = ?"));
			}
			if (base.getComentarioShipping() != null) {
				query.append(utils.ajustaColumna(" comentarioShipping = ?"));
			}
			if (base.getBl() != null) {
				query.append(utils.ajustaColumna(" BL = ?"));
			}
			if (base.getFechaBl() != null) {
				query.append(utils.ajustaColumna(" fechaBL = ?"));
			}
			if (base.getEta() != null) {
				query.append(utils.ajustaColumna(" eta = ?"));
			}
			if (base.getComentarioTruperBooking() != null) {
				query.append(utils.ajustaColumna(" comentarioTruperBooking = ?"));
			}
			if (base.getAprobadoPorCompras() != null) {
				query.append(utils.ajustaColumna(" aprobadoPorCompras = ?"));
			}
			if (base.getTipoRetraso() != null) {
				query.append(utils.ajustaColumna(" tipoRetraso = ?"));
			}
			if (base.esModificadoProveedor() != null) {
				query.append(utils.ajustaColumna(" fueModificadoProveedor = ?"));
			}
			if (base.getAprobadoProveedor() != null) {
				query.append(utils.ajustaColumna(" aprobadoProveedor = ?"));
			}
			if (base.getAerolinea() != null) {
				query.append(utils.ajustaColumna(" aerolinea = ?"));
			}
			if (base.getAvion() != null) {
				query.append(utils.ajustaColumna(" avion = ?"));
			}
			if (base.getPaisDestino() != null) {
				query.append(utils.ajustaColumna(" paisdestino = ?"));
			}
			if (base.getLlegadaAvion() != null) {
				query.append(utils.ajustaColumna(" llegadaavion = ?"));
			}
			if (base.esAprobadoSDI() != null) {
				query.append(utils.ajustaColumna(" aprobadoSDI = ?"));
			}
			if (base.getComentarioCancelacion() != null) {
				query.append(utils.ajustaColumna(" comentarioCancelacion = ?"));
			}
			if (base.getStatus() != null) {
				query.append(utils.ajustaColumna(" status = ?"));
			}
			if (base.getFechaUltimoRechazo() != null) {
				query.append(utils.ajustaColumna(" fechaUltimoRechazo = ?"));
			}
			if (base.getFechaUltimaCorreccion() != null) {
				query.append(utils.ajustaColumna(" fechaUltimaCorreccion = ?"));
			}
			if (base.getUsuarioAceptoRechazoSAR() != null) {
				query.append(utils.ajustaColumna(" usuarioUltimoRechazoAceptacion = ?"));
			}
			if (base.getRevision() != null) {
				query.append(utils.ajustaColumna(" revision = ?"));
			}
			if (base.getNombreArchivoMRP() != null) {
				query.append(utils.ajustaColumna(" archivoMRP = ?"));
			}
			if (base.getTieneDiferenciaMRP() != null) {
				query.append(utils.ajustaColumna(" diferenciaMRP = ?"));
			}
			if (base.getCargaArchivoMRP() != null) {
				query.append(utils.ajustaColumna(" cargaArchivoMRP = ?"));
			}
			if (base.getCargadoMRP() != null) {
				query.append(utils.ajustaColumna(" cargadoMRP = ?"));
			}
			if (base.getNotificacionMRP() != null) {
				query.append(utils.ajustaColumna(" notificacionMRP = ?"));
			}
			if (base.getAprobadoDirImportaciones() != null) {
				query.append(utils.ajustaColumna(" aprobadoDirImportaciones = ?"));
			}
			if (base.getNeedsAuthImpDir() != null) {
				query.append(utils.ajustaColumna(" needAuthImpDir = ?"));
			}
			if (base.getAplicaBitacora() != null) {
				query.append(utils.ajustaColumna(" aplicaBitacoraImpDir = ?"));
			}
			if (base.getEnRevisionConfirmFinal() != null) {
				query.append(utils.ajustaColumna(" enRevisionConfirmFinal = ?"));
			}
			if (base.getNumRevFinal() != null) {
				query.append(utils.ajustaColumna(" numRevFinal = ?"));
			}
			if (base.getTieneSimulador() != null) {
				query.append(utils.ajustaColumna(" tieneSimulador = ?"));
			}
			if (base.getVersionSDI() != null) {
				query.append(utils.ajustaColumna(" versionSetDocumentos = ?"));
			}
			
			if (base.getAprobadoConfMngr() != null) {
				query.append(utils.ajustaColumna(" aprobadoConfMngr = ?"));
			}

			if (base.getBookingUpdateSupplier() != null
					|| (base.getResetUpdateSupplier() != null && base.getResetUpdateSupplier())) {
				query.append(utils.ajustaColumna(" bookingUpdateSupplier = ?"));
			}

			if (base.getCarrierUpdateSupplier() != 0
					|| (base.getResetUpdateSupplier() != null && base.getResetUpdateSupplier())) {
				query.append(utils.ajustaColumna(" carrierUpdateSupplier = ?"));
			}

			if (base.getDateETDFinalUpdateSupplier() != null
					|| (base.getResetUpdateSupplier() != null && base.getResetUpdateSupplier())) {
				query.append(utils.ajustaColumna(" dateETDFinalUpdateSupplier = ?"));
			}
			
			if (base.getEsRechazado() != null && base.getEsRechazado()) {
				query.append(utils.ajustaColumna(" isRechazado = ?"));
			}

			query.append(utils.ajustaColumna(" dateUpdateSupplier = ?"));
			query.append(" where folio  = ? ");

			pst = con.prepareStatement(query.toString());

			utils.inicializaQuery(query.toString());

			int cont = 1;

			if (base.getEsAereo() != null) {
				utils.ajustaParametro(cont++, pst, base.getEsAereo(), Boolean.class);
			}
			if (base.getProveedor() != null) {
				utils.ajustaParametro(cont++, pst, base.getProveedor(), String.class);
			}
			if (base.getPuertoSalida() != null) {
				utils.ajustaParametro(cont++, pst, base.getPuertoSalida(), String.class);
			}
			if (base.getNaviera() != null) {
				utils.ajustaParametro(cont++, pst, base.getNaviera(), Integer.class);
			}
			if (base.getFechaEmbarque() != null) {
				utils.ajustaParametro(cont++, pst, base.getFechaEmbarque(), Integer.class);
			}
			if (base.getConsolidado() != null) {
				utils.ajustaParametro(cont++, pst, base.getConsolidado(), Boolean.class);
			}
			if (base.getFechaSolicitudDeAprobacion() != null) {
				utils.ajustaParametro(cont++, pst, base.getFechaSolicitudDeAprobacion(), Integer.class);
			}
			if (base.getUsuarioSolicitudDeAprobacion() != null) {
				utils.ajustaParametro(cont++, pst, base.getUsuarioSolicitudDeAprobacion(), String.class);
			}
			if (base.getFechaUltimaAprobacionRechazo() != null) {
				utils.ajustaParametro(cont++, pst, base.getFechaUltimaAprobacionRechazo(), Integer.class);
			}
			if (base.getUsuarioApruebaRechaza() != null) {
				utils.ajustaParametro(cont++, pst, base.getUsuarioApruebaRechaza(), String.class);
			}
			if (base.getTipoContenedor() != null) {
				utils.ajustaParametro(cont++, pst, base.getTipoContenedor(), Integer.class);
			}
			if (base.getPrioridad() != null) {
				utils.ajustaParametro(cont++, pst, base.getPrioridad(), Integer.class);
			}
			if (base.getViaje() != null) {
				utils.ajustaParametro(cont++, pst, base.getViaje(), String.class);
			}
			if (base.getPuertoDescarga() != null) {
				utils.ajustaParametro(cont++, pst, base.getPuertoDescarga(), String.class);
			}
			if (base.getContenedor() != null) {
				utils.ajustaParametro(cont++, pst, base.getContenedor(), String.class);
			}
			if (base.getFolioConsolidado() != null) {
				utils.ajustaParametro(cont++, pst,
						base.getFolioConsolidado().equals(new Integer("0")) ? null : base.getFolioConsolidado(),
						Integer.class);
			}
			if (base.getBooking() != null) {
				utils.ajustaParametro(cont++, pst, base.getBooking().trim(), String.class);
			}
			if (base.getEtdPlanner() != null) {
				utils.ajustaParametro(cont++, pst, base.getEtdPlanner(), Integer.class);
			}
			if (base.getEtdReal() != null) {
				utils.ajustaParametro(cont++, pst, base.getEtdReal(), Integer.class);
			}
			if (base.getEtdModificada() != null) {
				utils.ajustaParametro(cont++, pst, base.getEtdModificada(), Integer.class);
			}
			if (base.getBarcoSugerido() != null) {
				utils.ajustaParametro(cont++, pst, base.getBarcoSugerido(), String.class);
			}
			if (base.getTransporte() != null) {
				utils.ajustaParametro(cont++, pst, base.getTransporte(), Integer.class);
			}
			if (base.getComentarioPlanner() != null) {
				utils.ajustaParametro(cont++, pst, base.getComentarioPlanner(), String.class);
			}
			if (base.getComentarioShipping() != null) {
				utils.ajustaParametro(cont++, pst, base.getComentarioShipping(), String.class);
			}
			if (base.getBl() != null) {
				utils.ajustaParametro(cont++, pst, base.getBl(), String.class);
			}
			if (base.getFechaBl() != null) {
				utils.ajustaParametro(cont++, pst, base.getFechaBl(), Integer.class);
			}
			if (base.getEta() != null) {
				utils.ajustaParametro(cont++, pst, base.getEta(), Integer.class);
			}
			if (base.getComentarioTruperBooking() != null) {
				utils.ajustaParametro(cont++, pst, base.getComentarioTruperBooking(), String.class);
			}
			if (base.getAprobadoPorCompras() != null) {
				utils.ajustaParametro(cont++, pst, base.getAprobadoPorCompras(), Boolean.class);
			}
			if (base.getTipoRetraso() != null) {
				utils.ajustaParametro(cont++, pst, base.getTipoRetraso(), Integer.class);
			}
			if (base.esModificadoProveedor() != null) {
				utils.ajustaParametro(cont++, pst, base.esModificadoProveedor(), Boolean.class);
			}
			if (base.getAprobadoProveedor() != null) {
				utils.ajustaParametro(cont++, pst, base.getAprobadoProveedor(), Boolean.class);
			}
			if (base.getAerolinea() != null) {
				utils.ajustaParametro(cont++, pst, base.getAerolinea(), Integer.class);
			}
			if (base.getPaisDestino() != null) {
				utils.ajustaParametro(cont++, pst, base.getPaisDestino(), Integer.class);
			}
			if (base.getAvion() != null) {
				utils.ajustaParametro(cont++, pst, base.getAvion(), String.class);
			}
			if (base.getLlegadaAvion() != null) {
				utils.ajustaParametro(cont++, pst, base.getLlegadaAvion(), Integer.class);
			}
			if (base.esAprobadoSDI() != null) {
				utils.ajustaParametro(cont++, pst, base.esAprobadoSDI(), Boolean.class);
			}
			// este campo siempre
			if (base.getComentarioCancelacion() != null) {
				utils.ajustaParametro(cont++, pst, base.getComentarioCancelacion(), String.class);
			}
			if (base.getStatus() != null) {
				utils.ajustaParametro(cont++, pst, base.getStatus(), Integer.class);
			}
			if (base.getFechaUltimoRechazo() != null) {
				utils.ajustaParametro(cont++, pst, base.getFechaUltimoRechazo(), Integer.class);
			}
			if (base.getFechaUltimaCorreccion() != null) {

				utils.ajustaParametro(cont++, pst, base.getFechaUltimaCorreccion(), Integer.class);
			}
			if (base.getUsuarioAceptoRechazoSAR() != null) {
				utils.ajustaParametro(cont++, pst, base.getUsuarioAceptoRechazoSAR(), String.class);
			}
			if (base.getRevision() != null) {
				utils.ajustaParametro(cont++, pst, base.getRevision(), Integer.class);
			}
			if (base.getNombreArchivoMRP() != null) {
				utils.ajustaParametro(cont++, pst, base.getNombreArchivoMRP(), String.class);
			}

			if (base.getTieneDiferenciaMRP() != null) {
				utils.ajustaParametro(cont++, pst, base.getTieneDiferenciaMRP(), Boolean.class);
			}
			if (base.getCargaArchivoMRP() != null) {
				utils.ajustaParametro(cont++, pst, base.getCargaArchivoMRP(), Integer.class);
			}
			if (base.getCargadoMRP() != null) {
				utils.ajustaParametro(cont++, pst, base.getCargadoMRP(), Boolean.class);
			}
			if (base.getNotificacionMRP() != null) {
				utils.ajustaParametro(cont++, pst, base.getNotificacionMRP(), Boolean.class);
			}
			if (base.getAprobadoDirImportaciones() != null) {
				utils.ajustaParametro(cont++, pst, base.getAprobadoDirImportaciones(), Boolean.class);
			}
			if (base.getNeedsAuthImpDir() != null) {
				utils.ajustaParametro(cont++, pst, base.getNeedsAuthImpDir(), Boolean.class);
			}
			if (base.getAplicaBitacora() != null) {
				utils.ajustaParametro(cont++, pst, base.getAplicaBitacora(), Boolean.class);
			}
			if (base.getEnRevisionConfirmFinal() != null) {
				utils.ajustaParametro(cont++, pst, base.getEnRevisionConfirmFinal(), Boolean.class);
			}
			if (base.getNumRevFinal() != null) {
				utils.ajustaParametro(cont++, pst, base.getNumRevFinal(), Integer.class);
			}
			if (base.getTieneSimulador() != null) {
				utils.ajustaParametro(cont++, pst, base.getTieneSimulador(), Boolean.class);
			}
			if (base.getVersionSDI() != null) {
				utils.ajustaParametro(cont++, pst, base.getVersionSDI(), Integer.class);
			}

			if (base.getBookingUpdateSupplier() != null
					|| (base.getResetUpdateSupplier() != null && base.getResetUpdateSupplier())) {
				utils.ajustaParametro(cont++, pst, base.getBookingUpdateSupplier(), String.class);
			}
			
			if (base.getAprobadoConfMngr() != null) {
				utils.ajustaParametro(cont++, pst, base.getAprobadoConfMngr(), Boolean.class);
			}

			if (base.getCarrierUpdateSupplier() != 0
					|| (base.getResetUpdateSupplier() != null && base.getResetUpdateSupplier())) {
				utils.ajustaParametro(cont++, pst, base.getCarrierUpdateSupplier(), Integer.class);
			}

			if (base.getDateETDFinalUpdateSupplier() != null
					|| (base.getResetUpdateSupplier() != null && base.getResetUpdateSupplier())) {
				utils.ajustaParametro(cont++, pst, base.getDateETDFinalUpdateSupplier(), Date.class);
			}
			
			if(base.getEsRechazado()!=null && base.getEsRechazado()) {
				utils.ajustaParametro(cont++, pst, base.getEsRechazado(), Boolean.class);
			}

			utils.ajustaParametro(cont++, pst, new Date(), Date.class);

			/// Este es obligatorio
			utils.ajustaParametro(cont++, pst, base.getFolio(), Integer.class);
			resultado = pst.executeUpdate();
			pst.close();

		
		} catch (SQLException sqlE) {
			try {
				log.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
			throw sqlE;
		} catch (IOException ioE) {
			try {
				log.error(ioE.getMessage(), ioE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception ioE2) {
				log.error(ioE2.getMessage(), ioE2);
			}
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}

		return resultado;
	}

	public static ArrayList<CdiHistoricoRevisionBean> dameHistoricoRevisionesSAR(int folioSAR)
			throws SQLException, ClassNotFoundException {

		ArrayList<CdiHistoricoRevisionBean> listaSAR = new ArrayList<CdiHistoricoRevisionBean>();

		Connection con = null;

		try {
			con = ConexionDB.dameConexion();

			ResultSet rs = null;
			StringBuffer query = new StringBuffer();
			Statement st = null;

			query.append("SELECT  sar, accion, fecha, revision ");
			query.append(" FROM   cdiHistoricoRevisiones ");
			query.append(" WHERE   sar =  " + folioSAR);
			query.append(" ORDER BY   fecha desc");

			st = con.createStatement();
			rs = st.executeQuery(query.toString());

			while (rs.next()) {
				CdiHistoricoRevisionBean tmpSAR = new CdiHistoricoRevisionBean();
				tmpSAR.setAccion(rs.getString("accion"));
				tmpSAR.setFecha(rs.getInt("fecha"));
				tmpSAR.setRevision(rs.getInt("revision"));
				tmpSAR.setSar(rs.getInt("sar"));

				listaSAR.add(tmpSAR);
			}
			rs.close();
			ConexionDB.devuelveConexion(con);

		} catch (SQLException sqlE) {
			try {
				log.error(sqlE.getMessage(), sqlE);
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
			throw sqlE;
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}

		return listaSAR;
	}

	public static void insertHistoricoRevicion(CdiHistoricoRevisionBean base)
			throws SQLException, ClassNotFoundException {
		Connection con = null;
		int resultado = 0;
		DAOUtils utilDao = new DAOUtils();
		try {
			con = ConexionDB.dameConexion();

			PreparedStatement pst = null;
			StringBuffer query = new StringBuffer();

			query.append(" INSERT INTO cdiHistoricoRevisiones ");
			query.append(" ( sar,accion,fecha,comentario ) ");
			query.append(" VALUES ( ?,?,?,? ) ");

			pst = con.prepareStatement(query.toString());

			int cont = 1;

			if (base.getSar() != null) {
				utilDao.ajustaParametro(cont++, pst, base.getSar(), Integer.class);
			}
			if (base.getAccion() != null) {
				utilDao.ajustaParametro(cont++, pst, base.getAccion(), String.class);
			}
			if (base.getFecha() != null) {
				utilDao.ajustaParametro(cont++, pst, base.getFecha(), Integer.class);
			}
			if (base.getComentario() != null) {
				utilDao.ajustaParametro(cont++, pst, base.getComentario(), String.class);
			}
			utilDao.inicializaQuery(query.toString());
			resultado = pst.executeUpdate();
			pst.close();
		} catch (SQLException sqlE) {
			try {
				log.error("Error al ejecutar query:" + utilDao.dameQueryFinal() + " " + sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
			throw sqlE;
		} catch (IOException ioE) {
			try {
				log.error(ioE.getMessage(), ioE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception ioE2) {
				log.error(ioE2.getMessage(), ioE2);
			}
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
	}

	public static void insertaCDIBloqueos(CdiBloqueosBean base) throws SQLException, ClassNotFoundException {
		Connection con = null;
		int resultado = 0;
		DAOUtils utilDao = new DAOUtils();
		try {
			con = ConexionDB.dameConexion();

			PreparedStatement pst = null;
			StringBuffer query = new StringBuffer();

			query.append(" INSERT INTO cdiBloqueos ");
			query.append(" ( dato,tipo,usuario,fechaBloqueo,status ) ");
			query.append(" VALUES ( ?,?,?,?,? ) ");

			pst = con.prepareStatement(query.toString());

			int cont = 1;

			if (base.getDato() != null) {
				utilDao.ajustaParametro(cont++, pst, base.getDato(), String.class);
			}
			if (base.getTipo() != null) {
				utilDao.ajustaParametro(cont++, pst, base.getTipo(), String.class);
			}
			if (base.getUsuario() != null) {
				utilDao.ajustaParametro(cont++, pst, base.getUsuario(), String.class);
			}
			if (base.getFechaBloqueo() != null) {
				utilDao.ajustaParametro(cont++, pst, base.getFechaBloqueo(), Integer.class);
			}

			if (base.getStatus() != null) {
				utilDao.ajustaParametro(cont++, pst, base.getStatus(), Boolean.class);
			}
			utilDao.inicializaQuery(query.toString());
			resultado = pst.executeUpdate();
			pst.close();
		} catch (SQLException sqlE) {
			try {
				log.error("Error al ejecutar query:" + utilDao.dameQueryFinal() + " " + sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
			throw sqlE;
		} catch (IOException ioE) {
			try {
				log.error(ioE.getMessage(), ioE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception ioE2) {
				log.error(ioE2.getMessage(), ioE2);
			}
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
	}

	public static void updateCDIBloqueos(CdiBloqueosBean base) throws SQLException, ClassNotFoundException {
		Connection con = null;
		int resultado = 0;
		DAOUtils utilDao = new DAOUtils();
		try {
			con = ConexionDB.dameConexion();

			PreparedStatement pst = null;
			StringBuffer query = new StringBuffer();

			query.append(" Update cdiBloqueos ");
			query.append(" set ");

			if (base.getStatus() != null) {
				query.append(utilDao.ajustaColumna(" status = ?"));
			}

			if (base.getFechaDesBloqueo() != null) {
				query.append(utilDao.ajustaColumna(" fechaDesbloqueo = ?"));
			}
			query.append(" where dato  = ? ");
			query.append(" AND status  = 1 ");
			pst = con.prepareStatement(query.toString());

			int cont = 1;

			if (base.getStatus() != null) {
				utilDao.ajustaParametro(cont++, pst, base.getStatus(), Boolean.class);
			}
			if (base.getFechaDesBloqueo() != null) {
				utilDao.ajustaParametro(cont++, pst, base.getFechaDesBloqueo(), Integer.class);
			}

			utilDao.ajustaParametro(cont++, pst, base.getDato(), String.class);

			utilDao.inicializaQuery(query.toString());

			resultado = pst.executeUpdate();

			pst.close();

			ConexionDB.devuelveConexion(con);

		} catch (SQLException sqlE) {
			try {
				log.error("Error al ejecutar query:" + utilDao.dameQueryFinal() + " " + sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
			throw sqlE;
		} catch (IOException ioE) {
			try {
				log.error(ioE.getMessage(), ioE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception ioE2) {
				log.error(ioE2.getMessage(), ioE2);
			}
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
	}

	/// la llave sera el sar o prveeodr |tipo tipo es SAR o PROV
	// TODO cambiar a select mas dinamico para despues reporteo o sacar los vencidos
	public static HashMap<String, CdiBloqueosBean> dameBloqueos() throws SQLException, ClassNotFoundException {

		HashMap<String, CdiBloqueosBean> mapaBlock = new HashMap<String, CdiBloqueosBean>();

		Connection con = null;

		try {
			con = ConexionDB.dameConexion();

			ResultSet rs = null;
			StringBuffer query = new StringBuffer();
			Statement st = null;

			query.append("SELECT  dato,tipo,usuario,fechaBloqueo,status ");
			query.append(" FROM   cdiBloqueos ");
			query.append(" WHERE   status =  1");
			st = con.createStatement();
			rs = st.executeQuery(query.toString());
			while (rs.next()) {

				CdiBloqueosBean blo = new CdiBloqueosBean();
				blo.setDato(rs.getString("dato"));
				blo.setFechaBloqueo(rs.getInt("fechaBloqueo"));
				blo.setStatus(rs.getBoolean("status"));
				blo.setTipo(rs.getString("tipo"));
				blo.setUsuario(rs.getString("usuario"));

				mapaBlock.put(blo.getDato() + "|" + blo.getTipo(), blo);
			}
			rs.close();
		} catch (SQLException sqlE) {
			try {
				log.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
			throw sqlE;
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
		return mapaBlock;
	}

	public static int insertaPuertoDirecto(BeanPuerto bean) throws SQLException, ClassNotFoundException {
		Connection con = null;
		int resultado = 0;
		DAOUtils utilDao = new DAOUtils();
		try {
			con = ConexionDB.dameConexion();

			PreparedStatement pst = null;
			StringBuffer query = new StringBuffer();

			query.append(" INSERT INTO cdiPuertosDirectos ");
			query.append(" ( clave,nombre,pais ) ");
			query.append(" VALUES ( ?,?,? ) ");

			pst = con.prepareStatement(query.toString());

			int cont = 1;

			if (bean.getClave() != null) {
				utilDao.ajustaParametro(cont++, pst, bean.getClave(), Integer.class);
			}
			if (bean.getNombre() != null) {
				utilDao.ajustaParametro(cont++, pst, bean.getNombre(), String.class);
			}
			if (bean.getPais() != null) {
				utilDao.ajustaParametro(cont++, pst, bean.getPais(), String.class);
			}
			utilDao.inicializaQuery(query.toString());

			resultado = pst.executeUpdate();

			pst.close();

			ConexionDB.devuelveConexion(con);

		} catch (SQLException sqlE) {
			try {
				log.error("Error al ejecutar query:" + utilDao.dameQueryFinal() + " " + sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
			throw sqlE;
		} catch (IOException ioE) {
			try {
				log.error(ioE.getMessage(), ioE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception ioE2) {
				log.error(ioE2.getMessage(), ioE2);
			}
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
		return resultado;
	}

	public static ArrayList<SARConsolidadosHistorico> dameHistoriaC(String folio)
			throws SQLException, ClassNotFoundException {
		ArrayList<SARConsolidadosHistorico> listaSAR = new ArrayList<SARConsolidadosHistorico>();

		Connection con = null;

		try {
			con = ConexionDB.dameConexion();

			ResultSet rs = null;
			StringBuffer query = new StringBuffer();
			Statement st = null;

			query.append(
					"SELECT     id, folio, puertoSalida, naviera, fechaEmbarque, tipoContenedor, prioridad, barcoSugerido, viaje,  ");
			query.append(" puertoDescarga, contenedor, booking, etdFinal, transporte,  ");
			query.append(" comentarioConsolidado, sarsEnContenedor,fechaModificacion, ");
			query.append(" usuarioModificacion,retrasoProveedor,tipoProducto,tipoRetraso ");
			query.append(" FROM    cdi_consolidadoHistorico ");
			query.append(" WHERE   sarsEnContenedor like '%" + folio + "%' ");
			query.append(" order by fechaModificacion, folio, id ");

			st = con.createStatement();
			rs = st.executeQuery(query.toString());

			while (rs.next()) {
				SARConsolidadosHistorico tmp = new SARConsolidadosHistorico();
				tmp.setId(rs.getInt("id"));
				tmp.setFolio(rs.getInt("folio"));
				tmp.setPuertoSalida(rs.getString("puertoSalida"));
				tmp.setNaviera(rs.getInt("naviera"));
				tmp.setFechaEmbarque(rs.getInt("fechaEmbarque"));
				tmp.setTipoContenedor(rs.getInt("tipoContenedor"));
				tmp.setPrioridad(rs.getInt("prioridad"));
				tmp.setBarcoSugerido(rs.getString("barcoSugerido"));
				tmp.setViaje(rs.getString("viaje"));
				tmp.setPuertoDescarga(rs.getString("puertoDescarga"));
				tmp.setContenedor(rs.getString("contenedor"));
				tmp.setBooking(rs.getString("booking"));
				tmp.setEtdReal(rs.getInt("etdFinal"));
				tmp.setTransporte(rs.getInt("transporte"));
				tmp.setComentarioConsol(rs.getString("comentarioConsolidado"));
				tmp.setPOsEnConsolidado(rs.getString("sarsEnContenedor"));
				tmp.setFechaModficacion(rs.getInt("fechaModificacion"));
				tmp.setUsuarioMof(rs.getString("usuarioModificacion"));
				tmp.setRetrasoProveedor(rs.getString("retrasoProveedor"));
				tmp.setTipoProducto(rs.getString("tipoProducto"));
				tmp.setTipoRetraso(rs.getInt("tipoRetraso"));

				listaSAR.add(tmp);
			}
			rs.close();
			ConexionDB.devuelveConexion(con);

		} catch (SQLException sqlE) {
			try {
				log.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
			throw sqlE;
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
		return listaSAR;
	}

	public static int insertaNaviera(Naviera bean) throws SQLException, ClassNotFoundException {
		Connection con = null;
		int resultado = 0;
		DAOUtils utilDao = new DAOUtils();
		try {
			con = ConexionDB.dameConexion();

			PreparedStatement pst = null;
			StringBuffer query = new StringBuffer();

			query.append(" INSERT INTO cdiNavieras ");
			query.append(" ( clave,nombre ) ");
			query.append(" VALUES ( ?,? ) ");

			pst = con.prepareStatement(query.toString());

			int cont = 1;

			if (bean.getClave() > 0) {
				utilDao.ajustaParametro(cont++, pst, bean.getClave(), Integer.class);
			}
			if (bean.getNombre() != null) {
				utilDao.ajustaParametro(cont++, pst, bean.getNombre(), String.class);
			}
			utilDao.inicializaQuery(query.toString());

			resultado = pst.executeUpdate();

			pst.close();

			ConexionDB.devuelveConexion(con);

		} catch (SQLException sqlE) {
			try {
				log.error("Error al ejecutar query:" + utilDao.dameQueryFinal() + " " + sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
			throw sqlE;
		} catch (IOException ioE) {
			try {
				log.error(ioE.getMessage(), ioE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception ioE2) {
				log.error(ioE2.getMessage(), ioE2);
			}
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
		return resultado;
	}

	public static List<SarBO> getEstadosFechasSARs() {
		List<SarBO> lstBeanSar = new ArrayList<SarBO>();
		Connection con = null;
		Statement st = null;
		ResultSet rs = null;
		String select = null;
		try {
			con = ConexionDB.dameConexion();
			st = con.createStatement();
			select = "SELECT folio, proveedor, status, consolidado, booking, aprobadoSDI, "
					+ "naviera, contenedor, folioConsolidado, " + "fechaEmbarque, fecIniPlanning, tinyFecIniPlanning, "
					+ "fecIniShipping, tinyFecIniShipping, fecIniConsol, "
					+ "tinyFecIniConsol, fecIniBooking, tinyFecIniBooking, "
					+ "fecIniSDI, tinyFecIniSDI, fecIniEmbarque, tinyFecIniEmbarque, "
					+ "needAuthImpDir, fechaApruebaDirImportaciones,preciosLiberados "
					+ "FROM CdiSar WHERE status IN (1,2,3,6)";
			rs = st.executeQuery(select);
			while (rs.next()) {
				int folio = rs.getInt("folio");
				String proveedor = rs.getString("proveedor");
				int status = rs.getInt("status");
				boolean consolidado = rs.getBoolean("consolidado");
				String booking = rs.getString("booking");
				int fecEmbarque = rs.getInt("fechaEmbarque");
				boolean aprobadoSDI = rs.getBoolean("aprobadoSDI");
				int naviera = rs.getInt("naviera");
				String contenedor = rs.getString("contenedor");
				int folioConsolidado = rs.getInt("folioConsolidado");
				long fecIniPlanning = rs.getLong("fecIniPlanning");
				int tinyFecIniPlanning = rs.getInt("tinyFecIniPlanning");
				long fecIniShipping = rs.getLong("fecIniShipping");
				int tinyFecIniShipping = rs.getInt("tinyFecIniShipping");
				long fecIniConsol = rs.getLong("fecIniConsol");
				int tinyFecIniConsol = rs.getInt("tinyFecIniConsol");
				long fecIniBooking = rs.getLong("fecIniBooking");
				int tinyFecIniBooking = rs.getInt("tinyFecIniBooking");
				long fecIniSDI = rs.getLong("fecIniSDI");
				int tinyFecIniSDI = rs.getInt("tinyFecIniSDI");
				long fecIniEmbarque = rs.getLong("fecIniEmbarque");
				int tinyFecIniEmbarque = rs.getInt("tinyFecIniEmbarque");
				boolean needsAuthImpDir = rs.getBoolean("needAuthImpDir");
				int fechaAprobacionDirImportaciones = rs.getInt("fechaApruebaDirImportaciones");
				boolean preciosLiberados = rs.getBoolean("preciosLiberados");
				SarDetalleBO tmp = new SarDetalleBO();
				tmp.setFolio(folio);
				SarBO beanSar = new SarBO();
				beanSar.setFolio(folio);
				beanSar.setProveedor(proveedor);
				beanSar.setStatus(status);
				beanSar.setConsolidado(consolidado);
				beanSar.setBooking(booking);
				beanSar.setFechaEmbarque(fecEmbarque);
				beanSar.setAprobadoSDI(aprobadoSDI);
				beanSar.setNaviera(naviera);
				beanSar.setContenedor(contenedor);
				beanSar.setFolioConsolidado(folioConsolidado);
				beanSar.setFecIniPlanning(fecIniPlanning);
				beanSar.setTinyFecIniPlanning(tinyFecIniPlanning);
				beanSar.setFecIniShipping(fecIniShipping);
				beanSar.setTinyFecIniShipping(tinyFecIniShipping);
				beanSar.setFecIniConsolidados(fecIniConsol);
				beanSar.setTinyFecIniConsolidados(tinyFecIniConsol);
				beanSar.setFecIniBooking(fecIniBooking);
				beanSar.setTinyFecIniBooking(tinyFecIniBooking);
				beanSar.setFecIniSDI(fecIniSDI);
				beanSar.setTinyFecIniSDI(tinyFecIniSDI);
				beanSar.setFecIniEmbarque(fecIniEmbarque);
				beanSar.setTinyFecIniEmbarque(tinyFecIniEmbarque);
				beanSar.setNeedsAuthImpDir(needsAuthImpDir);
				beanSar.setFechaAprobacionDirImportaciones(fechaAprobacionDirImportaciones);
				beanSar.setPreciosLiberados(preciosLiberados);
				lstBeanSar.add(beanSar);
			}
			rs.close();
			st.close();
			ConexionDB.devuelveConexion(con);
		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				log.error("Error al renovar la conexion a la BD", e);
			}
			log.error("Error al ejecutar la consulta: " + select, e);
		} catch (Exception e) {
			e.printStackTrace();
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error("Error al devolver la conexion al POOL", e);
			}
			log.error("Error al ejecutar el metodo getEstadosFechasSARs()", e);
		}
		return lstBeanSar;
	}

	public static int insertaRegistros(String estado, List<SarBO> lstSAR) {
		int resultado = 0;
		Connection con = null;
		PreparedStatement st = null;
		StringBuffer query = null;
		GregorianCalendar gc = new GregorianCalendar();
		int fecha = FuncionesComunesPLI.gregorianCalendar2int(gc);
		try {
			con = ConexionDB.dameConexion();
			for (SarBO bean : lstSAR) {
				query = new StringBuffer();
				query.append("INSERT into MonitoreoSARVencidos (folio, fecha, estado)");
				query.append(" VALUES (?, ?, ?)");
				st = con.prepareStatement(query.toString());
				st.setInt(1, bean.getFolio());
				st.setInt(2, fecha);
				st.setString(3, estado);
				resultado = st.executeUpdate();
			}
			ConexionDB.devuelveConexion(con);
			;
		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				log.error("Error al renovar la conexion a la BD", e);
			}
			log.error("Error al ejecutar la consulta: " + query.toString(), e);
		} catch (Exception e) {
			e.printStackTrace();
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error("Error al devolver la conexion al POOL", e);
			}
			log.error("Error al ejecutar el metodo insertaReegistros()", e);
		}
		return resultado;
	}

	/**
	 * Metodo para contar cuantos sars vencidos hay en determinado tiempo
	 * 
	 * @param periodo (-1 = ayer, 0-n = mes del actual hacia atras)
	 * @return
	 * @throws SQLException
	 */
	public static int getCantidadSARVencidos(int periodo, String estado) {
		int eventos = 0;
		GregorianCalendar gc = new GregorianCalendar();
		int fecha = 0;
		int fecha2 = 0;
		if (periodo == -1) {
			gc.add(Calendar.DAY_OF_MONTH, periodo);
			fecha = FuncionesComunesPLI.gregorianCalendar2int(gc);
		} else if (periodo >= 0) {
			gc.set(Calendar.DAY_OF_MONTH, 1);
			gc.add(Calendar.MONTH, -periodo);
			fecha = FuncionesComunesPLI.gregorianCalendar2int(gc);
			gc.add(Calendar.MONTH, 1);
			gc.add(Calendar.DAY_OF_MONTH, -1);
			fecha2 = FuncionesComunesPLI.gregorianCalendar2int(gc);
		}
		Connection con = null;
		ResultSet rs = null;
		PreparedStatement pst = null;
		StringBuffer query = new StringBuffer();

		try {
			con = ConexionDB.dameConexion();

			query.append("SELECT COUNT(*) eventos FROM MonitoreoSARVencidos");
			if (periodo == -1) {
				query.append(" WHERE fecha = ?");
			} else if (periodo >= 0) {
				query.append(" WHERE fecha BETWEEN ? AND ?");
			}
			query.append(" AND estado = ?");
			pst = con.prepareStatement(query.toString());
			pst.setInt(1, fecha);
			if (periodo >= 0) {
				pst.setInt(2, fecha2);
				pst.setString(3, estado);
			} else {
				pst.setString(2, estado);
			}
			rs = pst.executeQuery();

			while (rs.next()) {
				eventos = rs.getInt("eventos");
			}
			rs.close();
			pst.close();
			ConexionDB.devuelveConexion(con);
		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
				;
			} catch (Exception ex) {
				log.error("Error al renovar la conexion a la BD", e);
			}
			log.error("Error al ejecutar la consulta: " + query.toString(), e);
		} catch (Exception e) {
			e.printStackTrace();
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error("Error al devolver la conexion al POOL", e);
			}
			log.error("Error al ejecutar el metodo getCantidadSARVencidos()", e);
		}
		return eventos;
	}

	/**
	 * Metodo especial para truperBooking, aqui busco todos los sars que esten en un
	 * status especial pero tengan un dato, cualquiera en el campo de booking, es
	 * decir, son prospectos para estar en el archivo de la naviera
	 * 
	 * @param booking
	 * @param status
	 * @return
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 */
	public static ArrayList<SarBO> selectSarParaArchivoNavieras() throws SQLException, ClassNotFoundException {

		ArrayList<SarBO> listaSAR = new ArrayList<SarBO>();

		Connection con = null;

		try {
			con = ConexionDB.dameConexion();

			ResultSet rs = null;
			PreparedStatement pst = null;
			StringBuffer query = new StringBuffer();

			query.append(
					" SELECT     folio, proveedor, puertoSalida, naviera, fechaEmbarque, consolidado, status, fechaSolAprobacion,   ");
			query.append(
					" usuarioSolAprobacion, fechaUltAprobRechazo, usuarioApruebaRechaza, tipoContenedor, prioridad, ");
			query.append(
					" barcoSugerido, viaje, puertoDescarga, contenedor, booking, etd,etdFinal, comentarioCancelacion,folioConsolidado,transporte, ");
			query.append(
					" comentarioPlanner, comentarioShipping, esSinPO, eta, bl, aprobadoPorCompras, tipoRetraso, fechaCreacion, esAereo, ");
			query.append(
					" fueModificadoProveedor, aerolinea, avion, llegadaavion, aceptadoConDiferencias, paisDestino, cargoAProveedor, ");
			query.append(
					" otraAerolinea,aprobadoProveedor,esmultiple,mandante, aprobadoSDI,cerradoDocumentosProveedor,");
			query.append(
					" fechaCierreDocumentosProveedor,fechaAprobadoSDI, comentarioTruperBooking,fechaUltimoRechazo,  ");
			query.append(
					" fechaUltimaCorreccion, usuarioUltimoRechazoAceptacion, revision, fecIniPlanning, tinyFecIniPlanning, ");
			query.append(
					" fecIniShipping, tinyFecIniShipping, fecIniConsol, tinyFecIniConsol, fecIniBooking, tinyFecIniBooking, ");
			query.append(
					" fecIniSDI, tinyFecIniSDI, fecIniEmbarque, tinyFecIniEmbarque, enRevisionConfirmFinal, numRevFinal");
			query.append(" FROM         cdiSAR ");
			query.append(" WHERE   	status NOT IN (");
			query.append(SAR.STATUS_SIN_SOLICITUD_APROBACION).append(",");
			query.append(SAR.STATUS_ESPERA_APROBACION_PLANEACION).append(",");
			query.append(SAR.STATUS_ESPERA_APROBACION_SHIPPING).append(",");
			query.append(SAR.STATUS_CANCELADO).append(",");
			query.append(SAR.STATUS_RECHAZADO).append(")");
			query.append(" AND   	booking is not  NULL ");

			pst = con.prepareStatement(query.toString());

			rs = pst.executeQuery();

			while (rs.next()) {

				SarBO tmpSAR = new SarBO();
				tmpSAR.setFolio(rs.getInt("folio"));
				tmpSAR.setProveedor(rs.getString("proveedor"));
				tmpSAR.setPuertoSalida(rs.getString("puertoSalida"));
				tmpSAR.setNaviera(rs.getInt("naviera"));
				if (rs.wasNull()) {
					tmpSAR.setNaviera(null);
				}
				tmpSAR.setFechaEmbarque(rs.getInt("fechaEmbarque"));
				tmpSAR.setConsolidado(rs.getBoolean("consolidado"));
				tmpSAR.setStatus(rs.getInt("status"));
				tmpSAR.setFechaSolicitudDeAprobacion(rs.getInt("fechaSolAprobacion"));
				if (rs.wasNull()) {
					tmpSAR.setFechaSolicitudDeAprobacion(null);
				}
				tmpSAR.setUsuarioSolicitudDeAprobacion(rs.getString("usuarioSolAprobacion"));
				tmpSAR.setFechaUltimaAprobacionRechazo(rs.getInt("fechaUltAprobRechazo"));
				tmpSAR.setUsuarioApruebaRechaza(rs.getString("usuarioApruebaRechaza"));
				tmpSAR.setTipoContenedor(rs.getInt("tipoContenedor"));
				tmpSAR.setPrioridad(rs.getInt("prioridad"));
				tmpSAR.setBarcoSugerido(rs.getString("barcoSugerido"));
				tmpSAR.setViaje(rs.getString("viaje"));
				tmpSAR.setPuertoDescarga(rs.getString("puertoDescarga"));
				tmpSAR.setContenedor(rs.getString("contenedor"));
				tmpSAR.setBooking(rs.getString("booking"));
				tmpSAR.setEtdPlanner(rs.getInt("etd"));
				tmpSAR.setEtdReal(rs.getInt("etdFinal"));
				tmpSAR.setComentarioCancelacion(rs.getString("comentarioCancelacion"));
				tmpSAR.setFolioConsolidado(rs.getInt("folioConsolidado"));
				if (rs.wasNull()) {
					tmpSAR.setFolioConsolidado(null);
				}
				tmpSAR.setEsAereo(rs.getBoolean("esAereo"));
				tmpSAR.setAvion(rs.getString("avion"));
				tmpSAR.setAerolinea(rs.getInt("aerolinea"));
				tmpSAR.setLlegadaAvion(rs.getInt("llegadaAvion"));
				if (rs.wasNull()) {
					tmpSAR.setLlegadaAvion(null);
				}

				tmpSAR.setTransporte(rs.getInt("transporte"));
				tmpSAR.setComentarioPlanner(rs.getString("comentarioPlanner"));
				tmpSAR.setComentarioShipping(rs.getString("comentarioShipping"));
				tmpSAR.setEsSinPO(rs.getBoolean("esSinPO"));
				tmpSAR.setEta(rs.getInt("eta"));

				tmpSAR.setBl(rs.getString("bl"));
				tmpSAR.setAprobadoPorCompras(rs.getBoolean("aprobadoPorCompras"));
				tmpSAR.setTipoRetraso(rs.getInt("tipoRetraso"));
				tmpSAR.setCreationDate(rs.getInt("fechaCreacion"));
				tmpSAR.setModificadoProveedor(rs.getBoolean("fueModificadoProveedor"));
				tmpSAR.setAceptadoConDiferencias(rs.getBoolean("aceptadoConDiferencias"));
				if (rs.wasNull()) {
					tmpSAR.setAceptadoConDiferencias(null);
				}
				tmpSAR.setPaisDestino(rs.getInt("paisDestino"));
				if (rs.wasNull()) {
					tmpSAR.setPaisDestino(null);
				}

				tmpSAR.setCargoAProveedor(rs.getBoolean("cargoAProveedor"));
				tmpSAR.setOtraAerolinea(rs.getString("otraAerolinea"));
				tmpSAR.setAprobadoProveedor(rs.getBoolean("aprobadoProveedor"));

				tmpSAR.setEsMultiple(rs.getBoolean("esmultiple"));
				if (rs.wasNull()) {
					tmpSAR.setEsMultiple(null);
				}
				tmpSAR.setMandante(rs.getInt("mandante"));
				if (rs.wasNull()) {
					tmpSAR.setMandante(null);
				}
				tmpSAR.setAprobadoSDI(rs.getBoolean("aprobadoSDI"));
				if (rs.wasNull()) {
					tmpSAR.setAprobadoSDI(null);
				}

				tmpSAR.setCerradoDocumentosProveedor(rs.getBoolean("cerradoDocumentosProveedor"));
				tmpSAR.setFechaCierreDocumentosProveedor(rs.getInt("fechaCierreDocumentosProveedor"));
				tmpSAR.setFechaAprobadoSDI(rs.getInt("fechaAprobadoSDI"));
				tmpSAR.setComentarioTruperBooking(rs.getString("comentarioTruperBooking"));
				tmpSAR.setFechaUltimaCorreccion(rs.getInt("fechaUltimaCorreccion"));
				tmpSAR.setUsuarioAceptoRechazoSAR(rs.getString("usuarioUltimoRechazoAceptacion"));
				tmpSAR.setRevision(rs.getInt("revision"));
				tmpSAR.setFechaUltimaAprobacionRechazo(rs.getInt("fechaUltimoRechazo"));
				tmpSAR.setFecIniPlanning(rs.getLong("fecIniPlanning"));
				tmpSAR.setTinyFecIniPlanning(rs.getInt("tinyFecIniPlanning"));
				tmpSAR.setFecIniShipping(rs.getLong("fecIniShipping"));
				tmpSAR.setTinyFecIniShipping(rs.getInt("tinyFecIniShipping"));
				tmpSAR.setFecIniConsolidados(rs.getLong("fecIniConsol"));
				tmpSAR.setTinyFecIniConsolidados(rs.getInt("tinyFecIniConsol"));
				tmpSAR.setFecIniBooking(rs.getLong("fecIniBooking"));
				tmpSAR.setTinyFecIniBooking(rs.getInt("tinyFecIniBooking"));
				tmpSAR.setFecIniSDI(rs.getLong("fecIniSDI"));
				tmpSAR.setTinyFecIniSDI(rs.getInt("tinyFecIniSDI"));
				tmpSAR.setFecIniEmbarque(rs.getLong("FecIniEmbarque"));
				tmpSAR.setTinyFecIniEmbarque(rs.getInt("tinyFecIniEmbarque"));
				tmpSAR.setEnRevisionConfirmFinal(rs.getBoolean("enRevisionConfirmFinal"));
				tmpSAR.setNumRevFinal(rs.getInt("numRevFinal"));

				listaSAR.add(tmpSAR);
			}
			rs.close();
			pst.close();
			ConexionDB.devuelveConexion(con);

		} catch (SQLException sqlE) {
			try {
				log.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
			throw sqlE;
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}

		return listaSAR;
	}

	public static ArrayList<SarBO> selectSarSDIRechazos() throws SQLException, ClassNotFoundException {

		ArrayList<SarBO> listaSAR = new ArrayList<SarBO>();

		Connection con = null;

		try {
			con = ConexionDB.dameConexion();

			ResultSet rs = null;
			PreparedStatement pst = null;
			StringBuffer query = new StringBuffer();

			query.append(" SELECT     folio,rechazoDocumentosSDI ");
			query.append(" FROM         cdiSAR ");
			query.append(" WHERE   	status =").append(SAR.STATUS_DOCUMENTOS_SDI);
			query.append(" AND   	rechazoDocumentosSDI = 1 ");

			pst = con.prepareStatement(query.toString());

			rs = pst.executeQuery();

			while (rs.next()) {

				SarBO tmpSAR = new SarBO();
				tmpSAR.setFolio(rs.getInt("folio"));

				listaSAR.add(tmpSAR);
			}
			rs.close();
			pst.close();
			ConexionDB.devuelveConexion(con);

		} catch (SQLException sqlE) {
			try {
				log.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
			throw sqlE;
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}

		return listaSAR;
	}

	@Deprecated
	public static ArrayList<CdiDocumentBO> damefacturasRepetidas(CdiDocumentBO bean, String proveedor)
			throws SQLException, ClassNotFoundException {

		ArrayList<CdiDocumentBO> lista = new ArrayList<CdiDocumentBO>();
		Connection con = null;

		try {
			con = ConexionDB.dameConexion();

			ResultSet rs = null;
			StringBuffer query = new StringBuffer();
			Statement st = null;

			query.append("select a.folio , b.sar , b.numero,b.version, b.pos,b.tipo, a.proveedor, ");
			query.append(" b.embarcaMadera , b.esGenerado ,b.fecha ,b.observaciones ,b.packagesAmpara ,");
			query.append(" b.pos ,b.representanteLegal ,b.ruta ,b.nombrearch ,b.fechacreacion ,b.nombreUser ,");
			query.append(" b.aprobadoSDI,b.prioridad,b.userUpdate,b.dateUpdate ");
			query.append(" from cdisar a , cdidocumentos b ");
			query.append(" where b.numero = '" + bean.getNumero() + "'");
			query.append(" and b.tipo = 'FAC' ");
			query.append(" and a.folio = b.sar ");
			query.append(" and a.proveedor = " + proveedor);

			st = con.createStatement();
			rs = st.executeQuery(query.toString());

			while (rs.next()) {

				CdiDocumentBO result = new CdiDocumentBO();
				result.setEmbarcaMadera(rs.getBoolean("embarcaMadera"));
				result.setEsGenerado(rs.getBoolean("esGenerado"));
				result.setFecha(rs.getInt("fecha"));
				result.setNumero(rs.getString("numero"));
				result.setObservaciones(rs.getString("observaciones"));
				result.setPackagesAmpara(rs.getDouble("packagesAmpara"));
				result.setPos(rs.getString("pos"));
				result.setRepresentanteLegal(rs.getString("representanteLegal"));
				result.setSar(rs.getInt("sar"));
				result.setTipo(rs.getString("tipo"));
				result.setVersion(rs.getDouble("version"));
				result.setRuta(rs.getString("ruta"));
				result.setNombreArch(rs.getString("nombrearch"));
				result.setFechaCreacion(rs.getInt("fechacreacion"));
				result.setNombreUsuario(rs.getString("nombreUser"));
				result.setAprobadoSDI(rs.getBoolean("aprobadoSDI"));
				if (rs.wasNull()) {
					result.setAprobadoSDI(null);
				}
				result.setPrioridad(rs.getInt("prioridad"));
				result.setUsuarioUpdate(rs.getString("userUpdate"));
				result.setFechaUpdate(rs.getInt("dateUpdate"));

				lista.add(new CdiDocumentBO(result));
			}
			rs.close();
		} catch (SQLException sqlE) {
			try {
				log.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
			throw sqlE;
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
		return lista;
	}

	public static ArrayList<ProveedorXplaneadorBO> dameProveedoresXPlaneador()
			throws SQLException, ClassNotFoundException {

		ArrayList<ProveedorXplaneadorBO> lista = new ArrayList<ProveedorXplaneadorBO>();
		Connection con = null;

		try {
			con = ConexionDB.dameConexion();

			ResultSet rs = null;
			StringBuffer query = new StringBuffer();
			Statement st = null;

			query.append("SELECT id,planeadorId,nombrePlaneador,proveedor ");
			query.append(" FROM  cdiProveedorXplaneador ORDER BY nombreplaneador");

			st = con.createStatement();
			rs = st.executeQuery(query.toString());

			while (rs.next()) {
				ProveedorXplaneadorBO result = new ProveedorXplaneadorBO();
				result.setId(rs.getInt("id"));
				result.setIdPlaneador(rs.getString("planeadorId"));
				result.setNombrePlaneador(rs.getString("nombrePlaneador"));
				result.setProveedoresStr(rs.getString("proveedor"));

				lista.add(result);
			}
			rs.close();
			ConexionDB.devuelveConexion(con);

		} catch (SQLException sqlE) {
			try {
				log.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
			throw sqlE;
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
		return lista;
	}

	public static List<SarBO> dameSARsParaReporte() throws SQLException, ClassNotFoundException {

		List<SarBO> lista = new ArrayList<SarBO>();
		Connection con = null;

		try {
			con = ConexionDB.dameConexion();

			ResultSet rs = null;
			StringBuffer query = new StringBuffer();
			Statement st = null;

			query.append("select folio, fechaCreacion, proveedor, consolidado, status, folioConsolidado, ");
			query.append("aprobadoProveedor, aprobadoSDI, fueModificadoProveedor, aceptadoConDiferencias, ");
			query.append("tinyFecIniPlanning, tinyFecIniShipping, tinyFecIniBooking, tinyFecIniConsol, ");
			query.append("fechaUltimoRechazo, usuarioUltimoRechazoAceptacion, comentarioCancelacion, ");
			query.append("fechaUltAprobRechazo, usuarioApruebaRechaza ");
			query.append("from cdiSar");

			st = con.createStatement();
			rs = st.executeQuery(query.toString());

			while (rs.next()) {
				SarBO result = new SarBO();
				result.setFolio(rs.getInt("folio"));
				result.setCreationDate(rs.getInt("fechaCreacion"));
				result.setProveedor(rs.getString("proveedor"));
				result.setConsolidado(rs.getBoolean("consolidado"));
				result.setStatus(rs.getInt("status"));
				result.setFolioConsolidado(rs.getInt("folioConsolidado"));
				result.setAprobadoProveedor(rs.getBoolean("aprobadoProveedor"));
				result.setAprobadoSDI(rs.getBoolean("aprobadoSDI"));
				result.setModificadoProveedor(rs.getBoolean("fueModificadoProveedor"));
				result.setAceptadoConDiferencias(rs.getBoolean("aceptadoConDiferencias"));
				result.setTinyFecIniPlanning(rs.getInt("tinyFecIniPlanning"));
				result.setTinyFecIniShipping(rs.getInt("tinyFecIniShipping"));
				result.setTinyFecIniBooking(rs.getInt("tinyFecIniBooking"));
				result.setTinyFecIniConsolidados(rs.getInt("tinyFecIniConsol"));
				result.setFechaUltimoRechazo(rs.getInt("fechaUltimoRechazo"));
				result.setUsuarioAceptoRechazoSAR(rs.getString("usuarioUltimoRechazoAceptacion"));
				result.setComentarioCancelacion(rs.getString("comentarioCancelacion"));
				result.setFechaUltimaAprobacionRechazo(rs.getInt("fechaUltAprobRechazo"));
				result.setUsuarioApruebaRechaza(rs.getString("usuarioApruebaRechaza"));
				lista.add(result);
			}
			rs.close();
			ConexionDB.devuelveConexion(con);

		} catch (SQLException sqlE) {
			try {
				log.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
			throw sqlE;
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
		return lista;
	}

	/**
	 * Metodo para validar si una PO pertenece a un proveedor
	 * 
	 * @return
	 */
	public static boolean validaPOProveedor(String usuario, String po) throws SQLException, ClassNotFoundException {
		boolean result = false;
		Connection con = null;
		GregorianCalendar gc = new GregorianCalendar();
		gc.add(Calendar.MONTH, -6);
		int fechaDesde = FuncionesComunesPLI.gregorianCalendar2int(gc);
		try {
			con = ConexionDB.dameConexion();

			ResultSet rs = null;
			StringBuffer query = new StringBuffer();
			PreparedStatement st = null;

			query.append("select a.folio, a.aprobadoProveedor, a.fueModificadoProveedor, a.aceptadoConDiferencias");
			query.append(" from cdisar a left outer join cdisardetalle b on a.folio = b.folio");
			query.append(" where a.proveedor = ? and b.po = ? and a.aprobadoProveedor = 1 and a.fechaCreacion >= ?");
			query.append(
					" and (a.fueModificadoProveedor = 0 or (a.fueModificadoProveedor = 1 and a.aceptadoConDiferencias = 1))");

			st = con.prepareStatement(query.toString());
			st.setString(1, usuario);
			st.setString(2, po);
			st.setInt(3, fechaDesde);
			rs = st.executeQuery();

			result = rs.next();

			rs.close();
			ConexionDB.devuelveConexion(con);

		} catch (SQLException sqlE) {
			try {
				log.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
		return result;
	}

	/**
	 * Metodo para validar si una PO pertenece a un proveedor
	 * 
	 * @return
	 */
	public static SarBO dameTotalesSAR(SarBO bean) throws SQLException, ClassNotFoundException {
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();

			ResultSet rs = null;
			StringBuffer query = new StringBuffer();
			PreparedStatement st = null;

			query.append(
					"select folio, SUM(PesoProveedor) totalPeso, SUM(VolumenProveedor) volumenProveedor from cdisardetalle where folio = ? group by folio");

			st = con.prepareStatement(query.toString());
			st.setInt(1, bean.getFolio());
			rs = st.executeQuery();

			if (rs.next()) {
				bean.setPeso(rs.getDouble("totalPeso"));
				bean.setVolumen(rs.getDouble("volumenProveedor"));
			}

			rs.close();
			ConexionDB.devuelveConexion(con);

		} catch (SQLException sqlE) {
			try {
				log.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
		return bean;
	}

	/**
	 * Metodo para consultar los Chats de un SAR
	 * 
	 * @return
	 */
	public static List<BeanSarChat> consultaChatsPorFolio(String sFolio) throws SQLException, ClassNotFoundException {
		List<BeanSarChat> lstSar = new ArrayList<BeanSarChat>();
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();

			ResultSet rs = null;
			StringBuffer query = new StringBuffer();
			PreparedStatement st = null;

			query.append("select id, mensaje, usuario, fecha, fechaMillis, folio, esProveedor");
			query.append(" from cdiSARChat where folio = ?");

			st = con.prepareStatement(query.toString());
			st.setString(1, sFolio);
			rs = st.executeQuery();

			while (rs.next()) {
				int id = rs.getInt("id");
				String mensaje = rs.getString("mensaje");
				String usuario = rs.getString("usuario");
				int fecha = rs.getInt("fecha");
				long fechaMillis = rs.getLong("fechaMillis");
				boolean proveedor = rs.getBoolean("esProveedor");
				String folio = rs.getString("folio");
				BeanSarChat beanChat = new BeanSarChat();
				beanChat.setId(id);
				beanChat.setMensaje(mensaje);
				beanChat.setUsuario(usuario);
				beanChat.setFecha(fecha);
				beanChat.setFechaMillis(fechaMillis);
				beanChat.setFolio(folio);
				beanChat.setProveedor(proveedor);
				lstSar.add(beanChat);
			}

			rs.close();
			ConexionDB.devuelveConexion(con);

		} catch (SQLException sqlE) {
			try {
				log.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
		return lstSar;
	}

	/**
	 * Metodo para consultar los Chats de un SAR
	 * 
	 * @return
	 */
	public static boolean insertaMensajeChat(BeanSarChat bean) throws SQLException, ClassNotFoundException {
		boolean result = false;
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();

			int regs = 0;
			StringBuffer query = new StringBuffer();
			PreparedStatement st = null;

			query.append("INSERT INTO cdiSARChat (mensaje, usuario, fecha, fechaMillis, folio, esProveedor)");
			query.append(" VALUES (?,?,?,?,?,?)");

			st = con.prepareStatement(query.toString());
			st.setString(1, bean.getMensaje());
			st.setString(2, bean.getUsuario());
			st.setInt(3, bean.getFecha());
			st.setLong(4, bean.getFechaMillis());
			st.setString(5, bean.getFolio());
			st.setBoolean(6, bean.isProveedor());
			regs = st.executeUpdate();

			if (regs > 0) {
				result = true;
			}

			ConexionDB.devuelveConexion(con);

		} catch (SQLException sqlE) {
			try {
				log.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
		return result;
	}

	public static boolean insertaDetalleOtros(SarDetalleBO detalle) {
		Connection con = null;
		PreparedStatement pst = null;

		StringBuffer sql = new StringBuffer();
		sql.append("INSERT INTO cdiSARDetalleOthers ");
		sql.append("            (folio ");
		sql.append("             , po ");
		sql.append("             , pootheritem ");
		sql.append("             , posicion ");
		sql.append("             , descripcion ");
		sql.append("             , cantidad ");
		sql.append("             , pesoproveedor ");
		sql.append("             , volumenproveedor ");
		sql.append("             , preciounitario ");
		sql.append("             , condicionPago ");
		sql.append("             , unidadMedida) ");
		sql.append(" VALUES      (? ,? ,? ,? ,? ,? ,? ,? ,? ,?, ?) ");

		boolean exito = false;

		try {
			con = ConexionDB.dameConexion();
			pst = con.prepareStatement(sql.toString());
			int i = 1;
			pst.setInt(i, detalle.getFolio());
			pst.setString(++i, detalle.getPo());

			String po_item = detalle.getPoOtherItem();
			if (UtilsString.isStringValida(po_item)) {
				pst.setString(++i, po_item);
			} else {
				pst.setNull(++i, Types.VARCHAR);
			}
			pst.setInt(++i, detalle.getPosicion());
			pst.setString(++i, detalle.getDescripcion());
			pst.setInt(++i, detalle.getCantidad());
			pst.setDouble(++i, detalle.getPesoProveedor());
			pst.setDouble(++i, detalle.getVolumenProveedor());
			BigDecimal precioUnitario = detalle.getPrecioUnitario();
			if (precioUnitario == null || precioUnitario.compareTo(BigDecimal.ZERO) != 1) {
				pst.setNull(++i, Types.DECIMAL);
			} else {
				pst.setBigDecimal(++i, precioUnitario);
			}

			String po_item_condicion_pago = detalle.getPoOtherItemCondicionPago();
			if (UtilsString.isStringValida(po_item_condicion_pago)) {
				pst.setString(++i, po_item_condicion_pago);
			} else {
				pst.setNull(++i, Types.VARCHAR);
			}
			pst.setString(++i, detalle.getUnidaMedida());
			exito = pst.executeUpdate() == 1;
		} catch (SQLException e) {
			e.printStackTrace();
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} catch (Exception e) {
			e.printStackTrace();
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (SQLException e) {
				log.error(e.getMessage(), e);
			}
		}

		return exito;
	}

	/**
	 * Metodo para consultar los items no relacionados a una PO dentro de un SAR
	 * 
	 * @return
	 */
	public static List<SarDetalleBO> consultaDetalleOtros(String sFolio) throws ClassNotFoundException {
		List<SarDetalleBO> lstSar = new ArrayList<SarDetalleBO>();
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();

			ResultSet rs = null;
			StringBuffer query = new StringBuffer();
			PreparedStatement st = null;

			query.append("select folio, po, posicion, descripcion, cantidad, pesoProveedor, volumenProveedor,");
			query.append(
					" cartones,pesobruto,pesoneto,cubicaje,poOtherItem,condicionPago,precioUnitario, unidadMedida");
			query.append(" from cdiSARDetalleOthers where folio = ?");
			st = con.prepareStatement(query.toString());
			st.setString(1, sFolio);
			rs = st.executeQuery();

			while (rs.next()) {
				int folio = rs.getInt("folio");
				String po = rs.getString("po");
				String poOtherItem = rs.getString("poOtherItem");
				if (UtilsString.isStringValida(poOtherItem)) {
					poOtherItem = poOtherItem.trim();
				}
				int posicion = rs.getInt("posicion");
				String descripcion = rs.getString("descripcion");
				int cantidad = rs.getInt("cantidad");
				double peso = rs.getDouble("pesoProveedor");
				double volumen = rs.getDouble("volumenProveedor");
				BigDecimal precio = rs.getBigDecimal("precioUnitario");
				if (rs.wasNull()) {
					precio = null;
				}
				BigDecimal pesoBruto = rs.getBigDecimal("pesobruto");
				BigDecimal pesoNetp = rs.getBigDecimal("pesoneto");
				BigDecimal cubicaje = rs.getBigDecimal("cubicaje");
				int cartones = rs.getInt("cartones");

				String condicionPago = rs.getString("condicionPago");
				String unidadMedida = rs.getString("unidadMedida");

				SarDetalleBO beanChat = new SarDetalleBO();
				beanChat.setFolio(folio);
				beanChat.setPo(po.trim());
				beanChat.setPosicion(posicion);
				beanChat.setDescripcion(descripcion);
				beanChat.setCantidad(cantidad);
				beanChat.setPesoProveedor(peso);
				beanChat.setVolumenProveedor(volumen);
				beanChat.setCartones(cartones);
				beanChat.setPesoBrutoPKL(pesoBruto);
				beanChat.setPesoNetoPKL(pesoNetp);
				beanChat.setCubicajePKL(cubicaje);
				beanChat.setPoOtherItem(poOtherItem);
				beanChat.setCondicionPago(condicionPago);
				beanChat.setPrecioUnitario(precio);
				beanChat.setUnidaMedida(unidadMedida);
				beanChat.setValorEmbarque(precio == null ? null : precio.multiply(new BigDecimal(cantidad)));
				lstSar.add(beanChat);
			}

			rs.close();
			ConexionDB.devuelveConexion(con);

		} catch (SQLException sqlE) {
			try {
				log.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
		return lstSar;
	}

	public static boolean eliminaPosicionOtros(int folio, String po, int posicion) {
		Connection con = null;
		Statement st = null;
		int res = 0;
		try {
			con = ConexionDB.dameConexion();
			st = con.createStatement();

			String delete = "DELETE FROM cdiSARDetalleOthers WHERE folio = " + folio + " AND po = '" + po
					+ "' AND posicion = " + posicion;
			res = st.executeUpdate(delete);

			log.info("[Eliminar posicion Others] OK!! SAR: " + folio + " po: " + po + " pos: " + posicion);
		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				log.error("[Eliminar posicion Others] Error SAR: " + folio + " po: " + po + " pos: " + posicion
						+ " causa: " + ex.getMessage(), ex);
			}
			log.error("[Eliminar posicion Others] Error SAR: " + folio + " po: " + po + " pos: " + posicion + " causa:"
					+ e.getMessage(), e);
		} catch (Exception e) {
			e.printStackTrace();
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
		return (res > 0);
	}

	@Deprecated // utilizar actualizaDetalleOtrosDinamico
	public static boolean actualizaDetalleOtros(int folio, String po, int posicion, int cantidad, double peso,
			double volumen) {
		Connection con = null;
		PreparedStatement pst = null;
		String update = "UPDATE cdiSARDetalleOthers SET cantidad = ?, pesoProveedor = ?, volumenProveedor = ?"
				+ " WHERE folio = ? AND po = ? AND posicion = ?";
		boolean exito = false;

		try {
			con = ConexionDB.dameConexion();
			pst = con.prepareStatement(update);

			pst.setInt(1, cantidad);
			pst.setDouble(2, peso);
			pst.setDouble(3, volumen);
			pst.setInt(4, folio);
			pst.setString(5, po);
			pst.setInt(6, posicion);

			exito = pst.executeUpdate() == 1;

			ConexionDB.devuelveConexion(con);

		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} catch (Exception e) {
			e.printStackTrace();
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}

		return exito;
	}

	public static boolean actualizaDetalleOtrosDinamico(SarDetalleBO det) {
		Connection con = null;
		PreparedStatement pst = null;
		StringBuffer update = new StringBuffer();
		update.append(" UPDATE cdiSARDetalleOthers SET  folio = ").append(det.getFolio());
		if (det.getCartones() != null) {
			update.append(" ,cartones = ? ");
		}
		if (det.getPesoNetoPKL() != null) {
			update.append(" ,pesoNeto = ? ");
		}
		if (det.getPesoBrutoPKL() != null) {
			update.append(" ,pesoBruto = ? ");
		}
		if (det.getCubicajePKL() != null) {
			update.append(" ,cubicaje = ? ");
		}

		update.append(" WHERE folio = ? AND po = ? AND posicion = ? ");

		boolean exito = false;

		try {
			con = ConexionDB.dameConexion();
			pst = con.prepareStatement(update.toString());
			int cont = 1;
			if (det.getCartones() != null) {
				pst.setInt(cont++, det.getCartones());
			}
			if (det.getPesoNetoPKL() != null) {
				pst.setBigDecimal(cont++, det.getPesoNetoPKL());
			}
			if (det.getPesoBrutoPKL() != null) {
				pst.setBigDecimal(cont++, det.getPesoBrutoPKL());
			}
			if (det.getCubicajePKL() != null) {
				pst.setBigDecimal(cont++, det.getCubicajePKL());
			}

			pst.setInt(cont++, det.getFolio());
			pst.setString(cont++, det.getPo());
			pst.setInt(cont++, det.getPosicion());

			exito = pst.executeUpdate() == 1;

			ConexionDB.devuelveConexion(con);

		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} catch (Exception e) {
			e.printStackTrace();
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}

		return exito;
	}

	public static HashMap<Integer, String> selectMapaErroresPorPOPosicion()
			throws SQLException, ClassNotFoundException {

		HashMap<Integer, String> mapa = new HashMap<Integer, String>();
		Connection con = null;

		try {
			con = ConexionDB.dameConexion();

			ResultSet rs = null;
			StringBuffer query = new StringBuffer();
			Statement st = null;

			query.append("SELECT id, referencia, descripcion ");
			query.append(" FROM cdiCatalogoErroresPorPO ");

			st = con.createStatement();
			rs = st.executeQuery(query.toString());

			while (rs.next()) {
				mapa.put(rs.getInt("id"), rs.getString("referencia"));
			}
			rs.close();
			ConexionDB.devuelveConexion(con);

		} catch (SQLException sqlE) {
			try {
				log.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
			throw sqlE;
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
		return mapa.size() > 0 ? mapa : null;
	}

	public static boolean insertaOrdenConRedFlag(PoRedFlag poRedFlag) {
		Connection con = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		StringBuilder insert = new StringBuilder();
		insert.append(
				"INSERT INTO cdiPosRedFlag (po, proveedor, fechaCreacion, usuarioBloquea, comentarioProveedor) VALUES (?,?,?,?,?)");
		StringBuilder select = new StringBuilder();
		select.append("SELECT id");
		select.append(" FROM cdiPosRedFlag where po = ?");
		select.append(" and proveedor = ? and fechaRespuesta is NULL");
		StringBuilder insertDetalle = new StringBuilder();
		insertDetalle.append("INSERT INTO cdiPosRedFlagDetalle (idRedFlag, po, posicion,");
		insertDetalle.append(" material, planeador, centro, cantidad, peso, volumen, fechaProforma)");
		insertDetalle.append(" VALUES (?,?,?,?,?,?,?,?,?,?)");
		boolean exito = false;
		String idRedFlag = "";
		try {
			con = ConexionDB.dameConexion();
			pst = con.prepareStatement(insert.toString());
			pst.setString(1, poRedFlag.getPo());
			pst.setString(2, poRedFlag.getProveedor());
			pst.setInt(3, poRedFlag.getFechaCreacion());
			pst.setString(4, poRedFlag.getUsuarioBloquea());
			pst.setString(5, poRedFlag.getComentarioProveedor());
			exito = pst.executeUpdate() > 0;
			pst.clearParameters();
			if (exito) {
				pst = con.prepareStatement(select.toString());
				pst.setString(1, poRedFlag.getPo());
				pst.setString(2, poRedFlag.getProveedor());
				rs = pst.executeQuery();
				if (rs.next()) {
					idRedFlag = rs.getString("id");
					rs.close();
					for (SARDetalle detPoRedFlag : poRedFlag.getPoRedFlagDetalle()) {
						pst.clearParameters();
						pst = con.prepareStatement(insertDetalle.toString());
						pst.setString(1, idRedFlag);
						pst.setString(2, detPoRedFlag.getPo());
						pst.setInt(3, detPoRedFlag.getPosicion());
						pst.setInt(4, detPoRedFlag.getMaterial());
						pst.setString(5, detPoRedFlag.getPlaneador());
						pst.setString(6, detPoRedFlag.getCentro());
						pst.setInt(7, detPoRedFlag.getCantidad());
						pst.setDouble(8, detPoRedFlag.getPesoPO());
						pst.setDouble(9, detPoRedFlag.getVolumenPO());
						pst.setInt(10, detPoRedFlag.getFechaProforma());
						pst.executeUpdate();
					}
				}
			}
			ConexionDB.devuelveConexion(con);

		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} catch (Exception e) {
			e.printStackTrace();
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (SQLException e) {
				log.error(e.getMessage(), e);
			}
		}

		return exito;
	}

	public static Map<String, PoRedFlag> dameOrdenesConProblemas(String id) throws ClassNotFoundException {
		Map<String, PoRedFlag> mapaOrdenesRedFlag = new HashMap<String, PoRedFlag>();
		Connection con = null;

		try {
			con = ConexionDB.dameConexion();

			ResultSet rs = null;
			ResultSet rsDetalle = null;
			StringBuffer select = new StringBuffer();
			StringBuffer selectDetalle = new StringBuffer();
			PreparedStatement st = null;
			PreparedStatement stDetalle = null;

			select.append("SELECT id, po, proveedor, fechaCreacion, usuarioBloquea, comentarioProveedor,");
			select.append(" fechaRespuesta, usuarioRespuesta, comentarioPlaneador");
			select.append(" FROM cdiPosRedFlag");
			if (id != null && !"".equals(id)) {
				select.append(" WHERE id = ?");
			}
			selectDetalle.append(
					"SELECT idRedFlag, po, posicion, material, planeador, centro, cantidad, peso, volumen, fechaProforma");
			selectDetalle.append(" FROM cdiPosRedFlagDetalle where idRedFlag = ?");

			st = con.prepareStatement(select.toString());
			if (id != null && !"".equals(id)) {
				st.setString(1, id);
			}
			rs = st.executeQuery();

			while (rs.next()) {
				PoRedFlag bean = new PoRedFlag();
				List<SARDetalle> lstDetRedFlag = new ArrayList<SARDetalle>();
				bean.setId(rs.getInt("id"));
				bean.setPo(rs.getString("po").trim());
				bean.setProveedor(rs.getString("proveedor"));
				bean.setFechaCreacion(rs.getInt("fechaCreacion"));
				bean.setUsuarioBloquea(rs.getString("usuarioBloquea"));
				bean.setComentarioProveedor(rs.getString("comentarioProveedor"));
				bean.setFechaRespuesta(rs.getInt("fechaRespuesta"));
				bean.setUsuarioRespuesta(rs.getString("usuarioRespuesta"));
				bean.setComentarioPlaneador(rs.getString("comentarioPlaneador"));
				stDetalle = con.prepareStatement(selectDetalle.toString());
				stDetalle.setInt(1, rs.getInt("id"));
				rsDetalle = stDetalle.executeQuery();
				while (rsDetalle.next()) {
					SARDetalle detRedFlag = new SarDetalleBO();
					detRedFlag.setFolio(rsDetalle.getInt("idRedFlag"));
					detRedFlag.setPo(rsDetalle.getString("po").trim());
					detRedFlag.setPosicion(rsDetalle.getInt("posicion"));
					detRedFlag.setMaterial(rsDetalle.getInt("material"));
					detRedFlag.setPlaneador(rsDetalle.getString("planeador").trim());
					detRedFlag.setCentro(rsDetalle.getString("centro").trim());
					detRedFlag.setCantidad(rsDetalle.getInt("cantidad"));
					detRedFlag.setPesoPO(rsDetalle.getDouble("peso"));
					detRedFlag.setVolumenPO(rsDetalle.getDouble("volumen"));
					detRedFlag.setFechaProforma(rsDetalle.getInt("fechaProforma"));
					lstDetRedFlag.add(detRedFlag);
				}
				rsDetalle.close();
				stDetalle.close();
				bean.setPoRedFlagDetalle(lstDetRedFlag);
				mapaOrdenesRedFlag.put(rs.getString("po"), bean);
			}
			rs.close();
			st.close();
			ConexionDB.devuelveConexion(con);

		} catch (SQLException sqlE) {
			try {
				log.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
		return mapaOrdenesRedFlag.size() > 0 ? mapaOrdenesRedFlag : null;
	}

	public static boolean actualizaPOsRedFlag(PoRedFlag bean) {
		Connection con = null;
		PreparedStatement pst = null;
		String update = "UPDATE cdiPosRedFlag SET fechaRespuesta = ?, usuarioRespuesta = ?, comentarioPlaneador = ?"
				+ " WHERE id = ?";
		boolean exito = false;

		try {
			con = ConexionDB.dameConexion();
			pst = con.prepareStatement(update);

			pst.setInt(1, bean.getFechaRespuesta());
			pst.setString(2, bean.getUsuarioRespuesta());
			pst.setString(3, bean.getComentarioPlaneador());
			pst.setInt(4, bean.getId());

			exito = pst.executeUpdate() > 0;

			ConexionDB.devuelveConexion(con);

		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} catch (Exception e) {
			e.printStackTrace();
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}

		return exito;
	}

	public static ArrayList<Integer> dameFoliosSinBookingRegistrado(int diasMenos) throws ServletException {
		ArrayList<Integer> resultado = new ArrayList<Integer>();
		Connection conexion = null;
		try {
			conexion = ConexionDB.dameConexion();
			Statement stmt = conexion.createStatement();
			/// genero el dia de hoy y contra ese voy a validar
			GregorianCalendar fecha = new GregorianCalendar();
			fecha.add(Calendar.DATE, -diasMenos);
			int diasComparar = FuncionesComunesPLI.gregorianCalendar2int(fecha);
			StringBuffer query = new StringBuffer();
			query.append("SELECT folio, tinyFecIniBooking ");
			query.append(" FROM cdisar WITH (NOLOCK) WHERE status = 3  AND (booking IS NULL OR REPLACE(booking,' ', '') = '')");
			//query.append(" AND  tinyFecIniBooking < " + diasComparar);
			ResultSet rs = stmt.executeQuery(query.toString());
			while (rs.next()) {
				resultado.add(rs.getInt("folio"));
			}
			stmt.close();
		} catch (SQLException sqle) {
			try {
				ConexionDB.renuevaConexion(conexion);
			} catch (SQLException e2) {
				log.error(e2.getMessage());
				throw new ServletException("Error en la base de datos");
			}
		} catch (Exception e) {
			try {
				ConexionDB.devuelveConexion(conexion);
			} catch (SQLException e2) {
				log.error(e2.getMessage());
				throw new ServletException("Error en la base de datos");
			}
		} finally {
			try {
				ConexionDB.devuelveConexion(conexion);
			} catch (Exception sqlEx2) {
				log.error("[dameFoliosSinBookingRegistrado]" + sqlEx2.getMessage());
			}
		}
		return resultado;
	}

	public static boolean insertaItinerarioNaviera(BeanItinerarioNaviera data, int length) {
		Connection con = null;
		PreparedStatement pst = null;
		StringBuilder insert = new StringBuilder();
		insert.append(
				"INSERT INTO cdiItinerariosNaviera (folio, timeMillis, creationDate, imgData, sarStatus, userName)");
		insert.append(" VALUES (?,?,?,?,?,?)");

		boolean exito = false;

		try {
			con = ConexionDB.dameConexion();
			pst = con.prepareStatement(insert.toString());
			pst.setInt(1, data.getFolio());
			pst.setLong(2, data.getTimeMillis());
			pst.setInt(3, data.getCreationDate());
			pst.setBinaryStream(4, data.getImgData(), length);
			pst.setInt(5, data.getSarStatus());
			pst.setString(6, data.getUser());
			exito = pst.executeUpdate() == 1;
			ConexionDB.devuelveConexion(con);
		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} catch (Exception e) {
			e.printStackTrace();
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} finally {
			try {
				pst.close();
				ConexionDB.devuelveConexion(con);
			} catch (SQLException e) {
				log.error(e.getMessage(), e);
			}
		}
		return exito;
	}

	public static List<BeanItinerarioNaviera> consultaItinerarioNavieras(String folioSearch) {
		Connection con = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		StringBuilder select = new StringBuilder();
		select.append("select folio, timeMillis, creationDate, imgData, sarStatus, userName");
		select.append(" FROM cdiItinerariosNaviera WHERE folio = ?");

		List<BeanItinerarioNaviera> lstItinerariosNaviera = new ArrayList<BeanItinerarioNaviera>();

		try {
			con = ConexionDB.dameConexion();
			pst = con.prepareStatement(select.toString());
			pst.setString(1, folioSearch);
			rs = pst.executeQuery();
			while (rs.next()) {
				Integer folio = rs.getInt("folio");
				Long timeMillis = rs.getLong("timeMillis");
				Integer creationDate = rs.getInt("creationDate");
				byte[] byteArr = rs.getBytes("imgData");
				InputStream imgData = new ByteArrayInputStream(byteArr);
				Integer sarStatus = rs.getInt("sarStatus");
				String userName = rs.getString("userName");
				BeanItinerarioNaviera itinerarioNaviera = new BeanItinerarioNaviera();
				itinerarioNaviera.setFolio(folio);
				itinerarioNaviera.setTimeMillis(timeMillis);
				itinerarioNaviera.setCreationDate(creationDate);
				itinerarioNaviera.setImgData(imgData);
				itinerarioNaviera.setSarStatus(sarStatus);
				itinerarioNaviera.setUser(userName);
				lstItinerariosNaviera.add(itinerarioNaviera);
			}
		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} catch (Exception e) {
			e.printStackTrace();
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} finally {
			try {
				rs.close();
				pst.close();
				ConexionDB.devuelveConexion(con);
			} catch (SQLException e) {
				log.error(e.getMessage(), e);
			}
		}
		return lstItinerariosNaviera;
	}

	public static boolean insertaDatosMRP(List<BeanMRPData> lstMrpData) {
		Connection con = null;
		PreparedStatement pst = null;
		StringBuilder delete = new StringBuilder();
		delete.append("DELETE cdiMRPFiles where folio = ? AND po = ? AND posicion = ?");

		StringBuilder insert = new StringBuilder();
		insert.append("INSERT INTO cdiMRPFiles (folio, po, posicion, material, height, width, length,");
		insert.append(" volume, weight, innerBox, masterCarton, proveedor, fechaRegistro, usuarioCarga)");
		insert.append(" VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)");

		boolean exito = false;

		try {
			con = ConexionDB.dameConexion();
			con.setAutoCommit(false);
			pst = con.prepareStatement(delete.toString());
			for (BeanMRPData data : lstMrpData) {
				pst.setInt(1, data.getFolio());
				pst.setString(2, data.getPo());
				pst.setInt(3, data.getPosicion());
				pst.executeUpdate();
			}
			pst.close();
			pst = con.prepareStatement(insert.toString());
			for (BeanMRPData data : lstMrpData) {
				pst.setInt(1, data.getFolio());
				pst.setString(2, data.getPo());
				pst.setInt(3, data.getPosicion());
				pst.setInt(4, data.getMaterial());
				pst.setDouble(5, data.getHeight());
				pst.setDouble(6, data.getWidth());
				pst.setDouble(7, data.getLength());
				pst.setDouble(8, data.getVolume());
				pst.setDouble(9, data.getWeight());
				pst.setInt(10, data.getInner());
				pst.setInt(11, data.getMaster());
				pst.setString(12, data.getCveProveedor());
				pst.setInt(13, data.getFechaRegistro());
				pst.setString(14, data.getUsuarioCarga());
				exito = pst.executeUpdate() == 1;
				if (exito) {
					con.commit();
				} else {
					con.rollback();
					break;
				}
			}
			ConexionDB.devuelveConexion(con);
		} catch (SQLException e) {
			try {
				con.rollback();
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} catch (Exception e) {
			e.printStackTrace();
			try {
				con.rollback();
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} finally {
			try {
				con.setAutoCommit(true);
				pst.close();
				ConexionDB.devuelveConexion(con);
			} catch (SQLException e) {
				log.error(e.getMessage(), e);
			}
		}
		return exito;
	}

	public static List<BeanMRPData> consultaDatosMRP(BeanMRPData bean) {
		DAOUtils utils = new DAOUtils();
		Connection con = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		List<BeanMRPData> lstMrpData = new ArrayList<BeanMRPData>();

		StringBuilder select = new StringBuilder();
		select.append("select folio, po, posicion, material, height, width, length,");
		select.append(" volume, weight, innerBox, masterCarton, proveedor, fechaRegistro, usuarioCarga");
		select.append(" FROM  cdiMRPFiles WHERE 1=1 ");

		try {
			con = ConexionDB.dameConexion();

			utils.setSelect(true);

			if (bean.getFolio() != null) {
				select.append(utils.ajustaColumna(" AND  folio = ? "));
			}
			if (bean.getPo() != null) {
				select.append(utils.ajustaColumna(" AND  po = ? "));
			}
			if (bean.getPosicion() != null) {
				select.append(utils.ajustaColumna(" AND  posicion = ? "));
			}
			pst = con.prepareStatement(select.toString());

			int cont = 1;

			utils.inicializaQuery(select.toString());

			if (bean.getFolio() != null) {
				utils.ajustaParametro(cont++, pst, bean.getFolio(), Integer.class);
			}
			if (bean.getPo() != null) {
				utils.ajustaParametro(cont++, pst, bean.getPo(), String.class);
			}
			if (bean.getPosicion() != null) {
				utils.ajustaParametro(cont++, pst, bean.getPosicion(), Integer.class);
			}
			rs = pst.executeQuery();
			while (rs.next()) {
				BeanMRPData mrpData = new BeanMRPData();
				Integer detFolio = rs.getInt("folio");
				String po = rs.getString("po");
				Integer posicion = rs.getInt("posicion");
				Integer material = rs.getInt("material");
				Double height = rs.getDouble("height");
				Double width = rs.getDouble("width");
				Double length = rs.getDouble("length");
				Double volume = rs.getDouble("volume");
				Double weight = rs.getDouble("weight");
				Integer inner = rs.getInt("innerBox");
				Integer master = rs.getInt("masterCarton");
				String cveProveedor = rs.getString("proveedor");
				Integer fechaRegistro = rs.getInt("fechaRegistro");
				String usuarioCarga = rs.getString("usuarioCarga");
				mrpData.setFolio(detFolio);
				mrpData.setPo(po);
				mrpData.setPosicion(posicion);
				mrpData.setMaterial(material);
				mrpData.setHeight(height);
				mrpData.setWidth(width);
				mrpData.setLength(length);
				mrpData.setVolume(volume);
				mrpData.setWeight(weight);
				mrpData.setInner(inner);
				mrpData.setMaster(master);
				mrpData.setCveProveedor(cveProveedor);
				mrpData.setFechaRegistro(fechaRegistro);
				mrpData.setUsuarioCarga(usuarioCarga);
				lstMrpData.add(mrpData);
			}
		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} catch (Exception e) {
			e.printStackTrace();
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} finally {
			try {
				rs.close();
				pst.close();
				ConexionDB.devuelveConexion(con);
			} catch (SQLException e) {
				log.error(e.getMessage(), e);
			}
		}
		return lstMrpData;
	}

	/**
	 * Hace la busqueda del historico de consolidados pero por el campo
	 * "sarsEnContenedor" aqui los datos vienen en cadena separada por ",".
	 * 
	 * 
	 * @param bean
	 * @return
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 */
	public static ArrayList<SARConsolidadosHistorico> selectConsolidadoHistoricoByContenidoEnCC(String folioABuscar)
			throws SQLException, ClassNotFoundException {

		ArrayList<SARConsolidadosHistorico> listaSAR = new ArrayList<SARConsolidadosHistorico>();

		Connection con = null;

		try {
			con = ConexionDB.dameConexion();

			ResultSet rs = null;
			StringBuffer query = new StringBuffer();
			Statement st = null;

			query.append(
					"SELECT     id, folio, puertoSalida, naviera, fechaEmbarque, tipoContenedor, prioridad, barcoSugerido, viaje,  ");
			query.append(" puertoDescarga, contenedor, booking, etdFinal, transporte,  ");
			query.append(" comentarioConsolidado, sarsEnContenedor,fechaModificacion, ");
			query.append(" usuarioModificacion,retrasoProveedor,tipoProducto,tipoRetraso ");
			query.append(" FROM    cdi_consolidadoHistorico ");
			query.append(" WHERE   sarsEnContenedor like '%");
			query.append(folioABuscar);
			query.append("%'");
			query.append(" ORDER BY id desc ");

			st = con.createStatement();
			rs = st.executeQuery(query.toString());

			while (rs.next()) {
				SARConsolidadosHistorico tmp = new SARConsolidadosHistorico();
				tmp.setId(rs.getInt("id"));
				tmp.setFolio(rs.getInt("folio"));
				tmp.setPuertoSalida(rs.getString("puertoSalida"));
				tmp.setNaviera(rs.getInt("naviera"));
				tmp.setFechaEmbarque(rs.getInt("fechaEmbarque"));
				tmp.setTipoContenedor(rs.getInt("tipoContenedor"));
				tmp.setPrioridad(rs.getInt("prioridad"));
				tmp.setBarcoSugerido(rs.getString("barcoSugerido"));
				tmp.setViaje(rs.getString("viaje"));
				tmp.setPuertoDescarga(rs.getString("puertoDescarga"));
				tmp.setContenedor(rs.getString("contenedor"));
				tmp.setBooking(rs.getString("booking"));
				tmp.setEtdReal(rs.getInt("etdFinal"));
				tmp.setTransporte(rs.getInt("transporte"));
				tmp.setComentarioConsol(rs.getString("comentarioConsolidado"));
				tmp.setPOsEnConsolidado(rs.getString("sarsEnContenedor"));
				tmp.setFechaModficacion(rs.getInt("fechaModificacion"));
				tmp.setUsuarioMof(rs.getString("usuarioModificacion"));
				tmp.setRetrasoProveedor(rs.getString("retrasoProveedor"));
				tmp.setTipoProducto(rs.getString("tipoProducto"));
				tmp.setTipoRetraso(rs.getInt("tipoRetraso"));

				listaSAR.add(tmp);
			}
			rs.close();
			ConexionDB.devuelveConexion(con);

		} catch (SQLException sqlE) {
			try {
				log.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
			throw sqlE;
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}

		return listaSAR;
	}

	public static ArrayList<ImportacionesProveedoresBean> dameTodosLosProveedores()
			throws SQLException, ClassNotFoundException {
		ArrayList<ImportacionesProveedoresBean> listaProveedores = new ArrayList<ImportacionesProveedoresBean>(1000);
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();
			ResultSet rs = null;
			StringBuffer query = new StringBuffer();
			Statement st = null;
			query.append("SELECT distinct (proveedor) as proveedor FROM cdisar  ");
			st = con.createStatement();
			rs = st.executeQuery(query.toString());
			while (rs.next()) {
				ImportacionesProveedoresBean bean = new ImportacionesProveedoresBean();
				bean.setClaveProveedor(rs.getString("proveedor"));
				listaProveedores.add(bean);
			}
			rs.close();
		} catch (SQLException sqlE) {
			try {
				log.error("Error generando consulta proveedores:: " + sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception sqlEx2) {
				log.error("Error generando consulta proveedores:: " + sqlEx2.getMessage(), sqlEx2);
			}
			throw sqlE;
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error("Error generando consulta proveedores:: " + sqlEx2.getMessage(), sqlEx2);
			}
		}
		return listaProveedores;
	}

	public static List<SARHistoryLogBean> selectSARHistoryLog(SARHistoryLogBean sar) {

		List<SARHistoryLogBean> lstSarHistoryLogs = new ArrayList<SARHistoryLogBean>();

		Connection con = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		DAOUtils utils = new DAOUtils();

		StringBuilder select = new StringBuilder(
				"SELECT folio, supplier, sarType, action, modificationDate, modificationTimeStamp, userName,");
		select.append(
				" etd, eta, shippingPort, portOfDischarge, carrier, destinationCountry, delayType, vessel, voyage, booking,");
		select.append(
				" bl, containerType, containerNumber, priority, groundTransportation, sarLocked, consolidatedFolio, comments, esDirecto , createDate, ContainerSupplier");
		select.append(" FROM cdiSARHistoryLog WITH (NOLOCK) ");
		select.append(" WHERE 1=1");

		utils.setSelect(true);

		try {
			con = ConexionDB.dameConexion();
			if (sar.getFolio() != null) {
				select.append(utils.ajustaColumna(" AND folio = ?"));
			}
			if (sar.getUserName() != null) {
				select.append(utils.ajustaColumna(" AND userName = ?"));
			}
			if (sar.getFechaIni() != null) {
				select.append(utils.ajustaColumna(" AND modificationDate >= ?"));
			}
			if (sar.getFechaFin() != null) {
				select.append(utils.ajustaColumna(" AND modificationDate <= ?"));
			}
			pst = con.prepareStatement(select.toString());
			int cont = 1;

			utils.inicializaQuery(select.toString());

			if (sar.getFolio() != null) {
				utils.ajustaParametro(cont++, pst, sar.getFolio(), Integer.class);
			}
			if (sar.getUserName() != null) {
				utils.ajustaParametro(cont++, pst, sar.getUserName(), String.class);
			}
			if (sar.getFechaIni() != null) {
				utils.ajustaParametro(cont++, pst, sar.getFechaIni(), Integer.class);
			}
			if (sar.getFechaFin() != null) {
				utils.ajustaParametro(cont++, pst, sar.getFechaFin(), Integer.class);
			}

			rs = pst.executeQuery();

			while (rs.next()) {
				SARHistoryLogBean temp = new SARHistoryLogBean();
				temp.setFolio(rs.getInt("folio"));
				temp.setSupplier(rs.getString("supplier"));
				temp.setSarType(rs.getString("sarType"));
				temp.setAction(rs.getInt("action"));
				temp.setModificationDate(rs.getInt("modificationDate"));
				temp.setModificationTimeStamp(rs.getLong("modificationTimeStamp"));
				temp.setUserName(rs.getString("userName"));
				temp.setEtd(rs.getInt("etd"));
				temp.setEta(rs.getInt("eta"));
				temp.setShippingPort(rs.getString("shippingPort"));
				temp.setPortOfDischarge(rs.getString("portOfDischarge"));
				temp.setCarrier(rs.getInt("carrier"));
				temp.setDestinationCountry(rs.getInt("destinationCountry"));
				temp.setDelayType(rs.getInt("delayType"));
				temp.setVessel(rs.getString("vessel"));
				temp.setVoyage(rs.getString("voyage"));
				temp.setBooking(rs.getString("booking"));
				temp.setBl(rs.getString("bl"));
				temp.setContainerType(rs.getInt("containerType"));
				temp.setContainerNumber(rs.getString("containerNumber"));
				temp.setPriority(rs.getInt("priority"));
				temp.setGroundTransportation(rs.getInt("groundTransportation"));
				temp.setSarLocked(rs.getBoolean("sarLocked"));
				temp.setConsolidatedFolio(rs.getInt("consolidatedFolio"));
				temp.setComments(rs.getString("comments"));
				temp.setEsDirecto(rs.getBoolean("esDirecto"));
				temp.setCreateDate(rs.getDate("createDate"));
				temp.setReferenciaContenedorProveedor(rs.getString("ContainerSupplier"));
				lstSarHistoryLogs.add(temp);
			}

			ConexionDB.devuelveConexion(con);

		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} catch (Exception e) {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
		return lstSarHistoryLogs;
	}

	/**
	 * Regresa una lista de los historicos de SARs Esto para el reporte de F&R de
	 * SARs liberados
	 * 
	 */
	public static List<SARHistoryLogBean> selectSARHistoryLogBulk(List<SarBO> lista, String fechas) {

		List<SARHistoryLogBean> lstSarHistoryLogs = new ArrayList<SARHistoryLogBean>(10000);

		Connection con = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		DAOUtils utils = new DAOUtils();

		StringBuilder select = new StringBuilder();
		select.append("select h.folio, supplier, sarType, action, modificationDate, modificationTimeStamp, userName,");
		select.append(
				"h.etd, h.eta, shippingPort, portOfDischarge, carrier, destinationCountry, delayType, vessel, voyage, h.booking, ");
		select.append(
				"h.bl, containerType, containerNumber, priority, groundTransportation, sarLocked, consolidatedFolio, comments, esDirecto ");
		select.append(" from cdisar s, cdiSARHistoryLog h  ");
		select.append(" where s.folio = h.folio  ");
		select.append(" and  status not in (").append(SarBO.STATUS_SIN_SOLICITUD_APROBACION);
		select.append(",").append(SarBO.STATUS_ESPERA_APROBACION_PLANEACION).append(") ");
		select.append(fechas);

		utils.setSelect(true);

		try {
			con = ConexionDB.dameConexion();
			pst = con.prepareStatement(select.toString());
			utils.inicializaQuery(select.toString());

			rs = pst.executeQuery();

			while (rs.next()) {
				SARHistoryLogBean temp = new SARHistoryLogBean();
				temp.setFolio(rs.getInt("folio"));
				temp.setSupplier(rs.getString("supplier"));
				temp.setSarType(rs.getString("sarType"));
				temp.setAction(rs.getInt("action"));
				temp.setModificationDate(rs.getInt("modificationDate"));
				temp.setModificationTimeStamp(rs.getLong("modificationTimeStamp"));
				temp.setUserName(rs.getString("userName"));
				temp.setEtd(rs.getInt("etd"));
				temp.setEta(rs.getInt("eta"));
				temp.setShippingPort(rs.getString("shippingPort"));
				temp.setPortOfDischarge(rs.getString("portOfDischarge"));
				temp.setCarrier(rs.getInt("carrier"));
				temp.setDestinationCountry(rs.getInt("destinationCountry"));
				temp.setDelayType(rs.getInt("delayType"));
				temp.setVessel(rs.getString("vessel"));
				temp.setVoyage(rs.getString("voyage"));
				temp.setBooking(rs.getString("booking"));
				temp.setBl(rs.getString("bl"));
				temp.setContainerType(rs.getInt("containerType"));
				temp.setContainerNumber(rs.getString("containerNumber"));
				temp.setPriority(rs.getInt("priority"));
				temp.setGroundTransportation(rs.getInt("groundTransportation"));
				temp.setSarLocked(rs.getBoolean("sarLocked"));
				temp.setConsolidatedFolio(rs.getInt("consolidatedFolio"));
				temp.setComments(rs.getString("comments"));
				temp.setEsDirecto(rs.getBoolean("esDirecto"));
				lstSarHistoryLogs.add(temp);
			}

			ConexionDB.devuelveConexion(con);

		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				log.error("[selectSARHistoryLogBulk]" + ex.getMessage(), ex);
			}
			log.error("[selectSARHistoryLogBulk]" + e.getMessage(), e);
		} catch (Exception e) {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error("[selectSARHistoryLogBulk]" + ex.getMessage(), ex);
			}
			log.error("[selectSARHistoryLogBulk]" + e.getMessage(), e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error("[selectSARHistoryLogBulk]" + sqlEx2.getMessage(), sqlEx2);
			}
		}
		return lstSarHistoryLogs;
	}

	public static boolean insertaSARHistoryLog(SARHistoryLogBean sar) throws ServletException {
		Connection con = null;
		PreparedStatement pst = null;
		DAOUtils utilDao = new DAOUtils();

		StringBuilder insert = ConsultasConstants.INSERTA_SAR_HISTORY_LOG;

		boolean exito = false;

		try {
			con = ConexionDB.dameConexion();
			pst = con.prepareStatement(insert.toString());
			int cont = 1;
			utilDao.ajustaParametro(cont++, pst, sar.getFolio(), Integer.class);
			utilDao.ajustaParametro(cont++, pst, sar.getSupplier(), String.class);
			utilDao.ajustaParametro(cont++, pst, sar.getSarType(), String.class);
			utilDao.ajustaParametro(cont++, pst, sar.getAction(), Integer.class);
			utilDao.ajustaParametro(cont++, pst, sar.getModificationDate(), Integer.class);
			utilDao.ajustaParametro(cont++, pst, sar.getModificationTimeStamp(), Long.class);
			utilDao.ajustaParametro(cont++, pst, sar.getUserName(), String.class);
			utilDao.ajustaParametro(cont++, pst, sar.getEtd(), Integer.class);
			utilDao.ajustaParametro(cont++, pst, sar.getEta(), Integer.class);
			utilDao.ajustaParametro(cont++, pst, sar.getShippingPort(), String.class);
			utilDao.ajustaParametro(cont++, pst, sar.getPortOfDischarge(), String.class);
			utilDao.ajustaParametro(cont++, pst, sar.getCarrier(), Integer.class);
			utilDao.ajustaParametro(cont++, pst, sar.getDestinationCountry(), Integer.class);
			utilDao.ajustaParametro(cont++, pst, sar.getDelayType(), Integer.class);
			utilDao.ajustaParametro(cont++, pst, sar.getVessel(), String.class);
			utilDao.ajustaParametro(cont++, pst, sar.getVoyage(), String.class);
			utilDao.ajustaParametro(cont++, pst, sar.getBooking(), String.class);
			utilDao.ajustaParametro(cont++, pst, sar.getBl(), String.class);
			utilDao.ajustaParametro(cont++, pst, sar.getContainerType(), Integer.class);
			utilDao.ajustaParametro(cont++, pst, sar.getContainerNumber(), String.class);
			utilDao.ajustaParametro(cont++, pst, sar.getPriority(), Integer.class);
			utilDao.ajustaParametro(cont++, pst, sar.getGroundTransportation(), Integer.class);
			utilDao.ajustaParametro(cont++, pst, sar.getSarLocked(), Boolean.class);
			utilDao.ajustaParametro(cont++, pst, sar.getConsolidatedFolio(), Integer.class);
			utilDao.ajustaParametro(cont++, pst, sar.getComments(), String.class);
			utilDao.ajustaParametro(cont++, pst, sar.getEsDirecto(), Boolean.class);
			utilDao.ajustaParametro(cont++, pst, sar.getReferenciaContenedorProveedor(), String.class);
			utilDao.ajustaParametro(cont++, pst, sar.getCommentProfiles(), String.class);
			utilDao.ajustaParametro(cont++, pst , sar.getCreateDate(), Date.class);

			utilDao.inicializaQuery(insert.toString());

			exito = pst.executeUpdate() > 0;
			ConexionDB.devuelveConexion(con);
		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} catch (Exception e) {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
			throw new ServletException(e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
		return exito;
	}

	public static Map<Integer, String> dameMapaSARHistoryLogActions() {

		Map<Integer, String> mapSarHistoryLogActions = new HashMap<Integer, String>();

		Connection con = null;
		PreparedStatement pst = null;
		ResultSet rs = null;

		StringBuilder select = new StringBuilder("SELECT id, action");
		select.append(" FROM cdiActionsSARHistoryLog ");

		try {
			con = ConexionDB.dameConexion();
			pst = con.prepareStatement(select.toString());
			rs = pst.executeQuery();

			while (rs.next()) {
				int id = rs.getInt("id");
				String action = rs.getString("action");
				mapSarHistoryLogActions.put(id, action);
			}

			ConexionDB.devuelveConexion(con);

		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} catch (Exception e) {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
		return mapSarHistoryLogActions;
	}

	public static boolean borraSeguimientoPOsSinSAR() throws ServletException {
		Connection con = null;
		PreparedStatement pst = null;

		StringBuilder delete = new StringBuilder("DELETE seguimientoPOsSinSAR");

		boolean exito = false;

		try {
			con = ConexionDB.dameConexion();
			pst = con.prepareStatement(delete.toString());
			exito = pst.executeUpdate() > 0;
			ConexionDB.devuelveConexion(con);
		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} catch (Exception e) {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
			throw new ServletException(e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}

		return exito;
	}

	public static List<ReporteCambiosETDBooking> cambiosETDBooking(int dia) {
		Connection con = null;
		PreparedStatement pst = null;
		ResultSet rs = null;

		List<ReporteCambiosETDBooking> lstcambiosETDBooking = new ArrayList<ReporteCambiosETDBooking>();

		StringBuilder select = new StringBuilder(
				"select  A.folio, A.sarType, A.Supplier, A.containerNumber, S.consolidado,");
		select.append(
				" A.booking, A.carrier, A.esDirecto, S.tinyFecIniShipping, S.tinyFecIniBooking, S.tinyFecIniConsol,");
		select.append(" A.modificationDate, A.modificationTimeStamp, A.etd,a.etdanterior, A.userName");
		select.append(" from(");
		select.append("		SELECT folio, sarType, supplier, containerNumber, booking, carrier,");
		select.append("		esDirecto, modificationDate, modificationTimeStamp, etd, userName,");
		select.append(" 	CASE WHEN (etd+ etd) = (");
		select.append(" 		sum(etd) OVER (");
		select.append(" 			PARTITION BY folio");
		select.append(" 			ORDER by modificationTimeStamp");
		select.append(" 			ROWS BETWEEN 1 PRECEDING AND CURRENT ROW");
		select.append(" 		)");
		select.append(" 	) THEN 0 ELSE 1 END banetd,");
		select.append(" 	FIRST_VALUE(etd) OVER (");
		select.append(" 		PARTITION BY folio");
		select.append(" 		ORDER BY modificationTimeStamp");
		select.append(" 		ROWS BETWEEN 1 PRECEDING AND CURRENT ROW");
		select.append(" 	) etdanterior");
		select.append(" 	FROM cdiSARHistoryLog");
		select.append(" ) a");
		select.append(" join (");
		select.append(" 	select userName, realName");
		select.append(" 	from cdiUSers u ");
		select.append(" 	join cdiUserProfiles p on u.userProfile = p.id");
		select.append(" 	where p.isBooking = 1");
		select.append(" ) usr on a.userName = usr.userName");
		select.append(" join cdiSAR s on a.folio = s.folio");
		select.append(" WHERE A.banetd = 1");
		select.append(" and a.etd <> a.etdanterior");
		select.append(" and sarType = 'F'");
		select.append(" and modificationDate = ?");
		select.append(" ORDER BY A.folio, A.modificationTimeStamp");

		try {
			con = ConexionDB.dameConexion();
			pst = con.prepareStatement(select.toString());
			pst.setInt(1, dia);
			rs = pst.executeQuery();

			while (rs.next()) {
				String folio = rs.getString("folio");
				boolean consolidado = rs.getBoolean("consolidado");
				String sarType = consolidado ? "C" : "F";
				String proveedor = rs.getString("supplier");
				ImportacionesProveedoresBean ipb = FuncionesComunesPLI.getProveedor(proveedor);
				String nombreProveedor = ipb == null ? "-" : ipb.getNombreProveedor();
				String etd = FuncionesComunesPLI.formateaFecha(rs.getInt("etd"));
				String etdAnterior = FuncionesComunesPLI.formateaFecha(rs.getInt("etdAnterior"));
				int dateIniBooking = consolidado ? rs.getInt("tinyFecIniConsol") : rs.getInt("tinyFecIniBooking");
				String daysInBooking = Integer.toString(Utilerias.diasHabiles(dia, dateIniBooking, false));
				String shippingApprovalDate = FuncionesComunesPLI.formateaFecha(dateIniBooking);
				String week = Integer.toString(FuncionesComunesPLI.numeroSemanaImportaciones(rs.getInt("etd")));
				String poStatus = rs.getBoolean("esDirecto") ? "D" : "";
				String container = rs.getString("containerNumber");
				String booking = rs.getString("booking");
				Naviera naviera = FuncionesComunesPLI.mapaNavieras == null ? null
						: FuncionesComunesPLI.mapaNavieras.get(rs.getInt("carrier"));
				String carrier = naviera == null ? "-" : naviera.getNombre();

				ReporteCambiosETDBooking bean = new ReporteCambiosETDBooking();
				bean.setFolio(folio);
				bean.setSarType(sarType);
				bean.setFolioCompleto(sarType + folio);
				bean.setProveedor(proveedor);
				bean.setNombreProveedor(nombreProveedor);
				bean.setEtd(etd);
				bean.setEtdAnterior(etdAnterior);
				bean.setDaysInBooking(daysInBooking);
				bean.setShippingApprovalDate(shippingApprovalDate);
				bean.setWeek(week);
				bean.setPoStatus(poStatus);
				bean.setContainer(container);
				bean.setBooking(booking);
				bean.setCarrier(carrier);

				lstcambiosETDBooking.add(bean);
			}

			ConexionDB.devuelveConexion(con);

		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} catch (Exception e) {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
		return lstcambiosETDBooking;
	}

	public static ArrayList<SARDetalleSimulador> selectSarDetalleSimulador(int folioSar) throws ClassNotFoundException {

		ArrayList<SARDetalleSimulador> listaSAR = new ArrayList<SARDetalleSimulador>();

		Connection con = null;

		try {
			con = ConexionDB.dameConexion();

			ResultSet rs = null;
			PreparedStatement pst = null;
			StringBuffer query = new StringBuffer();

			query.append(
					"SELECT folio, po, posicion , material , cantidad , pesoProveedor , volumenProveedor , centro,planeador,cantidadModificada,"
							+ "pesoModificado,volumenModificado,cliente,fechaProforma,paisOrigen,noDocumento,cartones,cantidadXcarton,pesoneto,pesobruto,cubicaje,pallet,cartonxpallet, ");
			query.append(
					" unidadMedida,condicionPago,moneda,preciounitario, esPedidoDirecto,tieneDiferenciaMRP, statusMRP, tipoValidacionMRP, ");
			query.append(
					" fechaCreacionSimulador,usuarioCreacionSimulador,alerta,bo,os,inventarioAlArribo,etdNuevo,etdOriginal,etdTEL ");
			query.append(" FROM   cdiSARDetalleSimulador ");
			query.append(" WHERE   folio = ?   ");
			query.append(" ORDER BY PO DESC");

			pst = con.prepareStatement(query.toString());
			pst.setInt(1, folioSar);

			rs = pst.executeQuery();

			while (rs.next()) {

				SARDetalleSimulador tmpSAR = new SARDetalleSimulador();
				tmpSAR.setPo(rs.getString("po").trim());
				tmpSAR.setPosicion(rs.getInt("posicion"));
				tmpSAR.setMaterial(rs.getInt("material"));
				tmpSAR.setCantidad(rs.getInt("cantidad"));
				tmpSAR.setPesoProveedor(rs.getDouble("pesoProveedor"));
				tmpSAR.setVolumenProveedor(rs.getDouble("volumenProveedor"));
				tmpSAR.setFolio(rs.getInt("folio"));
				tmpSAR.setCentro(rs.getString("centro"));
				tmpSAR.setPlaneador(rs.getString("planeador"));
				tmpSAR.setTieneDiferenciasMRP(rs.getBoolean("tieneDiferenciaMRP"));
				tmpSAR.setNumeroDoc(rs.getString("noDocumento"));
				if (rs.wasNull()) {
					tmpSAR.setNumeroDoc(null);
				}

				tmpSAR.setCantidadModificada(rs.getInt("cantidadModificada"));
				if (rs.wasNull()) {
					tmpSAR.setCantidadModificada(null);
				}
				tmpSAR.setPesoModificado(rs.getDouble("pesoModificado"));
				if (rs.wasNull()) {
					tmpSAR.setPesoModificado(null);
				}
				tmpSAR.setVolumenModificado(rs.getDouble("volumenModificado"));
				if (rs.wasNull()) {
					tmpSAR.setVolumenModificado(null);
				}
				tmpSAR.setCliente(rs.getString("cliente"));
				tmpSAR.setFechaProforma(rs.getInt("fechaProforma"));
				tmpSAR.setPaisOrigen(rs.getInt("paisOrigen"));
				if (rs.wasNull()) {
					tmpSAR.setPaisOrigen(null);
				}

				tmpSAR.setCartones(rs.getInt("cartones"));
				tmpSAR.setCantidadXCarton(rs.getInt("cantidadXcarton"));
				tmpSAR.setPesoNetoPKL(rs.getBigDecimal("pesoneto"));
				tmpSAR.setPesoBrutoPKL(rs.getBigDecimal("pesobruto"));
				tmpSAR.setCubicajePKL(rs.getBigDecimal("cubicaje"));
				tmpSAR.setPallet(rs.getInt("pallet"));
				tmpSAR.setCartonXPallet(rs.getInt("cartonxpallet"));
				tmpSAR.setUnidaMedida(rs.getString("unidadMedida"));
				tmpSAR.setCondicionPago(rs.getString("condicionPago"));
				tmpSAR.setMoneda(rs.getString("moneda"));
				tmpSAR.setPrecioUnitario(rs.getDouble("preciounitario"));
				tmpSAR.setPedidoDirecto(rs.getBoolean("esPedidoDirecto"));
				tmpSAR.setStatusMRP(rs.getInt("statusMRP"));
				if (rs.wasNull()) {
					tmpSAR.setStatusMRP(null);
				}
				tmpSAR.setTipoValidacionMRP(rs.getInt("tipoValidacionMRP"));
				tmpSAR.setFechaCreaSimulador(rs.getInt("fechaCreacionSimulador"));
				tmpSAR.setUsuarioCreaSimulador(rs.getString("usuarioCreacionSimulador"));

				tmpSAR.setAlerta(rs.getBoolean("alerta"));
				tmpSAR.setBackorderPronosticado(rs.getBigDecimal("bo"));
				tmpSAR.setOverStock(rs.getDouble("os"));
				tmpSAR.setInventaroAlArribo(rs.getInt("inventarioAlArribo"));
				tmpSAR.setEtdNuevo(rs.getInt("etdNuevo"));
				tmpSAR.setEtdOriginal(rs.getInt("etdOriginal"));
				tmpSAR.setEtdTEL(rs.getInt("etdTel"));

				listaSAR.add(tmpSAR);
			}
			rs.close();
			pst.close();
			ConexionDB.devuelveConexion(con);

		} catch (SQLException sqlE) {
			try {
				log.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}

		return listaSAR;
	}

	public static boolean insertaDetalleSimulador(SARDetalleSimulador detalle, String usaurio) {
		GregorianCalendar hoy = new GregorianCalendar();
		Connection con = null;
		Statement st = null;
		String insert = "INSERT INTO cdiSARDetalleSimulador (folio, po, posicion, material, cantidad, pesoProveedor, volumenProveedor, centro, precioUnitario, "
				+ "planeador, cliente, fechaProforma, unidadMedida ,condicionPago,moneda,esPedidoDirecto,tieneDiferenciaMRP,statusMRP,"
				+ "fechaCreacionSimulador,usuarioCreacionSimulador,alerta,bo,os,inventarioAlArribo,etdNuevo,etdOriginal,etdTEL ) VALUES ("
				+ detalle.getFolio() + ", '" + detalle.getPo() + "', " + detalle.getPosicion() + ", "
				+ detalle.getMaterial() + ", " + detalle.getCantidad() + "," + detalle.getPesoProveedor() + ", "
				+ detalle.getVolumenProveedor() + ", '" + detalle.getCentro() + "', " + detalle.getPrecioUnitario()
				+ ",'" + detalle.getPlaneador() + "','" + detalle.getCliente() + "'," + detalle.getFechaProforma() + ","
				+ (detalle.getUnidaMedida() != null ? ("'" + detalle.getUnidaMedida() + "',") : "'',")
				+ (detalle.getCondicionPago() != null ? ("'" + detalle.getCondicionPago() + "',") : "'',")
				+ (detalle.getMoneda() != null ? ("'" + detalle.getMoneda() + "',") : "'',")
				+ (detalle.isPedidoDirecto() ? 1 : 0) + "," + (detalle.isTieneDiferenciasMRP() ? 1 : 0) + ","
				+ (detalle.isTieneDiferenciasMRP() ? 3 : "NULL") + ","
				+ (FuncionesComunesPLI.gregorianCalendar2int(hoy)) + "," + "'" + (usaurio) + "'" + ","
				+ (detalle.isAlerta() ? 1 : 0) + "," + detalle.getBackorderPronosticado().doubleValue() + ","
				+ detalle.getOverStock() + "," + detalle.getInventaroAlArribo() + "," + detalle.getEtdNuevo() + ","
				+ detalle.getEtdOriginal() + "," + detalle.getEtdTEL() + ")";
		boolean exito = false;

		try {
			con = ConexionDB.dameConexion();
			st = con.createStatement();
			exito = st.executeUpdate(insert) == 1;

			ConexionDB.devuelveConexion(con);
			st.close();
		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} catch (Exception e) {
			e.printStackTrace();
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}

		return exito;
	}

	public static boolean deleteSARDetalleSimulador(int folio) throws ServletException {
		Connection con = null;
		PreparedStatement pst = null;
		StringBuffer delete = new StringBuffer();
		boolean exito = false;
		try {

			delete.append("DELETE  cdiSarDetalleSimulador ");
			delete.append(" WHERE folio = ?");

			int cont = 1;
			con = ConexionDB.dameConexion();

			pst = con.prepareStatement(delete.toString());

			agregarPs(cont++, pst, folio, Integer.class);

			int resultado = pst.executeUpdate();
			exito = resultado > 0;
			pst.close();

			ConexionDB.devuelveConexion(con);

		} catch (Exception e) {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
			throw new ServletException(e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}

		return exito;
	}

	public static Map<Integer, ReferenceNumberBean> selectReferenceNumbers(List<SarBO> lstSars)
			throws ClassNotFoundException {

		Map<Integer, ReferenceNumberBean> mapRefNumbers = new HashMap<Integer, ReferenceNumberBean>();

		Connection con = null;

		try {
			con = ConexionDB.dameConexion();

			ResultSet rs = null;
			PreparedStatement pst = null;
			StringBuffer query = new StringBuffer();

			query.append(
					"SELECT folio, version, referenceNumber, carrier, bookingRequestDateCompany, ETD, vesselName, ");
			query.append(" usuario, fechaCreacion, fechaCreacionLong, comentario,fechaRespuestaBooking ");// actualizadoProveedor
			query.append(" FROM            cdiReferenceNumber a");
			query.append(
					" WHERE version = (select max(version) version from cdiReferenceNumber where folio = a.folio ) ");
			query.append(" and a.folio = ? ");

			for (SarBO sar : lstSars) {
				pst = con.prepareStatement(query.toString());
				pst.setInt(1, sar.getFolio());
				rs = pst.executeQuery();
				while (rs.next()) {

					ReferenceNumberBean result = new ReferenceNumberBean();
					result.setFolio(rs.getInt("folio"));
					result.setReferenceNumber(rs.getString("referenceNumber").trim());
					result.setCarrier(rs.getInt("carrier"));
					result.setBookingRequestDateCompany(rs.getInt("bookingRequestDateCompany"));
					result.setFechaCreacionLong(rs.getLong("fechaCreacionLong"));
					result.setETD(rs.getInt("ETD"));
					result.setVesselName(rs.getString("vesselName"));
					result.setUsuario(rs.getString("usuario"));
					result.setFechaCreacion(rs.getInt("fechaCreacion"));
					result.setVersion(rs.getInt("version"));
					result.setComentario(rs.getString("comentario"));
					result.setRespuestaBooking(rs.getString("fechaRespuestaBooking"));
					mapRefNumbers.put(sar.getFolio(), result);
				}
				rs.close();
				pst.close();
			}
		} catch (SQLException sqlE) {
			try {
				log.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
		return mapRefNumbers;
	}

	public static boolean insertaReferenceNumber(ReferenceNumberBean reference) throws ServletException {
		GregorianCalendar hoy = new GregorianCalendar();
		Connection con = null;
		Statement st = null;
		String insert = "INSERT INTO cdiReferenceNumber ( "
				+ "folio, referenceNumber, carrier, bookingRequestDateCompany,"
				+ "ETD, vesselName, usuario, fechaCreacion, fechaCreacionLong, " + " version )  "// actualizadoProveedor
				+ " VALUES (" + reference.getFolio() + ", '" + reference.getReferenceNumber() + "', "
				+ reference.getCarrier() + ", " + reference.getBookingRequestDateCompany() + ", " + reference.getETD()
				+ ",'" + reference.getVesselName() + "', '" + reference.getUsuario() + "', '"
				+ FuncionesComunesPLI.gregorianCalendar2int(hoy) + "', " + hoy.getTimeInMillis() + ", "
				+ reference.getVersion() + ")";
		boolean exito = false;

		try {
			con = ConexionDB.dameConexion();
			st = con.createStatement();
			exito = st.executeUpdate(insert) == 1;

			ConexionDB.devuelveConexion(con);
			st.close();

		} catch (Exception e) {
			e.printStackTrace();
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error("[insertaReferenceNumber] Error " + ex.getMessage(), ex);
			}
			log.error("[insertaReferenceNumber] Error " + e.getMessage(), e);
			throw new ServletException(e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}

		return exito;
	}

	public static boolean updateReferenceNumber(ReferenceNumberBean bean) throws ServletException {
		Connection con = null;
		PreparedStatement pst = null;
		StringBuffer query = new StringBuffer();

		query.append("UPDATE cdiReferenceNumber SET  referenceNumber = ?,");
		query.append(" carrier = ?, bookingRequestDateCompany = ?,");
		query.append(" ETD = ?, vesselName= ?, usuario= ?  ");
		if (bean.getComentario() != null) {
			query.append(" ,fechaRespuestaBooking = GETDATE() ");
			query.append(" , comentario = ? ");
		}

		query.append(" WHERE folio = ? and version = ? ");

		boolean exito = false;

		try {
			con = ConexionDB.dameConexion();
			pst = con.prepareStatement(query.toString());
			int cont = 1;
			pst.setString(cont++, bean.getReferenceNumber());
			pst.setInt(cont++, bean.getCarrier());
			pst.setInt(cont++, bean.getBookingRequestDateCompany());
			pst.setInt(cont++, bean.getETD());
			pst.setString(cont++, bean.getVesselName());
			pst.setString(cont++, bean.getUsuario());
			if (bean.getComentario() != null) {
				pst.setString(cont++, bean.getComentario());
			}
			pst.setInt(cont++, bean.getFolio());
			pst.setInt(cont++, bean.getVersion());
			exito = pst.executeUpdate() > 0;
		} catch (Exception e) {
			e.printStackTrace();
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error("[updateReferenceNumber] Error: " + ex.getMessage(), ex);
			}
			log.error("[updateReferenceNumber] Error: " + e.getMessage(), e);
			throw new ServletException(e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
		return exito;
	}

	/**
	 * @throws ServletException
	 * 
	 */
	public static ArrayList<BeanDocumentosSDI> selectDocumentosSDI(Integer versionSDI, String booking, String proveedor)
			throws ClassNotFoundException {

		Connection con = null;
		ArrayList<BeanDocumentosSDI> lista = new ArrayList<>();

		try {
			con = ConexionDB.dameConexion();

			ResultSet rs = null;
			PreparedStatement pst = null;
			StringBuffer query = new StringBuffer();
			query.append(" SELECT id, versionSDI, proveedor, booking,  ");
			query.append(" fechaAceptaProveedor, fechaRechazo, versionFacturas, versionPK, versionBL, versionPreBL, ");
			query.append(" facturasCompletas, packingListCargado, preBLGenerado, BLGenerado, ");
			query.append(" tieneOtrosDocumentos, fechaCreacion, comentariosSDI ");
			query.append(" FROM  cdiDocumentosSDI ");
			query.append(" WHERE proveedor = ? ");
			query.append(" AND booking = ? ");
			if (versionSDI != null) {
				query.append(" AND versionSDI = ? ");
			}

			query.append(" ORDER BY versionSDI desc ");

			pst = con.prepareStatement(query.toString());
			int cont = 1;
			pst.setString(cont++, proveedor);
			pst.setString(cont++, booking);
			if (versionSDI != null) {
				pst.setInt(cont++, versionSDI);
			}
			rs = pst.executeQuery();

			while (rs.next()) {
				BeanDocumentosSDI doc = new BeanDocumentosSDI();
				doc.setBlGenerado(rs.getBoolean("BLGenerado"));
				doc.setBooking(rs.getString("booking"));
				doc.setComentariosSDI(rs.getString("comentariosSDI"));
				doc.setFacturasCompletas(rs.getBoolean("facturasCompletas"));
				doc.setFechaAceptaProveedor(rs.getTimestamp("fechaAceptaProveedor"));
				doc.setFechaCreacion(rs.getTimestamp("fechaCreacion"));
				doc.setFechaRechazo(rs.getTimestamp("fechaRechazo"));
				doc.setId(rs.getInt("id"));
				doc.setPackingListGenerado(rs.getBoolean("packingListCargado"));
				doc.setPreBLGenerado(rs.getBoolean("preBLGenerado"));
				doc.setProveedor(rs.getString("proveedor"));
				doc.setTieneOtrosDocumentos(rs.getBoolean("tieneOtrosDocumentos"));
				doc.setVersionBL(rs.getInt("versionBL"));
				doc.setVersionFacturas(rs.getInt("versionFacturas"));
				doc.setVersionPK(rs.getInt("versionPK"));
				doc.setVersionPreBL(rs.getInt("versionPreBL"));
				doc.setVersionSDI(rs.getInt("versionSDI"));
				lista.add(doc);
			}
			rs.close();
			pst.close();

			ConexionDB.devuelveConexion(con);

		} catch (SQLException sqlE) {
			try {
				log.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);

			}
			throw new ClassNotFoundException(sqlE.getMessage());
		}

		return lista;
	}

	public static BeanDocumentosSDI selectDocumentosSDI(int id) throws ClassNotFoundException, ServletException {

		Connection con = null;

		BeanDocumentosSDI doc = null;
		try {
			con = ConexionDB.dameConexion();

			ResultSet rs = null;
			PreparedStatement pst = null;
			StringBuffer query = new StringBuffer();
			query.append(" SELECT id, versionSDI, proveedor, booking,  ");
			query.append(" fechaAceptaProveedor, fechaRechazo, versionFacturas, versionPK, versionBL, versionPreBL, ");
			query.append(" facturasCompletas, packingListCargado, preBLGenerado, BLGenerado, ");
			query.append(" tieneOtrosDocumentos, fechaCreacion, comentariosSDI, ");
			query.append(" cartons, pallets, bulks ");
			query.append(" FROM  cdiDocumentosSDI ");
			query.append(" WHERE id = ? ");
			query.append(" ORDER BY versionSDI desc ");

			pst = con.prepareStatement(query.toString());
			int cont = 1;
			pst.setInt(cont++, id);
			rs = pst.executeQuery();

			while (rs.next()) {
				doc = new BeanDocumentosSDI();
				doc.setBlGenerado(rs.getBoolean("BLGenerado"));
				doc.setBooking(rs.getString("booking"));
				doc.setComentariosSDI(rs.getString("comentariosSDI"));
				doc.setFacturasCompletas(rs.getBoolean("facturasCompletas"));
				doc.setFechaAceptaProveedor(rs.getTimestamp("fechaAceptaProveedor"));
				doc.setFechaCreacion(rs.getTimestamp("fechaCreacion"));
				doc.setFechaRechazo(rs.getTimestamp("fechaRechazo"));
				doc.setId(rs.getInt("id"));
				doc.setPackingListGenerado(rs.getBoolean("packingListCargado"));
				doc.setPreBLGenerado(rs.getBoolean("preBLGenerado"));
				doc.setProveedor(rs.getString("proveedor"));
				doc.setTieneOtrosDocumentos(rs.getBoolean("tieneOtrosDocumentos"));
				doc.setVersionBL(rs.getInt("versionBL"));
				doc.setVersionFacturas(rs.getInt("versionFacturas"));
				doc.setVersionPK(rs.getInt("versionPK"));
				doc.setVersionPreBL(rs.getInt("versionPreBL"));
				doc.setVersionSDI(rs.getInt("versionSDI"));
				doc.setCartons(rs.getInt("cartons"));
				doc.setPallets(rs.getInt("pallets"));
				doc.setBulks(rs.getInt("bulks"));
			}
			rs.close();
			pst.close();

			ConexionDB.devuelveConexion(con);

		} catch (SQLException sqlE) {
			try {
				log.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);

			}
			throw new ServletException(sqlE);
		}

		return doc;
	}

	public static int insertaDocumentosSDI(BeanDocumentosSDI doc) throws ServletException {
		Connection con = null;
		Statement st = null;
		StringBuffer insert = new StringBuffer();
		int idAuto = 0;

		insert.append("INSERT INTO cdiDocumentosSDI ( ");
		insert.append("versionSDI, proveedor, booking,");
		insert.append(" versionFacturas, versionPK, versionBL, versionPreBL,");
		insert.append(" facturasCompletas, packingListCargado, preBLGenerado, BLGenerado, ");
		insert.append(" tieneOtrosDocumentos, fechaCreacion ");
		insert.append(")");
		insert.append(" VALUES (");
		insert.append(doc.getVersionSDI());
		insert.append(",");
		insert.append("'").append(doc.getProveedor()).append("'");
		insert.append(",");
		insert.append("'").append(doc.getBooking()).append("'");
		insert.append(",");
		insert.append(doc.getVersionFacturas());
		insert.append(",");
		insert.append(doc.getVersionPK());
		insert.append(",");
		insert.append(doc.getVersionBL());
		insert.append(",");
		insert.append(doc.getVersionPreBL());
		insert.append(",");
		insert.append(Boolean.TRUE.equals(doc.getFacturasCompletas()) ? 1 : 0);
		insert.append(",");
		insert.append(Boolean.TRUE.equals(doc.getPackingListGenerado()) ? 1 : 0);
		insert.append(",");
		insert.append(Boolean.TRUE.equals(doc.getPreBLGenerado()) ? 1 : 0);
		insert.append(",");
		insert.append(Boolean.TRUE.equals(doc.getBlGenerado()) ? 1 : 0);
		insert.append(",");
		insert.append(Boolean.TRUE.equals(doc.getTieneOtrosDocumentos()) ? 1 : 0);
		insert.append(",");
		insert.append(" getDate() ");
		insert.append(")");

		try {
			con = ConexionDB.dameConexion();
			st = con.createStatement();
			st.executeUpdate(insert.toString(), Statement.RETURN_GENERATED_KEYS);
			ResultSet rs = st.getGeneratedKeys();
			if (rs.next()) {
				idAuto = rs.getInt(1);
			}
			st.close();
		} catch (Exception e) {
			e.printStackTrace();
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error("[insertaDocumentosSDI] Error " + ex.getMessage(), ex);
			}
			log.error("[insertaDocumentosSDI] Error " + e.getMessage(), e);
			throw new ServletException(e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (SQLException e) {
				log.error("error", e);
			}
		}
		return idAuto;
	}

	public static int insertaDocumentosSDIRechazo(BeanDocumentosSDI doc) throws ServletException {
		Connection con = null;
		PreparedStatement pst = null;
		StringBuffer insert = new StringBuffer();
		int idAuto = 0;

		insert.append("INSERT INTO cdiDocumentosSDI ( ");
		insert.append("versionSDI, proveedor, booking,");
		insert.append(" versionFacturas, versionPK, versionBL, versionPreBL,");
		insert.append(" facturasCompletas, packingListCargado, preBLGenerado, BLGenerado, ");
		insert.append(" tieneOtrosDocumentos, fechaCreacion,fechaRechazo,comentariosSDI, usuarioRechazo ");
		insert.append(")");
		insert.append(" VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,getDate(),?,?)");

		try {
			con = ConexionDB.dameConexion();
			pst = con.prepareStatement(insert.toString(), Statement.RETURN_GENERATED_KEYS);
			int cont = 1;
			pst.setInt(cont++, doc.getVersionSDI() + 1);
			pst.setString(cont++, doc.getProveedor());
			pst.setString(cont++, doc.getBooking());
			pst.setInt(cont++, doc.getVersionFacturas());
			pst.setInt(cont++, doc.getVersionPK());
			pst.setInt(cont++, doc.getVersionBL());
			pst.setInt(cont++, doc.getVersionPreBL());
			pst.setInt(cont++, Boolean.TRUE.equals(doc.getFacturasCompletas()) ? 1 : 0);
			pst.setInt(cont++, Boolean.TRUE.equals(doc.getPackingListGenerado()) ? 1 : 0);
			pst.setInt(cont++, Boolean.TRUE.equals(doc.getPreBLGenerado()) ? 1 : 0);
			pst.setInt(cont++, Boolean.TRUE.equals(doc.getBlGenerado()) ? 1 : 0);
			pst.setInt(cont++, Boolean.TRUE.equals(doc.getTieneOtrosDocumentos()) ? 1 : 0);
			pst.setDate(cont++, UtilsFechas.setConvierteFechaToSQLDate(doc.getFechaCreacion()));
			pst.setString(cont++, doc.getComentariosSDI());
			pst.setString(cont++, doc.getUsuarioRechazo());
			pst.executeUpdate();

			ResultSet rs = pst.getGeneratedKeys();
			if (rs.next()) {
				idAuto = rs.getInt(1);
			}

			ConexionDB.devuelveConexion(con);
			rs.close();
			pst.close();

		} catch (Exception e) {
			e.printStackTrace();
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error("[insertaDocumentosSDI] Error " + ex.getMessage(), ex);
			}
			log.error("[insertaDocumentosSDI] Error " + e.getMessage(), e);
			throw new ServletException(e);
		}

		return idAuto;
	}

	public static void updateDocumentosSDI(BeanDocumentosSDI doc) throws ServletException, SQLException {
		Connection con = null;
		Statement st = null;
		StringBuffer insert = new StringBuffer();
		int result = 0;
		DAOUtils utilDao = new DAOUtils();
		insert.append("UPDATE cdiDocumentosSDI SET ");
		if (doc.getVersionFacturas() != null) {
			insert.append(utilDao.ajustaColumna(" versionFacturas = "));
			insert.append(doc.getVersionFacturas()).append(" ");
		}
		if (doc.getVersionBL() != null) {
			insert.append(utilDao.ajustaColumna(" versionbl ="));
			insert.append(doc.getVersionBL()).append(" ");
		}
		if (doc.getVersionPK() != null) {
			insert.append(utilDao.ajustaColumna("  versionPK = "));
			insert.append(doc.getVersionPK()).append(" ");
		}
		if (doc.getVersionPreBL() != null) {
			insert.append(utilDao.ajustaColumna(" versionPreBL = "));
			insert.append(doc.getVersionPreBL()).append(" ");
		}
		if (doc.getFacturasCompletas() != null) {
			insert.append(utilDao.ajustaColumna("  facturasCompletas = "));
			insert.append(doc.getFacturasCompletas() ? 1 : 0).append(" ");
		}
		if (doc.getPackingListGenerado() != null) {
			insert.append(utilDao.ajustaColumna("  packingListCargado = "));
			insert.append(doc.getPackingListGenerado() ? 1 : 0).append(" ");
		}
		if (doc.getPreBLGenerado() != null) {
			insert.append(utilDao.ajustaColumna("  preBLGenerado = "));
			insert.append(doc.getPreBLGenerado() ? 1 : 0).append(" ");
		}
		if (doc.getBlGenerado() != null) {
			insert.append(utilDao.ajustaColumna("  BLGenerado = "));
			insert.append(doc.getBlGenerado() ? 1 : 0).append(" ");
		}
		if (doc.getTieneOtrosDocumentos() != null) {
			insert.append(utilDao.ajustaColumna("  tieneOtrosDocumentos = "));
			insert.append(doc.getTieneOtrosDocumentos() ? 1 : 0).append(" ");
		}
		if (doc.getFechaAceptaProveedor() != null) {
			insert.append(utilDao.ajustaColumna("  fechaaceptaproveedor = "));
			insert.append(" getDate() ").append(" ");
		}
		
		
		if (doc.getTotal()!= null) {		
			insert.append(utilDao.ajustaColumna("  total = "));		
			insert.append(doc.getTotal().toString()).append(" ");		
		}		
		if (doc.getSubTotal() != null) {		
			insert.append(utilDao.ajustaColumna("  subtotal = "));		
			insert.append(doc.getSubTotal().toString()).append(" ");		
		}		
		if (doc.getSubTotalOthers() != null) {		
			insert.append(utilDao.ajustaColumna("  subtotalfocs = "));		
			insert.append(doc.getSubTotalOthers().toString()).append(" ");		
		}		
		if (doc.getSubTotalFocs() != null) {		
			insert.append(utilDao.ajustaColumna("  subtotalothers = "));		
			insert.append(doc.getSubTotalFocs().toString()).append(" ");		
		}		

		insert.append(utilDao.ajustaColumna(" cartons = "));
		insert.append(doc.getCartons()).append(" ");

		insert.append(utilDao.ajustaColumna(" pallets = "));
		insert.append(doc.getPallets()).append(" ");

		insert.append(utilDao.ajustaColumna(" bulks = "));
		insert.append(doc.getBulks()).append(" ");

		insert.append(" WHERE ");
		insert.append(" id =  ").append(doc.getId());

		try {
			con = ConexionDB.dameConexion();
			st = con.createStatement();
			result = st.executeUpdate(insert.toString());
			ConexionDB.devuelveConexion(con);
			st.close();
		} catch (Exception e) {
			e.printStackTrace();
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error("[insertaDocumentosSDI] Error " + ex.getMessage(), ex);
			}
			log.error("[insertaDocumentosSDI] Error " + e.getMessage(), e);
			throw new ServletException(e);
		}
		if (result == 0) {
			log.error("[insertaDocumentosSDI] Ningun registro modificado en el update");
			throw new ServletException("Ningun registro modificado en el update");
		}
	}

	public static ArrayList<Integer> selectSarsEnBooking(int id) throws ClassNotFoundException, ServletException {

		Connection con = null;
		ArrayList<Integer> lista = new ArrayList<Integer>();

		try {
			con = ConexionDB.dameConexion();

			ResultSet rs = null;
			PreparedStatement pst = null;
			StringBuffer query = new StringBuffer();
			query.append(" SELECT id,  sar ");
			query.append(" FROM  cdisarsenbooking ");
			query.append(" WHERE id = ? ");

			pst = con.prepareStatement(query.toString());
			int cont = 1;
			pst.setInt(cont++, id);
			rs = pst.executeQuery();

			while (rs.next()) {
				lista.add(rs.getInt("sar"));
			}
			rs.close();
			pst.close();

			ConexionDB.devuelveConexion(con);

		} catch (SQLException sqlE) {
			try {
				log.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);

			}
			throw new ServletException(sqlE);
		}

		return lista;
	}
	
	public static ArrayList<Integer> selectIdBySars(int id) throws ClassNotFoundException, ServletException {	
		Connection con = null;	
		ArrayList<Integer> lista = new ArrayList<Integer>();	
		try {	
			con = ConexionDB.dameConexion();	
			ResultSet rs = null;	
			PreparedStatement pst = null;	
			StringBuffer query = new StringBuffer();	
			query.append(" SELECT id,  sar ");	
			query.append(" FROM  cdisarsenbooking ");	
			query.append(" WHERE sar = ? ");	
			pst = con.prepareStatement(query.toString());	
			int cont = 1;	
			pst.setInt(cont++, id);	
			rs = pst.executeQuery();	
			while (rs.next()) {	
				lista.add(rs.getInt("id"));	
			}	
			rs.close();	
			pst.close();	
			ConexionDB.devuelveConexion(con);	
		} catch (SQLException sqlE) {	
			try {	
				log.error(sqlE.getMessage(), sqlE);	
				ConexionDB.renuevaConexion(con);	
			} catch (Exception sqlEx2) {	
				log.error(sqlEx2.getMessage(), sqlEx2);	
			}	
			throw new ServletException(sqlE);	
		}	
		return lista;	
	}	
	

	public static void insertaSarsEnBooking(SarBO bo, int id) throws ServletException {
		Connection con = null;
		Statement st = null;
		StringBuffer insert = null;
		ArrayList<String> sars = new ArrayList<String>();
		if (Boolean.TRUE.equals(bo.getEsMultiple())) {
			String[] arreglos = bo.getFoliosMultiples().split(",");
			for (String tmp : arreglos) {
				sars.add(tmp);
			}
		} else {
			sars.add(bo.getFolio() + "");
		}

		try {
			con = ConexionDB.dameConexion();
			st = con.createStatement();
			for (String tmp : sars) {
				insert = new StringBuffer();
				insert.append("INSERT INTO cdisarsenbooking ( ");
				insert.append("id, sar");
				insert.append(")");
				insert.append(" VALUES (");
				insert.append(id);
				insert.append(",");
				insert.append(tmp);
				insert.append(")");
				st.addBatch(insert.toString());
			}

			st.executeBatch();
			ConexionDB.devuelveConexion(con);
			st.close();

		} catch (Exception e) {
			e.printStackTrace();
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error("[insertaSarsEnBooking] Error " + ex.getMessage(), ex);
			}
			log.error("[insertaSarsEnBooking] Error " + e.getMessage(), e);
			throw new ServletException(e);
		}
	}

	public static ArrayList<Integer> selectSarsConMismoBooking(String proveedor, String booking)
			throws ClassNotFoundException, ServletException {

		Connection con = null;
		ArrayList<Integer> lista = new ArrayList<Integer>();

		try {
			con = ConexionDB.dameConexion();

			ResultSet rs = null;
			PreparedStatement pst = null;
			StringBuffer query = new StringBuffer();
			query.append(" SELECT folio ");
			query.append(" FROM  cdisar ");
			query.append(" WHERE booking = ? ");
			query.append(" AND proveedor = ? ");
			query.append(" AND status > 2 ");
			query.append(" AND aprobadoProveedor = 1 ");

			pst = con.prepareStatement(query.toString());
			int cont = 1;
			pst.setString(cont++, booking);
			pst.setString(cont++, proveedor);
			rs = pst.executeQuery();

			while (rs.next()) {
				lista.add(rs.getInt("folio"));
			}
			rs.close();
			pst.close();

			ConexionDB.devuelveConexion(con);

		} catch (SQLException sqlE) {
			try {
				log.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);

			}
			throw new ServletException(sqlE);
		}

		return lista;
	}

	public static ArrayList<BeanFactura> selectFactura(BeanFactura fact, BeanDocumentosSDI docBase)
			throws ClassNotFoundException {

		ArrayList<BeanFactura> facturas = new ArrayList<BeanFactura>();

		Connection con = null;

		try {
			con = ConexionDB.dameConexion();

			ResultSet rs = null;
			PreparedStatement pst = null;
			StringBuffer query = new StringBuffer();
			query.append(" SELECT id, versionDocumento, condicionPago, nombre, madera, ");
			query.append(" paisorigen, fechaCreacion, rutaArchivo, tieneOtros ");
			query.append(" FROM  cdi_facturas ");
			query.append(" WHERE id = ? ");
			query.append(" AND  versionDocumento = ? ");
			if (fact != null && fact.getCondicionDePago() != null) {
				query.append(" AND condicionPago  = ? ");
			}

			pst = con.prepareStatement(query.toString());
			int cont = 1;
			pst.setInt(cont++, docBase.getId());
			pst.setInt(cont++, docBase.getVersionFacturas());
			if (fact != null && fact.getCondicionDePago() != null) {
				pst.setString(cont++, fact.getCondicionDePago());
			}

			rs = pst.executeQuery();
			while (rs.next()) {
				BeanFactura factu = new BeanFactura();
				factu.setCondicionDePago(rs.getString("condicionPago"));
				factu.setFechaCreacion(rs.getDate("fechaCreacion"));
				factu.setId(rs.getInt("id"));
				factu.setNombre(rs.getString("nombre"));
				factu.setPaisOrigen(rs.getString("paisorigen"));
				factu.setRutaArchivo(rs.getString("rutaArchivo"));
				factu.setTieneMadera(rs.getBoolean("madera"));
				factu.setTieneOtros(rs.getBoolean("tieneOtros"));
				factu.setVersionDocumento(rs.getInt("versionDocumento"));

				facturas.add(factu);
			}
			rs.close();
			pst.close();

			ConexionDB.devuelveConexion(con);

		} catch (SQLException sqlE) {
			try {
				log.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}

		return facturas;
	}

	public static BeanFactura selectFacturaXId(int id, String condicionPago) throws ClassNotFoundException {
		BeanFactura factu = null;
		Connection con = null;

		try {
			con = ConexionDB.dameConexion();

			ResultSet rs = null;
			PreparedStatement pst = null;
			StringBuffer query = new StringBuffer();
			query.append(" SELECT a.id, versionDocumento, condicionPago, nombre, madera,  ");
			query.append(" paisorigen, b.fechaCreacion, rutaArchivo, tieneOtros ");
			query.append(" FROM cdiDocumentosSDI a, cdi_facturas b WHERE  ");
			query.append(" a.id = ? and a.id=b.id ");
			query.append(" and a.versionFacturas = b.versionDocumento ");
			query.append(" and b.condicionPago = ? ");

			pst = con.prepareStatement(query.toString());
			int cont = 1;
			pst.setInt(cont++, id);
			pst.setString(cont++, condicionPago);

			rs = pst.executeQuery();
			if (rs.next()) {
				factu = new BeanFactura();
				factu.setCondicionDePago(rs.getString("condicionPago"));
				factu.setFechaCreacion(rs.getDate("fechaCreacion"));
				factu.setId(rs.getInt("id"));
				factu.setNombre(rs.getString("nombre"));
				factu.setPaisOrigen(rs.getString("paisorigen"));
				factu.setRutaArchivo(rs.getString("rutaArchivo"));
				factu.setTieneMadera(rs.getBoolean("madera"));
				factu.setTieneOtros(rs.getBoolean("tieneOtros"));
				factu.setVersionDocumento(rs.getInt("versionDocumento"));
			}
			rs.close();
			pst.close();

			ConexionDB.devuelveConexion(con);

		} catch (SQLException sqlE) {
			try {
				log.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}

		return factu;
	}

	public static List<BeanFactura> selectFacturaXId(int id) throws ClassNotFoundException {	
		BeanFactura factu = null;	
		Connection con = null;	
		List<BeanFactura> lista = new ArrayList<BeanFactura>();	
		try {	
			con = ConexionDB.dameConexion();	
			ResultSet rs = null;	
			PreparedStatement pst = null;	
			StringBuffer query = new StringBuffer();	
			query.append(" SELECT a.id, versionDocumento, condicionPago, nombre, madera,  ");	
			query.append(" paisorigen, b.fechaCreacion, rutaArchivo, tieneOtros ");	
			query.append(" FROM cdiDocumentosSDI a, cdi_facturas b WHERE  ");	
			query.append(" a.id = ? and a.id=b.id ");	
			query.append(" and a.versionFacturas = b.versionDocumento ");	
			pst = con.prepareStatement(query.toString());	
			int cont = 1;	
			pst.setInt(cont++, id);	
			rs = pst.executeQuery();	
			while (rs.next()) {	
				factu = new BeanFactura();	
				factu.setCondicionDePago(rs.getString("condicionPago"));	
				factu.setFechaCreacion(rs.getDate("fechaCreacion"));	
				factu.setId(rs.getInt("id"));	
				factu.setNombre(rs.getString("nombre"));	
				factu.setPaisOrigen(rs.getString("paisorigen"));	
				factu.setRutaArchivo(rs.getString("rutaArchivo"));	
				factu.setTieneMadera(rs.getBoolean("madera"));	
				factu.setTieneOtros(rs.getBoolean("tieneOtros"));	
				factu.setVersionDocumento(rs.getInt("versionDocumento"));	
				lista.add(factu);	
			}	
			rs.close();	
			pst.close();	
			ConexionDB.devuelveConexion(con);	
		} catch (SQLException sqlE) {	
			try {	
				log.error(sqlE.getMessage(), sqlE);	
				ConexionDB.renuevaConexion(con);	
			} catch (Exception sqlEx2) {	
				log.error(sqlEx2.getMessage(), sqlEx2);	
			}	
		}	
		return lista;	
	}	
	public static boolean modificaNombreDeFactura(Integer id, String condicionPago,String rutaArchivo) throws ServletException {	
		Connection con = null;	
		PreparedStatement pst = null;	
		StringBuffer insert = new StringBuffer();	
		boolean exito = false;	
		try {	
			insert.append(" update cdi_facturas ");	
			insert.append(" SET rutaArchivo =? ");	
			insert.append(" WHERE id = ? ");	
			insert.append(" AND   condicionPago = ? ");	
			insert.append(" AND   versionDocumento   = ");	
			insert.append(" (SELECT a.versionFacturas FROM cdiDocumentosSDI a WHERE a.id = ? )");	
			con = ConexionDB.dameConexion();	
			pst = con.prepareStatement(insert.toString());	
			pst.setString(1, rutaArchivo);	
			pst.setInt(2, id);	
			pst.setString(3, condicionPago);	
			pst.setInt(4, id); 	
			exito = pst.executeUpdate() > 0;	
			ConexionDB.devuelveConexion(con);	
			pst.close();	
		} catch (Exception e) {	
			e.printStackTrace();	
			try {	
				ConexionDB.devuelveConexion(con);	
			} catch (Exception ex) {	
				log.error("[insertFactura] Error " + ex.getMessage(), ex);	
			}	
			log.error("[insertFactura] Error " + e.getMessage(), e);	
			throw new ServletException(e);	
		} finally {	
			try {	
				ConexionDB.devuelveConexion(con);	
			} catch (Exception sqlEx2) {	
				log.error(sqlEx2.getMessage(), sqlEx2);	
			}	
		}	
		return exito;	
	}	

	public static boolean insertFactura(BeanFactura fact) throws ServletException {
		Connection con = null;
		PreparedStatement pst = null;
		StringBuffer insert = new StringBuffer();
		boolean exito = false;

		try {
			insert.append("INSERT INTO cdi_facturas ( ");
			insert.append("id, versionDocumento, condicionPago, nombre, madera,");
			insert.append("paisorigen, fechaCreacion, rutaArchivo, tieneOtros)");
			insert.append(" VALUES (?,?,?,?,?,?,getDate(),?,?)");
			con = ConexionDB.dameConexion();
			pst = con.prepareStatement(insert.toString());

			int cont = 1;
			pst.setInt(cont++, fact.getId());
			pst.setInt(cont++, fact.getVersionDocumento());
			pst.setString(cont++, fact.getCondicionDePago());
			pst.setString(cont++, fact.getNombre());
			pst.setBoolean(cont++, fact.getTieneMadera());
			pst.setString(cont++, fact.getPaisOrigen());
			pst.setString(cont++, fact.getRutaArchivo());
			pst.setBoolean(cont++, Boolean.TRUE.equals(fact.getTieneOtros()));

			exito = pst.executeUpdate() > 0;
			ConexionDB.devuelveConexion(con);
			pst.close();
		} catch (Exception e) {
			e.printStackTrace();
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error("[insertFactura] Error " + ex.getMessage(), ex);
			}
			log.error("[insertFactura] Error " + e.getMessage(), e);
			throw new ServletException(e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}

		return exito;
	}

	/**
	 * Confirma si el nombre de la factura ya existe, para un mismo proveedor en las
	 * ultimas versiones de facturas
	 */
	public static boolean nombreYaExiste(String nombreFactura, String proveedor) throws ClassNotFoundException {
		Connection con = null;
		boolean existe = false;
		try {
			con = ConexionDB.dameConexion();
			ResultSet rs = null;
			Statement st = null;
			StringBuffer query = new StringBuffer();
			query.append(" SELECT  a.proveedor, versionSetDocumentos from cdisar a INNER JOIN cdiDocumentosSDI b  ");
			query.append(" ON a.versionSetDocumentos = b.versionSDI and a.proveedor = b.proveedor  ");
			query.append(" AND a.booking  = b.booking INNER JOIN  cdi_Facturas c ");
			query.append(" ON b.id = c.id and c.nombre = '").append(nombreFactura).append("' ");
			query.append(" AND b.id = c.id and b.proveedor = '").append(proveedor).append("' ");
			query.append(" AND b.versionFacturas = c.versionDocumento ");

			st = con.createStatement();
			rs = st.executeQuery(query.toString());
			if (rs.next()) {
				existe = true;

			}
			rs.close();
			st.close();

			ConexionDB.devuelveConexion(con);

		} catch (SQLException sqlE) {
			try {
				log.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
		return existe;
	}

	public static ArrayList<String> dameCondicionesPagoDetalles(ArrayList<Integer> lista)
			throws ClassNotFoundException {
		Connection con = null;
		ArrayList<String> result = new ArrayList<>();
		try {
			con = ConexionDB.dameConexion();
			ResultSet rs = null;
			Statement st = null;
			StringBuffer query = new StringBuffer();
			query.append(" SELECT distinct (condicionPago) from cdiSARDetalle  ");
			query.append(" where folio in (");
			int cont = 0;
			for (Integer valor : lista) {
				if (cont > 0) {
					query.append(",");
				}
				query.append(valor);
				cont++;
			}
			query.append(") ");
			query.append("and condicionPago is not null ");

			st = con.createStatement();
			rs = st.executeQuery(query.toString());
			while (rs.next()) {
				result.add(rs.getString("condicionPago"));
			}
			rs.close();
			st.close();

			ConexionDB.devuelveConexion(con);

		} catch (SQLException sqlE) {
			try {
				log.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
		return result;
	}

	public static ArrayList<String> dameCondicionesPagoDetallesOtros(ArrayList<Integer> lista)
			throws ClassNotFoundException {
		Connection con = null;
		ArrayList<String> result = new ArrayList<>();
		try {
			con = ConexionDB.dameConexion();
			ResultSet rs = null;
			Statement st = null;
			StringBuffer query = new StringBuffer();
			query.append(" SELECT distinct (condicionPago) from cdiSARDetalleOthers  ");
			query.append(" where folio in (");
			int cont = 0;
			for (Integer valor : lista) {
				if (cont > 0) {
					query.append(",");
				}
				query.append(valor);
				cont++;
			}
			query.append(") ");
			query.append("and condicionPago is not null ");

			st = con.createStatement();
			rs = st.executeQuery(query.toString());
			while (rs.next()) {
				result.add(rs.getString("condicionPago"));
			}
			rs.close();
			st.close();

			ConexionDB.devuelveConexion(con);

		} catch (SQLException sqlE) {
			try {
				log.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
		return result;
	}
	
	public static boolean modificaNombreDeFacturaBL(Integer id, String tipo , Integer version,String rutaArchivo) throws ServletException {	
		Connection con = null;	
		PreparedStatement pst = null;	
		StringBuffer update = new StringBuffer();	
		boolean exito = false;	
		try {	
			update.append(" update cdi_BL ");	
			update.append(" SET rutaArchivo =? ");	
			update.append(" WHERE id = ?  ");	
			update.append(" AND tipo = ?  ");	
			update.append(" AND versiondocumento = ?  ");	
			con = ConexionDB.dameConexion();	
			pst = con.prepareStatement(update.toString());	
			pst.setString(1, rutaArchivo);	
			pst.setInt(2, id);	
			pst.setString(3, tipo);	
			pst.setInt(4, version);	
			exito = pst.executeUpdate() > 0;	
			ConexionDB.devuelveConexion(con);	
			pst.close();	
		} catch (Exception e) {	
			e.printStackTrace();	
			try {	
				ConexionDB.devuelveConexion(con);	
			} catch (Exception ex) {	
				log.error("[insertFactura] Error " + ex.getMessage(), ex);	
			}	
			log.error("[insertFactura] Error " + e.getMessage(), e);	
			throw new ServletException(e);	
		} finally {	
			try {	
				ConexionDB.devuelveConexion(con);	
			} catch (Exception sqlEx2) {	
				log.error(sqlEx2.getMessage(), sqlEx2);	
			}	
		}	
		return exito;	
	}
	
	public static boolean modificaNombreDeFacturaOTROSPROV(Integer id, String nombre,String nombreNuevo,String rutaArchivo) throws ServletException {	
		Connection con = null;	
		PreparedStatement pst = null;	
		StringBuffer update = new StringBuffer();	
		boolean exito = false;	
		try {	
			update.append(" update cdi_otros_documentos ");	
			update.append(" SET rutaArchivo =?, nombre=? ");	
			update.append(" WHERE id = ?  ");	
			update.append(" AND eliminado = 0  ");	
			update.append(" AND nombre=?  ");	
			con = ConexionDB.dameConexion();	
			pst = con.prepareStatement(update.toString());	
			pst.setString(1, rutaArchivo);	
			pst.setString(2, nombreNuevo);	
			pst.setInt(3, id);	
			pst.setString(4, nombre); 	
			exito = pst.executeUpdate() > 0;	
			ConexionDB.devuelveConexion(con);	
			pst.close();	
		} catch (Exception e) {	
			e.printStackTrace();	
			try {	
				ConexionDB.devuelveConexion(con);	
			} catch (Exception ex) {	
				log.error("[insertFactura] Error " + ex.getMessage(), ex);	
			}	
			log.error("[insertFactura] Error " + e.getMessage(), e);	
			throw new ServletException(e);	
		} finally {	
			try {	
				ConexionDB.devuelveConexion(con);	
			} catch (Exception sqlEx2) {	
				log.error(sqlEx2.getMessage(), sqlEx2);	
			}	
		}	
		return exito;	
	}	

	
	public static boolean modificaNombreDeFacturaPL(Integer id, Integer version,String rutaArchivo) throws ServletException {	
		Connection con = null;	
		PreparedStatement pst = null;	
		StringBuffer update = new StringBuffer();	
		boolean exito = false;	
		try {	
			update.append(" update cdi_PackingList ");	
			update.append(" SET rutaArchivo =? ");	
			update.append(" WHERE id = ?  ");	
			con = ConexionDB.dameConexion();	
			pst = con.prepareStatement(update.toString());	
			pst.setString(1, rutaArchivo);	
			pst.setInt(2, id);	
			exito = pst.executeUpdate() > 0;	
			ConexionDB.devuelveConexion(con);	
			pst.close();	
		} catch (Exception e) {	
			e.printStackTrace();	
			try {	
				ConexionDB.devuelveConexion(con);	
			} catch (Exception ex) {	
				log.error("[insertFactura] Error " + ex.getMessage(), ex);	
			}	
			log.error("[insertFactura] Error " + e.getMessage(), e);	
			throw new ServletException(e);	
		} finally {	
			try {	
				ConexionDB.devuelveConexion(con);	
			} catch (Exception sqlEx2) {	
				log.error(sqlEx2.getMessage(), sqlEx2);	
			}	
		}	
		return exito;	
	}
	
	public static BeanPL selectPL(int id) throws ClassNotFoundException {

		BeanPL plBean = null;

		Connection con = null;

		try {
			con = ConexionDB.dameConexion();

			ResultSet rs = null;
			PreparedStatement pst = null;
			StringBuffer query = new StringBuffer();

			query.append(" SELECT id,nombre, ");
			query.append(" fechaCreacion,rutaArchivo, versionDocumento");
			query.append(" FROM  cdi_PackingList ");
			query.append(" WHERE id = ? ");
			query.append(" ORDER BY versionDocumento desc ");

			pst = con.prepareStatement(query.toString());
			int cont = 1;
			pst.setInt(cont++, id);
			rs = pst.executeQuery();
			if (rs.next()) {
				plBean = new BeanPL();
				plBean.setId(rs.getInt("id"));
				plBean.setNombre(rs.getString("nombre"));
				plBean.setFechaCreacion(rs.getDate("fechaCreacion"));
				plBean.setRutaArchivo(rs.getString("rutaArchivo"));
				plBean.setVersionDocumento(rs.getInt("versionDocumento"));
			}
			rs.close();
			pst.close();

			ConexionDB.devuelveConexion(con);
		} catch (SQLException sqlE) {
			try {
				log.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
		return plBean;
	}

	public static boolean insertaPL(BeanPL fact) throws ServletException {
		Connection con = null;
		Statement st = null;
		StringBuffer insert = new StringBuffer();
		insert.append("INSERT INTO cdi_PackingList ( ");
		insert.append("id,nombre,versionDocumento,");
		insert.append("fechaCreacion,rutaArchivo)");
		insert.append(" VALUES (");
		insert.append(fact.getId());
		insert.append(",'");
		insert.append(fact.getNombre());
		insert.append("',");
		insert.append(fact.getVersionDocumento());
		insert.append(",");
		insert.append("GETDATE()");
		insert.append(",");
		insert.append("'").append(fact.getRutaArchivo()).append("'");

		insert.append(")");

		boolean exito = false;

		try {
			con = ConexionDB.dameConexion();
			st = con.createStatement();
			exito = st.executeUpdate(insert.toString()) == 1;

			ConexionDB.devuelveConexion(con);
			st.close();

		} catch (Exception e) {
			e.printStackTrace();
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error("[insertaPL] Error " + ex.getMessage(), ex);
			}
			log.error("[insertaPL] Error " + e.getMessage(), e);
			throw new ServletException(e);
		}
		return exito;
	}

	public static BeanBL selectBL(int id, String tipo) throws ClassNotFoundException {

		BeanBL blBean = null;

		Connection con = null;

		try {
			con = ConexionDB.dameConexion();

			ResultSet rs = null;
			PreparedStatement pst = null;
			StringBuffer query = new StringBuffer();

			query.append(" SELECT id, tipo, versionDocumento, nombre,  ");
			query.append(" rutaArchivo, fechaCreacion ");
			query.append(" FROM  cdi_BL ");
			query.append(" WHERE id = ? ");
			query.append(" AND tipo = ? ");
			query.append(" ORDER BY versiondocumento desc ");

			pst = con.prepareStatement(query.toString());
			int cont = 1;
			pst.setInt(cont++, id);
			pst.setString(cont++, tipo);
			rs = pst.executeQuery();
			if (rs.next()) {

				blBean = new BeanBL();
				blBean.setId(rs.getInt("id"));
				blBean.setVersionDocumento(rs.getInt("versionDocumento"));
				blBean.setNombre(rs.getString("nombre"));
				blBean.setFechaCreacion(rs.getDate("fechaCreacion"));
				blBean.setRutaArchivo(rs.getString("rutaArchivo"));
				blBean.setTipo(rs.getString("tipo"));
			}
			rs.close();
			pst.close();

			ConexionDB.devuelveConexion(con);

		} catch (SQLException sqlE) {
			try {
				log.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}

		return blBean;
	}

	public void deleteBL(int id)  {
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();

			ResultSet rs = null;
			PreparedStatement pst = null;
			StringBuffer query = new StringBuffer();

			query.append(" DELETE FROM cdi_BL  ");
			query.append(" WHERE id = ? ");

			pst = con.prepareStatement(query.toString());
			pst.setInt(1, id);
			rs = pst.executeQuery();

			rs.close();
			pst.close();

			

		} catch (Exception sqlE) {
			log.error(sqlE.getMessage(), sqlE);
		} finally {
			ConexionDB.devolver(con);
		}

	}

	public void deleteOtros(int id)  {
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();

			ResultSet rs = null;
			PreparedStatement pst = null;
			StringBuffer query = new StringBuffer();

			query.append(" DELETE FROM cdi_otros_documentos  ");
			query.append(" WHERE id = ? ");

			pst = con.prepareStatement(query.toString());
			pst.setInt(1, id);
			rs = pst.executeQuery();

			rs.close();
			pst.close();

		} catch (Exception sqlE) {
			log.error(sqlE.getMessage(), sqlE);
		} finally {
			ConexionDB.devolver(con);
		}

	}
	
	public boolean deleteCdiDocumentosSDI(int id) 
	{
		Connection con = null;
		boolean eliminadoInDocumentsSDI = false;
		
		try 
		{
			con = ConexionDB.dameConexion();
			PreparedStatement pst = null;
			StringBuffer query = new StringBuffer();

			query.append(" DELETE FROM cdiDocumentosSDI  ");
			query.append(" WHERE id = ? ");

			pst = con.prepareStatement(query.toString());
			pst.setInt(1, id);
			eliminadoInDocumentsSDI = pst.executeUpdate() > 0 ? true : false;

			pst.close();

		} 
		catch (Exception sqlE) 
		{
			log.error("Exception: {} ", sqlE.getMessage(), sqlE);
		} 
		finally 
		{
			ConexionDB.devolver(con);
		}
		return eliminadoInDocumentsSDI;
	}

	public boolean mergeCdiSARsEnBooking(int id, int folio)
	{
		Connection con = null;
		boolean eliminadoSARInBooking = false;
		
		try 
		{
			con = ConexionDB.dameConexion();
			PreparedStatement pst = null;
			pst = con.prepareStatement(ConsultasConstants.MERGE_IN_CDI_SARS_EN_BOOKING);
			pst.setInt(1, id);
			pst.setInt(2, folio);
			eliminadoSARInBooking = pst.executeUpdate() > 0 ? true : false;

			pst.close();
			
		} 
		catch (Exception sqlE) 
		{
			log.error("Exception: {} ", sqlE.getMessage(), sqlE);
		} 
		finally 
		{
			ConexionDB.devolver(con);
		}
		return eliminadoSARInBooking;
	}

	public boolean deletecdiSARsEnBooking(int id, int folio) 
	{
		Connection con = null;
		boolean eliminadoSARInBooking = false;
		
		try 
		{
			con = ConexionDB.dameConexion();
			PreparedStatement pst = null;
			StringBuffer query = new StringBuffer();

			query.append(" DELETE FROM cdiSARsEnBooking  ");
			query.append(" WHERE id = ? ");
			query.append(" OR sar = ? ");

			pst = con.prepareStatement(query.toString());
			pst.setInt(1, id);
			pst.setInt(2, folio);
			eliminadoSARInBooking = pst.executeUpdate() > 0 ? true : false;

			pst.close();
			
		} 
		catch (Exception sqlE) 
		{
			log.error("Exception: {} ", sqlE.getMessage(), sqlE);
		} 
		finally 
		{
			ConexionDB.devolver(con);
		}
		return eliminadoSARInBooking;
	}

	public static boolean insertaBL(BeanBL bl) throws ServletException {
		Connection con = null;
		Statement st = null;
		StringBuffer insert = new StringBuffer();
		insert.append("INSERT INTO cdi_bl ( ");
		insert.append("id, tipo, versionDocumento, nombre, rutaArchivo, fechaCreacion) ");
		insert.append(" VALUES (");
		insert.append(bl.getId());
		insert.append(",");
		insert.append("'").append(bl.getTipo()).append("'");
		insert.append(",");
		insert.append(bl.getVersionDocumento());
		insert.append(",");
		insert.append("'").append(bl.getNombre()).append("'");
		insert.append(",");
		insert.append("'").append(bl.getRutaArchivo()).append("'");
		insert.append(",GETDATE() )");

		boolean exito = false;

		try {
			con = ConexionDB.dameConexion();
			st = con.createStatement();
			exito = st.executeUpdate(insert.toString()) == 1;

			ConexionDB.devuelveConexion(con);
			st.close();
		} catch (Exception e) {
			e.printStackTrace();
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error("[insertaBL] Error " + ex.getMessage(), ex);
			}
			log.error("[insertaBL] Error " + e.getMessage(), e);
			throw new ServletException(e);
		}
		return exito;
	}

	public static ArrayList<BeanOtrosDocumentos> selectOtrosDocumentos(BeanOtrosDocumentos otros)
			throws ClassNotFoundException {

		ArrayList<BeanOtrosDocumentos> lista = new ArrayList<BeanOtrosDocumentos>();
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();

			ResultSet rs = null;
			PreparedStatement pst = null;
			StringBuffer query = new StringBuffer();

			query.append(" SELECT id, nombre, rutaArchivo,  ");
			query.append(" eliminado, fechaEliminado, fechaCreacion ");
			query.append(" FROM   cdi_otros_documentos ");
			query.append(" WHERE id = ? ");
			query.append(" AND eliminado = 0 ");
			if (otros.getNombre() != null) {
				query.append(" AND nombre =").append("'").append(otros.getNombre()).append("'");
			}

			pst = con.prepareStatement(query.toString());
			int cont = 1;
			pst.setInt(cont++, otros.getId());
			rs = pst.executeQuery();
			while (rs.next()) {
				BeanOtrosDocumentos tmp = new BeanOtrosDocumentos();

				tmp.setId(rs.getInt("id"));
				tmp.setFechaEliminacion(rs.getDate("fechaEliminado"));
				tmp.setNombre(rs.getString("nombre"));
				tmp.setFechaCreacion(rs.getDate("fechaCreacion"));
				tmp.setRutaArchivo(rs.getString("rutaArchivo"));
				tmp.setEliminado(rs.getBoolean("eliminado"));
				lista.add(tmp);
			}
			rs.close();
			pst.close();

			ConexionDB.devuelveConexion(con);

		} catch (SQLException sqlE) {
			try {
				log.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}

		return lista;
	}

	public static boolean insertaOtroDocumento(BeanOtrosDocumentos otro) throws ServletException {
		Connection con = null;
		Statement st = null;
		StringBuffer insert = new StringBuffer();
		insert.append("INSERT INTO cdi_otros_documentos ( ");
		insert.append("id, nombre, rutaArchivo,eliminado,  ");
		insert.append("fechaCreacion )");
		insert.append(" VALUES (");
		insert.append(otro.getId());
		insert.append(",");
		insert.append("'").append(otro.getNombre()).append("'");
		insert.append(",");
		insert.append("'").append(otro.getRutaArchivo()).append("'");
		insert.append(",0,GETDATE() )");

		boolean exito = false;

		try {
			con = ConexionDB.dameConexion();
			st = con.createStatement();
			exito = st.executeUpdate(insert.toString()) == 1;

			ConexionDB.devuelveConexion(con);
			st.close();
		} catch (Exception e) {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error("[insertaBL] Error " + ex.getMessage(), ex);
			}
			log.error("[insertaBL] Error " + e.getMessage(), e);
		}
		return exito;
	}

	/**
	 * Cambia el status de los sars indicados, se crea el metodo para usarlo cuando
	 * un proveedor manda documentos a SDI
	 * 
	 * @param status
	 * @param sars
	 * @return
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 */
	public static void updateSARsStatus(int status, ArrayList<Integer> sars)
			throws SQLException, ClassNotFoundException {
		Connection con = null;
		int resultado = 0;
		DAOUtils utils = new DAOUtils();
		try {
			con = ConexionDB.dameConexion();

			PreparedStatement pst = null;
			StringBuffer query = new StringBuffer();

			query.append(" UPDATE cdiSAR ");
			query.append(" SET status= ").append(status).append(" ");
			query.append(" WHERE folio  in ( ");
			int x = 0;
			for (Integer folio : sars) {
				if (x > 0) {
					query.append(",");
				}
				query.append("?");
				x++;
			}
			query.append(" ) ");

			pst = con.prepareStatement(query.toString());

			utils.inicializaQuery(query.toString());
			int cont = 1;
			for (Integer folio : sars) {
				utils.ajustaParametro(cont++, pst, folio, Integer.class);
			}
			resultado = pst.executeUpdate();

			pst.close();

			ConexionDB.devuelveConexion(con);

			if (resultado == 0) {
				throw new SQLException("No se actualizo registro...");
			}

		} catch (SQLException sqlE) {
			try {
				log.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
			throw sqlE;
		} catch (IOException ioE) {
			try {
				log.error(ioE.getMessage(), ioE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception ioE2) {
				log.error(ioE2.getMessage(), ioE2);
			}
		}
	}

	public static void updateSARStatusGDR(int folio, int gdrEnRevision, int gdrAprobado) throws SQLException, ClassNotFoundException {
		Connection con = null;
		int resultado = 0;
		DAOUtils utils = new DAOUtils();
		try {
			con = ConexionDB.dameConexion();

			PreparedStatement pst = null;
			StringBuilder query = ConsultasConstants.UPDATE_SAR_STATUS_GDR;

			pst = con.prepareStatement(query.toString());

			utils.inicializaQuery(query.toString());
			int cont = 1;
			if(gdrEnRevision == 1)
			    utils.ajustaParametro(cont++, pst, Boolean.TRUE, Boolean.class);
			else
			    utils.ajustaParametro(cont++, pst, Boolean.FALSE, Boolean.class);
			if(gdrAprobado == 1)
			    utils.ajustaParametro(cont++, pst, Boolean.TRUE, Boolean.class);
			else
			    utils.ajustaParametro(cont++, pst, Boolean.FALSE, Boolean.class);
			utils.ajustaParametro(cont++, pst, folio, Integer.class);
			resultado = pst.executeUpdate();

			pst.close();

			ConexionDB.devuelveConexion(con);

			if (resultado == 0) {
				throw new SQLException("No se actualizo registro...");
			}

		} catch (SQLException sqlE) {
			try {
				log.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
			throw sqlE;
		} catch (IOException ioE) {
			try {
				log.error(ioE.getMessage(), ioE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception ioE2) {
				log.error(ioE2.getMessage(), ioE2);
			}
		}
	}

	public static void aprobacionGDR(int folio) throws SQLException, ClassNotFoundException {
		Connection con = null;
		int resultado = 0;
		DAOUtils utils = new DAOUtils();
		try {
			con = ConexionDB.dameConexion();
			RevisionGDR revision = new RevisionGDR();
			revision.setFolio(folio);
			revision.setActivo(true);
			RevisionGDRDAO gdrDao = new RevisionGDRDAO();
			List<RevisionGDR> revisiones = (List<RevisionGDR>) gdrDao.select(revision);
			RevisionGDR sar = revisiones != null ? revisiones.get(0) : null;

			Date gdrModificado = sar.getFechaGDRModificada() != null ?
				DateUtils.getInstance().parseIntToDate(sar.getFechaGDRModificada(), "yyyyMMdd"): null;

			PreparedStatement pst = null;
			StringBuilder query = ConsultasConstants.APROBACION_GDR;

			int cont = 1;
			pst = con.prepareStatement(query.toString());
			utils.inicializaQuery(query.toString());

			if(sar.getFechaETDModificada() != null)
			    utils.ajustaParametro(cont++, pst, sar.getFechaETDModificada(), Integer.class);
			if(gdrModificado != null)
			    utils.ajustaParametro(cont++, pst, gdrModificado, Date.class);
			utils.ajustaParametro(cont++, pst, folio, Integer.class);
			resultado = pst.executeUpdate();

			pst.close();

			ConexionDB.devuelveConexion(con);

			if (resultado == 0) {
				throw new SQLException("No se actualizo registro...");
			}

		} catch (SQLException sqlE) {
			try {
				log.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
			throw sqlE;
		} catch (IOException ioE) {
			try {
				log.error(ioE.getMessage(), ioE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception ioE2) {
				log.error(ioE2.getMessage(), ioE2);
			}
		}
	}

	public static void updateSARRechazoSDI(int status, ArrayList<Integer> sars, int versionSDI)
			throws SQLException, ClassNotFoundException {
		Connection con = null;
		int resultado = 0;
		DAOUtils utils = new DAOUtils();
		try {
			con = ConexionDB.dameConexion();

			PreparedStatement pst = null;
			StringBuffer query = new StringBuffer();

			query.append(" UPDATE cdiSAR ");
			query.append(" SET status= ").append(status).append(" ");
			query.append(" , versionSetDocumentos= ").append(versionSDI).append(" ");
			query.append(" WHERE folio  in ( ");
			int x = 0;
			for (Integer folio : sars) {
				if (x > 0) {
					query.append(",");
				}
				query.append("?");
				x++;
			}
			query.append(" ) ");

			pst = con.prepareStatement(query.toString());

			utils.inicializaQuery(query.toString());
			int cont = 1;
			for (Integer folio : sars) {
				utils.ajustaParametro(cont++, pst, folio, Integer.class);
			}
			resultado = pst.executeUpdate();

			pst.close();

			ConexionDB.devuelveConexion(con);

			if (resultado == 0) {
				throw new SQLException("No se actualizo registro...");
			}

		} catch (SQLException sqlE) {
			try {
				log.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
			throw sqlE;
		} catch (IOException ioE) {
			try {
				log.error(ioE.getMessage(), ioE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception ioE2) {
				log.error(ioE2.getMessage(), ioE2);
			}
		}
	}

	public static int updateSARsVersionSDI(int versionSDI, ArrayList<Integer> sars)
			throws SQLException, ClassNotFoundException {
		Connection con = null;
		int resultado = 0;
		DAOUtils utils = new DAOUtils();
		try {
			con = ConexionDB.dameConexion();

			PreparedStatement pst = null;
			StringBuffer query = new StringBuffer();

			query.append(" UPDATE cdiSAR ");
			query.append(" SET versionSetDocumentos= ").append(versionSDI).append(" ");
			query.append(" WHERE folio  in ( ");
			int x = 0;
			for (Integer folio : sars) {
				if (x > 0) {
					query.append(",");
				}
				query.append("?");
				x++;
			}
			query.append(" ) ");

			pst = con.prepareStatement(query.toString());

			utils.inicializaQuery(query.toString());
			int cont = 1;
			for (Integer folio : sars) {
				utils.ajustaParametro(cont++, pst, folio, Integer.class);
			}
			resultado = pst.executeUpdate();

			pst.close();

			ConexionDB.devuelveConexion(con);

		} catch (SQLException sqlE) {
			try {
				log.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
			throw sqlE;
		} catch (IOException ioE) {
			try {
				log.error(ioE.getMessage(), ioE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception ioE2) {
				log.error(ioE2.getMessage(), ioE2);
			}
		}
		return resultado;
	}

	public static BeanControlSDI selectControlSDI(BeanControlSDI control) throws ClassNotFoundException {

		BeanControlSDI obj = null;
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();

			ResultSet rs = null;
			PreparedStatement pst = null;
			StringBuffer query = new StringBuffer();

			query.append(" SELECT versionSDI, proveedor, booking, idDocumentos, fechaAceptaProveedor,  ");
			query.append(" comentarioProveedor, analista, aprobado, fechaAprobadoSDI,fechaAsignadoAnalista ");
			query.append(" FROM   cdiControlSDI ");
			query.append(" WHERE proveedor = ? ");
			query.append(" AND rtrim(ltrim(booking)) = ? ");

			pst = con.prepareStatement(query.toString());
			int cont = 1;
			pst.setString(cont++, control.getProveedor());
			pst.setString(cont++, control.getBooking());
			rs = pst.executeQuery();
			while (rs.next()) {
				obj = new BeanControlSDI();
				obj.setVersionSDI(rs.getInt("versionSDI"));
				obj.setProveedor(rs.getString("proveedor"));
				obj.setBooking(rs.getString("booking"));
				obj.setIdDocumentos(rs.getInt("idDocumentos"));
				obj.setFechaAceptaProveedor(rs.getDate("fechaAceptaProveedor"));
				obj.setComentariosProveedor(rs.getString("comentarioProveedor"));
				obj.setAnalistaSDI(rs.getString("analista"));
				obj.setAprobadoSDI(rs.getBoolean("aprobado"));
				obj.setFechaAprobadoSDI(rs.getDate("fechaAprobadoSDI"));
				obj.setFechaAsignado(rs.getDate("fechaAsignadoAnalista"));
			}
			rs.close();
			pst.close();

			ConexionDB.devuelveConexion(con);

		} catch (SQLException sqlE) {
			try {
				log.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
		return obj;
	}

	/**
	 * Me regresa los datos que voy a mostrar en la vista de SARs con documentos
	 * 
	 * @deprecated Utilizar
	 *             {@link ShpmntsWdocsDao#getDocuments(SearchParamsDocs, String)}
	 * @param control
	 * @param vista   --> es "NUEVOS" o "AMENDED", los nuevos son los que acaban de
	 *                llegar y los amenden tiene una revision
	 * @return
	 * @throws ClassNotFoundException
	 */
	public static ArrayList<BeanVistaDocumentos> selectControlSDIVista(SearchParamsDocs search, String vista)
			throws ClassNotFoundException {

		ArrayList<BeanVistaDocumentos> lista = new ArrayList<>();
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();

			ResultSet rs = null;
			PreparedStatement pst = null;
			StringBuffer query = new StringBuffer();

			query.append(" SELECT a.booking,c.versionSDI,c.idDocumentos,a.proveedor,c.comentarioProveedor,  ");
			query.append(" c.analista,c.aprobado,c.fechaAprobadoSDI,c.fechaAceptaProveedor,c.fechaAsignadoAnalista  ");
			query.append(" FROM cdisar a inner join cdiDocumentosSDI b  ");
			query.append(
					" ON a.booking = b.booking and a.versionSetDocumentos = b.versionSDI and a.proveedor = b.proveedor ");
			query.append(" INNER JOIN cdiControlSDI c ON   ");
			query.append(" c.booking = b.booking and c.versionSDI = b.versionSDI and c.proveedor = b.proveedor  ");
			query.append(" Inner join cdisardetalle d ON a.folio = d.folio ");
			query.append(" INNER join cdi_facturas f  ON b.id = f.id and f.versionDocumento = b.versionFacturas ");
			query.append(" and d.condicionPago = f.condicionPago  ");

			if ("NUEVOS".equals(vista)) {// Si es null es nuevo si es 0 es amended
				query.append(" AND aprobado IS NULL ");
			} else if ("AMENDED".equals(vista)) {
				query.append(" AND aprobado = 0  AND a.status=").append(SarBO.STATUS_INICIO_SDI).append(" ");
			} else {
				query.append(" AND aprobado = 1 ");
			}
			if (search.getProveedor() != null) {
				query.append(" AND a.proveedor = ? ");
			}
			if (search.getBl() != null) {
				query.append(" AND a.bl = ?");
			}
			if (search.getInvoice() != null) {
				query.append(" AND f.nombre ?");
			}
			if (search.getEtaFrom() != null && search.getEtaTo() != null) {
				query.append(" AND a.eta BETWEEN ? AND ? ");
			}
			if (search.getPo() != null) {
				query.append(" AND d.po =?");
			}
			if (search.getPrioridad() != null && search.getPrioridad() > 0) {
				query.append(" AND a.prioridad =?");
			}
			if (search.getBooking() != null) {
				query.append(" AND c.booking =?");
			}
			if (search.getContenedor() != null) {
				query.append(" AND a.contenedor =?");
			}
			if (search.getNaviera() != null && search.getNaviera() > 0) {
				query.append(" AND a.naviera =?");
			}
			if (search.getAnalyst() != null && !"-1".equals(search.getAnalyst())) {
				query.append(" AND c.analista =?");
			}

			if (search.getApprovalFrom() != null && search.getApprovalTo() != null) {
				query.append(" AND c.fechaAprobadoSDI BETWEEN ? AND ? ");
			}

			query.append(" GROUP BY a.booking,c.versionSDI,c.idDocumentos,a.proveedor,c.comentarioProveedor, ");
			query.append(" c.analista,c.aprobado,c.fechaAprobadoSDI,c.fechaAceptaProveedor,c.fechaAsignadoAnalista ");
			query.append(" ORDER BY c.fechaaceptaproveedor asc ");

			pst = con.prepareStatement(query.toString());

			int cont = 1;
			if (search.getProveedor() != null) {
				pst.setString(cont++, search.getProveedor());
			}
			if (search.getBl() != null) {
				pst.setString(cont++, search.getBl());
			}
			if (search.getInvoice() != null) {
				pst.setString(cont++, search.getInvoice());
			}
			if (search.getEtaFrom() != null && search.getEtaTo() != null) {
				pst.setInt(cont++, FuncionesComunesPLI.transformaFormatoFecha(search.getEtaFrom()));
				pst.setInt(cont++, FuncionesComunesPLI.transformaFormatoFecha(search.getEtaTo()));
			}
			if (search.getPo() != null) {
				pst.setString(cont++, search.getPo());
			}
			if (search.getPrioridad() != null && search.getPrioridad() > 0) {
				pst.setInt(cont++, search.getPrioridad());
			}
			if (search.getBooking() != null) {
				pst.setString(cont++, search.getBooking());
			}
			if (search.getContenedor() != null) {
				pst.setString(cont++, search.getContenedor());
			}
			if (search.getNaviera() != null && search.getNaviera() > 0) {
				pst.setInt(cont++, search.getNaviera());
			}
			if (search.getAnalyst() != null && !"-1".equals(search.getAnalyst())) {
				pst.setString(cont++, search.getAnalyst());
			}
			if (search.getApprovalFrom() != null && search.getApprovalTo() != null) {
				GregorianCalendar gFrom = FuncionesComunesPLI
						.int2GregorianCalendar(FuncionesComunesPLI.transformaFormatoFecha(search.getApprovalFrom()));
				GregorianCalendar gTo = FuncionesComunesPLI
						.int2GregorianCalendar(FuncionesComunesPLI.transformaFormatoFecha(search.getApprovalTo()));
				java.sql.Date dTo = new java.sql.Date(gFrom.getTimeInMillis());
				java.sql.Date dFrom = new java.sql.Date(gTo.getTimeInMillis());
				pst.setDate(cont++, dTo);
				pst.setDate(cont++, dFrom);
			}

			rs = pst.executeQuery();
			while (rs.next()) {
				BeanVistaDocumentos obj = new BeanVistaDocumentos();
				obj.setVersionSDI(rs.getInt("versionSDI"));
				obj.setProveedor(rs.getString("proveedor"));
				obj.setBooking(rs.getString("booking"));
				obj.setIdDocumentos(rs.getInt("idDocumentos"));
				obj.setFechaAceptaProveedor(rs.getDate("fechaAceptaProveedor"));
				obj.setComentariosProveedor(rs.getString("comentarioProveedor"));
				obj.setAnalistaSDI(rs.getString("analista"));
				obj.setAprobadoSDI(rs.getBoolean("aprobado"));
				obj.setFechaAprobadoSDI(rs.getDate("fechaAprobadoSDI"));
				obj.setFechaAsignado(rs.getDate("fechaAsignadoAnalista"));
				lista.add(obj);
			}
			rs.close();
			pst.close();

			ConexionDB.devuelveConexion(con);

		} catch (SQLException sqlE) {
			try {
				log.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
		return lista;
	}

	public static ArrayList<BeanArregloPuertosDestino> selectControlSDIVistaSelector() throws ClassNotFoundException {

		ArrayList<BeanArregloPuertosDestino> lista = new ArrayList<BeanArregloPuertosDestino>();
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();

			ResultSet rs = null;
			PreparedStatement pst = null;
			

			pst = con.prepareStatement(SELECT_CONTROL_SDI_VISTA_SELECTOR);
			rs = pst.executeQuery();
			while (rs.next()) {
				BeanArregloPuertosDestino obj = new BeanArregloPuertosDestino();
				obj.setClavePuertoDescarga(rs.getString("puertoDescarga"));
				Boolean b = rs.getBoolean("esPedidoDirecto");
				obj.setDirecto(Boolean.TRUE.equals(b));

				lista.add(obj);
			}
			rs.close();
			pst.close();

			ConexionDB.devuelveConexion(con);

		} catch (SQLException sqlE) {
			try {
				log.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
		return lista;
	}

	public static void insertaControlSDI(BeanControlSDI doc) throws ServletException {
		Connection con = null;
		Statement st = null;
		StringBuffer insert = new StringBuffer();

		insert.append("INSERT INTO cdiControlSDI ( ");
		insert.append(" versionSDI, proveedor, booking, idDocumentos,fechaAceptaProveedor,analista, ");
		insert.append("fechaAsignadoAnalista,comentarioProveedor  ");
		insert.append(")");
		insert.append(" VALUES (");
		insert.append(doc.getVersionSDI());
		insert.append(",");
		insert.append("'").append(doc.getProveedor()).append("'");
		insert.append(",");
		insert.append("'").append(doc.getBooking()).append("'");
		insert.append(",");
		insert.append(doc.getIdDocumentos());
		insert.append(",");
		insert.append(" getDate(), ");
		insert.append("'").append(doc.getAnalistaSDI()).append("'");
		insert.append(", getDate(), ");
		insert.append("'").append(doc.getComentariosProveedor()).append("'");
		insert.append(")");

		boolean exito = false;

		try {

			con = ConexionDB.dameConexion();
			st = con.createStatement();
			exito = st.executeUpdate(insert.toString()) == 1;

			ConexionDB.devuelveConexion(con);
			st.close();
			if (!exito) {
				throw new Exception("No se insert� ningun registro, favor de verificar");
			}
		} catch (Exception e) {
			e.printStackTrace();
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error("[insertaDocumentosSDI] Error " + ex.getMessage(), ex);
			}
			log.error("[insertaDocumentosSDI] Error " + e.getMessage(), e);
			throw new ServletException(e);
		}
	}

	public static void updateControlSDI(BeanControlSDI doc) throws ServletException, SQLException {
		Connection con = null;
		Statement st = null;
		StringBuffer insert = new StringBuffer();
		int result = 0;
		DAOUtils utilDao = new DAOUtils();
		utilDao.setSelect(false);
		insert.append("UPDATE cdiControlSDI SET ");
		if (doc.getFechaAceptaProveedor() != null) {
			insert.append(utilDao.ajustaColumna(" fechaAceptaProveedor = "));
			insert.append("getDate() ");
		}
		if (doc.getIdDocumentos() != null) {
			insert.append(utilDao.ajustaColumna(" idDocumentos ="));
			insert.append(doc.getIdDocumentos()).append(" ");
		}
		String comentariosProveedor = doc.getComentariosProveedor();
		if (comentariosProveedor != null) {
			insert.append(utilDao.ajustaColumna(" comentarioProveedor = ? "));
		}

		if (doc.getAnalistaSDI() != null) {
			insert.append(utilDao.ajustaColumna(" analista = ")).append("'");
			insert.append((doc.getAnalistaSDI())).append("' ");
			insert.append(utilDao.ajustaColumna(" fechaAsignadoAnalista = getDate() "));
		}
		if (doc.getAprobadoSDI() != null) {
			insert.append(utilDao.ajustaColumna(" aprobado = "));
			insert.append(doc.getAprobadoSDI() ? 1 : 0).append(" ");
		}

		if (doc.getFechaAprobadoSDI() != null) {
			insert.append(utilDao.ajustaColumna(" fechaAprobadoSDI = "));
			insert.append("getDate() ");
		}

		if (doc.getVersionSDI() != null) {
			insert.append(utilDao.ajustaColumna(" versionSDI = "));
			insert.append(doc.getVersionSDI());
		}

		String tipoBl = doc.getTipoBl();
		if (UtilsString.isStringValida(tipoBl)) {
			insert.append(utilDao.ajustaColumna(" tipoBl = '")).append(tipoBl.trim()).append("'");
		}

		insert.append(" WHERE ");

		insert.append(" proveedor =  ").append("'").append(doc.getProveedor()).append("'");
		insert.append(" AND booking =  ").append("'").append(doc.getBooking()).append("'");

		try {
			con = ConexionDB.dameConexion();
			try (PreparedStatement pst = con.prepareStatement(insert.toString())) {
				if (comentariosProveedor != null) {
					pst.setString(1, comentariosProveedor);
				}
				result = pst.executeUpdate();
			}
		} catch (Exception e) {
			e.printStackTrace();
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error("[updateControlSDI] Error " + ex.getMessage(), ex);
			}
			log.error("[updateControlSDI] Error " + e.getMessage(), e);
			throw new ServletException(e);
		} finally {
			ConexionDB.devuelveConexion(con);
		}
		if (result == 0) {
			log.error("[updateControlSDI] Ningun registro modificado en el update");
			throw new ServletException("Ningun registro modificado en el update");
		}
	}

	public static ArrayList<UsuarioBean> dameAnalistasSDI() throws ClassNotFoundException {

		ArrayList<UsuarioBean> lista = new ArrayList<UsuarioBean>();
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();

			ResultSet rs = null;
			PreparedStatement pst = null;
			StringBuffer query = new StringBuffer();

			query.append(" select username,realname from cdiusers a, cdiuserprofiles b   ");
			query.append(" where b.profilename = 'general.userProfile.documentsAnalyst'  ");
			query.append(" and b.id=a.userprofile ");

			pst = con.prepareStatement(query.toString());
			rs = pst.executeQuery();
			while (rs.next()) {
				UsuarioBean obj = new UsuarioBean();
				obj.setNombre(rs.getString("realname") == null?"": rs.getString("realname"));
				obj.setUsuario(rs.getString("username"));

				lista.add(obj);
			}
			rs.close();
			pst.close();

			ConexionDB.devuelveConexion(con);

		} catch (SQLException sqlE) {
			try {
				log.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
		return lista;
	}

	public static String analistasSDIPorNaviera(int naviera) throws ClassNotFoundException {

		String result = null;
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();

			ResultSet rs = null;
			PreparedStatement pst = null;
			StringBuffer query = new StringBuffer();

			query.append(" select naviera, analistaSDI   ");
			query.append(" FROM cdi_analistaPorNavieraSDI ");
			query.append(" WHERE naviera = " + naviera);

			pst = con.prepareStatement(query.toString());
			rs = pst.executeQuery();
			while (rs.next()) {
				result = rs.getString("analistaSDI");
			}
			rs.close();
			pst.close();

			ConexionDB.devuelveConexion(con);

		} catch (SQLException sqlE) {
			try {
				log.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
		return result;
	}

	public static ArrayList<SarDetalleBO> dameDatosDetalles(String sars) throws ClassNotFoundException {
		Connection con = null;
		ArrayList<SarDetalleBO> listaResult = new ArrayList<>(300);
		try {
			con = ConexionDB.dameConexion();

			ResultSet rs = null;
			PreparedStatement pst = null;
			StringBuffer query = new StringBuffer();

			query.append(
					"SELECT sar.folio,status,po, posicion , material , cantidad , pesoProveedor , volumenProveedor ,");
			query.append(
					" centro,planeador,cantidadModificada,pesoModificado,volumenModificado,cliente,fechaProforma, ");
			query.append(
					" paisOrigen,noDocumento,cartones,cantidadXcarton,pesoneto,pesobruto,cubicaje,pallet,cartonxpallet,");
			query.append(" unidadMedida,condicionPago,moneda,preciounitario, esPedidoDirecto,");
			query.append(
					" tieneDiferenciaMRP, statusMRP, tipoValidacionMRP, almacen, cantidadUnidadMedida, factorCantidadUnidadMedida, descripcionComplementoFactura, eliminarProyeccion, commentDeleteProjection  ");
			query.append(" FROM cdisar sar WITH (NOLOCK) INNER JOIN  cdisardetalle det WITH (NOLOCK) ON sar.folio = det.folio ");
			query.append(" WHERE sar.folio IN (");
			query.append(sars);
			query.append(" ) ");
			query.append(" UNION ");
			query.append(
					"SELECT sar.folio,status,po, posicion , material , cantidad , pesoProveedor , volumenProveedor ,");
			query.append(
					" centro,planeador,cantidadModificada,pesoModificado,volumenModificado,cliente,fechaProforma, ");
			query.append(
					" paisOrigen,noDocumento,cartones,cantidadXcarton,pesoneto,pesobruto,cubicaje,pallet,cartonxpallet,");
			query.append(" unidadMedida,condicionPago,moneda,preciounitario, esPedidoDirecto,");
			query.append(
					" tieneDiferenciaMRP, statusMRP, tipoValidacionMRP, almacen, cantidadUnidadMedida, factorCantidadUnidadMedida, descripcionComplementoFactura, eliminarProyeccion, commentDeleteProjection  ");
			query.append(" FROM cdisar sar WITH (NOLOCK) INNER JOIN  cdiSARDetalleRechazados rech WITH (NOLOCK) ON  sar.folio = rech.folio ");
			query.append(" WHERE sar.folio IN (");
			query.append(sars);
			query.append(" )");

			pst = con.prepareStatement(query.toString());
			rs = pst.executeQuery();
			while (rs.next()) {
				SarDetalleBO tmp = new SarDetalleBO();
				tmp.setFolio(rs.getInt("folio"));
				tmp.setPo(rs.getString("po"));
				if (!rs.wasNull()) {
					tmp.setPo(tmp.getPo().trim());
				}
				tmp.setPosicion(rs.getInt("posicion"));
				tmp.setMaterial(rs.getInt("material"));
				tmp.setCantidad(rs.getInt("cantidad"));
				tmp.setPesoProveedor(rs.getDouble("pesoProveedor"));
				tmp.setVolumenProveedor(rs.getDouble("volumenProveedor"));
				tmp.setCentro(rs.getString("centro"));
				tmp.setPlaneador(rs.getString("planeador"));
				tmp.setCantidadModificada(rs.getInt("cantidadModificada"));
				tmp.setPesoModificado(rs.getDouble("pesoModificado"));
				tmp.setVolumenModificado(rs.getDouble("volumenModificado"));
				tmp.setCliente(rs.getString("cliente"));
				tmp.setFechaProforma(rs.getInt("fechaProforma"));
				tmp.setPaisOrigen(rs.getInt("paisOrigen"));
				tmp.setNumeroDoc(rs.getString("noDocumento"));
				tmp.setCartones(rs.getInt("cartones"));
				tmp.setCantidadXCarton(rs.getInt("cantidadXcarton"));
				tmp.setPesoNetoPKL(rs.getBigDecimal("pesoneto"));
				tmp.setPesoBrutoPKL(rs.getBigDecimal("pesobruto"));
				tmp.setCubicajePKL(rs.getBigDecimal("cubicaje"));
				tmp.setPallet(rs.getInt("pallet"));
				tmp.setCartonXPallet(rs.getInt("cartonxpallet"));
				tmp.setUnidaMedida(rs.getString("unidadMedida"));
				tmp.setCondicionPago(rs.getString("condicionPago"));
				tmp.setMoneda(rs.getString("moneda"));
				tmp.setPrecioUnitario(rs.getBigDecimal("preciounitario"));
				tmp.setPedidoDirecto(rs.getBoolean("esPedidoDirecto"));
				tmp.setTieneDiferenciasMRP(rs.getBoolean("tieneDiferenciaMRP"));
				tmp.setStatusMRP(rs.getInt("statusMRP"));
				tmp.setTipoValidacionMRP(rs.getInt("tipoValidacionMRP"));
				tmp.setAlmacen(rs.getString("almacen"));
				tmp.setCantidadUnidadMedida(rs.getBigDecimal("cantidadUnidadMedida"));
				tmp.setFactorCantidadUnidadMedida(rs.getBigDecimal("factorCantidadUnidadMedida"));
				tmp.setDescripcionComplementoFactura(rs.getString("descripcionComplementoFactura"));
				tmp.setEliminarProyeccion(rs.getBoolean("eliminarProyeccion"));
				tmp.setCommentDeleteProjection(rs.getString("commentDeleteProjection"));
				ProductoBean prod = FuncionesComunesPLI.productos.get(tmp.getMaterial().toString());
				if(prod != null){
					tmp.setDescripcion(prod.getDescripcion());
				}
				listaResult.add(tmp);
			}
			rs.close();
			pst.close();

			ConexionDB.devuelveConexion(con);

		} catch (SQLException sqlE) {
			try {
				log.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(con);
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
		return listaResult;
	}

	/**
	 * Uso metodo para sacar el ETD de cada folio SAR.
	 * 
	 * @param sars
	 * @return
	 * @throws ClassNotFoundException
	 */
	public static ArrayList<SarBO> dameFoliosParaDetalles(String sars) throws ClassNotFoundException {
		Connection con = null;
		ArrayList<SarBO> listaResult = new ArrayList<>(300);
		try {
			con = ConexionDB.dameConexion();

			ResultSet rs = null;
			PreparedStatement pst = null;
			StringBuffer query = new StringBuffer();

			query.append("SELECT folio, fechaembarque, etdFinal FROM cdisar WHERE folio in (");
			query.append(sars);
			query.append(" )");

			pst = con.prepareStatement(query.toString());
			rs = pst.executeQuery();
			while (rs.next()) {
				SarBO tmp = new SarBO();
				tmp.setFolio(rs.getInt("folio"));
				tmp.setFechaEmbarque(rs.getInt("fechaembarque"));
				tmp.setEtdReal(rs.getInt("etdFinal"));

				listaResult.add(tmp);
			}
			rs.close();
			pst.close();

			ConexionDB.devuelveConexion(con);

		} catch (SQLException sqlE) {
			try {
				log.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(con);
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
		return listaResult;
	}

	public static boolean isFolioAReferenceNumber(Integer folio) {

		boolean res = false;

		Connection con = null;
		StringBuffer query = new StringBuffer();

		try {
			con = ConexionDB.dameConexion();

			ResultSet rs = null;
			PreparedStatement pst = null;
			query.append("SELECT COUNT(*) FROM cdiReferenceNumber WHERE folio = ?");

			pst = con.prepareStatement(query.toString());
			pst.setInt(1, folio);

			rs = pst.executeQuery();

			while (rs.next()) {
				res = rs.getInt(1) > 0;
			}

			rs.close();
			pst.close();
			ConexionDB.devuelveConexion(con);

		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
				;
			} catch (Exception ex) {
				log.error("Error al renovar la conexion a la BD", e);
			}
			log.error("Error al ejecutar la consulta: " + query.toString(), e);
		} catch (Exception e) {
			e.printStackTrace();
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error("Error al devolver la conexion al POOL", e);
			}
			log.error("Error al ejecutar el metodo isFolioAReferenceNumber", e);
		}

		return res;
	}

	/**
	 * @throws ServletException
	 * 
	 */
	public static FasesSARBO selectSAR_ControlReference(SarBO folio) {

		Connection con = null;
		FasesSARBO resultado = null;

		try {
			con = ConexionDB.dameConexion();

			ResultSet rs = null;
			PreparedStatement pst = null;

			StringBuilder sbWhere = new StringBuilder();
			sbWhere.append(" WHERE s.folio = ? ");

			pst = con.prepareStatement(CONTROL_REFERENCE + sbWhere.toString());
			pst.setInt(1, folio.getFolio());
			rs = pst.executeQuery();

			while (rs.next()) {
				resultado = new FasesSARBO();
				resultado.setFolio(rs.getInt("folio"));
				resultado.setStatus(rs.getInt("status"));
				resultado.setNeedAuthImpDir(rs.getBoolean("needAuthImpDir"));
				resultado.setAprobadoDirImportaciones(rs.getBoolean("aprobadoDirImportaciones"));
				resultado.setAprobadoConfMngr(rs.getBoolean("aprobadoConfMngr"));   
				resultado.setConsolidado(rs.getBoolean("consolidado"));
				resultado.setFolioConsolidado(rs.getInt("folioConsolidado"));
				resultado.setBooking(rs.getString("booking"));
				resultado.setEnRevisionConfirmFinal(rs.getBoolean("enRevisionConfirmFinal"));
				resultado.setAprobadoProveedor(rs.getBoolean("aprobadoProveedor"));
				resultado.setVersionSetDocumentos(rs.getInt("versionSetDocumentos"));
				resultado.setExisteRegistroControl(rs.getString("bookingCont") != null);
				resultado.setProveedor(rs.getString("proveedor"));
				resultado.setAprobadoSDI(rs.getBoolean("aprobado"));
				resultado.setExisteRegistroReference(rs.getInt("folioRefNum") > 0);
				resultado.setReferenceNumber(rs.getString("referenceNumber"));
				resultado.setPreciosRevisados(rs.getBoolean("preciosRevisados"));
				Timestamp ts = rs.getTimestamp("fechaConfirmacionFinal");
				Date date = ts != null ? new Date(ts.getTime()) : null;
				resultado.setFechaConfirmacionFinal(date);

			}
			rs.close();
			pst.close();

			ConexionDB.devuelveConexion(con);

		} catch (SQLException sqlE) {
			try {
				log.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);

			}

		} catch (ClassNotFoundException e) {
			try {
				log.error(e.getMessage(), e);
				ConexionDB.renuevaConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);

			}

		}

		return resultado;
	}
	

	// CONSULTAS AUTOMATIZACI�N BOOKING
	public static SAR getSARByFolio(String folio) {
		Connection con = null;
		ResultSet rs = null;
		PreparedStatement pst = null;
		SAR sar = new SAR();
		try {
			StringBuilder sql = new StringBuilder();

			sql.append(
					" select sar.puertoSalida, sar.puertoDescarga,  sar.puertoDescarga , sar.booking , sar.usuarioApruebaPlanning ,  det.esPedidoDirecto , sar.naviera , sar.contenedor, sar.BL, ")
					.append(" sar.viaje , sar.barcoSugerido ,  sar.etdFinal , sar.eta ").append(" from cdiSAR sar ")
					.append(" inner join cdiSARDetalle det on sar.folio = det.folio ").append(" where sar.folio  = ? ")
					.append(" group by sar.puertoSalida,  sar.puertoDescarga,  sar.puertoDescarga ,  sar.booking , sar.folio,sar.usuarioApruebaPlanning,det.esPedidoDirecto,sar.naviera,sar.viaje,sar.barcoSugerido,sar.etdFinal,sar.eta, sar.contenedor, sar.BL    ");

			con = ConexionDB.dameConexion();
			pst = con.prepareStatement(sql.toString());
			pst.setString(1, folio);
			rs = pst.executeQuery();

			while (rs.next()) {
				sar.setUsuarioApruebaPlanning(rs.getString("usuarioApruebaPlanning"));
				sar.setTienePedidoDirecto(rs.getBoolean("esPedidoDirecto"));

				sar.setBooking(rs.getString("booking"));
				sar.setNaviera(rs.getInt("naviera"));
				sar.setViaje(rs.getString("viaje"));
				sar.setBarcoSugerido(rs.getString("barcoSugerido"));
				sar.setEtdReal(rs.getInt("etdFinal"));
				sar.setEta(rs.getInt("eta"));
				sar.setPuertoDescarga(rs.getString("puertoDescarga"));
				sar.setPuertoSalida(rs.getString("puertoSalida"));
				sar.setContenedor(rs.getString("contenedor"));	
				sar.setBl(rs.getString("BL"));				
			}

			con.close();

		} catch (Exception e) {
			log.error(e.toString(), e);
		} finally {
			ConexionDB.devolver(con);
		}
		return sar;

	}

	public static boolean addCommentRM(String folio, String comment, String commentType, int idUser) {
		Connection con = null;
		Statement st = null;

		try {

			StringBuilder queryRM = new StringBuilder();
			queryRM.append("     INSERT INTO [cdiSarRM_Chat]  ")
					.append(" ([folio]  ,[id_user] ,[commentType]  ,[comment])  VALUES  (   ").append("'").append(folio)
					.append("','").append(idUser).append("', '").append(commentType).append("', '").append(comment)
					.append("' )");

			con = ConexionDB.dameConexion();
			st = con.createStatement();
			st.execute(queryRM.toString());

			con.close();
			return true;

		} catch (Exception e) {
			log.error(e.toString(), e);
		} finally {
			ConexionDB.devolver(con);
		}
		return false;
	}

	public static boolean insertRM(SarRM_BO sarRM) {
		Connection con = null;
		Statement st = null;

		try {

			StringBuilder queryRM = new StringBuilder();
			queryRM.append("IF EXISTS (SELECT * FROM cdiSarRM WHERE folio = '").append(sarRM.getFolio()).append("'")
					.append(") ").append(" BEGIN  ").append(" update cdiSarRM  set estatus_RM = 'pendiente_rm' , ")
					.append(" booking = ")
					.append(sarRM.getBooking() != null
							? (UtilsSQL.getInstance().clearStringsSQL(sarRM.getBooking()) + ",")
							: "null  , ")
					.append(" carrier = ")
					.append(sarRM.getCarrier() != null ? ("'" + sarRM.getCarrier() + "',") : "null  , ")
					.append(" voyage  = ")
					.append(sarRM.getVoyage() != null ? ("'" + sarRM.getVoyage() + "',") : "null ,")
					.append(" vessel  = ")
					.append(sarRM.getVessel() != null ? ("'" + sarRM.getVessel() + "',") : "null ,")
					.append(" pol    = ").append(sarRM.getPol() != null ? ("'" + sarRM.getPol() + "',") : "null  , ")
					.append(" pod    = ").append(sarRM.getPod() != null ? ("'" + sarRM.getPod() + "',") : "null  , ")
					.append(" etd    = ").append(sarRM.getEtd() != null ? ("'" + sarRM.getEtd() + "',") : "null  , ")
					.append(" eta    = ").append(sarRM.getEta() != null ? ("'" + sarRM.getEta() + "',") : "null  , ")
					.append(" transist_time = ")
					.append(sarRM.getTransist_time() != null ? ("'" + sarRM.getTransist_time() + "', ") : "null ,  ")

					.append(" id_user = '").append(sarRM.getUserRM().getIdUser()).append("' ,").append(" reason = '")
					.append(sarRM.getMotivo()).append("', ").append(" create_date = GETDATE() ")
					.append(" WHERE folio = '").append(sarRM.getFolio()).append("'")
					.append("     END   ELSE BEGIN                                                                   ")
					.append("     INSERT INTO [cdiSarRM]                                                                  ")
					.append("                ([folio]                                                                     ")
					.append("                ,[booking]                                                                   ")
					.append("                ,[carrier]                                                                   ")
					.append("                ,[voyage]                                                                    ")
					.append("                ,[vessel]                                                                    ")
					.append("                ,[pol]                                                                       ")
					.append("                ,[pod]                                                                       ")
					.append("                ,[etd]                                                                       ")
					.append("                ,[eta]                                                                       ")
					.append("                ,[transist_time]                                                             ")
					.append("                ,[id_user]                                                                   ")
					.append("                ,[estatus_RM]                                                                ")
					.append("                ,[isConsol]                                                                  ")
					.append("                ,[reason])                                                                   ")

					.append("          VALUES                                                                             ")
					.append("                (                                                                            ")

					.append(sarRM.getFolio() != null ? ("'" + sarRM.getFolio() + "',") : "null  , ")

					.append(sarRM.getBooking() != null
							? (UtilsSQL.getInstance().clearStringsSQL(sarRM.getBooking()) + ",")
							: "null  , ")
					.append(sarRM.getCarrier() != null ? ("'" + sarRM.getCarrier() + "',") : "null  , ")
					.append(sarRM.getVoyage() != null ? ("'" + sarRM.getVoyage() + "',") : "null ,")
					.append(sarRM.getVessel() != null ? ("'" + sarRM.getVessel() + "',") : "null ,")
					.append(sarRM.getPol() != null ? ("'" + sarRM.getPol() + "',") : "null  , ")
					.append(sarRM.getPod() != null ? ("'" + sarRM.getPod() + "',") : "null  , ")
					.append(sarRM.getEtd() != null ? ("'" + sarRM.getEtd() + "',") : "null  , ")
					.append(sarRM.getEta() != null ? ("'" + sarRM.getEta() + "',") : "null  , ")
					.append(sarRM.getTransist_time() != null ? ("'" + sarRM.getTransist_time() + "',") : "null  , ")
					.append("'").append(sarRM.getUserRM().getIdUser() + "'").append(", 'pendiente_rm',")
					.append(sarRM.isConsol() ? "1" : "0").append(" , ")
					.append(sarRM.getMotivo() != null ? ("'" + sarRM.getMotivo() + "' )") : "null  ) ").append(" END");

			con = ConexionDB.dameConexion();
			st = con.createStatement();
			st.execute(queryRM.toString());

			con.close();
			return true;

		} catch (Exception e) {
			log.error(e.toString(), e);
		} finally {
			ConexionDB.devolver(con);
		}
		return false;
	}

	public static boolean tipificarRM(String folio, String estatus) {
		Connection con = null;
		Statement st = null;

		try {
			StringBuilder queryRM = new StringBuilder();
			queryRM.append(" update cdiSarRM set estatus_RM = '").append(estatus).append("'  where folio = '")
					.append(folio).append("'");

			con = ConexionDB.dameConexion();
			st = con.createStatement();

			st.executeUpdate(queryRM.toString());

			con.close();
		} catch (Exception e) {
			log.error(e.toString(), e);
		} finally {
			ConexionDB.devolver(con);
		}
		return true;
	}

	public static List<SarRMChat_BO> consultaChatsRM(String folio) {
		Connection con = null;
		Statement st = null;
		ResultSet rs = null;
		List<SarRMChat_BO> sarRMChats_list = new ArrayList<SarRMChat_BO>();

		try {
			StringBuilder queryRM = new StringBuilder();
			queryRM.append(" select usuario.realName , usuario.userEmail,  chat.*  from cdiSarRM_Chat chat  ")
					.append(" INNER JOIN cdiUsers usuario on usuario.id =  chat.id_user  WHERE chat.folio = '")
					.append(folio).append("'").append("				 order by create_date desc ");

			con = ConexionDB.dameConexion();
			st = con.createStatement();
			rs = st.executeQuery(queryRM.toString());

			while (rs.next()) {
				SarRMChat_BO sarChatRM = new SarRMChat_BO();
				sarChatRM.setComment(rs.getString("comment"));
				sarChatRM.setCommentType(rs.getString("commentType"));
				sarChatRM.setCreate_date(rs.getTimestamp("create_date"));

				UserBean user = new UserBean();
				user.setIdUser(rs.getInt("id_user"));
				user.setUserEmail(rs.getString("userEmail"));
				user.setUserName(rs.getString("realName"));

				sarChatRM.setUser(user);
				sarRMChats_list.add(sarChatRM);
			}

			con.close();
		} catch (Exception e) {
			log.error(e.toString(), e);
		} finally {
			ConexionDB.devolver(con);
		}
		return sarRMChats_list;
	}

	public static SarRM_BO consultaSarRMByFolio(String folio) {
		Connection con = null;
		Statement st = null;
		ResultSet rs = null;
		SarRM_BO sarRM = new SarRM_BO();

		try {
			StringBuilder queryRM = new StringBuilder();
			queryRM.append(
					" select sar.aprobadoProveedor, sar.paisDestino , rm.folio , rm.booking,  n.nombre, rm.vessel , rm.voyage , rm.pol , rm.pod , rm.eta ,  rm.etd , rm.carrier , rm.reason , rm.estatus_RM  , rm.create_date  from cdiSarRM rm ")
					.append(" left join cdiNavieras n on  rm.carrier = n.clave ")
					.append("  right join cdiSar sar on sar.folio= rm.folio ").append("  WHERE sar.folio = '")
					.append(folio).append("'");

			con = ConexionDB.dameConexion();
			st = con.createStatement();
			rs = st.executeQuery(queryRM.toString());

			while (rs.next()) {
				sarRM.setFolio(rs.getString("folio"));
				sarRM.setBooking(rs.getString("booking"));
				sarRM.setCarrier(rs.getString("nombre"));
				sarRM.setVessel(rs.getString("vessel"));
				sarRM.setVoyage(rs.getString("voyage"));
				sarRM.setPol(rs.getString("pol"));
				sarRM.setPod(rs.getString("pod"));
				sarRM.setEta(rs.getString("eta"));
				sarRM.setEtd(rs.getString("etd"));
				sarRM.setCarrierId(rs.getInt("carrier"));
				sarRM.setMotivo(rs.getString("reason"));
				sarRM.setFechaSolicitado(rs.getTimestamp("create_date"));
				sarRM.setReason(rs.getString("reason"));
				sarRM.setEstatus_RM(rs.getString("estatus_RM"));
				sarRM.setPaisDestino(rs.getInt("paisDestino"));
				sarRM.setTieneConfFinal(rs.getBoolean("aprobadoProveedor"));
			}

			con.close();

		} catch (Exception e) {
			log.error(e.toString(), e);
		} finally {
			ConexionDB.devolver(con);
		}
		return sarRM;
	}

	public static SarRM_BO consulta_Sar_RM(String folio) {
		Connection con = null;
		Statement st = null;
		ResultSet rs = null;
		SarRM_BO responseSar = new SarRM_BO();
		try {
			StringBuilder querySar = new StringBuilder();
			querySar.append(
					"SELECT s.folio, s.booking, n.nombre, s.barcoSugerido , s.viaje , s.puertoSalida , s.puertoDescarga , s.eta ")
					.append(" , ").append(SarDao.CONDICION_ETD_ETDFINAL).append(" as etd   FROM  cdiSar  s ")
					.append(" left join cdiNavieras n on  s.naviera = n.clave   WHERE s.folio =").append(folio);

			con = ConexionDB.dameConexion();
			st = con.createStatement();

			rs = st.executeQuery(querySar.toString());

			while (rs.next()) {
				SarRM_BO sar = new SarRM_BO();
				sar.setFolio(rs.getString("folio"));
				sar.setBooking(rs.getString("booking"));
				sar.setCarrier(rs.getString("nombre"));
				sar.setVessel(rs.getString("barcoSugerido"));
				sar.setVoyage(rs.getString("viaje"));
				sar.setPol(rs.getString("puertoSalida"));
				sar.setPod(rs.getString("puertoDescarga"));
				sar.setEta(rs.getString("eta"));
				sar.setEtd(rs.getString("etd"));
				responseSar = sar;
			}

			ConexionDB.devuelveConexion(con);
			con.close();
		} catch (Exception e) {
			log.error(e.toString(), e);
		} finally {
			ConexionDB.devolver(con);
		}

		return responseSar;
	}

	public static List<SarRM_BO> getSarRM_statusList(String estatus, UserBean user) {
		Connection con = null;
		PreparedStatement pst = null;
		ResultSet rs = null;

		List<SarRM_BO> sarRM_list = new ArrayList<SarRM_BO>();

		try {
			StringBuilder queryRM = new StringBuilder();
			queryRM.append(" SELECT sar.proveedor , rm.* , det.esPedidoDirecto, sar.aprobadoProveedor FROM  cdiSarRM rm ");
			queryRM.append(" inner join cdiSar sar on sar.folio = rm.folio ");
			queryRM.append(" right join  cdiSARDetalle det on sar.folio =  det.folio ");
			queryRM.append(" WHERE rm.estatus_RM  = ? ");
			List<UserProfileBean> profile = consultaPerfilUsuario(user);

			for (UserProfileBean p : profile) {
				if (!(p.isVeSARDirecto() && p.isVeSARNormal())) {
					queryRM.append(" and det.esPedidoDirecto  = ");
					queryRM.append(p.isVeSARDirecto() ? 1 : 0);

				}
			}

			queryRM.append(" group by sar.proveedor ,det.esPedidoDirecto ,  rm.folio, rm.booking , ");
			queryRM.append(" rm.carrier , rm.vessel , rm.voyage , rm.pol, rm.pod , rm.eta, rm.etd, ");
			queryRM.append(" rm.reason , rm.transist_time, rm.create_date , rm.id_user,rm.estatus_RM , rm.isConsol, sar.aprobadoProveedor ");

			con = ConexionDB.dameConexion();
			pst = con.prepareStatement(queryRM.toString());
			pst.setString(1, estatus);

			rs = pst.executeQuery();

			while (rs.next()) {
				SarRM_BO sarRM = new SarRM_BO();
				sarRM.setFolio(rs.getString("folio"));
				sarRM.setBooking(rs.getString("booking"));
				sarRM.setCarrier(rs.getString("carrier"));
				sarRM.setVessel(rs.getString("vessel"));
				sarRM.setVoyage(rs.getString("voyage"));
				sarRM.setPol(rs.getString("pol"));
				sarRM.setPod(rs.getString("pod"));
				sarRM.setEta(rs.getString("eta"));
				sarRM.setEtd(rs.getString("etd"));
				sarRM.setIdProveedor(rs.getInt("proveedor"));
				sarRM.setTieneConfFinal(rs.getBoolean("aprobadoProveedor"));
				sarRM.setProveedorBean(FuncionesComunesPLI.getProveedor(String.valueOf(sarRM.getIdProveedor())));
				sarRM.setMotivo(rs.getString("reason"));
				sarRM.setEsPedidoDirecto(rs.getBoolean("esPedidoDirecto"));

				int idUserLastChat = getIdUserForLastChat(sarRM.getFolio());
				sarRM.setIdUserLastChat(idUserLastChat);
				sarRM.setUnread(user.getIdUser() != idUserLastChat ? true : false);

				sarRM_list.add(sarRM);
			}

			con.close();
		} catch (Exception e) {
			log.error(e.toString(), e);
		} finally {
			ConexionDB.devolver(con);
		}
		return sarRM_list;
	}
	// FIN CONSULTAS AUTOMATIZACI�N BOOKING

	public static int getIdUserForLastChat(String folio) {
		Connection con = null;
		Statement st = null;
		ResultSet rs = null;

		int id_user = 0;
		try {

			StringBuilder queryRM = new StringBuilder();
			queryRM.append("select top 1 id_user from cdiSarRM_Chat  ").append(" where folio =  '").append(folio)
					.append("'").append(" order by create_date desc  ");

			con = ConexionDB.dameConexion();
			st = con.createStatement();
			rs = st.executeQuery(queryRM.toString());

			while (rs.next()) {
				id_user = rs.getInt("id_user");
			}

			con.close();
		} catch (Exception e) {
			log.error(e.toString(), e);
		} finally {
			ConexionDB.devolver(con);
		}
		return id_user;
	}

	public boolean insertRMLog(SarRM_BO sarRM) {
		Connection con = null;
		PreparedStatement preparedStatement = null;

		try {
			con = ConexionDB.dameConexion();

			preparedStatement = con.prepareStatement(ConsultasConstants.INSERT_RM_LOG);
			preparedStatement.setString(1, sarRM.getFolio());
			preparedStatement.setString(2, sarRM.getBooking());
			preparedStatement.setString(3, sarRM.getCarrier());
			preparedStatement.setString(4, sarRM.getVoyage());
			preparedStatement.setString(5, sarRM.getVessel());
			preparedStatement.setString(6, sarRM.getPol());
			preparedStatement.setString(7, sarRM.getPod());
			preparedStatement.setString(8, sarRM.getEtd());
			preparedStatement.setString(9, sarRM.getEtdAnterior());

			preparedStatement.setString(10, sarRM.getEta());
			preparedStatement.setString(11, sarRM.getTransist_time() == null ? "-1" : sarRM.getTransist_time());
			preparedStatement.setString(12, sarRM.getEstatus_RM());
			preparedStatement.setBoolean(13, sarRM.isConsol());
			preparedStatement.setString(14, sarRM.getReason());
			preparedStatement.setString(15, sarRM.getSupplier());
			preparedStatement.setString(16, sarRM.getBl());
			preparedStatement.setInt(17, sarRM.getTipoContenedor() == null ? -1 : sarRM.getTipoContenedor());
			preparedStatement.setString(18, sarRM.getContenedor());
			preparedStatement.setTimestamp(19, new java.sql.Timestamp(sarRM.getFechaSolicitado().getTime()));
			int row = preparedStatement.executeUpdate();
			con.close();

			return row == 1 ? true : false;
		} catch (Exception e) {
			log.error("Query: {}, Exception: {}", ConsultasConstants.INSERT_RM_LOG, e);
		} finally {
			ConexionDB.devolver(con);
		}
		return false;
	}

	public String findByfolio(String folio) {
		Connection con = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		String currentETD = "";

		try {
			con = ConexionDB.dameConexion();

			preparedStatement = con.prepareStatement(ConsultasConstants.FIND_FOLIO);
			preparedStatement.setString(1, folio);
			resultSet = preparedStatement.executeQuery();

			if (resultSet.next()) {
				currentETD = resultSet.getString("Current ETD");
			}
			con.close();
		} catch (Exception e) {
			log.error("Query: {}, Exception: {}", ConsultasConstants.FIND_FOLIO, e);
		} finally {
			ConexionDB.devolver(con);
		}
		return currentETD;
	}

	public List<RequestUpdateSupplierModel> getPendingUpdateSupplierByBooking() throws ServletException {
		Connection con = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		List<RequestUpdateSupplierModel> requestPendingList = new ArrayList<RequestUpdateSupplierModel>();
		try {
			con = ConexionDB.dameConexion();
			pst = con.prepareStatement(PENDING_UPDATESUPPLIER_ByBOOKING);

			rs = pst.executeQuery();

			while (rs.next()) {
				RequestUpdateSupplierModel requestUpdate = new RequestUpdateSupplierModel();

				requestUpdate.setBooking(rs.getString("booking"));
				requestUpdate.setBookingUpdateSupplier(rs.getString("bookingUpdateSupplier"));
				requestUpdate.setNaviera(rs.getInt("naviera"));
				requestUpdate.setCarrierUpdateSupplier(rs.getInt("carrierUpdateSupplier"));
				requestUpdate.setEtdFina(rs.getInt("etdFina"));
				requestUpdate.setDateEtdFinalUpdateSupplier(rs.getDate("dateETDFinalUpdateSupplier"));
				requestUpdate.setDateUpdateSupplier(rs.getDate("dateUpdateSupplier"));
				requestUpdate.setFolio(rs.getString("folio"));
				requestUpdate.setProveedor(rs.getString("proveedor"));
				requestUpdate.setPlanner(rs.getString("usuarioApruebaPlanning"));
			}

			rs.close();
			pst.close();
		} catch (Exception sqlE) {
			log.error(sqlE.getMessage(), sqlE);
		} finally {
			ConexionDB.devolver(con);
		}

		return requestPendingList;

	}
	
	
	public BeanDocumentosSDI getIdDocumentsSDIBySAR(Integer sar) throws ClassNotFoundException, ServletException 
	{
		Connection con = null;
		BeanDocumentosSDI beanDocumentosSDI = null;
		
		try 
		{
			con = ConexionDB.dameConexion();

			ResultSet rs = null;
			PreparedStatement pst = null;
			pst = con.prepareStatement(ConsultasConstants.GET_DOCUMENTS_SDI_BY_ID);
			pst.setInt(1, sar);
			rs = pst.executeQuery();

			if (rs.next()) 
			{
				beanDocumentosSDI = new BeanDocumentosSDI();
				beanDocumentosSDI.setId(rs.getInt("id"));
			}
			rs.close();
			pst.close();
		} 
		catch (Exception exception) 
		{
			log.error(exception.getMessage(), exception);
		} 
		finally 
		{
			ConexionDB.devolver(con);
		}
		return beanDocumentosSDI;
	}
	
	public String findReferenceNumberByfolio(String folio) {
		Connection con = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		String currentRN = "";
		try {
			con = ConexionDB.dameConexion();
			preparedStatement = con.prepareStatement(ConsultasConstants.FIND_REFERENCE_NUMBER_BY_FOLIO);
			preparedStatement.setString(1, folio);
			resultSet = preparedStatement.executeQuery();
			if (resultSet.next())
				currentRN = resultSet.getString("Reference Number");
			con.close();
		} catch (Exception e) {
			log.error("Query: {}, Exception: {}", ConsultasConstants.FIND_REFERENCE_NUMBER_BY_FOLIO, e);
		} finally {
			ConexionDB.devolver(con);
		}
		return currentRN;
	}
	
	public String getReleaseDateByShipping(String folio) {
		Connection con = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		String dateByShipping = "";
		try {
			con = ConexionDB.dameConexion();
			preparedStatement = con.prepareStatement(ConsultasConstants.GET_RELEASE_DATE_BYSHIPPING);
			preparedStatement.setString(1, folio);
			resultSet = preparedStatement.executeQuery();
			if (resultSet.next()) 
				dateByShipping = resultSet.getString("Approved by Shipping");
			con.close();
		} catch (Exception e) {
			log.error("Query: {}, Exception: {}", ConsultasConstants.GET_RELEASE_DATE_BYSHIPPING, e);
		} finally {
			ConexionDB.devolver(con);
		}
		return dateByShipping;
	}

	public Integer findActionHistoryByAction(String action) {
		Connection con = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		Integer currentAction = 0;
		try {
			con = ConexionDB.dameConexion();
			preparedStatement = con.prepareStatement(ConsultasConstants.FIND_ACTION_ID_BY_ACTION);
			preparedStatement.setString(1, action);
			resultSet = preparedStatement.executeQuery();
			if (resultSet.next())
				currentAction = resultSet.getInt("Action Id");
			con.close();
		} catch (Exception e) {
			log.error("Query: {}, Exception: {}", ConsultasConstants.FIND_ACTION_ID_BY_ACTION, e);
		} finally {
			ConexionDB.devolver(con);
		}
		return currentAction;
	}
	
	
	/**	
	 * cambia estatus de un sar para revision en vista de priserelease	
	 * 	
	 * @param status	
	 * @param sars	
	 * @return	
	 * @throws SQLException	
	 * @throws ClassNotFoundException	
	 */	
	public static void updateSARsPriceRelease(boolean status, Integer sar)	
			throws SQLException, ClassNotFoundException {	
		Connection con = null;	
		int resultado = 0;	
		DAOUtils utils = new DAOUtils();	
		try {	
			con = ConexionDB.dameConexion();	
			PreparedStatement pst = null;	
			StringBuffer query = new StringBuffer();	
			query.append(" UPDATE cdiSAR ");	
			query.append(" SET preciosEnRevision = ").append(status).append(" ");	
			query.append(" WHERE folio  =  ");	
			query.append( sar);	
			pst = con.prepareStatement(query.toString());	
			utils.inicializaQuery(query.toString());	
			int cont = 1;	
			utils.ajustaParametro(cont, pst, sar, Integer.class);	
			resultado = pst.executeUpdate();	
			pst.close();	
			if (resultado == 0) {	
				throw new SQLException("No se actualizo registro...");	
			}	
		} catch (SQLException sqlE) {	
			try {	
				log.error(sqlE.getMessage(), sqlE);	
				ConexionDB.renuevaConexion(con);	
			} catch (Exception sqlEx2) {	
				log.error(sqlEx2.getMessage(), sqlEx2);	
			}	
			throw sqlE;	
		} catch (IOException ioE) {	
			try {	
				log.error(ioE.getMessage(), ioE);	
				ConexionDB.renuevaConexion(con);	
			} catch (Exception ioE2) {	
				log.error(ioE2.getMessage(), ioE2);	
			}	
		}finally {	
			try {	
				ConexionDB.devuelveConexion(con);	
			} catch (Exception sqlEx2) {	
				log.error(sqlEx2.getMessage(), sqlEx2);	
			}	
		}	
	}	
	
	
	
	public static Boolean insertaControlEmb(ControlEmbarqueModel bean) {	
		Connection con = null;	
		Statement st = null;	
		ResultSet rs = null;	
			
		Boolean bol = false;	
			
		try {	
			String insert = "insert into cdiControlEmbarque(booking, folio, shiiping_line, buqueSalida, shipper, consoFull, lugarEntrega, instruccionBl, estatusDocumento, estatus, tAnalist, aa, comment)"	
					+ " VALUES ('" + bean.getBooking() + "', " + bean.getFolio() + ", '" + bean.getShippingLine()	
					+ "','" + bean.getBuqueSalida() + "', '" + bean.getShipper() + "', '" + bean.getConso() + "', '" + bean.getLugarEntrega() + "', '"	
					+ bean.getInstruccionBl() + "', '" + bean.getStatusDoc() + "','"	
					+ bean.getStatus() + "',"	
					+ "'" + bean.getTrafficAnalist() + "',"	
					+ "'" + bean.getCustomAgent()+ "',"	
					+ "'" + bean.getComment() + "')";	
			con = ConexionDB.dameConexion();	
			st = con.createStatement();	
			bol = st.execute(insert);	
				
			if (bol) {	
				throw new SQLException("No se actualizo registro de control de embarque...");	
			}	
			ConexionDB.devuelveConexion(con);	
		} catch (SQLException e) {	
			try {	
				ConexionDB.renuevaConexion(con);	
			} catch (Exception ex) {	
				log.error(ex.getMessage(), ex);	
			}	
			log.error(e.getMessage(), e);	
		} catch (Exception e) {	
			e.printStackTrace();	
			try {	
				ConexionDB.devuelveConexion(con);	
			} catch (Exception ex) {	
				log.error(ex.getMessage(), ex);	
			}	
			log.error(e.getMessage(), e);	
		} finally {	
			try {	
				ConexionDB.devuelveConexion(con);	
			} catch (Exception sqlEx2) {	
				log.error(sqlEx2.getMessage(), sqlEx2);	
			}	
		}	
		return bol;	
	}	
	
	
	public static Integer updateControlEmb(ControlEmbarqueModel bean) {	
		Connection con = null;	
		PreparedStatement pst = null;	
			
		Integer ra = 0;	
			
		try {	
			String update = "update cdiControlEmbarque set shiiping_line = '" + bean.getShippingLine() + "', buqueSalida = '" + bean.getBuqueSalida() + " ', "	
					+ "shipper = '" + bean.getShipper() + "', "	
					+ "consoFull = '" + bean.getConso() + "', "	
					+ "lugarEntrega = '" + bean.getLugarEntrega() + "', "	
					+ "instruccionBl = '" + bean.getInstruccionBl() + "', "	
					+ "estatusDocumento = '" + bean.getStatusDoc() + "', "	
					+ "estatus = '" + bean.getStatus() + "' ,"	
					+ "tAnalist = '" + bean.getTrafficAnalist() + "' ,"	
					+ "aa = '" + bean.getCustomAgent() + "' ,"	
					+ "comment = '" + bean.getComment() + "' "	
					+ "where booking = '" + bean.getBooking() + "' and folio = " + bean.getFolio() + " ";	
			con = ConexionDB.dameConexion();	
			pst = con.prepareStatement(update);	
			ra = pst.executeUpdate();	
				
			if (ra == 0) {	
				throw new SQLException("No se actualizo registro de control de embarque...");	
			}	
			ConexionDB.devuelveConexion(con);	
		} catch (SQLException e) {	
			try {	
				ConexionDB.renuevaConexion(con);	
			} catch (Exception ex) {	
				log.error(ex.getMessage(), ex);	
			}	
			log.error(e.getMessage(), e);	
		} catch (Exception e) {	
			e.printStackTrace();	
			try {	
				ConexionDB.devuelveConexion(con);	
			} catch (Exception ex) {	
				log.error(ex.getMessage(), ex);	
			}	
			log.error(e.getMessage(), e);	
		} finally {	
			try {	
				ConexionDB.devuelveConexion(con);	
			} catch (Exception sqlEx2) {	
				log.error(sqlEx2.getMessage(), sqlEx2);	
			}	
		}	
		return ra;	
	}	
	
	
	
	public static Integer existControlEmb(Integer sar, String booking) throws ClassNotFoundException, ServletException 	
	{	
		Connection con = null;	
		Integer folio = null;	
			
		try 	
		{	
			con = ConexionDB.dameConexion();	
			ResultSet rs = null;	
			PreparedStatement pst = null;	
			pst = con.prepareStatement("select folio from cdiControlEmbarque where booking =  ? and folio = ? ");	
			pst.setString(1, booking);	
			pst.setInt(2, sar);	
			rs = pst.executeQuery();	
			while (rs.next()) {	
				folio = rs.getInt(1);	
			}	
				
			rs.close();	
			pst.close();	
		} 	
		catch (Exception exception) 	
		{	
			log.error(exception.getMessage(), exception);	
		} 	
		finally 	
		{	
			ConexionDB.devolver(con);	
		}	
		return folio;	
	}	
			
	public static TraficoConsolVO validaConsolidadosAceptados(String proveedor, String booking)	
			throws ClassNotFoundException {	
		TraficoConsolVO traficoConsol = new TraficoConsolVO();	
		Connection con = null;	
		ConsolidacionFolioDto sarVO = new ConsolidacionFolioDto();	
		try {	
			con = ConexionDB.dameConexion();	
			ResultSet rs = null;	
			PreparedStatement pst = null;	
			pst = con.prepareStatement(ALL_CONSOLIDATED_COMPLETE.toString());	
			pst.setString(1, proveedor);	
			pst.setString(2, booking);	
			rs = pst.executeQuery();	
			List<String> foliosFaltantes = new ArrayList<String>();	
			while (rs.next()) {	
					sarVO.setContenedor(rs.getString("contenedor"));	
					sarVO.setFechaEta(rs.getString("eta"));	
					sarVO.setNaviera(rs.getInt("naviera"));	
					sarVO.setPuerto(rs.getString("puertoSalida"));	
					sarVO.setBooking(rs.getString("booking"));	
					sarVO.setProveedorBean(FuncionesComunesPLI.getProveedor(rs.getString("proveedor")));	
					sarVO.setBlNumber(rs.getString("bl"));	
					sarVO.setPrioridad(rs.getInt("prioridad"));	
					sarVO.setDispatchMode(rs.getInt("transporte"));	
					sarVO.setFolioConsolidado(rs.getInt("folioConsolidado"));	
					sarVO.setResult(rs.getString("result"));	
					sarVO.setBlNumber(rs.getString("bl"));	
					sarVO.setFolio(rs.getString("folio"));	
					try {	
					sarVO.setAgenteAduanal(Integer.parseInt(rs.getString("aa")));	
					}catch(Exception e) {	
						sarVO.setAgenteAduanal(0);	
					}	
					sarVO.setAnalistaTrafico(rs.getString("tAnalist"));	
			}	
			traficoConsol.setConsolidado(sarVO);	
			rs.close();	
			pst.close();	
		} catch (	
		SQLException sqlE) {	
			try {	
				log.error(sqlE.getMessage(), sqlE);	
				ConexionDB.renuevaConexion(con);	
			} catch (Exception sqlEx2) {	
				log.error(sqlEx2.getMessage(), sqlEx2);	
			}	
		}finally {	
			try {	
				ConexionDB.devuelveConexion(con);	
			} catch (Exception sqlEx2) {	
				log.error(sqlEx2.getMessage(), sqlEx2);	
			}	
		}	
		return traficoConsol;	
	}	
	

	
	public static Boolean validaFolioTrafico(int[] folios)	
			throws ClassNotFoundException {	
		Connection con = null;	
		Boolean resultado= false;	
		try {	
			con = ConexionDB.dameConexion();	
			ResultSet rs = null;	
			PreparedStatement pst = null;	
			String arrayToString = Arrays.toString(folios);	
			String query = VALIDATE_DOCUMENTS_CONSOLIDADOS.toString();	
			query = query.replaceAll(Pattern.quote("$$FOLIOS$$"), arrayToString.replace("[","").replace("]", ""));	
			pst = con.prepareStatement(query);	
			rs = pst.executeQuery();	
			while (rs.next()) {	
				resultado =  rs.getBoolean("result"); 	
			}	
			rs.close();	
			pst.close();	
		} catch (	
		SQLException sqlE) {	
			try {	
				log.error(sqlE.getMessage(), sqlE);	
				ConexionDB.renuevaConexion(con);	
			} catch (Exception sqlEx2) {	
				log.error(sqlEx2.getMessage(), sqlEx2);	
			}	
		}finally {	
			try {	
				ConexionDB.devuelveConexion(con);	
			} catch (Exception sqlEx2) {	
				log.error(sqlEx2.getMessage(), sqlEx2);	
			}	
		}	
		return resultado;	
	}	
	
	
	public static List<ConsolidacionFolioDetalleDTO> getFoliosConsolidados(int folios)	
			throws ClassNotFoundException {	
		Connection con = null;	
		List<ConsolidacionFolioDetalleDTO> foliosDetalle = new ArrayList<ConsolidacionFolioDetalleDTO>();	
		try {	
			con = ConexionDB.dameConexion();	
			ResultSet rs = null;	
			PreparedStatement pst = null;	
			String query = GET_CONSOLIDADOS.toString();	
			query = query.replaceAll(Pattern.quote("$$FOLIOS$$"), ""+folios);	
			pst = con.prepareStatement(query);	
			rs = pst.executeQuery();	
			while (rs.next()) {	
				ConsolidacionFolioDetalleDTO detalle = new ConsolidacionFolioDetalleDTO();	
				detalle.setBooking(rs.getString("booking"));	
				detalle.setProveedor(rs.getString("proveedor"));	
				detalle.setSar(rs.getInt("folio"));	
				detalle.setIdOrigenDocumento(rs.getInt("id"));	
				foliosDetalle.add(detalle);	
			}	
			rs.close();	
			pst.close();	
		} catch ( SQLException sqlE) {	
			try {	
				log.error(sqlE.getMessage(), sqlE);	
				ConexionDB.renuevaConexion(con);	
			} catch (Exception sqlEx2) {	
				log.error(sqlEx2.getMessage(), sqlEx2);	
			}	
		}finally {	
			try {	
				ConexionDB.devuelveConexion(con);	
			} catch (Exception sqlEx2) {	
				log.error(sqlEx2.getMessage(), sqlEx2);	
			}	
		}	
		return foliosDetalle;	
	}	
	
	public void revocacionControlSDI(String booking) {	
		Connection conn = null;	
		try {	
				
			conn = ConexionDB.dameConexion();	
			PreparedStatement stmt = conn.prepareStatement(QueriresFacturacionSQL.SQL_REVOCACION_CONTROL_SDI);	
			stmt.setString(1, booking);	
			stmt.executeUpdate();	
			stmt.close();				
		} catch (ClassNotFoundException e) {	
			log.info(e.getMessage(),e);	
			e.printStackTrace();	
		} catch (SQLException e) {	
			e.printStackTrace();	
		} finally {	
			try {	
				if (conn != null)	
					ConexionDB.devuelveConexion(conn);	
			} catch (SQLException e) {	
				log.info(e.getMessage(),e);	
				e.printStackTrace();	
			}	
		}	
	}	
		
		
	public void revocacionFacturacion(Integer idFacturacion) {	
		Connection conn = null;	
		try {	
				
			conn = ConexionDB.dameConexion();	
			PreparedStatement stmt = conn.prepareStatement(QueriresFacturacionSQL.SQL_REVOCACION_FACTURACION);	
			stmt.setInt(1, idFacturacion);	
			stmt.executeUpdate();	
			stmt.close();	
		} catch (ClassNotFoundException e) {	
			log.info(e.getMessage(),e);	
			e.printStackTrace();	
		} catch (SQLException e) {	
			e.printStackTrace();	
		} finally {	
			try {	
				if (conn != null)	
					ConexionDB.devuelveConexion(conn);	
			} catch (SQLException e) {	
				log.info(e.getMessage(),e);	
				e.printStackTrace();	
			}	
		}	
	}	
	
	public static void updaterReferenciaContenedorProveedor(Integer folioSar, String referenciaContenedorProveedor)
			throws SQLException, ClassNotFoundException {
		String s = "update cdiSar set referenciaContenedorProveedor = ? where folio = ? ";
		Connection c = null;
		try {
			c = ConexionDB.dameConexion();
			PreparedStatement ps = c.prepareStatement(s);
			ps.setString(1, referenciaContenedorProveedor);
			ps.setInt(2, folioSar.intValue());
			ps.execute();
			ConexionDB.devuelveConexion(c);
		} catch (SQLException sqlE) {
			try {
				c.rollback();
				log.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(c);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
			throw sqlE;
		} finally {
			try {
				ConexionDB.devuelveConexion(c);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
	}
	
	public static String findReferenciaContenedorProveedor(Integer folio) {
		String query = "SELECT referenciaContenedorProveedor FROM cdiSar WHERE folio = ? ";
		Connection con = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		String result = "";
		try {
			con = ConexionDB.dameConexion();
			preparedStatement = con.prepareStatement(query);
			preparedStatement.setInt(1, folio);
			resultSet = preparedStatement.executeQuery();
			if (resultSet.next())
				result = resultSet.getString("referenciaContenedorProveedor");
			con.close();
		} catch (Exception e) {
			log.error("Query: {}, Exception: {}", query, e);
		} finally {
			ConexionDB.devolver(con);
		}
		return result;
	}

	public static List<Integer> obtieneFoliosPendientesContenedor(Integer seven, Integer five, Integer threOrLess, Integer today) {
		Connection con = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		StringBuilder select = ConsultasConstants.FOLIOS_PENDIENTES_CONTENEDOR;
		List<Integer> foliosAConsultar = new ArrayList<Integer>();
		try {
			con = ConexionDB.dameConexion();
			pst = con.prepareStatement(select.toString());
			pst.setInt(1, seven);
			pst.setInt(2, five);
			pst.setInt(3, threOrLess);
			pst.setInt(4, today);
			pst.setInt(5, seven);
			pst.setInt(6, five);
			pst.setInt(7, threOrLess);
			pst.setInt(8, today);
			rs = pst.executeQuery();

			while (rs.next()) {
				foliosAConsultar.add(rs.getInt("folio"));
			}
			rs.close();
			pst.close();
		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} catch (Exception e) {
			e.printStackTrace();
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
		return foliosAConsultar;
	}
	
	
	public static Integer actualizarSAR(GrdLineamientosAccionesDto dto) {
		Connection conn = null;
		try {
			conn = ConexionDB.dameConexion();
			System.out.println("vamos actualizar estatus");
			int resultado = 0;
			StringBuilder query = new StringBuilder();
			String comentarioCancelaciacion = "";
			String comentarioAprobacion = "";
			if (dto.getAccion().equals("aprobacionGDRGerente")) {
				comentarioCancelaciacion = "";
				comentarioAprobacion = dto.getComentarios();
			} else if (dto.getAccion().equals("rechazoGDRGerente")) {
				comentarioCancelaciacion = dto.getComentarios();
				comentarioAprobacion = "";
			}
			log.info("Actualizacion de estatus  actualizarSAR {} , {}  ",dto.getFolio() + "->"+ dto.getIdEstatus(),dto.getStatusAnterior());
			query.append(" UPDATE cdiSAR SET ");
			query.append("	messageGRDrechazo=? , messageGRDaprobacion=?, status=?, approvalGRDlineacion=? , statusAnteriorGRD = ?");
			query.append(" WHERE folio=? ");

			PreparedStatement stmt = conn.prepareStatement(query.toString());
			stmt.setString(1, comentarioCancelaciacion);
			stmt.setString(2, comentarioAprobacion);
			stmt.setInt(3, dto.getIdEstatus());
			stmt.setInt(4, dto.getApprovalGRDlineacion());
			stmt.setInt(5, dto.getStatusAnterior());
			stmt.setInt(6, dto.getFolio());

			resultado = stmt.executeUpdate();

			if (resultado > 0) {
				log.info("Actualizacion correcta");
				System.out.println("actualizo bien");
			}

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();

		} finally {
			ConexionDB.devolver(conn);
		}
		return dto.getFolio();

	}
	
	public static void updateSARStatusGDR_AND_LINEAMIENTOS(int folio, int gdrEnRevision, int gdrAprobado, boolean changeStatus) throws SQLException, ClassNotFoundException {
		Connection con = null;
		int resultado = 0;
		DAOUtils utils = new DAOUtils();
		try {
			con = ConexionDB.dameConexion();

			PreparedStatement pst = null;
			StringBuilder query = ConsultasConstants.UPDATE_SAR_STATUS_GDR;
			if(changeStatus)
				query = ConsultasConstants.UPDATE_SAR_STATUS_GDR_AND_BO;
			pst = con.prepareStatement(query.toString());

			utils.inicializaQuery(query.toString());
			int cont = 1;
			if(gdrEnRevision == 1)
			    utils.ajustaParametro(cont++, pst, Boolean.TRUE, Boolean.class);
			else
			    utils.ajustaParametro(cont++, pst, Boolean.FALSE, Boolean.class);
			if(gdrAprobado == 1)
			    utils.ajustaParametro(cont++, pst, Boolean.TRUE, Boolean.class);
			else
			    utils.ajustaParametro(cont++, pst, Boolean.FALSE, Boolean.class);
			utils.ajustaParametro(cont++, pst, folio, Integer.class);
			resultado = pst.executeUpdate();

			pst.close();

			ConexionDB.devuelveConexion(con);

			if (resultado == 0) {
				throw new SQLException("No se actualizo registro...");
			}

		} catch (SQLException sqlE) {
			try {
				log.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
			throw sqlE;
		} catch (IOException ioE) {
			try {
				log.error(ioE.getMessage(), ioE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception ioE2) {
				log.error(ioE2.getMessage(), ioE2);
			}
		}
	}
	
	public static void aprobacionGDRBOLINEAMIENTO(int folio,boolean changeStatus) throws SQLException, ClassNotFoundException {
		Connection con = null;
		int resultado = 0;
		DAOUtils utils = new DAOUtils();
		try {
			con = ConexionDB.dameConexion();
			RevisionGDR revision = new RevisionGDR();
			revision.setFolio(folio);
			revision.setActivo(true);
			if(changeStatus){
				revision.setActivo(false);
			}
			RevisionGDRDAO gdrDao = new RevisionGDRDAO();
			List<RevisionGDR> revisiones = (List<RevisionGDR>) gdrDao.select(revision);
			RevisionGDR sar = revisiones != null ? revisiones.get(0) : null;

			Date gdrModificado = sar.getFechaGDRModificada() != null ?
				DateUtils.getInstance().parseIntToDate(sar.getFechaGDRModificada(), "yyyyMMdd"): null;

			PreparedStatement pst = null;
			StringBuilder query = ConsultasConstants.APROBACION_GDR;
			if(changeStatus){
				query = ConsultasConstants.APROBACION_GDR_BO_LINEAMIENTO;
			}
			int cont = 1;
			pst = con.prepareStatement(query.toString());
			utils.inicializaQuery(query.toString());

			if(sar.getFechaETDModificada() != null)
			    utils.ajustaParametro(cont++, pst, sar.getFechaETDModificada(), Integer.class);
			if(gdrModificado != null)
			    utils.ajustaParametro(cont++, pst, gdrModificado, Date.class);
			utils.ajustaParametro(cont++, pst, folio, Integer.class);
			resultado = pst.executeUpdate();

			pst.close();

			ConexionDB.devuelveConexion(con);

			if (resultado == 0) {
				throw new SQLException("No se actualizo registro...");
			}

		} catch (SQLException sqlE) {
			try {
				log.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
			throw sqlE;
		} catch (IOException ioE) {
			try {
				log.error(ioE.getMessage(), ioE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception ioE2) {
				log.error(ioE2.getMessage(), ioE2);
			}
		}
	}
	/**
	 * 
	 * @param profiles lista se perfiles a consultar separados por comas
	 * @return
	 * @throws ServletException
	 */
	public static List<UserBean> dameUsuariosByProfiles(int[] profiles) throws ServletException {
		List<UserBean> lstUsers = new ArrayList<UserBean>();
		Connection con = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		DAOUtils utils = new DAOUtils();

		StringBuilder select = new StringBuilder();
		select.append("SELECT id, userName, pwd, lastPwdChangeDate, changePwd,");
		select.append(" realName, userEmail, userProfile, active, userType,");
		select.append(" creationDate, creationUser");
		select.append(" FROM cdiUsers WHERE userProfile IN ( ");
		for( int i =0 ; i < profiles.length;i++ ) {
			if( i+1 == profiles.length ) {
				select.append("?);");
			}else {
				select.append("?,");
			}
		}
		
		utils.setSelect(true);

		try {
			con = ConexionDB.dameConexion();
			pst = con.prepareStatement(select.toString());
			
			utils.inicializaQuery(select.toString());
			int x = 1;
			for( int prof : profiles ) {
				pst.setInt(x++, prof);
			}
			rs = pst.executeQuery();

			while (rs.next()) {
				UserBean userBean = new UserBean();
				userBean.setIdUser(rs.getInt("id"));
				userBean.setUserName(rs.getString("userName"));
				userBean.setPwd(rs.getString("pwd"));
				userBean.setLastPwdChangeDate(rs.getInt("lastPwdChangeDate"));
				userBean.setCambiarPwd(rs.getBoolean("changePwd"));
				userBean.setRealName(rs.getString("realName"));
				userBean.setUserEmail(rs.getString("userEmail"));
				userBean.setUserProfile(rs.getInt("userProfile"));
				userBean.setActive(rs.getBoolean("active"));
				userBean.setUserType(rs.getInt("userType"));
				userBean.setCreationDate(rs.getLong("creationDate"));
				userBean.setCreationUser(rs.getString("creationUser"));
				lstUsers.add(userBean);
			}
			rs.close();
			pst.close();
		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
				throw new ServletException(ex);
			}
			log.error(e.getMessage(), e);
			throw new ServletException(e);
		} catch (Exception e) {
			e.printStackTrace();
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
				throw new ServletException(ex);
			}
			log.error(e.getMessage(), e);
			throw new ServletException(e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
				throw new ServletException(sqlEx2);
			}
		}
		return lstUsers;
	}
		
	public static Integer actualizaComentarioItemsDirectos(String comentario, Integer folio) {
		
		Connection con = null;
		int response = 0; 
		String update = "UPDATE cdiSAR SET commentDeleteProjection = ? WHERE folio = ? ";

		try {

			con = ConexionDB.dameConexion();

			try (PreparedStatement pst = con.prepareStatement(update)) {

				pst.setString(1, comentario);
				pst.setInt(2, folio);
				
				response = pst.executeUpdate();

			}

		} catch (Exception e) {
			ConexionDB.renovar(con);
			log.error("Ocurrio un error al intentar actuaizar el comentario de folio: {} {} ", e, e.getMessage());
		} finally {
			ConexionDB.devolver(con);
		}
		
		return response;
	}
	
public static Integer borrarComentarioItemsDirectos(Integer folio) {
		
		Connection con = null;
		int response = 0; 
		String update = "UPDATE cdiSAR SET commentDeleteProjection = null WHERE folio = ? ";

		try {

			con = ConexionDB.dameConexion();

			try (PreparedStatement pst = con.prepareStatement(update)) {

				pst.setInt(1, folio);
				response = pst.executeUpdate();

			}

		} catch (Exception e) {
			ConexionDB.renovar(con);
			log.error("Ocurrio un error al intentar borrar el comentario de folio: {} {} ", e, e.getMessage());
		} finally {
			ConexionDB.devolver(con);
		}
		
		return response;
	}

	public static List<CdiCatManagers> selectManagers () throws Exception {	
		
		List<CdiCatManagers> lstManagers = new ArrayList<CdiCatManagers>();
		Connection con = null;	
			
		try {	
			con = ConexionDB.dameConexion();	
			ResultSet rs = null;	
			PreparedStatement pst = null;	
			pst = con.prepareStatement(SELECT_MANAGERS.toString());	
			rs = pst.executeQuery();	
			
			while (rs.next()) {	
				
				CdiCatManagers manager = new CdiCatManagers();
				manager.setIdManager(rs.getString("id"));
				manager.setUserName(rs.getString("userName"));
				lstManagers.add(manager);
				
			}	
				
			rs.close();	
			pst.close();	
			
		} catch (Exception exception) {	
			ConexionDB.devuelveConexion(con);
			log.error(exception.getMessage(), exception);	
		} finally {	
			ConexionDB.devuelveConexion(con);
		}	
		
		return lstManagers;	
	}
	
	public static List<CdiManagersPlanners> selectPlannersbyManager (String idManager) throws Exception {	
		
		List<CdiManagersPlanners> lstPlanners = new ArrayList<CdiManagersPlanners>();
		Connection con = null;	
			
		try {	
			con = ConexionDB.dameConexion();	
			ResultSet rs = null;	
			PreparedStatement pst = null;	
			pst = con.prepareStatement(SELECT_PLANNERS_BY_MANAGER.toString());	
			pst.setString(1, idManager);
			rs = pst.executeQuery();	
			
			while (rs.next()) {	
				
				CdiManagersPlanners planner = new CdiManagersPlanners();
				planner.setIdPlanner(rs.getString("idPlanner"));
				lstPlanners.add(planner);
				
			}	
				
			rs.close();	
			pst.close();	
			
		} catch (Exception exception) {	
			ConexionDB.devuelveConexion(con);
			log.error(exception.getMessage(), exception);	
		} finally {	
			ConexionDB.devuelveConexion(con);
		}	
		
		return lstPlanners;	
	}	

	
	public static BeanSendDocumentsTEL selectSarToSendDocumentsTEL (Integer folio) throws Exception {	
		
		BeanSendDocumentsTEL beanSendDocumentsTEL = new BeanSendDocumentsTEL();
		Connection con = null;	
			
		try {	
			con = ConexionDB.dameConexion();	
			ResultSet rs = null;	
			PreparedStatement pst = null;	
			pst = con.prepareStatement(SELECT_SAR_SEND_DOCUMENTS_TEL.toString());	
			pst.setInt(1, folio);
			rs = pst.executeQuery();	
			
			while (rs.next()) {	
				beanSendDocumentsTEL.setFolio(rs.getInt("folio"));
				beanSendDocumentsTEL.setAprobado(rs.getBoolean("aprobado"));
				beanSendDocumentsTEL.setContenedor(rs.getString("contenedor"));
				beanSendDocumentsTEL.setBooking(rs.getString("booking"));
				beanSendDocumentsTEL.setNumeroFactura(rs.getString("numeroFactura"));
			}	
				
			rs.close();	
			pst.close();	
			
		} catch (Exception exception) {	
			ConexionDB.devuelveConexion(con);
			log.error(exception.getMessage(), exception);	
		} finally {	
			ConexionDB.devuelveConexion(con);
		}	
		
		return beanSendDocumentsTEL;	
	}	

	

	public List<BeanFactura> selectFacturaXIdOtherVersion(int id,String condicion) throws ClassNotFoundException {
		BeanFactura factu = null;	
		Connection con = null;	
		List<BeanFactura> lista = new ArrayList<BeanFactura>();	
		try {	
			con = ConexionDB.dameConexion();	
			ResultSet rs = null;	
			PreparedStatement pst = null;	 	
			pst = con.prepareStatement(SELECT_FACTURA_BY_ID_AND_CONDITION.toString());	
			int cont = 1;	
			pst.setInt(cont++, id);	
			pst.setString(cont++, condicion);	
			rs = pst.executeQuery();	
			while (rs.next()) {	
				factu = new BeanFactura();	
				factu.setCondicionDePago(rs.getString("condicionPago"));	
				factu.setFechaCreacion(rs.getDate("fechaCreacion"));	
				factu.setId(rs.getInt("id"));	
				factu.setNombre(rs.getString("nombre"));	
				factu.setPaisOrigen(rs.getString("paisorigen"));	
				factu.setRutaArchivo(rs.getString("rutaArchivo"));	
				factu.setTieneMadera(rs.getBoolean("madera"));	
				factu.setTieneOtros(rs.getBoolean("tieneOtros"));	
				factu.setVersionDocumento(rs.getInt("versionDocumento"));	
				lista.add(factu);	
			}	
			rs.close();	
			pst.close();	
			ConexionDB.devuelveConexion(con);	
		} catch (SQLException sqlE) {	
			try {	
				log.error(sqlE.getMessage(), sqlE);	
				ConexionDB.renuevaConexion(con);	
			} catch (Exception sqlEx2) {	
				log.error(sqlEx2.getMessage(), sqlEx2);	
			}	
		}	
		return lista;
	}
}