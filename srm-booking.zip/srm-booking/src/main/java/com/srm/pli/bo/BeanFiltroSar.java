package com.srm.pli.bo;

public class BeanFiltroSar {

	private Integer folio;
	private String proveedor;
	private Integer fechaInicial;
	private Integer fechaFinal;

	public Integer getFolio() {
		return folio;
	}

	public void setFolio(Integer folio) {
		this.folio = folio;
	}

	public String getProveedor() {
		return proveedor;
	}

	public void setProveedor(String proveedor) {
		this.proveedor = proveedor;
	}

	public Integer getFechaInicial() {
		return fechaInicial;
	}

	public void setFechaInicial(Integer fechaInicial) {
		this.fechaInicial = fechaInicial;
	}

	public Integer getFechaFinal() {
		return fechaFinal;
	}

	public void setFechaFinal(Integer fechaFinal) {
		this.fechaFinal = fechaFinal;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("BeanFiltroSar [getFolio=");
		builder.append(getFolio());
		builder.append(", getProveedor=");
		builder.append(getProveedor());
		builder.append(", getFechaInicial=");
		builder.append(getFechaInicial());
		builder.append(", getFechaFinal=");
		builder.append(getFechaFinal());
		builder.append("]");
		return builder.toString();
	}
}