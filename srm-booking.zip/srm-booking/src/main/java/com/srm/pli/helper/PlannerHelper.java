package com.srm.pli.helper;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import com.srm.pli.bo.SarBO;
import com.srm.pli.bo.SarDetalleBO;
import com.srm.pli.utils.FuncionesComunesPLI;
import com.truper.businessEntity.ProductoBean;
import com.truper.businessEntity.UserBean;
import com.truper.utils.string.UtilsString;

public class PlannerHelper {

	private static final PlannerHelper instance = new PlannerHelper();

	private PlannerHelper() {
	}

	public static PlannerHelper getInstance() {
		return instance;
	}

	public String buildFiltro(String celula, String tipoFolio, String planeador, Integer folio, String po,
			String supplier) {
		StringBuilder filtro = new StringBuilder();
		filtro.append("UN:").append(celula);
		filtro.append("|tipo:").append(tipoFolio);
		filtro.append("|planner:").append(planeador);
		filtro.append("|folio:").append(folio);
		filtro.append("|po:").append(po);
		filtro.append("|supplier:").append(supplier);
		return filtro.toString();
	}

	/**
	 * Filtro por unidad de Negocio
	 * 
	 * @param lista
	 * @param unidadNegocio
	 * @return
	 * @throws Exception
	 */
	public List<SarBO> filtraUnidadNegocio(List<SarBO> lista, String unidadNegocio) throws Exception {
		if (lista == null || lista.isEmpty() || unidadNegocio == null || "0".equals(unidadNegocio)
				|| "".equals(unidadNegocio))
			return lista;

		List<SarBO> nuevaLista = new ArrayList<SarBO>();
		HashSet<Integer> foliosEnMapa = new HashSet<Integer>();
		for (SarBO tmpSAR : lista) {
			List<SarDetalleBO> detalle = FuncionesComunesPLI.getDetalleSAR(tmpSAR);
			for (SarDetalleBO det : detalle) {
				ProductoBean prod = FuncionesComunesPLI.productos.get(det.getMaterial() + "");
				if (prod != null && prod.getProductoCentro() != null
						&& prod.getProductoCentro().containsKey(det.getCentro())
						&& prod.getProductoCentro().get(det.getCentro()).getCellCode().equals(unidadNegocio)) {
					if (!foliosEnMapa.contains(tmpSAR.getFolio())) {
						foliosEnMapa.add(tmpSAR.getFolio());
						nuevaLista.add(tmpSAR);
					}

				}
			}
		}
		return nuevaLista;
	}

	/**
	 * Filtro por comercializados o fabricados
	 * 
	 * @param lista
	 * @param tipoProducto
	 * @return
	 * @throws Exception
	 */
	public List<SarBO> filtraTipoProducto(List<SarBO> lista, String tipoProducto) throws Exception {
		if (lista == null || lista.isEmpty() || tipoProducto == null
				|| !("C".equals(tipoProducto) || "F".equals(tipoProducto)))
			return lista;

		List<SarBO> nuevaLista = new ArrayList<SarBO>();
		boolean debeEntrar = false;
		for (SarBO tmpSAR : lista) {
			SarDetalleBO tmpSarDet = new SarDetalleBO();
			tmpSarDet.setFolio(tmpSAR.getFolio());
			List<SarDetalleBO> detalle = FuncionesComunesPLI.getDetalleSAR(tmpSAR);
			debeEntrar = false;
			for (SarDetalleBO det : detalle) {
				ProductoBean prod = FuncionesComunesPLI.productos.get(det.getMaterial() + "");
				if (prod != null && (("C".equals(tipoProducto) && prod.isComercializado())
						|| ("F".equals(tipoProducto) && !prod.isComercializado()))) {
					debeEntrar = true;
					break;
				} else {
					debeEntrar = false;
				}
			}
			if (debeEntrar) {
				nuevaLista.add(tmpSAR);
			}
		}
		return nuevaLista;
	}

	/**
	 * Filtro por planeador
	 * 
	 * @param lista
	 * @param planeador
	 * @return
	 * @throws Exception
	 */
	public List<SarBO> filtraPlaneador(List<SarBO> lista, String planeador) throws Exception {
		if (lista == null || lista.isEmpty() || planeador == null || "ALL".equals(planeador))
			return lista;

		List<SarBO> nuevaLista = new ArrayList<SarBO>();
		for (SarBO tmpSAR : lista) {
			List<SarDetalleBO> detalles = FuncionesComunesPLI.getDetalleSAR(tmpSAR);
			if (detalles != null && detalles.size() > 0) {
				for (SarDetalleBO det : detalles) {
					if (planeador.contains(det.getPlaneador())) {
						nuevaLista.add(tmpSAR);
						break;
					}
				}
			}
		}
		return nuevaLista;
	}

	/**
	 * Filtro por PO
	 * 
	 * @param lista
	 * @param po
	 * @return
	 * @throws Exception
	 */
	public List<SarBO> filtraPO(List<SarBO> lista, String po) throws Exception {
		if (lista == null || lista.isEmpty() || !UtilsString.isStringValida(po))
			return lista;

		po = po.trim();
		List<SarBO> nuevaLista = new ArrayList<SarBO>();
		for (SarBO tmpSAR : lista) {
			SarDetalleBO tmpSarDet = new SarDetalleBO();
			tmpSarDet.setFolio(tmpSAR.getFolio());
			ArrayList<SarDetalleBO> listaDet = (ArrayList<SarDetalleBO>) FuncionesComunesPLI.getDetalleSAR(tmpSAR);
			for (SarDetalleBO det : listaDet) {
				if (det.getPo().trim().equals(po)) {
					nuevaLista.add(tmpSAR);
					break;
				}
			}
		}
		return nuevaLista;
	}

	public List<SarBO> filtraProveedor(List<SarBO> lista, String proveedor) {
		if (lista == null || lista.isEmpty() || !UtilsString.isStringValida(proveedor))
			return lista;

		proveedor = proveedor.trim();
		if (proveedor.length() > 5) {
			proveedor = proveedor.substring(0, 6);
		}
		List<SarBO> nuevaLista = new ArrayList<SarBO>();
		for (SarBO tmpSAR : lista) {
			if (tmpSAR == null)
				continue;
			String tmp_proveedor = tmpSAR.getProveedor();
			if (!UtilsString.isStringValida(tmp_proveedor))
				continue;
			tmp_proveedor = tmp_proveedor.trim();
			if (proveedor.equalsIgnoreCase(tmp_proveedor))
				nuevaLista.add(tmpSAR);
		}
		return nuevaLista;
	}
	
	/**
	 * Regresa una lista con el filtro de SARs que puede ver el usuario.
	 * Hay 3 tipos de filtro.
	 * Si el usuario puede ver Directos 
	 * Si el usuario puede ver Sars normales
	 * Si el usuario puede ver los 2 tipos de SAR, es decir sin filtro
	 * 
	 * @param lista
	 * @param user
	 * @return
	 * @throws Exception
	 */
	public List<SarBO> filtraPorTipoSAR(List<SarBO> lista, UserBean usuario) throws Exception {
		
		if(!UsuarioHelper.getInstance().veSarsDirectosYNormales(usuario) ) {
			List<SarBO> nuevaLista = new ArrayList<SarBO>();
			if(UsuarioHelper.getInstance().veSoloSARsDirectos(usuario)) {
				for (SarBO tmpSAR : lista) {
					if(FormatSARHelper.getInstance().tienePedioDirecto( tmpSAR)) {
						nuevaLista.add(tmpSAR);
					}
				}
			}else {
				for (SarBO tmpSAR : lista) {
					if(!FormatSARHelper.getInstance().tienePedioDirecto( tmpSAR)) {
						nuevaLista.add(tmpSAR);
					}
				}
			}
			return  nuevaLista;//Si hubo un cambio al filtrar regreso nueva lista
		}
		return lista;//Si debe ver todo, regreso la lista original
	}
	
}
