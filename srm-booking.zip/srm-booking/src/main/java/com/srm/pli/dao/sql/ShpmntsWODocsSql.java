package com.srm.pli.dao.sql;

public class ShpmntsWODocsSql {

	public static final String SELECT_PUERTOS_DESCARGA_HOY;
	public static final String SELECT_SARS_CONFIRMACION_FINAL_SIN_DOCUMENTOS;

	static {
		StringBuilder sql = new StringBuilder();
		sql.append("SELECT DISTINCT s.puertodescarga ");
		sql.append("                , s.esaereo ");
		sql.append("                , ( CASE ");
		sql.append("                      WHEN sd.espedidodirecto = 1 THEN 1 ");
		sql.append("                      ELSE Isnull(sdr.espedidodirecto, 0) ");
		sql.append("                    END ) AS esPedidoDirecto ");
		sql.append(" FROM   cdiSAR s ");
		sql.append("       LEFT JOIN cdiSarDetalle sd ");
		sql.append("              ON s.folio = sd.folio AND sd.esPedidoDirecto = 1 ");
		sql.append("       LEFT JOIN cdiSarDetalleRechazados sdr ");
		sql.append("              ON s.folio = sdr.folio AND sdr.esPedidoDirecto = 1 ");
		sql.append("       LEFT JOIN cdiDocumentosSDI docs ");
		sql.append("              ON s.versionsetdocumentos = docs.versionsdi ");
		sql.append("                 AND s.booking = docs.booking ");
		sql.append("                 AND s.proveedor = docs.proveedor ");
		sql.append(" WHERE  s.aprobadoproveedor = 1 ");
		sql.append("       AND ( s.versionsetdocumentos IS NULL ");
		sql.append("              OR ( docs.fechaaceptaproveedor IS NULL ");
		sql.append("                   AND docs.fecharechazo IS NOT NULL ) ");
		sql.append("              OR ( docs.fechaaceptaproveedor IS NULL ");
		sql.append("                   AND docs.fecharechazo IS NULL ) ) ");
		sql.append("       AND s.etdfinal <= Cast(CONVERT(VARCHAR(8), Getdate(), 112) AS INT)");
		SELECT_PUERTOS_DESCARGA_HOY = sql.toString();
		
		sql = new StringBuilder();
		sql.append("SELECT DISTINCT ");
		sql.append("		s.folio ");
		sql.append("		, (CASE ");
		sql.append("			WHEN s.etdfinal IS NOT NULL AND s.etdfinal > 20000101 ");
		sql.append("			THEN s.etdfinal ");
		sql.append("			ELSE s.fechaembarque ");
		sql.append("		END) AS etd ");
		sql.append("       , s.eta ");
		sql.append("	   , s.proveedor ");
		sql.append("	   , s.booking ");
		sql.append("	   , CONVERT ( VARCHAR( 8 ), s.fechaConfirmacionFinal, 112 ) as fechaConfirmacionFinal ");
		sql.append("	   , DATEDIFF(DAY, CONVERT(smalldatetime,CAST(s.fechaConfirmacionFinal AS varchar)), GETDATE()) diasDesdeConfirmacionFinal ");
		sql.append("	   , s.puertoDescarga ");
		sql.append("	   , s.esaereo ");
		sql.append("	   , (CASE ");
		sql.append("		  WHEN sd.esPedidoDirecto = 1 ");
		sql.append(" 			THEN 1 ");
		sql.append(" 			ELSE ISNULL(sdr.esPedidoDirecto, 0) ");
		sql.append("		 END) AS esPedidoDirecto ");
		sql.append(" FROM cdisar s ");
		sql.append("        INNER JOIN cdiProveedorModulo pm ON s.proveedor = pm.supplier AND s.fechaConfirmacionFinal >= pm.createDate ");
		sql.append("        LEFT JOIN cdiSarDetalle sd ON s.folio = sd.folio AND sd.esPedidoDirecto = 1 ");
		sql.append("        LEFT JOIN cdiSarDetalleRechazados sdr ON s.folio = sdr.folio AND sdr.esPedidoDirecto = 1 ");
		sql.append("		LEFT JOIN cdidocumentossdi d ON s.proveedor = d.proveedor ");
		sql.append("                 AND s.booking = d.booking ");
		sql.append("                 AND s.versionsetdocumentos = d.versionsdi ");
		sql.append(" WHERE ISNULL(LTRIM(RTRIM(s.booking)), '') <> '' ");
		sql.append("	AND d.fechaAceptaProveedor IS NULL ");
		sql.append("	AND d.fechaRechazo IS NULL ");
		sql.append("	AND DATEADD(day,DATEDIFF(day,0,s.fechaConfirmacionFinal),0) ");
		sql.append("			<= DATEADD(day,DATEDIFF(day,0,GETDATE()-1),0) ");
		SELECT_SARS_CONFIRMACION_FINAL_SIN_DOCUMENTOS = sql.toString();
	}

}
