package com.srm.pli.dao;

import static com.srm.pli.dao.sql.CatalogosSQL.SELECT_PROVEEDOR_MODULO;
import static com.srm.pli.dao.sql.CatalogosSQL.SELECT_PROVEEDOR_MODULO_DONDE;
import static com.srm.pli.dao.sql.CatalogosSQL.SELECT_UNIDAD_MEDIDA;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashSet;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.srm.pli.db.ConexionDB;

public class CatalogosDAO {

	private static CatalogosDAO instance = new CatalogosDAO();
	private static final Logger LOGGER = LogManager.getRootLogger();

	private CatalogosDAO() {
	}

	public static CatalogosDAO getInstance() {
		return instance;
	}

	public HashSet<String> selectUnidadesMedida() {
		HashSet<String> resultado = null;
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();
			try (Statement st = con.createStatement()) {
				try (ResultSet rs = st.executeQuery(SELECT_UNIDAD_MEDIDA)) {
					resultado = new HashSet<>();
					while (rs.next()) {
						resultado.add(rs.getString("abreviatura"));
					}
				}
			}
		} catch (SQLException sqle) {
			sqle.printStackTrace();
			LOGGER.error(sqle);
			ConexionDB.renovar(con);
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error(e);
		} finally {
			ConexionDB.devolver(con);
		}
		return resultado;
	}

	public HashSet<String> selectProveedoresModulo() {
		HashSet<String> resultado = null;
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();
			try (Statement st = con.createStatement()) {
				try (ResultSet rs = st.executeQuery(SELECT_PROVEEDOR_MODULO)) {
					resultado = new HashSet<>();
					while (rs.next()) {
						resultado.add(rs.getString("supplier"));
					}
				}
			}
		} catch (SQLException sqle) {
			sqle.printStackTrace();
			LOGGER.error(sqle);
			ConexionDB.renovar(con);
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error(e);
		} finally {
			ConexionDB.devolver(con);
		}
		return resultado;
	}

	public HashSet<String> selectProveedorModulo(String supplier) {
		HashSet<String> resultado = null;
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();
			try (PreparedStatement ps = con.prepareStatement(SELECT_PROVEEDOR_MODULO_DONDE)) {
				ps.setString(1, supplier);
				try (ResultSet rs = ps.executeQuery()) {
					resultado = new HashSet<>();
					while (rs.next()) {
						resultado.add(rs.getString("supplier"));
					}
				}
			}
		} catch (SQLException sqle) {
			sqle.printStackTrace();
			LOGGER.error(sqle);
			ConexionDB.renovar(con);
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error(e);
		} finally {
			ConexionDB.devolver(con);
		}
		return resultado;
	}
}