package com.srm.pli.dao;

import static com.srm.pli.dao.sql.CorreoSql.SELECT_CORREOS_TIPO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashSet;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.srm.pli.db.ConexionDB;
import com.srm.pli.enums.TipoCorreoEnum;
import com.srm.pli.utils.CorreoUtils;

public class CorreoDao {

	private static final CorreoDao instance = new CorreoDao();
	private static final Logger LOGGER = LogManager.getRootLogger();

	public CorreoDao() {
	}

	public static CorreoDao getInstance() {
		return instance;
	}

	public HashSet<String> getCorreos(TipoCorreoEnum tipo) {
		HashSet<String> respuesta = null;
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();
			try (PreparedStatement pst = con.prepareStatement(SELECT_CORREOS_TIPO)) {
				pst.setString(1, tipo.toString());
				try (ResultSet rs = pst.executeQuery()) {
					respuesta = new HashSet<>();
					while (rs.next()) {
						String correo = rs.getString("correo");
						if (correo == null)
							continue;
						correo = correo.trim();
						boolean valido = CorreoUtils.getInstance().isCorreoValido(correo);
						if (valido) {
							respuesta.add(correo);
						}
					}
				}
			}
		} catch (SQLException sqle) {
			sqle.printStackTrace();
			LOGGER.error(sqle);
			ConexionDB.renovar(con);
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error(e);
		} finally {
			ConexionDB.devolver(con);
		}
		return respuesta;
	}

}
