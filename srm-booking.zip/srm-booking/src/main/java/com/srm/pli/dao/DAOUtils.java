package com.srm.pli.dao;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import com.srm.pli.enums.Variables;
import com.srm.pli.utils.FuncionesComunesPLI;



/**
 * Clase de utilidades para consultas a tablas
 * Pensado para utilizarlo con querys dimamicos
 * Utilizo los metodos de Ivan para agregar al Prepared Statement los valores
 * 
 * @author drodriguez
 */
public  class DAOUtils extends DAO{

	/**
	 * 
	 */
	private static final long serialVersionUID = 5208086621453575849L;
	private ArrayList<String> columnas = new ArrayList<String>();
	private int parametroNum = 0;
	private int columnaNum = 0;
	private String query = "";
	private boolean  isSelect = false;
	
	
	public void inicializaQuery(String queryInicial){
        query = queryInicial;
    }
	
	private void reemplazaDatos() throws SQLException{
		try{
//			for(int i = 0; i < columnas.size() ;i++){
//				query.
//				query = query.replaceFirst("\\?", columnas.get(i) );
//				System.out.println("--> "+query);
//			}
			
			StringBuffer nuevoQuery = new StringBuffer();
			///escapo el caracter %
			//query = query.replaceAll("%", "\\%");
			
			String[] partesQuery = query.split("\\?"); 
			for(int i = 0; i < (partesQuery.length-2) ;i++){
				nuevoQuery.append(partesQuery[i]);
				nuevoQuery.append(columnas.get(i));
				
				query = nuevoQuery.toString();
			}
		}catch(Exception e){
			throw new SQLException(e.toString());
		}
		
		//return query;
	}
	
	
	
	//ArrayList<String> parametros = new ArrayList<String>();
	/**
	 * me regresa la cadena con coma o sin coma para un query
	 * @param posicion
	 * @return
	 * @throws SQLException
	 */
	public String ajustaColumna(String columna) throws SQLException {
        String ajustado = "";
    	if(columnaNum == 0 || isSelect){
    		ajustado = columna;
        }else{
        	ajustado = ","+columna;
        }
        columnaNum++;
        return ajustado;
    }
	
    /**
     * Agrega el parametro al PreparedStatement y guardo el logeo para informacion
     * 
     * @param parametro
     * @return
     * @throws SQLException
     */
	public  void ajustaParametro(int posicion, PreparedStatement ps, Object campo, Class tipo) throws SQLException, IOException {
        //String nuevoQuery = "";
        //String tmp = "";
    	////Aqui mando a llamar el metodo de Ivan
    	agregarPs(posicion, ps, campo, tipo);
    	///en esta parte reemplazo el unico ? y lo reemplazo por el valor para ir generando el query
    	
    	if (campo == null || campo.equals(Variables.NULL.getValue()) || campo.equals(Variables.NULL.getDescripcion())) {
    		//query = query.replaceAll("\\?", "null" );
    		columnas.add(null);
        }
        else {
            if (String.class == tipo) {
            	//query = query.replaceFirst("\\?", "'"+campo+"'" );
            	columnas.add("'"+campo+"'");
            }
            else if (Integer.class == tipo) {
            	//query = query.replaceFirst("\\?", ""+campo+"" );
            	columnas.add(""+campo+"");
            }
            else if (Date.class == tipo) {
                //ps.setDate(posicion, new java.sql.Date(((Date) campo).getTime()));
            	//query = query.replaceFirst("\\?", ""+new java.sql.Date(((Date) campo).getTime())+"" );
            	columnas.add(""+new java.sql.Date(((Date) campo).getTime())+"");
            }
            else if (Timestamp.class == tipo) {
                //ps.setTimestamp(posicion, new Timestamp(((Date) campo).getTime()));
            	//query = query.replaceFirst("\\?", ""+new Timestamp(((Date) campo).getTime())+"" );
            	columnas.add(""+new Timestamp(((Date) campo).getTime())+"");
            }
            else if (Float.class == tipo) {
            	//query = query.replaceFirst("\\?", ""+campo+"" );
            	columnas.add(""+campo+"" );
            }
            else if (BigDecimal.class == tipo) {
            	//ps.setBigDecimal(posicion, ((BigDecimal) campo));
            	//query = query.replaceFirst("\\?", ((BigDecimal) campo).toString());
            	columnas.add(((BigDecimal) campo).toString());
            }
            else if (Boolean.class == tipo) {
            	//ps.setBoolean(posicion, ((Boolean) campo));
            	//query = query.replaceFirst("\\?", (((Boolean)campo) ? "1" :"0"  ));
            	columnas.add((((Boolean)campo) ? "1" :"0"  ));
            }
            else if (Long.class == tipo) {
            	//query = query.replaceFirst("\\?", ""+campo+"" );
            	columnas.add(""+campo+"" );
            }
        }
    }
    
    
	public  String dameQueryFinal() throws SQLException{
    	reemplazaDatos();
    	return query;
    }
    
	public Date generaDate(int fecha) {
		Calendar cal = Calendar.getInstance();
		GregorianCalendar greg = FuncionesComunesPLI.int2GregorianCalendar(fecha);
		
		cal.set(Calendar.DATE, greg.get(Calendar.DATE) );
		cal.set(Calendar.MONTH,greg.get(Calendar.MONTH) );
		cal.set(Calendar.YEAR, greg.get(Calendar.YEAR));
		
		return cal.getTime();
	}
    
	
	/*
	 *Metods que no voy a implementar por el momento 
	 */
	@Override
	public List<?> select(Object o) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean insert(Object o) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean update(Object o) {
		// TODO Auto-generated method stub
		return false;
	}
	
	public boolean isSelect() {
		return isSelect;
	}

	public void setSelect(boolean isSelect) {
		this.isSelect = isSelect;
	}

	public  static void main (String [] args){
		System.out.println("Ini");
		DAOUtils dao = new DAOUtils();
		dao.query = "update cdiSAR  set  folioConsolidado = ?, comentarioCancelacion = ?, status = ?, fechaUltimoRechazo = ?, usuarioUltimoRechazoAceptacion = ? where folio  = ?";
		dao.columnas = new ArrayList<String>();
		dao.columnas.add("null");
		dao.columnas.add("'TEST $'");
		dao.columnas.add("7");
		dao.columnas.add("20150904");
		dao.columnas.add("'igarcia'");
		dao.columnas.add("1686");
		// update cdiSAR  set  folioConsolidado = ?, comentarioCancelacion = ?, status = ?, fechaUltimoRechazo = ?, usuarioUltimoRechazoAceptacion = ? where folio  = ? 
		//[null, 'TEST $', 7, 20150904, 'igarcia', 1686]
		try {
			dao.reemplazaDatos();
		} catch (SQLException e) {
			BOOKING_LOGGER.error(e.getMessage(), e);
		}
		
		
		
		
	////UN ejemplo de un insert
		/*
		DAOUtils util = new DAOUtils();
		StringBuffer query = new StringBuffer();					
		query.append(" INSERT INTO cdiHistoricoRevisiones ");
		query.append(" ( sar,accion,fecha,revision,comentario ) ");
		query.append(" VALUES ( ?,?,?,?,? ) ");						
		int cont =1;
		try {
			util.ajustaParametro(cont++, null, 14, Integer.class);
			util.ajustaParametro(cont++, null, "A", String.class);
			util.ajustaParametro(cont++, null, 20150202, Integer.class);
			util.ajustaParametro(cont++, null, 1, Integer.class);
			util.ajustaParametro(cont++, null, "Pruebas", String.class);
			
			
			util.inicializaQuery(query.toString());
			util.reemplazaDatos();
			
			System.out.println(util.dameQueryFinal());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		*/
		
		////Ejemplo de un update
//		int cont =1;
//		StringBuffer sb = new StringBuffer();
//		DAOUtils util = new DAOUtils();
//		try {
//		sb.append("UPDATE cdiHistoricoRevisiones SET ");				
//		sb.append(util.ajustaColumna("accion = ?"));
//		sb.append(util.ajustaColumna("fecha = ?"));
//		sb.append(" WHERE sar = ? ");
//		util.inicializaQuery(sb.toString());
//		//util.ajustaParametro(cont++, null, 14, Integer.class);
//		util.ajustaParametro(cont++, null, "B", String.class);
//		util.ajustaParametro(cont++, null, 20170202, Integer.class);
//		util.ajustaParametro(cont++, null, 14, Integer.class);
////		util.ajustaParametro(cont++, null, "Pruebas", String.class);
//		System.out.println(util.dameQueryFinal());
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		
		
		
		
		
		System.out.println("FIn");
	}
}
