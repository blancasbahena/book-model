package com.srm.pli.enums;

public enum Variables {

	NULL(-1, "null"), BLANCK(-2,""), CERO(0,"");
	
	private final int    valor;
	private final String descripcion;
	
	private Variables(int valor, String descripcion) {
		this.valor = valor;
		this.descripcion = descripcion;
	}
	
	public int getValue() {
		return valor;
	}
	
	public String getDescripcion() {
		return descripcion;
	}
}
