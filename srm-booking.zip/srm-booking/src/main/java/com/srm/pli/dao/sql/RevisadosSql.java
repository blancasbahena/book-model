package com.srm.pli.dao.sql;

public class RevisadosSql {

	public static final String SELECT_REVISADOS = new StringBuilder("")
			.append("SELECT folio, po, posicion, material, centro, cantidad, pesoProveedor, volumenProveedor, ")
			.append("precioUnitario, planeador, cantidadModificada, pesoModificado, volumenModificado, cliente, unidadMedida, condicionPago, ")
			.append("moneda, fechaProforma, paisOrigen, noDocumento, cartones, cantidadXCarton, pesoNeto, PesoBruto, cubicaje, pallet, ")
			.append("cartonXPallet, esPedidoDirecto, tieneDiferenciaMRP, statusMRP, tipoValidacionMRP, tipoModificacion, needsAuthPlanningMgr, cantidadUnidadMedida , factorCantidadUnidadMedida ")
			.append("FROM cdiSarDetalleEnRevision ").append("WHERE folio = ? ").toString();

	public static final String SELECT_REVISADOS_OTROS = new StringBuilder("")
			.append("SELECT folio, po, posicion, descripcion, cantidad, pesoProveedor, volumenProveedor, ")
			.append("cantidadModificada, pesoModificado, volumenModificado, tipoModificacion, needsAuthPlanningMgr ")
			.append(", poOtherItemModificado, precioUnitarioModificado, condicionPagoModificado, unidadMedidaModificado  ")
			.append("FROM cdiSarDetalleOthersEnRevision ").append("WHERE folio = ? ").toString();

	public static final String ADD_DETALLE = new StringBuilder().append(
			"INSERT INTO cdiSARDetalle (folio, po, posicion, material, cantidad, pesoProveedor, volumenProveedor, centro, precioUnitario, ")
			.append("planeador, cliente, fechaProforma, unidadMedida ,condicionPago,moneda,esPedidoDirecto,tieneDiferenciaMRP,statusMRP , factorCantidadUnidadMedida , cantidadUnidadMedida ) ")
			.append("VALUES ( ?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?").append(" ) ").toString();

}
