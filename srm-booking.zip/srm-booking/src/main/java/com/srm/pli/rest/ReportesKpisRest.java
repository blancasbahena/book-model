package com.srm.pli.rest;

import java.io.File;
import java.util.Map;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;
import com.srm.pli.bo.DataDescripcionExcel;
import com.srm.pli.bo.DataReporteKpi;
import com.srm.pli.enums.Mensajes;
import com.srm.pli.services.impl.ReportesKpisServiceImpl;
import com.srm.pli.utils.UtilsExcel;
import com.srm.pli.ws.vo.ResponseReporteKpisVO;
import com.sun.jersey.multipart.FormDataParam;
import com.truper.infra.rs.BaseRS;

@Path("/reporteKPIs")
public class ReportesKpisRest extends BaseRS
{
	private static final long serialVersionUID = 1L;
	
	@POST
	@Path("/cambio/semana")
	@Consumes({MediaType.MULTIPART_FORM_DATA})
	@Produces("application/vnd.ms-excel")
	public Response reporteCambioXSemana(
			@FormDataParam("fechaInicio") String fechaInicio, 
			@FormDataParam("fechaFin") String fechaFin,
			@FormDataParam("downloaded") Boolean descargable) 
	{
		log.info("Inicio Ws::Entrando al Ws que obtiene el reporte KIPSs por 'CAMBIOS POR SEMANA' ");
		ResponseReporteKpisVO responseVO = new ResponseReporteKpisVO();
		Response response = null;
		
		try 
		{
			if(descargable != null && !descargable)
			{
				Map<Integer, Map<String, DataReporteKpi>> dataReporteKpis = ReportesKpisServiceImpl.getInstance().getDataCambiosXSemana(fechaInicio, fechaFin);			
				return buildOK_JSONResponse(dataReporteKpis);
			}
			else
			if(descargable != null && descargable)
			{
				DataDescripcionExcel dataInfoReporteKpis = ReportesKpisServiceImpl.getInstance().getInfoDataReporte(1);
				Map<Integer, Map<String, DataReporteKpi>> dataReporteKpis = ReportesKpisServiceImpl.getInstance().getDataCambiosXSemana(fechaInicio, fechaFin);			
				File file = UtilsExcel.generarReporteByTipo(dataReporteKpis, dataInfoReporteKpis, fechaInicio, fechaFin);
				
				if(!dataReporteKpis.isEmpty())
				{
					ResponseBuilder responseBuilder = Response.ok((Object) file);
					responseBuilder.header("Content-Disposition", "attachment; filename=" + dataInfoReporteKpis.getNombreArchivo() + "");
					return responseBuilder.build();
				}
			}
			else
			{
				responseVO.setTipoMensaje(Mensajes.TIPO_WARNING.getMensaje());
				responseVO.setMensaje(Mensajes.MSG_WARNING.getMensaje());
				response = Response.status(300).build();
			}
		} 
		catch (Exception e) 
		{
			log.error("Hubo un error al obtener los datos para el reporte KPIPs con fechas {} - {}, Exception: {}", fechaInicio, fechaFin, e.getMessage(), e);
			responseVO.setTipoMensaje(Mensajes.TIPO_ERROR.getMensaje());
			responseVO.setMensaje(Mensajes.MSG_ERROR.getMensaje());
			response = buildErrorResponse(responseVO);
		}
		log.info("Fin Ws::Se termino de ejecutar el Ws que obtiene el reporte KPIPs por  'CAMBIOS POR SEMANA' ");
		
		return response;
	}
	
	@POST
	@Path("/cambio/naviera/proveedor")
	@Consumes({MediaType.MULTIPART_FORM_DATA})
	@Produces("application/vnd.ms-excel")
	public Response reporteCambioXNaviera(
			@FormDataParam("fechaInicio") String fechaInicio, 
			@FormDataParam("fechaFin") String fechaFin,
			@FormDataParam("downloaded") Boolean descargable) 
	{
		log.info("Inicio Ws::Entrando al Ws que obtiene el reporte KPIPs por 'CAMBIO NAVIERA POR PROVEEDOR' ");
		ResponseReporteKpisVO responseVO = new ResponseReporteKpisVO();
		Response response = null;
		
		try 
		{
			if(descargable != null && !descargable)
			{
				Map<String, Map<String, DataReporteKpi>> dataReporteKpis = ReportesKpisServiceImpl.getInstance().getDataCambiosXNavieraProveedor(fechaInicio, fechaFin);			
				return buildOK_JSONResponse(dataReporteKpis);
			}
			else
			if(descargable != null && descargable)
			{
				DataDescripcionExcel dataDescripcionExcel = ReportesKpisServiceImpl.getInstance().getInfoDataReporte(2);
				Map<String, Map<String, DataReporteKpi>> dataReporteKpis = ReportesKpisServiceImpl.getInstance().getDataCambiosXNavieraProveedor(fechaInicio, fechaFin);			
				File file = UtilsExcel.generarReporteByTipo3(dataReporteKpis, dataDescripcionExcel, fechaInicio, fechaFin);
				
				if(!dataReporteKpis.isEmpty())
				{
					ResponseBuilder responseBuilder = Response.ok((Object) file);
					responseBuilder.header("Content-Disposition", "attachment; filename=" + dataDescripcionExcel.getNombreArchivo() + "");
					return responseBuilder.build();
				}
			}
			else
			{
				responseVO.setTipoMensaje(Mensajes.TIPO_WARNING.getMensaje());
				responseVO.setMensaje(Mensajes.MSG_WARNING.getMensaje());
				response = Response.status(300).build();
			}
		} 
		catch (Exception e) 
		{
			log.error("Hubo un error al obtener los datos para el reporte KPIPs con fechas {} - {}, Exception: {}", fechaInicio, fechaFin, e.getMessage(), e);
			responseVO.setTipoMensaje(Mensajes.TIPO_ERROR.getMensaje());
			responseVO.setMensaje(Mensajes.MSG_ERROR.getMensaje());
			response = buildErrorResponse(responseVO);
		}
		log.info("Fin Ws::Se termino de ejecutar el Ws que obtiene el reporte KPIPs por 'CAMBIO NAVIERA POR PROVEEDOR' ");
		
		return response;
	}
	
	@POST
	@Path("/contenedor/naviera/semana")
	@Consumes({MediaType.MULTIPART_FORM_DATA})
	@Produces("application/vnd.ms-excel")
	public Response reporteVolBycontenedorXNaviera(
			@FormDataParam("fechaInicio") String fechaInicio, 
			@FormDataParam("fechaFin") String fechaFin,
			@FormDataParam("downloaded") Boolean descargable) 
	{
		log.info("Inicio Ws::Entrando al Ws que obtiene el reporte KPIPs por 'VOL. DE CONTENEDORES POR NAVIERA POR SEMANA' ");
		ResponseReporteKpisVO responseVO = new ResponseReporteKpisVO();
		Response response = null;
		
		try 
		{
			if(descargable != null && !descargable)
			{
				Map<Integer, Map<String, DataReporteKpi>> dataReporteKpis = ReportesKpisServiceImpl.getInstance().getDataVolDeContenedorXNavieraXSemana(fechaInicio, fechaFin);			
				return buildOK_JSONResponse(dataReporteKpis);
			}
			else
			if(descargable != null && descargable)
			{
				DataDescripcionExcel dataDescripcionExcel = ReportesKpisServiceImpl.getInstance().getInfoDataReporte(3);
				Map<Integer, Map<String, DataReporteKpi>> dataReporteKpis = ReportesKpisServiceImpl.getInstance().getDataVolDeContenedorXNavieraXSemana(fechaInicio, fechaFin);			
				File file = UtilsExcel.generarReporteByTipo(dataReporteKpis, dataDescripcionExcel, fechaInicio, fechaFin);
				
				if(!dataReporteKpis.isEmpty())
				{
					ResponseBuilder responseBuilder = Response.ok((Object) file);
					responseBuilder.header("Content-Disposition", "attachment; filename=" + dataDescripcionExcel.getNombreArchivo() + "");
					return responseBuilder.build();
				}
			}
			else
			{
				responseVO.setTipoMensaje(Mensajes.TIPO_WARNING.getMensaje());
				responseVO.setMensaje(Mensajes.MSG_WARNING.getMensaje());
				response = Response.status(300).build();
			}
		} 
		catch (Exception e) 
		{
			log.error("Hubo un error al obtener los datos para el reporte KPIPs con fechas {} - {}, Exception: {}", fechaInicio, fechaFin, e.getMessage(), e);
			responseVO.setTipoMensaje(Mensajes.TIPO_ERROR.getMensaje());
			responseVO.setMensaje(Mensajes.MSG_ERROR.getMensaje());
			response = buildErrorResponse(responseVO);
		}
		log.info("Fin Ws::Se termino de ejecutar el Ws que obtiene el reporte KPIPs por 'VOL. DE CONTENEDORES POR NAVIERA POR SEMANA' ");
		
		return response;
	}
	
	@POST
	@Path("/cambio/puerto")
	@Consumes({MediaType.MULTIPART_FORM_DATA})
	@Produces("application/vnd.ms-excel")
	public Response reporteCambiosXTopPuerto(
			@FormDataParam("fechaInicio") String fechaInicio, 
			@FormDataParam("fechaFin") String fechaFin,
			@FormDataParam("downloaded") Boolean descargable) 
	{
		log.info("Inicio Ws::Entrando al Ws que obtiene el reporte KPI�s por 'CAMBIOS POR TOP PUERTOS' ");
		ResponseReporteKpisVO responseVO = new ResponseReporteKpisVO();
		Response response = null;
		
		try 
		{
			if(descargable != null && !descargable)
			{
				Map<Integer, Map<String, DataReporteKpi>> dataReporteKpis = ReportesKpisServiceImpl.getInstance().getDataCambiosXTopDePuertoXSemana(fechaInicio, fechaFin);			
				return buildOK_JSONResponse(dataReporteKpis);
			}
			else
			if(descargable != null && descargable)
			{
				DataDescripcionExcel dataDescripcionExcel = ReportesKpisServiceImpl.getInstance().getInfoDataReporte(4);
				Map<Integer, Map<String, DataReporteKpi>> dataReporteKpis = ReportesKpisServiceImpl.getInstance().getDataCambiosXTopDePuertoXSemana(fechaInicio, fechaFin);			
				File file = UtilsExcel.generarReporteByTipo2(dataReporteKpis, dataDescripcionExcel, fechaInicio, fechaFin);
				
				if(!dataReporteKpis.isEmpty())
				{
					ResponseBuilder responseBuilder = Response.ok((Object) file);
					responseBuilder.header("Content-Disposition", "attachment; filename=" + dataDescripcionExcel.getNombreArchivo() + "");
					return responseBuilder.build();
				}
			}
			else
			{
				responseVO.setTipoMensaje(Mensajes.TIPO_WARNING.getMensaje());
				responseVO.setMensaje(Mensajes.MSG_WARNING.getMensaje());
				response = Response.status(300).build();
			}
		} 
		catch (Exception e) 
		{
			log.error("Hubo un error al obtener los datos para el reporte KPIps con fechas {} - {}, Exception: {}", fechaInicio, fechaFin, e.getMessage(), e);
			responseVO.setTipoMensaje(Mensajes.TIPO_ERROR.getMensaje());
			responseVO.setMensaje(Mensajes.MSG_ERROR.getMensaje());
			response = buildErrorResponse(responseVO);
		}
		log.info("Fin Ws::Se termino de ejecutar el Ws que obtiene el reporte KPIps por 'CAMBIOS POR TOP PUERTOS' ");
		
		return response;
	}
	
	@POST
	@Path("/contenedor/puerto/semana")
	@Consumes({MediaType.MULTIPART_FORM_DATA})
	@Produces("application/vnd.ms-excel")
	public Response reporteVolBycontenedorXPuerto(
			@FormDataParam("fechaInicio") String fechaInicio, 
			@FormDataParam("fechaFin") String fechaFin,
			@FormDataParam("downloaded") Boolean descargable) 
	{
		log.info("Inicio Ws::Entrando al Ws que obtiene el reporte KPI�s por 'VOL. DE CONTENEDORES POR PUERTO POR SEMANA' ");
		ResponseReporteKpisVO responseVO = new ResponseReporteKpisVO();
		Response response = null;
		
		try 
		{
			if(descargable != null && !descargable)
			{
				Map<Integer, Map<String, DataReporteKpi>> dataReporteKpis = ReportesKpisServiceImpl.getInstance().getDataVolDeContenedorXPuertoXSemana(fechaInicio, fechaFin);			
				return buildOK_JSONResponse(dataReporteKpis);
			}
			else
			if(descargable != null && descargable)
			{
				DataDescripcionExcel dataDescripcionExcel = ReportesKpisServiceImpl.getInstance().getInfoDataReporte(5);
				Map<Integer, Map<String, DataReporteKpi>> dataReporteKpis = ReportesKpisServiceImpl.getInstance().getDataVolDeContenedorXPuertoXSemana(fechaInicio, fechaFin);			
				File file = UtilsExcel.generarReporteByTipo(dataReporteKpis, dataDescripcionExcel, fechaInicio, fechaFin);
				
				if(!dataReporteKpis.isEmpty())
				{
					ResponseBuilder responseBuilder = Response.ok((Object) file);
					responseBuilder.header("Content-Disposition", "attachment; filename=" + dataDescripcionExcel.getNombreArchivo() + "");
					return responseBuilder.build();
				}
			}
			else
			{
				responseVO.setTipoMensaje(Mensajes.TIPO_WARNING.getMensaje());
				responseVO.setMensaje(Mensajes.MSG_WARNING.getMensaje());
				response = Response.status(300).build();
			}
		} 
		catch (Exception e) 
		{
			log.error("Hubo un error al obtener los datos para el reporte KPIps con fechas {} - {}, Exception: {}", fechaInicio, fechaFin, e.getMessage(), e);
			responseVO.setTipoMensaje(Mensajes.TIPO_ERROR.getMensaje());
			responseVO.setMensaje(Mensajes.MSG_ERROR.getMensaje());
			response = buildErrorResponse(responseVO);
		}
		log.info("Fin Ws::Se termino de ejecutar el Ws que obtiene el reporte KPIps por 'VOL. DE CONTENEDORES POR PUERTO POR SEMANA' ");
		
		return response;
	}
}
