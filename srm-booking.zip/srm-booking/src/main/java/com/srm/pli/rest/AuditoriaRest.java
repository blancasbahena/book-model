package com.srm.pli.rest;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.srm.pli.bo.BeanFiltroAuditoria;
import com.srm.pli.bo.BeanFiltroAuditoriaVista;
import com.srm.pli.services.AuditoriaService;
import com.truper.businessEntity.BeanAuditoria;
import com.truper.businessEntity.BeanAuditoriaMatriz;
import com.truper.businessEntity.BeanAuditoriaPpu;
import com.truper.businessEntity.BeanAuditoriaRechazado;
import com.truper.businessEntity.BeanAuditoriaSar;
import com.truper.businessEntity.BeanAuditoriaSarDetalle;
import com.truper.businessEntity.BeanAuditoriaSinMatriz;
import com.truper.businessEntity.BeanAuditoriaSinMatrizDetalle;
import com.truper.businessEntity.UserBean;
import com.truper.infra.rs.BaseRS;
import com.truper.utils.date.EnumFechas;
import com.truper.utils.string.UtilsString;

@Path("/auditoria")
public class AuditoriaRest extends BaseRS {

	private static final long serialVersionUID = 5394059842158283958L;
	Gson g = new GsonBuilder().serializeSpecialFloatingPointValues().setDateFormat(EnumFechas.FORMATO_YYYY_MM_DD.to())
			.create();
	private static final Logger LOGGER = LogManager.getRootLogger();

	@Context
	private HttpServletRequest request;

	@POST
	@Path("/ordenesSinMatriz")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response getCabecerasOrdenesSinMatriz(String json) {
		List<BeanAuditoriaSinMatriz> r = null;
		try {
			BeanFiltroAuditoriaVista filtro = g.fromJson(json, BeanFiltroAuditoriaVista.class);
			r = AuditoriaService.getInstance().getCabeceraOrdenesSinMatriz(filtro);
		} catch (Exception e) {
			return buildErrorResponse(g.toJson(r));
		}
		return buildOKResponse(g.toJson(r));
	}

	@POST
	@Path("/detalleOrdenSinMatriz")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response getDetalleOrdenSinMatriz(String json) {
		List<BeanAuditoriaSinMatrizDetalle> r = null;
		try {
			BeanAuditoria param = g.fromJson(json, BeanAuditoria.class);
			r = AuditoriaService.getInstance().getDetalleOrdenSinMatriz(param);
		} catch (Exception e) {
			return buildErrorResponse(g.toJson(r));
		}
		return buildOKResponse(g.toJson(r));
	}

	@POST
	@Path("/reject/detalleOrdenSinMatriz")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response getDetalleOrdenSinMatrizReject(String json) {
		List<BeanAuditoriaSinMatrizDetalle> r = null;
		try {
			BeanAuditoria param = g.fromJson(json, BeanAuditoria.class);
			r = AuditoriaService.getInstance().getDetalleOrdenSinMatrizReject(param);
		} catch (Exception e) {
			return buildErrorResponse(g.toJson(r));
		}
		return buildOKResponse(g.toJson(r));
	}

	@POST
	@Path("/liberaOrdenSinMatriz")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response liberaOrdenSinMatriz(String json) {
		String log = buildInicialLog("/liberaOrdenSinMatriz", json);
		try {
			LOGGER.info(log);
			BeanAuditoria param = g.fromJson(json, BeanAuditoria.class);
			AuditoriaService.getInstance().liberaOrdenSinMatriz(param);
		} catch (Exception e) {
			LOGGER.error("/liberaOrdenSinMatriz", e);
			return buildErrorResponse(e.getMessage());
		}
		LOGGER.info("/liberaOrdenSinMatriz @Success");
		return buildOKResponse(g.toJson(true));
	}

	@POST
	@Path("/liberaOrdenConMatriz")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response liberaOrdenConMatriz(String json) {
		String log = buildInicialLog("/liberaOrdenConMatriz", json);
		try {
			LOGGER.info(log);
			BeanAuditoriaMatriz param = g.fromJson(json, BeanAuditoriaMatriz.class);
			AuditoriaService.getInstance().liberaOrdenConMatriz(param);
		} catch (Exception e) {
			LOGGER.error("/liberaOrdenConMatriz", e);
			return buildErrorResponse(e.getMessage());
		}
		LOGGER.info("/liberaOrdenConMatriz @Success");
		return buildOKResponse(g.toJson(true));
	}

	@POST
	@Path("/rechazaOrdenSinMatriz")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response rechazaOrdenSinMatriz(String json) {
		String log = buildInicialLog("/rechazaOrdenSinMatriz", json);
		try {
			LOGGER.info(log);
			BeanAuditoria param = g.fromJson(json, BeanAuditoria.class);
			AuditoriaService.getInstance().rechazaOrdenSinMatriz(param);
		} catch (Exception e) {
			LOGGER.error("/rechazaOrdenSinMatriz", e);
			return buildErrorResponse(e.getMessage());
		}
		LOGGER.info("/rechazaOrdenSinMatriz @Success");
		return buildOKResponse(g.toJson(true));
	}

	@POST
	@Path("/reject/ordenes")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response getCabecerasOrdenesRechazadas(String json) {
		List<BeanAuditoriaRechazado> r = null;
		try {
			BeanFiltroAuditoriaVista filtro = g.fromJson(json, BeanFiltroAuditoriaVista.class);
			r = AuditoriaService.getInstance().getCabecerasOrdenesRechazadas(filtro);
		} catch (Exception e) {
			return buildErrorResponse(g.toJson(r));
		}
		return buildOKResponse(g.toJson(r));
	}

	@POST
	@Path("/ppu/ordenes")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response getCabecerasOrdenesPPU(String json) {
		List<BeanAuditoriaPpu> r = null;
		try {
			BeanFiltroAuditoriaVista filtro = g.fromJson(json, BeanFiltroAuditoriaVista.class);
			r = AuditoriaService.getInstance().getCabecerasOrdenesPPU(filtro);
		} catch (Exception e) {
			return buildErrorResponse(g.toJson(r));
		}
		return buildOKResponse(g.toJson(r));
	}

	@POST
	@Path("/sars")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response getCabecerasSAR(String json) {
		List<BeanAuditoriaSar> r = null;
		try {
			BeanFiltroAuditoriaVista param = g.fromJson(json, BeanFiltroAuditoriaVista.class);
			r = AuditoriaService.getInstance().getCabecerasSAR(param);
		} catch (Exception e) {
			return buildErrorResponse(g.toJson(r));
		}
		return buildOKResponse(g.toJson(r));
	}

	@GET
	@Path("/detalleSar/{folio}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getDetalleSar(@PathParam("folio") int folio) {
		List<BeanAuditoriaSarDetalle> r = null;
		try {
			r = AuditoriaService.getInstance().getDetalleSar(folio);
		} catch (Exception e) {
			return buildErrorResponse(g.toJson(r));
		}
		return buildOKResponse(g.toJson(r));
	}

	@POST
	@Path("/sars/actualiza")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response actualizaSAR(String json) {
		String log = buildInicialLog("/sars/actualiza", json);
		try {
			LOGGER.info(log);
			BeanFiltroAuditoria param = g.fromJson(json, BeanFiltroAuditoria.class);
			AuditoriaService.getInstance().actualizaSar(param, getUser());
		} catch (Exception e) {
			LOGGER.error("/sars/actualiza", e);
			return buildErrorResponse(e.getMessage());
		}
		LOGGER.info("/sars/actualiza @Success");
		return buildOKResponse(g.toJson(true));
	}

	@POST
	@Path("/detalleOrdenConMatriz")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response getDetalleOrdenConMatriz(String json) {
		List<BeanAuditoriaSinMatrizDetalle> r = null;
		try {
			BeanAuditoria param = g.fromJson(json, BeanAuditoria.class);
			r = AuditoriaService.getInstance().getDetalleOrdenConMatriz(param);
		} catch (Exception e) {
			return buildErrorResponse(g.toJson(r));
		}
		return buildOKResponse(g.toJson(r));
	}

	private UserBean getUser() {
		HttpSession session = request.getSession(false);
		if (session == null)
			return null;
		UserBean usuario = (UserBean) session.getAttribute("usuario");
		return usuario;
	}

	private String getUserToString() {
		UserBean user = getUser();
		if (user == null)
			return "null";
		return UtilsString.append("#", user.getIdUser(), " ", user.getUserName());
	}

	/**
	 * @param json
	 * @return
	 */
	private String buildInicialLog(String path, String json) {
		return UtilsString.append(path, " @User:", getUserToString(), " @Consumes:", json);
	}

}
