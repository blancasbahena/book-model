package com.srm.pli.bo.jasperReports;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;

import com.srm.pli.bo.SarDetalleBO;
import com.srm.pli.helper.FormatSARDetalleHelper;
import com.srm.pli.utils.FormatoUtils;
import com.srm.pli.utils.FuncionesComunesPLI;
import com.srm.pli.utils.PropertiesDb;
import com.truper.businessEntity.BeanLetoniano;
import com.truper.businessEntity.ProductoBean;
import com.truper.utils.number.UtilsNumero;
import com.truper.utils.string.UtilsString;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BeanPKLJasperDetalles {
	private String marca;
	private String po;
	private String codigo;
	private String material;
	private String descripcion;
	private int cantidad;
	private String unidad;
	private int cartones;
	private String pesoNeto;
	private String pesoBruto;
	private String volumen;
	private int posicion;
	private BeanLetoniano idioma = new BeanLetoniano();
	
	FormatSARDetalleHelper format = new FormatSARDetalleHelper();
	
	
	public BeanPKLJasperDetalles() {
		
	}
	
	public BeanPKLJasperDetalles(SarDetalleBO bo) {
		if(bo.getPoOtherItem() != null || !UtilsNumero.isInteger(bo.getPo())) {
			marca = "";
			po= bo.getPoOtherItem() == null ? "-" : bo.getPoOtherItem() ;
			codigo= "";
			material="";
			descripcion=bo.getDescripcion();
			//letoniano
			idioma = format.getLetoniano(bo.getMaterial());
			if(idioma.getItem()!=null)
			descripcion = idioma.getDescripcion();
			
			cantidad= (bo.getCantidadUnidadMedida() == null || bo.getCantidadUnidadMedida().compareTo(BigDecimal.ZERO) == 0 )?bo.getCantidad():bo.getCantidadUnidadMedida().intValue();
			unidad=bo.getUnidaMedida();
			cartones=bo.getCartones();
			pesoNeto= FuncionesComunesPLI.formatea(bo.getPesoNetoPKL().doubleValue(),3);
			pesoBruto=FuncionesComunesPLI.formatea(bo.getPesoBrutoPKL().doubleValue(),3);
			volumen=FuncionesComunesPLI.formatea(bo.getCubicajePKL().doubleValue(),3);
		}else {
			po=bo.getPo();
			codigo=bo.getMaterial()+"";
			ProductoBean p = FuncionesComunesPLI.productos.get(codigo);

			if(p != null) {
				material=p.getClave();
				descripcion=p.getDescripcion();
				//letoniano
				idioma = format.getLetoniano(bo.getMaterial());
				if(idioma.getItem()!=null)
					descripcion = idioma.getDescripcion();
				
				marca = p.getMarcaComercial();
			}
			
			cantidad=(bo.getCantidadUnidadMedida() == null || bo.getCantidadUnidadMedida().compareTo(BigDecimal.ZERO) == 0 )?bo.getCantidad():bo.getCantidadUnidadMedida().intValue();
			unidad=bo.getUnidaMedida();
			cartones=bo.getCartones();
			pesoNeto= FuncionesComunesPLI.formatea(bo.getPesoNetoPKL().doubleValue(),3);
			pesoBruto=FuncionesComunesPLI.formatea(bo.getPesoBrutoPKL().doubleValue(),3);
			volumen=FuncionesComunesPLI.formatea(bo.getCubicajePKL().doubleValue(),3);
		}
	}
	
	public BeanPKLJasperDetalles(SarDetalleBO bo, boolean isPrePL) {
		String CERO_CERO = "0.00";
		String ND = "N.D";
		if(bo.getPoOtherItem() != null || !UtilsNumero.isInteger(bo.getPo())) {
			marca = "";
			po= bo.getPoOtherItem() == null ? "" : bo.getPoOtherItem() ;
			codigo= "";
			material="";
			descripcion=bo.getDescripcion();
			//letoniano
			idioma = format.getLetoniano(bo.getMaterial());
			if(idioma.getItem()!=null)
			descripcion = idioma.getDescripcion();
			
			cantidad=(bo.getCantidadUnidadMedida() == null || bo.getCantidadUnidadMedida().compareTo(BigDecimal.ZERO)== 0 )?bo.getCantidad():bo.getCantidadUnidadMedida().intValue();
			unidad=bo.getUnidaMedida();
			cartones=bo.getCartones();
			try {
				
				String cubicaje = null;
				if(bo.getCubicajePKL() != null ) {
					if(BigDecimal.ZERO.compareTo(bo.getCubicajePKL()) < 0) {
						cubicaje = bo.getCubicajePKL().toString();
					}
				}
				String peso = null;
				if(bo.getPesoNetoPKL() != null) { 
					if(BigDecimal.ZERO.compareTo(bo.getPesoNetoPKL()) < 0  ) {
						peso = bo.getPesoNetoPKL().toString();
					}
				}
				if(UtilsString.isNullOrUndefined(cubicaje) || ND.equals(cubicaje) || 
						CERO_CERO.equals(cubicaje)) {
					bo.setCubicajePKL(new BigDecimal(bo.getVolumenProveedor()));
				}
				if(UtilsString.isNullOrUndefined(peso) || ND.equals(peso) || 
						CERO_CERO.equals(peso)) {
					bo.setPesoNetoPKL(new BigDecimal(bo.getPesoProveedor()));
				}
				
			}catch (Exception e) {
				cartones = 0;
			}
			
			
			pesoNeto= FuncionesComunesPLI.formatea(bo.getPesoNetoPKL() == null ? 0 : bo.getPesoNetoPKL().doubleValue(),2);
			pesoBruto=FuncionesComunesPLI.formatea(bo.getPesoBrutoPKL() == null ? 0 : bo.getPesoBrutoPKL().doubleValue(),2);
			volumen=FuncionesComunesPLI.formatea(bo.getCubicajePKL() == null ? 0 : bo.getCubicajePKL().doubleValue(),2);
			posicion = bo.getPosicion();
		}else {
		
			po=bo.getPo();
			codigo=bo.getMaterial()+"";
			cartones=bo.getCartones();
			posicion = bo.getPosicion();
			ProductoBean p = FuncionesComunesPLI.productos.get(codigo);
			if(p != null) {
				material=p.getClave();
				descripcion=p.getDescripcion();
				//letoniano
				idioma = format.getLetoniano(bo.getMaterial());
				if(idioma.getItem()!=null)
				descripcion = idioma.getDescripcion();
				
				marca = p.getMarcaComercial();
				try {
					double redondeo = bo.getCantidad() / p.getMaster();
					if(bo.getCartones() == null || bo.getCartones().intValue() == 0 ) {
						cartones = FormatoUtils.getInstance().roundCeiling(redondeo);
					}else {
						cartones = bo.getCartones();
					}
					
					String cubicaje = null;
					if(bo.getCubicajePKL() != null ) {
						if(BigDecimal.ZERO.compareTo(bo.getCubicajePKL()) < 0) {
							cubicaje = bo.getCubicajePKL().toString();
						}
					}
					String peso = null;
					if(bo.getPesoNetoPKL() != null) { 
						if(BigDecimal.ZERO.compareTo(bo.getPesoNetoPKL()) < 0  ) {
							peso = bo.getPesoNetoPKL().toString();
						}
					}
					if(UtilsString.isNullOrUndefined(cubicaje) || ND.equals(cubicaje) || 
							CERO_CERO.equals(cubicaje)) {
						bo.setCubicajePKL(new BigDecimal(bo.getVolumenProveedor()));
					}
					if(UtilsString.isNullOrUndefined(peso) || ND.equals(peso) || 
							CERO_CERO.equals(peso)) {
						bo.setPesoNetoPKL(new BigDecimal(bo.getPesoProveedor()));
					}
					
				}catch (Exception e) {
					cartones = 0;
				}
			}
			
			cantidad=(bo.getCantidadUnidadMedida() == null || bo.getCantidadUnidadMedida().compareTo(BigDecimal.ZERO)== 0 )?bo.getCantidad():bo.getCantidadUnidadMedida().intValue();
			unidad=bo.getUnidaMedida();
			
			pesoNeto= FuncionesComunesPLI.formatea(bo.getPesoNetoPKL() == null ? 0 : bo.getPesoNetoPKL().doubleValue(),2);
			pesoBruto=FuncionesComunesPLI.formatea(bo.getPesoBrutoPKL() == null ? 0 : bo.getPesoBrutoPKL().doubleValue(),2);
			volumen=FuncionesComunesPLI.formatea(bo.getCubicajePKL() == null ? 0 : bo.getCubicajePKL().doubleValue(),2);
		}
		idioma = format.getLetoniano(bo.getMaterial());
		if(idioma.getItem()!=null)
		this.descripcion = idioma.getDescripcion();
	}
}
