package com.srm.pli.rest;

import java.util.Set;
import java.util.TreeSet;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.srm.pli.helper.PriceReleaseHelper;
import com.srm.pli.services.CatalogoService;
import com.srm.pli.utils.CatalogosUtils;
import com.truper.infra.rs.BaseRS;

@Path("/utils")
public class UtilsREST extends BaseRS {

	private static final long serialVersionUID = -3638892123759747232L;

	@GET
	@Path("/catalogos/unidadesMedida")
	public Response unidadesMedida() {
		Set<String> catalogo = null;
		Set<String> catalogo_sort = null;
		catalogo = CatalogosUtils.getInstance().getUnidadesMedida();
		if (catalogo != null && !catalogo.isEmpty()) {
			catalogo_sort = new TreeSet<>(catalogo);
		}
		return buildOK_JSONResponse(catalogo_sort);
	}

	@GET
	@Path("/catalogos/unidadesMedida/{otherType}")
	public Response unidadesMedida(@PathParam("otherType") String otherType) {
		Set<String> catalogo = null;
		Set<String> catalogo_sort = null;
		if (otherType == null)
			return buildError_JSONResponse("Se recibio el tipo de other item nulo");
		otherType = otherType.trim();
		catalogo = CatalogoService.getInstance().getUnidadesDeMedida(otherType);
		if (catalogo != null && !catalogo.isEmpty()) {
			catalogo_sort = new TreeSet<>(catalogo);
		}
		return buildOK_JSONResponse(catalogo_sort);
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/otherItem/evaluaTipoServicio/{otherType}")
	public Response isOtherItemTipoServicio(@PathParam("otherType") String otherType) {
		if (otherType == null)
			return buildError_JSONResponse("Se recibio el tipo de other item nulo");
		boolean valor;
		try {
			valor = PriceReleaseHelper.getInstance().isOtherItemService(otherType);
		} catch (Exception e) {
			e.printStackTrace();
			return buildError_JSONResponse(e.getMessage());
		}
		return buildOK_JSONResponse(valor);
	}
}
