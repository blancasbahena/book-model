package com.srm.pli.helper;

import com.srm.pli.utils.FuncionesComunesPLI;
import com.truper.businessEntity.BeanRowFileCarrier;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
 @Getter
 @Setter
 @ToString
public class FormatRowFileNaviera {
	private String renglon;
	private String booking;
	private String bl;
	private String contenedor;	
	private String etd;
	private String eta;	
	private String barco;
	private String viaje; 
	private String pol;
	private String pod;	
	private Boolean esError;
	private String tieneConflicto;
	private String mensaje;
	private String sar;
	private String sarConsolidado;
	private String enviarSAP;
	private String cambio;
	private String resultadoSAP;
	private String cambioETDmayor;
	private String folioConsolidado;
	private String concatenado;
	
	public FormatRowFileNaviera(BeanRowFileCarrier origen){
		renglon = origen.getRenglon()+"";
		booking = origen.getBooking();
		bl =origen.getBl();
		contenedor =origen.getContenedor();
		etd = origen.getEtd() >0 ? FuncionesComunesPLI.formateaFecha(origen.getEtd())  : "N.D";
		eta =origen.getEta() >0 ? FuncionesComunesPLI.formateaFecha(origen.getEta())  : "N.D";
		barco = origen.getBarco();
		viaje = origen.getViaje();
		pol = (origen.getPol()  != null && !"-1".equals(origen.getPol())) ? FuncionesComunesPLI.mapaPuertosOrigen.get(origen.getPol()).getNombre() : "N.D"; 
		pod = (origen.getPod() != null && !"-1".equals(origen.getPod())) ? FuncionesComunesPLI.mapaPuertosDestino.get(origen.getPod()).getNombre() : "N.D";
		esError = origen.getEsError() != null && origen.getEsError() ? true : false;
		tieneConflicto =origen.isTieneConflicto()+"";
		mensaje = origen.getMensaje();
		enviarSAP = origen.isEnviarSAP()+"";
		cambio = origen.isCambio()+"";
		resultadoSAP = origen.isResultadoSAP()+"";
		sar = origen.getSar() != null && origen.getSar().intValue() > 0 ? origen.getSar()+"" : "N.D";
		cambioETDmayor = origen.isCambioETDmayor()+"";
		sarConsolidado = origen.getSarConsolidado() == null  ? "" : origen.getSarConsolidado()+"";
		folioConsolidado=  origen.getFolioConsolidado();
		concatenado =  origen.getConcatenado();
	}
	 
}
