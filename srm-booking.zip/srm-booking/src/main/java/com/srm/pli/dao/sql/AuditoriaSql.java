package com.srm.pli.dao.sql;

import com.srm.pli.bo.BeanFiltroAuditoriaVista;
import com.srm.pli.helper.AuditoriaHelper;
import com.truper.bpm.enums.EstatusAuditoriaEnum;
import com.truper.bpm.enums.StatusControlMatricesEnum;
import com.truper.bpm.enums.TipoPosicionEnum;
import com.truper.utils.string.UtilsString;

public class AuditoriaSql {

	public static final String UPSERT_AUDITORIA;
	public static final String UPDATE_SIN_MATRIZ_LIBERA;
	public static final String UPDATE_SIN_MATRIZ_RECHAZA;
	public static final String UPDATE_SAR;
	public static final String SELECT_SIN_MATRIZ_DETALLE_PO_DATE;
	public static final String SELECT_SIN_MATRIZ_DETALLE_PO_DATE_REJECT;
		
	public static final String SELECT_CON_MATRIZ_DETALLE_PO_SUPPLIER_DATE;
	public static final String SELECT_CON_MATRIZ_DETALLE_DATE_PO;
	public static final String SELECT_SAR_DETALLE_FOLIO;
	private static final String SELECT_SAR_CABECERAS;
	private static final String SELECT_SAR_CABECERAS_ESTATUS;
	private static final String SELECT_SIN_MATRIZ_CABECERAS_ESTATUS;
	private static final String SELECT_PPU_CABECERAS;
	private static final String SELECT_REJECT_CABECERAS;

	private AuditoriaSql() {
	}

	static {
		StringBuilder sql = new StringBuilder();
		sql.append("MERGE cdiAuditoria as [target] ");
		sql.append(" USING (SELECT ? estatus ");
		sql.append("            , ? proveedor ");
		sql.append("            , ? po ");
		sql.append("			, ? posicion ");
		sql.append("			, ? material ");
		sql.append("			, ? centro ");
		sql.append("			, ? cantidad ");
		sql.append("			, ? precioUnitario ");
		sql.append("			, ? fecha ");
		sql.append("			, ? documentosRequeridos) AS [source] ");
		sql.append(" ON [target].proveedor = [source].proveedor ");
		sql.append("	AND [target].po = [source].po ");
		sql.append("	AND [target].posicion = [source].posicion ");
		sql.append("	AND CONVERT(VARCHAR(8),[target].createDate,112) = CONVERT(VARCHAR(8),GETDATE(),112) ");
		sql.append(" WHEN matched THEN ");
		sql.append("    UPDATE SET [target].estatus = [source].estatus ");
		sql.append("             , [target].material = [source].material ");
		sql.append("             , [target].centro = [source].centro ");
		sql.append("			 , [target].cantidad = [source].cantidad ");
		sql.append("			 , [target].precioUnitario = [source].precioUnitario ");
		sql.append("			 , [target].fecha = [source].fecha ");
		sql.append("			 , [target].documentosRequeridos = [source].documentosRequeridos ");
		sql.append("			 , [target].comentarios = NULL ");
		sql.append("			 , [target].lastCreateDate = GETDATE() ");
		sql.append("			 , [target].releaseDate = NULL ");
		sql.append("			 , [target].rejectDate = NULL ");
		sql.append(" WHEN NOT matched THEN ");
		sql.append("    INSERT (estatus ");
		sql.append("             , proveedor ");
		sql.append("             , po ");
		sql.append("			 , posicion ");
		sql.append("			 , material ");
		sql.append("			 , centro ");
		sql.append("			 , cantidad ");
		sql.append("			 , precioUnitario ");
		sql.append("			 , fecha ");
		sql.append("			 , documentosRequeridos) ");
		sql.append("    VALUES ([source].estatus ");
		sql.append("             , [source].proveedor ");
		sql.append("             , [source].po ");
		sql.append("			 , [source].posicion ");
		sql.append("			 , [source].material ");
		sql.append("			 , [source].centro ");
		sql.append("			 , [source].cantidad ");
		sql.append("			 , [source].precioUnitario ");
		sql.append("			 , [source].fecha ");
		sql.append("			 , [source].documentosRequeridos); ");
		UPSERT_AUDITORIA = sql.toString();

		sql = new StringBuilder();
		sql.append(" UPDATE cdiAuditoria ");
		sql.append(" SET releaseDate = GETDATE() ");
		sql.append(" 		, estatus = ").append(EstatusAuditoriaEnum.RELEASE.getId());
		sql.append(" 		, comentarios = ? ");
		sql.append(" WHERE DATEADD(day,DATEDIFF(day,0,createDate),0) = ? ");
		sql.append(" 	AND proveedor = ? ");
		sql.append(" 	AND po = ? ");
		UPDATE_SIN_MATRIZ_LIBERA = sql.toString();
		
		sql = new StringBuilder();
		sql.append(" UPDATE cdiAuditoria ");
		sql.append(" SET rejectDate = GETDATE() ");
		sql.append(" 		, estatus = ").append(EstatusAuditoriaEnum.REJECT.getId());
		sql.append(" 		, comentarios = ? ");
		sql.append(" WHERE DATEADD(day,DATEDIFF(day,0,createDate),0) = ? ");
		sql.append(" 	AND proveedor = ? ");
		sql.append(" 	AND po = ? ");
		UPDATE_SIN_MATRIZ_RECHAZA = sql.toString();
		
		sql = new StringBuilder();
		sql.append(" UPDATE cdiPriceReleaseRequest ");
		sql.append("	SET estatusAuditoria = ? ");
		sql.append("		, comentariosAuditoria = ? ");
		sql.append("		, auditDate = GETDATE() ");
		sql.append(" WHERE folio = ?");
		UPDATE_SAR = sql.toString();
		
		sql = new StringBuilder();
		sql.append("SELECT posicion ");
		sql.append("       , material ");
		sql.append("       , centro ");
		sql.append("       , cantidad ");
		sql.append("       , precioUnitario ");
		sql.append("       , fecha ");
		sql.append(" FROM   cdiAuditoria ");
		sql.append(" WHERE DATEADD(day,DATEDIFF(day,0,createDate),0) = ? ");
		sql.append(" 	AND proveedor = ? ");
		sql.append(" 	AND po = ? ");
		sql.append(" ORDER  BY posicion ASC ");
		SELECT_SIN_MATRIZ_DETALLE_PO_DATE = sql.toString();
		
		sql = new StringBuilder();
		sql.append("SELECT posicion ");
		sql.append("       , material ");
		sql.append("       , centro ");
		sql.append("       , cantidad ");
		sql.append("       , precioUnitario ");
		sql.append("       , fecha ");
		sql.append(" FROM   cdiAuditoria ");
		sql.append(" WHERE DATEADD(day,DATEDIFF(day,0,createDate),0) = ? ");
		sql.append(" 	AND proveedor = ? ");
		sql.append(" 	AND po = ? ");
		sql.append(" ORDER  BY posicion ASC ");
		SELECT_SIN_MATRIZ_DETALLE_PO_DATE_REJECT = sql.toString();
		
		sql = new StringBuilder();
		sql.append("SELECT a.createDate ");
		sql.append("		, a.po ");
		sql.append("		, a.fecha etd ");
		sql.append("		, DATEDIFF(DAY, CONVERT(smalldatetime,CAST(a.fecha AS varchar)), GETDATE()) daysLeftForEtd ");
		sql.append("		, a.proveedor ");
		sql.append("		, material ");
		sql.append("		, centro ");
		sql.append("		, DATEDIFF(DAY, CONVERT(smalldatetime,CAST(a.createDate AS varchar)), GETDATE()) daysLeftFromCreateDate ");
		sql.append(" FROM cdiAuditoria a ");
		sql.append("	INNER JOIN ( ");
		sql.append("		SELECT * ");
		sql.append("			FROM ( ");
		sql.append("				SELECT	ROW_NUMBER() OVER (PARTITION BY CONVERT(VARCHAR(8),createDate,112), po ORDER BY fecha ASC) numero_agrupado, ");
		sql.append("						id, CONVERT(VARCHAR(8),createDate,112) createDate, po, fecha ");
		sql.append("				FROM	cdiAuditoria ");
		sql.append("				WHERE	estatus = ? ");
		sql.append("				GROUP BY id, CONVERT(VARCHAR(8),createDate,112), po, fecha ");
		sql.append("			) filas_numero ");
		sql.append("			WHERE filas_numero.numero_agrupado = 1 ");
		sql.append("	) filtrados ");
		sql.append("		ON a.id = filtrados.id ");
		SELECT_SIN_MATRIZ_CABECERAS_ESTATUS = sql.toString();
		
		sql = new StringBuilder();
		sql.append("SELECT a.rejectDate logDate ");
		sql.append("		, a.createDate ");
		sql.append("		, a.po ");
		sql.append("		, a.fecha etd ");
		sql.append("		, DATEDIFF(DAY, CONVERT(smalldatetime,CAST(a.fecha AS varchar)), GETDATE()) daysLeftForEtd ");
		sql.append("		, a.proveedor ");
		sql.append("		, material ");
		sql.append("		, centro ");
		sql.append("		, DATEDIFF(DAY, CONVERT(smalldatetime,CAST(a.rejectDate AS varchar)), GETDATE()) daysLeftFromCreateDate ");
		sql.append("		, a.comentarios ");
		sql.append("		, '").append(AuditoriaHelper.TIPO_SIN_MATRIZ).append("' Tipo ");
		sql.append(" FROM cdiAuditoria a ");
		sql.append("	INNER JOIN ( ");
		sql.append("		SELECT * ");
		sql.append("			FROM ( ");
		sql.append("				SELECT	ROW_NUMBER() OVER (PARTITION BY CONVERT(VARCHAR(8),createDate,112), po ORDER BY fecha ASC) numero_agrupado, ");
		sql.append("						id, CONVERT(VARCHAR(8),createDate,112) createDate, po, fecha ");
		sql.append("				FROM	cdiAuditoria ");
		sql.append("				WHERE	estatus = ").append(EstatusAuditoriaEnum.REJECT.getId());
		sql.append("				GROUP BY id, CONVERT(VARCHAR(8),createDate,112), po, fecha ");
		sql.append("			) filas_numero ");
		sql.append("			WHERE filas_numero.numero_agrupado = 1 ");
		sql.append("	) filtrados ");
		sql.append("		ON a.id = filtrados.id ");
		sql.append(" WHEREcdiAuditoria ");
		sql.append(" UNION ALL ");
		sql.append(" SELECT ORIGEN.fechaModificacion logDate ");
		sql.append("		, ORIGEN.fechaInsert createDate ");
		sql.append("		, ORIGEN.po ");
		sql.append("		, ORIGEN.ETD ");
		sql.append("		, DATEDIFF(DAY, CONVERT(smalldatetime,CAST(ORIGEN.ETD AS varchar)), GETDATE()) daysLeftForEtd ");
		sql.append("		, ORIGEN.proveedor ");
		sql.append("		, material ");
		sql.append("		, centro ");
		sql.append("		, DATEDIFF(DAY, CONVERT(smalldatetime,CAST(ORIGEN.fechaModificacion AS varchar)), GETDATE()) daysLeftFromCreateDate ");
		sql.append("		, ORIGEN.comentario ");
		sql.append("		, '").append(AuditoriaHelper.TIPO_CON_MATRIZ).append("' Tipo ");
		sql.append(" FROM cdiControlMatrices ORIGEN ");
		sql.append("	INNER JOIN ( ");
		sql.append("		SELECT * ");
		sql.append("			FROM ( ");
		sql.append("				SELECT ROW_NUMBER() OVER ( partition BY po, CONVERT(VARCHAR(8), fechainsert, 112) ORDER BY etd ASC) numero_agrupado, ");
		sql.append("						po, posicion, etd, CONVERT(VARCHAR(8), fechainsert, 112) AS fechaInsert ");
		sql.append("				FROM   cdiControlMatrices ");
		sql.append("				WHERE  status IN ( ");
		sql.append("								SELECT id FROM cdiCatalogoControlMatrices WHERE isAuditoria = 1 AND rechazado = 1 ");
		sql.append("						) ");
		sql.append("				GROUP  BY po, posicion, etd, CONVERT(VARCHAR(8), fechainsert, 112) ");
		sql.append("			) filas_numero ");
		sql.append("			WHERE filas_numero.numero_agrupado = 1 ");
		sql.append("	) ETD_MINIMA ON ");
		sql.append(" ORIGEN.po = ETD_MINIMA.po AND ORIGEN.posicion = ETD_MINIMA.posicion AND  CONVERT(VARCHAR(8),ORIGEN.fechaInsert,112)  = ETD_MINIMA.fechaInsert ");
		sql.append(" WHEREcdiControlMatrices ");
		SELECT_REJECT_CABECERAS = sql.toString();
		
		sql = new StringBuilder();
		sql.append(" SELECT ORIGEN.fechaModificacion logDate ");
		sql.append("		, ORIGEN.fechaInsert createDate ");
		sql.append("		, ORIGEN.po ");
		sql.append("		, ORIGEN.ETD ");
		sql.append("		, DATEDIFF(DAY, CONVERT(smalldatetime,CAST(ORIGEN.ETD AS varchar)), GETDATE()) daysLeftForEtd ");
		sql.append("		, ORIGEN.proveedor ");
		sql.append("		, material ");
		sql.append("		, centro ");
		sql.append("		, DATEDIFF(DAY, CONVERT(smalldatetime,CAST(ORIGEN.fechaModificacion AS varchar)), GETDATE()) daysLeftFromCreateDate ");
		sql.append("		, ORIGEN.comentario ");
		sql.append(" FROM cdiControlMatrices ORIGEN ");
		sql.append("	INNER JOIN ( ");
		sql.append("		SELECT * ");
		sql.append("			FROM ( ");
		sql.append("				SELECT ROW_NUMBER() OVER ( partition BY po, CONVERT(VARCHAR(8), fechainsert, 112) ORDER BY etd ASC) numero_agrupado, ");
		sql.append("						po, posicion, etd, CONVERT(VARCHAR(8), fechainsert, 112) AS fechaInsert ");
		sql.append("				FROM   cdiControlMatrices ");
		sql.append("				WHERE  status = '").append(StatusControlMatricesEnum.PENDING_PRICE_UPDATE.id()).append("'");
		sql.append("				GROUP  BY po, posicion, etd, CONVERT(VARCHAR(8), fechainsert, 112) ");
		sql.append("			) filas_numero ");
		sql.append("			WHERE filas_numero.numero_agrupado = 1 ");
		sql.append("	) ETD_MINIMA ON ");
		sql.append(" ORIGEN.po = ETD_MINIMA.po AND ORIGEN.posicion = ETD_MINIMA.posicion AND  CONVERT(VARCHAR(8),ORIGEN.fechaInsert,112)  = ETD_MINIMA.fechaInsert ");
		SELECT_PPU_CABECERAS = sql.toString();
		
		sql = new StringBuilder();
		sql.append("SELECT posicion ");
		sql.append("       , material ");
		sql.append("       , centro ");
		sql.append("       , cantidad ");
		sql.append("       , precioUnitario ");
		sql.append("       , ETD fecha ");
		sql.append(" FROM   cdiControlMatrices ");
		sql.append(" WHERE DATEADD(day,DATEDIFF(day,0,fechaInsert),0) = ? ");
		sql.append(" 	AND proveedor = ? ");
		sql.append(" 	AND po = ? ");
		sql.append(" ORDER  BY posicion ASC");
		SELECT_CON_MATRIZ_DETALLE_PO_SUPPLIER_DATE = sql.toString();
		
		sql = new StringBuilder();
		sql.append("SELECT proveedor ");
		sql.append("	   , posicion ");
		sql.append("       , material ");
		sql.append("       , centro ");
		sql.append("       , cantidad ");
		sql.append("       , precioUnitario ");
		sql.append("       , ETD fecha ");
		sql.append(" FROM   cdiControlMatrices ");
		sql.append(" WHERE DATEADD(day,DATEDIFF(day,0,fechaInsert),0) = ? ");
		sql.append(" 	AND po = ? ");
		sql.append(" ORDER  BY posicion ASC");
		SELECT_CON_MATRIZ_DETALLE_DATE_PO = sql.toString();
		
		sql = new StringBuilder();
		sql.append("SELECT filtrado.updateDateMax createDate ");
		sql.append("		, r.folio ");
		sql.append("		, (CASE WHEN s.etdFinal IS NULL OR s.etdFinal < 20000101 THEN s.fechaEmbarque ELSE s.etdFinal END) etd ");
		sql.append("		, DATEDIFF(DAY, CONVERT(smalldatetime,CAST((CASE WHEN s.etdFinal IS NULL OR s.etdFinal < 20000101 ");
		sql.append("			 THEN s.fechaEmbarque ELSE s.etdFinal END) AS varchar)), GETDATE()) daysLeftForEtd ");
		sql.append("		, s.proveedor ");
		sql.append("		, filtrado.material ");
		sql.append("		, filtrado.centro ");
		sql.append("		, DATEDIFF(DAY, CONVERT(smalldatetime,CAST(filtrado.updateDateMax AS varchar)), GETDATE()) daysLeftFromCreateDate ");
		sql.append("		, comentariosAuditoria comentarios ");
		sql.append(" FROM cdiPriceReleaseRequest r ");
		sql.append("		INNER JOIN ( ");
		sql.append("				SELECT * ");
		sql.append("				FROM ( ");
		sql.append("					SELECT ROW_NUMBER() OVER ( partition BY ir.folio ORDER BY ir.folio, ir.po ASC) numero_agrupado, ");
		sql.append("							ir.folio, ir.po, ir.posicion, isd.material, isd.centro, md.updateDateMax ");
		sql.append("					FROM   cdiSARDetalle isd ");
		sql.append("							INNER JOIN cdiPriceReleaseRequest ir ");
		sql.append("								ON isd.folio = ir.folio ");
		sql.append("								AND isd.po = ir.po ");
		sql.append("								AND isd.posicion = ir.posicion ");
		sql.append("							INNER JOIN (SELECT folio, MAX(updateDate) updateDateMax ");
		sql.append("										FROM cdiPriceReleaseRequest ");
		sql.append("										WHERE updateDate IS NOT NULL GROUP BY folio) md ");
		sql.append("								ON ir.folio = md.folio ");
		sql.append("								AND ir.updateDate = md.updateDateMax ");
		sql.append("					WHERE ir.tipo = '").append(TipoPosicionEnum.PO).append("' ");
		sql.append("					GROUP  BY ir.folio, ir.po, ir.posicion, isd.material, isd.centro, md.updateDateMax ");
		sql.append("				) filas_numero ");
		sql.append("				WHERE filas_numero.numero_agrupado = 1 ");
		sql.append("		) filtrado ON r.folio = filtrado.folio ");
		sql.append("				AND r.po = filtrado.po ");
		sql.append("				AND r.posicion = filtrado.posicion ");
		sql.append("		INNER JOIN cdiSAR s ON r.folio = s.folio ");
		sql.append("				AND (CASE WHEN s.etdFinal IS NULL OR s.etdFinal < 20000101 THEN s.fechaEmbarque ELSE s.etdFinal END) > 0 ");
		sql.append("				AND (CASE WHEN s.etdFinal IS NULL OR s.etdFinal < 20000101 THEN s.fechaEmbarque ELSE s.etdFinal END) IS NOT NULL ");
		sql.append(" WHERE r.tipo = '").append(TipoPosicionEnum.PO).append("' ");
		sql.append("	AND s.preciosRevisados = 1 ");
		sql.append("	AND (s.preciosLiberados IS NULL OR s.preciosLiberados = 0) ");
		sql.append("	AND (s.preciosEnRevision IS NULL OR s.preciosEnRevision = 0) ");
		sql.append("	AND filtrado.updateDateMax IS NOT NULL ");
		SELECT_SAR_CABECERAS = sql.toString();
		
		sql = new StringBuilder();
		sql.append("SELECT r.auditDate createDate ");
		sql.append("		, r.folio ");
		sql.append("		, (CASE WHEN s.etdFinal IS NULL OR s.etdFinal < 20000101 THEN s.fechaEmbarque ELSE s.etdFinal END) etd  ");
		sql.append("		, DATEDIFF(DAY, CONVERT(smalldatetime,CAST((CASE WHEN s.etdFinal IS NULL OR s.etdFinal < 20000101  ");
		sql.append("			THEN s.fechaEmbarque ELSE s.etdFinal END) AS varchar)), GETDATE()) daysLeftForEtd ");
		sql.append("		, s.proveedor ");
		sql.append("		, filtrado.material ");
		sql.append("		, filtrado.centro ");
		sql.append("		, DATEDIFF(DAY, CONVERT(smalldatetime,CAST(r.auditDate AS varchar)), GETDATE()) daysLeftFromCreateDate ");
		sql.append("		, comentariosAuditoria comentarios ");
		sql.append(" FROM cdiPriceReleaseRequest r ");
		sql.append("		INNER JOIN ( ");
		sql.append("				SELECT * ");
		sql.append("				FROM ( ");
		sql.append("					SELECT ROW_NUMBER() OVER ( partition BY ir.folio ORDER BY ir.folio, ir.po ASC) numero_agrupado, ");
		sql.append("							ir.folio, ir.po, ir.posicion, isd.material, isd.centro ");
		sql.append("					FROM   cdiSARDetalle isd ");
		sql.append("							INNER JOIN cdiPriceReleaseRequest ir ");
		sql.append("								ON isd.folio = ir.folio ");
		sql.append("								AND isd.po = ir.po ");
		sql.append("								AND isd.posicion = ir.posicion ");
		sql.append("					WHERE ir.tipo = '").append(TipoPosicionEnum.PO).append("' ");
		sql.append("					GROUP  BY ir.folio, ir.po, ir.posicion, isd.material, isd.centro ");
		sql.append("				) filas_numero ");
		sql.append("				WHERE filas_numero.numero_agrupado = 1 ");
		sql.append("		) filtrado ON r.folio = filtrado.folio ");
		sql.append("				AND r.po = filtrado.po ");
		sql.append("				AND r.posicion = filtrado.posicion ");
		sql.append("		INNER JOIN cdiSAR s ON r.folio = s.folio ");
		sql.append("				AND (CASE WHEN s.etdFinal IS NULL OR s.etdFinal < 20000101 THEN s.fechaEmbarque ELSE s.etdFinal END) > 0 ");
		sql.append("				AND (CASE WHEN s.etdFinal IS NULL OR s.etdFinal < 20000101 THEN s.fechaEmbarque ELSE s.etdFinal END) IS NOT NULL ");
		sql.append(" WHERE r.tipo = '").append(TipoPosicionEnum.PO).append("' ");
		sql.append("	AND r.estatusAuditoria = ? ");
		SELECT_SAR_CABECERAS_ESTATUS = sql.toString();
		
		sql = new StringBuilder();
		sql.append("SELECT r.po ");
		sql.append("       , r.posicion ");
		sql.append("       , d.material ");
		sql.append("       , d.centro ");
		sql.append("       , r.cantidad ");
		sql.append("       , d.precioUnitario ");
		sql.append("       , (CASE WHEN s.etdFinal IS NULL OR s.etdFinal < 20000101 THEN s.fechaEmbarque ELSE s.etdFinal END) fecha ");
		sql.append(" FROM   cdiPriceReleaseRequest r ");
		sql.append("       INNER JOIN cdiSAR s ");
		sql.append("               ON r.folio = s.folio ");
		sql.append("       INNER JOIN cdiSARDetalle d ");
		sql.append("               ON r.folio = d.folio ");
		sql.append("                  AND r.po = d.po ");
		sql.append("                  AND r.posicion = d.posicion ");
		sql.append(" WHERE r.tipo = '").append(TipoPosicionEnum.PO).append("' ");
		sql.append("       AND r.folio = ? ");
		sql.append(" ORDER  BY r.po ");
		sql.append("          , r.posicion");
		SELECT_SAR_DETALLE_FOLIO = sql.toString();
	}
	
	public static String getSelectSarCabeceras(BeanFiltroAuditoriaVista filtro) {
		StringBuffer query;
		if (filtro == null || filtro.getEstatus() == null) {
			query = new StringBuffer(SELECT_SAR_CABECERAS);
			query.append(" AND r.estatusAuditoria IS NULL ");
		} else {
			query = new StringBuffer(SELECT_SAR_CABECERAS_ESTATUS);
		}
		if( filtro != null ) {
			if (filtro.getFolio() != null && filtro.getFolio() > 0) {
				query.append("	AND r.folio = ? ");
			}
			if (UtilsString.isStringValida(filtro.getProveedor())) {
				query.append("	AND s.proveedor = ? ");
			}
			if (UtilsString.isStringValida(filtro.getPo())) {
				query.append("	AND r.po = ? ");
			}
		}
		if (filtro == null || filtro.getEstatus() == null) {
			query.append(" ORDER BY filtrado.updateDateMax, r.folio");
		} else {
			query.append(" ORDER BY r.auditDate, r.folio");
		}
		return query.toString();
	}
	
	public static String getSelectSinMatrizCabeceras(BeanFiltroAuditoriaVista filtro) {
		StringBuffer query = new StringBuffer(SELECT_SIN_MATRIZ_CABECERAS_ESTATUS);
		if (filtro != null) {
			boolean where = false;
			if(UtilsString.isStringValida(filtro.getProveedor())) {
				query.append(" WHERE a.proveedor = ?");
				where = true;
			}
			if(UtilsString.isStringValida(filtro.getPo())) {
				if(where) {
					query.append(" AND ");
				} else {
					query.append(" WHERE ");
				}
				query.append(" a.po = ? ");
			}
		}
		query.append(" ORDER BY a.createDate ASC, a.po ASC");
		return query.toString();
	}
	
	public static String getSelectPpuCabeceras(BeanFiltroAuditoriaVista filtro) {
		StringBuffer query = new StringBuffer(SELECT_PPU_CABECERAS);
		if (filtro != null) {
			boolean where = false;
			if(UtilsString.isStringValida(filtro.getProveedor())) {
				query.append(" WHERE ORIGEN.proveedor = ?");
				where = true;
			}
			if(UtilsString.isStringValida(filtro.getPo())) {
				if(where) {
					query.append(" AND ");
				} else {
					query.append(" WHERE ");
				}
				query.append(" ORIGEN.po = ? ");
			}
		}
		query.append(" ORDER BY logDate ASC, po ASC");
		return query.toString();
	}
	
	public static String getSelectRejectCabeceras(BeanFiltroAuditoriaVista filtro) {
		StringBuffer query = new StringBuffer(SELECT_REJECT_CABECERAS);
		StringBuffer whereAuditoria = new StringBuffer();
		StringBuffer whereMatriz = new StringBuffer();
		if (filtro != null) {
			boolean where = false;
			if (UtilsString.isStringValida(filtro.getProveedor())) {
				whereAuditoria.append(" WHERE a.proveedor = ? ");
				where = true;
			}
			if (UtilsString.isStringValida(filtro.getPo())) {
				if (where) {
					whereAuditoria.append(" AND ");
				} else {
					whereAuditoria.append(" WHERE ");
				}
				whereAuditoria.append(" a.po = ? ");
			}
			where = false;
			if (UtilsString.isStringValida(filtro.getProveedor())) {
				whereMatriz.append(" WHERE ORIGEN.proveedor = ? ");
				where = true;
			}
			if (UtilsString.isStringValida(filtro.getPo())) {
				if (where) {
					whereMatriz.append(" AND ");
				} else {
					whereMatriz.append(" WHERE ");
				}
				whereMatriz.append(" ORIGEN.po = ? ");
			}
		}
		query = new StringBuffer(query.toString().replace("WHEREcdiAuditoria", whereAuditoria));
		query = new StringBuffer(query.toString().replace("WHEREcdiControlMatrices", whereMatriz));
		query.append(" ORDER BY logDate ASC, po ASC");
		return query.toString();
	}
	
}
