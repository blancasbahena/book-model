package com.srm.pli.bo;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Arrays;
import java.util.List;

import com.srm.pli.dao.DocumentosDao;
import com.srm.pli.utils.FuncionesComunesPLI;
import com.srm.pli.utils.GeneraDocumentos;
import com.srm.pli.utils.PropertiesDb;
import com.truper.businessEntity.BeanLetoniano;
import com.truper.businessEntity.ProductoBean;

import lombok.extern.log4j.Log4j2;

@Log4j2
public class SarDetalleJasper {

	private String folio;
	private String po;
	private String marca;
	private String codigo;
	private String clave;
	private String descripcion;
	private int cantidad;
	private String unidad;
	private String precioUnitario;
	private BigDecimal totalLinea;
	// Informacion para acomodar lineas en vista
	private String condicionDePago;
	private boolean otros;
	private String poOther;
	private String poDescripcion;
	private String datosConcatenados;
	private Integer material;
	private static String BLANK = "";
	private BeanLetoniano idioma = new BeanLetoniano();
	private String descripcionComplementoFactura;

	public String getDescripcionComplementoFactura() {
		return descripcionComplementoFactura;
	}

	public void setDescripcionComplementoFactura(String descripcionComplementoFactura) {
		this.descripcionComplementoFactura = descripcionComplementoFactura;
	}

	// constructor simple
	public SarDetalleJasper() {

	}

	// constructor
	public SarDetalleJasper(SarDetalleBO obj,boolean otros) {
		this.otros = otros;
		this.condicionDePago = obj.getCondicionPago();
		this.codigo = isNull(obj.getMaterial());
		this.cantidad = (obj.getCantidadUnidadMedida() == null || obj.getCantidadUnidadMedida().compareTo(BigDecimal.ZERO)== 0 )?obj.getCantidad():obj.getCantidadUnidadMedida().intValue();
		this.folio = isNull(obj.getFolio());
		this.po = obj.getPo();
		this.precioUnitario = isNull(obj.getPrecioUnitario());
		this.unidad = isNull(obj.getUnidaMedida());
		BigDecimal cantidadB = new BigDecimal(this.cantidad);
		BigDecimal precioUnitB = obj.getPrecioUnitario();
		this.totalLinea = cantidadB.multiply(precioUnitB).setScale(6, RoundingMode.HALF_UP);
		ProductoBean p = FuncionesComunesPLI.productos.get((obj.getMaterial() != null ? obj.getMaterial().toString() : "" ));
		DocumentosDao dao = new DocumentosDao();

		List<String> OTHERS_ITEMS = Arrays.asList(PropertiesDb.getInstance().getStringTrim("cargaImportData.othersItems").split(","));
		if(p != null) {
			this.clave = p.getClave();
			this.descripcion = p.getDescripcion();
			this.marca = p.getMarcaComercial() != null ? p.getMarcaComercial() : BLANK;
		}else {
			this.clave = BLANK;
			this.descripcion = BLANK;
			this.marca = BLANK;
		}
		if(otros) {
			this.po = isNull(obj.getPoOtherItem());
			this.setPoOther(GeneraDocumentos.PO_OTROS);
			this.setPoDescripcion(obj.getPo());
			this.setDescripcion(obj.getDescripcion() + " "+ (obj.getDescripcionComplementoFactura() == null ? "" : obj.getDescripcionComplementoFactura()));
			this.setDatosConcatenados(dameDatosConcatenados());
		}
		this.material =  obj.getMaterial();
		if(p!=null) {
			if(p.isMateriaPrima() || OTHERS_ITEMS.contains(obj.getMaterial().toString())){
				idioma = dao.consultaHebreo(obj.getMaterial());
				log.info("Descripcion ZMP es: {}",idioma.getDescripcion());
				if(idioma.getItem()!=null)
					this.setDescripcion(idioma.getDescripcion() + " "+ ( obj.getDescripcionComplementoFactura() == null ? "" : obj.getDescripcionComplementoFactura()));
			}else{
		    idioma = dao.consultaLetoniano(obj.getMaterial());
				log.info("Descripcion ZCOM es: {}",idioma.getDescripcion());
				if(idioma.getItem()!=null)
					this.setDescripcion(idioma.getDescripcion() + " "+ ( obj.getDescripcionComplementoFactura() == null ? "" : obj.getDescripcionComplementoFactura()));
			}
		}else {
			if(obj.getMaterial()!=null) {
				idioma = dao.consultaLetoniano(obj.getMaterial());
				log.info("Descripcion ZCOM es: {}",idioma.getDescripcion());
				if(idioma.getItem()!=null) {
					this.setDescripcion(idioma.getDescripcion() + " "+ ( obj.getDescripcionComplementoFactura() == null ? "" : obj.getDescripcionComplementoFactura()));
				}		
			}
		}
	}

	/**
	 * Genera la concatenacion para llenar la variable y esa usarla en el Jasper
	 * para PDF
	 * 
	 * @return
	 */
	public String dameDatosConcatenados() {
		StringBuffer buff = new StringBuffer();
		buff.append((getPo() != null ? getPo() : ""));
		buff.append("   ");
		buff.append((getPoDescripcion() != null ? getPoDescripcion() : ""));
		buff.append("   ");
		buff.append((getDescripcion() != null ? getDescripcion() : ""));
		return buff.toString();
	}

	public String isNull(Object obj) {
		return obj != null ? obj.toString() : BLANK;
	}

	public String getFolio() {
		return folio;
	}

	public void setFolio(String folio) {
		this.folio = folio;
	}

	public String getPo() {
		return po;
	}

	public void setPo(String po) {
		this.po = po;
	}

	public String getMarca() {
		return marca;
	}

	public void setMarca(String marca) {
		this.marca = marca;
	}

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public String getClave() {
		return clave;
	}

	public void setClave(String clave) {
		this.clave = clave;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public String getUnidad() {
		return unidad;
	}

	public void setUnidad(String unidad) {
		this.unidad = unidad;
	}

	public String getPrecioUnitario() {
		return precioUnitario;
	}

	public void setPrecioUnitario(String precioUnitario) {
		this.precioUnitario = precioUnitario;
	}

	public String getCondicionDePago() {
		return condicionDePago;
	}

	public void setCondicionDePago(String condicionDePago) {
		this.condicionDePago = condicionDePago;
	}

	public boolean isOtros() {
		return otros;
	}

	public void setOtros(boolean otros) {
		this.otros = otros;
	}

	public String getPoOther() {
		return poOther;
	}

	public void setPoOther(String poOther) {
		this.poOther = poOther;
	}

	public String getPoDescripcion() {
		return poDescripcion;
	}

	public void setPoDescripcion(String poDescripcion) {
		this.poDescripcion = poDescripcion;
	}

	public String getDatosConcatenados() {
		return datosConcatenados;
	}

	public void setDatosConcatenados(String datosConcatenados) {
		this.datosConcatenados = datosConcatenados;
	}

	public int getCantidad() {
		return cantidad;
	}

	public void setCantidad(int cantidad) {
		this.cantidad = cantidad;
	}

	public BigDecimal getTotalLinea() {
		return totalLinea;
	}

	public void setTotalLinea(BigDecimal totalLinea) {
		this.totalLinea = totalLinea;
	}

	public Integer getMaterial() {
		return material;
	}

	public void setMaterial(Integer material) {
		this.material = material;
	}

}
