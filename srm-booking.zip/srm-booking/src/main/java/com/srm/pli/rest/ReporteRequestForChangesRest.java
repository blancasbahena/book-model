package com.srm.pli.rest;

import java.io.File;
import java.util.List;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;
import com.srm.pli.bo.ReporteRequestForChanges;
import com.srm.pli.enums.Mensajes;
import com.srm.pli.services.impl.ReporteRequestForChangesServiceImpl;
import com.srm.pli.utils.PropertiesDb;
import com.srm.pli.utils.UtilsExcel;
import com.srm.pli.ws.vo.ResponseRequestchangesVO;
import com.sun.jersey.multipart.FormDataParam;
import com.truper.infra.rs.BaseRS;


@Path("/reporte")
public class ReporteRequestForChangesRest extends BaseRS
{
	private static final long serialVersionUID = 1L;
	
	@POST
	@Path("/consultar/fechas")
	@Consumes({MediaType.MULTIPART_FORM_DATA})
	@Produces("application/vnd.ms-excel")
	public Response consultarReporteByDates(@FormDataParam("fechaInicio") String fechaInicio, @FormDataParam("fechaFin") String fechaFin) 
	{
		log.info("Inicio Ws::Entrando al Ws que obtiene el reporte por fechas");
		ResponseRequestchangesVO responseVO = new ResponseRequestchangesVO();
		Response response = null;
		
		try 
		{
			String nombreExcel = PropertiesDb.getInstance().getString("nombre.archivo.booking.request.changes");
			String pathReportesExcel = PropertiesDb.getInstance().getString("path.reportes.booking.request.changes");
			
			String[] nombreExcelSinExt = nombreExcel.split("\\.");
			List<ReporteRequestForChanges> reporteRequestForChanges = ReporteRequestForChangesServiceImpl.getInstance().getReporte(fechaInicio, fechaFin);			
			File file = UtilsExcel.generaReporteExcelRequestChanges(reporteRequestForChanges, nombreExcel, nombreExcelSinExt[0], pathReportesExcel);
			if(!reporteRequestForChanges.isEmpty())
			{
				ResponseBuilder responseBuilder = Response.ok((Object) file);
				responseBuilder.header("Content-Disposition", "attachment; filename=" + nombreExcel + "");
				return responseBuilder.build();
			}
			else
			{
				responseVO.setTipoMensaje(Mensajes.TIPO_WARNING.getMensaje());
				responseVO.setMensaje(Mensajes.MSG_WARNING.getMensaje());
				response = Response.status(300).build();
			}
		} 
		catch (Exception e) 
		{
			log.error("Hubo un error al obtener los datos para el reporte con fechas {} - {}, Exception: {}", fechaInicio, fechaFin, e.getMessage());
			responseVO.setTipoMensaje(Mensajes.TIPO_ERROR.getMensaje());
			responseVO.setMensaje(Mensajes.MSG_ERROR.getMensaje());
			response = buildErrorResponse(responseVO);
		}
		log.info("Fin Ws::Se termino de ejecutar el Ws que obtiene el reporte por fechas");
		
		return response;
	}
}
