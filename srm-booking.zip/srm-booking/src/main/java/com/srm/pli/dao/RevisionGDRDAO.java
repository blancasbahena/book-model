package com.srm.pli.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.srm.pli.constants.ConsultasConstants;
import com.srm.pli.db.ConexionDB;
import com.truper.businessEntity.RevisionGDR;

public class RevisionGDRDAO extends DAO {

	private static final long serialVersionUID = -5731462760867699671L;

	@Override
	public List<?> select(Object o) {
		RevisionGDR gdr = (RevisionGDR) o;
		List<RevisionGDR> revisiones = new ArrayList<RevisionGDR>();

		DAOUtils utils = new DAOUtils();
		Connection con = null;
		PreparedStatement pst = null;
		ResultSet rs = null;

		StringBuilder select = new StringBuilder();

		select.append("SELECT idRevisionGDR, folio, fechaGDRActual, fechaGDRModificada, ");
		select.append("fechaETDActual, fechaETDModificada, activo, diferenciaDiasETD ");
		select.append("FROM cdiRevisionGDR WHERE 1 = 1");

		utils.setSelect(true);

		try {
			con = ConexionDB.dameConexion();
			if (gdr.getFolio() != null)
				select.append(utils.ajustaColumna(" AND folio = ?"));
			if (gdr.getFechaGDRActual() != null)
				select.append(utils.ajustaColumna(" AND fechaGDRActual = ?"));
			if (gdr.getFechaGDRModificada() != null)
				select.append(utils.ajustaColumna(" AND fechaGDRModificada = ?"));
			if (gdr.getFechaETDActual() != null)
				select.append(utils.ajustaColumna(" AND fechaETDActual = ?"));
			if (gdr.getFechaETDModificada() != null)
				select.append(utils.ajustaColumna(" AND fechaETDModificada = ?"));
			if (gdr.getActivo() != null)
				select.append(utils.ajustaColumna(" AND activo = ?"));
			if (gdr.getDiferenciaDiasETD() != null)
			select.append(utils.ajustaColumna(" AND diferenciaDiasETD = ?"));
			
			pst = con.prepareStatement(select.toString());
			int cont = 1;
			utils.inicializaQuery(select.toString());

			if (gdr.getFolio() != null)
				utils.ajustaParametro(cont++, pst, gdr.getFolio(), Integer.class);
			if (gdr.getFechaGDRActual() != null)
				utils.ajustaParametro(cont++, pst, gdr.getFechaGDRActual(), Integer.class);
			if (gdr.getFechaGDRModificada() != null)
				utils.ajustaParametro(cont++, pst, gdr.getFechaGDRModificada(), Integer.class);
			if (gdr.getFechaETDActual() != null)
				utils.ajustaParametro(cont++, pst, gdr.getFechaETDActual(), Integer.class);
			if (gdr.getFechaETDModificada() != null)
				utils.ajustaParametro(cont++, pst, gdr.getFechaETDModificada(), Integer.class);
			if (gdr.getActivo() != null)
				utils.ajustaParametro(cont++, pst, gdr.getActivo(), Boolean.class);
			if (gdr.getDiferenciaDiasETD() != null)
				utils.ajustaParametro(cont++, pst, gdr.getDiferenciaDiasETD(), Integer.class);

			rs = pst.executeQuery();

			while (rs.next()) {
				RevisionGDR temp = new RevisionGDR();
				temp.setIdRevisionGDR(rs.getInt("idRevisionGDR"));
				temp.setFolio(rs.getInt("folio"));
				temp.setFechaGDRActual(rs.getInt("fechaGDRActual"));
				temp.setFechaGDRModificada(rs.getInt("fechaGDRModificada"));
				temp.setFechaETDActual(rs.getInt("fechaETDActual"));
				temp.setFechaETDModificada(rs.getInt("fechaETDModificada"));
				temp.setActivo(rs.getBoolean("activo"));
				temp.setDiferenciaDiasETD(rs.getInt("diferenciaDiasETD"));
				revisiones.add(temp);
			}

		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				BOOKING_LOGGER.error(ex.getMessage(), ex);
			}
			BOOKING_LOGGER.error(e.getMessage(), e);
		} catch (Exception e) {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				BOOKING_LOGGER.error(ex.getMessage(), ex);
			}
			BOOKING_LOGGER.error(e.getMessage(), e);
		} finally {
			try {
				rs.close();
				pst.close();
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				BOOKING_LOGGER.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
		return revisiones;
	}

	@Override
	public boolean insert(Object o) {
		RevisionGDR sar = (RevisionGDR) o;
		Connection con = null;
		PreparedStatement pst = null;
		DAOUtils utilDao = new DAOUtils();

		StringBuilder insert = ConsultasConstants.INSERT_REVISION_GDR;

		boolean exito = false;

		try {
			con = ConexionDB.dameConexion();
			pst = con.prepareStatement(insert.toString());
			int cont = 1;
			utilDao.ajustaParametro(cont++, pst, sar.getFolio(), Integer.class);
			utilDao.ajustaParametro(cont++, pst, sar.getFechaGDRActual(), Integer.class);
			utilDao.ajustaParametro(cont++, pst, sar.getFechaGDRModificada(), Integer.class);
			utilDao.ajustaParametro(cont++, pst, sar.getFechaETDActual(), Integer.class);
			utilDao.ajustaParametro(cont++, pst, sar.getFechaETDModificada(), Integer.class);
			utilDao.ajustaParametro(cont++, pst, sar.getDiferenciaDiasETD(), Integer.class);

			utilDao.inicializaQuery(insert.toString());

			exito = pst.executeUpdate() > 0;
			ConexionDB.devuelveConexion(con);
		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				BOOKING_LOGGER.error(ex.getMessage(), ex);
			}
			BOOKING_LOGGER.error(e.getMessage(), e);
		} catch (Exception e) {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				BOOKING_LOGGER.error(ex.getMessage(), ex);
			}
			BOOKING_LOGGER.error(e.getMessage(), e);
		} finally {
			try {
				pst.close();
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				BOOKING_LOGGER.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
		return exito;
	}

	@Override
	public boolean update(Object o) {
		RevisionGDR revision = (RevisionGDR) o;
		Connection con = null;
		PreparedStatement pst = null;

		StringBuilder update = new StringBuilder();
		update.append("UPDATE cdiRevisionGDR SET ");

		DAOUtils utils = new  DAOUtils();
		boolean exito = false;

		try {
			con = ConexionDB.dameConexion();
			if (revision.getActivo() != null)
				update.append(utils.ajustaColumna(" activo = ?"));
			update.append(" WHERE folio = ?");

			int cont = 1;
			pst = con.prepareStatement(update.toString());
			
			utils.inicializaQuery(update.toString());

			if (revision.getActivo() != null) 
				agregarPs(cont++, pst, revision.getActivo(), Boolean.class);

			agregarPs(cont++, pst, revision.getFolio(), Integer.class);

			int resultado = pst.executeUpdate();
			exito = resultado > 0;
			pst.close();

			ConexionDB.devuelveConexion(con);

		} catch (Exception e) {
			try {
				pst.close();
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				BOOKING_LOGGER.error(ex.getMessage(), ex);
			}
			BOOKING_LOGGER.error(e.getMessage(), e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				BOOKING_LOGGER.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
		return exito;
	}

}
