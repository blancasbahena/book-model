package com.srm.pli.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.srm.pli.bo.BeanSarConfirmacionFinal;
import com.srm.pli.db.ConexionDB;
import com.truper.utils.date.UtilsFechas;
import com.truper.utils.string.UtilsString;

public class ReporteSarDao {

	public static final Logger log = LogManager.getRootLogger();

	private static ReporteSarDao instance = null;

	private ReporteSarDao() {
	}

	public static ReporteSarDao getInstance() {
		if (instance == null)
			instance = new ReporteSarDao();
		return instance;
	}

	public List<BeanSarConfirmacionFinal> getSarsConfirmacionFinal(Date fechaInicial, Date fechaFinal) {
		List<BeanSarConfirmacionFinal> respuesta = null;
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();
			String sql = getQuerySarsConfirmacionFinal();
			try (PreparedStatement pst = con.prepareStatement(sql)) {
				pst.setDate(1, UtilsFechas.setConvierteFechaToSQLDate(fechaInicial));
				pst.setDate(2, UtilsFechas.setConvierteFechaToSQLDate(fechaFinal));
				try (ResultSet rs = pst.executeQuery()) {
					respuesta = new ArrayList<>();
					BeanSarConfirmacionFinal i;
					while (rs.next()) {
						i = getBeanSarConfirmacionFinal(rs);
						respuesta.add(i);
					}
				}
			}
		} catch (SQLException sqle) {
			log.error("Valores {} {}", fechaInicial, fechaFinal, sqle);
			ConexionDB.renovar(con);
		} catch (Exception e) {
			log.error("Valores {} {}", fechaInicial, fechaFinal, e);
		} finally {
			ConexionDB.devolver(con);
		}
		return respuesta;
	}

	/**
	 * @param rs
	 * @return
	 * @throws SQLException
	 */
	private BeanSarConfirmacionFinal getBeanSarConfirmacionFinal(ResultSet rs) throws SQLException {
		if (rs == null)
			return null;
		BeanSarConfirmacionFinal i;
		Integer folio = getInteger(rs, "folio");
		Integer status = getInteger(rs, "status");
		Boolean aereo = getBooleanNull(rs, "esAereo");
		Boolean consolidado = getBooleanNull(rs, "consolidado");
		String folioConsolidado = rs.getString("folioConsolidado");
		String confirmador = rs.getString("usuarioApruebaPlanning");
		String proveedor = rs.getString("proveedor");
		Date etd = rs.getDate("etd");
		String puertoOrigen = rs.getString("puertoSalida");
		Integer tipoContenedor = getInteger(rs, "tipoContenedor");
		String numeroContenedorBooking = rs.getString("contenedor");
		String numeroContenedorProveedor = rs.getString("contenedorProveedor");
		i = new BeanSarConfirmacionFinal();
		i.setFolio(folio);
		i.setStatus(status);
		i.setAereo(aereo);
		i.setConsolidado(consolidado);
		i.setFolioConsolidado(folioConsolidado);
		i.setConfirmador(confirmador);
		i.setProveedor(proveedor);
		i.setEtd(etd);
		i.setPuertoOrigen(puertoOrigen);
		i.setTipoContenedor(tipoContenedor);
		i.setNumeroContenedorBooking(numeroContenedorBooking);
		i.setNumeroContenedorProveedor(numeroContenedorProveedor);
		return i;
	}

	public String getQuerySarsConfirmacionFinal() {
		StringBuffer sql = new StringBuffer();
		sql.append("SELECT folio ");
		sql.append("       , status ");
		sql.append("       , esAereo ");
		sql.append("       , consolidado ");
		sql.append("       , folioConsolidado ");
		sql.append("       , usuarioApruebaPlanning ");
		sql.append("       , proveedor ");
		sql.append("       , dbo.Inttodatetime(( CASE ");
		sql.append("                               WHEN etdFinal IS NULL ");
		sql.append("                                     OR etdFinal < 20000101 THEN fechaEmbarque ");
		sql.append("                               ELSE etdFinal ");
		sql.append("                             END ), DEFAULT) etd ");
		sql.append("       , puertoSalida ");
		sql.append("       , tipoContenedor ");
		sql.append("       , contenedor ");
		sql.append("       , contenedorProveedor ");
		sql.append("FROM   cdisar ");
		sql.append("WHERE  fechaConfirmacionFinal BETWEEN ? AND ?");
		return sql.toString();
	}

	/**
	 * Metodo que retorna null cuando sea nulo el valor.
	 * 
	 * @param rs
	 * @param field
	 * @return {@link Integer}
	 * @throws SQLException
	 */
	private Integer getInteger(ResultSet rs, String field) throws SQLException {
		if (rs == null || !UtilsString.isStringValida(field))
			return null;
		Integer v = rs.getInt(field);
		if (rs.wasNull())
			return null;
		return v;
	}

	/**
	 * Metodo que retorna null cuando sea nulo el valor.
	 * 
	 * @param rs
	 * @param field
	 * @return {@link Boolean}
	 * @throws SQLException
	 */
	private Boolean getBooleanNull(ResultSet rs, String field) throws SQLException {
		if (rs == null || !UtilsString.isStringValida(field))
			return null;
		Boolean v = rs.getBoolean(field);
		if (rs.wasNull())
			return null;
		return v;
	}
}
