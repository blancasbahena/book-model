package com.srm.pli.enums;

import com.truper.utils.string.UtilsString;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.ToString;

@Getter
@AllArgsConstructor
@ToString
public enum TipoBlEnum {

	SWB("SWB"), TELEX("TELEX"), IMPRESION_EN_DESTINO("OBL AT DESTINATION"), ORIGINAL_BL("ORIGINAL (BL)"),
	ORIGINAL_CO("ORIGINAL (CO)");

	private String value;

	public static TipoBlEnum getValueOf(String value) {
		if (!UtilsString.isStringValida(value))
			return null;
		for (TipoBlEnum v : TipoBlEnum.values()) {
			if (v.getValue().equals(value)) {
				return v;
			}
		}
		return null;
	}
}