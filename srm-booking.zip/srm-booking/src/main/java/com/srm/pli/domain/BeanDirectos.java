package com.srm.pli.domain;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class BeanDirectos implements Serializable {

	private static final long serialVersionUID = -547151038430959270L;
	private String booking;
	private int folio;
	private String almacen;
	private String centro;
	private boolean isPedidoDirecto;
}
