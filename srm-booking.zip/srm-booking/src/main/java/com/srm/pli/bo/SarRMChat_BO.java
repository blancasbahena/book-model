package com.srm.pli.bo;

import java.io.Serializable;
import java.sql.Timestamp;

import com.truper.businessEntity.UserBean;

import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
public class SarRMChat_BO implements Serializable {

	private static final long serialVersionUID = -7663309896234437963L;
	
	private String folio;
	private UserBean user;
	private String comment;
	private Timestamp create_date;
	private String commentType;
}
