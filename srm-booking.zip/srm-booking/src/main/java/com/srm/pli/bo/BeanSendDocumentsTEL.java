package com.srm.pli.bo;

import java.io.Serializable;
import java.util.List;

import lombok.Data;

@Data
public class BeanSendDocumentsTEL implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7061195027434396942L;
	
	private Integer folio;
	private boolean aprobado;
	private String contenedor;
	private String booking;
	private String numeroFactura;
	private List<SarDetalleBO> detalles;

}
