package com.srm.pli.helper;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import com.srm.pli.utils.FuncionesWebservises;
import com.truper.businessEntity.BeanDetalleOrdenMaterial;
import com.truper.businessEntity.UpdateDataDetail;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class DetailHelper {

	private static DetailHelper instance = null;

	private DetailHelper() {
	}

	public static DetailHelper getInstance() {
		if (instance == null)
			instance = new DetailHelper();
		return instance;
	}

	/**
	 * Regresa si estamos hablando del mismo reigstro y si debo actualizar en tablas
	 * 
	 * @return
	 */
	private boolean deboActualizar(BeanDetalleOrdenMaterial det, UpdateDataDetail data) {
		if (det.getNumeroOrden().trim().equals(data.getPo().trim())) {
			if (det.getPosicion().equals(data.getPosition().toString())) {
				// hasta aqui es el mismo registro pero voy a ver si tienen diferecias
				BigDecimal precioUnitario = det.getPrecioUnitario().setScale(6, BigDecimal.ROUND_FLOOR);

				if (precioUnitario.compareTo(data.getUnitPrice()) != 0) {
					return true;
				}
				if (!det.getMoneda().equals(data.getMoneda())) {
					return true;
				}
				if (!det.getCondicionPago().equals(data.getCondPago())) {
					return true;
				}
			}
		}
		return false;
	}

	private UpdateDataDetail creaObjetoParaActualizar(BeanDetalleOrdenMaterial det, UpdateDataDetail data) {
		UpdateDataDetail nuevo = new UpdateDataDetail();
		nuevo.setCentro(det.getCentro());
		nuevo.setPo(det.getNumeroOrden().trim());
		nuevo.setPosition(Integer.parseInt(det.getPosicion()));
		nuevo.setCondPago(det.getCondicionPago());
		nuevo.setCondPagoOld(data.getCondPago());
		nuevo.setMoneda(det.getMoneda());
		nuevo.setMonedaOld(data.getMoneda());
		nuevo.setUnitPrice(det.getPrecioUnitario().setScale(6, BigDecimal.ROUND_FLOOR));
		nuevo.setUnitPriceOld(data.getUnitPrice());
		nuevo.setMaterial(data.getMaterial());
		nuevo.setFolio(data.getFolio());
		return nuevo;
	}

	/**
	 * Regresa el objeto a comparar
	 * 
	 * @param detalles
	 * @param bo
	 * @return
	 */
	private UpdateDataDetail objetoAComparar(BeanDetalleOrdenMaterial det,
			Map<String, List<UpdateDataDetail>> datosTablas) {
		UpdateDataDetail result = null;
		List<UpdateDataDetail> listaTemp = datosTablas.get(det.getNumeroOrden().trim());
		if (listaTemp != null && !listaTemp.isEmpty()) {
			for (UpdateDataDetail data : listaTemp) {
				if (deboActualizar(det, data)) {
					result = creaObjetoParaActualizar(det, data);
				}
			}
		}
		return result;
	}

	/**
	 * 
	 * @param datosTablas--- consulta pos query a tablas es lo que esta grabado en
	 *                       el detalle
	 * @return
	 * @throws Exception
	 */
	public List<UpdateDataDetail> regresaRegistrosAActualizar(Map<String, List<UpdateDataDetail>> datosTablas)
			throws Exception {
		log.info("[regresaRegistrosAActualizar] Inicio ");
		List<UpdateDataDetail> nuevaLista = new ArrayList<>();
		Set<String> posParaPedirEnTEL = new HashSet<>();
		for (Entry<String, List<UpdateDataDetail>> entry : datosTablas.entrySet()) {
			posParaPedirEnTEL.add(entry.getKey().trim());
		}
		Map<String, List<BeanDetalleOrdenMaterial>> mapaTelActualizado = FuncionesWebservises
				.getDetalleOrdenMaterial(posParaPedirEnTEL);
		if (mapaTelActualizado == null) {
			return nuevaLista;
		}
		for (Entry<String, List<UpdateDataDetail>> entry : datosTablas.entrySet()) {
			String poTEL = entry.getKey();
			if (poTEL != null) {
				List<BeanDetalleOrdenMaterial> listaDet = mapaTelActualizado.get(poTEL);
				if (listaDet != null) {
					for (BeanDetalleOrdenMaterial bean : listaDet) {
						UpdateDataDetail objEnTablasFR = objetoAComparar(bean, datosTablas);
						if (objEnTablasFR != null) {
							nuevaLista.add(objEnTablasFR);
						}
					}
				}
			}
		}

		log.info("[regresaRegistrosAActualizar] Fin ");
		return nuevaLista;
	}

}