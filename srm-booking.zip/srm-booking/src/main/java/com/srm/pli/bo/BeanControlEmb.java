package com.srm.pli.bo;

import lombok.Data;

@Data
public class BeanControlEmb {
	
	private String statusDoc;
	private String naviera;
	private String etd;
	private String eta;
	private String contenedor;
	private String booking;
	private String unidadNegocio;
	private String folio;
	private String proovedor;
	
	private String invFabrica;
	private String facturaPm;
	private String fechaCargaDoc;
	private String sdiAnalist;
	private int total;
	
}
