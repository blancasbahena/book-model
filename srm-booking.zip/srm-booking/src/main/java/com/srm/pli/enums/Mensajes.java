package com.srm.pli.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum Mensajes
{
	TIPO_EXITO("S"),
	TIPO_WARNING("W"),
	TIPO_ERROR("E"),
	MSG_ERROR("Hubo un error al ejecutar la Operacion."),
	MSG_EXITO("Proceso ejecutado correctamente."),
	MSG_WARNING("No se encontraron resultados."),
	MSG_ERROR_SAVE_IN_TABLE("Hubo un error al tratar de guardar el registro."),
	MSG_WARNING_NOT_FOUND_MESSAGES("No se encontraron mensajes.");

	private String mensaje;
}
