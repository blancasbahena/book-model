package com.srm.pli.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.srm.fungandrui.facturacion.models.ReporteSemanalIncidencias;
import com.srm.fungandrui.facturacion.queries.QueriresFacturacionSQL;
import com.srm.pli.db.ConexionDB;

public class ReporteIncidenciaDAO  extends DAO{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final Logger log = LogManager.getRootLogger();

	@Override
	public List<?> select(Object o) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean insert(Object o) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean update(Object o) {
		// TODO Auto-generated method stub
		return false;
	}

	
	public static List<ReporteSemanalIncidencias> getReporteSemanalIncidencias() {
		
		List<ReporteSemanalIncidencias> listReporteSemanalIncidencias = new ArrayList<ReporteSemanalIncidencias>();
		Connection conn = null;
		Calendar c = Calendar.getInstance();
		
		System.out.println( formatearCalendar(c));
		String fechaTemp = c.toString();
		 c.add(Calendar.DAY_OF_YEAR, -6);
		 
		System.out.println( formatearCalendar(c));
		String fechaTemp2 = c.toString();
		
		String SQL_LISTA_FACTURACION_REPORTE = new StringBuilder
				( "SELECT IFA.id_incidencia,CI.descripcion, CASE WHEN SUM(tiempo_solucion ) IS NULL THEN 0 ELSE SUM(tiempo_solucion )   ")
				.append("END  AS tiempo_solucion  ")
				.append("FROM incidencias_facturacion AS IFA ")
				.append("INNER JOIN cat_incidencias AS CI ON CI.id = IFA.id_incidencia ")
				.append("WHERE fecha_y_hora_start > '" )
				.append(fechaTemp)
				.append("'  AND  '")
				.append( fechaTemp2 )
				.append(" WHERE id_incidencia IS NOT NULL AND IFA.tiempo_solucion > 0 " )
				.append("group by IFA.id_incidencia,CI.descripcion,,fecha_y_hora_start  ")
				.toString();
		

		try {
			conn = ConexionDB.dameConexion();
			try (PreparedStatement pstmt = conn.prepareStatement(SQL_LISTA_FACTURACION_REPORTE)) {
				ResultSet rs = pstmt.executeQuery();
				while (rs.next()) {
					ReporteSemanalIncidencias reporteSI = new ReporteSemanalIncidencias();
					reporteSI.setIdIncidencia(rs.getString("id_incidencia"));
					reporteSI.setDescripcion(rs.getString("descripcion"));
					reporteSI.setTiempoSolucion(rs.getString("tiempo_solucion"));
					listReporteSemanalIncidencias.add(reporteSI);
				}
				pstmt.close();
				rs.close();
			} catch (SQLException e) {
				try {
					ConexionDB.renuevaConexion(conn);
				} catch (Exception ex) {
					log.error(ex.getMessage(), ex);
				}
				log.error(e.getMessage(), e);
			}
		} catch (Exception e) {
			try {
				ConexionDB.devuelveConexion(conn);
			} catch (Exception ex) {
				log.error(ex.getMessage().toString(), ex);
			}
			log.error(e.getMessage(), e);
		} finally {
			try {
				ConexionDB.devuelveConexion(conn);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
			}
	}
		return listReporteSemanalIncidencias;
	}
	
	public static String formatearCalendar(Calendar c) {
		DateFormat df = DateFormat.getDateInstance(DateFormat.DEFAULT, Locale.getDefault());
		return df.format(c.getTime());
}
	
	
	
	
	
}
