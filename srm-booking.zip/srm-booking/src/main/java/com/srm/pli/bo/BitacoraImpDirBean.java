package com.srm.pli.bo;

import java.util.GregorianCalendar;
import java.util.List;

import javax.servlet.ServletException;

import org.apache.commons.lang.StringEscapeUtils;
import org.json.JSONObject;

import com.srm.pli.dao.SAR_CDI_DAO;
import com.srm.pli.utils.FuncionesComunesPLI;
import com.srm.pli.utils.Utilerias;
import com.truper.businessEntity.UserBean;
import com.truper.infra.loggers.BaseLogger;

public class BitacoraImpDirBean {
	private Integer id;
	private Integer folio;
	private String comments;
	private String userName;
	private Integer creationDate;
	private Long creationDateLong;
	
	public JSONObject toJSON(UserBean user){
		JSONObject json = new JSONObject();
		json.put("id", id);
		json.put("folio", folio);
		json.put("mensaje", StringEscapeUtils.escapeHtml(comments));
		json.put("usuario", userName);
		String nombre = "";
		UserBean usuario = new UserBean();
		usuario.setUserName(userName);
		List<UserBean> lstUsers;
		try {
			lstUsers = SAR_CDI_DAO.dameUsuarios(usuario);
			if (lstUsers != null && !lstUsers.isEmpty()) {
				nombre = StringEscapeUtils.escapeHtml(lstUsers.get(0).getRealName());
			}
		} catch (ServletException e) {
			BaseLogger.BOOKING_LOGGER.error(e.getMessage(), e);
		}		
		json.put("nombre", nombre);
		boolean local = userName.equals(user.getUserName());
		json.put("local", local);
		GregorianCalendar fechaMillis = new GregorianCalendar();
		fechaMillis.setTimeInMillis(creationDateLong);
		json.put("fechaLarga", Utilerias.formatLongDate(fechaMillis));
		json.put("fecha", FuncionesComunesPLI.formateaFecha(creationDate));
		
		return json;
	}
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getFolio() {
		return folio;
	}
	public void setFolio(Integer folio) {
		this.folio = folio;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public Integer getCreationDate() {
		return creationDate;
	}
	public void setCreationDate(Integer creationDate) {
		this.creationDate = creationDate;
	}
	public Long getCreationDateLong() {
		return creationDateLong;
	}
	public void setCreationDateLong(Long creationDateLong) {
		this.creationDateLong = creationDateLong;
	}
}
