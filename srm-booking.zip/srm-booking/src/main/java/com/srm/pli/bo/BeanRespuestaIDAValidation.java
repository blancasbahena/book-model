package com.srm.pli.bo;

import java.util.List;
import java.util.Set;

import com.truper.businessEntity.BeanCommonResponse;
import com.truper.businessEntity.BeanRespuestaEtdEta;
import com.truper.businessEntity.SARRevisionIDABean;

public class BeanRespuestaIDAValidation extends BeanCommonResponse {

	private SARRevisionIDABean folioCC;
	private List<SARRevisionIDABean> foliosLCL;
	private Set<BeanRespuestaEtdEta> respuestaValidacion;

	public SARRevisionIDABean getFolioCC() {
		return folioCC;
	}

	public void setFolioCC(SARRevisionIDABean folioCC) {
		this.folioCC = folioCC;
	}

	public List<SARRevisionIDABean> getFoliosLCL() {
		return foliosLCL;
	}

	public void setFoliosLCL(List<SARRevisionIDABean> foliosLCL) {
		this.foliosLCL = foliosLCL;
	}

	public Set<BeanRespuestaEtdEta> getRespuestaValidacion() {
		return respuestaValidacion;
	}

	public void setRespuestaValidacion(Set<BeanRespuestaEtdEta> respuestaValidacion) {
		this.respuestaValidacion = respuestaValidacion;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("BeanRespuestaIDAValidation [getFolioCC=");
		builder.append(getFolioCC());
		builder.append(", getFoliosLCL=");
		builder.append(getFoliosLCL());
		builder.append(", getRespuestaValidacion=");
		builder.append(getRespuestaValidacion());
		builder.append("]");
		return builder.toString();
	}
}