package com.srm.pli.dao;

import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.Date;
import java.util.List;

import com.srm.pli.enums.Variables;
import com.truper.infra.dao.BaseDAO;

/**
 * Clase abstracta que define el comportamiento de los DAO 
 * 
 * @author jipatino
 */
public abstract class DAO extends BaseDAO{

	/**
	 * 
	 */
	private static final long serialVersionUID = -7019931953194487213L;

	/**
	 * Metodo que define la forma del select, recibe un object que servira como filtro para
	 * el select y regresara una lista del mismo tipo que el objeto recibido.
	 *  
	 * @param 	o	parametro Filtro
	 * @return		Lista de objetos que cumplen con el filtro del parametro <b>o</b>
	 */
	public abstract List<?> select(Object o);
	
	/**
	 * Metodo que define la forma del insert, recibe un objeto que servira como base a la informacion a insertar
	 * 
	 * @param 	o	Objeto a insertar
	 * @return	Estatus de la operacion
	 */
	public abstract boolean insert(Object o);
	
	/**
	 * Metodo que define la forma del update, recibe el objeto el cual debe contener la llave del registro
	 * @param	o	Objeto a realizar update
	 * @return	Estatus de la operacion
	 */
	public abstract boolean update(Object o);
	
	/**
     * Metodo que valida un campo para ver si es nulo y en caso de serlo, insertar un null a la
     * base de datos para la posicion indicada para el prepared statement. El metodo cuenta con el
     * soporte para los siguientes tipos de dato: - String - Integer - Date - Timestamp - Float
     * Ejemplo: agregarPs(4, ps, devolucionesBean.getFolio(), String.class);
     *
     * @param posicion La posicion del parametro en el query.
     * @param ps El prepared statement que estamos formando.
     * @param campo El atributo del VO que estamos probando.
     * @param tipo El tipo de dato del parametro campo.
     * @throws SQLException Excepcion de base de datos.
     */
    protected static void agregarPs(int posicion, PreparedStatement ps, Object campo, Class tipo) throws SQLException, IOException {
        if (campo == null || campo.equals(Variables.NULL.getValue()) || campo.equals(Variables.NULL.getDescripcion())) {
            if (String.class == tipo) {
                ps.setNull(posicion, Types.VARCHAR);
            }
            else if (Integer.class == tipo) {
                ps.setNull(posicion, Types.INTEGER);
            }
            else if (Date.class == tipo) {
                ps.setNull(posicion, Types.DATE);
            }
            else if (Timestamp.class == tipo) {
                ps.setNull(posicion, Types.TIMESTAMP);
            }
            else if (BigDecimal.class == tipo) {
                ps.setNull(posicion, Types.DECIMAL);
            }
            else if (Boolean.class == tipo) {
                ps.setNull(posicion, Types.BOOLEAN);
            }
            else if (Long.class == tipo) {
                ps.setNull(posicion, Types.LONGVARCHAR);
            }
            else if (InputStream.class == tipo) {
            	ps.setNull(posicion, Types.VARBINARY);
            }
        }
        else {
            if (String.class == tipo) {
                ps.setString(posicion, (String) campo);
            }
            else if (Integer.class == tipo) {
                ps.setInt(posicion,  (Integer)campo);
            }
            else if (Date.class == tipo) {
                ps.setDate(posicion, new java.sql.Date(((Date) campo).getTime()));
            }
            else if (Timestamp.class == tipo) {
                ps.setTimestamp(posicion, new Timestamp(((Date) campo).getTime()));
            }
            else if (Float.class == tipo) {
                ps.setFloat(posicion, ((Float) campo).floatValue());
            }
            else if (BigDecimal.class == tipo) {
            	ps.setBigDecimal(posicion, ((BigDecimal) campo));
            }
            else if (Boolean.class == tipo) {
            	ps.setBoolean(posicion, ((Boolean) campo));
            }
            else if (Long.class == tipo) {
            	ps.setLong(posicion, ((Long) campo));
            }
            else if (InputStream.class == tipo) {
    			ps.setBinaryStream(posicion, ((InputStream) campo));
            }
        }
    }
}
