package com.srm.pli.helper;

import java.util.Arrays;
import java.util.Date;
import java.util.List;

import com.srm.pli.bo.SarBO;
import com.srm.pli.dao.DocumentosDao;
import com.srm.pli.utils.FuncionesComunesPLI;
import com.srm.pli.utils.PropertiesDb;
import com.truper.businessEntity.BeanLetoniano;
import com.truper.businessEntity.BeanPuerto;
import com.truper.infra.loggers.BaseLogger;
import com.truper.utils.date.EnumFechas;
import com.truper.utils.date.UtilsFechas;

/**
 * Se crea esta clase con el fin de eliminar el uso de la clase FormatSARDetalle
 * para solo usar los datos necesarios y no la carga completa de informacion como 
 * se hace actualmente.
 * Si se requiere cargar algun mapa se solicita la carga de este en el constructor.
 * 
 * @author drodriguezv
 *
 */
public class FormatSARDetalleHelper {
	private static FormatSARDetalleHelper instance;
	private DocumentosDao dao = new DocumentosDao();
	private BeanLetoniano letoniano = new BeanLetoniano();
	
	//constructor privado, lo usare para cargar mapas la primera vez
	public FormatSARDetalleHelper() {
		try {
			FuncionesComunesPLI.cargaPlanners(false);
			FuncionesComunesPLI.cargaContenedores(false);
			FuncionesComunesPLI.cargaMapaCelulasXUnidadNegocio(false);
			FuncionesComunesPLI.cargaPuertosDestino(false);
			FuncionesComunesPLI.cargaAerolineasYPuertos(false);
			FuncionesComunesPLI.cargaPuertosOrigen(false);
			FuncionesComunesPLI.cargaMapaBloqueos(false);
			FuncionesComunesPLI.dameMapaCondicionPago(false);
			
		} catch (Exception e) {
			BaseLogger.BOOKING_LOGGER.error("[GeneraDocumentosUtils - constructor] Error al cargar los mapas", e.toString());
		}
	}
	
	static {
		instance = new FormatSARDetalleHelper();
	}
	
	public static FormatSARDetalleHelper getInstance() {
		return instance;
	}
	
	
	/**
	 * Regresa la ETD del SAR formateada, ya se considera si el sar tiene o no SAR Real o solo fecha embarque
	 * 
	 * 
	 * 
	 * @param sar
	 * @return
	 */
	public String dameETDFormateado(SarBO sar) {
		Integer fecha = dameETDDelSAR(sar);
		Date fechaDate = UtilsFechas.setConvierteFechaToDate(fecha, EnumFechas.FORMATO_YYYYMMDD);
		return UtilsFechas.setConvierteFechaToString(fechaDate, EnumFechas.FORMATO_DD_MM_YYYY_SLASH);
	}
	
	/**
	 * Regresa la fecha ETD del sar se valida si tiene ETD real o solo la fecha de embarque
	 * 
	 * @param sar
	 * @return
	 */
	public Integer dameETDDelSAR(SarBO sar) {
		if(sar == null) {
			return null;
		}else {
			if(sar.getEtdReal() != null && sar.getEtdReal() > 0) {
				return sar.getEtdReal();
			}else {
				return sar.getFechaEmbarque();
			}
		}
	}
	
	public String dameNombrePuertoOrigen(SarBO sar) {
		if(sar == null) {
			return null;
		}else {
			BeanPuerto ptoOrigen = FuncionesComunesPLI.mapaPuertosOrigen == null ? null
					: FuncionesComunesPLI.mapaPuertosOrigen.get(sar.getPuertoOrigen());
			return ptoOrigen.getNombre();
		}
	}
	
	public String dameNombrePuertoDestino(SarBO sar) {
		if(sar == null) {
			return null;
		}else {
			BeanPuerto ptoOrigen = FuncionesComunesPLI.mapaPuertosDestino == null ? null
					: FuncionesComunesPLI.mapaPuertosDestino.get(sar.getPuertoDescarga());
			return ptoOrigen.getNombre();
		}
	}
	
	public FormatSAR setLetoniano(FormatSAR fsar) {
		if(fsar == null || fsar.getDetalle() == null) {
			return fsar;
		}
		for(FormatSARDetalle det : fsar.getDetalle()) {
			letoniano = dao.consultaLetoniano(det.getMaterial());
			if(letoniano.getItem()!=null)
				det.setDescripcion(letoniano.getDescripcion());
		}
		return fsar;
	}

	public FormatSAR setDescripcion(FormatSAR fsar) {
		if(fsar == null || fsar.getDetalle() == null) {
			return fsar;
		}
		List<String> OTHERS_ITEMS = Arrays.asList(PropertiesDb.getInstance().getStringTrim("cargaImportData.othersItems").split(","));
		for(FormatSARDetalle det : fsar.getDetalle()) {
			if(OTHERS_ITEMS.contains(det.getMaterial().toString())){
				letoniano = dao.consultaHebreo(det.getMaterial());
				if(letoniano.getItem()!=null)
					det.setDescripcion(letoniano.getDescripcion());
			}else{
				letoniano = dao.consultaLetoniano(det.getMaterial());
				if(letoniano.getItem()!=null)
					det.setDescripcion(letoniano.getDescripcion());
			}
		}
		return fsar;
	}
	
	public BeanLetoniano getLetoniano(Integer material) {
		letoniano = dao.consultaLetoniano(material);
		return letoniano;
	}

	public BeanLetoniano getHebreo(Integer material) {
		letoniano = dao.consultaHebreo(material);
		return letoniano;
	}
	

	
}
