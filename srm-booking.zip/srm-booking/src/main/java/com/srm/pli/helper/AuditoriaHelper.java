package com.srm.pli.helper;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashSet;

import com.srm.pli.bo.jasperReports.BeanReporteControlPrecio;
import com.truper.businessEntity.BeanAuditoria;
import com.truper.businessEntity.BeanAuditoriaMatriz;
import com.truper.businessEntity.BeanAuditoriaPpu;
import com.truper.businessEntity.BeanAuditoriaSinMatrizDetalle;

public class AuditoriaHelper {

	private static final AuditoriaHelper instance = new AuditoriaHelper();
	public static final String TIPO_SIN_MATRIZ = "SinMatriz";
	public static final String TIPO_CON_MATRIZ = "ConMatriz";

	private AuditoriaHelper() {
	}

	public static AuditoriaHelper getInstance() {
		return instance;
	}

	public Comparator<BeanAuditoria> getOrdenamientoPorFechaPool(final boolean ascendente) {
		return new Comparator<BeanAuditoria>() {
			@Override
			public int compare(BeanAuditoria o1, BeanAuditoria o2) {
				int v = 0;
				if (ascendente)
					v = o1.getCreateDate().compareTo(o2.getCreateDate());
				else
					v = o2.getCreateDate().compareTo(o1.getCreateDate());
				if (v != 0)
					return v;
				v = o1.getPo().compareTo(o2.getPo());
				if (v != 0)
					return v;
				return Integer.compare(o1.getPosicion(), o2.getPosicion());
			}
		};
	}

	public BeanReporteControlPrecio parseTo(BeanAuditoriaPpu origin) {
		if (origin == null)
			return null;
		BeanReporteControlPrecio target = new BeanReporteControlPrecio();
		target.setLogDate(origin.getLogDate());
		target.setCreateDate(origin.getCreateDate());
		target.setPo(origin.getPo());
		target.setEtd(origin.getEtd());
		target.setDaysLeftForEtd(origin.getDaysLeftForEtd());
		target.setProveedor(origin.getProveedor());
		target.setProveedorDescripcion(origin.getProveedorDescripcion());
		target.setBu(origin.getBu());
		target.setDaysLeftFromLogDate(origin.getDaysLeftFromCreateDate());
		target.setComentarios(origin.getComentarios());
		return target;
	}

	public ArrayList<BeanReporteControlPrecio> parseTo(Collection<BeanAuditoriaPpu> origins) {
		if (origins == null)
			return null;
		ArrayList<BeanReporteControlPrecio> target = new ArrayList<>();
		for (BeanAuditoriaPpu beanPpu : origins) {
			if (beanPpu == null)
				continue;
			target.add(parseTo(beanPpu));
		}
		return target;
	}
	
	public HashSet<String> getBUs(HashSet<BeanAuditoriaSinMatrizDetalle> detalles){
		HashSet<String> bus = new HashSet<>();
		for (BeanAuditoriaSinMatrizDetalle detalle : detalles) {
			bus.add(detalle.getBuClave());
		}
		return bus;
	}
	
	/**
	 * @param param
	 * @return
	 */
	public BeanAuditoria getBean(BeanAuditoriaMatriz param) {
		BeanAuditoria newParam = new BeanAuditoria();
		newParam.setCreateDate(param.getCreateDate());
		newParam.setProveedor(param.getProveedor());
		newParam.setPo(param.getPo());
		newParam.setComentarios(param.getComentarios());
		return newParam;
	}
	
}
