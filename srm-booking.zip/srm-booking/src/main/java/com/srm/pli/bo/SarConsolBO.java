package com.srm.pli.bo;

import org.apache.commons.lang3.builder.EqualsBuilder;

import com.srm.pli.helper.FormatSARConsolidados;
import com.truper.businessEntity.SARConsolidados;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SarConsolBO extends SARConsolidados {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6394367361689951607L;
	/** sarBOAntesFormato  esta variable la usamos para guardar una copia del BO dentro del formateo para no formatear 
	 * multiples veces al recorrer una lista o acciones similares */
	
	
	private SarConsolBO  	consolBOAntesFormato;
	/** formatSARFormatoTemp objeto ya formateado que voy a reenviar en caso de que el BO no sufriera cambios, 
	 * ahorrandome tiempo de formateo*/
	private FormatSARConsolidados formatConsolFormatoTemp;
	private Boolean sarHistory;
	private boolean revisionIDA;
	private int IDAMinimo;
	private boolean isHighV;
	


	
	/**
	 * Regresa un true si el sarBO tiene cambios con respecto al sarBo que se guarda solamente
	 * cuando se hace un formatSAR, la idea es que si es una lista, no se este formateando
	 * una y otra vez un mismo BO, ya que el formateo lleva mucho tiempo.
	 * 
	 * @param sarOriginal
	 * @return
	 */
	public boolean sarBOConCambios(SarConsolBO sarOriginal ){
		SarConsolBO respaldo = consolBOAntesFormato; 
		boolean tieneCambios = true;
		if(respaldo == null || formatConsolFormatoTemp == null){
			tieneCambios = !EqualsBuilder.reflectionEquals(sarOriginal, respaldo, false);
		}
		return tieneCambios;
	}
	
	



}
