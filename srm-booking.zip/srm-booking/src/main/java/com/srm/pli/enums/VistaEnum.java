package com.srm.pli.enums;

public enum VistaEnum {
	BOOKING,
	PLANNER,
	SHIPPING,
	IMP_DIR,
	SUPPLIER,
	SEARCH,
	
	VENDOR,
	
	CANCELACION
}
