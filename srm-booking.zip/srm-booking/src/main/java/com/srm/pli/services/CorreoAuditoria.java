package com.srm.pli.services;

import static com.srm.pli.helper.CorreoHelper.MAIL_FR_HK_AUDIT;
import static com.srm.pli.helper.CorreoHelper.SALUDO_TODOS;

import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.srm.pli.format.email.CorreoFormatoGeneral;
import com.srm.pli.helper.AuditoriaHelper;
import com.srm.pli.helper.CorreoHelper;
import com.srm.pli.utils.FuncionesComunesPLI;
import com.truper.businessEntity.BeanAuditoria;
import com.truper.businessEntity.BeanAuditoriaMatriz;
import com.truper.businessEntity.BeanAuditoriaSinMatrizDetalle;
import com.truper.utils.date.EnumFechas;
import com.truper.utils.date.UtilsFechas;

public class CorreoAuditoria {

	private static final CorreoAuditoria instance = new CorreoAuditoria();

	private CorreoAuditoria() {
	}

	public static CorreoAuditoria getInstance() {
		return instance;
	}

	public void enviaRechazoPorAuditoria(BeanAuditoria param) {
		List<BeanAuditoriaSinMatrizDetalle> detallePo = AuditoriaService.getInstance().getDetalleOrdenSinMatrizReject(param);
		enviaRechazoAuditoria(param, detallePo);
	}
	
	public void enviaRechazoPorAuditoria(BeanAuditoriaMatriz param) {
		BeanAuditoria objeto = AuditoriaHelper.getInstance().getBean(param);
		List<BeanAuditoriaSinMatrizDetalle> detallePo = AuditoriaService.getInstance().getDetalleOrdenConMatriz(objeto);
		enviaRechazoAuditoria(objeto, detallePo);
	}

	/**
	 * @param param
	 * @param detallePo
	 */
	public void enviaRechazoAuditoria(BeanAuditoria param, List<BeanAuditoriaSinMatrizDetalle> detallePo) {
		Date minETD = null;
		Set<String> celulas = new HashSet<>();
		for (BeanAuditoriaSinMatrizDetalle b : detallePo) {
			if (b.getEtd() != null && (minETD == null || b.getEtd().before(minETD))) {
				minETD = b.getEtd();
			}
			celulas.add(b.getBuClave());
		}
		
		String po = param.getPo();
		String proveedor = param.getProveedor();
		String proveedor_full = FuncionesComunesPLI.getProveedorFullName(proveedor);
		
		StringBuilder parrafo = new StringBuilder("The PI ");
		parrafo.append(po).append(" from Supplier ");
		parrafo.append(proveedor_full).append(" with shipment date ");
		parrafo.append(UtilsFechas.setConvierteFechaToString(minETD, EnumFechas.FORMATO_YYYY_MM_DD));
		parrafo.append(", is rejected due to the following reason: ").append(param.getComentarios());
		parrafo.append("<br><br>Please review immediately and let us know the next step.");
		
		String preview = "Rejected PO";
		String table = CorreoAuditoriaFormato.getInstance().buildTableDetalleOrden(detallePo);
		String formatoHTML = CorreoFormatoGeneral.getInstance().getFormatoFR(SALUDO_TODOS, parrafo.toString(), preview, "#7d2181", table);
		
		StringBuilder subject = new StringBuilder("PI ").append(po).append(" Rejected by Audit Area");
		
		Map<String, Set<String>> correos = CorreoHelper.getInstance().buildCorreosRechazoAuditoria(celulas);
		String sender = CorreoHelper.getInstance().getEmail(MAIL_FR_HK_AUDIT);
		CorreoServices.getInstance().enviaCorreo(formatoHTML, subject.toString(), sender, correos);
	}
}
