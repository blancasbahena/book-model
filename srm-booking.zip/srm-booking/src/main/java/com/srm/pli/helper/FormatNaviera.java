package com.srm.pli.helper;

import com.truper.businessEntity.Naviera;

public class FormatNaviera {
	
	private String clave = null;
	private String nombre = null;
	
	/**
	 * Funcion para llenar el bean y 
	 * convertirlo por medio de Gson a un json y mandarlo a las vistas
	 * 
	 * @param naviera
	 */
	public void format(Naviera naviera){				
		clave  = 	String.valueOf(naviera.getClave());
		nombre =   	naviera.getNombre();
		
	}

	
	/*****Getters & setters ****///
	
	public String getClave() {
		return clave;
	}

	public void setClave(String clave) {
		this.clave = clave;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	
	
	
	
//	public JSONObject toJSON() {
//	JSONObject json = new JSONObject();
//	try{
//		json.put("clave", clave);
//		json.put("nombre", StringEscapeUtils.escapeHtml(nombre));
//	}catch(JSONException je){}
//	
//	return json;
	
}
