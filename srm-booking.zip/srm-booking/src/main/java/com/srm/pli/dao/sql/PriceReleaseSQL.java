package com.srm.pli.dao.sql;

import com.srm.pli.bo.SarBO;
import com.srm.pli.helper.PriceReleaseHelper;
import com.truper.bpm.enums.TipoPosicionEnum;

public class PriceReleaseSQL {

	/**
	 * @param Folio
	 *            SAR @int
	 */
	public static final String SELECT_SAR_PO_POSICION_WITH_OTHER_ITEM;
	public static final String SELECT_SAR_PRECIOS_EN_REVISION;
	public static final String SELECT_SAR_PRECIOS_EN_REVISION_REPORTE;
	public static final String SELECT_SAR_PRECIOS_EN_REVISION_FALTANTES_ACTUALIZADOS;
	public static final String SELECT_SAR_PRECIOS_ACTUALIZADOS;
	public static final String SELECT_PROVEEDOR_CON_MATRIZ;
	public static final String SELECT_SAR_PRECIOS_EN_REVISION_TIEMPO_EXCEDIDO;

	public static final String INSERT_PRICE_RELEASE_REQUEST;
	public static final String INSERT_PRICE_RELEASE_FROM_REQUEST;

	/**
	 * <lu>
	 * <li>preciosEnRevision @boolean</li>
	 * <li>WHERE</li>
	 * <li>FolioSAR @int</li></lu>
	 */
	public static final String UPDATE_SAR_PRECIOS_REVISION;
	
	public static final String UPDATE_SAR_PRECIOS_REVISION_SEGUNDA_VEZ;
	
	public static final String UPDATE_SAR_LIBERA_HACIA_PLANEACION, UPDATE_SAR_LIBERA_HACIA_CONFIRMACION_FINAL;
	/**
	 * <lu>
	 * <li>preciosLiberados @boolean</li>
	 * <li>WHERE</li>
	 * <li>FolioSAR @int</li></lu>
	 */
	public static final String UPDATE_SAR_PRECIOS_LIBERADOS;
	public static final String UPDATE_LIBERATION_BO_CONFIRMATION;
	
	
	public static final String UPDATE_SAR_REJECT;

	/**
	 * <lu>
	 * <li>precioUnitario @boolean</li>
	 * <li>WHERE</li>
	 * <li>FolioSAR @int</li>
	 * <li>tipo @String</li>
	 * <li>posicion @int</li></lu>
	 */
	public static final String UPDATE_OTHER_ITEM_PRICE;
	
	public static final String UPDATE_IF_IS_REVISION_PRECIOS;

	/**
	 * <lu> *
	 * <li>FolioSAR @int</li></lu>
	 */
	public static final String DELETE_SAR_PRECIOS_EN_REVISION;

	static {
		StringBuilder sql = new StringBuilder();
		sql.append(" DECLARE @folio VARCHAR(100) = ? ");
		sql.append(" SELECT 'PO'                               subtipo ");
		sql.append("       , d.po ");
		sql.append("       , d.posicion ");
		sql.append("       , Cast(d.material AS VARCHAR(100)) material ");
		sql.append("       , d.cantidad ");
		sql.append("       , d.preciounitario ");
		sql.append("       , 'P'                              tipo ");
		sql.append("       , s.preciosrevisados ");
		sql.append("       , d.planeador ");
		sql.append("       , d.centro ");
		sql.append("       , NULL 'unidadMedida'");
		sql.append(" FROM   cdiSARDetalle d ");
		sql.append("       INNER JOIN cdiSAR s ");
		sql.append("               ON d.folio = s.folio ");
		sql.append(" WHERE  d.folio = @folio ");
		sql.append(" UNION ALL ");
		sql.append(" SELECT o.po  subtipo ");
		sql.append("       , o.pootheritem ");
		sql.append("       , o.posicion ");
		sql.append("       , o.descripcion ");
		sql.append("       , o.cantidad ");
		sql.append("       , o.preciounitario ");
		sql.append("       , 'O' tipo ");
		sql.append("       , s.preciosrevisados ");
		sql.append("       , NULL ");
		sql.append("       , NULL ");
		sql.append("       , o.unidadMedida ");
		sql.append(" FROM   cdiSARDetalleOthers o ");
		sql.append("       INNER JOIN cdiSAR s ");
		sql.append("               ON o.folio = s.folio ");
		sql.append(" WHERE  o.folio = @folio");
		SELECT_SAR_PO_POSICION_WITH_OTHER_ITEM = sql.toString();

		sql = new StringBuilder();
		sql.append(" SELECT r.folio ");
		sql.append("       , r.po ");
		sql.append("       , s.proveedor ");
		sql.append("       , CASE WHEN d.planeador IS NULL");
		sql.append("       			THEN (SELECT TOP 1 (CONCAT(material,'").append(PriceReleaseHelper.TO_SPLIT).append("',centro)) FROM cdiSARDetalle aux WHERE aux.folio = r.folio)");
		sql.append("       			ELSE d.planeador");
		sql.append("       	 END AS planeador ");
		sql.append("       , r.posicion ");
		sql.append("       , r.material ");
		sql.append("       , r.cantidad ");
		sql.append("       , o.unidadMedida ");
		sql.append("       , d.centro ");
		sql.append("       , r.tipo ");
		sql.append("       , r.subtipo ");
		sql.append("       , r.pago ");
		sql.append("       , r.preciounitario ");
		sql.append("       , r.preciounitariosolicitado ");
		sql.append("       , CASE ");
		sql.append("           WHEN m.codigo IS NULL THEN 0 ");
		sql.append("           ELSE 1 ");
		sql.append("         END AS matriz ");
		sql.append("       , s.disagreeComments ");
		sql.append("       , r.createdate ");
		sql.append("       , r.updatedate ");
		sql.append(" FROM   cdipricereleaserequest r ");
		sql.append("       LEFT JOIN cdisar s ");
		sql.append("              ON r.folio = s.folio ");
		sql.append("       LEFT JOIN cdisardetalle d ");
		sql.append("              ON r.folio = d.folio ");
		sql.append("                 AND r.posicion = d.posicion ");
		sql.append("                 AND Ltrim(Rtrim(r.material)) = Ltrim(Rtrim(d.material)) ");
		sql.append("       LEFT JOIN cdicatalogoproveedoresconmatriz m ");
		sql.append("              ON s.proveedor = m.proveedor ");
		sql.append("                 AND Ltrim(Rtrim(r.material)) = Ltrim(Rtrim(m.codigo)) ");
		sql.append("       LEFT JOIN cdisardetalleothers o ");
		sql.append("              ON r.folio = o.folio ");
		sql.append("                 AND r.posicion = o.posicion ");
		sql.append(" WHERE  s.preciosenrevision = 1 ");
		sql.append(" ORDER  BY r.folio ");
		sql.append("          , r.po DESC ");
		sql.append("          , r.posicion");
		SELECT_SAR_PRECIOS_EN_REVISION = sql.toString();
		
		sql = new StringBuilder();
		sql.append("SELECT r.folio, r.createDate ");
		sql.append("		, r.po ");
		sql.append("		, ISNULL(s.etdFinal, s.fechaEmbarque) etd ");
		sql.append("		, IIF(s.etdFinal <> 0  ");
		sql.append("		, DATEDIFF(DAY, CONVERT(smalldatetime, CAST(ISNULL(s.etdFinal, s.fechaEmbarque) AS varchar)), GETDATE())  ");
		sql.append("		, DATEDIFF(DAY, CONVERT(smalldatetime, CAST(s.fechaEmbarque AS varchar)), GETDATE())) as daysLeftForEtd  ");
		sql.append("		, s.proveedor ");
		sql.append("		, r.material ");
		sql.append("		, d.centro ");
		sql.append("		, DATEDIFF(DAY, CONVERT(smalldatetime,CAST(r.createDate AS varchar)), GETDATE()) daysLeftFromCreateDate ");
		sql.append("		, s.disagreeComments ");
		sql.append("		, d.planeador ");
		sql.append(" FROM   cdipricereleaserequest r ");
		sql.append("       INNER JOIN cdisardetalle d ");
		sql.append("            ON r.folio = d.folio ");
		sql.append("            AND r.tipo = 'PO' AND r.PO = d.PO ");
		sql.append("                AND r.posicion = d.posicion ");
		sql.append("                AND Ltrim(Rtrim(r.material)) = Ltrim(Rtrim(d.material)) ");
		sql.append("		INNER JOIN cdiSAR s ");
		sql.append("			ON r.folio = s.folio ");
		sql.append(" WHERE r.updateDate IS NULL ");
		//sql.append("		AND r.tipo = '").append(TipoPosicionEnum.PO).append("' ");
		sql.append("		AND s.disagreeComments IS NOT NULL ");
		sql.append(" ORDER  BY r.createDate");
		SELECT_SAR_PRECIOS_EN_REVISION_REPORTE = sql.toString();
		
		sql = new StringBuilder();
		sql.append("SELECT	folio ");
		sql.append("		, ( Count(folio) - Count(updatedate) ) faltantes ");
		sql.append("		, SUM(CAST(ISNULL(precioActualizado, 0) as int)) actualizados ");
		sql.append("		, SUM(CASE ");
		sql.append("			WHEN tipo = '").append(TipoPosicionEnum.PO).append("' ");
		sql.append("			THEN CAST(ISNULL(precioActualizado, 0) as int) ");
		sql.append("			ELSE 0 ");
		sql.append("		END) actualizadosPO ");
		sql.append("		, SUM(CASE ");
		sql.append("			WHEN tipo <> '").append(TipoPosicionEnum.PO).append("' ");
		sql.append("			THEN CAST(ISNULL(precioActualizado, 0) as int) ");
		sql.append("			ELSE 0 ");
		sql.append("		END) actualizadosOthers ");
		sql.append(" FROM   cdipricereleaserequest ");
		sql.append(" WHERE  folio = ? ");
		sql.append(" GROUP  BY folio");
		SELECT_SAR_PRECIOS_EN_REVISION_FALTANTES_ACTUALIZADOS = sql.toString();
		
		sql = new StringBuilder();
		sql.append("SELECT s.proveedor ");
		sql.append("	, SUM(CAST(ISNULL(r.precioActualizado, 0) as smallint)) actualizados ");
		sql.append("FROM cdipricereleaserequest r ");
		sql.append("	INNER JOIN cdiSAR s ON r.folio = s.folio ");
		sql.append("WHERE r.folio = ? ");
		sql.append("GROUP BY s.proveedor");
		SELECT_SAR_PRECIOS_ACTUALIZADOS = sql.toString();
		
		sql = new StringBuilder();
		sql.append(" SELECT proveedor, codigo, create_date ");
		sql.append(" FROM cdiCatalogoProveedoresConMatriz ");
		sql.append(" WHERE proveedor = ? AND codigo IN ? ");
		SELECT_PROVEEDOR_CON_MATRIZ = sql.toString();
		
		sql = new StringBuilder();
		sql.append(" SELECT r.folio ");
		sql.append("        , d.material, d.centro ");
		sql.append(" FROM   cdipricereleaserequest r ");
		sql.append("        INNER JOIN cdisardetalle d ");
		sql.append("                ON r.folio = d.folio ");
		sql.append("                   AND r.posicion = d.posicion ");
		sql.append("                   AND Ltrim(Rtrim(r.material)) = Ltrim(Rtrim(d.material)) ");
		sql.append(" WHERE  r.createdate <= Dateadd(day, Datediff(day, 0, Getdate() - 3), 0) ");
		sql.append("        AND r.updatedate IS NULL ");
		sql.append(" GROUP  BY r.folio ");
		sql.append("           , d.material, d.centro ");
		sql.append(" ORDER  BY r.folio ");
		sql.append("           , d.material");
		SELECT_SAR_PRECIOS_EN_REVISION_TIEMPO_EXCEDIDO = sql.toString();

		sql = new StringBuilder();
		sql.append(" INSERT INTO cdiPriceReleaseRequest ");
		sql.append(" (folio ,po ,posicion ,material ,cantidad ,tipo ");
		sql.append(" ,subTipo ,pago ,precioUnitario ,precioUnitarioSolicitado) ");
		sql.append(" VALUES ( ? ,? ,? ,? ,? ,? ,? ,? ,? ,? ) ");
		INSERT_PRICE_RELEASE_REQUEST = sql.toString();

		sql = new StringBuilder();
		sql.append(" INSERT INTO cdiPriceRelease ");
		sql.append("            (folio ");
		sql.append("             , po ");
		sql.append("             , posicion ");
		sql.append("             , material ");
		sql.append("             , cantidad ");
		sql.append("             , tipo ");
		sql.append("             , subtipo ");
		sql.append("             , preciounitario ");
		sql.append("             , preciounitariosolicitado ");
		sql.append("             , requestcreatedate ");
		sql.append("             , pago ");
		sql.append("             , pagadero ");
		sql.append("             , precioactualizado ");
		sql.append("             , preciounitarioactualizado ");
		sql.append("             , requestupdatedate) ");
		sql.append(" SELECT folio ");
		sql.append("       , po ");
		sql.append("       , posicion ");
		sql.append("       , material ");
		sql.append("       , cantidad ");
		sql.append("       , tipo ");
		sql.append("       , subtipo ");
		sql.append("       , preciounitario ");
		sql.append("       , preciounitariosolicitado ");
		sql.append("       , createdate ");
		sql.append("       , pago ");
		sql.append("       , pagadero ");
		sql.append("       , precioactualizado ");
		sql.append("       , preciounitarioactualizado ");
		sql.append("       , updatedate ");
		sql.append(" FROM   cdiPriceReleaseRequest ");
		sql.append(" WHERE  folio = ? ");
		INSERT_PRICE_RELEASE_FROM_REQUEST = sql.toString();
		
		sql = new StringBuilder();
		sql.append(" UPDATE cdiSAR SET preciosEnRevision = ?  WHERE folio = ? ");
		UPDATE_SAR_PRECIOS_REVISION = sql.toString();

		sql = new StringBuilder();
		sql.append(" UPDATE cdiSAR SET preciosRevisados = 1, preciosEnRevision = 0, preciosLiberados = 0 WHERE folio = ? ");
		UPDATE_SAR_PRECIOS_REVISION_SEGUNDA_VEZ = sql.toString();
		
		sql = new StringBuilder();
		sql.append(" UPDATE cdiSAR SET ");
		sql.append("  fecIniPlanning = ? ");
		sql.append(" , tinyFecIniPlanning = ? ");
		sql.append(" , preciosLiberados = 1 ");
		sql.append(" , preciosEnRevision = 0 ");
		sql.append(" , status = ").append(SarBO.STATUS_ESPERA_APROBACION_PLANEACION);
		sql.append(" , estatusAuditoria = ? ");
		sql.append(" WHERE folio = ? ");
		UPDATE_SAR_LIBERA_HACIA_PLANEACION = sql.toString();
		
		sql = new StringBuilder();
		sql.append(" UPDATE cdiSAR SET ");
		sql.append("   preciosLiberados = 1 ");
		sql.append(" , preciosEnRevision = 0 ");
		sql.append(" , estatusAuditoria = ? ");
		sql.append(" WHERE folio = ? ");
		UPDATE_SAR_LIBERA_HACIA_CONFIRMACION_FINAL = sql.toString();

		sql = new StringBuilder();
		sql.append(" UPDATE cdiSAR SET preciosLiberados = ? ");
		sql.append(" , status = ").append(SarBO.STATUS_ESPERA_APROBACION_PLANEACION);
		sql.append(" WHERE folio = ? ");
		UPDATE_SAR_PRECIOS_LIBERADOS = sql.toString();
		
		sql = new StringBuilder();
		sql.append(" UPDATE cdiSAR SET preciosLiberados = ? ");
		sql.append(" , status = ").append(SarBO.STATUS_LIBERATION_BO_CONFIRMATION);
		sql.append(" WHERE folio = ? ");
		UPDATE_LIBERATION_BO_CONFIRMATION = sql.toString();

		sql = new StringBuilder();
		sql.append(" UPDATE cdiSARDetalleOthers SET precioUnitario = ? ");
		sql.append(" WHERE folio = ? AND po = ? AND posicion = ?");
		UPDATE_OTHER_ITEM_PRICE = sql.toString();

		sql = new StringBuilder();
		sql.append("DECLARE @folio INT ");
		sql.append("DECLARE @registros INT ");
		sql.append("SET @folio = ? ");
		sql.append("SET @registros = (SELECT Count(folio) ");
		sql.append("                  FROM   cdipricereleaserequest ");
		sql.append("                  WHERE  folio = @folio ");
		sql.append("                         AND updatedate IS NULL) ");
		sql.append("IF @registros > 0 ");
		sql.append("  UPDATE cdisar ");
		sql.append("  SET    preciosenrevision = 1 ");
		sql.append("  WHERE  folio = @folio ");
		UPDATE_IF_IS_REVISION_PRECIOS = sql.toString();
		
		sql = new StringBuilder();
		sql.append(" DELETE cdiPriceReleaseRequest WHERE folio = ? ");
		DELETE_SAR_PRECIOS_EN_REVISION = sql.toString();
		
		sql = new StringBuilder();
		sql.append(" UPDATE cdiSar ");
		sql.append(" SET   status = 0 ");
		sql.append("       , needAuthImpDir = 0 ");
		sql.append("       , notificacionMRP = 0 ");
		sql.append("       , enRevisionConfirmFinal = 0 ");
		sql.append("       , preciosenrevision = 0 ");
		sql.append("       , enRevisionIDA = 0 ");
		sql.append("       , estatusPago = 0 ");
		sql.append("       , obs_reject = ? ");
		sql.append(" WHERE  folio = ? ");
		UPDATE_SAR_REJECT = sql.toString();
		
		

		


		
	}


	
	
	private PriceReleaseSQL() {
	}

}
