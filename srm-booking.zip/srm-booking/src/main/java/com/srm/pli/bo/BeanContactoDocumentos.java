package com.srm.pli.bo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BeanContactoDocumentos {
	
	private String nombre_shipper;
	private String calle_shipper;
	private String colonia_shipper;
	private String edo_shipper;
	private String pais_shipper;
	private String rfc_shipper;
	private String tel_shipper;
	private String fax_shipper;
	private String contact_shipper;
	
	private String nombre_consignee;
	private String calle_consignee;
	private String edo_consignee;
	private String pais_consignee;
	private String rfc_consignee;
	private String tel_consignee;
	private String fax_consignee;
	private String contact_consignee;
}
