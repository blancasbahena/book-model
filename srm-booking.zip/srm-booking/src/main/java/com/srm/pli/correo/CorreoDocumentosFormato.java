package com.srm.pli.correo;

import java.util.List;

import com.srm.pli.bo.BeanVistaDocumentos;
import com.srm.pli.documents.IndicadoresDocumentosBean;
import com.srm.pli.format.email.CorreoFormatoGeneral;
import com.srm.pli.utils.FuncionesComunesPLI;
import com.truper.utils.date.EnumFechas;
import com.truper.utils.date.UtilsFechas;

public class CorreoDocumentosFormato {
	private static CorreoDocumentosFormato instance = new CorreoDocumentosFormato();

	private CorreoDocumentosFormato() {
	}

	public static CorreoDocumentosFormato getInstance() {
		return instance;
	}

	public String buildTableDocumentosNuevosTardios(List<BeanVistaDocumentos> documentos) {
		StringBuilder table = new StringBuilder();
		table.append(CorreoFormatoGeneral.getInstance().getTrHeader());
		table.append(CorreoFormatoGeneral.getInstance().getThHeader("Booking"));
		table.append(CorreoFormatoGeneral.getInstance().getThHeader("Proveedor"));
		table.append(CorreoFormatoGeneral.getInstance().getThHeader("Fecha proveedor"));
		table.append("</tr>");
		for (int i = 0; i < documentos.size(); i++) {
			BeanVistaDocumentos bean = documentos.get(i);
			if (i % 2 == 0) {
				table.append(CorreoFormatoGeneral.getInstance().getTrEven());
			} else {
				table.append(CorreoFormatoGeneral.getInstance().getTrOdd());
			}
			table.append(CorreoFormatoGeneral.getInstance().getTd(bean.getBooking()));
			String proveedor = FuncionesComunesPLI.getProveedorFullName(bean.getProveedor());
			table.append(CorreoFormatoGeneral.getInstance().getTd(proveedor));
			String fecha = UtilsFechas.setConvierteFechaToString(bean.getFechaAceptaProveedor(),
					EnumFechas.FORMATO_YYYY_MM_DD);
			table.append(CorreoFormatoGeneral.getInstance().getTd(fecha));
			table.append("</tr>");
		}
		return table.toString();
	}
	
	public String buildTableIndicadoresDocumentos(IndicadoresDocumentosBean indicadores) {
		StringBuilder table = new StringBuilder();
		table.append(CorreoFormatoGeneral.getInstance().getTrHeader());
		table.append(CorreoFormatoGeneral.getInstance().getThHeader("Recibidos"));
		table.append(CorreoFormatoGeneral.getInstance().getThHeader("Rechazados"));
		table.append(CorreoFormatoGeneral.getInstance().getThHeader("Aprobados"));
		table.append(CorreoFormatoGeneral.getInstance().getThHeader("Retro en tiempo"));
		table.append(CorreoFormatoGeneral.getInstance().getThHeader("Retro tardio"));
		table.append("</tr>");
		table.append(CorreoFormatoGeneral.getInstance().getTrOdd());
		table.append(CorreoFormatoGeneral.getInstance().getTd(indicadores.getRecibidos()));
		table.append(CorreoFormatoGeneral.getInstance().getTd(indicadores.getRechazados()));
		table.append(CorreoFormatoGeneral.getInstance().getTd(indicadores.getAprobados()));
		table.append(CorreoFormatoGeneral.getInstance().getTd(indicadores.getRetroalimentadosEnTiempo()));
		table.append(CorreoFormatoGeneral.getInstance().getTd(indicadores.getRetroalimentadosTardios()));
		table.append("</tr>");
		return table.toString();
	}
}
