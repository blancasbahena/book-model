package com.srm.pli.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.List;

import com.srm.pli.db.ConexionDB;
import com.truper.businessEntity.BeanCondicionesPago;


public class CatalogosTablas extends DAO {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2188051538989146333L;
	
	@Override
	public List<?> select(Object o) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean insert(Object o) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean update(Object o) {
		// TODO Auto-generated method stub
		return false;
	}
	
	public static HashMap<String, String> selectCondicionesPago() 
			throws SQLException, ClassNotFoundException {
		HashMap<String, String> lstSar = new HashMap<String, String>();
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();

			ResultSet rs = null;
			StringBuffer query = new StringBuffer();
			PreparedStatement st = null;
			
			query.append("SELECT clave,descripcion");
			query.append(" FROM cdi_cat_condicionespago ");
			
			st = con.prepareStatement(query.toString());
			rs = st.executeQuery();
			
			while (rs.next()) {
				String clave,descripcion;
				clave = rs.getString("clave");
				descripcion = rs.getString("descripcion");
				if(clave ==null || "".equals(clave)) {
					continue;
				}
				if(descripcion == null ) {
					descripcion = "";
				}
				lstSar.put(clave.trim(),descripcion.trim());
			}
			
			rs.close();
			ConexionDB.devuelveConexion(con);

		} catch (SQLException sqlE) {
			try {
				BOOKING_LOGGER.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception sqlEx2) {
				BOOKING_LOGGER.error(sqlEx2.getMessage(), sqlEx2);
			}
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				BOOKING_LOGGER.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
		return lstSar;
	}
	
	
	public static void deleteCondicionesPago() throws SQLException, ClassNotFoundException{
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();

			Statement st = null;
			StringBuffer query = new StringBuffer();
			query.append("DELETE FROM cdi_cat_condicionespago ");
			
			st = con.createStatement();
			st.execute(query.toString());
			st.close();
		} catch (SQLException sqlE) {
			try {
				BOOKING_LOGGER.error(sqlE.getMessage(), sqlE);
				ConexionDB.renuevaConexion(con);
			} catch (Exception sqlEx2) {
				BOOKING_LOGGER.error(sqlEx2.getMessage(), sqlEx2);
			}
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				BOOKING_LOGGER.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
	}
	
	
	public static boolean insert_cdiCatCondicionesPago(List<BeanCondicionesPago> datosInsertar) {
		Connection con = null;
		Statement st = null;
		String insert = "";
				
		boolean exito = false;

		try {
			con = ConexionDB.dameConexion();
			st = con.createStatement();
			for(BeanCondicionesPago tmp : datosInsertar){
				insert = "INSERT INTO cdi_cat_condicionespago (clave,descripcion) values('"
						+tmp.getClave()+"', '"+tmp.getDescripcion()+"')";
				st.addBatch(insert);
			}
			st.executeBatch();
			st.close();
		} catch (SQLException e) {
			try {
				st.close();
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				BOOKING_LOGGER.error(ex.getMessage(), ex);
			}
			BOOKING_LOGGER.error(e.getMessage(), e);
		} catch (Exception e) {
			try {
				st.close();
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				BOOKING_LOGGER.error(ex.getMessage(), ex);
			}
			BOOKING_LOGGER.error(e.getMessage(), e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				BOOKING_LOGGER.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
		return exito;
	}
}