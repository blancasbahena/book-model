package com.srm.pli.helper;

import org.apache.commons.lang3.StringEscapeUtils;

import com.srm.pli.tags.IconosProductosTag;
import com.srm.pli.utils.FuncionesComunesPLI;
import com.truper.businessEntity.BeanMRPData;
import com.truper.businessEntity.ProductoBean;

public class FormatMrpData {
	private String folio;
	private String folioRaw;
	private String folioVista;
	private String po;
	private String posicion;
	private String material;
	private String clave;
	private String descripcion;
	private String iconosTag;
	private String height;
	private String width;
	private String length;
	private String volume;
	private String weight;
	private String inner;
	private String master;
	private String cveProveedor;
	private String nombreProveedor;
	private String fechaRegistro;
	private String status;
	private String truperContact;
	private String usuarioCarga;
	
	public FormatMrpData (BeanMRPData data, int etd) {
		ProductoBean p = FuncionesComunesPLI.productos.get(data.getMaterial().toString());
		
		folio = String.valueOf(data.getFolio());
		po= data.getPo();
		posicion = String.valueOf(data.getPosicion());
		material = String.valueOf(data.getMaterial());
		IconosProductosTag ipt = new IconosProductosTag(String.valueOf(material), false, etd);
		iconosTag = ipt.doTagString();
		if(p != null){
			descripcion = StringEscapeUtils.escapeHtml3(p.getDescripcion());
			clave = p.getClave();
		}
		height = data.getHeight() == null ? "-" : FuncionesComunesPLI.formatea(data.getHeight(), 2);
		width = data.getWidth() == null ? "-" : FuncionesComunesPLI.formatea(data.getWidth(), 2);
		length = data.getLength() == null ? "-" : FuncionesComunesPLI.formatea(data.getLength(), 2);
		volume = data.getVolume() == null ? "-" : FuncionesComunesPLI.formatea(data.getVolume(), 2);
		weight = data.getWeight() == null ? "-" : FuncionesComunesPLI.formatea(data.getWeight(), 2);
		inner = data.getInner() == null ? "-" : FuncionesComunesPLI.formatea(data.getInner(), 0);
		master = data.getMaster() == null ? "-" : FuncionesComunesPLI.formatea(data.getMaster(), 0);
		cveProveedor = data.getCveProveedor();
		nombreProveedor = data.getCveProveedor() != null
				&& FuncionesComunesPLI.getProveedor(data.getCveProveedor()) != null ? FuncionesComunesPLI
				.getProveedor(data.getCveProveedor()).getNombreProveedor() : "-";
		fechaRegistro = data.getFechaRegistro() == null ? "-" : FuncionesComunesPLI.formateaFecha(data.getFechaRegistro());
		truperContact = data.getCveProveedor() != null
				&& FuncionesComunesPLI.getProveedor(data.getCveProveedor()) != null ? FuncionesComunesPLI
				.getProveedor(data.getCveProveedor()).getContacto() : "-";
		usuarioCarga = data.getUsuarioCarga();
	}
	
	public String getFolio() {
		return folio;
	}
	public void setFolio(String folio) {
		this.folio = folio;
	}
	public String getFolioRaw() {
		return folioRaw;
	}

	public void setFolioRaw(String folioRaw) {
		this.folioRaw = folioRaw;
	}

	public String getFolioVista() {
		return folioVista;
	}

	public void setFolioVista(String folioVista) {
		this.folioVista = folioVista;
	}

	public String getPo() {
		return po;
	}
	public void setPo(String po) {
		this.po = po;
	}
	public String getPosicion() {
		return posicion;
	}
	public void setPosicion(String posicion) {
		this.posicion = posicion;
	}
	public String getMaterial() {
		return material;
	}
	public void setMaterial(String material) {
		this.material = material;
	}
	public String getClave() {
		return clave;
	}

	public void setClave(String clave) {
		this.clave = clave;
	}

	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	public String getIconosTag() {
		return iconosTag;
	}

	public void setIconosTag(String iconosTag) {
		this.iconosTag = iconosTag;
	}

	public String getHeight() {
		return height;
	}
	public void setHeight(String height) {
		this.height = height;
	}
	public String getWidth() {
		return width;
	}
	public void setWidth(String width) {
		this.width = width;
	}
	public String getLength() {
		return length;
	}
	public void setLength(String length) {
		this.length = length;
	}
	public String getVolume() {
		return volume;
	}
	public void setVolume(String volume) {
		this.volume = volume;
	}
	public String getWeight() {
		return weight;
	}
	public void setWeight(String weight) {
		this.weight = weight;
	}
	public String getInner() {
		return inner;
	}
	public void setInner(String inner) {
		this.inner = inner;
	}
	public String getMaster() {
		return master;
	}
	public void setMaster(String master) {
		this.master = master;
	}
	public String getCveProveedor() {
		return cveProveedor;
	}
	public void setCveProveedor(String cveProveedor) {
		this.cveProveedor = cveProveedor;
	}
	public String getNombreProveedor() {
		return nombreProveedor;
	}
	public void setNombreProveedor(String nombreProveedor) {
		this.nombreProveedor = nombreProveedor;
	}
	public String getFechaRegistro() {
		return fechaRegistro;
	}
	public void setFechaRegistro(String fechaRegistro) {
		this.fechaRegistro = fechaRegistro;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}

	public String getTruperContact() {
		return truperContact;
	}

	public void setTruperContact(String truperContact) {
		this.truperContact = truperContact;
	}

	public String getUsuarioCarga() {
		return usuarioCarga;
	}

	public void setUsuarioCarga(String usuarioCarga) {
		this.usuarioCarga = usuarioCarga;
	}
	
	
}
