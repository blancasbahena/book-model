package com.srm.pli.init;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import com.srm.pli.utils.FuncionesComunesPLI;
import com.srm.pli.utils.PropertiesLoader;
import com.truper.infra.schedulers.BaseSchedulerService;

/**
 * 
 * @author danavarrom
 * @deprecated
 *
 */
public class ContextInitialization implements ServletContextListener {
	private BaseSchedulerService sarsVencidos = new BaseSchedulerService("com.srm.pli.schedulers.jobs.NotificaSARsVencidosJob", "sarsVencidos", "srmBooking", "0 0 7 ? * MON-FRI");
	private BaseSchedulerService reporteSARs = new BaseSchedulerService("com.srm.pli.schedulers.jobs.ReporteSARsAprobadosJob", "sarsAprobados", "srmBooking", "0 0 7 ? * MON-FRI");
	private BaseSchedulerService reporteSARs2 = new BaseSchedulerService("com.srm.pli.schedulers.jobs.ReporteSARsAprobadosJob", "sarsAprobados2", "srmBooking", "0 15 17 ? * MON-FRI");
	private BaseSchedulerService notifEtd = new BaseSchedulerService("com.srm.pli.schedulers.jobs.EnvioNotificacionesCdiJob", "notifEtd", "srmBooking", "0 0 17 * * ?");
	private BaseSchedulerService recargaMapas = new BaseSchedulerService("com.srm.pli.schedulers.jobs.RecargaDiariaMapasPLIJob", "recargaMapas", "srmBooking", "0 0 8 * * ?");
	private BaseSchedulerService reiniciaMapaDetalle = new BaseSchedulerService("com.srm.pli.schedulers.jobs.ReiniciaMapaDetalle", "reiniciaMapaDetalle", "srmBooking", "0 0 0/2 * * ?");
	
	

	@Override
	public void contextDestroyed(ServletContextEvent arg0) {
		if (PropertiesLoader.getInstance().getBoolean("srm.notificacionesAutomaticas")) {
			sarsVencidos.stopNotifications();
			reporteSARs.stopNotifications();
			reporteSARs2.stopNotifications();
			notifEtd.stopNotifications();
			
		}
		reiniciaMapaDetalle.stopNotifications();
		recargaMapas.stopNotifications();
	}

	@Override
	public void contextInitialized(ServletContextEvent arg0) {
		if (PropertiesLoader.getInstance().getBoolean("srm.notificacionesAutomaticas")) {
			sarsVencidos.startNotifications();
			reporteSARs.startNotifications();
			reporteSARs2.startNotifications();
			notifEtd.startNotifications();
		}
		reiniciaMapaDetalle.startNotifications();
		FuncionesComunesPLI.getProveedores(true);
	}

}
