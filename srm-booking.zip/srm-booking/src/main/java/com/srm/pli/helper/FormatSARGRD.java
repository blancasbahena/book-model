package com.srm.pli.helper;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang3.StringEscapeUtils;

import com.srm.pli.bo.FasesSARBO;
import com.srm.pli.bo.SarBO;
import com.srm.pli.bo.SarDetalleBO;
import com.srm.pli.dao.SAR_CDI_DAO;
import com.srm.pli.services.PuertosService;
import com.srm.pli.utils.EstatusUtils;
import com.srm.pli.utils.FuncionesComunesPLI;
import com.srm.pli.utils.Utilerias;
import com.truper.businessEntity.BeanDocumentosSDI;
import com.truper.businessEntity.BeanPuerto;
import com.truper.businessEntity.BeanSarChat;
import com.truper.businessEntity.BeanTransportes;
import com.truper.businessEntity.ProductoBean;

import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

@Getter
@Setter
@Slf4j
public class FormatSARGRD {
	private String folio;
	private String folioRaw;
	private String folioVista;
	private Boolean esOnHold;
	private Boolean esOnHoldSAR;
	private Boolean esOnHoldSupplier;
	private String vistaMultiples;
	private String folioVistaProv;
	private String dameIconosHTML;
	private String puertoOrigen;
	private String puertoDescarga;
	private String puertoDescargaReporte;
	private String puertoDescargaNum;
	private String puertoOrigenNum;
	private String naviera;
	private Integer cveNaviera;
	private String fechaEmbarque;
	private String etdProveedor;
	private Integer fechaEmbarqueInt;
	private Boolean consolidado;
	private String status;
	private Integer claveStatus;
	private String fechaSolicitudDeAprobacion;
	private String fechaUltimaAprobacionRechazo;
	private String tipoContenedor;
	private Integer tipoContenedorNum;
	private Integer prioridad;
	private String etdPlaner;
	private String etdReal;
	private String etdRealModificada;
	private String proveedor;
	private String proveedorClave;
	private String usuarioSolicitudDeAprobacion;
	private String usuarioApruebaRechaza;
	private String barcoSugerido;
	private String viaje;
	private String contenedor;
	private String booking;
	private String comentarioCancelacion;
	private String peso;
	private String volumen;
	private String pesoConfirmado;
	private String volumenConfirmado;
	private String folioConsolidado;
	private Integer transporte;
	private String transporteDesc;
	private String backOrderPron;
	private String backOrderPronSinFormato;
	private String overStock;
	private String colorPrioridad;
	private String colorPrioridadTxt;
	private String comentarioPlanner;
	private String comentarioShipping;
	private String valorEmbarque;
	private String valorEmbarqueConfirmado;
	private String listaPo;
	private String comentarioBooking;
	private String ida;
	private String maxIda;
	private Boolean esSinPO;
	private String eta;
	private String fechaCreacion;
	private Boolean esAereo;
	private Boolean modificadoProveedor;
	private Boolean aprobadoProveedor;
	private Boolean aceptadoConDiferencias;
	private Integer aerolinea;
	private String otraAerolinea;
	private String avion;
	private String llegadaAvion;
	private String paisDestino;
	private Boolean cargoAProveedor;
	private Boolean esMultiple;
	private String mandante;
	private String foliosMultiples;
	private String bl;
	private Boolean sarImportado;
	private Boolean cerradoDocumentosProveedor;
	private String fechaCierreDocumentosProveedor;
	private String fechaCierreDocumentosProveedorFormat;
	private String fechaAprobadoSDI;
	private String fechaAprobadoSDIFormat;
	private String fechaSolicitadoProveedor;
	private String fechaAprobadoPlannning;
	private String fechaAprobadoShipping;
	private Integer numPartidas;
	private ArrayList<FormatSARDetalle> detalle;
	private ArrayList<FormatSARDetalleOthers> detalleOthers;
	private boolean aviso;
	private String warning;
	private int pcntCumplimiento;
	private String fase;
	private Boolean aprobadoSDI;
	private Boolean esRechazadoSDI;
	private String posIncompletasImg;
	private String botonSimulador;
	private String textoWarning;
	private String colorWarning;
	private int daysInConsol;
	private String pos;
	private List<FormatSARChat> chats;
	private String daysSinceCreationDate;
	private String daysSincePlanningApproval;
	private String difPesoUserVsSis;
	private String difVolUserVsSis;
	private String varPesoUserVsSis;
	private String varVolUserVsSis;
	private String varPesoUserVsSisSinFormato;
	private String varVolUserVsSisSinFormato;
	private Boolean goodsAreReady;
	private Boolean gdrEnRevision;
	private Date goodsReadyDate;
	private String goodsReadyDateStr;
	private Boolean tieneDiferenciaMRP;
	private int cargaArchivoMRP;
	private String imagenArchivoMRP;
	private String archivoMRP;
	private String tipoRetraso;
	private String claveTipoRetraso;
	private String commentsForImpDir;
	private String piDate;
	private String safetyStock;
	private String forecastModel;
	private String var8Sem;
	private String var8SemDirectos;
	private String factPedidosDirectos;
	private String commentsImpDir;
	private String etdModificadaImpDir;
	private Boolean needAuthImpDir;
	private Boolean aprobadoDirImp;
	private Boolean cargadoMRP;
	private Boolean notificacionMRP;
	private Boolean tieneProdsNuevos;
	private String familias;
	private Boolean enRevisionConfirmFinal;
	private String commentsRevConfirmFinal;
	private String commentVendorRevFinalConfirm;
	private Boolean aprobadoRevConfirmFinal;
	private String usrApruebaRechazaRevFinal;
	private Boolean cambiosRevFinalApplied;
	private Boolean tienePedidosDirectos;
	private Boolean etdRealWarning;
	private String usrEtdRealWarning;
	private Boolean aplicaBitacoraImpDir;
	private Boolean bitacoraImpDirCerrada;
	private Boolean tieneSimulador;
	private Boolean tienePOsEliminadas;
	private Boolean tieneOthersEliminadas;
	private Boolean needsAuthPlanningMgr;
	private Boolean tieneDocumentos;
	private Boolean tieneFOCs;
	private String  condicionesPago;
	private ArrayList<String> condicionesPagoDescripcion;
	private boolean tieneMultiplesCondicionesPago;
	private String referenceNumber;
	private String versionReference;
	private String respuestaReferenceBooking;
	private boolean aceptadoCompras;
	private boolean generandoDocumentos;
	private boolean rechazadoSDI;
	private String fechaRechasoSDI;
	private String comentarioRechasoSDI;
	private ArrayList<String> erroresDocumentos;
	private boolean factuasCompletas;
	private boolean tieneOtrosDocumentos;
	private boolean preBL;
	private boolean BLGenerado;
	private boolean PackingListGenerado;
	private int idControlDocumental;
	private Boolean preciosRevisados;
	private Boolean preciosLiberados;
	private Boolean preciosEnRevision;
	private boolean revisionIDA;
	private String  fechaNuevoETDRevIDA;
	private boolean fechaIDAAceptada;
	private boolean bitacoraIDA;
	private boolean bitacoraIDACerrada;
	private int  versionDocumentos;
	private String almacen;
	private String moneda;
	private boolean tieneTSRAbiertos; 
	private boolean tieneTSRResueltos;
	private Integer tinyFechIniProfileApproved;
	private String commentProfiles;
	
	private String obs_reject;

	// Bandera para saber si los documentos van por fuera de F&R.
	@Getter
	@Setter
	private boolean bloqueoDocumentos;
	
	private String bookingUpdateSupplier;
	private int carrierUpdateSupplier;
	private String carrierNameUpdateSupplier;
	private Date dateETDFinalUpdateSupplier;
	private String referenciaContenedorProveedor;
	
	private List<String> POsByFolioSAR;

	private boolean pm;
	private boolean sife;
	
	private Integer folioSife;
	private String statusSife;
	
	public FormatSARGRD() {
		POsByFolioSAR = new ArrayList<String>();
	}
	
	public FormatSARGRD(SarBO sar, Locale locale) throws ClassNotFoundException {
		this(sar, locale, false);
		System.out.println("Servicio -----  00000000 "+ sar.getFolio());
	}
	
	public FormatSARGRD(SarBO sar, Locale locale, boolean vistaProveedor) throws ClassNotFoundException {
		if (locale == null) {
			locale = new Locale("es","MX");
		}
		try {
System.out.println("Servicio -----  0 - "+ sar.getFolio());
			List<SarBO> foliosList = new ArrayList<>();
			foliosList.add(sar);
System.out.println("Servicio -----  0 - "+ sar.getFolio());
			Map<Integer, FasesSARBO> valores = EstatusUtils.datosAvanceSAR(foliosList, locale, vistaProveedor);
System.out.println("Servicio -----  0 - "+ sar.getFolio());
			FasesSARBO avancesFolio = valores.get(sar.getFolio());
System.out.println("Servicio -----  1"+ sar.getFolio());
			FuncionesComunesPLI.cargaPuertosOrigen(false);
			FuncionesComunesPLI.cargaPuertosDirectos(false);
			FuncionesComunesPLI.cargaPuertosDestino(false);
			FuncionesComunesPLI.cargaNavieras(false);
			FuncionesComunesPLI.cargaContenedores(false);
			BeanPuerto ptoOrigen = FuncionesComunesPLI.mapaPuertosOrigen == null ? null
					: FuncionesComunesPLI.mapaPuertosOrigen.get(sar.getPuertoOrigen());
System.out.println("Servicio -----  2"+ sar.getFolio());
			String ptoDestino = "";
			GregorianCalendar gc = new GregorianCalendar();
			int hoy = FuncionesComunesPLI.gregorianCalendar2int(gc);
			tienePedidosDirectos = sar.tienePedidoDirecto();
			almacen = sar.getAlmacen();
System.out.println("Servicio -----  3"+ sar.getFolio());
			
			if (tienePedidosDirectos) {
				System.out.println("Servicio -----  3.1 "+ sar.getFolio());
				BeanPuerto ptoDirecto = PuertosService.getInstance().getPuertosDirectos() == null ? null
						: PuertosService.getInstance().getPuertosDirectos().get(sar.getPuertoDescarga());
				ptoDestino = ptoDirecto == null ? null : ptoDirecto.getNombre();
				System.out.println("Servicio -----  3.1 FIN "+ sar.getFolio());
			} else {
				System.out.println("Servicio -----  3.2"+ sar.getFolio());
				BeanPuerto ptoDes = FuncionesComunesPLI.mapaPuertosDestino.get(sar.getPuertoDescarga());
				ptoDestino = ptoDes== null ? "" : ptoDes.getNombre();
				System.out.println("Servicio -----  3.2 FIN 2"+ sar.getFolio());
			}
			folio = "F" + sar.getFolio();
System.out.println("Servicio -----  4.0  -->"+ sar.getFolio());
			bookingUpdateSupplier = sar.getBookingUpdateSupplier();
			carrierUpdateSupplier = sar.getCarrierUpdateSupplier();
			carrierNameUpdateSupplier = sar.getCarrierNameUpdateSupplier();
			dateETDFinalUpdateSupplier = sar.getDateETDFinalUpdateSupplier();
			folioRaw = String.valueOf(sar.getFolio());
System.out.println("Servicio -----  4 "+ sar.getFolio());
			String folioVista = sar.armaFolioVista();
			this.folioVista = folioVista;
			esOnHold = sar.isSarOnHold() == null ? false : sar.isSarOnHold();
			esOnHoldSAR = sar.isSarOnHoldBySAR() == null ? false : sar.isSarOnHoldBySAR();
			esOnHoldSupplier = sar.isSarOnHoldBySupplier() == null ? false : sar.isSarOnHoldBySupplier();
			vistaMultiples = sar.getMultipleHtml() != null ? sar.getMultipleHtml() : "";
			fechaIDAAceptada = sar.isAcceptedIDAValidation();
			String iconosSARHTML = sar.dameIconosSARHtml(true);
System.out.println("Servicio -----  5 "+ sar.getFolio());
		    folioVistaProv = sar.getFolio() + iconosSARHTML;
		    dameIconosHTML = iconosSARHTML != null && !"".equals(iconosSARHTML) ? "<br>" + iconosSARHTML : "";
		    bitacoraIDA = sar.isBitacoraIDA();
		    bitacoraIDACerrada = sar.isBitacoraIDACerrada();
			puertoOrigen = ptoOrigen != null ? StringEscapeUtils
					.escapeHtml3(ptoOrigen.getNombre()) : "-";
			puertoDescarga = ptoDestino != null ? StringEscapeUtils
					.unescapeJson(ptoDestino) : "-";
System.out.println("Servicio -----  6 "+ sar.getFolio());
			puertoDescargaReporte = ptoDestino != null ? ptoDestino : "-";
			puertoDescargaNum = sar.getPuertoDescarga();
			puertoOrigenNum = sar.getPuertoOrigen();
			goodsAreReady=sar.getGoodsAreReady();
			gdrEnRevision= sar.getGdrEnRevision() == null ? false: sar.getGdrEnRevision();
			goodsReadyDate = sar.getGoodsReadyDate();
			goodsReadyDateStr =  sar.getGoodsReadyDateStr();
			commentProfiles = sar.getCommentProfiles();
System.out.println("Servicio -----  7 "+ sar.getFolio());
			tinyFechIniProfileApproved = sar.getTinyFechIniProfileApproved();
			if (sar.getNaviera() == null) {
				naviera = "-";
			} else {
				naviera = FuncionesComunesPLI.mapaNavieras.get(sar.getNaviera()) != null ? FuncionesComunesPLI
						.mapaNavieras.get(sar.getNaviera()).getNombre()
						: "-";
				cveNaviera = sar.getNaviera();
			}
System.out.println("Servicio -----  8 "+ sar.getFolio());
			fechaEmbarque = sar.getFechaEmbarque() == null ? "-"
					: FuncionesComunesPLI.formateaFechaYYYYMMDD(sar
							.getFechaEmbarque());
			
			etdProveedor = sar.getEtdProveedor() == null ? "-"
					: FuncionesComunesPLI.formateaFechaYYYYMMDD(sar
							.getEtdProveedor());
			revisionIDA = sar.isEnRevicionIDA();
			fechaNuevoETDRevIDA = (sar.getNuevaFechaETD_IDA() == null || sar.getNuevaFechaETD_IDA().intValue() == 0) ? "-"
					: FuncionesComunesPLI.formateaFechaYYYYMMDD(sar.getNuevaFechaETD_IDA()); 
			fechaEmbarqueInt = sar.getFechaEmbarque() == null ? 0 : sar
					.getFechaEmbarque();
			consolidado = sar.getConsolidado() == null ? false : sar
					.getConsolidado();
System.out.println("Servicio -----  9 "+ sar.getFolio()); 
			status = avancesFolio != null ? avancesFolio.getLeyenda() : "" ;
			claveStatus = sar.getStatus();
			tipoRetraso = sar.getTipoRetraso() == null ? "" : FuncionesComunesPLI.getTipoRetraso() == null ? "" : 
				FuncionesComunesPLI.getTipoRetraso().get(sar.getTipoRetraso());
			claveTipoRetraso = sar.getTipoRetraso() == null ? "-1" : sar.getTipoRetraso().toString();
			fechaSolicitudDeAprobacion = sar.getFechaSolicitudDeAprobacion() == null ? "-"
					: FuncionesComunesPLI.formateaFecha(sar
							.getFechaSolicitudDeAprobacion());
			fechaUltimaAprobacionRechazo = sar.getFechaUltimaAprobacionRechazo() == null ? "-"
					: FuncionesComunesPLI.formateaFecha(sar
							.getFechaUltimaAprobacionRechazo());
			tipoContenedor = FuncionesComunesPLI.mapaContenedores.get(
					sar.getTipoContenedor()) != null ? FuncionesComunesPLI
					.mapaContenedores.get(sar.getTipoContenedor()).getNombre()
					: "-";
System.out.println("Servicio -----  10 "+ sar.getFolio());
			tipoContenedorNum = sar.getTipoContenedor();
			prioridad = sar.getPrioridad();
			etdPlaner = (sar.getEtdPlanner() == null || sar.getEtdPlanner() == 0) ? "-"
					: FuncionesComunesPLI
							.formateaFechaYYYYMMDD(sar.getEtdPlanner());
			etdReal = (sar.getEtdReal() == null || sar.getEtdReal() == 0) ? "-"
					: FuncionesComunesPLI.formateaFechaYYYYMMDD(sar.getEtdReal());
			etdRealModificada = (sar.getEtdModificada() == null || sar.getEtdModificada() == 0) ? "-"
					: FuncionesComunesPLI.formateaFechaYYYYMMDD(sar.getEtdModificada());
			proveedor = sar.getProveedor() != null
					&& FuncionesComunesPLI.getProveedor(sar.getProveedor()) != null ? FuncionesComunesPLI
					.getProveedor(sar.getProveedor()).getNombreProveedor() : "-";
System.out.println("Servicio -----  11 "+ sar.getFolio());
			proveedorClave = sar.getProveedor();
			usuarioSolicitudDeAprobacion = StringEscapeUtils.escapeHtml3(sar
					.getUsuarioSolicitudDeAprobacion());
			usuarioApruebaRechaza = StringEscapeUtils.escapeHtml3(sar
					.getUsuarioApruebaRechaza());
			barcoSugerido = sar.getBarcoSugerido() != null ? StringEscapeUtils
					.escapeHtml3(sar.getBarcoSugerido()) : "-";
			viaje = sar.getViaje() != null ? StringEscapeUtils.escapeHtml3(sar
					.getViaje()) : "-";
System.out.println("Servicio -----  12 "+ sar.getFolio());
			contenedor = sar.getContenedor() != null ? StringEscapeUtils
					.escapeHtml3(sar.getContenedor()) : "-";
			booking = sar.getBooking() != null ? StringEscapeUtils.escapeHtml3(sar
					.getBooking()) : "";
			comentarioCancelacion = StringEscapeUtils.escapeHtml3(sar
					.getComentarioCancelacion());
			peso = FuncionesComunesPLI.formatea(sar.getPeso(), 0);
			volumen = FuncionesComunesPLI.formatea(sar.getVolumen(), 2);
			pesoConfirmado = FuncionesComunesPLI.formatea(sar.getPesoConfirmado(),
					0);
System.out.println("Servicio -----  13 "+ sar.getFolio());
			volumenConfirmado = FuncionesComunesPLI.formatea(
					sar.getVolumenConfirmado(), 2);
			folioConsolidado = sar.getFolioConsolidado() != null ? sar
					.getFolioConsolidado().toString() : "N.D";
			transporte = sar.getTransporte() != null ? sar.getTransporte() : 0;
			transporteDesc = sar.getTransporte() != null
					&& BeanTransportes.transportesCDI.get(sar.getTransporte()) != null ? StringEscapeUtils
					.escapeHtml3(BeanTransportes.transportesCDI.get(sar
							.getTransporte())) : "-";
System.out.println("Servicio -----  14 "+ sar.getFolio());
			backOrderPron = sar.getBackorderPronosticadoTot() != null ? FuncionesComunesPLI
					.formatea(sar.getBackorderPronosticadoTot().doubleValue(), 0)
					: "0";
			backOrderPronSinFormato = sar.getBackorderPronosticadoTot() != null ? FuncionesComunesPLI
					.formatea(sar.getBackorderPronosticadoTot().doubleValue(), 0, false)
					: "0";
			overStock = sar.getOverStockTot() != null ? FuncionesComunesPLI.formatea(sar.getOverStockTot(), 0) : "0";
			colorPrioridad = sar.getPrioridad() != null ? sar.getPrioridad() == 1 ? SarBO.COLOR_BLANCO
					: (sar.getPrioridad() == 2 ? SarBO.COLOR_ROJO
							: SarBO.COLOR_MORADO)
					: "";
System.out.println("Servicio -----  15 "+ sar.getFolio());
			colorPrioridadTxt = sar.getPrioridad() != null ? sar.getPrioridad() == 1 ? "White"
					: (sar.getPrioridad() == 2 ? "Red" : "Purple")
					: "";
			String commentFakeForTest = StringEscapeUtils.escapeHtml3(sar
					.getComentarioPlanner());
			comentarioPlanner = commentFakeForTest;
			comentarioShipping = StringEscapeUtils.escapeHtml3(sar
					.getComentarioShipping());
			valorEmbarque = sar.getValorEmbarque() != null ? FuncionesComunesPLI
					.formatea(sar.getValorEmbarque().doubleValue(), 0) : "0";
			valorEmbarqueConfirmado = sar.getValorEmbarque() != null ? FuncionesComunesPLI
					.formatea(sar.getValorEmbarqueConfirmado().doubleValue(), 0)
					: "0";
System.out.println("Servicio -----  16 "+ sar.getFolio());
			listaPo = sar.getListaPos() != null ? sar.getListaPos().toString() : "";
			comentarioBooking = sar.getComentarioTruperBooking() != null ? StringEscapeUtils
					.escapeHtml3(sar.getComentarioTruperBooking()) : "";
			ida = sar.getIda() != null ? String.valueOf(sar.getIda()) : "N.D";
			maxIda = sar.getMaxIda() != null ? String.valueOf(sar.getMaxIda()) : "N.D";
			esSinPO = sar.getEsSinPO() != null && sar.getEsSinPO() ? true : false;
			eta = sar.getEta() == null || sar.getEta() == 0 ? "-"
					: FuncionesComunesPLI.formateaFechaYYYYMMDD(sar.getEta());
			fechaCreacion = sar.getCreationDate() != null
					&& sar.getCreationDate() != 0 ? FuncionesComunesPLI
					.formateaFechaYYYYMMDD(sar.getCreationDate()) : "N.D";
System.out.println("Servicio -----  17 "+ sar.getFolio());
			esAereo = sar.getEsAereo() != null ? sar.getEsAereo() : false;
			modificadoProveedor = sar.getModificadoProveedor() != null ? sar
					.getModificadoProveedor() : false;
			aprobadoProveedor = sar.getAprobadoProveedor() != null ? sar
					.getAprobadoProveedor() : false;
			aceptadoConDiferencias = sar.getAceptadoConDiferencias() != null ? sar
					.getAceptadoConDiferencias() : false;
			aerolinea = sar.getAerolinea() != null ? sar.getAerolinea() : -1;
			otraAerolinea = sar.getOtraAerolinea() != null ? sar.getOtraAerolinea()
					: "-";
System.out.println("Servicio -----  18 "+ sar.getFolio());
			avion = sar.getAvion() != null ? sar.getAvion() : "ND";
			llegadaAvion = sar.getLlegadaAvion() != null ? String.valueOf(sar
					.getLlegadaAvion()) : "-1";
			paisDestino = sar.getPaisDestino() != null ? String.valueOf(sar
					.getPaisDestino()) : "-1";
			cargoAProveedor = sar.getCargoAProveedor() != null ? sar
					.getCargoAProveedor() : false;
			esMultiple = sar.getEsMultiple() != null ? sar.getEsMultiple() : null;
			mandante = sar.getMandante() != null ? String
					.valueOf(sar.getMandante()) : "";
System.out.println("Servicio -----  19 "+ sar.getFolio());
			foliosMultiples = sar.getFoliosMultiples() != null ? sar
					.getFoliosMultiples() : "";
			bl = sar.getBl() != null ? sar.getBl() : "N.D";
			setTieneDocumentos(sar.isTieneDocumentos());
			sarImportado = FuncionesComunesPLI.elSarEsImportado(sar);
			cerradoDocumentosProveedor = sar.getCerradoDocumentosProveedor() != null ? sar
					.getCerradoDocumentosProveedor() : false;
			aprobadoSDI = sar.getAprobadoSDI() != null ? sar.getAprobadoSDI()
					: false;
System.out.println("Servicio -----  19 "+ sar.getFolio());
			String fechaCierreDocsProv = sar.getFechaCierreDocumentosProveedor() != null ? sar
					.getFechaCierreDocumentosProveedor().toString() : "";
			String fechaAprovSDI = sar.getFechaAprobadoSDI() != null ? sar
					.getFechaAprobadoSDI().toString() : "";
			fechaCierreDocumentosProveedor = fechaCierreDocsProv;
			fechaCierreDocumentosProveedorFormat = fechaCierreDocumentosProveedor != null
					&& !"".equals(fechaCierreDocumentosProveedor) ? String
					.valueOf(FuncionesComunesPLI.formateaFecha(Integer
							.parseInt(fechaCierreDocumentosProveedor))) : "N.D";
			fechaAprobadoSDI = fechaAprovSDI;
System.out.println("Servicio -----  20 "+ sar.getFolio());
			fechaAprobadoSDIFormat = fechaAprobadoSDI != null
					&& !"".equals(fechaAprobadoSDI) ? String
					.valueOf(FuncionesComunesPLI.formateaFecha(Integer
							.parseInt(fechaAprobadoSDI))) : "N.D";
			fechaSolicitadoProveedor = sar.getTinyFecIniPlanning() != null
					&& sar.getTinyFecIniPlanning() > 0 ? String
					.valueOf(FuncionesComunesPLI.formateaFecha(sar
							.getTinyFecIniPlanning())) : "N.D";
System.out.println("Servicio -----  21 "+ sar.getFolio());
			fechaAprobadoPlannning = sar.getTinyFecIniShipping() != null
					&& sar.getTinyFecIniShipping() > 0 ? String
					.valueOf(FuncionesComunesPLI.formateaFecha(sar
							.getTinyFecIniShipping())) : "N.D";
			if (consolidado) {
				fechaAprobadoShipping = sar.getTinyFecIniConsolidados() != null
						&& sar.getTinyFecIniConsolidados() > 0 ? String
						.valueOf(FuncionesComunesPLI.formateaFecha(sar
								.getTinyFecIniConsolidados())) : "N.D";
			} else {
				fechaAprobadoShipping = sar.getTinyFecIniBooking() != null
						&& sar.getTinyFecIniBooking() > 0 ? String
						.valueOf(FuncionesComunesPLI.formateaFecha(sar
								.getTinyFecIniBooking())) : "N.D";
			}
System.out.println("Servicio -----  22 "+ sar.getFolio());
			//
			erroresDocumentos = sar.getErroresDocumentos();
			
			daysInConsol = sar.getTinyFecIniConsolidados() == null ? 0 : (int) FuncionesComunesPLI.daysBetween(sar.getTinyFecIniConsolidados(), hoy);
			daysSinceCreationDate = (sar.getTinyFecIniPlanning()==null || sar.getTinyFecIniPlanning() == 0) ? "N.D." : FuncionesComunesPLI.formatea(Utilerias.diasHabiles(sar.getTinyFecIniPlanning(), hoy, false));
			daysSincePlanningApproval = (sar.getTinyFecIniShipping()==null || sar.getTinyFecIniShipping() == 0) ? "N.D." : FuncionesComunesPLI.formatea(Utilerias.diasHabiles(sar.getTinyFecIniShipping(), hoy, false));
			if (sar.getDetalle() != null) {
				// /Si es multiple quiero usar el ordenamieto que le doy antes no
				// este por eso lo quito
				if (esMultiple == null || !esMultiple) {
					Collections.sort(sar.getDetalleBO(), new Comparator<SarDetalleBO>() {
						@Override
						public int compare(SarDetalleBO o1, SarDetalleBO o2) {
							String x1 = o1.getPo();
							String x2 = o2.getPo();
							int sComp = x1.compareTo(x2);
	
							if (sComp != 0) {
								return sComp;
							} else {
								Integer i1 = o1.getPosicion();
								Integer i2 = o2.getPosicion();
								return i1 - i2;
							}
						}
					});
				}
System.out.println("Servicio -----  23 "+ sar.getFolio());
				numPartidas = sar.getDetalle().size();
				detalle = new ArrayList<FormatSARDetalle>();
				Set<String> setPos = new LinkedHashSet<String>();
				Set<String> setFamilias = new LinkedHashSet<String>();
				tieneFOCs = sar.getTieneFOCs();
				String condPago = "";
				condicionesPago = "";
				condicionesPagoDescripcion = new ArrayList<String>();
				int contador = 0;
	//			condicionesPago = condicionesPago != null ? condicionesPago : "";
				for (SarDetalleBO det : sar.getDetalleBO()) {
					ProductoBean p = FuncionesComunesPLI.productos.get(det.getMaterial().toString());
					setPos.add(det.getPo());
					if (p != null && p.getFamilia() != null) {
						setFamilias.add(StringEscapeUtils.escapeHtml3(p.getFamilia()));
					}
					condPago = det.getCondicionPago();
System.out.println("Servicio -----  24 "+ sar.getFolio());
					if(condPago != null && !condicionesPago.contains(condPago)) {//tieneMultiplesCondicionesPago
						
						try {
							String cdPago;
							cdPago = condPago + "|"+ FuncionesComunesPLI.dameMapaCondicionPago(false).get(condPago);
							condicionesPagoDescripcion.add(cdPago);
						} catch (SQLException e) {
							
						}
						
						if(contador > 0) {
							condPago =","+condPago;
							tieneMultiplesCondicionesPago = true;
						}
						condicionesPago += condPago;
						
						moneda = det.getMoneda();
						
						contador++;
					}
System.out.println("Servicio -----  25 "+ sar.getFolio());
					//condicionesPago += (condPago != null && !condicionesPago.contains(condPago) ) ?  condPago+"," : "";
					FormatSARDetalle formatDetalle = new FormatSARDetalle(det,sar.dameETDDelSAR()); 
					detalle.add(formatDetalle);
				}
				pos = (String) (setPos.isEmpty()?"N.D.":setPos.size()>1?((String)setPos.toArray()[0]).trim()
						+ "<img title='various' src='/srm_booking/images/plus.png'>":((String)setPos.toArray()[0]).trim());
				familias = (String) (setFamilias.isEmpty() ? "N.D." : Arrays.toString(setFamilias.toArray()));
			} else {
				numPartidas = 0;
			}
System.out.println("Servicio -----  26 "+ sar.getFolio());
			if (sar.getDetalleOtros() != null) {
				
				Collections.sort(sar.getDetalleOthers(), new Comparator<SarDetalleBO>() {
					@Override
					public int compare(SarDetalleBO o1, SarDetalleBO o2) {
						Integer i1 = o1.getPosicion();
						Integer i2 = o2.getPosicion();
						return i1 - i2;
					}
				});
				detalleOthers = new ArrayList<FormatSARDetalleOthers>();
				for (SarDetalleBO det : sar.getDetalleOthers()) {
					FormatSARDetalleOthers formatDetalleOthers = new FormatSARDetalleOthers(det);
					detalleOthers.add(formatDetalleOthers);
				}
				numPartidas += sar.getDetalleOtros().size();
			}
System.out.println("Servicio -----  27 "+ sar.getFolio());
			difPesoUserVsSis = sar.getDifPesoUserVSSystem() == null ? "N.D." : FuncionesComunesPLI.formatea(sar.getDifPesoUserVSSystem(),2);
			double varPeso = (sar.getDifPesoUserVSSystem() == null ? 0d : sar.getDifPesoUserVSSystem()) * 100 / sar.getPeso();
			varPesoUserVsSis = FuncionesComunesPLI.formatea(varPeso,0);
			varPesoUserVsSisSinFormato = FuncionesComunesPLI.formatea(varPeso,0,false);
			
			difVolUserVsSis = sar.getDifVolUserVSSystem() == null ? "N.D." : FuncionesComunesPLI.formatea(sar.getDifVolUserVSSystem(),2);
			double varVol = (sar.getDifVolUserVSSystem() == null ? 0d : sar.getDifVolUserVSSystem()) * 100 / sar.getVolumen();
			varVolUserVsSis = FuncionesComunesPLI.formatea(varVol,0);
			varVolUserVsSisSinFormato = FuncionesComunesPLI.formatea(varVol,0,false);
			
System.out.println("Servicio -----  28 "+ sar.getFolio());
			archivoMRP = sar.getNombreArchivoMRP();
			if(sar.calculaSitieneDiferenciaMRP()  != null && sar.calculaSitieneDiferenciaMRP() ){
				int carga = sar.getCargadoMRP() == null ? 0 : sar.getCargadoMRP() ? 1 : 0;
				if( carga == 0){
					//No hay archivo cargado es icono en blanco
					setImagenArchivoMRP("<i class=\"fa fa-file-pdf-o fa-2x\" aria-hidden=\"true\" style=\"color:#CFCFCF; text-align:top;\"></i>");
				}else{
					setImagenArchivoMRP("<a href=\"/srm_booking/Planning?accion=generaArchivoMRP&folio=" + folioRaw + "\" download"+ 
							" style=\"cursor: pointer;\" target=\"_blank\"> "+
							"<i class=\"fa fa-file-pdf-o fa-2x boton iconosAwesome\" aria-hidden=\"true\" style=\"color:#047870; text-align:top;\"></i></a>");
				}
			}else{
				setImagenArchivoMRP("");
			}
System.out.println("Servicio -----  29 "+ sar.getFolio());
			setTieneDiferenciaMRP(sar.calculaSitieneDiferenciaMRP());
			setCargaArchivoMRP(sar.getCargaArchivoMRP() != null ? sar.getCargaArchivoMRP() : 0);
			
			setAviso(sar.isAviso());
			setWarning(sar.getWarning());
			
			sar.setCumplimiento(avancesFolio != null && avancesFolio.getPorcentajeAvance() != null ? avancesFolio.getPorcentajeAvance() : 0);
			
			setPcntCumplimiento(sar.getCumplimiento());
			setFase(sar.getFase());
			esRechazadoSDI = sar.getEsRechazadoSDI();
System.out.println("Servicio -----  30 "+ sar.getFolio());
			String imgAccept = "<img class='boton readOnly' hspace='1' title='Accept SAR' width='20px' height='20px' onclick='acceptRow("
					+ folioRaw + ");' src='/srm_booking/images/agree.png'>";
			///quito la llave, ya que pasando shipping la cantidad deberia ser la misma, por el cambio de SAP en catidad de PO
			posIncompletasImg = imgAccept;
			if(sar.getTieneSimulador() != null && true == sar.getTieneSimulador()){
				botonSimulador = "<span id=\"span_"+sar.getFolio()+"\" class=\"fa-stack  boton\" style=\"vertical-align: top; display: inline-block; color:#5f6867;\" >";     
				botonSimulador += "<i class=\"fa fa-circle fa-stack-2x boton iconosAwesome\" style=\"vertical-align: middle; display: inline-block; \" ></i>";
				botonSimulador += "<i class=\"fa fa-line-chart fa-stack-1x fa-inverse boton iconosAwesome\" style=\"vertical-align: middle; display: inline-block; \" aria-hidden=\"true\"  title=\"Simulator view\" onclick=\"muestraSimulador('"+sar.getFolio()+"');\"></i>";
				botonSimulador += "</span>";
			}else{
				botonSimulador = "<span id=\"span_"+sar.getFolio()+"\" class=\"fa-stack  boton\" style=\"vertical-align: top; display: inline-block; \" >";
				botonSimulador += "<i class=\"fa fa-circle-o fa-stack-2x boton iconosAwesome\" style=\"vertical-align: middle; display: inline-block; \"></i>";
				botonSimulador += "<i class=\"fa fa-line-chart fa-stack-1x boton iconosAwesome\" aria-hidden=\"true\" style=\"vertical-align: middle; display: inline-block; \" title=\"Simulator view\" onclick=\"muestraSimulador('"+sar.getFolio()+"');\"></i>";
				botonSimulador += "</span>";
			}
System.out.println("Servicio -----  31 "+ sar.getFolio());
			if ((varPeso < -5d || varPeso > 5d) && varVol > -5d && varVol < 5d) {
				sar.setColorWarning("");
				sar.setTextoWarning("The SAR does not have the correct weight, please check.");
			}
			if ((varVol < -5d || varVol > 5d) && varPeso > -5d && varPeso < 5d) {
				sar.setColorWarning("");
				sar.setTextoWarning("The SAR does not have the correct volume, please check.");
			}
			if ((varPeso <= -5d || varPeso >= 5d) && (varVol <= -5d || varVol >= 5d)) {
				sar.setColorWarning("");
				sar.setTextoWarning("The SAR does not have either the correct weight and volume, please check.");
			}
System.out.println("Servicio -----  31 "+ sar.getFolio());
			textoWarning = sar.getTextoWarning();
			colorWarning = sar.getColorWarning();
			if (sar.getLstChat()!=null) {
				chats = new ArrayList<FormatSARChat>();
				for (BeanSarChat beanChat : sar.getLstChat()) {
					FormatSARChat formatChat = new FormatSARChat(beanChat);
					chats.add(formatChat);
				}
			}
System.out.println("Servicio -----  32 "+ sar.getFolio());
			commentsForImpDir = sar.getCommentForImpDir() == null ? "" : StringEscapeUtils.escapeHtml3(sar.getCommentForImpDir());
			piDate = sar.getPiDate() == null ? "N.D." : FuncionesComunesPLI.formateaFecha(sar.getPiDate());
			safetyStock = sar.getSafetyStock() == null ? "N.D." : FuncionesComunesPLI.formatea(sar.getSafetyStock(), 0);
			forecastModel = sar.getForecastModel() == null ? "N.D." : sar.getForecastModel();
			var8Sem = sar.getVar8Sem() == null ? "N.D." : FuncionesComunesPLI.formatea(sar.getVar8Sem(),0);
			var8SemDirectos = sar.getVar8SemanasDirectos() == null ? "N.D" : FuncionesComunesPLI.formatea(sar.getVar8SemanasDirectos(),0);
			factPedidosDirectos = sar.getFacturacionPedidosDirectos() == null ? "N.D" : FuncionesComunesPLI.formatea(sar.getFacturacionPedidosDirectos(),0);
			tienePedidosDirectos = sar.tienePedidoDirecto();
System.out.println("Servicio -----  33 "+ sar.getFolio());
			commentsImpDir = sar.getImpDirComments() == null ? "" : StringEscapeUtils.escapeHtml3(sar.getImpDirComments());
			etdModificadaImpDir = sar.getAdelantoAtrasoETDImpDir() == null ? "0" : sar.getAdelantoAtrasoETDImpDir().toString();
			needAuthImpDir = sar.getNeedsAuthImpDir() == null ? false : sar.getNeedsAuthImpDir();
			aprobadoDirImp = sar.getAprobadoDirImportaciones() == null ? false : sar.getAprobadoDirImportaciones();
			cargadoMRP = sar.getCargadoMRP() == null ? false : sar.getCargadoMRP();
			notificacionMRP = sar.getNotificacionMRP() == null ? false : sar.getNotificacionMRP();
System.out.println("Servicio -----  34 "+ sar.getFolio());
			tieneProdsNuevos = sar.getTieneProdsNuevos() == null ? false : sar.getTieneProdsNuevos();
			enRevisionConfirmFinal = sar.getEnRevisionConfirmFinal() == null ? false : sar.getEnRevisionConfirmFinal();
			commentsRevConfirmFinal = sar.getCommentRevFinalConfirm() == null ? "N.D." : StringEscapeUtils.escapeHtml3(sar.getCommentRevFinalConfirm());
			commentVendorRevFinalConfirm = sar.getCommentVendorRevFinalConfirm() == null ? "N.D." : StringEscapeUtils.escapeHtml3(sar.getCommentVendorRevFinalConfirm());
			aprobadoRevConfirmFinal = sar.getAceptadoRevFinalConfirm();
			usrApruebaRechazaRevFinal = StringEscapeUtils.escapeHtml3(sar.getUsrAceptaRechazaRevFinal());
			setCambiosRevFinalApplied(sar.getCambiosRevFinalApplied() == null ? Boolean.FALSE : sar.getCambiosRevFinalApplied());
System.out.println("Servicio -----  34 "+ sar.getFolio());
			etdRealWarning = sar.getEtdRealWarning() == null ? Boolean.FALSE : sar.getEtdRealWarning();
			usrEtdRealWarning = sar.getUsrEtdRealWarning() == null ? "" : sar.getUsrEtdRealWarning();
			aplicaBitacoraImpDir = sar.getAplicaBitacora() == null ? Boolean.FALSE : sar.getAplicaBitacora();
			bitacoraImpDirCerrada = sar.getBitacoraImportsDirCerrada() == null ? Boolean.FALSE : sar.getBitacoraImportsDirCerrada();
			tienePOsEliminadas = sar.isTienePOsEliminadas();
			tieneOthersEliminadas = sar.isTieneOthersEliminadas();
			needsAuthPlanningMgr = sar.getNeedsAuthPlanningMgr() == null ? Boolean.FALSE : sar.getNeedsAuthPlanningMgr();
System.out.println("Servicio -----  35 "+ sar.getFolio());
			tieneSimulador = sar.getTieneSimulador() != null ? sar.getTieneSimulador() : false;
			preciosRevisados = sar.getPreciosRevisados();
			preciosLiberados = sar.getPreciosLiberados();
			preciosEnRevision = sar.getPreciosEnRevision();
			aceptadoCompras = Boolean.TRUE.equals(sar.getPreciosLiberados());
			generandoDocumentos = false;
			fechaRechasoSDI = "";
			comentarioRechasoSDI = "";
			rechazadoSDI = false;
System.out.println("Servicio -----  36 "+ sar.getFolio());
			versionDocumentos = sar.getVersionSDI() != null ? sar.getVersionSDI() : 0; 
			///voy por los datos de codumentos
			if(sar.getVersionSDI() != null) {
				ArrayList<BeanDocumentosSDI> documentos = SAR_CDI_DAO.getInstance().selectDocumentosSDI(sar.getVersionSDI(), booking, proveedorClave);
				if(documentos != null && documentos.size() > 0) {
					factuasCompletas = Boolean.TRUE.equals(documentos.get(0).getFacturasCompletas());
					preBL = Boolean.TRUE.equals(documentos.get(0).getPreBLGenerado());
					BLGenerado = Boolean.TRUE.equals(documentos.get(0).getBlGenerado());
					PackingListGenerado = Boolean.TRUE.equals(documentos.get(0).getPackingListGenerado());
					idControlDocumental = documentos.get(0).getId();
					generandoDocumentos = true;
					fechaRechasoSDI = documentos.get(0).getFechaRechazo() != null ? documentos.get(0).getFechaRechazo()+"" : "";
					comentarioRechasoSDI = documentos.get(0).getComentariosSDI();
					rechazadoSDI = documentos.get(0).getFechaRechazo() != null;
					tieneOtrosDocumentos = Boolean.TRUE.equals(documentos.get(0).getTieneOtrosDocumentos());
				}
			}
System.out.println("Servicio -----  37 "+ sar.getFolio());
			tieneTSRAbiertos = sar.getTieneTSRAbiertos() != null && sar.getTieneTSRAbiertos();
			tieneTSRResueltos  = sar.getTieneTSRResueltos() != null && sar.getTieneTSRResueltos();
			statusSife = sar.getStatusSife()!= null ? sar.getStatusSife(): null;
			folioSife = sar.getFolioSife();
			obs_reject = sar.getObs_reject() == null ? "N.D." : sar.getObs_reject();
System.out.println("Servicio -----  38 "+ sar.getFolio());
			setPm(sar.isPm());
			setSife(sar.isSife());
			
			setFolioSife(sar.getFolioSife());
			setStatusSife(sar.getStatusSife());
			referenciaContenedorProveedor = sar.getReferenciaContenedorProveedor();
System.out.println("Servicio -----  39 "+ sar.getFolio());
			// /esta debe ser la ultima linea por que guardo el BO como respaldo
			sar.setSarBOAntesFormato(sar);
			//sar.setFormatSARFormatoTemp(this);
System.out.println("Servicio -----  40 "+ sar.getFolio());
		}catch(Exception ex) {
			System.out.println("Problemas con FormatSAR folio :: "+ sar.getFolio());
			log.info("Problemas con FormatSAR folio :: {}", sar.getFolio());
		}
	}
	

}
