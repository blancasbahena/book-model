package com.srm.pli.bo;

import java.io.Serializable;
import java.util.Objects;

import lombok.Data;

@Data
public class PlaneadorBeanBO implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String idPlaneador;
	private String nombre;
	private String [] correos;
	private String gerente;
	private String correoGerente;
	private String identificadorPlaneador;
	private String identificadorGerente;
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PlaneadorBeanBO other = (PlaneadorBeanBO) obj;
		return Objects.equals(nombre, other.nombre);
	}
	
	@Override
	public int hashCode() {
		return Objects.hash(nombre);
	}
	
}
