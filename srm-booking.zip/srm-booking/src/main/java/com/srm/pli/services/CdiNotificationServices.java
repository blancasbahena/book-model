package com.srm.pli.services;

import java.sql.SQLException;
import java.util.Date;

import javax.mail.MessagingException;
import javax.servlet.ServletException;

import com.truper.infra.loggers.BaseLogger;

import lombok.extern.log4j.Log4j2;

@Log4j2
public class CdiNotificationServices {
	private static CdiNotificationServices instance;
	private final CdiNotificationBuilderServices service = CdiNotificationBuilderServices.getInstance();
	
	private CdiNotificationServices() {
	}

	static {
		instance = new CdiNotificationServices();
	}

	public static CdiNotificationServices getInstance() {
		return instance;
	} 

	public void enviaNotificacionesEtaCdi() {
		try {
			BaseLogger.SCHEDULER_LOGGER.debug("Enviando notificaciones...");
			service.enviaNotificacionProveedorSinBooking();
			BaseLogger.SCHEDULER_LOGGER.debug("Termina envio de notificaciones.");
		} catch (MessagingException e) {
			BaseLogger.SCHEDULER_LOGGER.error("Error en envio de notificaciones el dia: " + new Date(), e);
		} catch (SQLException e) {
			BaseLogger.SCHEDULER_LOGGER.error("Error en envio de notificaciones el dia: " + new Date(), e);
		} catch (ClassNotFoundException e) {
			BaseLogger.SCHEDULER_LOGGER.error("Error en envio de notificaciones el dia: " + new Date(), e);
		}
	}
	
	public void recargaMapasPli() {
		try {
			BaseLogger.SCHEDULER_LOGGER.debug("Recargando mapas de PLI...");
			service.recargaMapasPli();
		} catch (MessagingException e) {
			BaseLogger.SCHEDULER_LOGGER.error(e.getMessage(), e);
		} catch (ServletException e) {
			BaseLogger.SCHEDULER_LOGGER.error(e.getMessage(), e);
		}
		BaseLogger.SCHEDULER_LOGGER.debug("Finaliza carga de mapas de PLI.");
	}
	
	public void notificaSARsVencidos() {
		BaseLogger.SCHEDULER_LOGGER.debug("Enviando SARs vencidos...");
		log.info("Enviando SARs vencidos...");
		try {
			service.verificaEstatusSARs();
			service.enviaRecordatorioRedFlagSinRespuesta();
			//agrego correo de recordatorio de booking
			service.recordatorioSolicitudBooking();
		} catch (Exception e) {
			log.error("Error en el job NotificaSARsVencidosJob, {}",e);
		}finally{
			log.info("Finaliza envio de SARs vencidos.");
			BaseLogger.SCHEDULER_LOGGER.debug("Finaliza envio de SARs vencidos.");
		}
	}
	
	public void generaReporteSARs() {
		BaseLogger.SCHEDULER_LOGGER.debug("Enviando reporte de SARs...");
		try {
			service.reporteSARsPendingPlannerApproval();
			service.generaReporteBooking();
			service.sarsSinBooking();
			service.reporteSARsBooking();
		} catch (Exception e) {
			log.error("Error en el job NotificaSARsVencidosJob, {}",e);
		}
		
		BaseLogger.SCHEDULER_LOGGER.debug("Finaliza envio de reporte de SARs.");
	}
	
	public void reiniciaMapaDetalle() {
		BaseLogger.SCHEDULER_LOGGER.debug("Reiniciando mapa Detalle");
		try {
			service.reinicaMapaDetalle();
		} catch (Exception e) {
			BaseLogger.SCHEDULER_LOGGER.error("Error en el servicio reiniciaMapaDetalle, {}",e);
		}
		BaseLogger.SCHEDULER_LOGGER.debug("Finaliza reiniciando mapa Detalle.");
	}
	
}
