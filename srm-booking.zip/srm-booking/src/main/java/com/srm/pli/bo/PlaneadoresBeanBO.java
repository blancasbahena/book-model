package com.srm.pli.bo;

import java.io.Serializable;

import lombok.Data;

@Data
public class PlaneadoresBeanBO implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String idPlaneador;
	private String nombre;
	private String [] correos;
	private String gerente;
	private String correoGerente;
	private String identificadorPlaneador;
	private String identificadorGerente;
	
}
