package com.srm.pli.helper;

import java.util.GregorianCalendar;

import com.srm.pli.utils.FuncionesComunesPLI;
import com.srm.pli.utils.Utilerias;
import com.truper.businessEntity.BeanSarChat;

public class FormatSARChat {
	private Integer id;
	private String mensaje;
	private String usuario;
	private String fecha;
	private String fechaLarga;
	private String folio;
	private Boolean proveedor; 
	
	public FormatSARChat(BeanSarChat beanChat) {
		id = beanChat.getId();
		GregorianCalendar fechaMillis = new GregorianCalendar();
		fechaMillis.setTimeInMillis(beanChat.getFechaMillis());
		usuario = beanChat.getUsuario();
		mensaje = beanChat.getMensaje();
		folio = beanChat.getFolio();
		fechaLarga = Utilerias.formatLongDate(fechaMillis);
		fecha = FuncionesComunesPLI.formateaFecha(beanChat.getFecha());
		proveedor = beanChat.isProveedor();
	}

	/**
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}

	/**
	 * @return the mensaje
	 */
	public String getMensaje() {
		return mensaje;
	}

	/**
	 * @param mensaje the mensaje to set
	 */
	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}

	/**
	 * @return the usuario
	 */
	public String getUsuario() {
		return usuario;
	}

	/**
	 * @param usuario the usuario to set
	 */
	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}

	/**
	 * @return the fecha
	 */
	public String getFecha() {
		return fecha;
	}

	/**
	 * @param fecha the fecha to set
	 */
	public void setFecha(String fecha) {
		this.fecha = fecha;
	}

	/**
	 * @return the fechaLarga
	 */
	public String getFechaLarga() {
		return fechaLarga;
	}

	/**
	 * @param fechaLarga the fechaLarga to set
	 */
	public void setFechaLarga(String fechaLarga) {
		this.fechaLarga = fechaLarga;
	}

	/**
	 * @return the folio
	 */
	public String getFolio() {
		return folio;
	}

	/**
	 * @param folio the folio to set
	 */
	public void setFolio(String folio) {
		this.folio = folio;
	}

	/**
	 * @return the proveedor
	 */
	public Boolean getProveedor() {
		return proveedor;
	}

	/**
	 * @param proveedor the proveedor to set
	 */
	public void setProveedor(Boolean proveedor) {
		this.proveedor = proveedor;
	}
}
