package com.srm.pli.schedulers.jobs;

import java.util.List;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import com.srm.pli.bo.DataEmailBean;
import com.srm.pli.bo.RevisionIDAVistaBean;
import com.srm.pli.services.impl.BookingPendientesIdasServiceImpl;
import com.srm.pli.services.impl.CdiConfPropertiesServiceImpl;
import com.srm.pli.services.impl.EnvioEmailServiceImpl;
import com.srm.pli.services.impl.GenerarReporteIdasPendientesServiceImpl;

import lombok.extern.log4j.Log4j2;


@Log4j2
public class EnviaMailReporteBookingPendientasIdasJob implements Job
{
	private BookingPendientesIdasServiceImpl bookingPendientesIdasService = BookingPendientesIdasServiceImpl.getInstance();
	private GenerarReporteIdasPendientesServiceImpl generarReporteIdasPendientesService = GenerarReporteIdasPendientesServiceImpl.getInstance();
	private EnvioEmailServiceImpl emailService = EnvioEmailServiceImpl.getInstance();
	private CdiConfPropertiesServiceImpl cdiConfPropertiesService = new CdiConfPropertiesServiceImpl();
	
	
	@Override
	public void execute(JobExecutionContext context) throws JobExecutionException
	{		
		try
		{
			List<RevisionIDAVistaBean> listaVistaTotal = bookingPendientesIdasService.getInfByIdasPendientes();
			log.info("# registros encontrados: " + (listaVistaTotal != null && !listaVistaTotal.isEmpty() ? listaVistaTotal.size() : 0));
			
			DataEmailBean dataEmailBean = cdiConfPropertiesService.getPropertiesByIdasPendientes();
			String formatoHTML = generarReporteIdasPendientesService.generarTemplateHTML(dataEmailBean, listaVistaTotal);

			emailService.enviarEmailTemplate(formatoHTML, dataEmailBean.getSubject(), dataEmailBean.getSender(), dataEmailBean.getCorreosMap());
		} 
		catch (Exception e)
		{
			log.error("Hubo un error: " + e.getMessage());
		}
	}

}
