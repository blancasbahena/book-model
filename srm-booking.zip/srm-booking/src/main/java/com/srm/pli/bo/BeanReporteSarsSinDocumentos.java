package com.srm.pli.bo;

import java.math.BigDecimal;

public class BeanReporteSarsSinDocumentos {

	private BigDecimal backorderGenerado;
	private Integer idaMinimo;
	private String bu;
	private Integer fechaEtd;
	private Integer fechaEta;
	private String puertoDescarga;
	private String proveedor;
	private String proveedorNombre;
	private String booking;
	private Integer fechaConfirmacionFinal;
	private Integer diasDesdeConfirmacionFinal;

	public BigDecimal getBackorderGenerado() {
		return backorderGenerado;
	}

	public void setBackorderGenerado(BigDecimal backorderGenerado) {
		this.backorderGenerado = backorderGenerado;
	}

	public Integer getIdaMinimo() {
		return idaMinimo;
	}

	public void setIdaMinimo(Integer idaMinimo) {
		this.idaMinimo = idaMinimo;
	}

	public String getBu() {
		return bu;
	}

	public void setBu(String bu) {
		this.bu = bu;
	}

	public Integer getFechaEtd() {
		return fechaEtd;
	}

	public void setFechaEtd(Integer fechaEtd) {
		this.fechaEtd = fechaEtd;
	}

	public Integer getFechaEta() {
		return fechaEta;
	}

	public void setFechaEta(Integer fechaEta) {
		this.fechaEta = fechaEta;
	}

	public String getPuertoDescarga() {
		return puertoDescarga;
	}

	public void setPuertoDescarga(String puertoDescarga) {
		this.puertoDescarga = puertoDescarga;
	}

	public String getProveedor() {
		return proveedor;
	}

	public void setProveedor(String proveedor) {
		this.proveedor = proveedor;
	}

	public String getProveedorNombre() {
		return proveedorNombre;
	}

	public void setProveedorNombre(String proveedorNombre) {
		this.proveedorNombre = proveedorNombre;
	}

	public String getBooking() {
		return booking;
	}

	public void setBooking(String booking) {
		this.booking = booking;
	}

	public Integer getFechaConfirmacionFinal() {
		return fechaConfirmacionFinal;
	}

	public void setFechaConfirmacionFinal(Integer fechaConfirmacionFinal) {
		this.fechaConfirmacionFinal = fechaConfirmacionFinal;
	}

	public Integer getDiasDesdeConfirmacionFinal() {
		return diasDesdeConfirmacionFinal;
	}

	public void setDiasDesdeConfirmacionFinal(Integer diasDesdeConfirmacionFinal) {
		this.diasDesdeConfirmacionFinal = diasDesdeConfirmacionFinal;
	}

}
