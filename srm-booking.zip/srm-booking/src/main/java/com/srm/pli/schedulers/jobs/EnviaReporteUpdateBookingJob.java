package com.srm.pli.schedulers.jobs;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import com.srm.pli.services.impl.UpdateSupplierReport;
import com.srm.pli.utils.CorreoUtils;
import com.srm.pli.utils.MailUtils;
import com.srm.pli.utils.PropertiesDb;
import com.truper.businessEntity.EmailAsynBean;

import lombok.extern.log4j.Log4j2;

@Log4j2
public class EnviaReporteUpdateBookingJob implements Job {

	@Override
	public void execute(JobExecutionContext arg0) throws JobExecutionException {
		log.info("Iniciando proceso de envio ");
		boolean esProcesoActivo = PropertiesDb.getInstance().getBoolean("email.job.updateSupplier.booking");
		if (esProcesoActivo) {
			try {
				EmailAsynBean emailBean = UpdateSupplierReport.getInstance().getEmailAsynBean();
				MailUtils.getInstance().enviaCorreo(
						CorreoUtils.getInstance().getArrayStringsFromAddress(emailBean.getAddress()), emailBean.getCc(),
						emailBean.getSubject(), emailBean.getSender(), emailBean.getMsg(), null);
				System.out.println("EnviaReporteUpdateBookingJob");
			} catch (Exception e) {
				log.error("Error al enviar >>  EnviaReporteUpdateBookingJob", e.getMessage());
			}
		} else {
			log.info("El proceso esta inactivo .");
		}
		log.info("Finalizando proceso ");
	}

}
