package com.srm.pli.bo;


import java.util.Date;

import com.truper.bpm.enums.StatusControlMatricesEnum;
import com.truper.businessEntity.BeanControlPrecios;

public class BeanMatrizDetalles extends BeanControlPrecios{
	private Date fechaInsert;
	private boolean isBacklog;
	private Date fechaBacklog;
	private Date fechaModificacion;
	private String  comentario;
	private StatusControlMatricesEnum status;
	
	private String descripcionMaterial;
	private double precio;
	private String moneda;
	private String vigInicio;
	private String vigFin;
	private double precio2;
	private String moneda2;
	private String vigInicio2;
	private String vigFin2;
	private double precio3;
	private String moneda3;
	private String vigInicio3;
	private String vigFin3;
	private double precio4;
	private String moneda4;
	private String vigInicio4;
	private String vigFin4;
	private int ultimoPrecio;
	
	
	public Date getFechaInsert() {
		return fechaInsert;
	}
	public void setFechaInsert(Date fechaInsert) {
		this.fechaInsert = fechaInsert;
	}
	public boolean isBacklog() {
		return isBacklog;
	}
	public void setBacklog(boolean isBacklog) {
		this.isBacklog = isBacklog;
	}
	public Date getFechaBacklog() {
		return fechaBacklog;
	}
	public void setFechaBacklog(Date fechaBacklog) {
		this.fechaBacklog = fechaBacklog;
	}
	public Date getFechaModificacion() {
		return fechaModificacion;
	}
	public void setFechaModificacion(Date fechaModificacion) {
		this.fechaModificacion = fechaModificacion;
	}
	public String getComentario() {
		return comentario;
	}
	public void setComentario(String comentario) {
		this.comentario = comentario;
	}
	public StatusControlMatricesEnum getStatus() {
		return status;
	}
	public void setStatus(StatusControlMatricesEnum status) {
		this.status = status;
	}
	public String getDescripcionMaterial() {
		return descripcionMaterial;
	}
	public void setDescripcionMaterial(String descripcionMaterial) {
		this.descripcionMaterial = descripcionMaterial;
	}
	public double getPrecio() {
		return precio;
	}
	public void setPrecio(double precio) {
		this.precio = precio;
	}
	public String getMoneda() {
		return moneda;
	}
	public void setMoneda(String moneda) {
		this.moneda = moneda;
	}
	public String getVigInicio() {
		return vigInicio;
	}
	public void setVigInicio(String vigInicio) {
		this.vigInicio = vigInicio;
	}
	public String getVigFin() {
		return vigFin;
	}
	public void setVigFin(String vigFin) {
		this.vigFin = vigFin;
	}
	public double getPrecio2() {
		return precio2;
	}
	public void setPrecio2(double precio2) {
		this.precio2 = precio2;
	}
	public String getMoneda2() {
		return moneda2;
	}
	public void setMoneda2(String moneda2) {
		this.moneda2 = moneda2;
	}
	public String getVigInicio2() {
		return vigInicio2;
	}
	public void setVigInicio2(String vigInicio2) {
		this.vigInicio2 = vigInicio2;
	}
	public String getVigFin2() {
		return vigFin2;
	}
	public void setVigFin2(String vigFin2) {
		this.vigFin2 = vigFin2;
	}
	public double getPrecio3() {
		return precio3;
	}
	public void setPrecio3(double precio3) {
		this.precio3 = precio3;
	}
	public String getMoneda3() {
		return moneda3;
	}
	public void setMoneda3(String moneda3) {
		this.moneda3 = moneda3;
	}
	public String getVigInicio3() {
		return vigInicio3;
	}
	public void setVigInicio3(String vigInicio3) {
		this.vigInicio3 = vigInicio3;
	}
	public String getVigFin3() {
		return vigFin3;
	}
	public void setVigFin3(String vigFin3) {
		this.vigFin3 = vigFin3;
	}
	public double getPrecio4() {
		return precio4;
	}
	public void setPrecio4(double precio4) {
		this.precio4 = precio4;
	}
	public String getMoneda4() {
		return moneda4;
	}
	public void setMoneda4(String moneda4) {
		this.moneda4 = moneda4;
	}
	public String getVigInicio4() {
		return vigInicio4;
	}
	public void setVigInicio4(String vigInicio4) {
		this.vigInicio4 = vigInicio4;
	}
	public String getVigFin4() {
		return vigFin4;
	}
	public void setVigFin4(String vigFin4) {
		this.vigFin4 = vigFin4;
	}	
	public int getUltimoPrecio() {
		return ultimoPrecio;
	}
	public void setUltimoPrecio(int ultimoPrecio) {
		this.ultimoPrecio = ultimoPrecio;
	}
	
	
	
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("BeanMatrizDetalles [getFechaInsert()=");
		builder.append(getFechaInsert());
		builder.append(", isBacklog()=");
		builder.append(isBacklog());
		builder.append(", getFechaBacklog()=");
		builder.append(getFechaBacklog());
		builder.append(", getFechaModificacion()=");
		builder.append(getFechaModificacion());
		builder.append(", getComentario()=");
		builder.append(getComentario());
		builder.append(", getStatus()=");
		builder.append(getStatus());
		builder.append(", getDescripcionMaterial()=");
		builder.append(getDescripcionMaterial());
		builder.append(", getPrecio()=");
		builder.append(getPrecio());
		builder.append(", getMoneda()=");
		builder.append(getMoneda());
		builder.append(", getVigInicio()=");
		builder.append(getVigInicio());
		builder.append(", getVigFin()=");
		builder.append(getVigFin());
		builder.append(", getPrecio2()=");
		builder.append(getPrecio2());
		builder.append(", getMoneda2()=");
		builder.append(getMoneda2());
		builder.append(", getVigInicio2()=");
		builder.append(getVigInicio2());
		builder.append(", getVigFin2()=");
		builder.append(getVigFin2());
		builder.append(", getPrecio3()=");
		builder.append(getPrecio3());
		builder.append(", getMoneda3()=");
		builder.append(getMoneda3());
		builder.append(", getVigInicio3()=");
		builder.append(getVigInicio3());
		builder.append(", getVigFin3()=");
		builder.append(getVigFin3());
		builder.append(", getPrecio4()=");
		builder.append(getPrecio4());
		builder.append(", getMoneda4()=");
		builder.append(getMoneda4());
		builder.append(", getVigInicio4()=");
		builder.append(getVigInicio4());
		builder.append(", getVigFin4()=");
		builder.append(getVigFin4());
		builder.append("]");
		return builder.toString();
	}
	
}
