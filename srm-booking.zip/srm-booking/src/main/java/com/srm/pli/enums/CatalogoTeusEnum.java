package com.srm.pli.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum CatalogoTeusEnum
{
	_40("40", 2),
	_40HC("40HC", 2),
	_40HQ("40HQ", 2),
	_20("20", 1),
	_LCL("LCL", 0);
	private String contenedor;
	private Integer teus;
}
