package com.srm.pli.process;

import java.util.ArrayList;
import java.util.HashMap;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.srm.pli.bo.SarBO;
import com.srm.pli.dao.SAR_CDI_DAO;
import com.srm.pli.helper.FormatRowFileNaviera;
import com.srm.pli.servlet.BookingCDIImpl;
import com.srm.pli.servlet.BookingProcess;
import com.srm.pli.utils.FuncionesComunesPLI;
import com.truper.businessEntity.BeanRowFileCarrier;
import com.truper.businessEntity.UserBean;
 

public class GeneraReporteNavieras implements Runnable {
	private ArrayList<BeanRowFileCarrier> listaAProcesar;
	private UserBean usuario;
	private String naviera;
	private boolean procesoKN;
	
	private static final Logger log = LogManager.getRootLogger();
	
	public GeneraReporteNavieras(ArrayList<BeanRowFileCarrier> parametroDeEntradaAlHilo, UserBean usuario,String naviera,boolean procesoKN) {
		this.listaAProcesar = parametroDeEntradaAlHilo;
		this.usuario = usuario;
		this.naviera = naviera;
		this.procesoKN = procesoKN;
	}
	
	
	public void run() {
		log.info("Nace hilo empiezo a mandar las confirmaciones a SAP.");
		//mapa para tratar los folios consolidados
		HashMap<Integer, BeanRowFileCarrier> mapaFoliosConsolidados = new HashMap<Integer, BeanRowFileCarrier>();
		
		if(listaAProcesar == null || listaAProcesar.size() ==0) {
			log.info("La lista no tiene elementos que procesar no se manda correo de resultados");
			
		}else {
			try {
				if(procesoKN) {
					ArrayList<FormatRowFileNaviera> listaFormato = new ArrayList<FormatRowFileNaviera>();
					SAR_CDI_DAO dao = new SAR_CDI_DAO();
					ArrayList<SarBO> listaSarBo = new ArrayList<SarBO>();
					for(BeanRowFileCarrier renglon : listaAProcesar) {
						if(renglon.isEnviarSAP() || renglon.isCambio()) {
							SarBO bo = new SarBO();
							bo.setFolio(renglon.getSar());
							ArrayList<SarBO> listTmp = dao.selectSar(bo,false);
							listaSarBo.add(listTmp.get(0));///posicion 0 por que busco por sar es decir solo hay un resultado
						}			
					}
					///con la lista voy por los detalles 
					FuncionesComunesPLI.dameDatosCDIDetalle(listaSarBo);
					for(BeanRowFileCarrier renglon : listaAProcesar) {
						if(renglon.isEnviarSAP() || renglon.isCambio()) {
							renglon = BookingCDIImpl.daTratamientoCorrecto(renglon,usuario);
							if(renglon.getEsError() != null && !renglon.getEsError()  && renglon.getSarConsolidado() != null && renglon.getSarConsolidado() > 0 ) {
								///Lo listo para guardar su historico
								mapaFoliosConsolidados.put(renglon.getSarConsolidado(), renglon);
							}
						}
					}
					listaFormato = new ArrayList<FormatRowFileNaviera>();
					//////Aqui deberia mandar a llamar la funcion para imprimir los resultados y mandar el correo
					for(BeanRowFileCarrier renglon : listaAProcesar) {
						try {
						FormatRowFileNaviera format = new FormatRowFileNaviera(renglon);
						listaFormato.add(format);
						}catch (Exception e) {
							log.error("[Error al tratar de generar la respuesta del archivo de navieras]"+e.getMessage(), e);
						}
					}
					log.info("Se da tratamiento a los folios consolidados en el archivo.");
					BookingCDIImpl.avanzaConsolidados( mapaFoliosConsolidados,usuario);
					log.info("Se da tratamiento a los registros del archivo de navieras, se procede a generar el archivo.");
					BookingProcess proces = new BookingProcess();
					proces.generaRespuestaNaviera(listaFormato,naviera);
				}else {
				
					ArrayList<FormatRowFileNaviera> listaFormato = new ArrayList<FormatRowFileNaviera>();
					SAR_CDI_DAO dao = new SAR_CDI_DAO();
					ArrayList<SarBO> listaSarBo = new ArrayList<SarBO>();
					for(BeanRowFileCarrier renglon : listaAProcesar) {
						if(renglon.isResultadoSAP() && renglon.isEnviarSAP()) {
							SarBO bo = new SarBO();
							bo.setFolio(renglon.getSar());
							ArrayList<SarBO> listTmp = dao.selectSar(bo,false);
							listaSarBo.add(listTmp.get(0));///posicion 0 por que busco por sar es decir solo hay un resultado
						}			
					}
					///con la lista voy por los detalles 
					FuncionesComunesPLI.dameDatosCDIDetalle(listaSarBo);
					for(BeanRowFileCarrier renglon : listaAProcesar) {
						if(renglon.isResultadoSAP() && renglon.isEnviarSAP()) {
							renglon = BookingCDIImpl.daTratamientoCorrecto(renglon,usuario);
							if(renglon.getEsError() != null && !renglon.getEsError()  && renglon.getSarConsolidado() != null && renglon.getSarConsolidado() > 0 ) {
								///Lo listo para guardar su historico
								mapaFoliosConsolidados.put(renglon.getSarConsolidado(), renglon);
							}
						}
					}
					listaFormato = new ArrayList<FormatRowFileNaviera>();
					//////Aqui deberia mandar a llamar la funcion para imprimir los resultados y mandar el correo
					for(BeanRowFileCarrier renglon : listaAProcesar) {
						FormatRowFileNaviera format = new FormatRowFileNaviera(renglon);
						listaFormato.add(format);
					}
					log.info("Se da tratamiento a los folios consolidados en el archivo.");
					BookingCDIImpl.avanzaConsolidados( mapaFoliosConsolidados,usuario);
					log.info("Se da tratamiento a los registros del archivo de navieras, se procede a generar el archivo.");
					BookingProcess proces = new BookingProcess();
					proces.generaRespuestaNaviera(listaFormato,naviera);
				}
			}catch (Exception e) {
				log.error("[Error al tratar de generar la respuesta del archivo de navieras]"+e.getMessage(), e);
				BookingProcess.correroErrorIT("El archivo de la naviera no se envio ", "Error envio archivo de naviera: "+e.getMessage());
			}
		}
		log.info("Fin Proceso del envio del correo de navieras");
	}
			
}
