package com.srm.pli.rest;

import java.io.IOException;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import org.codehaus.jackson.map.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.srm.app.response.vo.ResponseEmbarqueDirectosVO;
import com.srm.pli.bo.ParametrosIndexBean;
import com.srm.pli.services.impl.EmbarquesDirectosServiceImpl;
import com.truper.infra.rs.BaseRS;
import com.truper.utils.date.EnumFechas;
import lombok.extern.slf4j.Slf4j;


@Slf4j
@Path("/embarques")
public class EmbarquesDirectosRest extends BaseRS
{
	private static final long serialVersionUID = 1L;
	private Gson gson = new GsonBuilder().serializeSpecialFloatingPointValues().setDateFormat(EnumFechas.FORMATO_YYYY_MM_DD.to()).create();
	private ObjectMapper objectMapper = new ObjectMapper();	
	
	@POST
	@Path("/directos")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response construirDatosEmbarquestDirectos(String json)
	{
		log.info("Inicio::WS Entrando al ws que obtiene los datos de concentrado de datos, request: {}", json);
		ResponseEmbarqueDirectosVO responseVO = null;
		try
		{
			ParametrosIndexBean pametrosIndexBean = objectMapper.readValue(json, ParametrosIndexBean.class);
			responseVO = EmbarquesDirectosServiceImpl.getInstance().getInformacionToBuildExcelWithSAR(pametrosIndexBean);
		} 
		catch (IOException e)
		{
			log.error("Hubo un error en la Serializacion del json: {} , Exception: ", json, e);
		}
		log.info("Fin::Ws Se termino de obtener los datos de concentrado de datos");
		return buildOKResponse(gson.toJson(responseVO));
	}
}
