package com.srm.pli.bo;

public class ReporteMRPFiles {
	private String fechaRegistro;
	private String proveedor;
	private String nombreProveedor;
	private String orden;
	private String etd;
	private String folio;
	private String material;
	private String cantidad;
	private String pesoSAP;
	private String volumenSAP;
	private String pesoProveedor;
	private String volumenProveedor;
	private String varPeso;
	private String varVolumen;
	private String statusMRP;
	private Boolean datosSupplier;
	
	public String getFechaRegistro() {
		return fechaRegistro;
	}
	public void setFechaRegistro(String fechaRegistro) {
		this.fechaRegistro = fechaRegistro;
	}
	public String getProveedor() {
		return proveedor;
	}
	public void setProveedor(String proveedor) {
		this.proveedor = proveedor;
	}
	public String getNombreProveedor() {
		return nombreProveedor;
	}
	public void setNombreProveedor(String nombreProveedor) {
		this.nombreProveedor = nombreProveedor;
	}
	public String getOrden() {
		return orden;
	}
	public void setOrden(String orden) {
		this.orden = orden;
	}
	public String getEtd() {
		return etd;
	}
	public void setEtd(String etd) {
		this.etd = etd;
	}
	public String getFolio() {
		return folio;
	}
	public void setFolio(String folio) {
		this.folio = folio;
	}
	public String getMaterial() {
		return material;
	}
	public void setMaterial(String material) {
		this.material = material;
	}
	public String getCantidad() {
		return cantidad;
	}
	public void setCantidad(String cantidad) {
		this.cantidad = cantidad;
	}
	public String getPesoSAP() {
		return pesoSAP;
	}
	public void setPesoSAP(String pesoSAP) {
		this.pesoSAP = pesoSAP;
	}
	public String getVolumenSAP() {
		return volumenSAP;
	}
	public void setVolumenSAP(String volumenSAP) {
		this.volumenSAP = volumenSAP;
	}
	public String getPesoProveedor() {
		return pesoProveedor;
	}
	public void setPesoProveedor(String pesoProveedor) {
		this.pesoProveedor = pesoProveedor;
	}
	public String getVolumenProveedor() {
		return volumenProveedor;
	}
	public void setVolumenProveedor(String volumenProveedor) {
		this.volumenProveedor = volumenProveedor;
	}
	public String getVarPeso() {
		return varPeso;
	}
	public void setVarPeso(String varPeso) {
		this.varPeso = varPeso;
	}
	public String getVarVolumen() {
		return varVolumen;
	}
	public void setVarVolumen(String varVolumen) {
		this.varVolumen = varVolumen;
	}
	public String getStatusMRP() {
		return statusMRP;
	}
	public void setStatusMRP(String statusMRP) {
		this.statusMRP = statusMRP;
	}
	public Boolean getDatosSupplier() {
		return datosSupplier;
	}
	public void setDatosSupplier(Boolean datosSupplier) {
		this.datosSupplier = datosSupplier;
	}
}
