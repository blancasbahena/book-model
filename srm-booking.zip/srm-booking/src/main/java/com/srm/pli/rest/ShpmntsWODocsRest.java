package com.srm.pli.rest;

import java.io.File;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.srm.pli.services.ShpmntsWODocsService;
import com.truper.infra.loggers.BaseLogger;
import com.truper.infra.rs.BaseRS;

@Path("/ShpmntsWODocsRest")
public class ShpmntsWODocsRest extends BaseRS {

	private static final long serialVersionUID = 3236629181482736246L;

	@GET
	@Path("/reporteConfirmacionFinalSinDocumentos")
	@Produces(MediaType.APPLICATION_OCTET_STREAM)
	public Response downloadReporteConfirmacionFinalSinDocumentos() {
		Response r = null;
		File file = null;
		String nombre = "ShpmntsWODocs_FinalConfirmation";
		try {
			file = ShpmntsWODocsService.getInstance().getFileReporteSarsSinDocumentos();
			r = Response.ok(file, MediaType.APPLICATION_OCTET_STREAM)
					.header("Content-Disposition", "attachment;filename=" + nombre + ".xls").build();
		} catch (Exception e) {
			BaseLogger.BOOKING_LOGGER.error("Error al intentar generar el archivo " + nombre, e);
			r = buildErrorResponse("Error trying to download File.");
		}
		return r;
	}

}
