package com.srm.pli.bo;

import java.io.Serializable;
import java.util.Date;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ConsultaReporteKpis implements Serializable
{
	private static final long serialVersionUID = 1L;
	private String folio;
	private String carrier;
	private Integer tipoContenedor;
	private String contenedor;
	private String nombreContenedor;
	private String reason;
	private String eta;
	private String pod;
	private String pol;
	private String estatusRM;
	private Integer cantidad;
	private Integer naviera;
	private String nombreNaviera;
	private String puertoSalida;
	private String nombrePuertoOrigen;
	private Integer currentETD;
	private Date createDate;
}
