package com.srm.pli.rest;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.json.JSONObject;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;
import org.springframework.http.HttpHeaders;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.srm.fungandrui.pis.dto.RequestAuthWsPos;
import com.srm.fungandrui.pis.dto.RequestWsPos;
import com.srm.fungandrui.pis.dto.ResponseAuthWsPos;
import com.srm.fungandrui.pis.dto.ResponseWsPos;
import com.srm.pli.bo.BeanUserPOD;
import com.srm.pli.bo.BeanUserPlanner;
import com.srm.pli.bo.BeanUserPlannerManager;
import com.srm.pli.bo.ResponseWsPlanners;
import com.srm.pli.dao.PuertosDescargaDao;
import com.srm.pli.utils.FuncionesComunesPLI;
import com.srm.pli.utils.PropertiesDb;
import com.truper.businessEntity.BeanPuerto;
import com.truper.businessEntity.UserBean;
import com.truper.infra.rs.BaseRS;
import com.truper.utils.date.EnumFechas;

@Path("/PlannersService")
public class PlannersRest extends BaseRS {

	private static final long serialVersionUID = 5394059842158283958L;
	
	Gson g = new GsonBuilder().serializeSpecialFloatingPointValues().setDateFormat(EnumFechas.FORMATO_YYYY_MM_DD.to())
			.create();
	
	@Context
	private HttpServletRequest request;
	
	private RestTemplate restTemplate = new RestTemplate();

	@POST
	@Path("/user/planners/update")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response updateUserPlanners(String jsonIn) {
		
		JSONObject json = new JSONObject();
		BeanUserPlanner entrada = g.fromJson(jsonIn, BeanUserPlanner.class);
		String response = actualizarPlanners(entrada);
		
		if (response.equals("S")) {
			json.put("estatus", 1);
		} else {
			json.put("estatus", 0);
		}
			
		return buildOKResponse(g.toJson(json));
	}
	
	@POST
	@Path("/user/plannersManagers/update")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response updateUserPlannersManagers(String jsonIn) {
		
		JSONObject json = new JSONObject();
		BeanUserPlannerManager entrada = g.fromJson(jsonIn, BeanUserPlannerManager.class);
		String response = actualizarPlannersManagers(entrada);
		
		if (response.equals("S")) {
			json.put("estatus", 1);
		} else {
			json.put("estatus", 0);
		}
		
		return buildOKResponse(g.toJson(json));
	}
	
	private String actualizarPlanners(BeanUserPlanner entrada) {
		
		String URL_WSPOS = PropertiesDb.getInstance().getString("srm.truper.proforma");
		final String usuario  = PropertiesDb.getInstance().getString("srm.truper.wspos.user");
		final String password = PropertiesDb.getInstance().getString("srm.truper.wspos.pass");
		
		ResponseEntity<ResponseAuthWsPos> responseAuthen = authenticated(usuario, password,
				URL_WSPOS + "/authenticate");
		
		if (responseAuthen.getStatusCode() == HttpStatus.OK) {
			if(responseAuthen.getBody().getTipoMensaje().equals("S")) {
				String token =  responseAuthen.getBody().getToken();
				return updatePlanners(token, URL_WSPOS + "/planners", entrada);
			}
		}
		
		return "E";
	}
	
	private String actualizarPlannersManagers(BeanUserPlannerManager entrada) {
		
		String URL_WSPOS = PropertiesDb.getInstance().getString("srm.truper.proforma");
		final String usuario  = PropertiesDb.getInstance().getString("srm.truper.wspos.user");
		final String password = PropertiesDb.getInstance().getString("srm.truper.wspos.pass");
		
		ResponseEntity<ResponseAuthWsPos> responseAuthen = authenticated(usuario, password,
				URL_WSPOS + "/authenticate");
		
		if (responseAuthen.getStatusCode() == HttpStatus.OK) {
			if(responseAuthen.getBody().getTipoMensaje().equals("S")) {
				String token =  responseAuthen.getBody().getToken();
				return updatePlannersManagers(token, URL_WSPOS + "/planners/managers", entrada);
			}
		}
		
		return "E";
	}
	
	private String updatePlanners(String token, String url, BeanUserPlanner entrada){
		
		HttpHeaders headers = new HttpHeaders();
		log.info("Actualizar planners desde F&R, token : " + token);
		
		headers.setContentType(org.springframework.http.MediaType.APPLICATION_JSON);
		headers.set("Authorization", "Bearer " + token);
		headers.setAccept(Collections.singletonList(org.springframework.http.MediaType.APPLICATION_JSON));
		HttpEntity<BeanUserPlanner> request = new HttpEntity<BeanUserPlanner>(entrada, headers);
		log.info("url token :  " + url);
		
		
		ResponseEntity<ResponseWsPlanners> respuesta = restTemplate.exchange(
				url, HttpMethod.POST, request,
				new ParameterizedTypeReference<ResponseWsPlanners>() {
				});
		
		return respuesta.getBody().getTipoMensaje();
	
	}
	
	private String updatePlannersManagers(String token, String url, BeanUserPlannerManager entrada){
		
		HttpHeaders headers = new HttpHeaders();
		log.info("Actualizar managers desde F&R");
		
		headers.setContentType(org.springframework.http.MediaType.APPLICATION_JSON);
		headers.set("Authorization", "Bearer " + token);
		headers.setAccept(Collections.singletonList(org.springframework.http.MediaType.APPLICATION_JSON));
		HttpEntity<BeanUserPlannerManager> request = new HttpEntity<BeanUserPlannerManager>(entrada, headers);
		log.info("url token :  " + url);
		
		ResponseEntity<ResponseWsPlanners> respuesta = restTemplate.exchange(
				url, HttpMethod.POST, request,
				new ParameterizedTypeReference<ResponseWsPlanners>() {
				});
		
		return respuesta.getBody().getTipoMensaje();
		
	}
	
	private ResponseEntity<ResponseAuthWsPos> authenticated(String user, String pass,
			final String url) {
		log.info("Authenticated usuario: " + user);
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(org.springframework.http.MediaType.APPLICATION_JSON);
		headers.setAccept(Collections.singletonList(org.springframework.http.MediaType.APPLICATION_JSON));
		RequestAuthWsPos userDTO=new RequestAuthWsPos();
		userDTO.setUsername(user);
		userDTO.setPassword(pass);
		HttpEntity<RequestAuthWsPos> request = new HttpEntity<>(userDTO, headers);
		return restTemplate.exchange(url, HttpMethod.POST, request,
				new ParameterizedTypeReference<ResponseAuthWsPos>() {});

	}
	
}
