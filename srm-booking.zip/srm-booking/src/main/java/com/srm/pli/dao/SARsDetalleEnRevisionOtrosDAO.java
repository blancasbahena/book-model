package com.srm.pli.dao;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.srm.pli.bo.SarDetalleBO;
import com.srm.pli.db.ConexionDB;

public class SARsDetalleEnRevisionOtrosDAO extends DAO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6757408763340100114L;
	
	private static final Logger log = LogManager.getRootLogger();

	@Override
	public List<?> select(Object o) {
		SarDetalleBO det = (SarDetalleBO)o;
		List<SarDetalleBO> lstSarDetOtrosMod = new ArrayList<SarDetalleBO>();

		Connection con = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		DAOUtils utils = new  DAOUtils();		

		StringBuilder select = new StringBuilder("SELECT folio, po, posicion, descripcion, cantidad, pesoProveedor, volumenProveedor,");
		select.append(" cantidadModificada, pesoModificado, volumenModificado, tipoModificacion, needsAuthPlanningMgr ");
		select.append(" , poOtherItemModificado, precioUnitarioModificado, condicionPagoModificado, unidadMedidaModificado ");
		select.append(" FROM cdiSarDetalleOthersEnRevision ");
		select.append(" WHERE 1=1");
		
		utils.setSelect(true);

		try {
			con = ConexionDB.dameConexion();
			if (det.getFolio() != null) {
				select.append(utils.ajustaColumna(" AND folio = ?"));
			}
			if (det.getPo() != null) {
				select.append(utils.ajustaColumna(" AND po = ?"));
			}
			if (det.getPosicion() != null) {
				select.append(utils.ajustaColumna(" AND posicion = ?"));
			}
			if (det.getTipoModificacion() != null) {
				select.append(utils.ajustaColumna(" and tipoModificacion = ?"));
			}
			if (det.getNeedsAuthPlanningMgr() != null) {
				select.append(utils.ajustaColumna(" AND needsAuthPlanningMgr = ?"));
			}
			
			pst = con.prepareStatement(select.toString());
			int cont = 1;
			
			utils.inicializaQuery(select.toString());
			
			if (det.getFolio() != null) {
				utils.ajustaParametro(cont++, pst, det.getFolio(), Integer.class);
			}
			if (det.getPo() != null) {
				utils.ajustaParametro(cont++, pst, det.getPo(), String.class);
			}
			if (det.getPosicion() != null) {
				utils.ajustaParametro(cont++, pst, det.getPosicion(), Integer.class);
			}
			if (det.getTipoModificacion() != null) {
				utils.ajustaParametro(cont++, pst, det.getTipoModificacion(), Integer.class);
			}
			if (det.getNeedsAuthPlanningMgr() != null) {
				utils.ajustaParametro(cont++, pst, det.getNeedsAuthPlanningMgr(), Boolean.class);
			}
			rs = pst.executeQuery();

			while (rs.next()) {
				SarDetalleBO temp = new SarDetalleBO();
				temp.setFolio(rs.getInt("folio"));
				temp.setPo(rs.getString("po"));
				temp.setPosicion(rs.getInt("posicion"));
				temp.setDescripcion(rs.getString("descripcion"));
				temp.setCantidad(rs.getInt("cantidad"));
				temp.setPesoProveedor(rs.getDouble("pesoProveedor"));
				temp.setVolumenProveedor(rs.getDouble("volumenProveedor"));
				temp.setCantidadModificada(rs.getInt("cantidadModificada"));
				temp.setPesoModificado(rs.getDouble("pesoModificado"));
				temp.setVolumenModificado(rs.getDouble("volumenModificado"));
				temp.setTipoModificacion(rs.getInt("tipoModificacion"));
				temp.setNeedsAuthPlanningMgr(rs.getBoolean("needsAuthPlanningMgr"));
				temp.setPoOtherItem(rs.getString("poOtherItemModificado"));
				BigDecimal precioUnitario = rs.getBigDecimal("precioUnitarioModificado");
				if(rs.wasNull()) {
					precioUnitario = null;
				}
				temp.setPrecioUnitario(precioUnitario);
				temp.setPoOtherItemCondicionPago(rs.getString("condicionPagoModificado"));
				temp.setUnidaMedida(rs.getString("unidadMedidaModificado"));
				lstSarDetOtrosMod.add(temp);
			}

			ConexionDB.devuelveConexion(con);

		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				BOOKING_LOGGER.error(ex.getMessage(), ex);
			}
			BOOKING_LOGGER.error(e.getMessage(), e);
		} catch (Exception e) {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				BOOKING_LOGGER.error(ex.getMessage(), ex);
			}
			BOOKING_LOGGER.error(e.getMessage(), e);
		} finally {
			try {
				rs.close();
				pst.close();
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				BOOKING_LOGGER.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
		return lstSarDetOtrosMod;
	}

	@Override
	public boolean insert(Object o) {
		SarDetalleBO detalle = (SarDetalleBO)o;
		Connection con = null;
		PreparedStatement pst = null;
		DAOUtils utilDao = new DAOUtils();
		
		StringBuilder insert = new StringBuilder(" INSERT INTO cdiSarDetalleOthersEnRevision (folio, po, posicion, descripcion,");
		insert.append(" cantidad, pesoProveedor, volumenProveedor,");
		insert.append(" cantidadModificada, pesoModificado, volumenModificado, tipoModificacion, needsAuthPlanningMgr ");
		insert.append(" , poOtherItemModificado, precioUnitarioModificado, condicionPagoModificado, unidadMedidaModificado) ");
		insert.append(" VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ");

		boolean exito = false;

		try {
			con = ConexionDB.dameConexion();
			pst = con.prepareStatement(insert.toString());
			int cont = 1;
			utilDao.ajustaParametro(cont++, pst, detalle.getFolio(), Integer.class);
			utilDao.ajustaParametro(cont++, pst, detalle.getPo(), String.class);
			utilDao.ajustaParametro(cont++, pst, detalle.getPosicion(), Integer.class);
			String descripcion = detalle.getDescripcion() == null ? "-" : detalle.getDescripcion();
			utilDao.ajustaParametro(cont++, pst, descripcion, String.class);
			utilDao.ajustaParametro(cont++, pst, detalle.getCantidad(), Integer.class);
			utilDao.ajustaParametro(cont++, pst, detalle.getPesoProveedor() == null 
					? null : new BigDecimal(detalle.getPesoProveedor()).setScale(2,BigDecimal.ROUND_UP), BigDecimal.class);
			utilDao.ajustaParametro(cont++, pst, detalle.getVolumenProveedor() == null
					? null : new BigDecimal(detalle.getVolumenProveedor()).setScale(2,BigDecimal.ROUND_UP), BigDecimal.class);
			utilDao.ajustaParametro(cont++, pst, detalle.getCantidadModificada(), Integer.class);
			utilDao.ajustaParametro(cont++, pst, detalle.getPesoModificado() == null 
					? null : new BigDecimal(detalle.getPesoModificado()).setScale(2,BigDecimal.ROUND_UP), BigDecimal.class);
			utilDao.ajustaParametro(cont++, pst, detalle.getVolumenModificado() == null 
					? null : new BigDecimal(detalle.getVolumenModificado()).setScale(2,BigDecimal.ROUND_UP), BigDecimal.class);
			utilDao.ajustaParametro(cont++, pst, detalle.getTipoModificacion(), Integer.class);
			utilDao.ajustaParametro(cont++, pst, detalle.getNeedsAuthPlanningMgr(), Boolean.class);
			utilDao.ajustaParametro(cont++, pst, detalle.getPoOtherItem(), String.class);
			BigDecimal precioUnitario = null;
			if (detalle.getPrecioUnitario() != null && detalle.getPrecioUnitario().compareTo(BigDecimal.ZERO) == 1) {
				precioUnitario = detalle.getPrecioUnitario();
			}
			utilDao.ajustaParametro(cont++, pst, precioUnitario, BigDecimal.class);
			utilDao.ajustaParametro(cont++, pst, detalle.getPoOtherItemCondicionPago(), String.class);
			utilDao.ajustaParametro(cont++, pst, detalle.getUnidaMedida(), String.class);
			utilDao.inicializaQuery(insert.toString());		
			
			exito = pst.executeUpdate() > 0;
			ConexionDB.devuelveConexion(con);
		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				BOOKING_LOGGER.error(ex.getMessage(), ex);
			}
			BOOKING_LOGGER.error(e.getMessage(), e);
		} catch (Exception e) {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				BOOKING_LOGGER.error(ex.getMessage(), ex);
			}
			BOOKING_LOGGER.error(e.getMessage(), e);
		} finally {
			try {
				pst.close();
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				BOOKING_LOGGER.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
		return exito;
	}

	@Override
	public boolean update(Object o) {
		SarDetalleBO det = (SarDetalleBO)o;
		Connection con = null;
		PreparedStatement pst = null;
		StringBuilder update = new StringBuilder();
		update.append("UPDATE  cdiSarDetalleOthersEnRevision SET ");
		
		DAOUtils utils = new  DAOUtils();
		boolean exito = false;
		
		try {
			con = ConexionDB.dameConexion();
			
			if (det.getCantidad() != null) {
				update.append(" cantidad = ?,");
			}
			if (det.getPesoProveedor() != null) {
				update.append(" pesoProveedor = ?,");
			}
			if (det.getVolumenProveedor() != null) {
				update.append(" volumenProveedor = ?,");
			}
			if (det.getCantidadModificada() != null) {
				update.append(" cantidadModificada = ?,");
			}
			if (det.getPesoModificado() != null) {
				update.append(" pesoModificado = ?,");
			}
			if (det.getVolumenModificado() != null) {
				update.append(" volumenModificado = ?,");
			}
			if (det.getTipoModificacion() != null) {
				update.append(" tipoModificacion = ?,");
			}
			if (det.getNeedsAuthPlanningMgr() != null) {
				update.append(" needsAuthPlanningMgr = ?");
			}

			update.append(" WHERE ");
			update.append(" folio = ?");
			update.append(" AND po = ?");
			update.append(" AND posicion = ?");

			int cont = 1;
			pst = con.prepareStatement(update.toString());
			
			utils.inicializaQuery(update.toString());

			if (det.getCantidad() != null) {
				agregarPs(cont++, pst, det.getCantidad(), Integer.class);
			}
			if (det.getPesoProveedor() != null) {
				agregarPs(cont++, pst, new BigDecimal(det.getPesoProveedor()).setScale(2,BigDecimal.ROUND_UP),
						BigDecimal.class);
			}
			if (det.getVolumenProveedor() != null) {
				agregarPs(cont++, pst,
						new BigDecimal(det.getVolumenProveedor()).setScale(2,BigDecimal.ROUND_UP),
						BigDecimal.class);
			}
			if (det.getCantidadModificada() != null) {
				agregarPs(cont++, pst, det.getCantidadModificada(), Integer.class);
			}
			if (det.getPesoModificado() != null) {
				agregarPs(cont++, pst, new BigDecimal(det.getPesoModificado()).setScale(2,BigDecimal.ROUND_UP),
						BigDecimal.class);
			}
			if (det.getVolumenModificado() != null) {
				agregarPs(cont++, pst,
						new BigDecimal(det.getVolumenModificado()).setScale(2,BigDecimal.ROUND_UP),
						BigDecimal.class);
			}
			if (det.getTipoModificacion() != null) {
				agregarPs(cont++, pst,det.getTipoModificacion(), Integer.class);
			}
			if (det.getNeedsAuthPlanningMgr() != null) {
				agregarPs(cont++, pst,det.getNeedsAuthPlanningMgr(), Boolean.class);
			}

			agregarPs(cont++, pst, det.getFolio(), Integer.class);
			agregarPs(cont++, pst, det.getPo(), String.class);
			agregarPs(cont++, pst, det.getPosicion(), Integer.class);

			int resultado = pst.executeUpdate();
			exito = resultado > 0;
			pst.close();

			ConexionDB.devuelveConexion(con);

		} catch (Exception e) {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				BOOKING_LOGGER.error(ex.getMessage(), ex);
			}
			BOOKING_LOGGER.error(e.getMessage(), e);
		} finally {
			try {
				pst.close();
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				BOOKING_LOGGER.error(sqlEx2.getMessage(), sqlEx2);
			}
		}

		return exito;
	}
	
	public boolean delete(Object o) {
		Integer folio = (Integer)o;
		Connection con = null;
		PreparedStatement pst = null;
		StringBuilder delete = new StringBuilder();
		boolean exito = false;
		try {

			delete.append("DELETE  cdiSarDetalleOthersEnRevision");
			delete.append(" WHERE folio = ?");

			int cont = 1;
			con = ConexionDB.dameConexion();

			pst = con.prepareStatement(delete.toString());

			agregarPs(cont++, pst, folio, Integer.class);

			int resultado = pst.executeUpdate();
			log.info("Borrado en cdiSarDetalleOthersEnRevision, Folio: {}, Resultado: {}",folio,resultado);
			exito = resultado > 0;
			pst.close();

			ConexionDB.devuelveConexion(con);

		} catch (Exception e) {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				BOOKING_LOGGER.error(ex.getMessage(), ex);
			}
			BOOKING_LOGGER.error(e.getMessage(), e);
		} finally {
			try {
				pst.close();
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				BOOKING_LOGGER.error(sqlEx2.getMessage(), sqlEx2);
			}
		}

		return exito;
	}

}
