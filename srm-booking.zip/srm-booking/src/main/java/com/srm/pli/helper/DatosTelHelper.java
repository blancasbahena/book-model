package com.srm.pli.helper;

import com.srm.pli.bo.ClientePodBean;
import com.srm.pli.services.PuertosService;
import com.truper.businessEntity.BeanPuerto;
import com.truper.utils.string.UtilsString;

public class DatosTelHelper {

	private static DatosTelHelper instance = null;

	private DatosTelHelper() {
	}

	public static DatosTelHelper getInstance() {
		if (instance == null)
			instance = new DatosTelHelper();
		return instance;
	}

	public BeanPuerto conviertePuerto(ClientePodBean puerto) {
		String clave = puerto.getPuertoId();
		if (!UtilsString.isStringValida(clave))
			return null;
		BeanPuerto respuesta = PuertosService.getInstance().getPuertoDirecto(clave);
		if (respuesta == null) {
			String nombre = puerto.getPuerto();
			respuesta = new BeanPuerto(clave, nombre, true);
		}
		return respuesta;
	}
}
