package com.srm.pli.schedulers.jobs;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import com.srm.pli.services.KN_Process;

public class ProcesoArchivoKN implements Job {	
	
	@Override
	public void execute(JobExecutionContext arg0) throws JobExecutionException {
		KN_Process.getInstance().procesaArchivo_KN();
	}

}
