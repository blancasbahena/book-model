package com.srm.pli.bo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class FileUploadBO {
	private Long    idUnico ;
	private String  fileName;
	private Long    sizeFileInBytes;
	private String  contentType;
	private String  extent;
	private String  message;
	private boolean error;
}
