package com.srm.pli.schedulers.jobs;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import com.srm.pli.services.ControlPreciosEmailServices;
import com.truper.infra.loggers.BaseLogger;

public class EnviaMailsReminderXDays implements Job {
	private final ControlPreciosEmailServices enviaMails = ControlPreciosEmailServices
			.getInstance();
	
	
	@Override
	public void execute(JobExecutionContext arg0) throws JobExecutionException {
		BaseLogger.SCHEDULER_LOGGER.info("Inicia JOB EnviaMailsReminderXDays");
		try {
			enviaMails.envioMailsXDias();
		} catch (Exception e) {
			JobExecutionException e2 = new JobExecutionException (e);
			e2.setRefireImmediately (false); // para descartar el Job y seguir con el siguiente
			throw e2;
		} finally {
			BaseLogger.SCHEDULER_LOGGER.info("Termina JOB EnviaMailsReminderXDays");
		}
	}

}
