package com.srm.pli.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.srm.pli.bo.BitacoraImpDirBean;
import com.srm.pli.db.ConexionDB;

public class BitacoraImpDirDAO extends DAO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5366216674468521740L;

	@Override
	public List<?> select(Object o) {
		BitacoraImpDirBean bean = BitacoraImpDirBean.class.cast(o);
		List<BitacoraImpDirBean> lstBitacoraImpDir = new ArrayList<BitacoraImpDirBean>();

		Connection con = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		DAOUtils utils = new  DAOUtils();

		StringBuilder select = new StringBuilder("SELECT id, folio, comentario,");
		select.append(" userName, creationDate, creationDateLong");
		select.append(" FROM cdiBitacoraImportsDirector ");
		select.append(" WHERE 1=1 ");
		
		utils.setSelect(true);
		try {
			con = ConexionDB.dameConexion();
			
			if (bean.getFolio() != null) {
				select.append(utils.ajustaColumna(" AND folio = ? "));
			}
			if (bean.getUserName() != null && !"".equals(bean.getUserName())) {
				select.append(utils.ajustaColumna(" AND userName = ? "));
			}
			
			pst = con.prepareStatement(select.toString());
			
			int cont = 1;
			
			utils.inicializaQuery(select.toString());
			
			if (bean.getFolio() != null) {
				utils.ajustaParametro(cont++, pst, bean.getFolio(), Integer.class);
			}
			if (bean.getUserName() != null && !"".equals(bean.getUserName())) {
				utils.ajustaParametro(cont++, pst, bean.getUserName(), String.class);
			}
			
			rs = pst.executeQuery();
			
			while (rs.next()) {
				Integer id = rs.getInt("id");
				Integer folio = rs.getInt("folio");
				String comments = rs.getString("comentario");
				String userName = rs.getString("userName");
				Integer creationDate = rs.getInt("creationDate");
				Long creationDateLong = rs.getLong("creationDateLong");
				
				BitacoraImpDirBean beanTmp = new BitacoraImpDirBean();
				beanTmp.setId(id);
				beanTmp.setFolio(folio);
				beanTmp.setComments(comments);
				beanTmp.setUserName(userName);
				beanTmp.setCreationDate(creationDate);
				beanTmp.setCreationDateLong(creationDateLong);
				
				lstBitacoraImpDir.add(beanTmp);
			}

			ConexionDB.devuelveConexion(con);

		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				BOOKING_LOGGER.error(ex.getMessage(), ex);
			}
			BOOKING_LOGGER.error(e.getMessage(), e);
		} catch (Exception e) {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				BOOKING_LOGGER.error(ex.getMessage(), ex);
			}
			BOOKING_LOGGER.error(e.getMessage(), e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				BOOKING_LOGGER.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
		return lstBitacoraImpDir;
	}

	@Override
	public boolean insert(Object o) {
		BitacoraImpDirBean bean = BitacoraImpDirBean.class.cast(o);
		Connection con = null;
		PreparedStatement pst = null;
		DAOUtils utilDao = new DAOUtils();
		
		StringBuilder insert = new StringBuilder("INSERT INTO cdiBitacoraImportsDirector");
		insert.append(" (folio, comentario, userName, creationDate, creationDateLong)");
		insert.append(" VALUES (?, ?, ?, ?, ?)");
		
		boolean exito = false;
		try {
			con = ConexionDB.dameConexion();
			pst = con.prepareStatement(insert.toString());
			int cont = 1;
			utilDao.ajustaParametro(cont++, pst, bean.getFolio(), Integer.class);			
			utilDao.ajustaParametro(cont++, pst, bean.getComments(), String.class);
			utilDao.ajustaParametro(cont++, pst, bean.getUserName(), String.class);
			utilDao.ajustaParametro(cont++, pst, bean.getCreationDate(), Integer.class);
			utilDao.ajustaParametro(cont++, pst, bean.getCreationDateLong(), Long.class);
			
			utilDao.inicializaQuery(insert.toString());		
			
			exito = pst.executeUpdate() > 0;
			
			ConexionDB.devuelveConexion(con);
		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				BOOKING_LOGGER.error(ex.getMessage(), ex);
			}
			BOOKING_LOGGER.error(e.getMessage(), e);
		} catch (Exception e) {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				BOOKING_LOGGER.error(ex.getMessage(), ex);
			}
			BOOKING_LOGGER.error(e.getMessage(), e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				BOOKING_LOGGER.error(sqlEx2.getMessage(), sqlEx2);
			}
		}

		return exito;
	}

	@Override
	public boolean update(Object o) {
		return false;
	}
	
}
