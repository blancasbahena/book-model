package com.srm.pli.bo;

import java.util.Date;
import java.util.List;

public class BeanMatrizDetallesVista {
	private Date fechaInsert;
	private boolean isBacklog;
	private Date fechaBacklog;
	private Date fechaModificacion;
	private String comentario;
	private List<BeanMatrizDetalles> detalles;

	public BeanMatrizDetallesVista(BeanMatrizDetalles det) {
		this.fechaBacklog = det.getFechaBacklog();
		this.comentario = det.getComentario();
		this.fechaInsert = det.getFechaInsert();
		this.fechaModificacion = det.getFechaModificacion();
		this.isBacklog = det.isBacklog();

	}

	public Date getFechaInsert() {
		return fechaInsert;
	}

	public void setFechaInsert(Date fechaInsert) {
		this.fechaInsert = fechaInsert;
	}

	public boolean isBacklog() {
		return isBacklog;
	}

	public void setBacklog(boolean isBacklog) {
		this.isBacklog = isBacklog;
	}

	public Date getFechaBacklog() {
		return fechaBacklog;
	}

	public void setFechaBacklog(Date fechaBacklog) {
		this.fechaBacklog = fechaBacklog;
	}

	public Date getFechaModificacion() {
		return fechaModificacion;
	}

	public void setFechaModificacion(Date fechaModificacion) {
		this.fechaModificacion = fechaModificacion;
	}

	public String getComentario() {
		return comentario;
	}

	public void setComentario(String comentario) {
		this.comentario = comentario;
	}

	public List<BeanMatrizDetalles> getDetalles() {
		return detalles;
	}

	public void setDetalles(List<BeanMatrizDetalles> detalles) {
		this.detalles = detalles;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("BeanMatrizDetallesVista [getFechaInsert()=");
		builder.append(getFechaInsert());
		builder.append(", isBacklog()=");
		builder.append(isBacklog());
		builder.append(", getFechaBacklog()=");
		builder.append(getFechaBacklog());
		builder.append(", getFechaModificacion()=");
		builder.append(getFechaModificacion());
		builder.append(", getComentario()=");
		builder.append(getComentario());
		builder.append(", getDetalles()=");
		builder.append(getDetalles());
		builder.append("]");
		return builder.toString();
	}

}
