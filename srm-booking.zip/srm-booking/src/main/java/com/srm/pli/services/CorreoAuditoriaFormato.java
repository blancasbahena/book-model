package com.srm.pli.services;

import java.util.List;

import com.srm.pli.format.email.CorreoFormatoGeneral;
import com.truper.businessEntity.BeanAuditoriaSinMatrizDetalle;
import com.truper.utils.date.EnumFechas;
import com.truper.utils.date.UtilsFechas;

public class CorreoAuditoriaFormato {

	private static CorreoAuditoriaFormato instance = new CorreoAuditoriaFormato();

	private CorreoAuditoriaFormato() {
	}

	public static CorreoAuditoriaFormato getInstance() {
		return instance;
	}

	public String buildTableDetalleOrden(List<BeanAuditoriaSinMatrizDetalle> detallePo) {
		StringBuilder table = new StringBuilder();
		table.append(CorreoFormatoGeneral.getInstance().getTrHeader());
		table.append(CorreoFormatoGeneral.getInstance().getThHeader("Position"));
		table.append(CorreoFormatoGeneral.getInstance().getThHeader("Item"));
		table.append(CorreoFormatoGeneral.getInstance().getThHeader("ETD"));
		table.append("</tr>");
		for (int i = 0; i < detallePo.size(); i++) {
			BeanAuditoriaSinMatrizDetalle bean = detallePo.get(i);
			if (i % 2 == 0) {
				table.append(CorreoFormatoGeneral.getInstance().getTrEven());
			} else {
				table.append(CorreoFormatoGeneral.getInstance().getTrOdd());
			}
			table.append(CorreoFormatoGeneral.getInstance().getTd(bean.getPosicion()));
			table.append(CorreoFormatoGeneral.getInstance().getTd(bean.getMaterial()));
			table.append(CorreoFormatoGeneral.getInstance()
					.getTd(UtilsFechas.setConvierteFechaToString(bean.getEtd(), EnumFechas.FORMATO_YYYY_MM_DD)));
			table.append("</tr>");
		}
		return table.toString();
	}

}
