package com.srm.pli.bo;

import java.util.List;

import com.truper.businessEntity.BeanPuerto;

import lombok.Data;

@Data
public class BeanUserPOD {

	private String user;
	private List<BeanPuerto> listPorts;
}
