package com.srm.pli.dao.sql;

public class CatalogosSQL {

	public static final String SELECT_UNIDAD_MEDIDA;
	public static final String SELECT_PROVEEDOR_MODULO_DONDE;
	public static final String SELECT_PROVEEDOR_MODULO;

	static {
		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT abreviatura FROM cdiCatalogoUnidadesMedida ");
		SELECT_UNIDAD_MEDIDA = sql.toString();

		sql = new StringBuilder();
		sql.append(" SELECT supplier FROM cdiProveedorModulo ");
		SELECT_PROVEEDOR_MODULO = sql.toString();

		sql = new StringBuilder();
		sql.append(" SELECT supplier FROM cdiProveedorModulo WHERE supplier = ? ");
		SELECT_PROVEEDOR_MODULO_DONDE = sql.toString();
	}

}
