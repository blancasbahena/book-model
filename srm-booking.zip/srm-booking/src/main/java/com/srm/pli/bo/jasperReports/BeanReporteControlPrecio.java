package com.srm.pli.bo.jasperReports;

import java.io.Serializable;
import java.util.Date;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BeanReporteControlPrecio implements Serializable {
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -6406856954522534488L;
	
	private Date logDate;
	private Date createDate;
	private String po;
	private Date etd;
	private Integer daysLeftForEtd;
	private String proveedor;
	private String proveedorDescripcion;
	private String bu;
	private String planeador;
	private Integer daysLeftFromLogDate;
	private String comentarios;
	private Integer idaMinimo;
	private String comprador;
	private String directorBU;
	
	public Date getLogDate() {
		return logDate;
	}

	public void setLogDate(Date logDate) {
		this.logDate = logDate;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public String getPo() {
		return po;
	}

	public void setPo(String po) {
		this.po = po;
	}

	public Date getEtd() {
		return etd;
	}

	public void setEtd(Date etd) {
		this.etd = etd;
	}

	public Integer getDaysLeftForEtd() {
		return daysLeftForEtd;
	}

	public void setDaysLeftForEtd(Integer daysLeftForEtd) {
		this.daysLeftForEtd = daysLeftForEtd;
	}

	public String getProveedor() {
		return proveedor;
	}

	public void setProveedor(String proveedor) {
		this.proveedor = proveedor;
	}

	public String getProveedorDescripcion() {
		return proveedorDescripcion;
	}

	public void setProveedorDescripcion(String proveedorDescripcion) {
		this.proveedorDescripcion = proveedorDescripcion;
	}

	public String getBu() {
		return bu;
	}

	public void setBu(String bu) {
		this.bu = bu;
	}

	public String getPlaneador() {
		return planeador;
	}

	public void setPlaneador(String planeador) {
		this.planeador = planeador;
	}

	public Integer getDaysLeftFromLogDate() {
		return daysLeftFromLogDate;
	}

	public void setDaysLeftFromLogDate(Integer daysLeftFromLogDate) {
		this.daysLeftFromLogDate = daysLeftFromLogDate;
	}

	public String getComentarios() {
		return comentarios;
	}

	public void setComentarios(String comentarios) {
		this.comentarios = comentarios;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("BeanReporteControlPrecio [getLogDate=");
		builder.append(getLogDate());
		builder.append(", getCreateDate=");
		builder.append(getCreateDate());
		builder.append(", getPo=");
		builder.append(getPo());
		builder.append(", getEtd=");
		builder.append(getEtd());
		builder.append(", getDaysLeftForEtd=");
		builder.append(getDaysLeftForEtd());
		builder.append(", getProveedor=");
		builder.append(getProveedor());
		builder.append(", getProveedorDescripcion=");
		builder.append(getProveedorDescripcion());
		builder.append(", getBu=");
		builder.append(getBu());
		builder.append(", getPlaneador=");
		builder.append(getPlaneador());
		builder.append(", getDaysLeftFromLogDate=");
		builder.append(getDaysLeftFromLogDate());
		builder.append(", getComentarios=");
		builder.append(getComentarios());
		builder.append("]");
		return builder.toString();
	}

}
