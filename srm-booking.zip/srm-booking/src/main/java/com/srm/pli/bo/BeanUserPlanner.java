package com.srm.pli.bo;

import java.util.List;

import lombok.Data;

@Data
public class BeanUserPlanner {

	private String user;
	private List<BeanPlanners> listPlanners;
}
