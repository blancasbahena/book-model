package com.srm.pli.services;

import com.srm.pli.utils.FuncionesComunesPLI;
import com.truper.businessEntity.ContenedorCDI;
import com.truper.utils.string.UtilsString;

public class ContenedorService {

	private static ContenedorService instance;

	private ContenedorService() {
		FuncionesComunesPLI.cargaContenedores(false);
	}

	public static ContenedorService getInstance() {
		if (instance == null)
			instance = new ContenedorService();
		return instance;
	}

	public String getDescripcion(Integer tipoContenedor) {
		if (tipoContenedor == null)
			return null;
		String descripcion = null;
		ContenedorCDI contenedor = FuncionesComunesPLI.mapaContenedores.get(tipoContenedor);
		if (contenedor != null && UtilsString.isStringValida(contenedor.getNombre())) {
			descripcion = contenedor.getNombre().trim();
		}
		return descripcion;
	}
}
