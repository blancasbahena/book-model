package com.srm.pli.helper;

import com.truper.businessEntity.BeanPuerto;


public class FormatBeanPuerto {
	
	
	private String clave;
	private String nombre;
	
	
	/**
	 * Metodo para formatear en json y mandarlo a la vista
	 * 
	 * @param bean
	 */
	public void format(BeanPuerto bean ){
		clave 	= String.valueOf(bean.getClave());
		nombre 	= bean.getNombre();
	}

	
	public String getClave(){
		return clave;
	}
	
	public String getNombre(){
		return nombre;
	}
	
}
