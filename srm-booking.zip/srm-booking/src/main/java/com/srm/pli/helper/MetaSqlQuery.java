package com.srm.pli.helper;

import java.io.Serializable;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MetaSqlQuery implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4281720210574525729L;

	private List<MetaSqlQuery> metaDataQuery = null;

	private int parameterIndex;
	private Object queryData;

	private MetaSqlQuery(int parameterIndex, Object queryData) {
		this.parameterIndex = parameterIndex;
		this.queryData = queryData;
	}

	public MetaSqlQuery() {
	}

	public void addDataQuery(int parameterIndex, Object queryData) {
		MetaSqlQuery queryParam = new MetaSqlQuery(parameterIndex, queryData);
		if (this.metaDataQuery == null) {
			this.metaDataQuery = new ArrayList<MetaSqlQuery>();
		}
		metaDataQuery.add(queryParam);
	}

	public void addParamsToPreparedStatement(PreparedStatement preparedStatement)
			throws SQLException {
		if (this.metaDataQuery == null) {
			return;
		}
		for (MetaSqlQuery msq : this.metaDataQuery) {
			int paramIndx = msq.getParameterIndex();
			preparedStatement.setObject(paramIndx, msq.getQueryData());
		}
	}

	private int getParameterIndex() {
		return parameterIndex;
	}

	private Object getQueryData() {
		return queryData;
	}

}
