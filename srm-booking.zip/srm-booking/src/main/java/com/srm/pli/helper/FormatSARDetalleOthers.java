package com.srm.pli.helper;

import java.math.BigDecimal;

import com.srm.pli.bo.SarDetalleBO;
import com.srm.pli.utils.FuncionesComunesPLI;
import com.srm.pli.utils.Utilerias;
import com.truper.utils.number.UtilsNumero;

public class FormatSARDetalleOthers extends FormatSARDetalle {
	
	public FormatSARDetalleOthers(SarDetalleBO bean) {
		setFolio(bean.getFolio());
		setPo(bean.getPo());
		setPoOtherItem(bean.getPoOtherItem());
		setPosicion(bean.getPosicion());
		setDescripcion(bean.getDescripcion());
		setCantidad(FuncionesComunesPLI.formatea(bean.getCantidad()));
		setCantidadSinFormato(bean.getCantidad());
		setPesoProveedor(FuncionesComunesPLI.formatea(bean.getPesoProveedor(), 2));
		setVolumenProveedor(FuncionesComunesPLI.formatea(bean.getVolumenProveedor(), 2));
		String cantidadModificada = bean.getCantidadModificada() == null ? "-" : FuncionesComunesPLI.formatea(bean.getCantidadModificada());
		setCantidadModificada(cantidadModificada);
		String pesoModificado = bean.getPesoModificado() == null ? "-" : FuncionesComunesPLI.formatea(bean.getPesoModificado(),0);
		setPesoModificado(pesoModificado);
		String volumenModificado = bean.getVolumenModificado() == null ? "-" : FuncionesComunesPLI.formatea(bean.getVolumenModificado(), 2);
		setVolumenModificado(volumenModificado);
		String precioUnitario = (UtilsNumero.isGreaterThanZero(bean.getPrecioUnitario())) ? Utilerias.formatNumber(bean.getPrecioUnitario(), 4)
				: "-" ;
		setPrecioUnitario(precioUnitario);
		setTipoModificacionConfirmFinal(bean.getTipoModificacion());
		setMarca(bean.getMarca() != null ? bean.getMarca()  : "" );
		setValorEmbarque(bean.getValorEmbarque() != null ? FuncionesComunesPLI.formatea(bean.getValorEmbarque().doubleValue(), 2) : "");
		setClave(bean.getMaterial() != null ? bean.getMaterial().toString()  : "");
		setDescripcionReporte(bean.getDescripcion());
		setUnidadMedida(bean.getUnidaMedida() != null ? bean.getUnidaMedida() : "");
		setCartones(bean.getCartones() != null ? bean.getCartones()+"" : "");
		setPesoBrutoPKL(bean.getPesoBrutoPKL() != null ? bean.getPesoBrutoPKL().setScale(2, BigDecimal.ROUND_HALF_EVEN)+"" : "");
		setPesoNetoPKL(bean.getPesoNetoPKL() != null ? bean.getPesoNetoPKL().setScale(2, BigDecimal.ROUND_HALF_EVEN)+"" : "");
		setCubicajePKL(bean.getCubicajePKL() != null ? bean.getCubicajePKL().setScale(2, BigDecimal.ROUND_HALF_EVEN)+"" : "");
		setPagadero(PriceReleaseHelper.getInstance().isOtherItemWithPago(bean.getPo()));
	}
}
