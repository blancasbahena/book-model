package com.srm.pli.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.srm.pli.bo.BeanControlEmb;
import com.srm.pli.db.ConexionDB;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class ControlEmbDao {
	
	private static ControlEmbDao instance = null;

	private ControlEmbDao() {
	}

	public static ControlEmbDao getInstance() {
		if (instance == null)
			instance = new ControlEmbDao();
		return instance;
	}
	
	public List<BeanControlEmb> getPendRecp() throws SQLException {
		List<BeanControlEmb> lista = null;
		Connection con = null;
		StringBuffer sql = new StringBuffer();
		try {
			con = ConexionDB.dameConexion();
			
			sql.append("select ashl.action, nav.nombre, s.etdFinal as etd, s.eta, s.contenedor, s.booking, '' as unidadNegocio, s.folio, p.descripcion as proveedor ");
			sql.append("from cdiSAR s ");
			sql.append("inner join cdiNavieras as nav on nav.clave = s.naviera ");
			sql.append("inner join cdiControlEmbarque ce on ce.folio = s.folio and ce.booking = s.booking ");
			sql.append("inner join cdiSARHistoryLog shl  ");
			sql.append("	on shl.folio = s.folio and shl.booking = s.booking and shl.bl = s.BL ");
			sql.append("inner join cdiActionsSARHistoryLog ashl ");
			sql.append("	on ashl.id = shl.action and shl.createDate = (SELECT MAX(createDate) from cdiSARHistoryLog where folio = s.folio) ");
			sql.append("inner join srm_PROVEEDORES p ");
			sql.append("	on convert(int, p.CLAVE) = s.proveedor ");
			sql.append("where  (contenedor IS NOT NULL and s.contenedor <> '' and s.contenedor <> '-') and (s.booking IS NOT NULL and s.booking <> '') ");
			sql.append("and s.etdFinal = convert(varchar, getdate() - 6, 112) ");
			sql.append("order by modificationTimeStamp desc ");
			
			
			try (PreparedStatement pst = con.prepareStatement(sql.toString())) {
				try (ResultSet rs = pst.executeQuery()) {
					lista = new ArrayList<>();
					BeanControlEmb bo;
					while (rs.next()) {
						bo = new BeanControlEmb();
						bo.setStatusDoc(rs.getString("action"));
						bo.setNaviera(rs.getString("nombre"));
						bo.setEtd(rs.getString("etd") == null ? "-" : rs.getString("etd"));
						bo.setEta(rs.getString("eta") == null ? "-" : rs.getString("eta"));
						bo.setContenedor(
								(rs.getString("contenedor") == null || rs.getString("contenedor").equals("")) ? "-"
										: rs.getString("contenedor"));
						bo.setBooking((rs.getString("booking") == null || rs.getString("booking").equals("")) ? "-"
								: rs.getString("booking"));
						bo.setUnidadNegocio((rs.getString("unidadNegocio") == null || rs.getString("unidadNegocio").equals("")) ? "-"
								: rs.getString("unidadNegocio"));
						bo.setFolio((rs.getString("folio") == null || rs.getString("folio").equals("")) ? "-"
								: rs.getString("folio"));
						bo.setProovedor(rs.getString("proveedor"));
						lista.add(bo);
					}
				}
			}
			ConexionDB.devuelveConexion(con);
			return lista;
		} catch (Exception sqle) {
			log.error("Error al ejecutar la sentencia {}",sql.toString(),sqle);
			try {
				ConexionDB.devuelveConexion(con);
			} catch (SQLException e) {
				log.error("Error:",e);
			}
			throw new SQLException(sqle);
		}
		
	}
	
	public List<BeanControlEmb> getPendRecpEta() throws SQLException {
		List<BeanControlEmb> lista = null;
		Connection con = null;
		StringBuffer sql = new StringBuffer();
		try {
			con = ConexionDB.dameConexion();
			
			sql.append("select ashl.action, nav.nombre, s.eta, s.contenedor, sd.material, f.numero_factura_pm pm, csdi.analista, s.folio, sd.cantidad total ");
			sql.append("from cdiSAR s ");
			sql.append("LEFT JOIN cdiSarDetalle sd ON s.folio = sd.folio ");
			sql.append("inner join cdiNavieras as nav on nav.clave = s.naviera ");
			sql.append("inner join cdiControlEmbarque ce on ce.folio = s.folio and ce.booking = s.booking ");
			sql.append("left join cdiControlSDI as csdi on csdi.proveedor = s.proveedor and csdi.booking = s.booking ");
			sql.append("inner join cdiSARHistoryLog shl  ");
			sql.append("	on shl.folio = s.folio and shl.booking = s.booking and shl.bl = s.BL ");
			sql.append("inner join cdiActionsSARHistoryLog ashl ");
			sql.append("	on ashl.id = shl.action and shl.createDate = (SELECT MAX(createDate) from cdiSARHistoryLog where folio = s.folio) ");
			sql.append("LEFT JOIN facturacion f ON f.sar = s.folio ");
			sql.append("where  (contenedor IS NOT NULL and s.contenedor <> '' and s.contenedor <> '-') and (s.booking IS NOT NULL and s.booking <> '') ");
			sql.append("and DATEDIFF(DAY, GETDATE(), CONVERT(date, CAST(s.eta AS CHAR(8)), 112)) = 10 ");
			sql.append("order by modificationTimeStamp desc ");
			
			
			try (PreparedStatement pst = con.prepareStatement(sql.toString())) {
				try (ResultSet rs = pst.executeQuery()) {
					lista = new ArrayList<>();
					BeanControlEmb bo;
					while (rs.next()) {
						bo = new BeanControlEmb();
						bo.setStatusDoc(rs.getString("action"));
						bo.setNaviera(rs.getString("nombre"));
						bo.setEta(rs.getString("eta") == null ? "-" : rs.getString("eta"));
						bo.setContenedor(
								(rs.getString("contenedor") == null || rs.getString("contenedor").equals("")) ? "-"
										: rs.getString("contenedor"));
						bo.setInvFabrica(rs.getString("material"));
						bo.setFacturaPm(rs.getString("pm"));
						bo.setSdiAnalist(rs.getString("analista"));
						bo.setFolio((rs.getString("folio") == null || rs.getString("folio").equals("")) ? "-"
								: rs.getString("folio"));
						bo.setTotal(rs.getInt("total"));
						lista.add(bo);
					}
				}
			}
			ConexionDB.devuelveConexion(con);
			return lista;
		} catch (Exception sqle) {
			log.error("Error al ejecutar la sentencia {}",sql.toString(),sqle);
			try {
				ConexionDB.devuelveConexion(con);
			} catch (SQLException e) {
				log.error("Error:",e);
			}
			throw new SQLException(sqle);
		}
		
	}

}
