package com.srm.pli.services;

import com.srm.pli.bo.DataEmailBean;

public interface CdiConfPropertiesService
{
	String getValor(String llave);
	DataEmailBean getPropertiesByIdasPendientes();
}
