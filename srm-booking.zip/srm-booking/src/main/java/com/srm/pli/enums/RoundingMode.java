package com.srm.pli.enums;

import java.math.BigDecimal;

/**
 * Enum que se utilizara para saber cuantos decimales mostrar por 
 * tipo de dato, ejemplo Peso, volumen, precio unitario
 * Asi lograremos tener un mejor control
 * 
 * 
 * Inicio pruebas con volumen, es necesario empezar a probar con
 * los otros datos
 * @author drodriguezv
 *
 */
public enum RoundingMode {
	
	VOLUMEN(3,BigDecimal.ROUND_DOWN),
	PESO(3,BigDecimal.ROUND_DOWN),
	PRECIO_UNITARIO(5,BigDecimal.ROUND_DOWN);
	

	private final int decimales;
	private final int roundingMode;
	
	/**
	 * 
	 * @param decimales --> me indica el numero de decimales
	 * @param roundingMode --> seguimos el standar de BigDecimal.RoundingMode
	 */
	RoundingMode(int decimales,int roundingMode) {
		this.decimales = decimales;
		this.roundingMode = roundingMode;
		
	}

	public int getDecimales() {
		return decimales;
	}
	
	public int getRoundingMode() {
		return roundingMode;
	}
	
}
