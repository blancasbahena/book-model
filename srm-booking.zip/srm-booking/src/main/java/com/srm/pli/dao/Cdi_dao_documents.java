package com.srm.pli.dao;

import static com.srm.pli.dao.sql.DocumentosSql.SELECT_SET_DOCUMENTOS;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;

import com.srm.fungandrui.parcelmobi.models.DocumentosProveedorModel;
import com.srm.pli.db.ConexionDB;

import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

@Getter
@Slf4j
public class Cdi_dao_documents {
	
	private static Cdi_dao_documents instance;
	
	public static Cdi_dao_documents getInstance() {
		if (instance == null) {
			instance = new Cdi_dao_documents();
		}
		return instance;
	}
	

	public List<DocumentosProveedorModel> getDocumentsByBookingSupplier(String booking, String proveedor)
			throws ServletException {
		Connection con = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		List<DocumentosProveedorModel> documentsList = new ArrayList<DocumentosProveedorModel>();
		try {
			con = ConexionDB.dameConexion();
			pst = con.prepareStatement(SELECT_SET_DOCUMENTOS);
			pst.setString(1, proveedor);
			pst.setString(2, booking);

			rs = pst.executeQuery();

			while (rs.next()) {
				DocumentosProveedorModel documentos = new DocumentosProveedorModel();
				documentos.setTipoDocumento(rs.getString("tipo"));
				documentos.setRutaArchivo(rs.getString("rutaArchivo"));
				documentos.setNombreFactura(rs.getString("nombre"));
				documentos.setCondicionPago(rs.getString("condicionPago"));
				documentos.setFacturaOtros(rs.getBoolean("tieneOtros"));
				documentos.setId(rs.getInt("id"));

				documentsList.add(documentos);
			}

			rs.close();
			pst.close();
		} catch (Exception e) {
			log.error(e.getMessage() , e);
		} finally {
			ConexionDB.devolver(con);
		}
		return documentsList;

	}


	
	

}
