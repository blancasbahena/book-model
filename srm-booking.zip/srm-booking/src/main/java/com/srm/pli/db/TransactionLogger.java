package com.srm.pli.db;

import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.GregorianCalendar;

import com.srm.pli.utils.OutputStream2String;
import com.srm.pli.utils.Utilerias;

public class TransactionLogger{
	private static final int TOP_N_LONGEST_CONNECTIONS = 10;

	public class Unit implements Comparable<Unit>{
		private String table;
		private String sql;
		private String startTime;
		private String endTime;
		private long duration;
		private String strDuration;
        private Exception stackTraceExcep;
        private String stackTrace = null;
		
		/**Method that returns the SQL instruction used in this Statement registry.
		 * @return The SQL instruction used in this Statement registry.
		 */
		public String getSQL(){ return sql; }
        /**Method that returns the StackTrace related to this Statement registry.
         * @return The stack trace in this Statement registry.
         */
		public String getStackTrace() {
		    if ( stackTrace == null ) {
		        OutputStream2String convertidor = new OutputStream2String(); 
		        stackTraceExcep.printStackTrace( new PrintStream( convertidor ) );
		        stackTrace = convertidor.dameString();
		    }
		    return stackTrace;
		}
		/**Method that returns the formated start time of this Statement registry.
		 * @return The formated start time of this Statement registry.
		 */
		public String getStartTime(){ return startTime; }
		/**Method that returns the formated end time of this Statement registry.
		 * @return The formated end time of this Statement registry.
		 */
		public String getEndTime(){ return endTime; }
		/**Method that returns the formated time duration of this Statement registry.
		 * @return The formated time duration of this Statement registry.
		 */
		public String getDuration(){ return strDuration; }
		/**Method that returns the name of the table used in this Statement registry.
		 * @return The name of the table used in this Statement registry.
		 */
		public String getTableInvolved(){ return table; }
		
		public int getSize(){
			return table.length() + sql.length() + startTime.length() + endTime.length() + strDuration.length() + 22;		//22 ar the extra characters added on toString() method
		}
	
		public String toString(){
			StringBuilder sb = new StringBuilder("");
			sb.append(" |TIME_").append( strDuration ).append("|START_").append(startTime).
				append("|END_").append(endTime.toString()).append("|").append(sql).append("\n");
			return sb.toString();
		}

		public int compareTo(Unit u){
			long difference = u.duration - duration;
			
			return (difference==0? 0 : (difference>0? 1 : -1));
		}
	}

	//private GregorianCalendar loggingTime = new GregorianCalendar();
	private ArrayList<Unit> logs = new ArrayList<Unit>(TOP_N_LONGEST_CONNECTIONS);
	
	public TransactionLogger(){}
	
	private Unit createUnit(String tableInvolved, String sql, GregorianCalendar startTime, GregorianCalendar endTime) {
        Unit u = new Unit();
        u.table = tableInvolved;
        u.sql = sql;
        u.startTime = Utilerias.formatDateExtreme(startTime, Utilerias.SHORT_YEAR, Utilerias.NUMERIC_MONTH, Utilerias.ADD_PRECEDING_ZERO, 
                Utilerias.ADD_PRECEDING_ZERO, Utilerias.DMY, Utilerias.HOUR_MIN_SEC_MIL, Utilerias._24H, Utilerias.ENGLISH);
        u.endTime = Utilerias.formatDateExtreme(endTime, Utilerias.SHORT_YEAR, Utilerias.NUMERIC_MONTH, Utilerias.ADD_PRECEDING_ZERO, 
                Utilerias.ADD_PRECEDING_ZERO, Utilerias.DMY, Utilerias.HOUR_MIN_SEC_MIL, Utilerias._24H, Utilerias.ENGLISH);
        u.duration = endTime.getTimeInMillis()-startTime.getTimeInMillis();
        u.strDuration = Utilerias.formatTime(u.duration);
        u.stackTraceExcep = new Exception();
	    return u;
	}
	
	public void AddTransactionLogger(String tableInvolved, String sql, GregorianCalendar startTime, GregorianCalendar endTime){
		
		if(logs.size()<TOP_N_LONGEST_CONNECTIONS){
			logs.add( createUnit( tableInvolved, sql, startTime, endTime ) );
			Collections.sort(logs);
		}else{
		    long duration = endTime.getTimeInMillis()-startTime.getTimeInMillis();
			if( duration > logs.get(TOP_N_LONGEST_CONNECTIONS-1).duration ) {
				logs.remove(TOP_N_LONGEST_CONNECTIONS-1);	//removing last, to add latest
				logs.add( createUnit( tableInvolved, sql, startTime, endTime ) );
				Collections.sort(logs);	
			}
		}
	}
	
	public String toString(){
		StringBuilder sb = new StringBuilder("");
		
		for(Unit u : logs){
			sb.append( u.toString() ).append( System.getProperty("line.separator") );
		}
		
		return sb.toString();
	}

	public ArrayList<Unit> getLogs(){
		return new ArrayList<Unit>(logs);
	}
}
