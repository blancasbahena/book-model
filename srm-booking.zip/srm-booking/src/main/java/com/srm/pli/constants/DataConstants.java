package com.srm.pli.constants;

public class DataConstants
{
	public static final String SAR_TYPE = "F";
	public static final String SAR_COMMENTS_HISTORY_LOG = "A TSR has been already created today";
}
