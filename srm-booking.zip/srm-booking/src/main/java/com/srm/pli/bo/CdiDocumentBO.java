package com.srm.pli.bo;

import com.srm.pli.utils.FuncionesComunesPLI;
import com.truper.businessEntity.CDIDocumentosBean;

public class CdiDocumentBO extends CDIDocumentosBean{

	private String		fechaCrea;
	private String		rutaArch;
		
	
	public  CdiDocumentBO() {
		
	}
	
	public  CdiDocumentBO(CDIDocumentosBean bean) {
		super();
		
		setSar(bean.getSar());
		setNumero(bean.getNumero());
		setFecha(bean.getFecha());
		setEsGenerado(bean.getEsGenerado());
		setPos( 		 bean.getPos());
		setTipo( 		 bean.getTipo());
		setPackagesAmpara(  bean.getPackagesAmpara());
		setEmbarcaMadera(  bean.getEmbarcaMadera());
		setObservaciones( bean.getObservaciones());
		setRepresentanteLegal( bean.getRepresentanteLegal());
		setVersion( bean.getVersion());
		setRuta(bean.getRuta());
		setNombreArch( bean.getNombreArch());
		setTipoMoneda( bean.getTipoMoneda());
		setFechaCreacion( bean.getFechaCreacion());
		setAprobadoSDI( bean.esAprobadoSDI());
		setFechaUpdate(	 	bean.getFechaUpdate());
		setUsuarioUpdate( bean.getUsuarioUpdate());
		setPrioridad( bean.getPrioridad());
		//nueva variable
		setFechaCrea( FuncionesComunesPLI.formatea(getFechaCreacion()));
		setNombreUsuario( bean.getNombreUsuario());
		
		setComentarioRechazo(bean.getComentarioRechazo());
		setFechaRechazo(bean.getFechaRechazo());
		setFechaRechazoLong(bean.getFechaRechazoLong());
		setUsuarioRechazo(bean.getUsuarioRechazo());
		
		
		String rutaApache = "";
		String tmp = getRuta().substring(4);
		tmp = tmp.replace("\\\\", "/");
		tmp = tmp.replace("\\", "/");
		rutaApache+="http://"+tmp+getNombreArch();
		
		rutaArch=rutaApache;
		
	}
	
	
	
	/**  Getters & setters  **/	

	public String getFechaCrea() {
		return fechaCrea;
	}


	public void setFechaCrea(String fechaCrea) {
		this.fechaCrea = fechaCrea;
	}

	public String getRutaArch() {
		return rutaArch;
	}

	public void setRutaArch(String rutaArch) {
		this.rutaArch = rutaArch;
	}

	
}
