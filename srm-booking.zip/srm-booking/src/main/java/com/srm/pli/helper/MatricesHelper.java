package com.srm.pli.helper;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import com.srm.fungandrui.facturacion.dto.ReporteProcesoSifeDTO;
import com.srm.pli.bo.BeanMatrizCabecera;
import com.srm.pli.bo.BeanMatrizDetalles;
import com.srm.pli.bo.BeanMatrizDetallesVista;
import com.srm.pli.bo.BeanMatrizVistaCabecera;
import com.srm.pli.utils.FuncionesComunesPLI;
import com.srm.pli.utils.FuncionesWebservises;
import com.srm.pli.utils.ProductoUtils;
import com.truper.bpm.enums.StatusControlMatricesEnum;
import com.truper.businessEntity.BeanComparaRegInfo;
import com.truper.businessEntity.ImportacionesProveedoresBean;
import com.truper.businessEntity.ProductoBean;
import com.truper.utils.date.EnumFechas;
import com.truper.utils.date.UtilsFechas;

public class MatricesHelper {

	private static final MatricesHelper instance = new MatricesHelper();

	private MatricesHelper() {
		FuncionesComunesPLI.getProveedores(false);
	}

	public static MatricesHelper getInstance() {
		return instance;
	}

	/**
	 * Regresa los status de rechazados mas el status de nuevo, que son los que
	 * deben listarse en la vista de matrices
	 * 
	 * @return
	 */
	public Set<String> dameStatusParaMostrarseEnMatriz() {
		Set<String> result = new HashSet<>();
		result.add(StatusControlMatricesEnum.NEW.id());
		return result;
	}

	/**
	 * Regresa los status marcados como rechazados
	 * 
	 * @return
	 */
	public Set<String> dameStatusRechazados() {
		Set<String> result = new HashSet<>();
		for (StatusControlMatricesEnum data : StatusControlMatricesEnum.values()) {
			if (data.isRechazado() == 2 && data.isMatriz()) {
				result.add(data.id());
			}
		}
		return result;
	}

	public Set<String> dameStatusAceptados() {
		Set<String> result = new HashSet<>();
		for (StatusControlMatricesEnum data : StatusControlMatricesEnum.values()) {
			if (data.isRechazado() == 1 && data.isMatriz()) {
				result.add(data.id());
			}
		}
		return result;
	}

	public Set<String> dameStatusAceptadosReportes() {
		Set<String> result = new HashSet<>();
		for (StatusControlMatricesEnum data : StatusControlMatricesEnum.values()) {
			if (data.isRechazado() == 1) {
				result.add(data.id());
			}
		}
		return result;
	}

	public String dameDescripcionEnum(String status) {
		for (StatusControlMatricesEnum data : StatusControlMatricesEnum.values()) {
			if (data.id().equals(status)) {
				return data.getDescripcion();
			}
		}
		return "";
	}

	public Comparator<BeanMatrizCabecera> ordenaResultadosVista() {
		return new Comparator<BeanMatrizCabecera>() {
			Set<String> rechazados = dameStatusRechazados();

			@Override
			public int compare(BeanMatrizCabecera o1, BeanMatrizCabecera o2) {
				int compTmp = Boolean.compare(o2.isBacklog(), o1.isBacklog());
				if (compTmp != 0) {
					return compTmp;
				}
				// Compara si es NEW
				compTmp = Boolean.compare(StatusControlMatricesEnum.NEW.equals(o2.getStatus()),
						StatusControlMatricesEnum.NEW.equals(o1.getStatus()));
				if (compTmp != 0) {
					return compTmp;
				}
				compTmp = o1.getFechaInsert().compareTo(o2.getFechaInsert());
				if (compTmp != 0) {
					return compTmp;
				}
				compTmp = Boolean.compare(rechazados.contains(o1.getStatus().id()),
						rechazados.contains(o2.getStatus().id()));
				return compTmp;
			}
		};
	}

	public List<BeanMatrizVistaCabecera> generaBeanVista(List<BeanMatrizCabecera> lista) {
		List<BeanMatrizVistaCabecera> datoReturn = new ArrayList<>();
		for (BeanMatrizCabecera tmp : lista) {
			datoReturn.add(generaBeanVista(tmp));
		}
		return datoReturn;
	}

	public BeanMatrizVistaCabecera generaBeanVista(BeanMatrizCabecera cabeza) {
		BeanMatrizVistaCabecera obj = new BeanMatrizVistaCabecera();
		Date dateHoy = new Date();

		obj.setBacklog(cabeza.isBacklog());
		obj.setFechaBacklog(cabeza.getFechaBacklog());
		obj.setBu(ProductoUtils.getInstance().getBUName(cabeza.getMaterial().toString(), cabeza.getCentro()));
		obj.setComentario(cabeza.getComentario() != null ? cabeza.getComentario() : "");
		obj.setDaysFromLogDate((int) FuncionesComunesPLI.daysBetween(
				UtilsFechas.setConvierteFechaToInt(cabeza.getFechaInsert(), EnumFechas.FORMATO_YYYYMMDD),
				UtilsFechas.setConvierteFechaToInt(dateHoy, EnumFechas.FORMATO_YYYYMMDD)));
		obj.setDaysLeftETD((int) FuncionesComunesPLI.daysBetween(
				UtilsFechas.setConvierteFechaToInt(dateHoy, EnumFechas.FORMATO_YYYYMMDD), cabeza.getEtd()));
		obj.setFechaBacklog(cabeza.getFechaBacklog());
		if (cabeza.isBacklog()) {
			obj.setHoursFromBacklog(dameHorasEntreFechas(cabeza.getFechaBacklog(), dateHoy));
		}
		obj.setHoursFromInsert(dameHorasEntreFechas(cabeza.getFechaInsert(), dateHoy));

		obj.setFechaInsert(cabeza.getFechaInsert());
		obj.setFechaModificacion(cabeza.getFechaModificacion());
		obj.setSupplierName(FuncionesComunesPLI.getProveedor(cabeza.getProveedor()) != null
				? FuncionesComunesPLI.getProveedor(cabeza.getProveedor()).getNombreProveedor()
				: "");
		obj.setSupplierNumber(FuncionesComunesPLI.getProveedor(cabeza.getProveedor()) != null
				? FuncionesComunesPLI.getProveedor(cabeza.getProveedor()).getClaveProveedor()
				: "");
		obj.setStatus(cabeza.getStatus().id());
		obj.setStatusDescripcion(cabeza.getStatus().getDescripcion());
		obj.setPo(cabeza.getPo());
		obj.setEtd(UtilsFechas.setConvierteFechaIntToDate(cabeza.getEtd()));
		Set<String> rechazados = dameStatusRechazados();
		obj.setRejected(rechazados.contains(cabeza.getStatus().id()));
		obj.setxDias(cabeza.getxDias() != null ? cabeza.getxDias() : 0);
		return obj;
	}

	public BeanMatrizDetallesVista generaBeanVistaDetalle(List<BeanMatrizDetalles> detalle) {
		BeanMatrizDetallesVista vista = new BeanMatrizDetallesVista(detalle.get(0));
		// Necesito una lista de productos
		List<String> listaProductos = new ArrayList<>();
		for (BeanMatrizDetalles tmp : detalle) {
			listaProductos.add(tmp.getMaterial().toString());
		}

		Map<String, BeanComparaRegInfo> hash = FuncionesWebservises
				.getDatosPreciosMaterial(detalle.get(0).getProveedor(), listaProductos);

		for (BeanMatrizDetalles d : detalle) {
			ProductoBean p = FuncionesComunesPLI.productos.get(d.getMaterial().toString());
			if (p != null) {
				d.setDescripcionMaterial(p.getDescripcion());
			}

			if (hash != null && hash.containsKey(d.getMaterial().toString())) {
				BeanComparaRegInfo bcr = hash.get(d.getMaterial().toString());

				d.setPrecio(bcr.getPrecio1());
				d.setPrecio2(bcr.getPrecio2());
				d.setPrecio3(bcr.getPrecio3());
				d.setPrecio4(bcr.getPrecio4());

				if (bcr.getPrecio1() != bcr.getPrecio2()) {
					d.setUltimoPrecio(1);
				} else if (bcr.getPrecio2() != bcr.getPrecio3()) {
					d.setUltimoPrecio(2);
				} else if (bcr.getPrecio3() != bcr.getPrecio4()) {
					d.setUltimoPrecio(3);
				} else {
					d.setUltimoPrecio(4);
				}

				d.setMoneda(bcr.getMoneda1());
				d.setMoneda2(bcr.getMoneda2());
				d.setMoneda3(bcr.getMoneda3());
				d.setMoneda4(bcr.getMoneda4());
				d.setVigInicio(bcr.getVigenciaIni1());
				d.setVigInicio2(bcr.getVigenciaIni2());
				d.setVigInicio3(bcr.getVigenciaIni3());
				d.setVigInicio4(bcr.getVigenciaIni4());
				d.setVigFin(bcr.getVigenciaFin1());
				d.setVigFin2(bcr.getVigenciaFin2());
				d.setVigFin3(bcr.getVigenciaFin3());
				d.setVigFin4(bcr.getVigenciaFin4());
			}
		}
		vista.setDetalles(detalle);
		return vista;
	}

	public int dameHorasEntreFechas(Date d1, Date d2) {
		long diferencia = (((Math.abs(d1.getTime() - d2.getTime())) / 1000) / 60) / 60;// Segundos
		return (int) diferencia;
	}

	public StatusControlMatricesEnum dameEnumById(String id) {
		for (StatusControlMatricesEnum data : StatusControlMatricesEnum.values()) {
			if (data.id().equals(id)) {
				return data;
			}
		}
		return null;
	}

	public List<String> dameArraylistOrdenado(Map<String, BeanMatrizVistaCabecera> mapaFiltrad) {
		if (mapaFiltrad == null || mapaFiltrad.size() == 0) {
			return null;
		}
		List<String> result = new ArrayList<>();
		for (Entry<String, BeanMatrizVistaCabecera> entry : mapaFiltrad.entrySet()) {
			result.add(entry.getValue().getSupplierNumber().trim());
		}
		Collections.sort(result);
		return result;
	}

	public List<String> dameNombresDeProveedores(List<String> listaOrdenada) {
		if (listaOrdenada == null || listaOrdenada.size() == 0) {
			return null;
		}
		List<String> result = new ArrayList<>();
		for (String tmp : listaOrdenada) {
			ImportacionesProveedoresBean bean = FuncionesComunesPLI.getProveedor(tmp);
			if (bean != null) {
				result.add(bean.getNombreProveedor());
			}
		}
		return result;
	}

}