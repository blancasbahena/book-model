package com.srm.pli.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import com.srm.pli.bo.BeanVistaDocumentos;
import com.srm.pli.bo.SarBO;
import com.srm.pli.bo.SearchParamsDocs;
import com.srm.pli.db.ConexionDB;
import com.srm.pli.documents.ControlSdiBean;
import com.srm.pli.documents.LogDocumentosBean;
import com.srm.pli.enums.DocumentosAccionEnum;
import com.srm.pli.utils.FuncionesComunesPLI;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class ShpmntsWdocsDao {

	private static ShpmntsWdocsDao instance = null;

	private ShpmntsWdocsDao() {
	}

	public static ShpmntsWdocsDao getInstance() {
		if (instance == null)
			instance = new ShpmntsWdocsDao();
		return instance;
	}

	public List<BeanVistaDocumentos> getDocuments(SearchParamsDocs search, String vista) {
		List<BeanVistaDocumentos> r = null;
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();
			String query = getQueryDocuments(search, vista);
			try (PreparedStatement pst = con.prepareStatement(query)) {
				setPreparedStatement(pst, search);
				try (ResultSet rs = pst.executeQuery()) {
					r = new ArrayList<>();
					while (rs.next()) {
						BeanVistaDocumentos obj = new BeanVistaDocumentos();
						obj.setVersionSDI(rs.getInt("versionSDI"));
						obj.setProveedor(rs.getString("proveedor"));
						obj.setBooking(rs.getString("booking"));
						obj.setIdDocumentos(rs.getInt("idDocumentos"));
						obj.setFechaAceptaProveedor(rs.getTimestamp("fechaAceptaProveedor"));
						obj.setComentariosProveedor(rs.getString("comentarioProveedor"));
						obj.setAnalistaSDI(rs.getString("analista"));
						obj.setAprobadoSDI(rs.getBoolean("aprobado"));
						obj.setFechaAprobadoSDI(rs.getDate("fechaAprobadoSDI"));
						obj.setFechaAsignado(rs.getDate("fechaAsignadoAnalista"));
						obj.setFechaRechazo(rs.getDate("fechaRechazo"));
						obj.setPreBL(rs.getBoolean("preBLGenerado"));
						r.add(obj);
					}
				}
			}
		} catch (SQLException sqle) {
			log.error("Valores {}", search, sqle);
		} catch (Exception e) {
			log.error("Valores {}", search, e);
		} finally {
			ConexionDB.devolver(con);
		}
		return r;
	}

	private String getQueryDocuments(SearchParamsDocs search, String vista) {
		StringBuilder query = new StringBuilder();
		query.append("SELECT a.booking ");
		query.append("       , c.versionsdi ");
		query.append("       , c.iddocumentos ");
		query.append("       , a.proveedor ");
		query.append("       , c.comentarioproveedor ");
		query.append("       , c.analista ");
		query.append("       , c.aprobado ");
		query.append("       , c.fechaaprobadosdi ");
		query.append("       , c.fechaaceptaproveedor ");
		query.append("       , c.fechaasignadoanalista ");
		query.append("       , b.fechaRechazo ");
		query.append("       , g.preBLGenerado  ");
		query.append(" FROM   cdisar a ");
		query.append("       INNER JOIN cdidocumentossdi b ");
		query.append("               ON a.booking = b.booking ");
		query.append("                  AND a.versionsetdocumentos = b.versionsdi ");
		query.append("                  AND a.proveedor = b.proveedor ");
		query.append("       INNER JOIN cdicontrolsdi c ");
		query.append("               ON c.booking = b.booking ");
		query.append("                  AND c.versionsdi = b.versionsdi ");
		query.append("REJECTED".equals(vista) ? "- 1" : "");
		query.append("                  AND c.proveedor = b.proveedor ");
		query.append("       INNER JOIN cdisardetalle d ");
		query.append("               ON a.folio = d.folio ");
		query.append(" INNER JOIN cdiDocumentosSDI g ON g.proveedor =   a.proveedor AND g.booking = a.booking ");
		query.append(" AND g.versionSDI = a.versionSetDocumentos   ");
		query.append("       INNER JOIN cdi_facturas f ");
		query.append("               ON b.id = f.id ");
		query.append("                  AND d.condicionpago = f.condicionpago ");
		if (!"REJECTED".equals(vista)) {
			if ("NUEVOS".equals(vista)) {
				query.append(" AND c.aprobado IS NULL ");
			} else if ("AMENDED".equals(vista)) {
				query.append(" AND c.aprobado = 0  AND a.status=").append(SarBO.STATUS_INICIO_SDI).append(" ");
			} else {
				query.append(" AND c.aprobado = 1 ");
			}
		}
		Integer folio = search.getFolio();
		if(folio != null && folio.intValue() > 0) {
			query.append(" AND a.folio = ? ");
		}
		if (search.getProveedor() != null) {
			query.append(" AND a.proveedor = ? ");
		}
		if (search.getBl() != null) {
			query.append(" AND a.bl = ?");
		}
		if (search.getInvoice() != null) {
			query.append(" AND f.nombre = ?");
		}
		if (search.getEtaFrom() != null && search.getEtaTo() != null) {
			query.append(" AND a.eta BETWEEN ? AND ? ");
		}
		if (search.getPo() != null) {
			query.append(" AND d.po =?");
		}
		if (search.getPrioridad() != null && search.getPrioridad() > 0) {
			query.append(" AND a.prioridad =?");
		}
		if (search.getBooking() != null) {
			query.append(" AND c.booking =?");
		}
		if (search.getContenedor() != null) {
			query.append(" AND a.contenedor =?");
		}
		if (search.getNaviera() != null && search.getNaviera() > 0) {
			query.append(" AND a.naviera =?");
		}
		if (search.getAnalyst() != null && !"-1".equals(search.getAnalyst())) {
			query.append(" AND c.analista =?");
		}
		if (search.getApprovalFrom() != null && search.getApprovalTo() != null) {
			query.append(" AND c.fechaAprobadoSDI BETWEEN ? AND ? ");
		}
		query.append(" GROUP  BY a.booking ");
		query.append("          , c.versionsdi ");
		query.append("          , c.iddocumentos ");
		query.append("          , a.proveedor ");
		query.append("          , c.comentarioproveedor ");
		query.append("          , c.analista ");
		query.append("          , c.aprobado ");
		query.append("          , c.fechaaprobadosdi ");
		query.append("          , c.fechaaceptaproveedor ");
		query.append("          , c.fechaasignadoanalista ");
		query.append("          , b.fechaRechazo ,g.preBLGenerado ");
		query.append(" ORDER  BY c.fechaaceptaproveedor ASC");
		return query.toString();
	}

	private void setPreparedStatement(PreparedStatement pst, SearchParamsDocs search) throws SQLException {
		int cont = 1;
		
		Integer folio = search.getFolio();
		if(folio != null && folio.intValue() > 0) {
			pst.setInt(cont++, folio);
		}
		if (search.getProveedor() != null) {
			pst.setString(cont++, search.getProveedor());
		}
		if (search.getBl() != null) {
			pst.setString(cont++, search.getBl());
		}
		if (search.getInvoice() != null) {
			pst.setString(cont++, search.getInvoice());
		}
		if (search.getEtaFrom() != null && search.getEtaTo() != null) {
			pst.setInt(cont++, FuncionesComunesPLI.transformaFormatoFecha(search.getEtaFrom()));
			pst.setInt(cont++, FuncionesComunesPLI.transformaFormatoFecha(search.getEtaTo()));
		}
		if (search.getPo() != null) {
			pst.setString(cont++, search.getPo());
		}
		if (search.getPrioridad() != null && search.getPrioridad() > 0) {
			pst.setInt(cont++, search.getPrioridad());
		}
		if (search.getBooking() != null) {
			pst.setString(cont++, search.getBooking());
		}
		if (search.getContenedor() != null) {
			pst.setString(cont++, search.getContenedor());
		}
		if (search.getNaviera() != null && search.getNaviera() > 0) {
			pst.setInt(cont++, search.getNaviera());
		}
		if (search.getAnalyst() != null && !"-1".equals(search.getAnalyst())) {
			pst.setString(cont++, search.getAnalyst());
		}
		if (search.getApprovalFrom() != null && search.getApprovalTo() != null) {
			GregorianCalendar gFrom = FuncionesComunesPLI
					.int2GregorianCalendar(FuncionesComunesPLI.transformaFormatoFecha(search.getApprovalFrom()));
			GregorianCalendar gTo = FuncionesComunesPLI
					.int2GregorianCalendar(FuncionesComunesPLI.transformaFormatoFecha(search.getApprovalTo()));
			java.sql.Date dTo = new java.sql.Date(gFrom.getTimeInMillis());
			java.sql.Date dFrom = new java.sql.Date(gTo.getTimeInMillis());
			pst.setDate(cont++, dTo);
			pst.setDate(cont++, dFrom);
		}
	}

	public void insertLogDocumentos(LogDocumentosBean logBean) {
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();
			StringBuilder query = new StringBuilder();
			query.append("INSERT INTO cdiLogDocumentos (booking, proveedor, accion, fechaProveedor) ");
			query.append(" VALUES (?, ?, ?, ?)");
			try (PreparedStatement pst = con.prepareStatement(query.toString())) {
				pst.setString(1, logBean.getBooking());
				pst.setString(2, logBean.getProveedor());
				pst.setString(3, logBean.getAccion().name());
				pst.setTimestamp(4, new Timestamp(logBean.getFechaProveedor().getTime()));
				pst.executeUpdate();
			}
		} catch (SQLException sqle) {
			log.error("Valores {}", logBean, sqle);
		} catch (Exception e) {
			log.error("Valores {}", logBean, e);
		} finally {
			ConexionDB.devolver(con);
		}
	}

	public ControlSdiBean selectSdiControlSdi(String booking, String proveedor) {
		ControlSdiBean respuesta = null;
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();
			StringBuilder query = new StringBuilder();
			query.append("SELECT versionSdi, proveedor, idDocumentos, fechaAceptaProveedor, comentarioProveedor");
			query.append(", analista, aprobado, fechaAprobadoSdi, fechaAsignadoAnalista, tipoBl");
			query.append(" FROM cdiControlSdi ");
			query.append(" WHERE booking = ? AND proveedor = ?");
			try (PreparedStatement pst = con.prepareStatement(query.toString())) {
				pst.setString(1, booking);
				pst.setString(2, proveedor);
				try (ResultSet rs = pst.executeQuery()) {
					if (rs.next()) {
						Integer versionSdi = getInteger(rs, "versionSdi");
						Integer idDocumentos = getInteger(rs, "idDocumentos");
						Date fechaAceptaProveedor = rs.getTimestamp("fechaAceptaProveedor");
						String comentarioProveedor = rs.getString("comentarioProveedor");
						String analista = rs.getString("analista");
						Boolean aprobado = getBoolean(rs, "aprobado");
						Date fechaAprobadoSdi = rs.getTimestamp("fechaAprobadoSdi");
						Date fechaAsignadoAnalista = rs.getTimestamp("fechaAsignadoAnalista");
						String tipoBl = rs.getString("tipoBl");
						respuesta = new ControlSdiBean(versionSdi, proveedor, booking, idDocumentos,
								fechaAceptaProveedor, comentarioProveedor, analista, aprobado, fechaAprobadoSdi,
								fechaAsignadoAnalista, tipoBl);
					}
				}
			}
		} catch (SQLException sqle) {
			log.error("Valores {}", booking, sqle);
		} catch (Exception e) {
			log.error("Valores {}", booking, e);
		} finally {
			ConexionDB.devolver(con);
		}
		return respuesta;
	}

	public List<LogDocumentosBean> selectIndicadoresMensualesDeDocumentos() {
		List<LogDocumentosBean> respuesta = null;
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();
			StringBuilder query = new StringBuilder();
			Calendar hoy = GregorianCalendar.getInstance();
			int dia = hoy.get(Calendar.DAY_OF_MONTH);
			query.append("SELECT id, booking, proveedor, accion, fechaProveedor, createDate");
			query.append(" FROM cdiLogDocumentos ");
			query.append(" WHERE createDate BETWEEN ");
			// Obtiene primer dia y hora del mes anterior
			query.append(" DATEADD (month, DATEDIFF(month, 0 , GETDATE()-").append(dia).append(") , 0)");
			// Obtiene ultimo dia y hora del mes anterior
			query.append("	AND DATEADD(second, - 1 , DATEADD(month, DATEDIFF(month, 0, GETDATE()), 0))");
			try (Statement st = con.createStatement()) {
				try (ResultSet rs = st.executeQuery(query.toString())) {
					respuesta = new ArrayList<>();
					while (rs.next()) {
						Long id = getLong(rs, "id");
						String booking = rs.getString("booking");
						String proveedor = rs.getString("proveedor");
						String _accion = rs.getString("accion");
						DocumentosAccionEnum accion = DocumentosAccionEnum.valueOf(_accion);
						Date fechaProveedor = rs.getTimestamp("fechaProveedor");
						Date createDate = rs.getTimestamp("createDate");
						LogDocumentosBean bean = new LogDocumentosBean(id, booking, proveedor, accion, fechaProveedor,
								createDate);
						respuesta.add(bean);
					}
				}
			}
		} catch (SQLException sqle) {
			log.error(sqle.getMessage(), sqle);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		} finally {
			ConexionDB.devolver(con);
		}
		return respuesta;
	}

	private Integer getInteger(ResultSet rs, String campo) throws SQLException {
		int valor = rs.getInt(campo);
		Integer value = rs.wasNull() ? null : valor;
		return value;
	}

	private Boolean getBoolean(ResultSet rs, String campo) throws SQLException {
		boolean valor = rs.getBoolean(campo);
		Boolean value = rs.wasNull() ? null : valor;
		return value;
	}

	private Long getLong(ResultSet rs, String campo) throws SQLException {
		long valor = rs.getLong(campo);
		Long value = rs.wasNull() ? null : valor;
		return value;
	}
}