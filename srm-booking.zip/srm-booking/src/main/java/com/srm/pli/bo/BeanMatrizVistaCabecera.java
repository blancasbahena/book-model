package com.srm.pli.bo;


import java.util.Date;

public class BeanMatrizVistaCabecera{
	private Date fechaInsert;
	private boolean isBacklog;
	private boolean isRejected;
	private Date fechaBacklog;
	private Date fechaModificacion;
	private String  comentario;
	private String status;
	private String supplierName;
	private String supplierNumber;
	private String bu;
 	private int daysLeftETD;
	private int daysFromLogDate;
	private int hoursFromInsert;
	private int hoursFromBacklog;
	private String  po;
	private Date etd;
	private String statusDescripcion;
	private int xDias;
	
	public Date getFechaInsert() {
		return fechaInsert;
	}
	public void setFechaInsert(Date fechaInsert) {
		this.fechaInsert = fechaInsert;
	}
	public boolean isBacklog() {
		return isBacklog;
	}
	public void setBacklog(boolean isBacklog) {
		this.isBacklog = isBacklog;
	}
	public Date getFechaBacklog() {
		return fechaBacklog;
	}
	public void setFechaBacklog(Date fechaBacklog) {
		this.fechaBacklog = fechaBacklog;
	}
	public Date getFechaModificacion() {
		return fechaModificacion;
	}
	public void setFechaModificacion(Date fechaModificacion) {
		this.fechaModificacion = fechaModificacion;
	}
	public String getComentario() {
		return comentario;
	}
	public void setComentario(String comentario) {
		this.comentario = comentario;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getBu() {
		return bu;
	}
	public void setBu(String bu) {
		this.bu = bu;
	}
	public int getDaysLeftETD() {
		return daysLeftETD;
	}
	public void setDaysLeftETD(int daysLeftETD) {
		this.daysLeftETD = daysLeftETD;
	}
	public int getDaysFromLogDate() {
		return daysFromLogDate;
	}
	public void setDaysFromLogDate(int daysFromLogDate) {
		this.daysFromLogDate = daysFromLogDate;
	}
	public String getPo() {
		return po;
	}
	public void setPo(String po) {
		this.po = po;
	}
	public String getSupplierName() {
		return supplierName;
	}
	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}
	public String getSupplierNumber() {
		return supplierNumber;
	}
	public void setSupplierNumber(String supplierNumber) {
		this.supplierNumber = supplierNumber;
	}
	public Date getEtd() {
		return etd;
	}
	public void setEtd(Date etd) {
		this.etd = etd;
	}
	public String getStatusDescripcion() {
		return statusDescripcion;
	}
	public void setStatusDescripcion(String statusDescripcion) {
		this.statusDescripcion = statusDescripcion;
	}
	public boolean isRejected() {
		return isRejected;
	}
	public void setRejected(boolean isRejected) {
		this.isRejected = isRejected;
	}
	public int getHoursFromInsert() {
		return hoursFromInsert;
	}
	public void setHoursFromInsert(int hoursFromInsert) {
		this.hoursFromInsert = hoursFromInsert;
	}
	public int getHoursFromBacklog() {
		return hoursFromBacklog;
	}
	public void setHoursFromBacklog(int hoursFromBacklog) {
		this.hoursFromBacklog = hoursFromBacklog;
	}
	public int getxDias() {
		return xDias;
	}
	public void setxDias(int xDias) {
		this.xDias = xDias;
	}
	
}
