package com.srm.pli.bo;

import java.io.Serializable;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ConsultaDatosCdiSARBean implements Serializable
{
	private static final long serialVersionUID = 1L;
	private String numeroOrden;
	private String posicion;
	private String numProveedor;
	private String nombreProveedor;
	private String puertoOrigen;
	private String puertoDestino;
	private String nombreCliente;
	private String numCliente;
	private String pedidoCliente;
	private String poParcel;
	private String refacciones;
	private Integer etdPI;
	private Integer folioSAR;
	private Integer etdSAR;
	private String numBooking;	
	private Integer edtBooking;	
	private String contenedor;
	private Integer naviera;
	private Integer etaEstimadaNaviera;
	private String instruccionInicialBL;
	private String invNumFabrica;
	private String facturaFinal;
	private String facturaCliente;
	private String material;
	private String nombreNaviera;
	private String nombrePuertoDestino;
}
