package com.srm.pli.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLTimeoutException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import com.srm.pli.bo.ReporteRequestForChanges;
import com.srm.pli.constants.ConsultasConstants;
import com.srm.pli.bo.ConsultaReporteKpis;
import com.srm.pli.db.ConexionDB;
import com.srm.pli.helper.PuertosHelper;
import com.srm.pli.utils.FuncionesComunesPLI;
import com.srm.pli.utils.UtilsSQL;

public class CdiSarRMDao
{
	private static final CdiSarRMDao INSTANCE = new CdiSarRMDao();
	private static final Logger LOGGER = LogManager.getRootLogger();
	
	private CdiSarRMDao()
	{		
	}
	
	public static CdiSarRMDao getInstance()
	{
		return INSTANCE;
	}
	
	public List<ReporteRequestForChanges> getReporte(String fechaInicio, String fechaFin)
	{
		List<ReporteRequestForChanges> listReporte = new ArrayList<>();
		Connection con = null;
		
		try
		{
			con = ConexionDB.dameConexion();			
			
			try(PreparedStatement preparedStatement = con.prepareStatement(ConsultasConstants.GET_CONSULTA_DB_TO_KPIS)) 
			{				
				preparedStatement.setDate(1, java.sql.Date.valueOf(fechaInicio));
				preparedStatement.setDate(2, java.sql.Date.valueOf(fechaFin));
				
				try (ResultSet rs = preparedStatement.executeQuery()) 
				{
					while(rs.next()) 
					{
						ReporteRequestForChanges bean = new ReporteRequestForChanges();
						bean.setNumeroDeCambiosByETD(rs.getInt("numero de cambios de ETD"));
						bean.setSar(rs.getString("folio"));					
						bean.setBooking(rs.getString("booking"));
						bean.setLastETARegistered(rs.getString("Last ETA"));
						bean.setCurrentETARegistered(rs.getInt("Current ETA"));
						
						bean.setLastETD(rs.getString("Last ETD"));
						bean.setEtdSolicitada(rs.getString("ETD solicitada"));
						bean.setCurrentETDRegistered(rs.getInt("Current ETD"));
						
						bean.setVessel(rs.getString("vessel"));
						bean.setVoyage(rs.getString("voyage"));
						bean.setCarrier(rs.getString("carrier"));
						bean.setNombreNavieraByClave(rs.getString("nombreNaviera"));
						bean.setSupplier(rs.getString("proveedor"));
						String proveedorId = rs.getString("proveedor");
						bean.setNombreProveedor(rs.getString("proveedor") != null ? FuncionesComunesPLI.getNombreProveedor(proveedorId) : "");
						bean.setCurrentETARegistered(rs.getInt("current ETA"));
						bean.setBl(rs.getString("bl"));
						bean.setTipoContenedor(rs.getInt("tipoContenedor"));
						bean.setNombreContenedorByClave(rs.getString("nombreContenedor"));
						bean.setContenedor(rs.getString("contenedor"));						
						bean.setPol(rs.getString("pol"));
						bean.setPod(rs.getString("pod"));
						bean.setReason(rs.getString("reason"));	
						bean.setEstatusRM(rs.getString("estatus_RM"));	
						bean.setCreateDate(rs.getDate("create_date"));
						bean.setFechaSolicitado(rs.getDate("create_date_solicitado"));
						listReporte.add(bean);
					}
				}
			}
		} 
		catch (SQLException sqle) 
		{
			LOGGER.error("Error: {} " + sqle.getMessage(), sqle);
		} 
		catch (Exception e) 
		{
			LOGGER.error("Error: {} ", e.getMessage(), e);
		} 
		finally 
		{
			ConexionDB.devolver(con);
		}
		return listReporte;
	}
	
	public List<ConsultaReporteKpis> getCambiosXNavieraProveedor(String fechaInicio, String fechaFin)
	{
		List<ConsultaReporteKpis> consultaReporteKpis = new ArrayList<>();
		Connection con = null;
		
		try
		{
			con = ConexionDB.dameConexion();
			
			try(PreparedStatement preparedStatement = con.prepareStatement(ConsultasConstants.GET_CONSULTA_CAMBIOS_X_NAVIERA_PROVEEDOR)) 
			{				
				preparedStatement.setDate(1, java.sql.Date.valueOf(fechaInicio));
				preparedStatement.setDate(2, java.sql.Date.valueOf(fechaFin));
				
				try (ResultSet rs = preparedStatement.executeQuery()) 
				{
					while(rs.next()) 
					{
						ConsultaReporteKpis bean = new ConsultaReporteKpis();
						bean.setReason(rs.getString("reason"));	
						bean.setCantidad(rs.getInt("cantidad"));
						consultaReporteKpis.add(bean);
					}
				}
			}
		}
		catch(SQLTimeoutException sqle)
		{
			LOGGER.error("Error SQLTimeout: {} ", sqle.getMessage(), sqle);
		}
		catch (SQLException sqle) 
		{
			LOGGER.error("Error SQLException: {} ", sqle.getMessage(), sqle);
		} 
		catch (Exception e) 
		{
			LOGGER.error("Error Exception: {} ", e.getMessage(), e);
		}
		finally 
		{
			ConexionDB.devolver(con);
		}
		return consultaReporteKpis;
	}
	
	public List<ConsultaReporteKpis> getVolByContenedorXNavieraXSemana(String fechaInicio, String fechaFin, boolean puertos,  Set<String> listPuertos)
	{
		List<ConsultaReporteKpis> consultaReporteKpis = new ArrayList<>();
		Connection con = null;
		
		try
		{
			con = ConexionDB.dameConexion();
			StringBuilder stringBuilder = new StringBuilder();	
			stringBuilder.append("SELECT ");
			stringBuilder.append("s.folio, ");
			stringBuilder.append("s.contenedor, ");
			stringBuilder.append("cont.nombre as nombreContenedor, ");
			stringBuilder.append("s.naviera, ");
			stringBuilder.append("s.puertoSalida, ");
			stringBuilder.append("nav.nombre AS 'nombreNaviera', ");
			stringBuilder.append("s.etdFinal, ");
			stringBuilder.append(SarDao.CONDICION_ETD_ETDFINAL).append(" AS 'Current ETD' ");
			stringBuilder.append("FROM cdiSAR AS s ");
			stringBuilder.append("LEFT JOIN cdiNavieras nav ON nav.clave = s.naviera ");
			stringBuilder.append("LEFT JOIN cdiContenedores cont ON s.tipoContenedor = cont.clave ");
			stringBuilder.append("WHERE folio IS NOT NULL AND contenedor IS NOT NULL AND naviera IS NOt NULL AND len(Ltrim(contenedor)) <> 0 AND (Ltrim(contenedor)) <> '-' ");
			stringBuilder.append("AND ").append(SarDao.CONDICION_ETD_ETDFINAL).append(" BETWEEN ? AND ? ");
			if(puertos && listPuertos != null)
				stringBuilder.append("AND s.puertoSalida IN ").append(UtilsSQL.convierteToIN(listPuertos));
			stringBuilder.append(" ORDER BY 'Current ETD' DESC ");
				
			try(PreparedStatement preparedStatement = con.prepareStatement(stringBuilder.toString())) 
			{				
				String fechaInicioTmp = fechaInicio.replaceAll("-", "");
				String fechaFinTmp = fechaFin.replaceAll("-", "");
				preparedStatement.setInt(1, Integer.parseInt(fechaInicioTmp));
				preparedStatement.setInt(2, Integer.parseInt(fechaFinTmp));
				
				try (ResultSet rs = preparedStatement.executeQuery()) 
				{
					while(rs.next()) 
					{
						ConsultaReporteKpis bean = new ConsultaReporteKpis();
						bean.setFolio(rs.getString("folio"));	
						bean.setContenedor(rs.getString("contenedor"));
						bean.setNombreContenedor(rs.getString("nombreContenedor"));
						bean.setPuertoSalida(rs.getString("puertoSalida"));
						bean.setNombreNaviera(rs.getString("nombreNaviera"));
						bean.setCurrentETD(rs.getInt("Current ETD"));

						String nombrePuerto = PuertosHelper.getInstance().getNombrePuertoOrigen(rs.getString("puertoSalida"));
						bean.setNombrePuertoOrigen(nombrePuerto);
						consultaReporteKpis.add(bean);
					}
				}
			}
		}
		catch(SQLTimeoutException sqle)
		{
			LOGGER.error("Error SQLTimeout: {} ", sqle.getMessage(), sqle);
		}
		catch (SQLException sqle) 
		{
			LOGGER.error("Error SQLException: {} ", sqle.getMessage(), sqle);
		} 		
		catch (Exception e) 
		{
			LOGGER.error("Error Exception: {} ", e.getMessage(), e);
		} 
		finally 
		{
			ConexionDB.devolver(con);
		}
		return consultaReporteKpis;
	}
	
	public List<ConsultaReporteKpis> getCambiosByTopDePuertosXSemana(String fechaInicio, String fechaFin, Set<String> listPuertos)
	{
		List<ConsultaReporteKpis> consultaReporteKpis = new ArrayList<>();
		Connection con = null;
		
		try
		{
			con = ConexionDB.dameConexion();
			StringBuilder stringBuilder = new StringBuilder();	
			stringBuilder.append("SELECT ");
			stringBuilder.append("hLog.folio, ");
			stringBuilder.append("hLog.reason, ");
			stringBuilder.append("hLog.pol, ");
			stringBuilder.append("s.puertoSalida, ");
			stringBuilder.append("hLog.estatus_RM, ");
			stringBuilder.append("hLog.create_date, ");
			stringBuilder.append("(CASE WHEN s.etdFinal IS NULL OR s.etdFinal < 20000101 THEN s.fechaEmbarque ELSE s.etdFinal END) AS 'Current ETD' ");
			stringBuilder.append("FROM cdiSarRMLog hLog ");
			stringBuilder.append("INNER JOIN cdiSAR s ON hLog.folio = s.folio ");
			stringBuilder.append("WHERE hLog.pol IS NOT NULL and hLog.pol <> '-1' AND LEN(LTRIM(hLog.pol)) <> 0 AND (CASE WHEN s.etdFinal IS NULL OR s.etdFinal < 20000101 THEN s.fechaEmbarque ELSE s.etdFinal END) BETWEEN ? AND ? AND hLog.estatus_RM = 'aprobado_rm' ");
			stringBuilder.append("AND hLog.pol IN ").append(UtilsSQL.convierteToIN(listPuertos));
			stringBuilder.append("ORDER BY 'Current ETD' DESC");
				
			try(PreparedStatement preparedStatement = con.prepareStatement(stringBuilder.toString())) 
			{				
				String fechaInicioTmp = fechaInicio.replaceAll("-", "");
				String fechaFinTmp = fechaFin.replaceAll("-", "");
				preparedStatement.setInt(1, Integer.parseInt(fechaInicioTmp));
				preparedStatement.setInt(2, Integer.parseInt(fechaFinTmp));
				
				try (ResultSet rs = preparedStatement.executeQuery()) 
				{
					while(rs.next()) 
					{
						ConsultaReporteKpis bean = new ConsultaReporteKpis();
						bean.setFolio(rs.getString("folio"));					
						bean.setReason(rs.getString("reason"));	
						bean.setPol(rs.getString("pol"));						
						bean.setEstatusRM(rs.getString("estatus_RM"));
						bean.setCreateDate(rs.getDate("create_date"));
						bean.setCurrentETD(rs.getInt("Current ETD"));
						String nombrePuerto = PuertosHelper.getInstance().getNombrePuertoOrigen(rs.getString("puertoSalida"));
						bean.setNombrePuertoOrigen(nombrePuerto);
						consultaReporteKpis.add(bean);
					}
				}
			}
		}
		catch(SQLTimeoutException sqle)
		{
			LOGGER.error("Error SQLTimeout: {} ", sqle.getMessage(), sqle);
		}
		catch (SQLException sqle) 
		{
			LOGGER.error("Error SQLException: {} ", sqle.getMessage(), sqle);
		} 		
		catch (Exception e) 
		{
			LOGGER.error("Error Exception: {} ", e.getMessage(), e);
		} 
		finally 
		{
			ConexionDB.devolver(con);
		}
		return consultaReporteKpis;
	}
	
	public List<ConsultaReporteKpis> getInformacion(String fechaInicio, String fechaFin, Set<String> listReasons)
	{
		List<ConsultaReporteKpis> consultaReporteKpis = new ArrayList<>();
		Connection con = null;
		
		try
		{
			con = ConexionDB.dameConexion();
			StringBuilder query = new StringBuilder();	
			query.append("SELECT ");
			query.append("folio, ");
			query.append("carrier, ");
			query.append("tipoContenedor, ");
			query.append("reason, ");
			query.append("pod, ");
			query.append("eta, ");
			query.append("estatus_RM, ");
			query.append("create_date ");
			query.append("FROM cdiSarRMLog hLog ");
			query.append("WHERE hLog.create_date BETWEEN ? AND ? AND hLog.estatus_RM='aprobado_rm' ");
			query.append("AND reason IN ").append(UtilsSQL.convierteToIN(listReasons));
			query.append(" ORDER BY hLog.create_date DESC");
			
			try(PreparedStatement preparedStatement = con.prepareStatement(query.toString())) 
			{				
				preparedStatement.setDate(1, java.sql.Date.valueOf(fechaInicio));
				preparedStatement.setDate(2, java.sql.Date.valueOf(fechaFin));
				
				try (ResultSet rs = preparedStatement.executeQuery()) 
				{
					while(rs.next()) 
					{
						ConsultaReporteKpis bean = new ConsultaReporteKpis();
						bean.setFolio(rs.getString("folio"));					
						bean.setCarrier(rs.getString("carrier"));
						bean.setTipoContenedor(rs.getInt("tipoContenedor"));
						bean.setReason(rs.getString("reason"));	
						bean.setEta(rs.getString("eta"));
						bean.setPod(rs.getString("pod"));						
						bean.setEstatusRM(rs.getString("estatus_RM"));
						bean.setCreateDate(rs.getDate("create_date"));
						consultaReporteKpis.add(bean);
					}
				}
			}
		} 
		catch(SQLTimeoutException sqle)
		{
			LOGGER.error("Error SQLTimeout: {} ", sqle.getMessage(), sqle);		
		}
		catch (SQLException sqle) 
		{
			LOGGER.error("Error SQLException: {} ", sqle.getMessage(), sqle);
		} 		
		catch (Exception e) 
		{
			LOGGER.error("Error Exception: {} ", e.getMessage(), e);
		} 
		finally 
		{
			ConexionDB.devolver(con);
		}
		return consultaReporteKpis;
	}
}
