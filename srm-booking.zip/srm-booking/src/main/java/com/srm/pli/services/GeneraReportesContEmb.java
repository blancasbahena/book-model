package com.srm.pli.services;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import com.srm.pli.bo.BeanControlEmb;

public interface GeneraReportesContEmb {

	void enviaReportePendientes() throws SQLException, IOException;
	
	File generarReporteExcel(List<BeanControlEmb> lstPendientes, String etdEta) throws IOException;
	
}
