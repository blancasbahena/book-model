package com.srm.pli.helper;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

import com.truper.businessEntity.BeanDetalleOrdenMaterial;
import com.truper.businessEntity.BeanDocumentoAnalisis;
import com.truper.businessEntity.PricePosition;
import com.truper.businessEntity.UpdatePricesBean;

public final class SarDetailHelper {

	/**
	 * Don't let anyone instantiate this class.
	 */
	private SarDetailHelper() {
	}

	public static List<PricePosition> getPositionsWithNewPrices(List<PricePosition> origin,
			List<PricePosition> resource) {
		if (origin == null || resource == null)
			return null;
		if (origin.isEmpty() || resource.isEmpty())
			return resource;

		List<PricePosition> result = new ArrayList<>();
		for (PricePosition pricePosition : origin) {
			int index = resource.indexOf(pricePosition);
			if (index == -1) {
				continue;
			}
			PricePosition src = resource.get(index);
			BigDecimal sourceUnitPrice = src.getUnitPrice();
			if (sourceUnitPrice == null) {
				continue;
			}
			BigDecimal originUnitPrice = pricePosition.getUnitPrice();
			if (originUnitPrice == null || originUnitPrice.compareTo(sourceUnitPrice) != 0) {
				result.add(src);
			}
		}
		return result;
	}

	private static boolean esObjIgual(UpdatePricesBean obj1 ,UpdatePricesBean obj2 ) {
		if(obj1.getMaterial().compareTo(obj2.getMaterial()) == 0  && 
				obj1.getPo().equals(obj2.getPo()) &&
				obj1.getPosition().compareTo(obj2.getPosition()) == 0) {
			return true;
		}else {
			return false;
		}
	}
	
	private static int dameIndex(UpdatePricesBean obj , List<UpdatePricesBean> resource) {
		for(int i = 0 ; i < resource.size() ;i++) {
			UpdatePricesBean bean = resource.get(i);
			if(esObjIgual(bean, obj)) {
				return i;
			}
		}
		return -1;
	}
	
	public static List<UpdatePricesBean> getPositionsWithNewPricesForUpdate(List<UpdatePricesBean> origin,
			List<UpdatePricesBean> resource) {
		if (origin == null || resource == null)
			return null;
		if (origin.isEmpty() || resource.isEmpty())
			return resource;

		List<UpdatePricesBean> result = new ArrayList<>();
		for (UpdatePricesBean pricePosition : origin) {
			int index = dameIndex(pricePosition, resource);
			if (index == -1) {
				continue;
			}
			UpdatePricesBean src = resource.get(index);
			BigDecimal sourceUnitPrice = src.getUnitPrice();
			if (sourceUnitPrice == null) {
				continue;
			}
			BigDecimal originUnitPrice = pricePosition.getUnitPrice();
			if (originUnitPrice == null || originUnitPrice.compareTo(sourceUnitPrice) != 0) {
				src.setUnitPriceOld(originUnitPrice);
				result.add(src);
			}
		}
		return result;
	}
	
	public static List<PricePosition> parseToPricesPositions(
			Map<String, List<BeanDetalleOrdenMaterial>> positions) {
		if (positions == null)
			return null;

		List<PricePosition> resource = new ArrayList<>();
		if (positions.isEmpty())
			return resource;

		for (String po : positions.keySet()) {
			List<BeanDetalleOrdenMaterial> po_positions = positions.get(po);
			for (BeanDetalleOrdenMaterial detalle : po_positions) {
				PricePosition position = new PricePosition();
				position.setPo(po);
				position.setPosition(Integer.valueOf(detalle.getPosicion()));
				position.setMaterial(Integer.valueOf(detalle.getMaterial()));
				position.setUnitPrice(detalle.getPrecioUnitario());
				resource.add(position);
			}
		}
		return resource;
	}
	
	public static void completaUpdatePriceBean(Map<String, List<UpdatePricesBean>> mapaTablas,
			List<UpdatePricesBean> arregloACompletar) {
		if (mapaTablas == null || arregloACompletar == null) {
			return;
		}
		for (UpdatePricesBean bean : arregloACompletar) {
			if (mapaTablas.containsKey(bean.getPo())) {
				for (UpdatePricesBean upBean : mapaTablas.get(bean.getPo())) {
					if (upBean.getPosition().compareTo(bean.getPosition()) == 0) {
						bean.setFolio(upBean.getFolio());
						break;
					}
				}
			}
		}
		return;
	}
	
	public static List<UpdatePricesBean> parseToPricesUpdatePrices(
			Map<String, List<BeanDetalleOrdenMaterial>> positions) {
		if (positions == null)
			return null;

		List<UpdatePricesBean> resource = new ArrayList<>();
		if (positions.isEmpty())
			return resource;

		for (String po : positions.keySet()) {
			List<BeanDetalleOrdenMaterial> po_positions = positions.get(po);
			for (BeanDetalleOrdenMaterial detalle : po_positions) {
				UpdatePricesBean position = new UpdatePricesBean();
				position.setPo(po);
				position.setPosition(Integer.valueOf(detalle.getPosicion()));
				position.setMaterial(Integer.valueOf(detalle.getMaterial()));
				position.setUnitPrice(detalle.getPrecioUnitario());
				position.setCentro(detalle.getCentro());
				resource.add(position);
			}
		}
		return resource;
	}
	

	public static HashSet<Integer> getFolios(List<BeanDocumentoAnalisis> folios) {
		HashSet<Integer> folios_set = new HashSet<>();
		for (BeanDocumentoAnalisis bean : folios) {
			folios_set.add(bean.getFolio());
		}
		return folios_set;
	}
}
