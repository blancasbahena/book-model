package com.srm.pli.services;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.web.servlet.tags.HtmlEscapeTag;
import org.springframework.web.util.HtmlUtils;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.srm.pli.bo.BitacoraVistaBean;
import com.srm.pli.dao.BitacoraIDADAO;
import com.srm.pli.dao.RevisionIDASDAO;
import com.srm.pli.db.ConexionDB;
import com.srm.pli.helper.FormatSARHelper;
import com.truper.businessEntity.BitacoraIDABean;
import com.truper.businessEntity.SARRevisionIDABean;
import com.truper.utils.date.EnumFechas;

public class BitacoraIDAService {

	private static BitacoraIDAService instance = null;
	private static final Logger log = LogManager.getRootLogger();

	Gson g = new GsonBuilder().serializeSpecialFloatingPointValues().setDateFormat(EnumFechas.FORMATO_YYYY_MM_DD.to())
			.create();

	private BitacoraIDAService() {
	}

	public static BitacoraIDAService getInstance() {
		if (instance == null) {
			instance = new BitacoraIDAService();
		}
		return instance;
	}

	public List<BitacoraVistaBean> selectBitacorasOpen() {
		String folioCC = "CC";
		String folioLCL = "C";
		String folioFULL = "F";
		List<BitacoraVistaBean> lista = BitacoraIDADAO.getInstance().selectBitacoraOpen();
		if (lista == null || lista.size() == 0) {
			return null;
		}
		for (BitacoraVistaBean tmp : lista) {
			if (tmp.getFolio() == tmp.getFolioCC()) {
				tmp.setFolioVista(folioCC + tmp.getFolio());
			} else if (tmp.getFolioCC() == 1) {
				tmp.setFolioVista(folioLCL + tmp.getFolio());
			} else {
				tmp.setFolioVista(folioFULL + tmp.getFolio());
				tmp.setDirecto(FormatSARHelper.getInstance().tienePedioDirecto(tmp.getFolio()));
			}

		}
		return lista;
	}

	public void insertaBitacora(int folio, int folioCC, String mensaje, String usuario) throws Exception {
		Connection con = null;
		try {
			BitacoraIDABean bean = new BitacoraIDABean();
			bean.setComentario(mensaje);
			bean.setFolio(folio);
			bean.setFolioCC(folioCC);
			bean.setUserName(usuario);
			con = BitacoraIDADAO.getInstance().insertaRegistroBitacora(bean, con);
			con.commit();
			con.setAutoCommit(true);
			ConexionDB.devolver(con);
		} catch (Exception e) {
			log.error("[insertaBitacora] Error", e);
			con.rollback();
			con.setAutoCommit(true);
			ConexionDB.renovar(con);
			ConexionDB.devolver(con);
			throw new Exception(e);
		}
	}

	public int cierraBitacora(int folio, int foliocc, String usuario) throws SQLException {
		boolean esConsol = (folio == foliocc ? true : false);
		int result = 0;
		try {
			Connection con = BitacoraIDADAO.getInstance().updateRegistroBitacora(folio, foliocc, usuario);
			if (esConsol) {
				SARRevisionIDABean bean = new SARRevisionIDABean();
				bean.setFolio(folio);
				bean.setCc(foliocc);
				result = RevisionIDASDAO.getInstance().updateSAR_Revision_CCs_Close(bean, con);
			} else {
				result = RevisionIDASDAO.getInstance().updateSARFULL_close(folio, con);
			}
		} catch (Exception e) {
			log.error("[cierraBitacora]", e);
		}
		return result;
	}
}