package com.srm.pli.rest;


import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;

import javax.servlet.ServletException;
import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

import org.json.JSONArray;
import org.json.JSONObject;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.srm.pli.bo.BeanSDPDetalleView;
import com.srm.pli.bo.SarBO;
import com.srm.pli.dao.SAR_CDI_DAO;
import com.srm.pli.dao.SDP_DAO;
import com.srm.pli.servlet.SDP;
import com.srm.pli.utils.FuncionesComunesPLI;
import com.srm.pli.utils.UtilsSDP;
import com.truper.businessEntity.BeanSDP;
import com.truper.businessEntity.BeanSDPAcciones;
import com.truper.businessEntity.BeanSDPDetalle;
import com.truper.businessEntity.ProductoBean;
import com.truper.infra.loggers.BaseLogger;
import com.truper.infra.rs.BaseRS;

@Path("/SDPServices")
public class SDPRestServises extends BaseRS{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -3295258570394852215L;
	private static Gson gson = new GsonBuilder()
			.serializeSpecialFloatingPointValues().create();
	 

	@GET
	@Path("/POsSinSAR")
	@Produces(MediaType.APPLICATION_JSON)
	public Response damePOsSinSAR(@Context UriInfo ui) {
		Response r = null;
		MultivaluedMap<String, String> map = ui.getQueryParameters();
		String user = map.getFirst("user");
		String po = map.getFirst("po");
		String supplier = map.getFirst("supplier");
		String openClosed = map.getFirst("openClosed");
		String from = map.getFirst("from");
		String to = map.getFirst("to");
		
		
		
		
		//r = buildOK_JSONResponse(jsonResult);
		return r;
	}
	
	@POST
	@Path("/doStatusChange")
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED) 
	public Response updateSARsSinContenedor(@FormParam("folio") Integer folio,
			@FormParam("status") Integer status, @FormParam("diasFromETD") Integer dias,
			@FormParam("monto") String monto, @FormParam("etd") Integer etd,
			@FormParam("user") String user) throws ServletException {
		Response r = null;
		BeanSDP sdp = new BeanSDP();
		sdp.setFolio(folio);
		sdp.setStatus(status);
		sdp.setMontoTotal(Double.parseDouble(monto));
		sdp.setEtdNoFormato(etd);
		try {
			boolean updated = SDP_DAO.updateSDPCambiaStatus(sdp);
			if (updated) {
				JSONObject obj = new JSONObject();
				obj.put("errorCode", 0);
				obj.put("message", "OK");
				//r = buildOK_JSONResponse(obj.toString());
				r = buildOKResponse(obj.toString());
				if(SDP_DAO.STATUS_CONDONADOS == status) {
					FuncionesComunesPLI.guardaSARHistoryLog(34, folio, user, null, "F", "");
				}else if(SDP_DAO.STATUS_APLICADOS == status) {
					FuncionesComunesPLI.guardaSARHistoryLog(33, folio, user, null, "F", "");
				}else {
					FuncionesComunesPLI.guardaSARHistoryLog(35, folio, user, null, "F", "");
				}
			} else {
				r = buildErrorResponse("Error while trying to update the status of: " + folio);
			}
		}catch (Exception e) {
			
		}
		
		return r;
	}
	
	
	
	@GET
	@Path("/dameDetalle")
	@Produces(MediaType.APPLICATION_JSON)
	public Response dameDetalle(@Context UriInfo ui) {
		Response r = null;
		MultivaluedMap<String, String> map = ui.getQueryParameters();
		String folioStr = map.getFirst("folio");
		int folio = Integer.parseInt(folioStr);
		String etd = map.getFirst("etd");///Dias From ETD
		int etdInt = Integer.parseInt(etd);
		String diasTolerancia = map.getFirst("diasTolerancia");///Dias From ETD
		int diasToleranciaInt = Integer.parseInt(diasTolerancia);
		JSONObject jsonObject = new JSONObject();
		try {
			ArrayList<BeanSDPDetalle> detalle = SDP_DAO.selectSDPDetalle(folio);
			JSONArray jSars = new JSONArray();
			for(BeanSDPDetalle det : detalle) {
				BeanSDPDetalleView detView = new BeanSDPDetalleView(det);
				ProductoBean p =  FuncionesComunesPLI.productos.get(det.getCodigo());
				if(p != null) {
					detView.setDescripcion(p.getDescripcion());
					detView.setItem(p.getCodigo());
					detView.setCentro(p.getCentro());
				}
				
				if(det.getFechaProforma() == 0) {
					//throw new Exception("The PO: "+det.getPo()+" is closed please check this information and try againg.");
					jsonObject.put("errorCode", "1");
					jsonObject.put("message", "The PO: "+det.getPo()+" is closed please check this information and try againg.");
					r = buildOK_JSONResponse(jsonObject);
					BaseLogger.BOOKING_LOGGER.error("The PO: "+det.getPo()+" is closed please check this information and try againg.");
					return r;
				}
				GregorianCalendar greg = FuncionesComunesPLI.int2GregorianCalendar(det.getFechaProforma());
				greg.add(Calendar.DATE, diasToleranciaInt);
				int fprofMasTolerancia = FuncionesComunesPLI.gregorianCalendar2int(greg);
				
				int diasFromETD = 
						(int)FuncionesComunesPLI.daysBetween( fprofMasTolerancia,etdInt);
				diasFromETD = diasFromETD > SDP.DIAS_MAXIMOS ? SDP.DIAS_MAXIMOS : diasFromETD;
				double unidadXDiasXPrecio = 0;
				if(diasFromETD > 0) {
					unidadXDiasXPrecio = ((diasFromETD ) *  det.getMonto() ) / 100;
				}
				
				detView.setMontoDiario(FuncionesComunesPLI.formatea( unidadXDiasXPrecio,2 ));
				detView.setMontoMaximo(FuncionesComunesPLI.formatea(det.getMontoMax() ,2 ));
				detView.setCantidadView(FuncionesComunesPLI.formatea(det.getCantidad(),0));
				detView.setPrecioView(FuncionesComunesPLI.formatea(det.getPrecio(),2));
				jSars.put(gson.toJson(detView));
				
			}
			
			///Datos proveedor
			SarBO bo = new SarBO();
			bo.setFolio(folio);
			SAR_CDI_DAO dao = new SAR_CDI_DAO();
			ArrayList<SarBO> lista = dao.selectSar(bo,false);
			
			
			jsonObject.put("data", jSars);
			jsonObject.put("proveedor", FuncionesComunesPLI.getProveedor(lista.get(0).getProveedor()).getNombreProveedor());
			jsonObject.put("proveedorNum", lista.get(0).getProveedor());
			
			jsonObject.put("errorCode", "0");
			jsonObject.put("message", "OK");
			
			r = buildOK_JSONResponse(jsonObject);
			BaseLogger.BOOKING_LOGGER.info("[dameDetalle SDP] Se realiza bien la consulta del detalle");
			
		} catch (Exception e) {
			BaseLogger.BOOKING_LOGGER.error("[dameDetalle SDP]" , e);
			jsonObject.put("errorCode", "1");
			jsonObject.put("message", e.toString());
			r = buildErrorResponse();
		} 
		return r;
	}
	
	
}
