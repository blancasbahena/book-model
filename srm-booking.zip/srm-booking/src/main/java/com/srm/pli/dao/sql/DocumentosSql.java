package com.srm.pli.dao.sql;

public class DocumentosSql {

	public static final String SELECT_SET_DOCUMENTOS;

	static {
		StringBuilder sql = new StringBuilder();
		sql.append("DECLARE @versionFactura INT, ");
		sql.append("        @versionPK      INT, ");
		sql.append("        @versionBL      INT, ");
		sql.append("        @versionPreBL   INT, ");
		sql.append("        @id             INT ");
		sql.append(" DECLARE @proveedor VARCHAR(6) = ? ");
		sql.append(" DECLARE @booking VARCHAR(50) = ? ");
		sql.append(" DECLARE @versionSDI INT = (SELECT DISTINCT(versionSetDocumentos) FROM cdiSAR WHERE booking = @booking AND proveedor = @proveedor) ");
		sql.append(" SET @id = (SELECT id ");
		sql.append("           FROM   cdiDocumentosSDI ");
		sql.append("           WHERE  proveedor = @proveedor ");
		sql.append("                  AND booking = @booking ");
		sql.append("                  AND versionSDI = @versionSDI)");
		sql.append(" SET @versionFactura = (SELECT versionFacturas ");
		sql.append("                       FROM   cdiDocumentosSDI ");
		sql.append("                       WHERE  proveedor = @proveedor ");
		sql.append("                              AND booking = @booking ");
		sql.append("                              AND versionSDI = @versionSDI)");
		sql.append(" SET @versionPK = (SELECT versionPK ");
		sql.append("                  FROM   cdiDocumentosSDI ");
		sql.append("                  WHERE  proveedor = @proveedor ");
		sql.append("                         AND booking = @booking ");
		sql.append("                         AND versionSDI = @versionSDI)");
		sql.append(" SET @versionBL = (SELECT versionBL ");
		sql.append("                  FROM   cdiDocumentosSDI ");
		sql.append("                  WHERE  proveedor = @proveedor ");
		sql.append("                         AND booking = @booking ");
		sql.append("                         AND versionSDI = @versionSDI)");
		sql.append(" SET @versionPreBL = (SELECT versionPreBL ");
		sql.append("                     FROM   cdiDocumentosSDI ");
		sql.append("                     WHERE  proveedor = @proveedor ");
		sql.append("                            AND booking = @booking ");
		sql.append("                            AND versionSDI = @versionSDI)");
		sql.append(" SELECT 'FACTURA' Tipo,rutaArchivo,nombre,condicionPago, tieneOtros , versionDocumento   , id ");
		sql.append(" FROM   cdi_facturas ");
		sql.append(" WHERE  id = @id ");
		sql.append("       AND versionDocumento = @versionFactura ");
		sql.append(" UNION ALL ");
		sql.append(" SELECT 'PKL' Tipo,rutaArchivo,NULL,NULL,NULL , versionDocumento   , id ");
		sql.append(" FROM   cdi_PackingList ");
		sql.append(" WHERE  id = @id ");
		sql.append("       AND versionDocumento = @versionPK ");
		sql.append(" UNION ALL ");
		sql.append(" SELECT 'BL' Tipo,rutaArchivo,NULL,NULL,NULL , versionDocumento   , id ");
		sql.append(" FROM   cdi_BL ");
		sql.append(" WHERE  id = @id ");
		sql.append("       AND versionDocumento = @versionBL ");
		sql.append("       AND tipo = 'BL' ");
		sql.append(" UNION ALL ");
		sql.append(" SELECT 'PBL' Tipo,rutaArchivo,NULL,NULL,NULL  , versionDocumento   , id ");
		sql.append(" FROM   cdi_BL ");
		sql.append(" WHERE  id = @id ");
		sql.append("       AND versionDocumento = @versionPreBL ");
		sql.append("       AND tipo = 'PBL' ");
		sql.append(" UNION ALL ");
		sql.append(" SELECT 'OTRO' Tipo,rutaArchivo,nombre,NULL,NULL, NULL , id ");
		sql.append(" FROM   cdi_otros_documentos ");
		sql.append(" WHERE  id = @id ");
		sql.append("       AND ( eliminado IS NULL ");
		sql.append("              OR eliminado = 0 )");
		SELECT_SET_DOCUMENTOS = sql.toString();
	}

}
