package com.srm.pli.helper;

import com.truper.businessEntity.SARDetalle;

public class FormatPoRedFlagDetalle extends FormatSARDetalle {
	
	public FormatPoRedFlagDetalle(SARDetalle det) {
		setFolio(det.getFolio());
		setPo(det.getPo());
		setPosicion(det.getPosicion());
		setMaterial(det.getMaterial());
		setPlaneador(det.getPlaneador());
		setCentro(det.getCentro());
		setCantidad(String.valueOf(det.getCantidad()));
		setPesoProveedor(String.valueOf(det.getPesoPO()));
		setVolumenProveedor(String.valueOf(det.getVolumenPO()));
		setFechaProforma(String.valueOf(det.getFechaProforma()));
	}
}
