package com.srm.pli.enums;

public enum EnumDirectosBusquedaPor {

	BOOKING, FOLIO

}
