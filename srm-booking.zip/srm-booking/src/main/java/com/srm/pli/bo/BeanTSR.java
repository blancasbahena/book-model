package com.srm.pli.bo;

import java.io.Serializable;
import java.util.Date;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BeanTSR  implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 4907612997680023675L;
	
	private Integer folio;
	private String proveedor;
	private String nombreProveedor;
	private String referenceNumber;
	private	Integer carrier;
	private String carrierContactName;
	private String issueDescription;
	private Integer fechaRegistro;
	private Date timeRegistro;
	private String shippingPort;
	private Integer ETD;
	private Integer carrier_shippingReleased;
	private Boolean pendiente;
	private Boolean rechazado;
	private String comentariosBooking;
	private Date timeSolucion;
	private String usuarioBooking;
	
}
