package com.srm.pli.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.srm.pli.db.ConexionDB;
import com.srm.pli.domain.BeanDirectos;
import com.srm.pli.enums.EnumDirectosBusquedaPor;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class DirectosDao {

	private static DirectosDao instance = null;

	private DirectosDao() {
	}

	public static DirectosDao getInstance() {
		if (instance == null)
			instance = new DirectosDao();
		return instance;
	}

	public Map<Integer, List<BeanDirectos>> selectDirectos(EnumDirectosBusquedaPor buscarPor, String value) {
		Map<Integer, List<BeanDirectos>> respuesta = null;
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();
			StringBuilder query = new StringBuilder();
			query.append(" SELECT DISTINCT sar.booking, sar.folio ");
			query.append(" 	, detalle.almacen, detalle.centro, detalle.esPedidoDirecto ");
			query.append(" FROM cdiSAR sar (NOLOCK) ");
			query.append("		INNER JOIN cdiSARDetalle detalle (NOLOCK) ");
			query.append("			ON sar.folio = detalle.folio ");
			switch (buscarPor) {
			case BOOKING:
				query.append(" WHERE sar.booking = ? ");
				break;
			case FOLIO:
				query.append(" WHERE sar.folio = ? ");
				break;
			default:
				throw new Exception("El tipo no est� definido en EnumDirectosBusquedaPor");
			}
			try (PreparedStatement pst = con.prepareStatement(query.toString())) {
				pst.setString(1, value);
				try (ResultSet rs = pst.executeQuery()) {
					respuesta = new HashMap<>();
					while (rs.next()) {
						String booking = rs.getString("booking");
						int folio = rs.getInt("folio");
						String almacen = rs.getString("almacen");
						almacen = almacen == null ? null : almacen.trim();
						String centro = rs.getString("centro");
						centro = centro == null ? null : centro.trim();
						boolean isPedidoDirecto = rs.getBoolean("esPedidoDirecto");

						BeanDirectos bean = new BeanDirectos(booking, folio, almacen, centro, isPedidoDirecto);
						List<BeanDirectos> directos;
						if (respuesta.containsKey(folio)) {
							directos = respuesta.get(folio);
						} else {
							directos = new ArrayList<>();
							respuesta.put(folio, directos);
						}
						directos.add(bean);
					}
				}
			}
		} catch (Exception e) {
			log.error("Values {}, {}", buscarPor, e);
		} finally {
			ConexionDB.devolver(con);
		}
		return respuesta;
	}
}
