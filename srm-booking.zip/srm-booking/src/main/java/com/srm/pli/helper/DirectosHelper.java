package com.srm.pli.helper;

import java.util.Set;

import com.srm.pli.domain.BeanDirectos;
import com.srm.pli.utils.PropertiesDb;
import com.truper.utils.string.UtilsString;

public class DirectosHelper {

	private static DirectosHelper instance = null;
	private static final String PROP_ALMACENES = "producto.directos.almacen";
	private static final String PROP_CENTROS = "producto.directos.centros";

	private DirectosHelper() {
	}

	public static DirectosHelper getInstance() {
		if (instance == null)
			instance = new DirectosHelper();
		return instance;
	}

	public Set<String> getAlmacenes() {
		Set<String> valor = PropertiesDb.getInstance().getStringSet(PROP_ALMACENES);
		return valor;
	}

	public Set<String> getCentros() {
		Set<String> valor = PropertiesDb.getInstance().getStringSet(PROP_CENTROS);
		return valor;
	}

	public boolean isDirecto(BeanDirectos bean) {
		if (bean == null)
			return false;
		if (bean.isPedidoDirecto())
			return true;
		String almacen = bean.getAlmacen();
		if (UtilsString.isStringValida(almacen)) {
			Set<String> almacenes = getAlmacenes();
			if (almacenes != null && !almacenes.isEmpty() && almacenes.contains(almacen)) {
				return true;
			}
		}
		String centro = bean.getCentro();
		if (UtilsString.isStringValida(centro)) {
			Set<String> centros = getCentros();
			if (centros != null && !centros.isEmpty() && centros.contains(centro)) {
				return true;
			}
		}
		return false;
	}
}