package com.srm.pli.documents;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class IndicadoresDocumentosBean {
	private Integer recibidos = 0;
	private Integer rechazados = 0;
	private Integer aprobados = 0;
	private Integer retroalimentadosEnTiempo = 0;
	private Integer retroalimentadosTardios = 0;
}