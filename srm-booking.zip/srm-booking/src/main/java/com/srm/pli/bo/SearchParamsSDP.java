package com.srm.pli.bo;

public class SearchParamsSDP {
	private Integer folio;
	private Integer status;
	private Integer fechaIngresoIni;
	private Integer fechaIngresoFin;
	private Integer folioConsolidado;
	private Integer proveedor;
	private String po;
	
	
	public Integer getFolio() {
		return folio;
	}
	public void setFolio(Integer folio) {
		this.folio = folio;
	}
	public Integer getStatus() {
		return status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
	public Integer getFechaIngresoIni() {
		return fechaIngresoIni;
	}
	public void setFechaIngresoIni(Integer fechaIngresoIni) {
		this.fechaIngresoIni = fechaIngresoIni;
	}
	public Integer getFechaIngresoFin() {
		return fechaIngresoFin;
	}
	public void setFechaIngresoFin(Integer fechaIngresoFin) {
		this.fechaIngresoFin = fechaIngresoFin;
	}
	public Integer getFolioConsolidado() {
		return folioConsolidado;
	}
	public void setFolioConsolidado(Integer folioConsolidado) {
		this.folioConsolidado = folioConsolidado;
	}
	public Integer getProveedor() {
		return proveedor;
	}
	public void setProveedor(Integer proveedor) {
		this.proveedor = proveedor;
	}
	public String getPo() {
		return po;
	}
	public void setPo(String po) {
		this.po = po;
	}
}
