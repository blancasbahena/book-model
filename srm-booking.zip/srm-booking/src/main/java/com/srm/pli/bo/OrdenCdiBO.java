package com.srm.pli.bo;

import java.math.BigDecimal;

import com.srm.pli.utils.FuncionesComunesPLI;
import com.truper.businessEntity.OrdenCDI;

import lombok.Getter;
import lombok.Setter;

public class OrdenCdiBO extends OrdenCDI{
	///Si es null, no tienen nada ,si es  false ya se efectuo el cambio, si es true tiene cambio pendiente
	private Boolean tieneCambioETD = null;
	private Boolean redFlagOn = null;
	private Integer  etdSugerido = null;
	private Integer  etdActual = null;
	
	
	
	private BigDecimal cantidadUnidadMedida;
	private BigDecimal factorCantidadUnidadMedida;
	@Getter
	@Setter
	private String fabrica;
	@Getter
	@Setter
	private String fabricaDescripcion;
	@Getter
	@Setter
	private String descripcionComplementoFactura;
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 6987646759490082970L;

	public OrdenCdiBO(String orden, String posicion, String material, BigDecimal cantidad, String centro, 
			String planeador, Integer contenedor,String cliente, Boolean tieneCambioETD, Boolean redFlagOn){
		super(orden, posicion, material, cantidad, centro, planeador, contenedor, cliente);
		setVolumen(FuncionesComunesPLI.calculaVolumenParaCantidad(cantidad.intValue(), material));
		setPeso(FuncionesComunesPLI.calculaPesoParaCantidad(cantidad.intValue(), material));
		setTieneCambioETD(tieneCambioETD);
		setRedFlagOn(redFlagOn);
	}

	public void setCantidad(BigDecimal cantidad) {
		super.setCantidad(cantidad);
		setVolumen(FuncionesComunesPLI.calculaVolumenParaCantidad(cantidad.intValue(), getMaterial()));
		setPeso(FuncionesComunesPLI.calculaPesoParaCantidad(cantidad.intValue(), getMaterial()));
	}

	public void setRemanente(double remanente) {
		super.setRemanente(remanente);		
		setVolumenRemanente(FuncionesComunesPLI.calculaVolumenParaCantidad((int)remanente, getMaterial()));
		setPesoRemanente(FuncionesComunesPLI.calculaPesoParaCantidad((int)remanente, getMaterial()));
	}

	public Boolean getTieneCambioETD() {
		return tieneCambioETD;
	}

	public void setTieneCambioETD(Boolean tieneCambioETD) {
		this.tieneCambioETD = tieneCambioETD;
	}

	public Integer getEtdSugerido() {
		return etdSugerido;
	}

	public void setEtdSugerido(Integer etdSugerido) {
		this.etdSugerido = etdSugerido;
	}

	public Integer getEtdActual() {
		return etdActual;
	}

	public void setEtdActual(Integer etdActual) {
		this.etdActual = etdActual;
	}

	/**
	 * @return the redFlagOn
	 */
	public Boolean getRedFlagOn() {
		return redFlagOn;
	}

	/**
	 * @param redFlagOn the redFlagOn to set
	 */
	public void setRedFlagOn(Boolean redFlagOn) {
		this.redFlagOn = redFlagOn;
	}

	public BigDecimal getCantidadUnidadMedida() {
		return cantidadUnidadMedida;
	}

	public void setCantidadUnidadMedida(BigDecimal cantidadUnidadMedida) {
		this.cantidadUnidadMedida = cantidadUnidadMedida;
	}

	public BigDecimal getFactorCantidadUnidadMedida() {
		return factorCantidadUnidadMedida;
	}

	public void setFactorCantidadUnidadMedida(BigDecimal factorCantidadUnidadMedida) {
		this.factorCantidadUnidadMedida = factorCantidadUnidadMedida;
	}
	
	
	
}
