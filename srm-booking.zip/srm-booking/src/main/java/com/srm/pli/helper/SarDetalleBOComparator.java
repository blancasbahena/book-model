package com.srm.pli.helper;

import java.util.Comparator;

import com.srm.pli.bo.SarDetalleBO;

public class SarDetalleBOComparator implements Comparator<SarDetalleBO> {
	
	private boolean asc;
	
	public SarDetalleBOComparator (boolean asc) {
		this.asc = asc;
	}
	@Override
	public int compare(SarDetalleBO o1, SarDetalleBO o2) {
		
		return compareString(o1.getPo(), o2.getPo());
	}

	public int compareString(String s1, String s2){
    	return asc ? s1.compareTo(s2) : s2.compareTo(s1);
    }

}
