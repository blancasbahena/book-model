package com.srm.pli.services;

import java.io.File;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.ServletException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.srm.pli.bo.BeanFiltroMatriz;
import com.srm.pli.bo.BeanMatrizCabecera;
import com.srm.pli.bo.BeanMatrizDetalles;
import com.srm.pli.bo.SarBO;
import com.srm.pli.bo.jasperReports.BeanReporteControlPrecio;
import com.srm.pli.bo.jasperReports.BeanReporteControlPrecioSar;
import com.srm.pli.dao.MatricesDAO;
import com.srm.pli.helper.AuditoriaHelper;
import com.srm.pli.helper.CorreoHelper;
import com.srm.pli.process.GeneraReportesMatriz;
import com.srm.pli.utils.FuncionesComunesPLI;
import com.srm.pli.utils.MailUtils;
import com.srm.pli.utils.PropertiesDb;
import com.truper.businessEntity.BeanAuditoriaSinMatrizDetalle;
import com.truper.businessEntity.ProductoBean;
import com.truper.businessEntity.ProductoCentro;
import com.truper.utils.date.EnumFechas;
import com.truper.utils.date.UtilsFechas;

public class ControlPreciosEmailServices {

	private static final ControlPreciosEmailServices instance = new ControlPreciosEmailServices();
	private static final Logger log = LogManager.getRootLogger();
	private static final String POS_RELEASED_MATRIX_PENDING_RELEASE_AUDIT = "POS released by Matrix Area, pending to be released by Audit Area";
	private static final String POS_PIS_PENDING_REVIEW = "PO's - PI's pending price review by Purchases";

	private ControlPreciosEmailServices() {
	}

	public static ControlPreciosEmailServices getInstance() {
		return instance;
	}

	public void enviaReportesAutomaticosReporteSife() {
		log.info("INICIO de envio de correos automaticos Matriz/Auditoria");
		
		try {
			log.info("Envio de correo de Reportes Documento Procesados Exitosamente para SIFE");
			mailReportesDocumentoProcesadosExitosamente();
		} catch (Exception e) {
			e.printStackTrace();
			log.error("En mailReportesDocumentoProcesadosExitosamente metodo [mailReportesRevisionPreciosCompras]", e);
		}
		log.info("FIN de envio de correos automaticos Matriz/Auditoria");
	}
	
	public void enviaReportesAutomaticosMatrizAuditoria() {
		log.info("INICIO de envio de correos automaticos Matriz/Auditoria");
		
		try {
			mailMatrizPendientesXLiberar();
		} catch (Exception e) {
			log.error("En enviaReportesAutomaticosMatrizAuditoria metodo [mailMatrizPendientesXLiberar]", e);
		}
		try {
			mailMatrizLiberados();
		} catch (Exception e) {
			log.error("En enviaReportesAutomaticosMatrizAuditoria metodo [mailMatrizLiberados]", e);
		}
		try {
			mailMatrizRechazados();
		} catch (Exception e) {
			log.error("En enviaReportesAutomaticosMatrizAuditoria metodo [mailMatrizRechazados]", e);
		}
		try {
			mailReportesAuditoria();
		} catch (Exception e) {
			log.error("En enviaReportesAutomaticosMatrizAuditoria metodo [mailReportesAuditoria]", e);
		}
		try {
			mailReportesRevisionPreciosCompras();
		} catch (Exception e) {
			log.error("En enviaReportesAutomaticosMatrizAuditoria metodo [mailReportesRevisionPreciosCompras]", e);
		}
		log.info("FIN de envio de correos automaticos Matriz/Auditoria");
	}
	public boolean mailReportesDocumentoProcesadosExitosamente() throws Exception {
		log.info("INICIO mailReportesDocumentoProcesadosExitosamente");
		String nombreArchivoSife=PropertiesDb.getInstance().getString("srm.facturacion.sife.nombre");
		String numeroDiasRestadosSife=PropertiesDb.getInstance().getString("srm.facturacion.sife.dias");
		String emailsCC=PropertiesDb.getInstance().getString("srm.facturacion.sife.cc");
		String emailsBC=PropertiesDb.getInstance().getString("srm.facturacion.sife.bc");
		if(numeroDiasRestadosSife!=null) {
			try{
				Integer dato = Integer.parseInt(numeroDiasRestadosSife);
				numeroDiasRestadosSife = "- "+dato.toString();
			}catch(Exception ex) {log.error("Problemas con el numero de dias a Restar, ponga 0 en propiedad srm.facturacion.sife.dias");} ;
		}else {
			numeroDiasRestadosSife =" ";
		}
		File file;
		try {
			file = GeneraReportesMatriz.getInstance().generaReportesSife( GeneraReportesMatriz.EXITOSOS_SIFE,nombreArchivoSife,numeroDiasRestadosSife);
		} catch (Exception e) {
			log.error("Error [mailReportesDocumentoProcesadosExitosamente] al crear el archivo", e);
			throw new Exception(e);
		}
		// Voy por los destinatarios
		String[] mailsTo = emailsBC.split(";");
		String[] mailsCC = emailsCC.split(";");

		try {
			MailUtils.mandaMailMatrizAuditoria(GeneraReportesMatriz.EXITOSOS_SIFE, file, mailsTo, mailsCC);
			file = null;
		} catch (Exception e) {
			log.error("Error [mailReportesDocumentoProcesadosExitosamente] al enviar el correo", e);
			file = null;
			throw new Exception(e);
		}

		log.info("FIN mailReportesDocumentoProcesadosExitosamente");
		return true;
	} 
	public boolean mailMatrizPendientesXLiberar() throws Exception {
		log.info("INICIO mailMatrizPendientesXLiberar");

		File file;
		try {
			file = GeneraReportesMatriz.getInstance().generaReportesMatriz(GeneraReportesMatriz.VACIO,
					GeneraReportesMatriz.VACIO, GeneraReportesMatriz.EXITOSOS_SIFE,null,null);
		} catch (Exception e) {
			log.error("Error [mailMatrizPendientesXLiberar] al crear el archivo", e);
			throw new Exception(e);
		}
		// Voy por los destinatarios
		String[] mailsTo = dameMailsTo(dameHashMaterialesYCentros(GeneraReportesMatriz.VACIO,
				GeneraReportesMatriz.VACIO, GeneraReportesMatriz.PENDIENTES));
		String[] mailsCC = {CorreoHelper.EMAIL_GERENTE_INVENTARIOS};
		
		try {
			MailUtils.mandaMailMatrizAuditoria(GeneraReportesMatriz.PENDIENTES, file, mailsTo, mailsCC);
			file = null;
		} catch (Exception e) {
			log.error("Error [mailMatrizPendientesXLiberar] al enviar el correo", e);
			file = null;
			throw new Exception(e);
		}

		log.info("FIN mailMatrizPendientesXLiberar");
		return true;
	}

	public boolean mailReportesAuditoria() throws Exception {
		log.info("INICIO mailReportesAuditoria ");

		File file;
		ArrayList<BeanReporteControlPrecio> listaReportes = null;
		HashSet<BeanAuditoriaSinMatrizDetalle> detalles = null;
		HashSet<String> bus = null;
		try {
			listaReportes = AuditoriaService.getInstance().getPosConPbPendientesDeLiberarMatriz();

			detalles = AuditoriaService.getInstance().getDetalles(listaReportes);
			bus = AuditoriaHelper.getInstance().getBUs(detalles);
			file = GeneraReportesMatriz.getInstance().generaReportesAuditoria(listaReportes);
		} catch (Exception e) {
			log.error("Error [mailReportesAuditoria] al crear el archivo", e);
			throw new Exception(e);
		}
		// Voy por los destinatarios
		String[] mailsTo = dameMailsDirectorImportCompradorSrCompradorJrGerenteMatrizGerenteAudit(bus);
		try {
			MailUtils.mandaMailAuditoria(POS_RELEASED_MATRIX_PENDING_RELEASE_AUDIT, file, mailsTo, null);
			file = null;
		} catch (Exception e) {
			log.error("Error [mailReportesAuditoria] al enviar el correo", e);
			file = null;
			throw new Exception(e);
		}
		log.info("FIN mailReportesAuditoria ");
		return true;
	}
	
	public boolean mailReportesRevisionPreciosCompras() throws Exception {
		log.info("INICIO mailReportesRevisionPreciosCompras ");

		File file;
		List<BeanReporteControlPrecioSar> listaAux = null;
		List<BeanReporteControlPrecio> listaReportes = new ArrayList<>();
		Set<String> bus = new HashSet<>();
		Set<String> planeadores = new HashSet<>();
		try {
			listaAux = PriceReleaseServices.getInstance().getReportePOsPIsPendientesDeRevisionCompras();
			HashMap<String, BeanReporteControlPrecio> map = new HashMap<>();
			for (BeanReporteControlPrecioSar iter : listaAux) {
				String llave = iter.getLLave();
				BeanReporteControlPrecio bean;
				if (map.containsKey(llave)) {
					bean = map.get(llave);
					Date etd = iter.getEtd();
					Date ted_temp = bean.getEtd();
					if (etd != null && (ted_temp == null || etd.before(ted_temp))) {
						bean.setEtd(etd);
						bean.setDaysLeftForEtd(iter.getDaysLeftForEtd());
					}
				} else {
					map.put(llave, iter);
				}
				bus.add(iter.getBuClave());
				planeadores.add(iter.getPlaneador());
			}
			listaReportes.addAll(map.values());
			file = GeneraReportesMatriz.getInstance().generaReportePOsPIsPendientesDeRevisionCompras(listaReportes);
		} catch (Exception e) {
			log.error("Error [mailReportesRevisionPreciosCompras] al crear el archivo", e);
			throw new Exception(e);
		}
		// Voy por los destinatarios
		String[] mailsTo = dameMailsReportePOsPIsPendientesDeRevisionCompras(bus, planeadores);
		try {
			MailUtils.mandaMailReportePOsPIsPendientesDeRevisionCompras(POS_PIS_PENDING_REVIEW, file, mailsTo, null);
			file = null;
		} catch (Exception e) {
			log.error("Error [mailReportesRevisionPreciosCompras] al enviar el correo", e);
			file = null;
			throw new Exception(e);
		}
		log.info("FIN mailReportesRevisionPreciosCompras ");
		return true;
	}
	
	public boolean mailMatrizLiberados() throws Exception {
		log.info("INICIO mailMatrizLiberados ");
		File file;
		Date dateIni = UtilsFechas.getFechaActualSumaDiaMesAnio(0, -1, 0);
		String inicio = UtilsFechas.setConvierteFechaToString(dateIni, EnumFechas.FORMATO_YYYY_MM_DD_SLASH);
		Date dateFin = new Date();
		String fin = UtilsFechas.setConvierteFechaToString(dateFin, EnumFechas.FORMATO_YYYY_MM_DD_SLASH);
		try {
			file = GeneraReportesMatriz.getInstance().generaReportesMatriz(inicio, fin, GeneraReportesMatriz.LIBERADOS,null,null);
		} catch (Exception e) {
			log.error("Error [mailMatrizLiberados] al crear el archivo", e);
			throw new Exception(e);
		}
		String[] mailsTo = dameMailsTo(dameHashMaterialesYCentros(inicio, fin, GeneraReportesMatriz.LIBERADOS));
		String[] mailsCC = null;
		try {
			MailUtils.mandaMailMatrizAuditoria(GeneraReportesMatriz.LIBERADOS, file, mailsTo, mailsCC);
			file = null;
		} catch (Exception e) {
			log.error("Error [mailMatrizLiberados] al enviar el correo", e);
			file = null;
			throw new Exception(e);
		}
		log.info("FIN mailMatrizLiberados ");
		return true;
	}

	public boolean mailMatrizRechazados() throws Exception {
		log.info("INICIO mailMatrizRechazados ");
		File file;
		try {
			file = GeneraReportesMatriz.getInstance().generaReportesMatriz(GeneraReportesMatriz.VACIO,
					GeneraReportesMatriz.VACIO, GeneraReportesMatriz.RECHAZADOS, null,null);
		} catch (Exception e) {
			log.error("Error [mailMatrizRechazados] al crear el archivo", e);
			throw new Exception(e);
		}
		String[] mailsTo = dameMailsTo(dameHashMaterialesYCentros(GeneraReportesMatriz.VACIO,
				GeneraReportesMatriz.VACIO, GeneraReportesMatriz.RECHAZADOS));
		String[] mailsCC = CorreoHelper.getInstance().getEmail(CorreoHelper.MAIL_MATRIX_REJECTED).split(",");
		try {
			MailUtils.mandaMailMatrizAuditoria(GeneraReportesMatriz.RECHAZADOS, file, mailsTo, mailsCC);
			file = null;
		} catch (Exception e) {
			log.error("Error [mailMatrizRechazados] al enviar el correo", e);
			file = null;
			throw new Exception(e);
		}

		log.info("FIN mailMatrizRechazados ");
		return true;
	}

	public HashSet<String> dameHashMaterialesYCentros(String inicio, String fin, String tipoReporte) {
		BeanFiltroMatriz filtro = new BeanFiltroMatriz();
		filtro.setStatus(tipoReporte);
		int inicioInt = GeneraReportesMatriz.VACIO.equals(inicio) ? 0
				: FuncionesComunesPLI.fechaJquery2int(inicio, "/");
		int finInt = GeneraReportesMatriz.VACIO.equals(fin) ? 0 : FuncionesComunesPLI.fechaJquery2int(fin, "/");
		if (GeneraReportesMatriz.PENDIENTES.equals(tipoReporte)) {
			filtro.setLogIni(inicioInt == 0 ? null : UtilsFechas.setConvierteFechaIntToDate(inicioInt));
			filtro.setLogFin(finInt == 0 ? null : UtilsFechas.setConvierteFechaIntToDate(finInt));
		} else if (GeneraReportesMatriz.LIBERADOS.equals(tipoReporte)
				|| GeneraReportesMatriz.RECHAZADOS.equals(tipoReporte)) {
			filtro.setModIni(inicioInt == 0 ? null : UtilsFechas.setConvierteFechaIntToDate(inicioInt));
			filtro.setModFin(finInt == 0 ? null : UtilsFechas.setConvierteFechaIntToDate(finInt));
		}

		ArrayList<BeanMatrizCabecera> result = (ArrayList<BeanMatrizCabecera>) MatricesDAO.getInstance()
				.selectRegistrosMatriz(filtro);
		HashSet<String> datos = new HashSet<>();

		for (BeanMatrizCabecera tmp : result) {
			datos.addAll(dameMaterialYCentro(tmp));
		}
		return datos;
	}

	public HashSet<String> dameMaterialYCentro(BeanMatrizCabecera bean) {
		HashSet<String> datos = new HashSet<>();
		ArrayList<BeanMatrizDetalles> detalles = (ArrayList<BeanMatrizDetalles>) MatricesDAO.getInstance()
				.selectDetalles(bean.getPo(),
						UtilsFechas.setConvierteFechaToInt(bean.getFechaInsert(), EnumFechas.FORMATO_YYYYMMDD));

		for (BeanMatrizDetalles tmp : detalles) {
			datos.add(tmp.getMaterial().toString() + "|" + tmp.getCentro());
		}
		return datos;
	}

	public String[] dameMailsTo(HashSet<String> datos) throws ServletException {
		FuncionesComunesPLI.cargaPropertiesCDI(false);
		HashSet<String> correosTo = new HashSet<>();
		correosTo.add(SarBO.MAIL_GIL);
		correosTo.add(SarBO.EMAIL_GERENTE_AUDITORIA);
		correosTo.add(SarBO.EMAIL_GERENTE_MATRIZ);

		for (String dato : datos) {
			String[] split = dato.split("\\|");
			ProductoBean p = FuncionesComunesPLI.productos.get(split[0]);
			if (p != null && p.getProductoCentro() != null && p.getProductoCentro().get(split[1]) != null) {
				ProductoCentro pc = p.getProductoCentro().get(split[1]);

				String bu = pc.getCellCode();
				Set<String> correos = CorreoServices.getInstance().getCorreosDirectorBu(bu);
				if (correos != null && !correos.isEmpty()) {
					correosTo.addAll(correos);
				}
				correos = CorreoServices.getInstance().getCorreosGerenteBu(bu);
				if (correos != null && !correos.isEmpty()) {
					correosTo.addAll(correos);
				}
			}
		}
		
		String[] arreglo = new String[correosTo.size()];
		correosTo.toArray(arreglo);
		return arreglo;
	}

	public String[] dameMailsDirectorImportCompradorSrCompradorJrGerenteMatrizGerenteAudit(Set<String> bus) {
		Set<String> correos_set = new HashSet<>();
		correos_set.add(SarBO.MAIL_GIL);
		correos_set.add(SarBO.EMAIL_GERENTE_AUDITORIA);
		correos_set.add(SarBO.EMAIL_GERENTE_MATRIZ);
		for (String bu : bus) {
			Set<String> correos_temp = CorreoServices.getInstance().getCorreosDirectorBu(bu);
			if (correos_temp != null && correos_temp.size() > 0) {
				correos_set.addAll(correos_temp);
			}
			correos_temp = CorreoServices.getInstance().getCorreosGerenteBu(bu);
			if (correos_temp != null && correos_temp.size() > 0) {
				correos_set.addAll(correos_temp);
			}
		}
		String[] correos = new String[correos_set.size()];
		correos_set.toArray(correos);
		return correos;
	}
	
	public String[] dameMailsReportePOsPIsPendientesDeRevisionCompras(Set<String> bus, Set<String> planeadores) {
		HashSet<String> correos_set = new HashSet<>();
		correos_set.add(SarBO.EMAIL_OMAR_MORALES);
		correos_set.add(SarBO.MAIL_GIL);
		correos_set.add(SarBO.EMAIL_GERENTE_AUDITORIA);
		correos_set.add(SarBO.EMAIL_GERENTE_MATRIZ);

		Set<String> correos_temp = null;
		for (String bu : bus) {
			correos_temp = CorreoServices.getInstance().getCorreosDirectorBu(bu);
			if (correos_temp != null && !correos_temp.isEmpty()) {
				correos_set.addAll(correos_temp);
			}
			correos_temp = CorreoServices.getInstance().getCorreosGerenteBu(bu);
			if (correos_temp != null && !correos_temp.isEmpty()) {
				correos_set.addAll(correos_temp);
			}
		}
		correos_temp = CorreoServices.getInstance().getCorreosGerentePlaneacion(planeadores);
		if (correos_temp != null && !correos_temp.isEmpty()) {
			correos_set.addAll(correos_temp);
		}
		String[] correos = new String[correos_set.size()];
		correos_set.toArray(correos);
		return correos;
	}

	public void envioMailsXDias() { 
		try {
			log.info("Inicio envioMailsXDias ");
			HashSet<String> correos_set = new HashSet<>();
			correos_set.add(SarBO.EMAIL_GERENTE_MATRIZ);
			String[] correos = new String[correos_set.size()];
			correos_set.toArray(correos);
			GeneraReportesMatriz.getInstance().generaReporteXdias("X-Days reminder", correos, null);
			log.info("Fin envioMailsXDias ");
		} catch (ServletException e) {
			log.error("Error envioMailsXDias", e);
		}
	}
	
	
}
