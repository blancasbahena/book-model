package com.srm.pli.filters;

import java.io.IOException;
import java.net.URL;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.srm.pli.utils.PropertiesDb;

/**
 * Servlet Filter implementation class CORS
 */
public class CORS implements Filter {
	
	private static final Logger LOGGER = LogManager.getRootLogger();

	/**
	 * Default constructor.
	 */
	public CORS() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain chain)
			throws IOException, ServletException {

		HttpServletRequest request = (HttpServletRequest) servletRequest;
		// System.out.println("CORSFilter HTTP Request: " + request.getMethod());
		String whitelist = PropertiesDb.getInstance().getString("srm.booking.whitelist");
		HttpServletResponse resp = (HttpServletResponse) servletResponse;
		
		//LOGGER.info("Flag CORS validation  ::: " + PropertiesDb.getInstance().getString("srm.booking.whitelist.flag"));
		
		//LOGGER.info("WhiteList CORS validation  ::: " + whitelist);
		

		if (PropertiesDb.getInstance().getString("srm.booking.whitelist.flag").equalsIgnoreCase("true")) {
			String host = request.getHeader("Host");
			String origin = request.getHeader("Origin");
			URL aURL = null;
			if (origin != null) {
				aURL = new URL(origin);
				origin = aURL.getAuthority();
			}

			resp.setHeader("Host-Error", "");

			if (whitelist.indexOf(host) == -1) {
				LOGGER.info("Error Host ::: " + host);
				resp.setHeader("Host-Error", host);
				resp.sendError(HttpServletResponse.SC_BAD_REQUEST);
				throw new ServletException();
			}

			if (origin != null) {
				if (!whitelist.contains(origin)) {
					LOGGER.info("Error Origin ::: " + origin);
					resp.setHeader("Host-Error", origin);
					resp.sendError(HttpServletResponse.SC_BAD_REQUEST);
					throw new ServletException();
				}
			}
		}
		chain.doFilter(request, servletResponse);
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}
