package com.srm.pli.services;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.sap.document.sap.rfc.functions.ZMMINFOBUFFERS;
import com.srm.pli.bo.SarBO;
import com.srm.pli.bo.SarDetalleBO;
import com.srm.pli.dao.SAR_CDI_DAO;
import com.srm.pli.utils.FuncionesComunesPLI;
import com.srm.pli.utils.PropertiesDb;
import com.srm.pli.utils.TelServiceClient;
import com.srm.pli.utils.Utilerias;
import com.sun.jersey.core.util.MultivaluedMapImpl;
import com.truper.businessEntity.ProductoBean;

import lombok.extern.log4j.Log4j2;

@Log4j2
public class DetallesServices {

	private static DetallesServices instance = null;
	private static Map<Integer, ArrayList<SarDetalleBO>> mapaDetallesBO = null;
	private static Gson gson = new GsonBuilder().serializeSpecialFloatingPointValues().create();
	
	private DetallesServices() {
	}

	public static DetallesServices getInstance() {
		if(instance == null) {
			instance = new DetallesServices();
		}
		return instance;
	}

	public void borraMapaDetalles() {
		inicializaMapaGeneral(true);
	}
	
	public void eliminaDetalleSAR(int folio) {
		inicializaMapaGeneral(false);
		mapaDetallesBO.remove(folio);
	}
	
	private ArrayList<SarDetalleBO> mapToList(Map<String, SarDetalleBO> mapa){
		if(mapa == null) {
			return null;
		}
		ArrayList<SarDetalleBO> listDet = new ArrayList<>(mapa.values());
		return listDet;
	}
	
	/**
	 * regreso la lista del mapa
	 * @param sar
	 * @return
	 * @throws Exception
	 */
	public  List<SarDetalleBO> getDetalleSAR(SarBO sar) throws Exception{
		inicializaMapaGeneral(false);
		List<SarDetalleBO> list = mapaDetallesBO.get(sar.getFolio());
		if(list != null) {
			return  list;
		}else {
			ArrayList<SarBO> listaAConsultar = new ArrayList<>();
			//XXX genera detalles
			listaAConsultar.add(sar);
			cargaDatosSARs(listaAConsultar);
			return  mapaDetallesBO.get(sar.getFolio());
			
		}
		
	}
	
	
	public void cargaDatosSARs(SarBO sar) throws Exception {
		List<SarBO> lista = new ArrayList<>();
		lista.add(sar);
		cargaDatosSARs(lista);
	}
	
	/**
	 * Genero el mapa
	 * 
	 * @param sars
	 * @return
	 * @throws Exception
	 */
	public void cargaDatosSARs(List<SarBO> sars) throws Exception {
		inicializaMapaGeneral(false);
		ArrayList<SarDetalleBO> listaEnviar = new ArrayList<SarDetalleBO>(sars.size());
		int posicion = 0;
		StringBuffer buf = new StringBuffer();
		for (SarBO sar : sars) {
			Integer folio = sar.getFolio();
			if (folio == null || folio.intValue() <= 0) {
				continue;
			}
			if (!mapaDetallesBO.containsKey(folio)) {
				if (posicion > 0) {
					buf.append(",");
				}
				buf.append(folio);
				posicion++;
			}
			if (posicion == 400) {
				listaEnviar.addAll(SAR_CDI_DAO.dameDatosDetalles(buf.toString()));
				posicion = 0;
				buf = new StringBuffer();
			}
		}
		if (buf.length() > 0) {
			listaEnviar.addAll(SAR_CDI_DAO.dameDatosDetalles(buf.toString()));
		}
		if (listaEnviar.size() > 0) {
			agregaAMapaGeneral(listaEnviar);
		}
	}
	
	private void inicializaMapaGeneral(boolean reload) {
		if(mapaDetallesBO == null || reload ) {
			mapaDetallesBO =  new ConcurrentHashMap<Integer, ArrayList<SarDetalleBO>>();
		}
	}
	
	private void agregaAMapa(HashMap<Integer, SarBO> mapa , ArrayList<SarBO> sars) {
		for(SarBO s : sars) {
			mapa.put(s.getFolio(), s);
		}
	}
	
	
	private HashMap<Integer, SarBO> dameSarsBO(ArrayList<SarDetalleBO> detalles) throws ClassNotFoundException{
		int cont = 1;
		int posicion= 0;
		StringBuffer buf = new StringBuffer();
		HashMap<Integer, SarBO> map = new HashMap<>();
		HashSet<Integer> hash = new HashSet<>();
		//para quitar los repetidos
		for(SarDetalleBO det : detalles) {
			hash.add(det.getFolio());
		}
		
		for(Integer tmp : hash) {
			if(posicion > 0 ) {
				buf.append(",");
			}
			buf.append(tmp);
			cont++;
			posicion++;
			if(cont  == 400 ) {
				agregaAMapa(map,SAR_CDI_DAO.dameFoliosParaDetalles(buf.toString()));
				posicion= 0;
				buf = new StringBuffer();
			}
			
		}
		
		if(buf.length() > 0 ) {
			agregaAMapa(map,SAR_CDI_DAO.dameFoliosParaDetalles(buf.toString()));
		}
		return map;

	}
	
	private void dameInformacionDetalleSAR(ArrayList<SarDetalleBO> detalles) throws Exception{
		inicializaMapaGeneral(false);
		if(detalles == null || detalles.size() == 0) {
			return;
		}
		//Genero nueva lista, esta se mandara al webservice
		Set<SarDetalleBO> nuevaLista = new HashSet<SarDetalleBO>();
		for(SarDetalleBO det :  detalles){
			//LLeno la nueva lista de los que no contenga el mapa
			if(!mapaDetallesBO.containsKey(det.getFolio())){
				nuevaLista.add(det);
			}
		}
		if(nuevaLista == null || nuevaLista.isEmpty()) {
			return ;
		}
		agregaAMapaGeneral(new ArrayList<SarDetalleBO>(nuevaLista));
	}
	
	
	private void agregaAMapaGeneral(ArrayList<SarDetalleBO> detalles) throws Exception {
		
		Map<String, SarDetalleBO> mapaDetalles = new HashMap<String, SarDetalleBO>();
		
		for(SarDetalleBO obj : detalles) {
			mapaDetalles.put(obj.getFolio() + "|" + obj.getPo() + "|" + obj.getPosicion() , obj);
		}
		
		MultivaluedMapImpl formData = new MultivaluedMapImpl();
		formData.add("jsonObject",gson.toJson(detalles,new TypeToken<ArrayList<SarDetalleBO>>(){}.getType()));
		TelServiceClient tsc = new TelServiceClient("/dameDetalles", "TEL");
		String output = tsc.getRequest(formData);
		HashMap<Integer, ArrayList<SarDetalleBO>>  newMap = gson.fromJson(output,new TypeToken<HashMap<Integer, ArrayList<SarDetalleBO>>>(){}.getType());
		if (newMap != null) {
			HashMap<Integer, SarBO> mapaSARs = dameSarsBO(detalles);
			String codigosZSFC = PropertiesDb.getInstance().getString("cargaImportData.othersItems");
			String tmpCodigosZSFC [] = codigosZSFC!= null ? codigosZSFC.split(",") : null;
			///recorro el mapa nuevo para agregarlo al mapa de toda la aplicacion
			for(Entry<Integer, ArrayList<SarDetalleBO>> entry : newMap.entrySet()){
				HashMap<String, SarDetalleBO> innerMap = new HashMap<>();
				ArrayList<SarDetalleBO> lisToConsume = new ArrayList<>();
				int indice=0;
				///aqui calculo la diferencia de pesos y volumen
				for(SarDetalleBO det : entry.getValue()){
					
					det.setCommentDeleteProjection(mapaDetalles.get(det.getFolio() + "|" + det.getPo() + "|" + det.getPosicion()).getCommentDeleteProjection());
					det.setEliminarProyeccion(mapaDetalles.get(det.getFolio() + "|" + det.getPo() + "|" + det.getPosicion()).isEliminarProyeccion());
										
					det.setDescripcionComplementoFactura(detalles.get(indice).getDescripcionComplementoFactura());
					
					Double tmp = det.getPesoProveedor() -  FuncionesComunesPLI.calculaPesoParaCantidad(det.getCantidad(), det.getMaterial()+""); 
					det.setDifPesoUserVSSistem(tmp);
					tmp = det.getVolumenProveedor() -  FuncionesComunesPLI.calculaVolumenParaCantidad(det.getCantidad(), det.getMaterial()+""); 
					det.setDifVolumenUserVSSistem(tmp);
					
					ProductoBean prod = FuncionesComunesPLI.productos.get(det.getMaterial()+"");
					//double daysSafetyStock = 0.0;
					if (prod != null) {
						if(prod.isMateriaPrima())
							lisToConsume.add(det);
						//daysSafetyStock = prod.getDaysSafetyStock();
						det.setMarca(prod.getMarca());
					}
					//det.setDaysSafetyStock(daysSafetyStock);
					double valorPartida = det.getCantidad() * SarBO.getCostoFOB(det.getMaterial() + "");
					det.setValorEmbarque(new BigDecimal(valorPartida));
					SarBO bo = mapaSARs.get(det.getFolio());
					if(bo != null){
						try {
							Integer etd = (bo.getEtdReal() == null || bo.getEtdReal() == 0 )? bo.getFechaEmbarque() : bo.getEtdReal();
							int difDiasPIvsETD = Utilerias.diasHabiles(etd == null || etd == 0 ? 0 : etd, det.getDifDiasConfirm().intValue(), false);
							det.setDifDiasPIvsETD(difDiasPIvsETD);
						} catch (Exception e) {
							det.setDifDiasPIvsETD(null);
						}
					}else{
						det.setDifDiasPIvsETD(null);
					}
					
					if(tmpCodigosZSFC != null) {
						List<String> lstCodigosZSFC = Arrays.asList(tmpCodigosZSFC);
						if(!lstCodigosZSFC.isEmpty() && lstCodigosZSFC.contains(det.getMaterial().toString())) {
							det.setInventaroAlArribo(0);
							det.setBackorderPronosticado(new BigDecimal(0));
							det.setSafetyStock(new Double(0));
						}
					}
					
					innerMap.put(det.dameLlave(), det );
					indice++;
				}
				List<ZMMINFOBUFFERS> indicators = new ArrayList<>(); 
				ArrayList<SarDetalleBO> dets =  mapToList(innerMap);
				if(!lisToConsume.isEmpty()){
					try {
						indicators = IndicatorService.getInstance().getIndicatorsFromSAP(lisToConsume);
						for (SarDetalleBO det : dets) {
							int poInt = Integer.parseInt(det.getPo());
							int posicionInt = det.getPosicion();
			
							for (ZMMINFOBUFFERS indicator : indicators) {
								if ((Integer.parseInt(indicator.getPO()) == poInt && Integer.parseInt(indicator.getEBELP()) == posicionInt)
										|| (Integer.parseInt(indicator.getPOESPEJO()) == poInt && Integer.parseInt(indicator.getEBELNPESPEJO()) == posicionInt)	) {
									log.info("### Actualizando IDA de la PO ZMP: PO {}, Posicion {}, IDA FR: {} -> IDA SAP: {}", 
									det.getPo(), det.getPosicion(), det.getInventaroAlArribo(), indicator.getDIASINVENTARIOARRIBO());
									det.setInventaroAlArribo(Integer.parseInt(indicator.getDIASINVENTARIOARRIBO()));
									break; // Salir del bucle interno después de encontrar la coincidencia
								}
							}
						}
				} catch (Exception e) {
					log.error("Error al obtener los indicadores de SAP: {}", e.getMessage());
				}
				}
				if(dets != null) {
					mapaDetallesBO.put(entry.getKey(),dets);
				}
			}
		} else {
			throw new Exception("Falla en el servicio web de detalle");
		}
	}
}
