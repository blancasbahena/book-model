package com.srm.pli.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.srm.pli.bo.SarBO;
import com.srm.pli.db.ConexionDB;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class RequestBookingDAO{
	
	private static RequestBookingDAO instance;
	
	
	private RequestBookingDAO() {
		
	}
	
	public static RequestBookingDAO getInstance() {
		if (instance == null) {
			instance = new RequestBookingDAO();
		}
		return instance;
	}
	
	public List<SarBO> dameSarsSinBooking() throws SQLException {
		List<SarBO> lista = null;
		Connection con = null;
		StringBuffer sql = new StringBuffer();
		try {
			con = ConexionDB.dameConexion();
			
			sql.append("SELECT s.folio,s.proveedor, s.fechaEmbarque,s.etdFinal,s.usuarioApruebaPlanning ");
			sql.append("FROM cdisar s  LEFT JOIN  cdiReferenceNumber r ");
			sql.append("ON  r.folio =s.folio ");
			sql.append("WHERE s.status = 3  ");
			sql.append("AND s.booking is NULL AND r.folio is NULL ");
			sql.append("AND s.consolidado = 0 ");
			
			
			try (PreparedStatement pst = con.prepareStatement(sql.toString())) {
				try (ResultSet rs = pst.executeQuery()) {
					lista = new ArrayList<>();
					SarBO bo;
					while (rs.next()) {
						bo = new SarBO();
						bo.setFolio(rs.getInt("folio"));
						Integer fechaEmbarque = rs.getInt("fechaEmbarque");
						bo.setFechaEmbarque(fechaEmbarque != null ? fechaEmbarque : 0);
						Integer etd = rs.getInt("etdFinal");
						bo.setEtdReal(etd != null ? etd : 0);
						bo.setProveedor(rs.getString("proveedor"));
						bo.setUsuarioApruebaPlanning(rs.getString("usuarioApruebaPlanning"));
						lista.add(bo);
					}
				}
			}
			ConexionDB.devuelveConexion(con);
			return lista;
		} catch (Exception sqle) {
			log.error("Error al ejecutar la sentencia {}",sql.toString(),sqle);
			try {
				ConexionDB.devuelveConexion(con);
			} catch (SQLException e) {
				log.error("Error:",e);
			}
			throw new SQLException(sqle);
		}
		
	}
	
}
