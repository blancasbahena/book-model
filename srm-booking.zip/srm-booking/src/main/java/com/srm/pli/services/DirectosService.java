package com.srm.pli.services;

import static com.srm.pli.enums.EnumDirectosBusquedaPor.BOOKING;
import static com.srm.pli.enums.EnumDirectosBusquedaPor.FOLIO;

import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.srm.pli.dao.DirectosDao;
import com.srm.pli.domain.BeanDirectos;
import com.srm.pli.enums.EnumDirectosBusquedaPor;
import com.srm.pli.helper.DirectosHelper;
import com.truper.utils.string.UtilsString;

public class DirectosService {

	private static DirectosService instance = null;

	private DirectosService() {
	}

	public static DirectosService getInstance() {
		if (instance == null)
			instance = new DirectosService();
		return instance;
	}

	public boolean isBookingConDirectos(String booking) {
		if (!UtilsString.isStringValida(booking))
			return false;
		boolean contieneDirectos = contieneDirectos(BOOKING, booking);
		return contieneDirectos;
	}

	public boolean isFolioConDirectos(String folio) {
		if (!UtilsString.isStringValida(folio))
			return false;
		boolean contieneDirectos = contieneDirectos(FOLIO, folio);
		return contieneDirectos;
	}

	public boolean validaSiContieneDirectos(Map<Integer, List<BeanDirectos>> mapaDirectos) {
		if (mapaDirectos == null || mapaDirectos.isEmpty())
			return false;
		for (Entry<Integer, List<BeanDirectos>> entry : mapaDirectos.entrySet()) {
			List<BeanDirectos> directos = entry.getValue();
			if (directos == null || directos.isEmpty())
				continue;
			for (BeanDirectos beanDirectos : directos) {
				boolean isDirecto = DirectosHelper.getInstance().isDirecto(beanDirectos);
				if (isDirecto)
					return true;
			}
		}
		return false;
	}

	private boolean contieneDirectos(EnumDirectosBusquedaPor buscarPor, String valor) {
		Map<Integer, List<BeanDirectos>> mapaDirectos = null;
		mapaDirectos = DirectosDao.getInstance().selectDirectos(buscarPor, valor);
		boolean contieneDirectos = validaSiContieneDirectos(mapaDirectos);
		return contieneDirectos;
	}

}
