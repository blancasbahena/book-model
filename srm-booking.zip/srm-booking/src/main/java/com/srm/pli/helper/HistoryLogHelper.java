package com.srm.pli.helper;

import java.util.ArrayList;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.srm.pli.dao.SAR_CDI_DAO;
import com.srm.pli.enums.HistoryLogAction;
import com.srm.pli.utils.FuncionesComunesPLI;
import com.truper.businessEntity.UserBean;

public class HistoryLogHelper {
	
	public static final HistoryLogHelper instance = new HistoryLogHelper();
	private static final Logger LOGGER = LogManager.getRootLogger();
	
	
	private HistoryLogHelper() {
		
	}
	
	
	public static HistoryLogHelper getInstance() {
		return instance;
	}
	
	/**
	 * todos los SARs que tengan ese control documental y les inserta  
	 */
	public void insertaHistoryLogEnBooking(int idControlDocumental, int idEnumHistory,String usuario) {
		try {
			ArrayList<Integer> lista =  SAR_CDI_DAO.selectSarsEnBooking(idControlDocumental);
			for(Integer folio : lista) {
				FuncionesComunesPLI.guardaSARHistoryLog(idEnumHistory, folio, usuario, null, "F", null);
			}
		} catch (Exception e) {
			LOGGER.error("Error: agregando History log:"+e.toString());
		}
	}
	
	public String getUserName(UserBean userBean){
		if(userBean == null)
			return null;
		String username = userBean.getUserNameReal() != null ? userBean.getUserNameReal() : userBean.getUserName();
		return username;
	}
}
