package com.srm.pli.helper;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.truper.businessEntity.UserBean;

public class UsuarioHelper {

	private static UsuarioHelper instance = null;
	public static final Logger log = LogManager.getRootLogger();
	
	private UsuarioHelper() {
	}

	public static UsuarioHelper getInstance() {
		if(instance == null) {
			instance = new UsuarioHelper();
		}
		return instance;
	}
	
	/**
	 * Indica que el usuario puede ver todos los SARs, Directos  y SARs normales
	 * 
	 * @param usuario
	 * @return
	 */
	public boolean veSarsDirectosYNormales(UserBean usuario) {
		if(usuario == null) {
			return false;
		}
		
		if(usuario.isVeSARDirecto() && usuario.isVeSARNormal()) {
			return true;
		}
		return false;
	}
	
	public boolean veSoloSARsDirectos(UserBean usuario) {
		if(usuario == null) {
			return false;
		}
		
		if(usuario.isVeSARDirecto() && !usuario.isVeSARNormal()) {
			return true;
		}
		
		return false;
	}
}
