package com.srm.pli.dao;

import static com.srm.pli.dao.sql.AuditoriaSql.SELECT_CON_MATRIZ_DETALLE_DATE_PO;
import static com.srm.pli.dao.sql.AuditoriaSql.SELECT_CON_MATRIZ_DETALLE_PO_SUPPLIER_DATE;
import static com.srm.pli.dao.sql.AuditoriaSql.SELECT_SAR_DETALLE_FOLIO;
import static com.srm.pli.dao.sql.AuditoriaSql.SELECT_SIN_MATRIZ_DETALLE_PO_DATE;
import static com.srm.pli.dao.sql.AuditoriaSql.SELECT_SIN_MATRIZ_DETALLE_PO_DATE_REJECT;
import static com.srm.pli.dao.sql.AuditoriaSql.UPDATE_SAR;
import static com.srm.pli.dao.sql.AuditoriaSql.UPDATE_SIN_MATRIZ_LIBERA;
import static com.srm.pli.dao.sql.AuditoriaSql.UPDATE_SIN_MATRIZ_RECHAZA;
import static com.srm.pli.dao.sql.AuditoriaSql.UPSERT_AUDITORIA;
import static com.srm.pli.dao.sql.AuditoriaSql.getSelectPpuCabeceras;
import static com.srm.pli.dao.sql.AuditoriaSql.getSelectRejectCabeceras;
import static com.srm.pli.dao.sql.AuditoriaSql.getSelectSarCabeceras;
import static com.srm.pli.dao.sql.AuditoriaSql.getSelectSinMatrizCabeceras;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.srm.pli.bo.BeanFiltroAuditoria;
import com.srm.pli.bo.BeanFiltroAuditoriaVista;
import com.srm.pli.db.ConexionDB;
import com.srm.pli.utils.FuncionesComunesPLI;
import com.srm.pli.utils.ProductoUtils;
import com.truper.bpm.enums.EstatusAuditoriaEnum;
import com.truper.businessEntity.BeanAuditoria;
import com.truper.businessEntity.BeanAuditoriaMatriz;
import com.truper.businessEntity.BeanAuditoriaPpu;
import com.truper.businessEntity.BeanAuditoriaRechazado;
import com.truper.businessEntity.BeanAuditoriaSar;
import com.truper.businessEntity.BeanAuditoriaSarDetalle;
import com.truper.businessEntity.BeanAuditoriaSinMatriz;
import com.truper.businessEntity.BeanAuditoriaSinMatrizDetalle;
import com.truper.businessEntity.BeanAuditoriaSinMatrizDetalleProveedor;
import com.truper.businessEntity.BeanControlPrecios;
import com.truper.businessEntity.ImportacionesProveedoresBean;
import com.truper.utils.date.UtilsFechas;
import com.truper.utils.string.UtilsString;

public class AuditoriaDao {

	private static final AuditoriaDao instance = new AuditoriaDao();
	private static final Logger LOGGER = LogManager.getRootLogger();

	private AuditoriaDao() {
	}

	public static AuditoriaDao getInstance() {
		return instance;
	}

	public ArrayList<BeanAuditoriaSinMatrizDetalle> selectDetalleOrdenSinMatriz(BeanAuditoria param) {
		ArrayList<BeanAuditoriaSinMatrizDetalle> respuesta = null;
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();
			try (PreparedStatement pst = con.prepareStatement(SELECT_SIN_MATRIZ_DETALLE_PO_DATE)) {
				setWhereValues(param, pst, 0);
				try (ResultSet rs = pst.executeQuery()) {
					respuesta = new ArrayList<>();
					BeanAuditoriaSinMatrizDetalle bean = null;
					while (rs.next()) {
						bean = new BeanAuditoriaSinMatrizDetalle();
						setBasicValuesDetailsFromRs(bean, rs);
						respuesta.add(bean);
					}
				}
			}
		} catch (SQLException sqle) {
			sqle.printStackTrace();
			LOGGER.error(sqle);
			ConexionDB.renovar(con);
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error(e);
		} finally {
			ConexionDB.devolver(con);
		}
		return respuesta;
	}

	public ArrayList<BeanAuditoriaSinMatrizDetalle> selectDetalleOrdenSinMatrizReject(BeanAuditoria param) {
		ArrayList<BeanAuditoriaSinMatrizDetalle> respuesta = null;
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();
			try (PreparedStatement pst = con.prepareStatement(SELECT_SIN_MATRIZ_DETALLE_PO_DATE_REJECT)) {
				setWhereValues(param, pst, 0);
				try (ResultSet rs = pst.executeQuery()) {
					respuesta = new ArrayList<>();
					BeanAuditoriaSinMatrizDetalle bean = null;
					while (rs.next()) {
						bean = new BeanAuditoriaSinMatrizDetalle();
						setBasicValuesDetailsFromRs(bean, rs);
						respuesta.add(bean);
					}
				}
			}
		} catch (SQLException sqle) {
			sqle.printStackTrace();
			LOGGER.error(sqle);
			ConexionDB.renovar(con);
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error(e);
		} finally {
			ConexionDB.devolver(con);
		}
		return respuesta;
	}

	public ArrayList<BeanAuditoriaSinMatrizDetalle> selectDetalleOrdenConMatriz(BeanAuditoria param) {
		ArrayList<BeanAuditoriaSinMatrizDetalle> respuesta = null;
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();
			try (PreparedStatement pst = con.prepareStatement(SELECT_CON_MATRIZ_DETALLE_PO_SUPPLIER_DATE)) {
				setWhereValues(param, pst, 0);
				try (ResultSet rs = pst.executeQuery()) {
					respuesta = new ArrayList<>();
					BeanAuditoriaSinMatrizDetalle bean = null;
					while (rs.next()) {
						bean = new BeanAuditoriaSinMatrizDetalle();
						setBasicValuesDetailsFromRs(bean, rs);
						respuesta.add(bean);
					}
				}
			}
		} catch (SQLException sqle) {
			sqle.printStackTrace();
			LOGGER.error(sqle);
			ConexionDB.renovar(con);
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error(e);
		} finally {
			ConexionDB.devolver(con);
		}
		return respuesta;
	}
	
	public ArrayList<BeanAuditoriaSinMatrizDetalleProveedor> selectDetalleOrdenConMatrizFechaPo(Date createDate, String po) {
		ArrayList<BeanAuditoriaSinMatrizDetalleProveedor> respuesta = null;
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();
			try (PreparedStatement pst = con.prepareStatement(SELECT_CON_MATRIZ_DETALLE_DATE_PO)) {
				int i = 1;
				pst.setDate(i, UtilsFechas.setConvierteFechaToSQLDate(createDate));
				pst.setString(++i, po);
				try (ResultSet rs = pst.executeQuery()) {
					respuesta = new ArrayList<>();
					BeanAuditoriaSinMatrizDetalleProveedor bean = null;
					while (rs.next()) {
						bean = new BeanAuditoriaSinMatrizDetalleProveedor();
						bean.setProveedor(rs.getString("proveedor"));
						setBasicValuesDetailsFromRs(bean, rs);
						respuesta.add(bean);
					}
				}
			}
		} catch (SQLException sqle) {
			sqle.printStackTrace();
			LOGGER.error(sqle);
			ConexionDB.renovar(con);
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error(e);
		} finally {
			ConexionDB.devolver(con);
		}
		return respuesta;
	}

	public ArrayList<BeanAuditoriaSinMatriz> selectCabeceraOrdenesSinMatriz(BeanFiltroAuditoriaVista filtro) {
		ArrayList<BeanAuditoriaSinMatriz> respuesta = null;
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();
			try (PreparedStatement pst = con.prepareStatement(getSelectSinMatrizCabeceras(filtro))) {
				int i = 1;
				pst.setInt(i, filtro.getEstatus().getId());
				setFilterValues(filtro, pst, i);
				try (ResultSet rs = pst.executeQuery()) {
					respuesta = new ArrayList<>();
					BeanAuditoriaSinMatriz bean = null;
					while (rs.next()) {
						bean = new BeanAuditoriaSinMatriz();
						setBasicValuesHeadersFromRs(bean, rs);
						respuesta.add(bean);
					}
				}
			}
		} catch (SQLException sqle) {
			sqle.printStackTrace();
			LOGGER.error(sqle);
			ConexionDB.renovar(con);
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error(e);
		} finally {
			ConexionDB.devolver(con);
		}
		return respuesta;
	}

	public ArrayList<BeanAuditoriaRechazado> selectCabecerasOrdenesRechazadas(BeanFiltroAuditoriaVista filtro) {
		ArrayList<BeanAuditoriaRechazado> respuesta = null;
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();
			try (PreparedStatement pst = con.prepareStatement(getSelectRejectCabeceras(filtro))) {
				if (filtro != null) {
					int c = 1;
					int i = 0;
					while (c <= 2) {
						if (UtilsString.isStringValida(filtro.getProveedor())) {
							pst.setString(++i, filtro.getProveedor());
						}
						if (UtilsString.isStringValida(filtro.getPo())) {
							pst.setString(++i, filtro.getPo());
						}
						c++;
					}
				}
				try (ResultSet rs = pst.executeQuery()) {
					respuesta = new ArrayList<>();
					BeanAuditoriaRechazado bean = null;
					while (rs.next()) {
						bean = new BeanAuditoriaRechazado();
						setBasicValuesHeadersFromRs(bean, rs);
						Date logDate = rs.getTimestamp("logDate");
						String comentarios = rs.getString("comentarios");
						String tipo = rs.getString("tipo");
						bean.setLogDate(logDate);
						bean.setComentarios(comentarios);
						bean.setTipo(tipo);
						respuesta.add(bean);
					}
				}
			}
		} catch (SQLException sqle) {
			sqle.printStackTrace();
			LOGGER.error(sqle);
			ConexionDB.renovar(con);
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error(e);
		} finally {
			ConexionDB.devolver(con);
		}
		return respuesta;
	}

	public ArrayList<BeanAuditoriaPpu> selectCabecerasOrdenesPPU(BeanFiltroAuditoriaVista filtro) {
		ArrayList<BeanAuditoriaPpu> respuesta = null;
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();
			try (PreparedStatement pst = con.prepareStatement(getSelectPpuCabeceras(filtro))) {
				setFilterValues(filtro, pst, 0);
				try (ResultSet rs = pst.executeQuery()) {
					respuesta = new ArrayList<>();
					BeanAuditoriaPpu bean = null;
					while (rs.next()) {
						bean = new BeanAuditoriaPpu();
						setBasicValuesHeadersFromRs(bean, rs);
						Date logDate = rs.getTimestamp("logDate");
						String comentarios = rs.getString("comentario");
						bean.setLogDate(logDate);
						bean.setComentarios(comentarios);
						respuesta.add(bean);
					}
				}
			}
		} catch (SQLException sqle) {
			sqle.printStackTrace();
			LOGGER.error(sqle);
			ConexionDB.renovar(con);
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error(e);
		} finally {
			ConexionDB.devolver(con);
		}
		return respuesta;
	}

	public ArrayList<BeanAuditoriaSar> selectCabecerasSAR(BeanFiltroAuditoriaVista filtro) {
		ArrayList<BeanAuditoriaSar> respuesta = null;
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();
			try (PreparedStatement pst = con.prepareStatement(getSelectSarCabeceras(filtro))) {
				int c = 0;
				if (filtro != null) {
					if (filtro.getEstatus() != null) {
						pst.setInt(++c, filtro.getEstatus().getId());
					}
					if (filtro.getFolio() != null && filtro.getFolio() > 0) {
						pst.setInt(++c, filtro.getFolio());
					}
					setFilterValues(filtro, pst, c);
				}
				try (ResultSet rs = pst.executeQuery()) {
					respuesta = new ArrayList<>();
					BeanAuditoriaSar bean = null;
					while (rs.next()) {
						bean = new BeanAuditoriaSar();
						setBasicValuesFromRs(bean, rs);
						int folio = rs.getInt("folio");
						bean.setFolio(folio);
						String comentarios = rs.getString("comentarios");
						bean.setComentarios(comentarios);
						respuesta.add(bean);
					}
				}
			}
		} catch (SQLException sqle) {
			sqle.printStackTrace();
			LOGGER.error(sqle);
			ConexionDB.renovar(con);
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error(e);
		} finally {
			ConexionDB.devolver(con);
		}
		return respuesta;
	}

	public ArrayList<BeanAuditoriaSarDetalle> selectDetalleSar(int folio) {
		ArrayList<BeanAuditoriaSarDetalle> respuesta = null;
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();
			try (PreparedStatement pst = con.prepareStatement(SELECT_SAR_DETALLE_FOLIO)) {
				pst.setInt(1, folio);
				try (ResultSet rs = pst.executeQuery()) {
					respuesta = new ArrayList<>();
					BeanAuditoriaSarDetalle bean = null;
					while (rs.next()) {
						bean = new BeanAuditoriaSarDetalle();
						setBasicValuesDetailsFromRs(bean, rs);
						respuesta.add(bean);
					}
				}
			}
		} catch (SQLException sqle) {
			sqle.printStackTrace();
			LOGGER.error(sqle);
			ConexionDB.renovar(con);
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error(e);
		} finally {
			ConexionDB.devolver(con);
		}
		return respuesta;
	}

	public Integer updateLiberaOrdenSinMatriz(BeanAuditoria param) {
		Integer num_insert = null;
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();
			try (PreparedStatement pst = con.prepareStatement(UPDATE_SIN_MATRIZ_LIBERA);) {
				int i = 1;
				pst.setString(i, param.getComentarios());
				setWhereValues(param, pst, i);
				num_insert = pst.executeUpdate();
			}
		} catch (SQLException sqle) {
			sqle.printStackTrace();
			LOGGER.error("Informacion: " + param == null ? "NULL" : param.toString(), sqle);
			ConexionDB.renovar(con);
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error("Informacion: " + param == null ? "NULL" : param.toString(), e);
		} finally {
			ConexionDB.devolver(con);
		}
		return num_insert;
	}

	public Integer updateLiberaOrdenConMatriz(BeanAuditoriaMatriz param) {
		Integer num_insert = null;
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();
			StringBuilder sql = new StringBuilder();
			sql.append(" UPDATE cdiControlMatrices ");
			sql.append(" SET liberacionAuditoria = GETDATE() ");
			sql.append(" 		, status = ? ");
			sql.append(" 		, comentario = CONCAT(comentario, ' | Audit comments: ', ?) ");
			sql.append(" WHERE DATEADD(day,DATEDIFF(day,0,fechaInsert),0) = ? ");
			sql.append(" 	AND proveedor = ? ");
			sql.append(" 	AND po = ? ");
			try (PreparedStatement pst = con.prepareStatement(sql.toString())) {
				int i = 1;
				pst.setString(i, param.getEstatus().id());
				pst.setString(++i, param.getComentarios());
				setWhereValues(param, pst, i);
				num_insert = pst.executeUpdate();
			}
		} catch (SQLException sqle) {
			sqle.printStackTrace();
			LOGGER.error("Informacion: " + param == null ? "NULL" : param.toString(), sqle);
			ConexionDB.renovar(con);
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error("Informacion: " + param == null ? "NULL" : param.toString(), e);
		} finally {
			ConexionDB.devolver(con);
		}
		return num_insert;
	}

	public Integer updateRechazaOrdenSinMatriz(BeanAuditoria param) {
		Integer num_insert = null;
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();
			try (PreparedStatement pst = con.prepareStatement(UPDATE_SIN_MATRIZ_RECHAZA);) {
				int i = 1;
				pst.setString(i, param.getComentarios());
				setWhereValues(param, pst, i);
				num_insert = pst.executeUpdate();
			}
		} catch (SQLException sqle) {
			sqle.printStackTrace();
			LOGGER.error("Informacion: " + param == null ? "NULL" : param.toString(), sqle);
			ConexionDB.renovar(con);
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error("Informacion: " + param == null ? "NULL" : param.toString(), e);
		} finally {
			ConexionDB.devolver(con);
		}
		return num_insert;
	}

	public Integer updateSar(BeanFiltroAuditoria param) {
		Integer num_insert = null;
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();
			try (PreparedStatement pst = con.prepareStatement(UPDATE_SAR);) {
				int i = 1;
				pst.setInt(i, param.getEstatus().getId());
				pst.setString(++i, param.getComentarios());
				pst.setInt(++i, param.getFolio());
				num_insert = pst.executeUpdate();
			}
		} catch (SQLException sqle) {
			sqle.printStackTrace();
			LOGGER.error("Informacion: " + param == null ? "NULL" : param.toString(), sqle);
			ConexionDB.renovar(con);
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error("Informacion: " + param == null ? "NULL" : param.toString(), e);
		} finally {
			ConexionDB.devolver(con);
		}
		return num_insert;
	}

	public Integer upsertNuevasOrdenes(HashSet<BeanControlPrecios> informacion) {
		Integer num_insert = null;
		Connection con = null;
		Boolean autoCommit = null;
		try {
			con = ConexionDB.dameConexion();
			try (PreparedStatement pst = con.prepareStatement(UPSERT_AUDITORIA);) {
				autoCommit = con.getAutoCommit();
				con.setAutoCommit(false);
				for (BeanControlPrecios o : informacion) {
					int i = 1;
					pst.setInt(i, EstatusAuditoriaEnum.NEW.getId());
					i = setBasicParameters(pst, i, o);
					pst.addBatch();
				}
				int[] insert_counts = pst.executeBatch();
				con.commit();
				num_insert = new Integer(0);
				for (int i : insert_counts) {
					num_insert += i;
				}
			}
		} catch (SQLException sqle) {
			sqle.printStackTrace();
			LOGGER.error("Informacion: " + informacion == null ? "NULL" : informacion.toString(), sqle);
			ConexionDB.renovar(con);
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error("Informacion: " + informacion == null ? "NULL" : informacion.toString(), e);
		} finally {
			if (autoCommit != null) {
				try {
					con.setAutoCommit(autoCommit);
				} catch (SQLException e) {
					e.printStackTrace();
					LOGGER.error("Error al colocar " + autoCommit.toString() + " en setAutoCommit", e);
				}
			}
			ConexionDB.devolver(con);
		}
		return num_insert;
	}

	public int actualizaValorSimple(String tabla, String columna, Object valor, String columnaWhere, Object valorWhere)
			throws Exception {
		Integer num_update = null;
		Connection con = null;
		try {
			StringBuffer sql = new StringBuffer(" UPDATE ");
			sql.append(tabla).append(" SET ");
			sql.append(columna).append(" = ? WHERE ");
			sql.append(columnaWhere).append(" = ?");
			con = ConexionDB.dameConexion();
			try (PreparedStatement pst = con.prepareStatement(sql.toString());) {
				pst.setObject(1, valor);
				pst.setObject(2, valorWhere);
				num_update = pst.executeUpdate();
			}
		} catch (SQLException sqle) {
			sqle.printStackTrace();
			StringBuffer msg = new StringBuffer();
			msg.append("Informacion: Tabla: ").append(tabla);
			msg.append(", Columna: ").append(columna);
			msg.append(", Valor: ").append(valor);
			msg.append(", Columna Where: ").append(columnaWhere);
			msg.append(", Valor Where: ").append(valorWhere);
			LOGGER.error(msg.toString(), sqle);
			ConexionDB.renovar(con);
			throw sqle;
		} catch (Exception e) {
			e.printStackTrace();
			StringBuffer msg = new StringBuffer();
			msg.append("Informacion: Tabla: ").append(tabla);
			msg.append(", Columna: ").append(columna);
			msg.append(", Valor: ").append(valor);
			msg.append(", Columna Where: ").append(columnaWhere);
			msg.append(", Valor Where: ").append(valorWhere);
			LOGGER.error(msg.toString(), e);
			throw e;
		} finally {
			ConexionDB.devolver(con);
		}
		return num_update;
	}

	/**
	 * 
	 * @param pst
	 * @param i
	 * @param info
	 * @return
	 * @throws SQLException
	 */
	private int setBasicParameters(PreparedStatement pst, int i, BeanControlPrecios info) throws SQLException {
		pst.setString(++i, info.getProveedor());
		pst.setString(++i, info.getPo());
		pst.setInt(++i, info.getPosicion());
		pst.setInt(++i, info.getMaterial());
		pst.setString(++i, info.getCentro());
		pst.setInt(++i, info.getCantidad());
		pst.setBigDecimal(++i, info.getPrecioUnitario());
		pst.setInt(++i, info.getFecha());
		pst.setString(++i, info.getDocumentosRequeridos());
		return i;
	}

	/**
	 * @param rs
	 * @return
	 * @throws SQLException
	 */
	private void setBasicValuesHeadersFromRs(BeanAuditoriaSinMatriz bean, ResultSet rs) throws SQLException {
		setBasicValuesFromRs(bean, rs);
		String po = rs.getString("po");
		bean.setPo(po);
	}

	/**
	 * @param rs
	 * @return
	 * @throws SQLException
	 */
	private void setBasicValuesFromRs(BeanAuditoriaSinMatriz bean, ResultSet rs) throws SQLException {
		Date createDate = rs.getTimestamp("createDate");
		Integer etd_i = rs.getInt("etd");
		Date etd = UtilsFechas.setConvierteFechaIntToDate(etd_i);
		Integer daysLeftForEtd = rs.getInt("daysLeftForEtd");
		String proveedor = rs.getString("proveedor");
		int material = rs.getInt("material");
		String centro = rs.getString("centro");
		Integer daysLeftFromCreateDate = rs.getInt("daysLeftFromCreateDate");

		bean.setCreateDate(createDate);
		bean.setEtd(etd);
		bean.setDaysLeftForEtd(daysLeftForEtd);
		bean.setProveedor(proveedor);
		ImportacionesProveedoresBean bean_prov = FuncionesComunesPLI.getProveedor(proveedor);
		if (bean_prov != null)
			bean.setProveedorDescripcion(bean_prov.getNombreProveedor());
		String bu = ProductoUtils.getInstance().getBUName(String.valueOf(material), centro);
		bean.setBu(bu);
		bean.setDaysLeftFromCreateDate(daysLeftFromCreateDate);
	}

	/**
	 * @param rs
	 * @return
	 * @throws SQLException
	 */
	private void setBasicValuesDetailsFromRs(BeanAuditoriaSinMatrizDetalle bean, ResultSet rs) throws SQLException {
		int posicion = rs.getInt("posicion");
		int material = rs.getInt("material");
		String centro = rs.getString("centro");
		int cantidad = rs.getInt("cantidad");
		BigDecimal precioUnitario = rs.getBigDecimal("precioUnitario");
		Date etd = UtilsFechas.setConvierteFechaIntToDate(rs.getInt("fecha"));

		String material_s = String.valueOf(material);
		bean.setPosicion(posicion);
		bean.setMaterial(material);
		String clave = ProductoUtils.getInstance().getClave(material_s);
		bean.setClave(clave);
		bean.setCantidad(cantidad);
		bean.setPrecioUnitario(precioUnitario);
		bean.setEtd(etd);
		String bu = ProductoUtils.getInstance().getBUName(material_s, centro);
		bean.setBu(bu);
		String buClave = ProductoUtils.getInstance().getBU(material_s, centro);
		bean.setBuClave(buClave);
	}

	/**
	 * @param rs
	 * @return
	 * @throws SQLException
	 */
	private void setBasicValuesDetailsFromRs(BeanAuditoriaSarDetalle bean, ResultSet rs) throws SQLException {
		String po = rs.getString("po");
		int posicion = rs.getInt("posicion");
		int material = rs.getInt("material");
		String centro = rs.getString("centro");
		int cantidad = rs.getInt("cantidad");
		BigDecimal precioUnitario = rs.getBigDecimal("precioUnitario");
		Date etd = UtilsFechas.setConvierteFechaIntToDate(rs.getInt("fecha"));

		String material_s = String.valueOf(material);
		bean.setPo(po);
		bean.setPosicion(posicion);
		bean.setMaterial(material);
		String clave = ProductoUtils.getInstance().getClave(material_s);
		bean.setClave(clave);
		bean.setCantidad(cantidad);
		bean.setPrecioUnitario(precioUnitario);
		bean.setEtd(etd);
		String bu = ProductoUtils.getInstance().getBUName(material_s, centro);
		bean.setBu(bu);
	}

	/**
	 * @param param
	 * @param ps
	 * @param i
	 * @throws SQLException
	 */
	private void setWhereValues(BeanAuditoria param, PreparedStatement pst, int i) throws SQLException {
		pst.setDate(++i, UtilsFechas.setConvierteFechaToSQLDate(param.getCreateDate()));
		pst.setString(++i, param.getProveedor());
		pst.setString(++i, param.getPo());
	}

	/**
	 * @param param
	 * @param ps
	 * @param i
	 * @throws SQLException
	 */
	private void setWhereValues(BeanAuditoriaMatriz param, PreparedStatement pst, int i) throws SQLException {
		pst.setDate(++i, UtilsFechas.setConvierteFechaToSQLDate(param.getCreateDate()));
		pst.setString(++i, param.getProveedor());
		pst.setString(++i, param.getPo());
	}
	
	/**
	 * @param filtro
	 * @param pst
	 * @param i
	 * @throws SQLException
	 */
	private void setFilterValues(BeanFiltroAuditoriaVista filtro, PreparedStatement pst, int i) throws SQLException {
		if (filtro == null)
			return;
		if (UtilsString.isStringValida(filtro.getProveedor())) {
			pst.setString(++i, filtro.getProveedor());
		}
		if (UtilsString.isStringValida(filtro.getPo())) {
			pst.setString(++i, filtro.getPo());
		}
	}

}