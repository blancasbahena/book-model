package com.srm.pli.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import com.srm.pli.db.ConexionDB;
import com.truper.businessEntity.BeanPuerto;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class PuertosDescargaDao{

	private static PuertosDescargaDao instance = null;

	private static final String QUERY_DELETE_POD = new StringBuffer("DELETE FROM cdiConfirmadorPOD "
			+ "	WHERE userName = ? AND pod = ?").toString();
	
	private static final String INSERT_POD_CONFIRM = new StringBuffer("INSERT INTO cdiConfirmadorPOD ")
			.append(" (userName,pod,fechaCreacion,userCreated) ")
			.append("	VALUES (?,?,CURRENT_TIMESTAMP,?)").toString();
	
	private static final String SELECT_POD_COFIRM = new StringBuffer("SELECT pod FROM cdiConfirmadorPOD WHERE username = ? AND pod = ?").toString();
	
	public static PuertosDescargaDao getInstance() {
		if (instance == null) {
			instance = new PuertosDescargaDao();
		}
		return instance;
	}
	
	
	public static int updatePodByUser(String userCrea,String userPOD,List<BeanPuerto> puertos) {
		Connection con = null;
		PreparedStatement pst = null;
		int result = 0;
		ResultSet rs = null;
		try {
			con = ConexionDB.dameConexion();
			
			for(BeanPuerto info : puertos  ) {
				
				if( "delete".equals(info.getStatus()) ) {
					pst = con.prepareStatement(QUERY_DELETE_POD);
					pst.setString(1, userPOD);
					pst.setString(2, info.getClave());
					result = pst.executeUpdate();
				}else if( "new".equals(info.getStatus()) ) {
					pst = con.prepareStatement(INSERT_POD_CONFIRM);
					pst.setString(1, userPOD);
					pst.setString(2, info.getClave());
					pst.setString(3, userCrea);
					result = pst.executeUpdate();
				}
				if( "in".equals( info.getStatus())  ) {
					
					pst = con.prepareStatement(SELECT_POD_COFIRM);
					pst.setString(1, userPOD);
					pst.setString(2, info.getClave());
					
					rs = pst.executeQuery();
					
					if( !rs.next()) {
						pst.close();
						pst = con.prepareStatement(INSERT_POD_CONFIRM);
						pst.setString(1, userPOD);
						pst.setString(2, info.getClave());
						pst.setString(3, userCrea);
						result = pst.executeUpdate();
					}
					
					
				}
					
			}
			pst.close();
			ConexionDB.devuelveConexion(con);
			return result;
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		} catch (SQLException e) {
			e.printStackTrace();
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			log.error(e.getMessage(), e);
		}
		return result;
		
	}
}
