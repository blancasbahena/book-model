package com.srm.pli.bo;

public class BeanAuditoriaProveedorActualizado {

	private String proveedor;
	private int actualizados;

	public String getProveedor() {
		return proveedor;
	}

	public void setProveedor(String proveedor) {
		this.proveedor = proveedor;
	}

	public int getActualizados() {
		return actualizados;
	}

	public void setActualizados(int actualizados) {
		this.actualizados = actualizados;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("BeanAuditoriaProveedorActualizado [getProveedor=");
		builder.append(getProveedor());
		builder.append(", getActualizados=");
		builder.append(getActualizados());
		builder.append("]");
		return builder.toString();
	}

}
