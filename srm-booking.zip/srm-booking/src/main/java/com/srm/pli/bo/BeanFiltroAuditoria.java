package com.srm.pli.bo;

import com.truper.bpm.enums.EstatusAuditoriaEnum;

public class BeanFiltroAuditoria {

	private int folio;
	private EstatusAuditoriaEnum estatus;
	private String comentarios;

	public int getFolio() {
		return folio;
	}

	public void setFolio(int folio) {
		this.folio = folio;
	}

	public EstatusAuditoriaEnum getEstatus() {
		return estatus;
	}

	public void setEstatus(EstatusAuditoriaEnum estatus) {
		this.estatus = estatus;
	}

	public String getComentarios() {
		return comentarios;
	}

	public void setComentarios(String comentarios) {
		this.comentarios = comentarios;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("BeanFiltroAuditoria [getFolio=");
		builder.append(getFolio());
		builder.append(", getEstatus=");
		builder.append(getEstatus());
		builder.append(", getComentarios=");
		builder.append(getComentarios());
		builder.append("]");
		return builder.toString();
	}

}
