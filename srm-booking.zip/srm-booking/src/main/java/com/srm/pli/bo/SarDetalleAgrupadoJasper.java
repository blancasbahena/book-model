package com.srm.pli.bo;

import java.util.ArrayList;

import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

public class SarDetalleAgrupadoJasper {
	private String totalCantidad;
	private String subtotalPO;
	private String subtotalAmountOther;
	private String subtotalAmountOtherFOC;
	
	private ArrayList<SarDetalleJasper> detalles;

	public String getTotalCantidad() {
		return totalCantidad;
	}

	public void setTotalCantidad(String totalCantidad) {
		this.totalCantidad = totalCantidad;
	}


	public String getSubtotalPO() {
		return subtotalPO;
	}

	public void setSubtotalPO(String subtotalPO) {
		this.subtotalPO = subtotalPO;
	}

	public String getSubtotalAmountOther() {
		return subtotalAmountOther;
	}

	public void setSubtotalAmountOther(String subtotalAmountOther) {
		this.subtotalAmountOther = subtotalAmountOther;
	}

	public String getSubtotalAmountOtherFOC() {
		return subtotalAmountOtherFOC;
	}

	public void setSubtotalAmountOtherFOC(String subtotalAmountOtherFOC) {
		this.subtotalAmountOtherFOC = subtotalAmountOtherFOC;
	}

	public void setDetalles(ArrayList<SarDetalleJasper> detalles) {
		this.detalles = detalles;
	}
	public JRDataSource getDetalles() {
		return new JRBeanCollectionDataSource(detalles);
	}
}
