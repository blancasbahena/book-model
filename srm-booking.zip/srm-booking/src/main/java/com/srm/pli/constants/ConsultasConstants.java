package com.srm.pli.constants;

public class ConsultasConstants
{
	 public static final String GET_CONSULTA_DB_TO_KPIS = new StringBuilder("SELECT ")
	.append("  ROW_NUMBER() OVER(Partition by hLog.folio ORDER BY hLog.folio) AS 'numero de cambios de ETD', ")
	.append("	hLog.folio, ")
	.append("	hLog.booking, ")
	.append("	hLog.eta as 'Last ETA', ")
	.append("	s.eta as 'Current ETA', ")
	.append("	hLog.etdAnterior as 'Last ETD', ") 
	.append("	hLog.etd as 'ETD solicitada', ") 
	.append("	(CASE WHEN s.etdFinal IS NULL OR s.etdFinal < 20000101 THEN s.fechaEmbarque ELSE s.etdFinal END) as 'Current ETD', ") 
	.append("	hLog.vessel, ") 
	.append("	hLog.voyage, ") 
	.append("	hLog.carrier, ") 
	.append("	nav.nombre as nombreNaviera, ") 
	.append("	hLog.supplier as proveedor, ") 		
	.append("	hLog.bl, ") 
	.append("	hLog.tipoContenedor, ") 
	.append("	cont.nombre as nombreContenedor, ") 
	.append("	hLog.contenedor, ") 
	.append("	hLog.pol, ") 
	.append("	hLog.pod, ") 
	.append("	hLog.estatus_RM, ") 
	.append("	hLog.reason, ") 
	.append("	hLog.create_date, ") 
	.append("	hLog.create_date_solicitado ") 
	.append("FROM cdiSarRMLog hLog ") 
	.append("INNER JOIN cdiSarRM rm ON rm.folio = hLog.folio ") 
	.append("LEFT JOIN cdiSar s ON hLog.folio = s.folio ") 
	.append("LEFT JOIN cdiNavieras nav ON nav.clave = hLog.carrier ") 
	.append("LEFT JOIN cdiContenedores cont ON hLog.tipoContenedor = cont.clave ") 
	.append("WHERE hLog.create_date_solicitado BETWEEN ? AND ? ORDER BY hLog.folio DESC ").toString();
	 
	 public static final String GET_CONSULTA_CAMBIOS_X_NAVIERA_PROVEEDOR = new StringBuilder("SELECT ")
	.append("reason, ")
	.append("COUNT(reason) as cantidad ")
	.append("FROM cdiSarRMLog hLog ")
	.append("WHERE hLog.create_date >= ? and hLog.create_date <= ? and estatus_RM = 'aprobado_rm' ")
	.append("AND reason IN ('DELAY CARRIER', 'ADVANCE CARRIER', 'ROLL CARRIER', 'DELAY SHIPPER', 'ADVANCE SHIPPER', 'ROLL SHIPPER', 'DELAY WITHOUT NEW ETD BY CARRIER','DELAY WITHOUT NEW ETD BY SHIPPER') ")
	.append("GROUP BY reason ")
	.append("ORDER BY COUNT(hLog.reason) DESC ").toString();
	 
	 public static final String INSERT_RM_LOG = new StringBuilder("INSERT INTO cdiSarRMLog ")
	.append("(folio, booking, carrier, voyage, vessel, pol, pod, etd, etdAnterior, eta, transist_time, estatus_RM, isConsol, reason, ")
	.append("supplier, bl, tipoContenedor, contenedor, create_date, create_date_solicitado ) ")
	.append("values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?, GETDATE(), ?) ").toString();
	 
	 public static final String FIND_FOLIO = new StringBuilder("SELECT ")
	.append("(CASE WHEN s.etdFinal IS NULL OR s.etdFinal < 20000101 THEN s.fechaEmbarque ELSE s.etdFinal END) as 'Current ETD' ")
	.append("FROM cdiSar s ")
	.append("WHERE s.folio IN (?) ").toString();
	 
	 
	 public static final String FIND_NAME_FACTURA = new StringBuilder()
	.append("SELECT id, nombre FROM cdi_facturas WHERE id = ? AND versionDocumento = ? ").toString();
	 
	 public static final String GET_DOCUMENTOS_SDI = new StringBuilder()
	.append("SELECT id, versionFacturas FROM cdiDocumentosSDI WHERE proveedor = ? AND booking = ? AND versionSDI = ? ").toString();
	 
	 public static final String GET_VERSION_DOCUMENTO = new StringBuilder()
	.append("SELECT DISTINCT(versionSetDocumentos) FROM cdiSAR WHERE booking = ? AND proveedor = ? ").toString();
	 
	 public static final String GET_NOMBRE_NAVIERA = new StringBuilder()
	.append("SELECT clave, nombre FROM cdiNavieras ")
	.append("WHERE  clave = ? ")
	.toString();
	 
	 public static final String GET_INFORMACION_CDI_SAR = new StringBuilder()
	.append("WITH registroscdisar ") 
	.append("     AS (SELECT Row_number() ") 
	 .append("                  OVER ( ") 
	 .append("                    ORDER BY sar.proveedor) AS RowNumber, ") 
	 .append("                sar.proveedor, ") 
	 .append("                sar.puertosalida            AS 'puertoOrigen', ") 
	 .append("                sar.puertodescarga          AS 'puertoDestino', ") 
	 .append("                puertoOrigen.nombre         AS 'nombrePuertoOrigen', ") 
	 .append("                sarDetalle.cliente, ") 
	 .append("                sarDetalle.po               AS 'poParcel', ") 
	 .append("                sar.folio                   AS 'folioSAR', ") 
	 .append("                sar.fechaembarque           AS 'etdSAR', ") 
	 .append("                sar.booking                 AS 'numBKG', ") 
	 .append("                sar.etdfinal                AS 'etdBooking', ") 
	 .append("                sar.contenedor, ") 
	 .append("                sar.naviera, ") 
	 .append("                sar.eta 					AS 'etaEstimadaNaviera', ") 
	 .append("                sar.comentarioPlanner AS 'instruccionInicialBL' ") 
	 .append("         FROM   cdisar sar ") 
	 .append("         INNER JOIN cdisardetalle sarDetalle ON sarDetalle.folio = sar.folio ") 
	 .append("		 INNER JOIN cdiPuertosOrigen puertoOrigen ON puertoOrigen.clave = sar.puertoDescarga) ") 
	 .append("SELECT DISTINCT") 
	 .append("       registroscdisar.proveedor, ") 
	 .append("       registroscdisar.puertoorigen, ") 
	 .append("       registroscdisar.puertodestino, ") 
	 .append("       registroscdisar.nombrePuertoOrigen, ") 
	 .append("       registroscdisar.cliente, ") 
	 .append("       registroscdisar.poparcel, ") 
	 .append("       registroscdisar.foliosar, ") 
	 .append("       registroscdisar.etdsar, ") 
	 .append("       registroscdisar.numbkg, ") 
	 .append("       registroscdisar.etdbooking, ") 
	 .append("       registroscdisar.contenedor, ") 
	 .append("       registroscdisar.naviera, ") 
	 .append("       registroscdisar.etaEstimadaNaviera, ") 
	 .append("       registroscdisar.instruccionInicialBL ") 
	 .append("FROM   registroscdisar ") 
	 .append("WHERE  registroscdisar.foliosar = ? ").toString();
	 
	 public static final String GET_DOCUMENTS_SDI_BY_ID = new StringBuilder()
	.append("SELECT docs.id, sar.folio, sar.booking, sar.proveedor, sar.versionSetDocumentos FROM cdiSAR AS sar ")
	.append("INNER JOIN cdiDocumentosSDI AS docs ON sar.booking = docs.booking AND sar.proveedor = docs.proveedor ")
	.append("AND sar.versionSetDocumentos = docs.versionSDI ")
	.append("WHERE sar.folio = ?")
	.toString();
	 
	 public static final String MERGE_IN_CDI_SARS_EN_BOOKING = new StringBuilder()
	.append("MERGE cdiSARsEnBooking as [target] ")
	.append("USING (select ? id, ? sar ) AS [source] ")
	.append("ON ([target].id = [source].id AND [target].sar = [source].sar) ")
	.append("WHEN matched THEN ")
	.append("UPDATE SET [target].id = [source].id, [target].sar = [source].sar ")
	.append("WHEN not matched THEN ")
	.append("INSERT (id,sar) values ([source].id,[source].sar); ")
	.toString();
	 
	 public static final String FIND_REFERENCE_NUMBER_BY_FOLIO = new StringBuilder("SELECT ")
				.append("rn.referenceNumber as 'Reference Number' ")
				.append("FROM cdiReferenceNumber rn ")
				.append("WHERE rn.folio = ? ").toString();
	 
	 public static final String GET_RELEASE_DATE_BYSHIPPING = new StringBuilder("SELECT ")
				.append("hl.etd as 'Approved by Shipping' ")
				.append("FROM cdiSARHistoryLog hl ")
				.append("WHERE hl.action = 9 ")
				.append("AND hl.modificationTimeStamp = ")
				.append("(SELECT MAX(temp.modificationTimeStamp) ")
				.append("FROM cdiSARHistoryLog temp ")
				.append("WHERE temp.action = 9 AND temp.folio = hl.folio) ")
				.append("AND hl.folio = ? ").toString();
	
	public static final String FIND_ACTION_ID_BY_ACTION = new StringBuilder("SELECT ")
		.append("ah.id as 'Action Id' ")
		.append("FROM cdiActionsSARHistoryLog ah ")
		.append("WHERE ah.action = ? ").toString();

	public static final StringBuilder INSERT_REVISION_GDR = new StringBuilder("INSERT INTO cdiRevisionGDR (")
		.append("folio, fechaGDRActual, fechaGDRModificada, fechaETDActual, fechaETDModificada, diferenciaDiasETD) ")
		.append("VALUES (?,?,?,?,?,?)");

	public static final StringBuilder UPDATE_SAR_STATUS_GDR = new StringBuilder(" UPDATE cdiSAR ")
		.append(" SET gdrEnRevision= ?, ")
		.append(" gdrAprobado= ? ")
		.append(" WHERE folio = ? ");

	public static final StringBuilder APROBACION_GDR = new StringBuilder(" UPDATE cdiSAR ")
		.append(" SET etdFinal = ? ")
		.append(" ,goods_ready_date = ? ")
		.append(" ,gdrNotificado = 0 ")
		.append(" WHERE folio = ? ");

	public static final StringBuilder FOLIOS_PENDIENTES_CONTENEDOR = new StringBuilder()
		.append("SELECT folio FROM cdiSAR ")
		.append("WHERE (((etdfinal IS NOT NULL AND etdfinal > 0)  AND (etdfinal = ? OR etdFinal = ? ")
		.append("OR (etdFinal <= ? AND etdFinal >= ?))) ")
		.append("OR (fechaembarque = ? OR fechaembarque = ? ")
		.append("OR (fechaembarque <= ? AND fechaEmbarque >= ?) )) ")
		.append("AND referenciaContenedorProveedor IS NULL ")
		.append("AND contenedor IS NULL ")
		.append("AND status NOT IN (4, 6)");

	public static final StringBuilder INSERTA_SAR_HISTORY_LOG = new StringBuilder(
		"INSERT INTO cdiSARHistoryLog (folio, supplier, sarType, action, modificationDate, modificationTimeStamp,")
		.append(
		" userName, etd, eta, shippingPort, portOfDischarge, carrier, destinationCountry, delayType, vessel, voyage,")
		.append(
		" booking, bl, containerType, containerNumber, priority, groundTransportation, sarLocked, consolidatedFolio, comments, esDirecto, ContainerSupplier, commentProfiles, createDate)")
		.append(" VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
	
	public static final StringBuilder CONSULTA_REGISTROS_SIFE = new StringBuilder(" SELECT ")	
		.append("  f.factura_fecha_emision   diaFacturacion " )
		.append(" ,f.am_pm                   turnoDeentrega" )
		.append(" ,fac.nombre                numeroFactura" )
		.append(" ,f.supplier_code           numeroProveedor" )
		.append(" ,f.supplier_code           nombreProveedor" )
		.append(" ,f.documentoNumero         numeroDocumentoSap" )
		.append(" ,f.numero_factura_pm       numeroParceMobil" )
		.append(" ,f.monto_usd               importeUsd" )
		.append(" ,f.comentarios_incidencias identificacionHandling" )
		.append(" ,f.FolioSIFE   " )
		.append(" ,f.FolioSIFE43 " )
		.append(" ,f.sar         " )
		.append(" ,f.fechaProcesadoSIFE" )
		.append(" ,CONVERT (date,f.fechaProcesadoSIFE) fechaSife, auxkey " )
		.append(" FROM  facturacion f inner join cdisar cdi on  cdi.folio =f.sar" )
		.append(" inner join cdiDocumentosSDI sdi on sdi.proveedor  =cdi.proveedor  and sdi.booking =cdi.booking " )
		.append("       and sdi.versionSDI = ( select  max(versionSDI) from cdiDocumentosSDI sdsd where sdsd.proveedor  = sdi.proveedor and sdsd.booking =sdi.booking  )" )
		.append(" inner join cdi_facturas fac on fac.id  = sdi.id " )
		.append(" and f.supplier_code = cdi.proveedor " )
		.append(" and fac.condicionPago  =  f.condicionPago" )
		.append(" where estatus_cuarenta_tres=1 " )
		.append(" and estatus_diecinueve= 1  ")
		.append(" and CONVERT (date,fechaProcesadoSIFE) = CONVERT (date, GETDATE() srm.facturacion.sife.dias )")
		.append(" order by f.sar,numero_factura_pm,FolioSIFE,FolioSIFE43   ");
	public static final StringBuilder CONSULTA_REGISTROS_SIFE_HANDLING = new StringBuilder
			       (" SELECT  concat(LTRIM(RTRIM(cd.po)),'-',LTRIM(RTRIM(cd.posicion))) handling ")	
			.append("  FROM cdiSAR cs INNER join cdiSARDetalle cd on cs.folio = cd.folio " )
			.append(" WHERE cd.material = (select CONVERT (varchar,valor)    " )
			.append(" from cdiConfProperties ccp where llave  ='srm.facturacion.handling.charge')" )
			.append(" and cs.folio = ? " );
	public static final StringBuilder INSERTA_HEBREO = new StringBuilder("IF EXISTS")
	.append(" (SELECT idDescripcion, item, descripcionHebreo, fechaCarga" ) 
	.append(" FROM cdiDescHebreo WHERE item=?) ")
	.append(" UPDATE cdiDescHebreo SET descripcionHebreo= ?  ,")
	.append(" fechaCarga= ?  WHERE item = ?")
	.append(" ELSE INSERT INTO cdiDescHebreo(item, descripcionHebreo, fechaCarga) VALUES(?,?,?)");

	public static final StringBuilder CONSULTA_HEBREO = new StringBuilder(
		"SELECT * FROM cdiDescHebreo WHERE item = ? "
	);
	public static final StringBuilder APROBACION_GDR_BO_LINEAMIENTO = new StringBuilder(" UPDATE cdiSAR ")
			.append(" SET etdFinal = ? ")
			.append(" ,goods_ready_date = ? ")
			.append(" ,gdrNotificado = 0 ")
			.append(" ,status  = statusAnteriorGRD ")
			.append(" WHERE folio = ? ");
	public static final StringBuilder UPDATE_SAR_STATUS_GDR_AND_BO = new StringBuilder(" UPDATE cdiSAR ")
			.append(" SET gdrEnRevision= ?, ")
			.append(" gdrAprobado= ? ")
			.append(" ,status  = statusAnteriorGRD")
			.append(" WHERE folio = ? ");

}
