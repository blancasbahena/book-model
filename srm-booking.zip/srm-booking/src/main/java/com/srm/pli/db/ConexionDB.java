package com.srm.pli.db;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.GregorianCalendar;


public class ConexionDB {

	public static final int CONEXION_BDTEL			= 0;

	private static String url = null;

	public final static String pwdCambiaPwd 		= "%%T3sl42017*";
	
	public final static String TIPO_JDBC_MSQL 		= "MSQLJDBC";
    public final static String TIPO_JDBC_JTDS 		= "JTDSJDBC";
    
	
	static GregorianCalendar ultNotificacionBD    = new GregorianCalendar();
	
	public static String getUrl(){
		return url;
	}

	public static Connection dameConexion() throws ClassNotFoundException, SQLException {
		return DB_JNDI.getInstance().getConnection();
	}
	
	public static void renuevaConexion( Connection c ) throws SQLException {
		DB_JNDI.getInstance().closeConnection(c);
	}

	public static void devuelveConexion(Connection c) throws SQLException {
		DB_JNDI.getInstance().closeConnection(c);
	}
	
	@Deprecated
    public static void renovar(Connection con) {
    	DB_JNDI.getInstance().closeConnection(con);
    }

    public static void devolver(Connection con) {
    	DB_JNDI.getInstance().closeConnection(con);
    }
}
