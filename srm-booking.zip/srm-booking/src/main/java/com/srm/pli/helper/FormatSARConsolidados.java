package com.srm.pli.helper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang3.StringEscapeUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.srm.pli.bo.SarBO;
import com.srm.pli.bo.SarConsolBO;
import com.srm.pli.utils.FuncionesComunesPLI;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class FormatSARConsolidados {
	private Integer folioRaw;
	private String folio;
	private String folioVista;
	private String puertoDescarga;
	private String puertoDescargaNum;
	private String puertoSalida;
	private String puertoSalidaNum;
	private Object naviera;
	private Object navieraNum;
	private String fechaEmbarque;
	private int status;
	private String strStatus;
	private String tipoContenedor;
	private Integer tipoContenedorNum;
	private Integer prioridad;
	private String eta;
	private String barcoSugerido;
	private String etdReal;
	private String contenedor;
	private String viaje;
	private String booking;
	private Integer transporte;
	private String volumen;
	private String peso;
	private JSONArray proveedores;
	private String POsEnConsolidado;
	private Object backOrderPron;
	private Object colorPrioridad;
	private String comentarioConsol;
	private Object paisDestino;
	private String tipoProd;
	private String listaPo;
	private ArrayList<SarBO> detalle;
	private String comentarioTruperBooking;
	private int numPartidas;
	private boolean sarImportado;
	private boolean aviso;
	private String warning;
	private Integer revision;
	private Boolean etdRealWarning;
	private String usrEtdRealWarning;
	private boolean referenceNumber;
	private boolean fechaIDAAceptada;
	private boolean revisionIDA;
	private boolean bitacoraIDA;
	private boolean bitacoraIDACerrada;
	private int IDAMin;
	private String dameIconosHTML;
	private List<String> POsByFolioSAR;

	public FormatSARConsolidados(SarConsolBO consol){
		FuncionesComunesPLI.cargaPuertosDestino(false);
		FuncionesComunesPLI.cargaPuertosOrigen(false);
		FuncionesComunesPLI.cargaNavieras(false);
		FuncionesComunesPLI.cargaContenedores(false);
		folioRaw = consol.getFolio();
		folio = "C"+consol.getFolio();
		folioVista = "CC"+consol.getFolio()+(consol.getTipoProducto() != null ? consol.getTipoProducto() : "N")+(consol.getRevision() != null ? "R"+consol.getRevision() : ""  );
		puertoDescarga = FuncionesComunesPLI.mapaPuertosDestino.get(consol.getPuertoDescarga()).getNombre();
		puertoDescargaNum = consol.getPuertoDescarga();
		puertoSalida = consol.getPuertoSalida() != null ?  FuncionesComunesPLI.mapaPuertosOrigen.get(consol.getPuertoSalida()).getNombre() : "";
		puertoSalidaNum = consol.getPuertoSalida();
		naviera = consol.getNaviera() != null && consol.getNaviera() >= 0 ? FuncionesComunesPLI.mapaNavieras.get(consol.getNaviera()).getNombre() : null;
		navieraNum = consol.getNaviera();
		fechaEmbarque = consol.getFechaEmbarque() != null ? FuncionesComunesPLI.formateaFechaYYYYMMDD(consol.getFechaEmbarque()) : "";
		status = consol.getStatus();
		setStrStatus(StringEscapeUtils.escapeHtml3(dameLeyendaStatus()));
		tipoContenedor = consol.getTipoContenedor() != null && !"".equals(consol.getTipoContenedor()) ? FuncionesComunesPLI.mapaContenedores.get(consol.getTipoContenedor()).getNombre() : "";
		tipoContenedorNum = consol.getTipoContenedor();
		prioridad = consol.getPrioridad(); 
		eta = consol.getEta() != null ?  FuncionesComunesPLI.formateaFechaYYYYMMDD(consol.getEta()) : "";
		etdReal = consol.getEtdReal() != null && consol.getEtdReal() > 0   ?  FuncionesComunesPLI.formateaFechaYYYYMMDD(consol.getEtdReal()) : ""; 
		barcoSugerido = StringEscapeUtils.escapeHtml3(consol.getBarcoSugerido());
		viaje = StringEscapeUtils.escapeHtml3(consol.getViaje());
		contenedor = StringEscapeUtils.escapeHtml3(consol.getContenedor());
		booking = consol.getBooking() != null ? StringEscapeUtils.escapeHtml3(consol.getBooking()) : "";
		transporte = consol.getTransporte();
		revisionIDA = consol.isRevisionIDA();
		bitacoraIDA = consol.isBitacoraIDA();
		bitacoraIDACerrada = consol.isBitacoraIDACerrada();
		peso = FuncionesComunesPLI.formatea(consol.getPeso());
		volumen = FuncionesComunesPLI.formatea(consol.getVolumen(),2);
		proveedores = dameProveedores(consol.getMapaProveedores());
		POsEnConsolidado = consol.getPOsEnConsolidado();
		backOrderPron =  consol.getBackorderPronosticadoTot()!= null ? FuncionesComunesPLI.formatea(consol.getBackorderPronosticadoTot().doubleValue(), 2)  : 0;
		colorPrioridad = consol.getPrioridad() == 1 ? SarBO.COLOR_BLANCO  : (consol.getPrioridad() == 2  ? SarBO.COLOR_ROJO : SarBO.COLOR_MORADO );
		comentarioConsol = consol.getComentarioConsol() != null ? StringEscapeUtils.escapeJson(consol.getComentarioConsol()) : "";
		paisDestino = consol.getPaisDestino() != null ? consol.getPaisDestino() : "-1" ;
		tipoProd = consol.getTipoProducto() != null ? consol.getTipoProducto() : "N" ;
		listaPo = consol.getListaPos() != null ?  consol.getListaPos().toString() : "N.D";
		sarImportado = consol.isSarImportado();
		comentarioTruperBooking =consol.getComentarioTruperBooking();
		revision = consol.getRevision() != null ? consol.getRevision() : 0;
		if(detalle != null){
			numPartidas = detalle.size();
			for(SarBO det : detalle){
				detalle.add(det);
			}
		}else{
			numPartidas = 0;
		}
		setAviso(consol.isAviso());
		setWarning(consol.getWarning());
		etdRealWarning = consol.getEtdRealWarning() == null ? Boolean.FALSE : consol.getEtdRealWarning();
		usrEtdRealWarning = consol.getUsrEtdRealWarning() == null ? "" : consol.getUsrEtdRealWarning();
		setIDAMin(consol.getIDAMinimo());
		
		if(consol.isAlmacen45()) {
			dameIconosHTML = "<img title=\"Store 45\" width=\"15px\" height=\"15px\" src=\"/srm_booking/images/45icon.png\">";
		}
		
		///esta debe ser la ultima linea por que guardo el BO como respaldo
		consol.setConsolBOAntesFormato(consol);
		consol.setFormatConsolFormatoTemp(this);
		
	}

	/**
	 * Pendiente para una nueva iteracion despues de las juntas
	 * @return
	 * @throws JSONException 
	 */
	private JSONArray dameProveedores(HashMap<String, String> mapaProveedores) throws JSONException{
		JSONArray json = new JSONArray();
		//for()
		if(mapaProveedores == null){
			return json;
		}
		Set<String> set =  mapaProveedores.keySet();
		for(String llave : set){
			JSONObject jsonObj = new JSONObject();			
			jsonObj.put("proveedor", mapaProveedores.get(llave));
			jsonObj.put("proveedorClave",llave);
			json.put(jsonObj);
		}
				
		return json;
	}
	
	private String dameLeyendaStatus() {
		String status = "";
		
		switch (this.status) {
		case SarBO.STATUS_SIN_SOLICITUD_APROBACION:
			status = "Without Approval Request";
			break;
		case SarBO.STATUS_APROBADO:
			status = "Approved";
			break;
		case SarBO.STATUS_EMBARCADO:
			status = "Shipped";
			break;
		case SarBO.STATUS_ESPERA_APROBACION_PLANEACION:
		case SarBO.STATUS_ESPERA_APROBACION_SHIPPING:
			status = "Waiting for Approval";
			break;
		case SarBO.STATUS_CANCELADO:
			status = "Rejected";
			break;
		case SarBO.STATUS_EN_REVISION_PRECIOS:
			status = "Waiting for price release";
			break;
		default:
			status = "-";
			break;
		}
		
		return status;
	}


	
}
