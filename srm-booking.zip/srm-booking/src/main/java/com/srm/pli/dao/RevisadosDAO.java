package com.srm.pli.dao;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import com.srm.pli.bo.SarDetalleBO;
import static  com.srm.pli.dao.sql.RevisadosSql.SELECT_REVISADOS;
import static  com.srm.pli.dao.sql.RevisadosSql.SELECT_REVISADOS_OTROS;
import static  com.srm.pli.dao.sql.RevisadosSql.ADD_DETALLE;
import com.srm.pli.db.ConexionDB;
import com.truper.utils.string.UtilsString;


public class RevisadosDAO {

	private static final RevisadosDAO instance = new RevisadosDAO();
	private static final Logger log = LogManager.getRootLogger();
	private static String VACIO = "";
	
	private RevisadosDAO() {
	}

	public static RevisadosDAO getInstance() {
		return instance;
	}

	public void updateSAR(int folio, int nuevaETD, Connection con) throws Exception {
	Integer num_insert = null;
	try {
		StringBuilder sql = new StringBuilder();
		sql.append("UPDATE CDISAR SET etdFinal = ? ");
		sql.append(" WHERE folio = ?");
		
		try (PreparedStatement pst = con.prepareStatement(sql.toString());) {
			int i = 1;
			pst.setInt(i, nuevaETD);
			pst.setInt(++i, folio);
			num_insert = pst.executeUpdate();
		}
		if(num_insert == null || num_insert == 0) {
			throw new Exception("Error no se actualizo ningun registro.");
		}
	} catch (Exception e) {
		log.error("updateSAR: Folio: [{}] , nuevaETD: [{}]", folio , nuevaETD , e);
		throw e;
	}
}
	
	public List<SarDetalleBO> selectRevisados(int folio) {
		List<SarDetalleBO> respuesta = null;
		Connection con = null;
	try {
		con = ConexionDB.dameConexion();
		try (PreparedStatement pst = con.prepareStatement(SELECT_REVISADOS)) {
			pst.setInt(1, folio);
			try (ResultSet rs = pst.executeQuery()) {
				respuesta = new ArrayList<>();
				SarDetalleBO temp = null;
				while (rs.next()) {
					temp = new SarDetalleBO();
					temp.setFolio(rs.getInt("folio"));
					temp.setPo(rs.getString("po"));
					temp.setPosicion(rs.getInt("posicion"));
					temp.setMaterial(rs.getInt("material"));
					temp.setCentro(rs.getString("centro"));
					temp.setCantidad(rs.getInt("cantidad"));
					temp.setPesoProveedor(rs.getDouble("pesoProveedor"));
					temp.setVolumenProveedor(rs.getDouble("volumenProveedor"));
					BigDecimal precioUnitario = rs.getBigDecimal("preciounitario");
					if (rs.wasNull()) {
						precioUnitario = null;
					}
					temp.setPrecioUnitario(precioUnitario);
					temp.setPlaneador(rs.getString("planeador"));
					temp.setCantidadModificada(rs.getInt("cantidadModificada"));
					temp.setPesoModificado(rs.getDouble("pesoModificado"));
					temp.setVolumenModificado(rs.getDouble("volumenModificado"));
					temp.setCliente(rs.getString("cliente"));
					temp.setUnidaMedida(rs.getString("unidadMedida"));
					temp.setCondicionPago(rs.getString("condicionPago"));
					temp.setMoneda(rs.getString("moneda"));
					temp.setFechaProforma(rs.getInt("fechaProforma"));
					temp.setPaisOrigen(rs.getInt("paisOrigen"));
					temp.setNumeroDoc(rs.getString("noDocumento"));
					temp.setCartones(rs.getInt("cartones"));
					temp.setCantidadXCarton(rs.getInt("cantidadXCarton"));
					temp.setPesoNetoPKL(rs.getBigDecimal("pesoNeto"));
					temp.setPesoBrutoPKL(rs.getBigDecimal("PesoBruto"));
					temp.setCubicajePKL(rs.getBigDecimal("cubicaje"));
					temp.setPallet(rs.getInt("pallet"));
					temp.setCartonXPallet(rs.getInt("cartonXPallet"));
					temp.setPedidoDirecto(rs.getBoolean("esPedidoDirecto"));
					temp.setTieneDiferenciasMRP(rs.getBoolean("tieneDiferenciaMRP"));
					temp.setStatusMRP(rs.getInt("statusMRP"));
					temp.setTipoValidacionMRP(rs.getInt("tipoValidacionMRP"));
					temp.setTipoModificacion(rs.getInt("tipoModificacion"));
					temp.setNeedsAuthPlanningMgr(rs.getBoolean("needsAuthPlanningMgr"));
					temp.setFactorCantidadUnidadMedida(rs.getBigDecimal("factorCantidadUnidadMedida") == null ? BigDecimal.ONE:rs.getBigDecimal("factorCantidadUnidadMedida"));
					temp.setCantidadUnidadMedida(rs.getBigDecimal("cantidadUnidadMedida") == null ? new BigDecimal(rs.getInt("cantidadModificada")): rs.getBigDecimal("cantidadUnidadMedida"));
					respuesta.add(temp);
				}
			}
		}
	} catch (SQLException sqle) {
		log.error(sqle);
		ConexionDB.renovar(con);
	} catch (Exception e) {
		log.error(e);
	} finally {
		ConexionDB.devolver(con);
	}
	return respuesta;
}
	
	
	public List<SarDetalleBO> selectRevisadosOtros(int folio) {
		List<SarDetalleBO> respuesta = null;
		Connection con = null;
	try {
		con = ConexionDB.dameConexion();
		try (PreparedStatement pst = con.prepareStatement(SELECT_REVISADOS_OTROS)) {
			pst.setInt(1, folio);
			try (ResultSet rs = pst.executeQuery()) {
				respuesta = new ArrayList<>();
				SarDetalleBO temp = null;
				while (rs.next()) {
					temp = new SarDetalleBO();
					temp.setFolio(rs.getInt("folio"));
					temp.setPo(rs.getString("po"));
					temp.setPosicion(rs.getInt("posicion"));
					temp.setDescripcion(rs.getString("descripcion"));
					temp.setCantidad(rs.getInt("cantidad"));
					temp.setPesoProveedor(rs.getDouble("pesoProveedor"));
					temp.setVolumenProveedor(rs.getDouble("volumenProveedor"));
					temp.setCantidadModificada(rs.getInt("cantidadModificada"));
					temp.setPesoModificado(rs.getDouble("pesoModificado"));
					temp.setVolumenModificado(rs.getDouble("volumenModificado"));
					temp.setTipoModificacion(rs.getInt("tipoModificacion"));
					temp.setNeedsAuthPlanningMgr(rs.getBoolean("needsAuthPlanningMgr"));
					temp.setPoOtherItem(rs.getString("poOtherItemModificado"));
					BigDecimal precioUnitario = rs.getBigDecimal("precioUnitarioModificado");
					if(rs.wasNull()) {
						precioUnitario = null;
					}
					temp.setPrecioUnitario(precioUnitario);
					temp.setPoOtherItemCondicionPago(rs.getString("condicionPagoModificado"));
					temp.setUnidaMedida(rs.getString("unidadMedidaModificado"));
					respuesta.add(temp);
				}
			}
		}
	} catch (SQLException sqle) {
		log.error(sqle);
		ConexionDB.renovar(con);
	} catch (Exception e) {
		log.error(e);
	} finally {
		ConexionDB.devolver(con);
	}
	return respuesta;
}
	
	
	public void deleteDetalle(int folio, int po, int posicion,Connection con) throws Exception {
	Integer num_insert = null;
	try {
		StringBuilder sql = new StringBuilder();
		sql.append("DELETE FROM cdiSARDetalle WHERE folio = ? ");
		sql.append("AND po = ? ");
		sql.append("AND posicion = ? ");
		try (PreparedStatement pst = con.prepareStatement(sql.toString());) {
			int i = 1;
			pst.setInt(i++,folio );
			pst.setInt(i++, po);
			pst.setInt(i++, posicion);
			num_insert = pst.executeUpdate();
		}
		if(num_insert == null || num_insert == 0) {
			throw new SQLException("[deleteDetalle] No se ejecuto actualizacion favor de revisar.");
		}
	} catch (Exception e) {
		log.error("Informacion: folio: [{}], po:[{}],posicion:[{}]",folio,po,posicion, e);
		throw e;
	}
}
	
	public void deleteDetalleOtros(int folio, String po, int posicion,Connection con) throws Exception {
		Integer num_insert = null;
		try {
			StringBuilder sql = new StringBuilder();
			sql.append("DELETE FROM cdiSARDetalleOthers WHERE folio = ? ");
			sql.append("AND po = ? ");
			sql.append("AND posicion = ? ");
			try (PreparedStatement pst = con.prepareStatement(sql.toString());) {
				int i = 1;
				pst.setInt(i++,folio );
				pst.setString(i++, po.trim());
				pst.setInt(i++, posicion);
				num_insert = pst.executeUpdate();
				log.info("Borrado en cdiSARDetalleOthers, Folio: {}, PO: {}, Posicion: {}, Modificado: {}",folio,po.trim(),posicion,num_insert);
			}
			if(num_insert == null || num_insert == 0) {
				throw new SQLException("[deleteDetalleOtros] No se ejecuto actualizacion favor de revisar.");
			}
		} catch (Exception e) {
			log.error("Informacion: folio: [{}], po:[{}],posicion:[{}]",folio,po,posicion, e);
			throw e;
		}
	}
	
	
	public void addDetalle(SarDetalleBO det,Connection con) throws Exception {
		Integer num_insert = null;
		try {
			try (PreparedStatement pst = con.prepareStatement(ADD_DETALLE);) {
				int i = 1;
				pst.setInt(i++,det.getFolio() );
				pst.setString(i++, det.getPo());
				pst.setInt(i++, det.getPosicion());
				pst.setInt(i++, det.getMaterial());
				pst.setInt(i++, det.getCantidad());
				pst.setDouble(i++, det.getPesoProveedor());
				pst.setDouble(i++, det.getVolumenProveedor());
				pst.setString(i++, det.getCentro());
				pst.setBigDecimal(i++, det.getPrecioUnitario());
				pst.setString(i++, det.getPlaneador());
				pst.setString(i++, det.getCliente());
				pst.setInt(i++, det.getFechaProforma());
				pst.setString(i++, (det.getUnidaMedida() == null ? VACIO : det.getUnidaMedida()));
				pst.setString(i++, (det.getCondicionPago() == null ? VACIO : det.getCondicionPago()));
				pst.setString(i++, (det.getMoneda() == null ? VACIO : det.getMoneda()));
				pst.setInt(i++, (det.isPedidoDirecto() ? 1 : 0));
				pst.setInt(i++, (det.isTieneDiferenciasMRP() ? 1 : 0));
				if(det.isTieneDiferenciasMRP() ) {
					pst.setString(i++,  "3" );
				}else {
					pst.setNull(i++, Types.INTEGER);
				}
				
				pst.setDouble(i++, det.getFactorCantidadUnidadMedida().doubleValue());
				pst.setDouble(i++, det.getCantidadUnidadMedida().doubleValue());
				
				
				num_insert = pst.executeUpdate();
			}
			if(num_insert == null || num_insert == 0) {
				throw new SQLException("[deleteDetalle] No se ejecuto actualizacion favor de revisar.");
			}
		} catch (Exception e) {
			log.error("Informacion: folio: [{}], po:[{}],posicion:[{}]",det.getFolio(),det.getPo(),det.getPosicion(), e);
			throw e;
		}
	}
	
	
	public void addDetalleOthers(SarDetalleBO det,Connection con) throws Exception {
		Integer num_insert = null;
		try {
			StringBuilder sql = new StringBuilder();
			sql.append("INSERT INTO cdiSARDetalleOthers ");
			sql.append("            (folio ");
			sql.append("             , po ");
			sql.append("             , pootheritem ");
			sql.append("             , posicion ");
			sql.append("             , descripcion ");
			sql.append("             , cantidad ");
			sql.append("             , pesoproveedor ");
			sql.append("             , volumenproveedor ");
			sql.append("             , preciounitario ");
			sql.append("             , condicionPago ");
			sql.append("             , unidadMedida) ");
			sql.append(" VALUES      (? ,? ,? ,? ,? ,? ,? ,? ,? ,?, ?) ");
			
			try (PreparedStatement pst = con.prepareStatement(sql.toString());) {
				int i = 1;
				pst.setInt(i++,det.getFolio() );
				pst.setString(i++, det.getPo());
				String po_item = det.getPoOtherItem();
				if (UtilsString.isStringValida(po_item)) {
					pst.setString(i++, po_item);
				} else {
					pst.setNull(i++, Types.VARCHAR);
				}
				pst.setInt(i++, det.getPosicion());
				pst.setString(i++, det.getDescripcion());
				pst.setInt(i++, det.getCantidad());
				pst.setDouble(i++, det.getPesoProveedor());
				pst.setDouble(i++, det.getVolumenProveedor());
				BigDecimal precioUnitario = det.getPrecioUnitario();
				if( precioUnitario == null || precioUnitario.compareTo(BigDecimal.ZERO) != 1) {
					pst.setNull(i++, Types.DECIMAL);
				} else {
					pst.setBigDecimal(i++, precioUnitario);
				}
				
				String po_item_condicion_pago = det.getPoOtherItemCondicionPago();
				if (UtilsString.isStringValida(po_item_condicion_pago)) {
					pst.setString(i++, po_item_condicion_pago);	
				} else {
					pst.setNull(i++, Types.VARCHAR);
				}
				pst.setString(i++, det.getUnidaMedida());
				
				num_insert = pst.executeUpdate();
			}
			if(num_insert == null || num_insert == 0) {
				throw new SQLException("[addDetalleOthers] No se ejecuto actualizacion favor de revisar.");
			}
		} catch (Exception e) {
			log.error("Informacion: folio: [{}], po:[{}],posicion:[{}]",det.getFolio(),det.getPo(),det.getPosicion(), e);
			throw e;
		}
		
	}
	
	public void modifyDetalle(SarDetalleBO det,Connection con, boolean esDifMRP) throws Exception {
		Integer num_insert = null;
		try {
			StringBuilder sql = new StringBuilder();
			sql.append("UPDATE cdiSARDetalle SET cantidad = ?, ");
			sql.append("pesoProveedor = ?, volumenProveedor = ? , cantidadUnidadMedida = ? ");
			sql.append("WHERE folio = ? ");
			sql.append("AND po = ? ");
			sql.append("AND posicion = ? ");
			try (PreparedStatement pst = con.prepareStatement(sql.toString());) {
				int i = 1;
				int cantidad = det.getCantidadModificada() == null ? 0 : det.getCantidadModificada();
				double peso = det.getPesoModificado() == null ? 0D : det.getPesoModificado();				
				double volumen = det.getVolumenModificado() == null ? 0D : det.getVolumenModificado();
				BigDecimal precio = det.getPrecioUnitario() == null ? BigDecimal.ZERO : det.getPrecioUnitario();
					pst.setInt(i++,cantidad );
					pst.setDouble(i++,peso );
					pst.setDouble(i++,volumen);
					pst.setDouble(i++,det.getCantidadUnidadMedida().doubleValue());
					pst.setInt(i++, det.getFolio());
					pst.setString(i++, det.getPo());
					pst.setInt(i++, det.getPosicion());
				num_insert = pst.executeUpdate();
				log.info("Actualizacion: folio: [{}], po:[{}],posicion:[{}],cantidad:[{}] ,volumen:[{}] ,peso:[{}]",det.getFolio(),det.getPo(),
						det.getPosicion(),det.getCantidad(),det.getVolumenModificado(),det.getPesoModificado());
			}
			if(num_insert == null || num_insert == 0) {
				throw new SQLException("[deleteDetalle] No se ejecuto actualizacion favor de revisar.");
			}
		} catch (Exception e) {
			log.error("Informacion: folio: [{}], po:[{}],posicion:[{}]",det.getFolio(),det.getPo(),det.getPosicion(), e);
			throw e;
		}
	}
	
	public void modifyDetalleOtros(SarDetalleBO det,Connection con, boolean esDifMRP) throws Exception {
		Integer num_insert = null;
		try {
			StringBuilder sql = new StringBuilder();
			sql.append("UPDATE cdiSARDetalleOthers SET cantidad = ?, pesoProveedor = ?, volumenProveedor = ? ");
			sql.append("WHERE folio = ? AND po = ? AND posicion = ? ");
			try (PreparedStatement pst = con.prepareStatement(sql.toString());) {
				int i = 1;
				int cantidad = det.getCantidadModificada() == null ? 0 : det.getCantidadModificada();
				double peso = det.getPesoModificado() == null ? 0D : det.getPesoModificado();				
				double volumen = det.getVolumenModificado() == null ? 0D : det.getVolumenModificado();
				pst.setInt(i++, cantidad);
				pst.setDouble(i++, peso);
				pst.setDouble(i++, volumen);
				pst.setInt(i++, det.getFolio());
				pst.setString(i++, det.getPo());
				pst.setInt(i++, det.getPosicion());
				num_insert = pst.executeUpdate();
			}
			if(num_insert == null || num_insert == 0) {
				throw new SQLException("[deleteDetalle] No se ejecuto actualizacion favor de revisar.");
			}
		} catch (Exception e) {
			log.error("Informacion: folio: [{}], po:[{}],posicion:[{}]",det.getFolio(),det.getPo(),det.getPosicion(), e);
			throw e;
		}
	}
	
}