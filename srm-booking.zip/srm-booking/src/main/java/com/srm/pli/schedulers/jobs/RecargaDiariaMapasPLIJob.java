package com.srm.pli.schedulers.jobs;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import com.srm.pli.services.CdiNotificationServices;
import com.truper.infra.loggers.BaseLogger;

public class RecargaDiariaMapasPLIJob implements Job {
	private final CdiNotificationServices cdiNotifservice = CdiNotificationServices
			.getInstance();
	@Override
	public void execute(JobExecutionContext arg0) throws JobExecutionException {
		BaseLogger.SCHEDULER_LOGGER.info("Job RecargaDiariaMapasPLIJob Iniciando....");
		try {
			cdiNotifservice.recargaMapasPli();
		} catch (Exception e) {
			JobExecutionException e2 = new JobExecutionException (e);
			e2.setRefireImmediately (false); // para descartar el Job y seguir con el siguiente
			throw e2;
		} finally {
			BaseLogger.SCHEDULER_LOGGER.info("Job RecargaDiariaMapasPLIJob Finalizado.");
		}
	}

}
