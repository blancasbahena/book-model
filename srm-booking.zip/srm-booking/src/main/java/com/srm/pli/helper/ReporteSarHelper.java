package com.srm.pli.helper;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import com.srm.pli.bo.BeanSarConfirmacionFinal;
import com.srm.pli.bo.FasesSARBO;
import com.srm.pli.bo.SarBO;
import com.srm.pli.services.ContenedorService;
import com.srm.pli.utils.EstatusUtils;
import com.srm.pli.utils.FuncionesComunesPLI;
import com.srm.pli.utils.UnidadNegocioUtils;

/**
 * Clase encargada de proporcionar herramientas para la generaci�n de reportes
 * de sars.
 * 
 * @author rsantiagor
 *
 */
public class ReporteSarHelper {

	private static ReporteSarHelper instance = null;

	private static final String EMBARQUE_AEREO = "A";
	private static final String EMBARQUE_CONSOLIDADO = "C";
	private static final String EMBARQUE_FULL = "F";

	private ReporteSarHelper() {
	}

	public static ReporteSarHelper getInstance() {
		if (instance == null)
			instance = new ReporteSarHelper();
		return instance;
	}

	/**
	 * Completa la informaci�n de la lista
	 * 
	 * @param info
	 */
	public void completaInformacion(List<BeanSarConfirmacionFinal> info) {
		if (info == null || info.isEmpty())
			return;
		for (BeanSarConfirmacionFinal i : info) {
			Integer folio = i.getFolio();
			if (folio == null)
				continue;
			
			
			Integer status = i.getStatus();
			String tipoEmbarque = getTipoEmbarque(i);
			String comprador = UnidadNegocioUtils.getInstance().getCompradores(folio);
			String proveedor = i.getProveedor();
			String nombreProveedor = FuncionesComunesPLI.getNombreProveedor(proveedor);
			String puertoOrigen = i.getPuertoOrigen();
			String puertoOrigenDescripcion = PuertosHelper.getInstance().getNombrePuertoOrigen(puertoOrigen);
			Integer tipoContenedor = i.getTipoContenedor();
			String tipoContenedorDescripcion = ContenedorService.getInstance().getDescripcion(tipoContenedor);
			
			List<SarBO> foliosList = new ArrayList<>();
			SarBO bo = new SarBO();
			bo.setStatus(status);
			bo.setFolio(folio);
			if(i.getConsolidado()) {
				bo.setFolioConsolidado(folio);
			}
			foliosList.add(bo);
			
			
			Map<Integer, FasesSARBO> valores = EstatusUtils.datosAvanceSAR(foliosList, new Locale("es", "MX"), false);
			FasesSARBO avancesFolio = valores.get(folio);
			String statusDescripcion = avancesFolio.getLeyenda();
			
			i.setStatusDescripcion(statusDescripcion);
			i.setTipoEmbarque(tipoEmbarque);
			i.setComprador(comprador);
			i.setNombreProveedor(nombreProveedor);
			i.setPuertoOrigenDescripcion(puertoOrigenDescripcion);
			i.setTipoContenedorDescripcion(tipoContenedorDescripcion);
		}
	}

	/**
	 * Obtiene la leyenda en "es MX".
	 * 
	 * @param folio
	 * @param status
	 * @return String
	 */
	public String getLeyendaStatus(Integer folio, Integer status) {
		SarBO bean = new SarBO();
		bean.setFolio(folio);
		bean.setStatus(status);
		Locale locale = new Locale("es", "MX");
		String leyenda = bean.dameLeyendaStatus(locale);
		return leyenda;
	}

	/**
	 * Obtiene el tipo de embarque
	 * 
	 * @param bean
	 * @return String
	 *         <ul>
	 *         <li>{@value #EMBARQUE_AEREO} = Aereo</li>
	 *         <li>{@value #EMBARQUE_CONSOLIDADO} = Consolidado</li>
	 *         <li>{@value #EMBARQUE_FULL} = Full</li>
	 *         </ul>
	 */
	public String getTipoEmbarque(BeanSarConfirmacionFinal bean) {
		if (bean == null)
			return null;
		if (bean.getAereo() != null && bean.getAereo().booleanValue()) {
			return EMBARQUE_AEREO;
		}
		if (bean.getConsolidado() != null && bean.getConsolidado().booleanValue()) {
			return EMBARQUE_CONSOLIDADO;
		}
		return EMBARQUE_FULL;
	}
}
