package com.srm.pli.schedulers.jobs;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import com.srm.pli.utils.UtilsSDP;
import com.truper.infra.loggers.BaseLogger;

public class GeneraDatosSDP implements Job {
	private final UtilsSDP sdp = UtilsSDP.getInstance();
	@Override
	public void execute(JobExecutionContext arg0) throws JobExecutionException {
		BaseLogger.SCHEDULER_LOGGER.info("[GeneraDatosSDP] Inicia proceso de carga de datos SDP...");
		try {
			sdp.generaDatosSDP();
		} catch (Exception e) {
			JobExecutionException e2 = new JobExecutionException (e);
			e2.setRefireImmediately (false); // para descartar el Job y seguir con el siguiente
			throw e2;
		} finally {
			BaseLogger.SCHEDULER_LOGGER.info("[GeneraDatosSDP] Finalizo el proceso de carga de datos SDP");
		}
	}

}
