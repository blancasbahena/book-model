package com.srm.pli.services;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.srm.pli.bo.BeanFiltroAuditoria;
import com.srm.pli.bo.BeanFiltroAuditoriaVista;
import com.srm.pli.bo.jasperReports.BeanReporteControlPrecio;
import com.srm.pli.dao.AuditoriaDao;
import com.srm.pli.dao.SarDao;
import com.srm.pli.enums.HistoryLogAction;
import com.srm.pli.helper.AuditoriaHelper;
import com.truper.bpm.enums.EstatusAuditoriaEnum;
import com.truper.businessEntity.BeanAuditoria;
import com.truper.businessEntity.BeanAuditoriaMatriz;
import com.truper.businessEntity.BeanAuditoriaPpu;
import com.truper.businessEntity.BeanAuditoriaRechazado;
import com.truper.businessEntity.BeanAuditoriaSar;
import com.truper.businessEntity.BeanAuditoriaSarDetalle;
import com.truper.businessEntity.BeanAuditoriaSinMatriz;
import com.truper.businessEntity.BeanAuditoriaSinMatrizDetalle;
import com.truper.businessEntity.BeanAuditoriaSinMatrizDetalleProveedor;
import com.truper.businessEntity.BeanControlPrecios;
import com.truper.businessEntity.SAR;
import com.truper.businessEntity.UserBean;

public class AuditoriaService {

	private static final AuditoriaService instance = new AuditoriaService();
	private static final Logger LOGGER = LogManager.getRootLogger();

	private AuditoriaService() {
	}

	public static AuditoriaService getInstance() {
		return instance;
	}

	public List<BeanAuditoriaSinMatriz> getCabeceraOrdenesSinMatriz(BeanFiltroAuditoriaVista filtro) {
		List<BeanAuditoriaSinMatriz> resultado = AuditoriaDao.getInstance().selectCabeceraOrdenesSinMatriz(filtro);
		return resultado;
	}

	public List<BeanAuditoriaSinMatrizDetalle> getDetalleOrdenSinMatriz(BeanAuditoria param) {
		List<BeanAuditoriaSinMatrizDetalle> resultado = AuditoriaDao.getInstance().selectDetalleOrdenSinMatriz(param);
		return resultado;
	}

	public List<BeanAuditoriaSinMatrizDetalle> getDetalleOrdenSinMatrizReject(BeanAuditoria param) {
		List<BeanAuditoriaSinMatrizDetalle> resultado = AuditoriaDao.getInstance()
				.selectDetalleOrdenSinMatrizReject(param);
		return resultado;
	}

	public List<BeanAuditoriaSinMatrizDetalle> getDetalleOrdenConMatriz(BeanAuditoria param) {
		List<BeanAuditoriaSinMatrizDetalle> resultado = AuditoriaDao.getInstance().selectDetalleOrdenConMatriz(param);
		return resultado;
	}
	
	public List<BeanAuditoriaSinMatrizDetalleProveedor> getDetalleOrdenConMatriz(Date createDate, String po) {
		List<BeanAuditoriaSinMatrizDetalleProveedor> resultado = AuditoriaDao.getInstance().selectDetalleOrdenConMatrizFechaPo(createDate, po);
		return resultado;
	}

	public List<BeanAuditoriaRechazado> getCabecerasOrdenesRechazadas(BeanFiltroAuditoriaVista filtro) {
		List<BeanAuditoriaRechazado> resultado = AuditoriaDao.getInstance().selectCabecerasOrdenesRechazadas(filtro);
		return resultado;
	}

	public List<BeanAuditoriaPpu> getCabecerasOrdenesPPU(BeanFiltroAuditoriaVista filtro) {
		List<BeanAuditoriaPpu> resultado = AuditoriaDao.getInstance().selectCabecerasOrdenesPPU(filtro);
		return resultado;
	}

	public List<BeanAuditoriaSar> getCabecerasSAR(BeanFiltroAuditoriaVista filtro) {
		List<BeanAuditoriaSar> resultado = AuditoriaDao.getInstance().selectCabecerasSAR(filtro);
		return resultado;
	}

	public List<BeanAuditoriaSarDetalle> getDetalleSar(int folio) {
		List<BeanAuditoriaSarDetalle> resultado = AuditoriaDao.getInstance().selectDetalleSar(folio);
		return resultado;
	}

	public boolean liberaOrdenSinMatriz(BeanAuditoria param) {
		AuditoriaDao.getInstance().updateLiberaOrdenSinMatriz(param);
		return true;
	}

	public boolean liberaOrdenConMatriz(BeanAuditoriaMatriz param) {
		AuditoriaDao.getInstance().updateLiberaOrdenConMatriz(param);
		return true;
	}

	public boolean rechazaOrdenSinMatriz(BeanAuditoria param) {
		AuditoriaDao.getInstance().updateRechazaOrdenSinMatriz(param);
		CorreoAuditoria.getInstance().enviaRechazoPorAuditoria(param);
		return true;
	}

	public boolean actualizaSar(BeanFiltroAuditoria param, UserBean user) throws Exception {
		Integer folio = param.getFolio();
		Integer actualizados = AuditoriaDao.getInstance().updateSar(param);
		if (actualizados == null || actualizados.compareTo(Integer.valueOf(0)) != 1) {
			return false;
		}
		EstatusAuditoriaEnum estatus = param.getEstatus();
		liberaSarDesdeAuditoria(folio, estatus);
		String userName = user == null ? "null" : user.getUserName();
		HistoryLogServices.getInstance().registraAccion(folio, userName, HistoryLogAction.AUDIT_RELEASED_THE_PRICES);
		return true;
	}

	/**
	 * @param folio
	 * @param estatus
	 * @throws Exception
	 */
	public boolean liberaSarDesdeAuditoria(Integer folio, EstatusAuditoriaEnum estatus)
			throws Exception {
		if (EstatusAuditoriaEnum.RELEASED_PPU == estatus || EstatusAuditoriaEnum.RELEASED_REJECTED == estatus
				|| EstatusAuditoriaEnum.RELEASED_WITHOUT_AUDIT == estatus) {
			Integer estatus_folio = SarDao.getInstance().selectEstatusSAR(folio);
			if (estatus_folio == null) {
				LOGGER.error("liberaSarDesdeAuditoria @Error @" + estatus + " @Folio " + folio);
				throw new Exception("No se pudo obtener el estatus del folio: " + folio);
			} else if (estatus_folio.equals(SAR.STATUS_EN_REVISION_PRECIOS)) {
				PriceReleaseServices.getInstance().marcaSARLiberaHaciaPlaneacion(folio, estatus);
				LOGGER.info("liberaSarDesdeAuditoria > marcaSARLiberaHaciaPlaneacion @Success @" + estatus + " @Folio "
						+ folio);
			} else {
				PriceReleaseServices.getInstance().marcaSARLiberaHaciaConfirmacionFinal(folio, estatus);
				LOGGER.info("liberaSarDesdeAuditoria > marcaSARLiberaHaciaConfirmacionFinal @Success @" + estatus
						+ " @Folio " + folio);
			}
			CorreoServices.getInstance().enviaLiberacionPrecios(folio);
			return true;
		}
		LOGGER.warn("liberaSarDesdeAuditoria @Error @" + estatus + " @Folio " + folio);
		return false;
	}

	public boolean guardaNuevasOrdenes(HashSet<BeanControlPrecios> informacion) {
		AuditoriaDao.getInstance().upsertNuevasOrdenes(informacion);
		return false;
	}

	public int actualizaValorSimple(String tabla, String columna, Object valor, String columnaWhere, Object valorWhere)
			throws Exception {
		return AuditoriaDao.getInstance().actualizaValorSimple(tabla, columna, valor, columnaWhere, valorWhere);
	}

	public ArrayList<BeanReporteControlPrecio> getPosConPbPendientesDeLiberarMatriz() {
		ArrayList<BeanReporteControlPrecio> target = null;
		try {
			List<BeanAuditoriaPpu> origins = getCabecerasOrdenesPPU(null);
			target = AuditoriaHelper.getInstance().parseTo(origins);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return target;
	}

	public HashSet<BeanAuditoriaSinMatrizDetalle> getDetalles(ArrayList<BeanReporteControlPrecio> origins) {
		HashSet<BeanAuditoriaSinMatrizDetalle> detalles = new HashSet<>();
		for (BeanReporteControlPrecio i : origins) {
			BeanAuditoria param = new BeanAuditoria();
			param.setCreateDate(i.getCreateDate());
			param.setPo(i.getPo());
			param.setProveedor(i.getProveedor());
			detalles.addAll(getDetalleOrdenConMatriz(param));
		}
		return detalles;
	}
}
