package com.srm.pli.services;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.srm.pli.bo.SarBO;
import com.srm.pli.bo.SarDetalleBO;
import com.srm.pli.dao.SAR_CDI_DAO;
import com.srm.pli.helper.CorreoHelper;
import com.srm.pli.helper.FormatSAR;
import com.srm.pli.helper.FormatSARDetalle;
import com.srm.pli.utils.DateUtils;
import com.srm.pli.utils.FuncionesComunesPLI;
import com.srm.pli.utils.MailUtils;
import com.srm.pli.utils.PropertiesDb;
import com.srm.pli.utils.UtilsSarSQL;
import com.truper.businessEntity.UnidadNegocio;
import com.truper.businessEntity.UserBean;

import lombok.extern.log4j.Log4j2;

import static com.srm.pli.helper.CorreoHelper.MAIL_FR_HK_SYSTEM;

@Log4j2
public class CorreoContenedorService {

  private static CorreoContenedorService instance;
	private static final String MAILS_CONTAINER_SUPPLIER = "emails.container.supplier";

	private CorreoContenedorService() {
	}

	public static CorreoContenedorService getInstance() {
		if (instance == null)
			instance = new CorreoContenedorService();
		return instance;
	}
  
	public boolean enviaCorreosRecordatorios() throws Exception{
		boolean exito = false;
		//Construye fecha
		Calendar calToday = Calendar.getInstance();
		Calendar cal7 = Calendar.getInstance();
		Calendar cal5 = Calendar.getInstance();
		Calendar cal3 = Calendar.getInstance();
		cal7.set(Calendar.DATE, cal7.get(Calendar.DAY_OF_MONTH) + 7);
		cal5.set(Calendar.DATE, cal5.get(Calendar.DAY_OF_MONTH) + 5);
		cal3.set(Calendar.DATE, cal3.get(Calendar.DAY_OF_MONTH) + 3);
		Integer seven = DateUtils.getInstance().parseDateToInt(cal7.getTime());
		Integer five = DateUtils.getInstance().parseDateToInt(cal5.getTime());
		Integer trhe = DateUtils.getInstance().parseDateToInt(cal3.getTime());
		Integer today = DateUtils.getInstance().parseDateToInt(calToday.getTime());

		//Lista de folios de 7, 5 y 3 o menos dias antes de etd
		List<Integer> folioList = SAR_CDI_DAO.obtieneFoliosPendientesContenedor(seven, five, trhe, today);
		
		log.info("Lista de folios a los que se enviará correo: {}",folioList.toString());

		//Obtener todos los detalles por cada sar
		for(Integer folio: folioList){
			SarBO sar = UtilsSarSQL.getSar(String.valueOf(folio), false);
			//Agrega Detalle
			List<SarDetalleBO> lstDet = new ArrayList<>();
			boolean consolidado = (sar.getFolioConsolidado() != sar.getFolio()) ? false : true;
			if(consolidado){
				List<Integer> sarsEnCC = SAR_CDI_DAO.dameSARsEnCC(sar.getFolio());
				if (sarsEnCC != null && !sarsEnCC.isEmpty()) {
					for (Integer sarEnCC : sarsEnCC) {
						SarBO sarTmp = new SarBO();
						sarTmp.setFolio(sarEnCC);
						lstDet = FuncionesComunesPLI.getDetalleSAR(sarTmp) == null
								? new ArrayList<SarDetalleBO>()
								: FuncionesComunesPLI.getDetalleSAR(sarTmp);
					}
				} 
			}else{
				lstDet = FuncionesComunesPLI.getDetalleSAR(sar) == null
						? new ArrayList<SarDetalleBO>()
						: FuncionesComunesPLI.getDetalleSAR(sar);
			}
			List<SarDetalleBO> listaDetOtros = SAR_CDI_DAO.consultaDetalleOtros(String.valueOf(folio));
			sar.setDetalleBO(lstDet);
			sar.setDetalleOthers(listaDetOtros);

			FormatSAR formatSar = new FormatSAR(sar, null);
			log.info("Obteniendo correso del provedor del sar {}", sar.getFolio());
			Set<String> correos_proveedor = CorreoServices.getInstance().getCorreosProveedor(sar.getProveedor());
			Map<String, Object> datosMail = MailUtils.dameDatosDestinoMail(sar);
			log.info("Se obtuvieron crreos del proveedor y datos mail del sar {}", sar.getFolio());
			exito = enviaCorreoPorFolio(formatSar, correos_proveedor, datosMail);
		}
		return exito;
	}

	public boolean enviaCorreoPorFolio(FormatSAR formatSar, Set<String> correos_proveedor, Map<String, Object> datosMail){
		boolean exitoso = false;
		ArrayList<String> mailTo = new ArrayList<String>();
		log.info("Inicia envio de mail, recordatorio alta del sar {}", formatSar.getFolio());
		if(!correos_proveedor.isEmpty() && correos_proveedor != null)
				mailTo.addAll(correos_proveedor);

		Map<String, UnidadNegocio> uNegData = (Map<String, UnidadNegocio>) datosMail.get("bu");
		HashSet<String> uNegMail = new HashSet<String>();
		if (uNegData != null) {
			for (Map.Entry<String, UnidadNegocio> tmp : uNegData.entrySet()) {
				uNegMail.add(tmp.getValue().getMailContacto());
			}
			for (String correo : MailUtils.limpiaContactos(uNegMail)) {
				mailTo.add(correo);
			}
		}
		if(SarBO.MAIL_GRUPO_GERENTES_PLANNING != null)
		for (String tmp : SarBO.MAIL_GRUPO_GERENTES_PLANNING) {
			mailTo.add(tmp);
		}
		Map<String, UserBean> confirmadoresData = (Map<String, UserBean>) datosMail.get("confirmadores");
			if (confirmadoresData != null) {
				for (Map.Entry<String, UserBean> confirmador : confirmadoresData.entrySet()) {
					UserBean user = confirmador.getValue();
					if (user.getUserEmail() != null && !"".equals(user.getUserEmail())) {
						mailTo.add(user.getUserEmail());
					}
				}
			}
		String subject = "Confirm container pick up with carrier for shipment "+formatSar.getFolioVista()+" / Supplier "+formatSar.getProveedorClave();
		String body = construyeCuerpoCorreo(formatSar);
		String[] mailsTo = new String[mailTo.size()];
		mailsTo = mailTo.toArray(mailsTo);
		String sender = CorreoHelper.getInstance().getEmail(MAIL_FR_HK_SYSTEM);
		String[] mailsCC = PropertiesDb.getInstance().getStringArray(MAILS_CONTAINER_SUPPLIER);
		log.info("Se recolectaron todos los correos destino y copias correctamente del folio: {}", formatSar.getFolio());
		log.info("Los correos a los que se enviara el folio {}, son: TO: {}, CC: {}",
							formatSar.getFolioVista(), Arrays.toString(mailsTo), Arrays.toString(mailsCC));
		try {
			exitoso = MailUtils.enviaCorreo(mailsTo, mailsCC, subject, sender, body, null);
		} catch (Exception e) {
			log.error("Error al enviar correo", e);
		}
		if(exitoso)
			log.info("Se envío el correo exitosamente para el sar {}", formatSar.getFolio());
		return exitoso;
	}

	public String construyeCuerpoCorreo(FormatSAR formatSar){
		StringBuffer body = new StringBuffer();
		String etd = (formatSar.getEtdReal() != "-")? formatSar.getEtdReal(): formatSar.getFechaEmbarque();

		body.append("<html>");
		body.append("<head>");
		body.append("</head>");
		body.append("<body>");
		body.append("<style type='text/css'>");
		body.append("	.container {");
		body.append("		width: 100%;");
		body.append("		border-collapse: collapse;");
		body.append("	}");
		body.append("	.container td{");
		body.append("		border-width: 2px;");
		body.append("		border-style: solid;");
		body.append("		border-color: #2C9ADE;");
		body.append("	}");
		body.append("	.header {");
		body.append("		font-weight: bolder;");
		body.append("		background-color: #2C9ADE;");
		body.append("		color: white;");
		body.append("	}");
		body.append("</style>");
		body.append("	<br><b>Dear Vendor</b>");
		body.append("	      <br><b>").append(formatSar.getProveedor()).append("</b>");
		body.append("	<br><br>According to our records, you still not register the container # of the SAR folio listed below.");
		body.append("	<br><br>");
		body.append("	<table class = \"container\">");
		body.append("		<tbody>");
		body.append("			<tr>");
		body.append("	           <td class=\"header\" colspan=\"5\">Folio Number: ").append(formatSar.getFolioVista()).append("</td>");
		body.append("			</tr>");
		body.append("			<tr class = \"header\">");
		body.append("				<td>Item</td>");
		body.append("				<td>Code</td>");
		body.append("				<td>Description</td>");
		body.append("				<td>Qtv</td>");
		body.append("				<td>ETD</td>");
		body.append("			</tr>");

		for(FormatSARDetalle detalle: formatSar.getDetalle()){

			body.append("			<tr>");
			body.append("				<td>").append(detalle.getMaterial()).append("</td>");
			body.append("				<td>").append(detalle.getClave()).append("</td>");
			body.append("				<td>").append(detalle.getDescripcion()).append("</td>");
			body.append("				<td>").append(detalle.getCantidad()).append("</td>");
			body.append("				<td>").append(etd).append("</td>");
			body.append("			</tr>");

		}

		for(FormatSARDetalle otros: formatSar.getDetalleOthers()){
			body.append("			<tr>");
			body.append("				<td>").append(otros.getMaterial()).append("</td>");
			body.append("				<td>").append(otros.getClave()).append("</td>");
			body.append("				<td>").append(otros.getDescripcion()).append("</td>");
			body.append("				<td>").append(otros.getCantidad()).append("</td>");
			body.append("				<td>").append(etd).append("</td>");
			body.append("			</tr>");
		}

		body.append("		</tbody>");
		body.append("	</table>");
		body.append("		<br><br>Please confirm receipt of this message and that you have already registered, the Container # on the F&R Platform thru <b>SAR Status / Actions / Container Requested</b>");
		body.append("		<br><br>Looking forward to hearing from you soon.");
		body.append("		<br><br>Best Regards");
		body.append("	</body>");
		body.append("</html>");

		return body.toString();

	}
}
