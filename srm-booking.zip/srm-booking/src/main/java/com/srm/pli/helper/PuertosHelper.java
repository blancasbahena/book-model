package com.srm.pli.helper;

import com.srm.pli.services.PuertosService;
import com.srm.pli.utils.FuncionesComunesPLI;
import com.truper.businessEntity.BeanPuerto;
import com.truper.utils.string.UtilsString;

public class PuertosHelper {

	private static PuertosHelper instance = new PuertosHelper();

	private PuertosHelper() {
		FuncionesComunesPLI.cargaPuertosOrigen(false);
		FuncionesComunesPLI.cargaPuertosDestino(false);
	}

	public static PuertosHelper getInstance() {
		if (instance == null)
			instance = new PuertosHelper();
		return instance;
	}

	public String getNombrePuertoOrigen(String puertoOrigen) {
		if (!UtilsString.isStringValida(puertoOrigen))
			return null;
		BeanPuerto puerto = FuncionesComunesPLI.mapaPuertosOrigen.get(puertoOrigen);
		if (puerto == null)
			return null;
		return puerto.getNombre();
	}

	public String getNombrePuertoDestino(String puertoDestino, boolean tienePedidosDirectos) {
		String puerto;
		if (tienePedidosDirectos) {
			BeanPuerto ptoDirecto = PuertosService.getInstance().getPuertoDirecto(puertoDestino);
			if(ptoDirecto == null)
				return null;
			puerto = ptoDirecto == null ? null : ptoDirecto.getNombre();
		} else {
			puerto = FuncionesComunesPLI.mapaPuertosDestino == null || FuncionesComunesPLI.mapaPuertosDestino.get(puertoDestino) == null ? null
					: FuncionesComunesPLI.mapaPuertosDestino.get(puertoDestino).getNombre();
		}
		return puerto;
	}

}
