package com.srm.pli.bo;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class ClientePodBean {

	private Integer id;
	private String numeroOrden;
	private String clienteNumero;
	private String cliente;
	private String puertoId;
	private String puerto;
	private String paisId;
	private String pais;
	private Integer usuarioId;
	private String usuario;
	private Date createDate;
	private Integer usuarioUpdateId;
	private String usuarioUpdate;
	private Date updateDate;

}