package com.srm.pli.bo;

import java.util.Date;

public class BeanSarConfirmacionFinal {

	private Integer folio;
	private Integer status;
	private String statusDescripcion;
	private Boolean aereo;
	private Boolean consolidado;
	private String tipoEmbarque;
	private String folioConsolidado;
	private String confirmador;
	private String comprador;
	private String proveedor;
	private String nombreProveedor;
	private Date etd;
	private String puertoOrigen;
	private String puertoOrigenDescripcion;
	private Integer tipoContenedor;
	private String tipoContenedorDescripcion;
	private String numeroContenedorBooking;
	private String numeroContenedorProveedor;

	public Integer getFolio() {
		return folio;
	}

	public void setFolio(Integer folio) {
		this.folio = folio;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public String getStatusDescripcion() {
		return statusDescripcion;
	}

	public void setStatusDescripcion(String statusDescripcion) {
		this.statusDescripcion = statusDescripcion;
	}

	public Boolean getAereo() {
		return aereo;
	}

	public void setAereo(Boolean aereo) {
		this.aereo = aereo;
	}

	public Boolean getConsolidado() {
		return consolidado;
	}

	public void setConsolidado(Boolean consolidado) {
		this.consolidado = consolidado;
	}

	public String getTipoEmbarque() {
		return tipoEmbarque;
	}

	public void setTipoEmbarque(String tipoEmbarque) {
		this.tipoEmbarque = tipoEmbarque;
	}

	public String getFolioConsolidado() {
		return folioConsolidado;
	}

	public void setFolioConsolidado(String folioConsolidado) {
		this.folioConsolidado = folioConsolidado;
	}

	public String getConfirmador() {
		return confirmador;
	}

	public void setConfirmador(String confirmador) {
		this.confirmador = confirmador;
	}

	public String getComprador() {
		return comprador;
	}

	public void setComprador(String comprador) {
		this.comprador = comprador;
	}

	public String getProveedor() {
		return proveedor;
	}

	public void setProveedor(String proveedor) {
		this.proveedor = proveedor;
	}

	public String getNombreProveedor() {
		return nombreProveedor;
	}

	public void setNombreProveedor(String nombreProveedor) {
		this.nombreProveedor = nombreProveedor;
	}

	public Date getEtd() {
		return etd;
	}

	public void setEtd(Date etd) {
		this.etd = etd;
	}

	public String getPuertoOrigen() {
		return puertoOrigen;
	}

	public void setPuertoOrigen(String puertoOrigen) {
		this.puertoOrigen = puertoOrigen;
	}

	public String getPuertoOrigenDescripcion() {
		return puertoOrigenDescripcion;
	}

	public void setPuertoOrigenDescripcion(String puertoOrigenDescripcion) {
		this.puertoOrigenDescripcion = puertoOrigenDescripcion;
	}

	public Integer getTipoContenedor() {
		return tipoContenedor;
	}

	public void setTipoContenedor(Integer tipoContenedor) {
		this.tipoContenedor = tipoContenedor;
	}

	public String getTipoContenedorDescripcion() {
		return tipoContenedorDescripcion;
	}

	public void setTipoContenedorDescripcion(String tipoContenedorDescripcion) {
		this.tipoContenedorDescripcion = tipoContenedorDescripcion;
	}

	public String getNumeroContenedorBooking() {
		return numeroContenedorBooking;
	}

	public void setNumeroContenedorBooking(String numeroContenedorBooking) {
		this.numeroContenedorBooking = numeroContenedorBooking;
	}

	public String getNumeroContenedorProveedor() {
		return numeroContenedorProveedor;
	}

	public void setNumeroContenedorProveedor(String numeroContenedorProveedor) {
		this.numeroContenedorProveedor = numeroContenedorProveedor;
	}
}