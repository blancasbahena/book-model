package com.srm.pli.helper;

import java.math.BigDecimal;
import java.util.Optional;

import org.apache.commons.lang3.StringEscapeUtils;

import com.srm.pli.bo.SarBO;
import com.srm.pli.bo.SarDetalleBO;
import com.srm.pli.tags.IconosProductosTag;
import com.srm.pli.utils.FuncionesComunesPLI;
import com.truper.businessEntity.BeanPaisesOrigen;
import com.truper.businessEntity.PlaneadorBean;
import com.truper.businessEntity.ProductoBean;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@ToString
public class FormatSARDetalle {
	
	private Integer folio;
	private String po;
	private String poOtherItem;
	private boolean pagadero;
	private String centro;
	private Integer posicion;
	private Integer material;
	private String iconosTag;
	private String descripcion;
	private String descripcionENG;
	private String descripcionESP;
	private String descripcionReporte;
	private String clave;
	private String cantidad;
	private Integer cantidadSinFormato;
	private String pesoProveedor;
	private String pesoProveedorTn;
	private String volumenProveedor;
	private String cantidad100;
	private String peso100;
	private String volumen100;
	private String pesoSAP;
	private String volumenSAP;
	private Integer ida;
	private String backorder;
	private String backorderSinFormato;
	private String precioUnitario;
	private boolean diferenciaPreciosAFavor;
	private String diferenciaPrecios;
	private String fechaProforma;
	private String cantidadModificada;
	private String pesoModificado;
	private String volumenModificado;						
	private String paisOrigen;
	private String paisOrigenStr;
	private BigDecimal valorPartidaSinFormato;
	private String valorPartidaConFormato;
	private BigDecimal valorPartidaSinFormatoTT;
	private String valorPartidaConFormatoTT;
	private String unidadMedida;
	private String precioUnitarioTT;
	private String precioUnitarioPO;
	private String valorPartida;
	private boolean noEsPOCompleta;
	private int     cantidadTotalPO;
	private String difPesoUserVsSis;
	private String difPesoUserVsSisTn;
	private String varPesoUserVsSis;
	private String varPesoUserVsSisSinFormato;
	private String difVolUserVsSis;
	private String varVolUserVsSis;
	private String varVolUserVsSisSinFormato;
	private String overStock;
	private String diasAlArribo;
	private String picoInvDeseado;
	private String valorEmbarque;
	private String difDiasConfirm;
	private String familia;
	private String safetyStock;
	private String daysSafetyStock;
	private String var8Semanas;
	private String var8SemanasDirectos;
	private String facPedidosDirectos;
	private String difPIvsEtd;
	private String master;
	private boolean tieneDiferenciaMRP;
	private int statusMRP;
	private int tipoValidacionMRP;
	private String planeador;
	private String nombrePlaneador;
	private String forecastModel;
	private Integer tipoModificacionConfirmFinal;
	private String tienePedidoDirecto;
	private String cartones;
	private String pesoNetoPKL;
	private String cubicajePKL;
	private String pesoBrutoPKL;
	private String marca;
	private String totalLinea;
	private double totalXLineaSinFormato;
	private int cartonesEnSAP;
	private String almacen;
	private Integer daysAdvanced;
	private Integer daysDelayed;
	
	private String cantidadUnidadMedida;
	private Integer fabrica;
	private String procentajePicoInvDeseado;

	@Getter @Setter
	private boolean isSeasonal;
	@Getter @Setter
	private String totalVar12Semanas;
	@Getter @Setter
	private String totalVar8Semanas;
	@Getter @Setter
	private char abc;
	
	private String overStockPct;
	private String diasPO;
	
	private boolean eliminarProyeccion;
	private String commentDeleteProjection;
	
	public FormatSARDetalle(){}
	///Constructor que uso solo momentaneamente hasta ver como vamos a tratar los otros en los documentos
	public FormatSARDetalle(SarDetalleBO otro){
		folio = otro.getFolio();
		po = otro.getPo();
		cantidadSinFormato = otro.getCantidad();
		cantidad = (otro.getCantidadUnidadMedida()+"");
		clave = ("");
		marca = ("");
		material = (otro.getMaterial() != null ? otro.getMaterial() : 0);
		descripcionReporte = (otro.getDescripcion());
		precioUnitario  = (otro.getPrecioUnitario()+"");
		totalLinea = ("0");
		unidadMedida =  (otro.getUnidaMedida() != null ? otro.getUnidaMedida() : "" );
		pesoBrutoPKL = otro.getPesoBrutoPKL() != null ? FuncionesComunesPLI.formatea(otro.getPesoBrutoPKL().doubleValue(), 2) : "";
		pesoNetoPKL = otro.getPesoNetoPKL() != null ? FuncionesComunesPLI.formatea(otro.getPesoNetoPKL().doubleValue(), 2) : "";
		cubicajePKL = otro.getCubicajePKL() != null ? FuncionesComunesPLI.formatea(otro.getCubicajePKL().doubleValue(), 2) : "";
		cartones = otro.getCartones() != null ? otro.getCartones()+"" : "";
		poOtherItem = otro.getPoOtherItem();
		pagadero = PriceReleaseHelper.getInstance().isOtherItemWithPago(po);
	}
	
	public FormatSARDetalle(SarDetalleBO detalle,int etd) {
		ProductoBean p = FuncionesComunesPLI.productos.get(detalle.getMaterial().toString());
		
		folio = detalle.getFolio();
		po= detalle.getPo();
		poOtherItem = detalle.getPoOtherItem();
		pagadero = PriceReleaseHelper.getInstance().isOtherItemWithPago(po);
		centro= detalle.getCentro();
		posicion = detalle.getPosicion();
		material = detalle.getMaterial();
		setTienePedidoDirecto(detalle.isPedidoDirecto() ? "1" : "0");
		IconosProductosTag ipt = new IconosProductosTag(String.valueOf(material), detalle.isPedidoDirecto(),etd, detalle.getAlmacen(), detalle.isMegaAltaVolumetria());
		iconosTag  = ipt.doTagString();
		cantidad = FuncionesComunesPLI.formatea(detalle.getCantidad());
		cantidadUnidadMedida = FuncionesComunesPLI.formatea((detalle.getCantidadUnidadMedida() == null || detalle.getCantidadUnidadMedida().compareTo(BigDecimal.ZERO)== 0)?detalle.getCantidad():Integer.valueOf(detalle.getCantidadUnidadMedida().intValue()));
		cantidadSinFormato  = detalle.getCantidad();
		cartones = detalle.getCartones()+"";
		pesoNetoPKL = detalle.getPesoNetoPKL() != null ? FuncionesComunesPLI.formatea(detalle.getPesoNetoPKL().doubleValue(), 3) : "N.D";
		cubicajePKL = detalle.getCubicajePKL() != null ? FuncionesComunesPLI.formatea(detalle.getCubicajePKL().doubleValue(), 3) : "N.D";
		pesoBrutoPKL = detalle.getPesoBrutoPKL() != null ? FuncionesComunesPLI.formatea(detalle.getPesoBrutoPKL().doubleValue(), 3) : "N.D";
		marca = p != null ? p.getMarcaComercial() : "";
		totalXLineaSinFormato =   detalle.getPrecioUnitario().multiply(new BigDecimal(detalle.getCantidad())).doubleValue();
		totalLinea  = FuncionesComunesPLI.formatea(totalXLineaSinFormato, 6);
		pesoProveedor = FuncionesComunesPLI.formatea(detalle.getPesoProveedor(), 0);
		pesoProveedorTn = FuncionesComunesPLI.formatea(detalle.getPesoProveedor()/1000, 2);
		volumenProveedor = FuncionesComunesPLI.formatea(detalle.getVolumenProveedor(), 2,false);
		double iPesoSAP = FuncionesComunesPLI.calculaPesoParaCantidad(detalle.getCantidad(), detalle.getMaterial()+"");
		pesoSAP = FuncionesComunesPLI.formatea(iPesoSAP, 0);
		double iVolumenSAP = FuncionesComunesPLI.calculaVolumenParaCantidad(detalle.getCantidad(), detalle.getMaterial()+"");
		volumenSAP = FuncionesComunesPLI.formatea(iVolumenSAP, 2);
		ida = detalle.getInventaroAlArribo()==null ? 0 : detalle.getInventaroAlArribo();
		
		if(detalle.isEliminarProyeccion()) {
			backorder = "$0";
		} else {
			backorder = detalle.getBackorderPronosticado() != null ?  "$" + FuncionesComunesPLI.formatea(detalle.getBackorderPronosticado().doubleValue(),0) : "$0.0";
		}
		
		backorderSinFormato = detalle.getBackorderPronosticado() != null ?  FuncionesComunesPLI.formatea(detalle.getBackorderPronosticado().doubleValue(),0,false) : "$0.0";
		precioUnitario = detalle.getPrecioUnitario() == null ? "-" : String.valueOf(detalle.getPrecioUnitario());
		planeador = detalle.getPlaneador() == null ? "-" : detalle.getPlaneador();
		PlaneadorBean plannerBean = FuncionesComunesPLI.planners.get(planeador);
		nombrePlaneador = plannerBean == null ? "-" : StringEscapeUtils.escapeHtml3(plannerBean.getNombre());
		diferenciaPreciosAFavor = detalle.esDiferenciaPreciosAFavor();
		diferenciaPrecios = FuncionesComunesPLI.formatea(detalle.getPrecioUnitarioPO().subtract(detalle.getPrecioUnitario()).doubleValue(), 1, false);
		fechaProforma = detalle.getFechaProforma() == null ? "-" : FuncionesComunesPLI.formateaFecha(detalle.getFechaProforma());
		cantidadModificada = detalle.getCantidadModificada() != null ? FuncionesComunesPLI.formatea(detalle.getCantidadModificada()) : "-";
		pesoModificado = detalle.getPesoModificado() != null ? FuncionesComunesPLI.formatea(detalle.getPesoModificado(), 0) : "-";
		volumenModificado = detalle.getVolumenModificado() != null ? FuncionesComunesPLI.formatea(detalle.getVolumenModificado(), 2) : "-";						
		cantidad100 = detalle.getCantidad100() != null ? FuncionesComunesPLI.formatea(detalle.getCantidad100()) : "-";
		peso100 = detalle.getPeso100() != null ? FuncionesComunesPLI.formatea(detalle.getPeso100(), 0) : "-";
		volumen100 = detalle.getVolumen100() != null ? FuncionesComunesPLI.formatea(detalle.getVolumen100(), 2) : "-";						
		paisOrigen = detalle.getPaisOrigen() != null ? String.valueOf(detalle.getPaisOrigen()) : "-1";
		paisOrigenStr = paisOrigen != null ? BeanPaisesOrigen.mapaPaisesOrigen.get(paisOrigen) : "";
		noEsPOCompleta = detalle.isNoEsPOCompleta();
		cantidadTotalPO = detalle.getCantidadTotalPO();
		difPesoUserVsSis = detalle.getDifPesoUserVSSistem() == null ? "N.D." : FuncionesComunesPLI.formatea(detalle.getDifPesoUserVSSistem().doubleValue(),0);
		difPesoUserVsSisTn = detalle.getDifPesoUserVSSistem() == null ? "N.D." : FuncionesComunesPLI.formatea(detalle.getDifPesoUserVSSistem().doubleValue()/1000,2);
		double varPeso = iPesoSAP == 0.0 ? 0.0 : ((iPesoSAP / detalle.getPesoProveedor())-1D)*100D;
		varPesoUserVsSis = FuncionesComunesPLI.formatea(varPeso,2);
		varPesoUserVsSisSinFormato = FuncionesComunesPLI.formatea(varPeso,2,false);
		difVolUserVsSis = detalle.getDifVolumenUserVSSistem() == null ? "N.D." : FuncionesComunesPLI.formatea(detalle.getDifVolumenUserVSSistem().doubleValue(),2,false);
		double varVol = iVolumenSAP == 0.0 ? 0.0 : ((iVolumenSAP / detalle.getVolumenProveedor())-1D)*100D;
		varVolUserVsSis = FuncionesComunesPLI.formatea(varVol,2);
		varVolUserVsSisSinFormato = FuncionesComunesPLI.formatea(varVol,2,false);
		overStock = detalle.getOverStock() == null ? "N.D." : FuncionesComunesPLI.formatea(detalle.getOverStock(),0);
		diasAlArribo = detalle.getDiasAlArribo() == null ? "N/D" : FuncionesComunesPLI.formatea(detalle.getDiasAlArribo(),0);
		picoInvDeseado = detalle.getPicoInventarioDeseado() == null ? "N.D." : FuncionesComunesPLI.formatea(detalle.getPicoInventarioDeseado(),0);
		Double diasAlArriboDouble= detalle.getDiasAlArribo() !=null?Double.parseDouble(detalle.getDiasAlArribo().toString()):0.0;
		Double picoInvDeseadoDouble= detalle.getPicoInventarioDeseado() !=null?Double.parseDouble(detalle.getPicoInventarioDeseado().toString()):0.0;
		if (picoInvDeseadoDouble>0) {
			Double total= ((diasAlArriboDouble-picoInvDeseadoDouble)/picoInvDeseadoDouble)*100;
			procentajePicoInvDeseado =  FuncionesComunesPLI.formatea(total,2,false);
		}else {
			procentajePicoInvDeseado= "0";
		}
		
		difDiasConfirm = detalle.getDifDiasConfirm() == null ? "N.D." : detalle.getDifDiasConfirm().compareTo(FuncionesComunesPLI.CERO) == 0 ? "N.D." : FuncionesComunesPLI.formateaFecha(detalle.getDifDiasConfirm().intValue());
		safetyStock = detalle.getSafetyStock() == null ? "N.D" : FuncionesComunesPLI.formatea(detalle.getSafetyStock(),0);
		daysSafetyStock = detalle.getDaysSafetyStock() == null ? "N.D" : FuncionesComunesPLI.formatea(detalle.getDaysSafetyStock(),0);
		var8Semanas = detalle.getVar8Semanas() == null ? "N.D" : FuncionesComunesPLI.formatea(detalle.getVar8Semanas(),0);
		var8SemanasDirectos = detalle.getVar8SemanasDirectos() == null ? "N.D" : FuncionesComunesPLI.formatea(detalle.getVar8SemanasDirectos(),0);
		facPedidosDirectos = detalle.getFacturacionPedidosDirectos() == null ? "N.D" : FuncionesComunesPLI.formatea(detalle.getFacturacionPedidosDirectos(),0);
		forecastModel = detalle.getTipoPron() == null ? "N.D." : detalle.getTipoPron();
		///aqui calculo otro precioUnitario para la factura
		BigDecimal valPartidaTT = FuncionesComunesPLI.CERO;
		tieneDiferenciaMRP = detalle.isTieneDiferenciasMRP();
		if (detalle.isTieneDiferenciasMRP()) {
			statusMRP = detalle.getStatusMRP() == null ? 3 : detalle.getStatusMRP();
			tipoValidacionMRP = detalle.getTipoValidacionMRP() == null ? 0 : detalle.getTipoValidacionMRP();
		}
		difPIvsEtd = detalle.getDifDiasPIvsETD() == null ? "N.D" : FuncionesComunesPLI.formatea(detalle.getDifDiasPIvsETD(),0);
		tipoModificacionConfirmFinal = detalle.getTipoModificacion() == null ? 0 : detalle.getTipoModificacion();
		
		if(p != null){
			descripcion = StringEscapeUtils.escapeHtml3(p.getDescripcion());
			descripcionENG = StringEscapeUtils.escapeHtml3(p.getDescription());
			descripcionReporte = p.getDescripcion();
			clave = p.getClave();
			BigDecimal valPartida = new BigDecimal(SarBO.getCostoFOB(String.valueOf(detalle.getMaterial())) * (detalle.getCantidad()));
			valorPartidaSinFormato = valPartida.setScale(2, BigDecimal.ROUND_HALF_EVEN);
			valorPartidaConFormato = FuncionesComunesPLI.formatea(valPartida.doubleValue(),2);
			valorEmbarque = valorPartidaConFormato;
			valPartidaTT = new BigDecimal(Double.parseDouble(precioUnitario) * detalle.getCantidad());
			valorPartidaSinFormatoTT = valPartidaTT.setScale(5, BigDecimal.ROUND_HALF_EVEN);
			valorPartidaConFormatoTT = FuncionesComunesPLI.formatea(valPartidaTT.doubleValue(),2);
			unidadMedida = detalle.getUnidaMedida() != null ? detalle.getUnidaMedida() : "N.D"; 
			//XXX ojo el precioUnitario ya lo tengo en la PO
			precioUnitarioTT = FuncionesComunesPLI.formatea(Double.parseDouble(precioUnitario),5);
			precioUnitarioPO = FuncionesComunesPLI.formatea(SarBO.getCostoFOB(String.valueOf(detalle.getMaterial())),5);
			familia = p.getFamilia() == null ? "N.D" : p.getFamilia();
			master = p.getMaster()  == 0  ? "1" : p.getMaster()+"";
			isSeasonal = p.isSeasonal();
			totalVar12Semanas = p.getTotalVar12Semanas();
			totalVar8Semanas = p.getTotalVar8Semanas();
			
			if(!p.isMateriaPrima()) {
				abc = Optional.ofNullable(p.getProductoCentro()).map(productoCentro -> productoCentro.get("P5")).map(p5 -> p5.getAbc()).orElse(' ');
			} else if(p.isMateriaPrima()) {
				abc = Optional.ofNullable(p.getProductoCentro())
						.map(productoCentro -> productoCentro.get(detalle.getCentro())).map(clas -> clas.getAbc()).orElse(' ');
			}
			
		}else{
			descripcion = detalle.getDescripcion() != null && !"".equals(detalle.getDescripcion()) ? detalle.getDescripcion() : "";
			clave = "N.D";
			valorPartida = "ND";
			valorPartidaConFormato = "ND";
			unidadMedida = detalle.getUnidaMedida() != null ? detalle.getUnidaMedida() : "";
			valorEmbarque = "0";
			marca = "";
			material = 0;
			isSeasonal = false;
			totalVar12Semanas = "ND";
			totalVar8Semanas = "ND";
			abc = ' ';
		}
		
		almacen = detalle.getAlmacen();
		fabrica = detalle.getFabrica();
		
		eliminarProyeccion = detalle.isEliminarProyeccion();
		commentDeleteProjection = detalle.getCommentDeleteProjection()  == null ? "" : detalle.getCommentDeleteProjection();
		
		daysAdvanced = detalle.getDaysAdvanced();
		daysDelayed = detalle.getDaysDelayed();

	}
	
	public FormatSARDetalle(SarDetalleBO detalle,int etd, Double valorTotalEmbarque) {
		ProductoBean p = FuncionesComunesPLI.productos.get(detalle.getMaterial().toString());
		
		folio = detalle.getFolio();
		po= detalle.getPo();
		poOtherItem = detalle.getPoOtherItem();
		pagadero = PriceReleaseHelper.getInstance().isOtherItemWithPago(po);
		centro= detalle.getCentro();
		posicion = detalle.getPosicion();
		material = detalle.getMaterial();
		setTienePedidoDirecto(detalle.isPedidoDirecto() ? "1" : "0");
		IconosProductosTag ipt = new IconosProductosTag(String.valueOf(material), detalle.isPedidoDirecto(),etd, detalle.getAlmacen(), detalle.isMegaAltaVolumetria());
		iconosTag  = ipt.doTagString();
		cantidad = FuncionesComunesPLI.formatea(detalle.getCantidad());
		cantidadUnidadMedida = FuncionesComunesPLI.formatea((detalle.getCantidadUnidadMedida() == null || detalle.getCantidadUnidadMedida().compareTo(BigDecimal.ZERO)== 0)?detalle.getCantidad():Integer.valueOf(detalle.getCantidadUnidadMedida().intValue()));
		cantidadSinFormato  = detalle.getCantidad();
		cartones = detalle.getCartones()+"";
		pesoNetoPKL = detalle.getPesoNetoPKL() != null ? FuncionesComunesPLI.formatea(detalle.getPesoNetoPKL().doubleValue(), 3) : "N.D";
		cubicajePKL = detalle.getCubicajePKL() != null ? FuncionesComunesPLI.formatea(detalle.getCubicajePKL().doubleValue(), 3) : "N.D";
		pesoBrutoPKL = detalle.getPesoBrutoPKL() != null ? FuncionesComunesPLI.formatea(detalle.getPesoBrutoPKL().doubleValue(), 3) : "N.D";
		marca = p != null ? p.getMarcaComercial() : "";
		totalXLineaSinFormato =   detalle.getPrecioUnitario().multiply(new BigDecimal(detalle.getCantidad())).doubleValue();
		totalLinea  = FuncionesComunesPLI.formatea(totalXLineaSinFormato, 6);
		pesoProveedor = FuncionesComunesPLI.formatea(detalle.getPesoProveedor(), 0);
		pesoProveedorTn = FuncionesComunesPLI.formatea(detalle.getPesoProveedor()/1000, 2);
		volumenProveedor = FuncionesComunesPLI.formatea(detalle.getVolumenProveedor(), 2,false);
		double iPesoSAP = FuncionesComunesPLI.calculaPesoParaCantidad(detalle.getCantidad(), detalle.getMaterial()+"");
		pesoSAP = FuncionesComunesPLI.formatea(iPesoSAP, 0);
		double iVolumenSAP = FuncionesComunesPLI.calculaVolumenParaCantidad(detalle.getCantidad(), detalle.getMaterial()+"");
		volumenSAP = FuncionesComunesPLI.formatea(iVolumenSAP, 2);
		ida = detalle.getInventaroAlArribo()==null ? 0 : detalle.getInventaroAlArribo();
		
		if(detalle.isEliminarProyeccion()) {
			backorder = "$0";
		} else {
			backorder = detalle.getBackorderPronosticado() != null ?  "$" + FuncionesComunesPLI.formatea(detalle.getBackorderPronosticado().doubleValue(),0) : "$0.0";
		}
		
		backorderSinFormato = detalle.getBackorderPronosticado() != null ?  FuncionesComunesPLI.formatea(detalle.getBackorderPronosticado().doubleValue(),0,false) : "$0.0";
		precioUnitario = detalle.getPrecioUnitario() == null ? "-" : String.valueOf(detalle.getPrecioUnitario());
		planeador = detalle.getPlaneador() == null ? "-" : detalle.getPlaneador();
		PlaneadorBean plannerBean = FuncionesComunesPLI.planners.get(planeador);
		nombrePlaneador = plannerBean == null ? "-" : StringEscapeUtils.escapeHtml3(plannerBean.getNombre());
		diferenciaPreciosAFavor = detalle.esDiferenciaPreciosAFavor();
		diferenciaPrecios = FuncionesComunesPLI.formatea(detalle.getPrecioUnitarioPO().subtract(detalle.getPrecioUnitario()).doubleValue(), 1, false);
		fechaProforma = detalle.getFechaProforma() == null ? "-" : FuncionesComunesPLI.formateaFecha(detalle.getFechaProforma());
		cantidadModificada = detalle.getCantidadModificada() != null ? FuncionesComunesPLI.formatea(detalle.getCantidadModificada()) : "-";
		pesoModificado = detalle.getPesoModificado() != null ? FuncionesComunesPLI.formatea(detalle.getPesoModificado(), 0) : "-";
		volumenModificado = detalle.getVolumenModificado() != null ? FuncionesComunesPLI.formatea(detalle.getVolumenModificado(), 2) : "-";						
		cantidad100 = detalle.getCantidad100() != null ? FuncionesComunesPLI.formatea(detalle.getCantidad100()) : "-";
		peso100 = detalle.getPeso100() != null ? FuncionesComunesPLI.formatea(detalle.getPeso100(), 0) : "-";
		volumen100 = detalle.getVolumen100() != null ? FuncionesComunesPLI.formatea(detalle.getVolumen100(), 2) : "-";						
		paisOrigen = detalle.getPaisOrigen() != null ? String.valueOf(detalle.getPaisOrigen()) : "-1";
		paisOrigenStr = paisOrigen != null ? BeanPaisesOrigen.mapaPaisesOrigen.get(paisOrigen) : "";
		noEsPOCompleta = detalle.isNoEsPOCompleta();
		cantidadTotalPO = detalle.getCantidadTotalPO();
		difPesoUserVsSis = detalle.getDifPesoUserVSSistem() == null ? "N.D." : FuncionesComunesPLI.formatea(detalle.getDifPesoUserVSSistem().doubleValue(),0);
		difPesoUserVsSisTn = detalle.getDifPesoUserVSSistem() == null ? "N.D." : FuncionesComunesPLI.formatea(detalle.getDifPesoUserVSSistem().doubleValue()/1000,2);
		double varPeso = iPesoSAP == 0.0 ? 0.0 : ((iPesoSAP / detalle.getPesoProveedor())-1D)*100D;
		varPesoUserVsSis = FuncionesComunesPLI.formatea(varPeso,2);
		varPesoUserVsSisSinFormato = FuncionesComunesPLI.formatea(varPeso,2,false);
		difVolUserVsSis = detalle.getDifVolumenUserVSSistem() == null ? "N.D." : FuncionesComunesPLI.formatea(detalle.getDifVolumenUserVSSistem().doubleValue(),2,false);
		double varVol = iVolumenSAP == 0.0 ? 0.0 : ((iVolumenSAP / detalle.getVolumenProveedor())-1D)*100D;
		varVolUserVsSis = FuncionesComunesPLI.formatea(varVol,2);
		varVolUserVsSisSinFormato = FuncionesComunesPLI.formatea(varVol,2,false);
		overStock = detalle.getOverStock() == null ? "N.D." : FuncionesComunesPLI.formatea(detalle.getOverStock(),0);
		diasAlArribo = detalle.getDiasAlArribo() == null ? "N/D" : FuncionesComunesPLI.formatea(detalle.getDiasAlArribo(),0);
		picoInvDeseado = detalle.getPicoInventarioDeseado() == null ? "N.D." : FuncionesComunesPLI.formatea(detalle.getPicoInventarioDeseado(),0);
		Double diasAlArriboDouble= detalle.getDiasAlArribo() !=null?Double.parseDouble(detalle.getDiasAlArribo().toString()):0.0;
		Double picoInvDeseadoDouble= detalle.getPicoInventarioDeseado() !=null?Double.parseDouble(detalle.getPicoInventarioDeseado().toString()):0.0;
		if (picoInvDeseadoDouble>0) {
			Double total= ((diasAlArriboDouble-picoInvDeseadoDouble)/picoInvDeseadoDouble)*100;
			procentajePicoInvDeseado =  FuncionesComunesPLI.formatea(total,2,false);
		}else {
			procentajePicoInvDeseado= "0";
		}
		
		overStockPct = detalle.getOverStock() == null ? "N.D." : FuncionesComunesPLI.formatea((detalle.getOverStock()/valorTotalEmbarque)*100,2)+" %";
		diasPO = detalle.getDiasPO()== null ? "N.D." : FuncionesComunesPLI.formatea(detalle.getDiasPO(),0);
		difDiasConfirm = detalle.getDifDiasConfirm() == null ? "N.D." : detalle.getDifDiasConfirm().compareTo(FuncionesComunesPLI.CERO) == 0 ? "N.D." : FuncionesComunesPLI.formateaFecha(detalle.getDifDiasConfirm().intValue());
		safetyStock = detalle.getSafetyStock() == null ? "N.D" : FuncionesComunesPLI.formatea(detalle.getSafetyStock(),0);
		daysSafetyStock = detalle.getDaysSafetyStock() == null ? "N.D" : FuncionesComunesPLI.formatea(detalle.getDaysSafetyStock(),0);
		var8Semanas = detalle.getVar8Semanas() == null ? "N.D" : FuncionesComunesPLI.formatea(detalle.getVar8Semanas(),0);
		var8SemanasDirectos = detalle.getVar8SemanasDirectos() == null ? "N.D" : FuncionesComunesPLI.formatea(detalle.getVar8SemanasDirectos(),0);
		facPedidosDirectos = detalle.getFacturacionPedidosDirectos() == null ? "N.D" : FuncionesComunesPLI.formatea(detalle.getFacturacionPedidosDirectos(),0);
		forecastModel = detalle.getTipoPron() == null ? "N.D." : detalle.getTipoPron();
		///aqui calculo otro precioUnitario para la factura
		BigDecimal valPartidaTT = FuncionesComunesPLI.CERO;
		tieneDiferenciaMRP = detalle.isTieneDiferenciasMRP();
		if (detalle.isTieneDiferenciasMRP()) {
			statusMRP = detalle.getStatusMRP() == null ? 3 : detalle.getStatusMRP();
			tipoValidacionMRP = detalle.getTipoValidacionMRP() == null ? 0 : detalle.getTipoValidacionMRP();
		}
		difPIvsEtd = detalle.getDifDiasPIvsETD() == null ? "N.D" : FuncionesComunesPLI.formatea(detalle.getDifDiasPIvsETD(),0);
		tipoModificacionConfirmFinal = detalle.getTipoModificacion() == null ? 0 : detalle.getTipoModificacion();
		
		if(p != null){
			descripcion = StringEscapeUtils.escapeHtml3(p.getDescripcion());
			descripcionENG = StringEscapeUtils.escapeHtml3(p.getDescription());
			descripcionReporte = p.getDescripcion();
			clave = p.getClave();
			BigDecimal valPartida = new BigDecimal(SarBO.getCostoFOB(String.valueOf(detalle.getMaterial())) * (detalle.getCantidad()));
			valorPartidaSinFormato = valPartida.setScale(2, BigDecimal.ROUND_HALF_EVEN);
			valorPartidaConFormato = FuncionesComunesPLI.formatea(valPartida.doubleValue(),2);
			valorEmbarque = valorPartidaConFormato;
			valPartidaTT = new BigDecimal(Double.parseDouble(precioUnitario) * detalle.getCantidad());
			valorPartidaSinFormatoTT = valPartidaTT.setScale(5, BigDecimal.ROUND_HALF_EVEN);
			valorPartidaConFormatoTT = FuncionesComunesPLI.formatea(valPartidaTT.doubleValue(),2);
			unidadMedida = detalle.getUnidaMedida() != null ? detalle.getUnidaMedida() : "N.D"; 
			//XXX ojo el precioUnitario ya lo tengo en la PO
			precioUnitarioTT = FuncionesComunesPLI.formatea(Double.parseDouble(precioUnitario),5);
			precioUnitarioPO = FuncionesComunesPLI.formatea(SarBO.getCostoFOB(String.valueOf(detalle.getMaterial())),5);
			familia = p.getFamilia() == null ? "N.D" : p.getFamilia();
			master = p.getMaster()  == 0  ? "1" : p.getMaster()+"";  
			isSeasonal = p.isSeasonal();
			totalVar12Semanas = p.getTotalVar12Semanas();
			totalVar8Semanas = p.getTotalVar8Semanas();
			
			if(!p.isMateriaPrima()) {
				abc = Optional.ofNullable(p.getProductoCentro()).map(productoCentro -> productoCentro.get("P5")).map(p5 -> p5.getAbc()).orElse(' ');
			} else if(p.isMateriaPrima()) {
				abc = Optional.ofNullable(p.getProductoCentro())
						.map(productoCentro -> productoCentro.get(detalle.getCentro())).map(clas -> clas.getAbc()).orElse(' ');
			}
			
			
		}else{
			descripcion = detalle.getDescripcion() != null && !"".equals(detalle.getDescripcion()) ? detalle.getDescripcion() : "";
			clave = "N.D";
			valorPartida = "ND";
			valorPartidaConFormato = "ND";
			unidadMedida = detalle.getUnidaMedida() != null ? detalle.getUnidaMedida() : "";
			valorEmbarque = "0";
			marca = "";
			material = 0;
			isSeasonal = false;
			totalVar12Semanas = "ND";
			totalVar8Semanas = "ND";
			abc = ' ';
		}
		
		almacen = detalle.getAlmacen();
		fabrica = detalle.getFabrica();
		
		eliminarProyeccion = detalle.isEliminarProyeccion();
		commentDeleteProjection = detalle.getCommentDeleteProjection()  == null ? "" : detalle.getCommentDeleteProjection();
		
		daysAdvanced = detalle.getDaysAdvanced();
		daysDelayed = detalle.getDaysDelayed();

	}
	
	
	/**
	 * @return the folio
	 */
	public Integer getFolio() {
		return folio;
	}

	/**
	 * @param folio the folio to set
	 */
	public void setFolio(Integer folio) {
		this.folio = folio;
	}

	/**
	 * @return the po
	 */
	public String getPo() {
		return po;
	}

	/**
	 * @param po the po to set
	 */
	public void setPo(String po) {
		this.po = po;
	}

	public String getPoOtherItem() {
		return poOtherItem;
	}

	public void setPoOtherItem(String poOtherItem) {
		this.poOtherItem = poOtherItem;
	}
	
	public boolean isPagadero() {
		return pagadero;
	}
	public void setPagadero(boolean pagadero) {
		this.pagadero = pagadero;
	}
	/**
	 * @return the centro
	 */
	public String getCentro() {
		return centro;
	}

	/**
	 * @param centro the centro to set
	 */
	public void setCentro(String centro) {
		this.centro = centro;
	}

	/**
	 * @return the posicion
	 */
	public Integer getPosicion() {
		return posicion;
	}

	/**
	 * @param posicion the posicion to set
	 */
	public void setPosicion(Integer posicion) {
		this.posicion = posicion;
	}

	/**
	 * @return the material
	 */
	public Integer getMaterial() {
		return material;
	}

	/**
	 * @param material the material to set
	 */
	public void setMaterial(Integer material) {
		this.material = material;
	}

	/**
	 * @return the iconosTag
	 */
	public String getIconosTag() {
		return iconosTag;
	}

	/**
	 * @param iconosTag the iconosTag to set
	 */
	public void setIconosTag(String iconosTag) {
		this.iconosTag = iconosTag;
	}

	/**
	 * @return the descripcion
	 */
	public String getDescripcion() {
		return descripcion;
	}

	/**
	 * @param descripcion the descripcion to set
	 */
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public String getDescripcionENG() {
		return descripcionENG;
	}

	public void setDescripcionENG(String descripcionENG) {
		this.descripcionENG = descripcionENG;
	}

	/**
	 * @return the descripcionESP
	 */
	public String getDescripcionESP() {
		return descripcionESP;
	}

	/**
	 * @param descripcionESP the descripcionESP to set
	 */
	public void setDescripcionESP(String descripcionESP) {
		this.descripcionESP = descripcionESP;
	}

	/**
	 * @return the clave
	 */
	public String getClave() {
		return clave;
	}

	/**
	 * @param clave the clave to set
	 */
	public void setClave(String clave) {
		this.clave = clave;
	}

	/**
	 * @return the cantidad
	 */
	public String getCantidad() {
		return cantidad;
	}

	/**
	 * @param cantidad the cantidad to set
	 */
	public void setCantidad(String cantidad) {
		this.cantidad = cantidad;
	}

	/**
	 * @return the pesoProveedor
	 */
	public String getPesoProveedor() {
		return pesoProveedor;
	}

	/**
	 * @param pesoProveedor the pesoProveedor to set
	 */
	public void setPesoProveedor(String pesoProveedor) {
		this.pesoProveedor = pesoProveedor;
	}

	/**
	 * @return the volumenProveedor
	 */
	public String getVolumenProveedor() {
		return volumenProveedor;
	}

	/**
	 * @param volumenProveedor the volumenProveedor to set
	 */
	public void setVolumenProveedor(String volumenProveedor) {
		this.volumenProveedor = volumenProveedor;
	}

	public String getPesoSAP() {
		return pesoSAP;
	}

	public void setPesoSAP(String pesoSAP) {
		this.pesoSAP = pesoSAP;
	}

	public String getVolumenSAP() {
		return volumenSAP;
	}

	public void setVolumenSAP(String volumenSAP) {
		this.volumenSAP = volumenSAP;
	}

	/**
	 * @return the ida
	 */
	public Integer getIda() {
		return ida;
	}

	/**
	 * @param ida the ida to set
	 */
	public void setIda(Integer ida) {
		this.ida = ida;
	}

	/**
	 * @return the backorder
	 */
	public String getBackorder() {
		return backorder;
	}

	/**
	 * @param backorder the backorder to set
	 */
	public void setBackorder(String backorder) {
		this.backorder = backorder;
	}

	public String getBackorderSinFormato() {
		return backorderSinFormato;
	}

	public void setBackorderSinFormato(String backorderSinFormato) {
		this.backorderSinFormato = backorderSinFormato;
	}

	/**
	 * @return the precioUnitario
	 */
	public String getPrecioUnitario() {
		return precioUnitario;
	}

	/**
	 * @param precioUnitario the precioUnitario to set
	 */
	public void setPrecioUnitario(String precioUnitario) {
		this.precioUnitario = precioUnitario;
	}

	/**
	 * @return the diferenciaPreciosAFavor
	 */
	public boolean isDiferenciaPreciosAFavor() {
		return diferenciaPreciosAFavor;
	}

	/**
	 * @param diferenciaPreciosAFavor the diferenciaPreciosAFavor to set
	 */
	public void setDiferenciaPreciosAFavor(boolean diferenciaPreciosAFavor) {
		this.diferenciaPreciosAFavor = diferenciaPreciosAFavor;
	}

	/**
	 * @return the diferenciaPrecios
	 */
	public String getDiferenciaPrecios() {
		return diferenciaPrecios;
	}

	/**
	 * @param diferenciaPrecios the diferenciaPrecios to set
	 */
	public void setDiferenciaPrecios(String diferenciaPrecios) {
		this.diferenciaPrecios = diferenciaPrecios;
	}

	/**
	 * @return the fechaProforma
	 */
	public String getFechaProforma() {
		return fechaProforma;
	}

	/**
	 * @param fechaProforma the fechaProforma to set
	 */
	public void setFechaProforma(String fechaProforma) {
		this.fechaProforma = fechaProforma;
	}

	/**
	 * @return the cantidadModificada
	 */
	public String getCantidadModificada() {
		return cantidadModificada;
	}

	/**
	 * @param cantidadModificada the cantidadModificada to set
	 */
	public void setCantidadModificada(String cantidadModificada) {
		this.cantidadModificada = cantidadModificada;
	}

	/**
	 * @return the pesoModificado
	 */
	public String getPesoModificado() {
		return pesoModificado;
	}

	/**
	 * @param pesoModificado the pesoModificado to set
	 */
	public void setPesoModificado(String pesoModificado) {
		this.pesoModificado = pesoModificado;
	}

	/**
	 * @return the volumenModificado
	 */
	public String getVolumenModificado() {
		return volumenModificado;
	}

	/**
	 * @param volumenModificado the volumenModificado to set
	 */
	public void setVolumenModificado(String volumenModificado) {
		this.volumenModificado = volumenModificado;
	}

	public String getCantidad100() {
		return cantidad100;
	}

	public void setCantidad100(String cantidad100) {
		this.cantidad100 = cantidad100;
	}

	public String getPeso100() {
		return peso100;
	}

	public void setPeso100(String peso100) {
		this.peso100 = peso100;
	}

	public String getVolumen100() {
		return volumen100;
	}

	public void setVolumen100(String volumen100) {
		this.volumen100 = volumen100;
	}

	/**
	 * @return the paisOrigen
	 */
	public String getPaisOrigen() {
		return paisOrigen;
	}

	/**
	 * @param paisOrigen the paisOrigen to set
	 */
	public void setPaisOrigen(String paisOrigen) {
		this.paisOrigen = paisOrigen;
	}

	/**
	 * @return the paisOrigenStr
	 */
	public String getPaisOrigenStr() {
		return paisOrigenStr;
	}

	/**
	 * @param paisOrigenStr the paisOrigenStr to set
	 */
	public void setPaisOrigenStr(String paisOrigenStr) {
		this.paisOrigenStr = paisOrigenStr;
	}

	/**
	 * @return the valorPartidaSinFormato
	 */
	public BigDecimal getValorPartidaSinFormato() {
		return valorPartidaSinFormato;
	}

	/**
	 * @param valorPartidaSinFormato the valorPartidaSinFormato to set
	 */
	public void setValorPartidaSinFormato(BigDecimal valorPartidaSinFormato) {
		this.valorPartidaSinFormato = valorPartidaSinFormato;
	}

	/**
	 * @return the valorPartidaConFormato
	 */
	public String getValorPartidaConFormato() {
		return valorPartidaConFormato;
	}

	/**
	 * @param valorPartidaConFormato the valorPartidaConFormato to set
	 */
	public void setValorPartidaConFormato(String valorPartidaConFormato) {
		this.valorPartidaConFormato = valorPartidaConFormato;
	}

	/**
	 * @return the valorPartidaSinFormatoTT
	 */
	public BigDecimal getValorPartidaSinFormatoTT() {
		return valorPartidaSinFormatoTT;
	}

	/**
	 * @param valorPartidaSinFormatoTT the valorPartidaSinFormatoTT to set
	 */
	public void setValorPartidaSinFormatoTT(BigDecimal valorPartidaSinFormatoTT) {
		this.valorPartidaSinFormatoTT = valorPartidaSinFormatoTT;
	}

	/**
	 * @return the valorPartidaConFormatoTT
	 */
	public String getValorPartidaConFormatoTT() {
		return valorPartidaConFormatoTT;
	}

	/**
	 * @param valorPartidaConFormatoTT the valorPartidaConFormatoTT to set
	 */
	public void setValorPartidaConFormatoTT(String valorPartidaConFormatoTT) {
		this.valorPartidaConFormatoTT = valorPartidaConFormatoTT;
	}

	/**
	 * @return the unidadMedida
	 */
	public String getUnidadMedida() {
		return unidadMedida;
	}

	/**
	 * @param unidadMedida the unidadMedida to set
	 */
	public void setUnidadMedida(String unidadMedida) {
		this.unidadMedida = unidadMedida;
	}

	/**
	 * @return the precioUnitarioTT
	 */
	public String getPrecioUnitarioTT() {
		return precioUnitarioTT;
	}

	/**
	 * @param precioUnitarioTT the precioUnitarioTT to set
	 */
	public void setPrecioUnitarioTT(String precioUnitarioTT) {
		this.precioUnitarioTT = precioUnitarioTT;
	}

	/**
	 * @return the precioUnitarioPO
	 */
	public String getPrecioUnitarioPO() {
		return precioUnitarioPO;
	}

	/**
	 * @param precioUnitarioPO the precioUnitarioPO to set
	 */
	public void setPrecioUnitarioPO(String precioUnitarioPO) {
		this.precioUnitarioPO = precioUnitarioPO;
	}

	/**
	 * @return the valorPartida
	 */
	public String getValorPartida() {
		return valorPartida;
	}

	/**
	 * @param valorPartida the valorPartida to set
	 */
	public void setValorPartida(String valorPartida) {
		this.valorPartida = valorPartida;
	}

	public boolean isNoEsPOCompleta() {
		return noEsPOCompleta;
	}

	public void setNoEsPOCompleta(boolean noEsPOCompleta) {
		this.noEsPOCompleta = noEsPOCompleta;
	}

	public int getCantidadTotalPO() {
		return cantidadTotalPO;
	}

	public void setCantidadTotalPO(int cantidadTotalPO) {
		this.cantidadTotalPO = cantidadTotalPO;
	}

	public Integer getCantidadSinFormato() {
		return cantidadSinFormato;
	}

	public void setCantidadSinFormato(Integer cantidadSinFormato) {
		this.cantidadSinFormato = cantidadSinFormato;
	}

	/**
	 * @return the difPesoUserVsSis
	 */
	public String getDifPesoUserVsSis() {
		return difPesoUserVsSis;
	}

	/**
	 * @param difPesoUserVsSis the difPesoUserVsSis to set
	 */
	public void setDifPesoUserVsSis(String difPesoUserVsSis) {
		this.difPesoUserVsSis = difPesoUserVsSis;
	}

	/**
	 * @return the difVolUserVsSis
	 */
	public String getDifVolUserVsSis() {
		return difVolUserVsSis;
	}

	/**
	 * @param difVolUserVsSis the difVolUserVsSis to set
	 */
	public void setDifVolUserVsSis(String difVolUserVsSis) {
		this.difVolUserVsSis = difVolUserVsSis;
	}

	/**
	 * @return the overStock
	 */
	public String getOverStock() {
		return overStock;
	}

	/**
	 * @param overStock the overStock to set
	 */
	public void setOverStock(String overStock) {
		this.overStock = overStock;
	}

	/**
	 * @return the diasAlArribo
	 */
	public String getDiasAlArribo() {
		return diasAlArribo;
	}

	/**
	 * @param diasAlArribo the diasAlArribo to set
	 */
	public void setDiasAlArribo(String diasAlArribo) {
		this.diasAlArribo = diasAlArribo;
	}

	/**
	 * @return the picoInvDeseado
	 */
	public String getPicoInvDeseado() {
		return picoInvDeseado;
	}

	/**
	 * @param picoInvDeseado the picoInvDeseado to set
	 */
	public void setPicoInvDeseado(String picoInvDeseado) {
		this.picoInvDeseado = picoInvDeseado;
	}

	/**
	 * @return the valorEmbarque
	 */
	public String getValorEmbarque() {
		return valorEmbarque;
	}

	/**
	 * @param valorEmbarque the valorEmbarque to set
	 */
	public void setValorEmbarque(String valorEmbarque) {
		this.valorEmbarque = valorEmbarque;
	}

	/**
	 * @return the difDiasConfirm
	 */
	public String getDifDiasConfirm() {
		return difDiasConfirm;
	}

	/**
	 * @param difDiasConfirm the difDiasConfirm to set
	 */
	public void setDifDiasConfirm(String difDiasConfirm) {
		this.difDiasConfirm = difDiasConfirm;
	}

	/**
	 * @return the familia
	 */
	public String getFamilia() {
		return familia;
	}

	/**
	 * @param familia the familia to set
	 */
	public void setFamilia(String familia) {
		this.familia = familia;
	}

	/**
	 * @return the varPesoUserVsSis
	 */
	public String getVarPesoUserVsSis() {
		return varPesoUserVsSis;
	}

	/**
	 * @param varPesoUserVsSis the varPesoUserVsSis to set
	 */
	public void setVarPesoUserVsSis(String varPesoUserVsSis) {
		this.varPesoUserVsSis = varPesoUserVsSis;
	}

	/**
	 * @return the varVolUserVsSis
	 */
	public String getVarVolUserVsSis() {
		return varVolUserVsSis;
	}

	/**
	 * @param varVolUserVsSis the varVolUserVsSis to set
	 */
	public void setVarVolUserVsSis(String varVolUserVsSis) {
		this.varVolUserVsSis = varVolUserVsSis;
	}

	/**
	 * @return the safetyStock
	 */
	public String getSafetyStock() {
		return safetyStock;
	}

	/**
	 * @param safetyStock the safetyStock to set
	 */
	public void setSafetyStock(String safetyStock) {
		this.safetyStock = safetyStock;
	}

	/**
	 * @return the daysSafetyStock
	 */
	public String getDaysSafetyStock() {
		return daysSafetyStock;
	}

	/**
	 * @param daysSafetyStock the daysSafetyStock to set
	 */
	public void setDaysSafetyStock(String daysSafetyStock) {
		this.daysSafetyStock = daysSafetyStock;
	}

	/**
	 * @return the var8Semanas
	 */
	public String getVar8Semanas() {
		return var8Semanas;
	}

	/**
	 * @param var8Semanas the var8Semanas to set
	 */
	public void setVar8Semanas(String var8Semanas) {
		this.var8Semanas = var8Semanas;
	}

	public String getVar8SemanasDirectos() {
		return var8SemanasDirectos;
	}

	public void setVar8SemanasDirectos(String var8SemanasDirectos) {
		this.var8SemanasDirectos = var8SemanasDirectos;
	}

	public String getFacPedidosDirectos() {
		return facPedidosDirectos;
	}

	public void setFacPedidosDirectos(String facPedidosDirectos) {
		this.facPedidosDirectos = facPedidosDirectos;
	}

	/**
	 * @return the difPIvsEtd
	 */
	public String getDifPIvsEtd() {
		return difPIvsEtd;
	}

	/**
	 * @param difPIvsEtd the difPIvsEtd to set
	 */
	public void setDifPIvsEtd(String difPIvsEtd) {
		this.difPIvsEtd = difPIvsEtd;
	}

	public String getMaster() {
		return master;
	}

	public void setMaster(String master) {
		this.master = master;
	}

	/**
	 * @return the planeador
	 */
	public String getPlaneador() {
		return planeador;
	}

	/**
	 * @param planeador the planeador to set
	 */
	public void setPlaneador(String planeador) {
		this.planeador = planeador;
	}

	public String getForecastModel() {
		return forecastModel;
	}

	public void setForecastModel(String forecastModel) {
		this.forecastModel = forecastModel;
	}

	public int getStatusMRP() {
		return statusMRP;
	}

	public void setStatusMRP(int statusMRP) {
		this.statusMRP = statusMRP;
	}

	/**
	 * @return the tipoValidacionMRP
	 */
	public int getTipoValidacionMRP() {
		return tipoValidacionMRP;
	}

	/**
	 * @param tipoValidacionMRP the tipoValidacionMRP to set
	 */
	public void setTipoValidacionMRP(int tipoValidacionMRP) {
		this.tipoValidacionMRP = tipoValidacionMRP;
	}

	public String getNombrePlaneador() {
		return nombrePlaneador;
	}

	public void setNombrePlaneador(String nombrePlaneador) {
		this.nombrePlaneador = nombrePlaneador;
	}

	public Integer getTipoModificacionConfirmFinal() {
		return tipoModificacionConfirmFinal;
	}

	public void setTipoModificacionConfirmFinal(Integer tipoModificacionConfirmFinal) {
		this.tipoModificacionConfirmFinal = tipoModificacionConfirmFinal;
	}

	public String getTienePedidoDirecto() {
		return tienePedidoDirecto;
	}

	public void setTienePedidoDirecto(String tienePedidoDirecto) {
		this.tienePedidoDirecto = tienePedidoDirecto;
	}

	public String getCartones() {
		return cartones;
	}

	public void setCartones(String cartones) {
		this.cartones = cartones;
	}

	public String getPesoNetoPKL() {
		return pesoNetoPKL;
	}

	public void setPesoNetoPKL(String pesoNetoPKL) {
		this.pesoNetoPKL = pesoNetoPKL;
	}

	public String getCubicajePKL() {
		return cubicajePKL;
	}

	public void setCubicajePKL(String cubicajePKL) {
		this.cubicajePKL = cubicajePKL;
	}

	public String getPesoBrutoPKL() {
		return pesoBrutoPKL;
	}

	public void setPesoBrutoPKL(String pesoBrutoPKL) {
		this.pesoBrutoPKL = pesoBrutoPKL;
	}

	public String getMarca() {
		return marca;
	}

	public void setMarca(String marca) {
		this.marca = marca;
	}

	public String getDescripcionReporte() {
		return descripcionReporte;
	}

	public void setDescripcionReporte(String descripcionReporte) {
		this.descripcionReporte = descripcionReporte;
	}

	public String getTotalLinea() {
		return totalLinea;
	}

	public void setTotalLinea(String totalLinea) {
		this.totalLinea = totalLinea;
	}

	public double getTotalXLineaSinFormato() {
		return totalXLineaSinFormato;
	}

	public void setTotalXLineaSinFormato(double totalXLineaSinFormato) {
		this.totalXLineaSinFormato = totalXLineaSinFormato;
	}
	public int getCartonesEnSAP() {
		return cartonesEnSAP;
	}
	public void setCartonesEnSAP(int cartonesEnSAP) {
		this.cartonesEnSAP = cartonesEnSAP;
	}
	public String getAlmacen() {
		return almacen;
	}
	public void setAlmacen(String almacen) {
		this.almacen = almacen;
	}
	public String getCantidadUnidadMedida() {
		return cantidadUnidadMedida;
	}
	public void setCantidadUnidadMedida(String cantidadUnidadMedida) {
		this.cantidadUnidadMedida = cantidadUnidadMedida;
	}
	
	public Integer getFabrica() {
		return fabrica;
	}
	public void setFabrica(Integer fabrica) {
		this.fabrica = fabrica;
	}
	public String getProcentajePicoInvDeseado() {
		return procentajePicoInvDeseado;
	}
	public void setProcentajePicoInvDeseado(String procentajePicoInvDeseado) {
		this.procentajePicoInvDeseado = procentajePicoInvDeseado;
	}
	public String getOverStockPct() {
		return overStockPct;
	}
	public void setOverStockPct(String overStockPct) {
		this.overStockPct = overStockPct;
	}
	public Integer getDaysAdvanced() {
		return daysAdvanced;
	}
	public void setDaysAdvanced(Integer daysAdvanced) {
		this.daysAdvanced = daysAdvanced;
	}
	public Integer getDaysDelayed() {
		return daysDelayed;
	}
	public void setDaysDelayed(Integer daysDelayed) {
		this.daysDelayed = daysDelayed;
	}	
	
	
}
