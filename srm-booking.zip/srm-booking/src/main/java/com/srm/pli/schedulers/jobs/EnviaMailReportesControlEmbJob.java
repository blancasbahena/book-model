package com.srm.pli.schedulers.jobs;

import java.io.IOException;
import java.sql.SQLException;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import com.srm.pli.services.GeneraReportesContEmb;
import com.srm.pli.services.impl.GeneraReportesContEmbImpl;

import lombok.extern.log4j.Log4j2;

@Log4j2
public class EnviaMailReportesControlEmbJob implements Job {
	
	private final GeneraReportesContEmb generaReportesContEmb = GeneraReportesContEmbImpl.getInstance();

	@Override
	public void execute(JobExecutionContext context) throws JobExecutionException {
		log.info(":::::::::: Ejecutando envio de correos de control de embarque ::::::::::");
		System.out.println(":::::::::: Ejecutando envio de correos de control de embarque ::::::::::");
		
		try {
			generaReportesContEmb.enviaReportePendientes();
		} catch (SQLException | IOException e) {
			log.error("EnviaMailReportesControlEmbJob error:", e);
		}
		
	}

}
