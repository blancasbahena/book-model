package com.srm.pli.documents;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashSet;
import java.util.Set;

import com.srm.pli.db.ConexionDB;

import lombok.extern.log4j.Log4j2;

@Log4j2
public class BloqueoDocumentosDao {

	private static BloqueoDocumentosDao instance = null;

	private BloqueoDocumentosDao() {
	}

	public static BloqueoDocumentosDao getInstance() {
		if (instance == null)
			instance = new BloqueoDocumentosDao();
		return instance;
	}

	public boolean insertBloqueoDocumentos(Integer folio) {
		if (folio == null) {
			return false;
		}
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();
			String query = "INSERT INTO cdiBloqueoDocumentos (folio) VALUES (?)";
			try (PreparedStatement pst = con.prepareStatement(query)) {
				pst.setInt(1, folio);
				int cambios = pst.executeUpdate();
				if (cambios > 0)
					return true;
			}
		} catch (SQLException sqle) {
			log.error("bloqueaDocumentos | {}", folio, sqle);
		} catch (Exception e) {
			log.error("bloqueaDocumentos | {}", folio, e);
		} finally {
			ConexionDB.devolver(con);
		}
		return false;
	}

	public Integer selectBloqueoDocumentos(Integer folio) {
		if (folio == null) {
			return null;
		}
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();
			String query = "SELECT folio FROM cdiBloqueoDocumentos WITH (NOLOCK) WHERE folio = ?";
			try (PreparedStatement pst = con.prepareStatement(query)) {
				pst.setInt(1, folio);
				try (ResultSet rs = pst.executeQuery()) {
					if (rs.next()) {
						int _folio = rs.getInt("folio");
						if (rs.wasNull())
							return null;
						return _folio;
					}
				}
			}
		} catch (SQLException sqle) {
			log.error("selectBloqueoDocumentos | {}", folio, sqle);
		} catch (Exception e) {
			log.error("selectBloqueoDocumentos | {}", folio, e);
		} finally {
			ConexionDB.devolver(con);
		}
		return null;
	}
	
	public Set<Integer> selectBloqueoDocumentos() {
		Set<Integer> foliosBloqueados = null;
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();
			String query = "SELECT folio FROM cdiBloqueoDocumentos";
			try (Statement st = con.createStatement()) {
				try (ResultSet rs = st.executeQuery(query)) {
					foliosBloqueados = new HashSet<>();
					while (rs.next()) {
						int _folio = rs.getInt("folio");
						if (rs.wasNull())
							continue;
						foliosBloqueados.add(_folio);
					}
				}
			}
		} catch (SQLException sqle) {
			log.error("selectBloqueoDocumentos", sqle);
		} catch (Exception e) {
			log.error("selectBloqueoDocumentos", e);
		} finally {
			ConexionDB.devolver(con);
		}
		return foliosBloqueados;
	}

	public boolean deleteBloqueoDocumentos(Integer folio) {
		if (folio == null) {
			return false;
		}
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();
			String query = "DELETE cdiBloqueoDocumentos WHERE folio = ?";
			try (PreparedStatement pst = con.prepareStatement(query)) {
				pst.setInt(1, folio);
				int cambios = pst.executeUpdate();
				if (cambios > 0)
					return true;
			}
		} catch (SQLException sqle) {
			log.error("eliminaBloqueoDocumentos | {}", folio, sqle);
		} catch (Exception e) {
			log.error("eliminaBloqueoDocumentos | {}", folio, e);
		} finally {
			ConexionDB.devolver(con);
		}
		return false;
	}
}
