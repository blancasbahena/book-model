package com.srm.pli.dao;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.srm.pli.bo.SarDetalleBO;
import com.srm.pli.db.ConexionDB;
import com.srm.pli.helper.RoundingHelper;

public class SARsDetalleEnRevisionDAO extends DAO {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2456461656659276094L;

	@Override
	public List<?> select(Object o) {
		SarDetalleBO det = (SarDetalleBO)o;
		List<SarDetalleBO> lstSarDetallesModificados = new ArrayList<SarDetalleBO>();

		Connection con = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		DAOUtils utils = new  DAOUtils();		

		StringBuilder select = new StringBuilder("SELECT folio, po, posicion, material, centro, cantidad, pesoProveedor, volumenProveedor,");
		select.append(" precioUnitario, planeador, cantidadModificada, pesoModificado, volumenModificado, cliente, unidadMedida, condicionPago,");
		select.append(" moneda, fechaProforma, paisOrigen, noDocumento, cartones, cantidadXCarton, pesoNeto, PesoBruto, cubicaje, pallet,");
		select.append(" cartonXPallet, esPedidoDirecto, tieneDiferenciaMRP, statusMRP, tipoValidacionMRP, tipoModificacion, needsAuthPlanningMgr, ");
		select.append(" almacen , factorCantidadUnidadMedida , cantidadUnidadMedida ");
		select.append(" FROM cdiSarDetalleEnRevision ");
		select.append(" WHERE 1=1");
		
		utils.setSelect(true);

		try {
			con = ConexionDB.dameConexion();
			if (det.getFolio() != null) {
				select.append(utils.ajustaColumna(" AND folio = ?"));
			}
			if (det.getPo() != null) {
				select.append(utils.ajustaColumna(" AND po = ?"));
			}
			if (det.getPosicion() != null) {
				select.append(utils.ajustaColumna(" AND posicion = ?"));
			}
			if (det.getTipoModificacion() != null) {
				select.append(utils.ajustaColumna(" AND tipoModificacion = ?"));
			}
			if (det.getNeedsAuthPlanningMgr() != null) {
				select.append(utils.ajustaColumna(" AND needsAuthPlanningMgr = ?"));
			}
			
			pst = con.prepareStatement(select.toString());
			int cont = 1;
			
			utils.inicializaQuery(select.toString());
			
			if (det.getFolio() != null) {
				utils.ajustaParametro(cont++, pst, det.getFolio(), Integer.class);
			}
			if (det.getPo() != null) {
				utils.ajustaParametro(cont++, pst, det.getPo(), String.class);
			}
			if (det.getPosicion() != null) {
				utils.ajustaParametro(cont++, pst, det.getPosicion(), Integer.class);
			}
			if (det.getTipoModificacion() != null) {
				utils.ajustaParametro(cont++, pst, det.getTipoModificacion(), Integer.class);
			}
			if (det.getNeedsAuthPlanningMgr() != null) {
				utils.ajustaParametro(cont++, pst, det.getNeedsAuthPlanningMgr(), Boolean.class);
			}
			rs = pst.executeQuery();

			while (rs.next()) {
				SarDetalleBO temp = new SarDetalleBO();
				temp.setFolio(rs.getInt("folio"));
				temp.setPo(rs.getString("po"));
				temp.setPosicion(rs.getInt("posicion"));
				temp.setMaterial(rs.getInt("material"));
				temp.setCentro(rs.getString("centro"));
				temp.setCantidad(rs.getInt("cantidad"));
				temp.setPesoProveedor(rs.getDouble("pesoProveedor"));
				temp.setVolumenProveedor(rs.getDouble("volumenProveedor"));
				BigDecimal precioUnitario = rs.getBigDecimal("preciounitario");
				if (rs.wasNull()) {
					precioUnitario = null;
				}
				temp.setPrecioUnitario(precioUnitario);
				temp.setPlaneador(rs.getString("planeador"));
				temp.setCantidadModificada(rs.getInt("cantidadModificada"));
				temp.setPesoModificado(rs.getDouble("pesoModificado"));
				temp.setVolumenModificado(rs.getDouble("volumenModificado"));
				temp.setCliente(rs.getString("cliente"));
				temp.setUnidaMedida(rs.getString("unidadMedida"));
				temp.setCondicionPago(rs.getString("condicionPago"));
				temp.setMoneda(rs.getString("moneda"));
				temp.setFechaProforma(rs.getInt("fechaProforma"));
				temp.setPaisOrigen(rs.getInt("paisOrigen"));
				temp.setNumeroDoc(rs.getString("noDocumento"));
				temp.setCartones(rs.getInt("cartones"));
				temp.setCantidadXCarton(rs.getInt("cantidadXCarton"));
				temp.setPesoNetoPKL(rs.getBigDecimal("pesoNeto"));
				temp.setPesoBrutoPKL(rs.getBigDecimal("PesoBruto"));
				temp.setCubicajePKL(rs.getBigDecimal("cubicaje"));
				temp.setPallet(rs.getInt("pallet"));
				temp.setCartonXPallet(rs.getInt("cartonXPallet"));
				temp.setPedidoDirecto(rs.getBoolean("esPedidoDirecto"));
				temp.setTieneDiferenciasMRP(rs.getBoolean("tieneDiferenciaMRP"));
				temp.setStatusMRP(rs.getInt("statusMRP"));
				temp.setTipoValidacionMRP(rs.getInt("tipoValidacionMRP"));
				temp.setTipoModificacion(rs.getInt("tipoModificacion"));
				temp.setNeedsAuthPlanningMgr(rs.getBoolean("needsAuthPlanningMgr"));
				temp.setAlmacen(rs.getString("almacen"));
				temp.setFactorCantidadUnidadMedida(rs.getBigDecimal("factorCantidadUnidadMedida") == null ? BigDecimal.ONE:rs.getBigDecimal("factorCantidadUnidadMedida"));
				temp.setCantidadUnidadMedida(rs.getBigDecimal("cantidadUnidadMedida") == null ? new BigDecimal(rs.getInt("cantidadModificada")): rs.getBigDecimal("cantidadUnidadMedida"));
				lstSarDetallesModificados.add(temp);
			}

			ConexionDB.devuelveConexion(con);

		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				BOOKING_LOGGER.error(ex.getMessage(), ex);
			}
			BOOKING_LOGGER.error(e.getMessage(), e);
		} catch (Exception e) {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				BOOKING_LOGGER.error(ex.getMessage(), ex);
			}
			BOOKING_LOGGER.error(e.getMessage(), e);
		} finally {
			try {
				rs.close();
				pst.close();
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				BOOKING_LOGGER.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
		return lstSarDetallesModificados;
	}

	@Override
	public boolean insert(Object o) {
		SarDetalleBO detalle = (SarDetalleBO)o;
		Connection con = null;
		PreparedStatement pst = null;
		DAOUtils utilDao = new DAOUtils();
		
		StringBuilder insert = new StringBuilder("INSERT INTO cdiSarDetalleEnRevision (folio, po, posicion, material, centro,");
		insert.append(" cantidad, pesoProveedor, volumenProveedor, precioUnitario, planeador,");
		insert.append(" cantidadModificada, pesoModificado, volumenModificado, cliente, unidadMedida,");
		insert.append(" condicionPago, moneda, fechaProforma, paisOrigen, noDocumento, cartones,");
		insert.append(" cantidadXCarton, pesoNeto, PesoBruto, cubicaje, pallet, cartonXPallet, esPedidoDirecto,");
		insert.append(" tieneDiferenciaMRP, statusMRP, tipoValidacionMRP, tipoModificacion, needsAuthPlanningMgr, ");
		insert.append( "almacen , factorCantidadUnidadMedida , cantidadUnidadMedida )");
		insert.append(" VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");

		boolean exito = false;

		try {
			con = ConexionDB.dameConexion();
			pst = con.prepareStatement(insert.toString());
			int cont = 1;
			utilDao.ajustaParametro(cont++, pst, detalle.getFolio(), Integer.class);
			utilDao.ajustaParametro(cont++, pst, detalle.getPo(), String.class);
			utilDao.ajustaParametro(cont++, pst, detalle.getPosicion(), Integer.class);
			Integer material = detalle.getMaterial() == null ? Integer.valueOf(0) : detalle.getMaterial();
			utilDao.ajustaParametro(cont++, pst, material, Integer.class);
			utilDao.ajustaParametro(cont++, pst, detalle.getCentro(), String.class);
			utilDao.ajustaParametro(cont++, pst, detalle.getCantidad(), Integer.class);
			utilDao.ajustaParametro(cont++, pst, detalle.getPesoProveedor() == null 
					? null : new BigDecimal(detalle.getPesoProveedor()).setScale(2,BigDecimal.ROUND_UP), BigDecimal.class);
			utilDao.ajustaParametro(cont++, pst, detalle.getVolumenProveedor() == null
					? null : RoundingHelper.getInstance().getVolumenBigDecimal(detalle.getVolumenProveedor()), BigDecimal.class);
			utilDao.ajustaParametro(cont++, pst, detalle.getPrecioUnitario() == null
					? null : detalle.getPrecioUnitario(), BigDecimal.class);
			utilDao.ajustaParametro(cont++, pst, detalle.getPlaneador(), String.class);
			utilDao.ajustaParametro(cont++, pst, detalle.getCantidadModificada(), Integer.class);
			utilDao.ajustaParametro(cont++, pst, detalle.getPesoModificado() == null 
					? null : new BigDecimal(detalle.getPesoModificado()).setScale(2,BigDecimal.ROUND_UP), BigDecimal.class);
			utilDao.ajustaParametro(cont++, pst, detalle.getVolumenModificado() == null 
					? null : RoundingHelper.getInstance().getVolumenBigDecimal(detalle.getVolumenModificado()), BigDecimal.class);
			utilDao.ajustaParametro(cont++, pst, detalle.getCliente(), String.class);
			utilDao.ajustaParametro(cont++, pst, detalle.getUnidaMedida(), String.class);
			utilDao.ajustaParametro(cont++, pst, detalle.getCondicionPago(), String.class);
			utilDao.ajustaParametro(cont++, pst, detalle.getMoneda(), String.class);
			utilDao.ajustaParametro(cont++, pst, detalle.getFechaProforma(), Integer.class);
			utilDao.ajustaParametro(cont++, pst, detalle.getPaisOrigen(), Integer.class);
			utilDao.ajustaParametro(cont++, pst, detalle.getNumeroDoc(), String.class);
			utilDao.ajustaParametro(cont++, pst, detalle.getCartones(), Integer.class);
			utilDao.ajustaParametro(cont++, pst, detalle.getCantidadXCarton(), Integer.class);
			utilDao.ajustaParametro(cont++, pst, detalle.getPesoNetoPKL() == null 
					? null : detalle.getPesoNetoPKL().setScale(2,BigDecimal.ROUND_UP), BigDecimal.class);
			utilDao.ajustaParametro(cont++, pst, detalle.getPesoBrutoPKL() == null 
					? null : detalle.getPesoBrutoPKL().setScale(2,BigDecimal.ROUND_UP), BigDecimal.class);
			utilDao.ajustaParametro(cont++, pst, detalle.getCubicajePKL() == null 
					? null : detalle.getCubicajePKL().setScale(2,BigDecimal.ROUND_UP), BigDecimal.class);
			utilDao.ajustaParametro(cont++, pst, detalle.getPallet(), Integer.class);
			utilDao.ajustaParametro(cont++, pst, detalle.getCartonXPallet(), Integer.class);
			utilDao.ajustaParametro(cont++, pst, detalle.isPedidoDirecto(), Boolean.class);
			utilDao.ajustaParametro(cont++, pst, detalle.isTieneDiferenciasMRP(), Boolean.class);
			utilDao.ajustaParametro(cont++, pst, detalle.getStatusMRP(), Integer.class);
			utilDao.ajustaParametro(cont++, pst, detalle.getTipoValidacionMRP(), Integer.class);
			utilDao.ajustaParametro(cont++, pst, detalle.getTipoModificacion(), Integer.class);
			utilDao.ajustaParametro(cont++, pst, detalle.getNeedsAuthPlanningMgr(), Boolean.class);
			utilDao.ajustaParametro(cont++, pst, detalle.getAlmacen(), String.class);
			utilDao.ajustaParametro(cont++, pst, detalle.getFactorCantidadUnidadMedida(), BigDecimal.class);
			utilDao.ajustaParametro(cont++, pst, detalle.getCantidadUnidadMedida(), BigDecimal.class);
			
			utilDao.inicializaQuery(insert.toString());
			
			exito = pst.executeUpdate() > 0;
			ConexionDB.devuelveConexion(con);

		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				BOOKING_LOGGER.error(ex.getMessage(), ex);
			}
			BOOKING_LOGGER.error(e.getMessage(), e);
		} catch (Exception e) {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				BOOKING_LOGGER.error(ex.getMessage(), ex);
			}
			BOOKING_LOGGER.error(e.getMessage(), e);
		} finally {
			try {
				pst.close();
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				BOOKING_LOGGER.error(sqlEx2.getMessage(), sqlEx2);
			}
		}

		return exito;
	}

	@Override
	public boolean update(Object o) {
		SarDetalleBO det = (SarDetalleBO)o;
		Connection con = null;
		PreparedStatement pst = null;
		StringBuilder update = new StringBuilder();
		update.append("UPDATE  cdiSarDetalleEnRevision SET ");
		
		DAOUtils utils = new  DAOUtils();
		boolean exito = false;
		
		try {
			con = ConexionDB.dameConexion();
			if (det.getCantidad() != null) {
				update.append(utils.ajustaColumna(" cantidad = ?"));
			}
			if (det.getPesoProveedor() != null) {
				update.append(utils.ajustaColumna(" pesoProveedor = ?"));
			}
			if (det.getVolumenProveedor() != null) {
				update.append(utils.ajustaColumna(" volumenProveedor = ?"));
			}
			if (det.getCantidadModificada() != null) {
				update.append(utils.ajustaColumna(" cantidadModificada = ?"));
			}
			if (det.getPesoModificado() != null) {
				update.append(utils.ajustaColumna(" pesoModificado = ?"));
			}
			if (det.getVolumenModificado() != null) {
				update.append(utils.ajustaColumna(" volumenModificado = ?"));
			}
			if (det.getTipoModificacion() != null) {
				update.append(utils.ajustaColumna(" tipoModificacion = ?"));
			}
			if (det.getNeedsAuthPlanningMgr() != null) {
				update.append(utils.ajustaColumna(" needsAuthPlanningMgr = ?"));
			}

			update.append(" WHERE  ");
			update.append(" folio = ?");
			update.append(" AND po = ?");
			update.append(" AND posicion = ?");

			int cont = 1;
			pst = con.prepareStatement(update.toString());
			
			utils.inicializaQuery(update.toString());

			if (det.getCantidad() != null) {
				agregarPs(cont++, pst, det.getCantidad(), Integer.class);
			}
			if (det.getPesoProveedor() != null) {
				agregarPs(cont++, pst, new BigDecimal(det.getPesoProveedor()).setScale(2,BigDecimal.ROUND_UP),
						BigDecimal.class);
			}
			if (det.getVolumenProveedor() != null) {
				agregarPs(cont++, pst,
						new BigDecimal(det.getVolumenProveedor()).setScale(2,BigDecimal.ROUND_UP),
						BigDecimal.class);
			}
			if (det.getCantidadModificada() != null) {
				agregarPs(cont++, pst, det.getCantidadModificada(), Integer.class);
			}
			if (det.getPesoModificado() != null) {
				agregarPs(cont++, pst, new BigDecimal(det.getPesoModificado()).setScale(2,BigDecimal.ROUND_UP),
						BigDecimal.class);
			}
			if (det.getVolumenModificado() != null) {
				agregarPs(cont++, pst,
						new BigDecimal(det.getVolumenModificado()).setScale(2,BigDecimal.ROUND_UP),
						BigDecimal.class);
			}
			if (det.getTipoModificacion() != null) {
				agregarPs(cont++, pst,det.getTipoModificacion(), Integer.class);
			}
			if (det.getNeedsAuthPlanningMgr() != null) {
				agregarPs(cont++, pst, det.getNeedsAuthPlanningMgr(), Boolean.class);
			}

			agregarPs(cont++, pst, det.getFolio(), Integer.class);
			agregarPs(cont++, pst, det.getPo(), String.class);
			agregarPs(cont++, pst, det.getPosicion(), Integer.class);

			int resultado = pst.executeUpdate();
			exito = resultado > 0;
			pst.close();

			ConexionDB.devuelveConexion(con);

		} catch (Exception e) {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				BOOKING_LOGGER.error(ex.getMessage(), ex);
			}
			BOOKING_LOGGER.error(e.getMessage(), e);
		} finally {
			try {
				pst.close();
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				BOOKING_LOGGER.error(sqlEx2.getMessage(), sqlEx2);
			}
		}

		return exito;
	}
	
	public boolean delete(Object o) {
		Integer folio = (Integer) o;
		Connection con = null;
		PreparedStatement pst = null;
		StringBuilder delete = new StringBuilder();
		boolean exito = false;
		try {

			delete.append("DELETE  cdiSarDetalleEnRevision");
			delete.append(" WHERE folio = ?");

			int cont = 1;
			con = ConexionDB.dameConexion();

			pst = con.prepareStatement(delete.toString());

			agregarPs(cont++, pst, folio, Integer.class);

			int resultado = pst.executeUpdate();
			exito = resultado > 0;
			pst.close();

			ConexionDB.devuelveConexion(con);

		} catch (Exception e) {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				BOOKING_LOGGER.error(ex.getMessage(), ex);
			}
			BOOKING_LOGGER.error(e.getMessage(), e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				BOOKING_LOGGER.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
		return exito;
	}

}
