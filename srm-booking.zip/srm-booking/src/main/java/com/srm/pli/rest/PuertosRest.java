package com.srm.pli.rest;

import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.srm.pli.bo.BeanUserPOD;
import com.srm.pli.dao.PuertosDescargaDao;
import com.srm.pli.services.PuertosService;
import com.srm.pli.utils.FuncionesComunesPLI;
import com.truper.businessEntity.BeanPuerto;
import com.truper.businessEntity.UserBean;
import com.truper.infra.rs.BaseRS;
import com.truper.utils.date.EnumFechas;

@Path("/PuertosService")
public class PuertosRest extends BaseRS {

	private static final long serialVersionUID = 5394059842158283958L;
	Gson g = new GsonBuilder().serializeSpecialFloatingPointValues().setDateFormat(EnumFechas.FORMATO_YYYY_MM_DD.to())
			.create();
	private static final Logger LOGGER = LogManager.getRootLogger();

	@Context
	private HttpServletRequest request;

	
	
	//TODO generar simil de puertos
	@POST
	@Path("/nuevoPuertoDirecto")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response nuevoPuertoDirecto(String puertoClave) {
		try {
			boolean result = PuertosService.getInstance().updatePuertoDirecto(puertoClave);
			JSONObject json = new JSONObject();
			if(result) {
				PuertosService.getInstance().recargaPuertosDirectos(true);
				json.put("error", 0);
				json.put("mensaje", "The port has been updated correctly");
			}else {
				json.put("error", 1);
				json.put("mensaje", "Error please try again");
			}
			return buildOKResponse(g.toJson(json));
		} catch (Exception e) {
			JSONObject json = new JSONObject();
			json.put("error", 1);
			json.put("mensaje", e.toString());
			return buildOKResponse(json);
		}
	}
	
	
	@POST
	@Path("/reiniciaMapaPuertos")
	@Produces(MediaType.APPLICATION_JSON)
	public Response reiniciaMapaPuertos() {
//		List<BeanAuditoriaSinMatriz> r = null;
//		try {
//			BeanFiltroAuditoriaVista filtro = g.fromJson(json, BeanFiltroAuditoriaVista.class);
//			r = AuditoriaService.getInstance().getCabeceraOrdenesSinMatriz(filtro);
//		} catch (Exception e) {
//			return buildErrorResponse(g.toJson(r));
//		}
//		return buildOKResponse(g.toJson(r));
		return null;
	}
	

	
	@POST
	@Path("/user/ports/update")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response updateUserPorts(String jsonIn) {
		JSONObject json = new JSONObject();

		BeanUserPOD entrada = g.fromJson(jsonIn, BeanUserPOD.class);
		
		HttpSession sesion = request.getSession(false);
		
		UserBean usuario = (UserBean) sesion.getAttribute("usuario");
		
		String aux = entrada.getUser().replaceAll("\\[","").replaceAll("\\]", "").replaceAll("\"", "");
		String[] arayUsers = aux.split(",");
		
		for( String user : arayUsers ) {
			PuertosDescargaDao.getInstance().updatePodByUser(usuario.getUserName(), user, entrada.getListPorts());
		}
		
		HashMap<String, BeanPuerto> puertosUser = FuncionesComunesPLI.cargaPuertosDestinoPorConfirmador(entrada.getUser());
		HashMap<String, BeanPuerto> puertos = FuncionesComunesPLI.cargaPuertosDestino(false);
		json.put("puertosUser", puertosUser);
		json.put("puertos", puertos);
		json.put("estatus",1);
		
		return buildOKResponse(g.toJson(json));
	}
	
}
