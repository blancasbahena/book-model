package com.srm.pli.enums;

public enum TipoCorreoEnum {
	FR_GERENTE
}
