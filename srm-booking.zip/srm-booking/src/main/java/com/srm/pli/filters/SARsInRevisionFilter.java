package com.srm.pli.filters;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.json.JSONObject;

import com.srm.pli.bo.SarBO;
import com.srm.pli.dao.SAR_CDI_DAO;
import com.srm.pli.utils.FuncionesComunesPLI;
import com.srm.pli.utils.PropertiesLoader;
import com.truper.infra.loggers.BaseLogger;

public class SARsInRevisionFilter implements Filter {
	
	private ServletContext context;
	public static SAR_CDI_DAO dao = new SAR_CDI_DAO();

	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
		this.context = filterConfig.getServletContext();
		this.context.log("RequestLoggingFilter initialized");
	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		HttpServletRequest req = (HttpServletRequest) request;
		JSONObject jsonObj = new JSONObject();
		Map<String, String> mapaParametros = new HashMap<String, String>();
		String uri = req.getRequestURI();
		String acciones = PropertiesLoader.getInstance().getString("srm.bloqueo.revision.acciones") == null 
				? "" : PropertiesLoader.getInstance().getString("srm.bloqueo.revision.acciones");
		List<String> lstAcciones = Arrays.asList(acciones.split(","));
		Enumeration<?> params = (Enumeration<?>)req.getParameterNames();
		while(params.hasMoreElements()){
			String name = (String)params.nextElement();
			String value = request.getParameter(name);
			mapaParametros.put(name, value);
		}
		String accion = mapaParametros.get("accion");
		
		if (lstAcciones.contains(accion) && (uri.endsWith("Search") || uri.endsWith("Planning")
				|| uri.endsWith("Shipping") || uri.endsWith("Consolidation") || uri.endsWith("Booking"))) {
			String folio = mapaParametros.get("folio");
			if (folio != null) {
				SarBO sar = new SarBO();
				sar.setFolio(Integer.valueOf(folio));
				sar.setEnRevisionConfirmFinal(true);
				List<SarBO> lstSarsEnRevision;
				try {
					lstSarsEnRevision = dao.selectSar(sar,false);
				} catch (SQLException e) {
					BaseLogger.BOOKING_LOGGER.error(e.getMessage(), e);
					throw new ServletException(e);
				} catch (Exception e) {
					BaseLogger.BOOKING_LOGGER.error(e.getMessage(), e);
					throw new ServletException(e);
				}
				if (lstSarsEnRevision!= null && !lstSarsEnRevision.isEmpty()) {
					jsonObj.put("errorCode", 1);
					jsonObj.put("errorStr", "The folio " + folio + " is currently being modified by another user. Please try again latter. Click \"Ok\" button.");
					jsonObj.put("imagen", "<img src=\"/srm_booking/images/no.gif\" style=\"width: 12px;height: 12px;\" title=\"The folio " 
						+ folio + " is currently being modified by another user. Please try again latter. Click \"Ok\" button.\"/>");
					response.getWriter().print(jsonObj);
					return;
				}
			} 
		}
		chain.doFilter(request, response);
	}

	@Override
	public void destroy() {
		
	}

}
