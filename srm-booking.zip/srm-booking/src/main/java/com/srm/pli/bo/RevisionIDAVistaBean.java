package com.srm.pli.bo;

import java.util.List;

import com.srm.pli.utils.Constantes;
import com.truper.businessEntity.SARDetalle;
import com.truper.businessEntity.SARRevisionIDABean;

import lombok.Getter;
import lombok.Setter;

public class RevisionIDAVistaBean extends SARRevisionIDABean {

	private static final long serialVersionUID = 2L;
	private String proveedor;
	private String POD;
	private Integer creationDate;
	private String creationDateStr;
	private int daysSinceCreation;
	private String container;
	private double volumenSupplier;
	private double varVolumenSupplier;
	private double weightSupplier;
	private double varWeightSupplier;
	private double totalOS;
	private double minimunIDA;
	private double totalBO;
	private double amount;
	private String folioStr;
	private int contenedorInt;
	private String PODVista;
	private String proveedorVista;
	private Integer fechaEmbarque;
	private String pos;
	private String ETDAnterior;
	private String ETDNuevoStr;
	private String plannerName;
	private String plannerCode;
	private boolean tieneMasPOs;
	private boolean almacen45;
	@Getter
	@Setter
	private boolean directo;	

	@Getter
	@Setter
	private String creationDateVista;
	
	public String getProveedor() {
		return proveedor;
	}

	public void setProveedor(String proveedor) {
		this.proveedor = proveedor;
	}

	public String getPOD() {
		return POD;
	}

	public void setPOD(String pOD) {
		POD = pOD;
	}

	public int getDaysSinceCreation() {
		return daysSinceCreation;
	}

	public void setDaysSinceCreation(int daysSinceCreation) {
		this.daysSinceCreation = daysSinceCreation;
	}

	public String getContainer() {
		return container;
	}

	public void setContainer(String container) {
		this.container = container;
	}

	public double getVolumenSupplier() {
		return volumenSupplier;
	}

	public void setVolumenSupplier(double volumenSupplier) {
		this.volumenSupplier = volumenSupplier;
	}

	public double getWeightSupplier() {
		return weightSupplier;
	}

	public void setWeightSupplier(double weightSupplier) {
		this.weightSupplier = weightSupplier;
	}

	public double getTotalOS() {
		return totalOS;
	}

	public void setTotalOS(double totalOS) {
		this.totalOS = totalOS;
	}

	public double getMinimunIDA() {
		return minimunIDA;
	}

	public void setMinimunIDA(double minimunIDA) {
		this.minimunIDA = minimunIDA;
	}

	public double getTotalBO() {
		return totalBO;
	}

	public void setTotalBO(double totalBO) {
		this.totalBO = totalBO;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public boolean isTieneMasPOs() {
		return tieneMasPOs;
	}

	public void setTieneMasPOs(boolean tieneMasPOs) {
		this.tieneMasPOs = tieneMasPOs;
	}

	public Integer getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(Integer creationDate) {
		this.creationDate = creationDate;
	}

	public String getFolioStr() {
		return folioStr;
	}

	public void setFolioStr(String folioStr) {
		this.folioStr = folioStr;
	}

	public int getContenedorInt() {
		return contenedorInt;
	}

	public void setContenedorInt(int contenedorInt) {
		this.contenedorInt = contenedorInt;
	}

	public String getPODVista() {
		return PODVista;
	}

	public void setPODVista(String pODVista) {
		PODVista = pODVista;
	}

	public String getProveedorVista() {
		return proveedorVista;
	}

	public void setProveedorVista(String proveedorVista) {
		this.proveedorVista = proveedorVista;
	}

	public Integer getFechaEmbarque() {
		return fechaEmbarque;
	}

	public void setFechaEmbarque(Integer fechaEmbarque) {
		this.fechaEmbarque = fechaEmbarque;
	}

	public String getPos() {
		return pos;
	}

	public void setPos(String pos) {
		this.pos = pos;
	}

	public String getCreationDateStr() {
		return creationDateStr;
	}

	public void setCreationDateStr(String creationDateStr) {
		this.creationDateStr = creationDateStr;
	}

	public String getETDAnterior() {
		return ETDAnterior;
	}

	public void setETDAnterior(String eTDAnterior) {
		ETDAnterior = eTDAnterior;
	}

	public String getETDNuevoStr() {
		return ETDNuevoStr;
	}

	public void setETDNuevoStr(String eTDNuevoStr) {
		ETDNuevoStr = eTDNuevoStr;
	}

	public double getVarWeightSupplier() {
		return varWeightSupplier;
	}

	public void setVarWeightSupplier(double varWeightSupplier) {
		this.varWeightSupplier = varWeightSupplier;
	}

	public double getVarVolumenSupplier() {
		return varVolumenSupplier;
	}

	public void setVarVolumenSupplier(double varVolumenSupplier) {
		this.varVolumenSupplier = varVolumenSupplier;
	}

	public String getPlannerName() {
		return plannerName;
	}

	public void setPlannerName(String plannerName) {
		this.plannerName = plannerName;
	}

	public String getPlannerCode() {
		return plannerCode;
	}

	public void setPlannerCode(String plannerCode) {
		this.plannerCode = plannerCode;
	}

	public boolean isAlmacen45() {
		return almacen45;
	}

	public void setAlmacen45(boolean almacen45) {
		this.almacen45 = almacen45;
	}

	public void setAlmacen45(List<SARDetalle> detalle) {
		if(detalle != null & detalle.size() > 0) {
			for (int i = 0; i < detalle.size(); i++) {
				SARDetalle d = detalle.get(i);
				if(Constantes.ALMACEN_45.equals(d.getAlmacen())){
					setAlmacen45(true);
					break;
				}
			}
		}
		
	}
}
