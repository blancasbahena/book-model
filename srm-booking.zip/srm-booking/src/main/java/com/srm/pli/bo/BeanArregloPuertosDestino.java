package com.srm.pli.bo;

public class BeanArregloPuertosDestino {
	
	private static final long serialVersionUID = 1L;
	private String clavePuertoDescarga;
	private boolean directo;
	public String getClavePuertoDescarga() {
		return clavePuertoDescarga;
	}
	public void setClavePuertoDescarga(String clavePuertoDescarga) {
		this.clavePuertoDescarga = clavePuertoDescarga;
	}
	public boolean isDirecto() {
		return directo;
	}
	public void setDirecto(boolean directo) {
		this.directo = directo;
	}
	
	
	
}
