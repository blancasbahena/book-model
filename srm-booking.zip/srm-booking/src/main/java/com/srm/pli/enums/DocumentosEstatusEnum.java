package com.srm.pli.enums;

public enum DocumentosEstatusEnum {

	NUEVOS, REJECTED, AMENDED, FINISHED

}
