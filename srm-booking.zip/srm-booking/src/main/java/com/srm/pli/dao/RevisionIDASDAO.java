package com.srm.pli.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.srm.pli.bo.RevisionIDAVistaBean;
import com.srm.pli.bo.SarDetalleBO;
import com.srm.pli.db.ConexionDB;
import com.srm.pli.helper.SarHelper;
import com.truper.businessEntity.SARRevisionIDABean;
import com.truper.utils.sql.UtilsSQL;

public class RevisionIDASDAO {

	private static RevisionIDASDAO instance;
	private static final Logger log = LogManager.getRootLogger();

	private RevisionIDASDAO() {
	}

	public static RevisionIDASDAO getInstance() {
		if (instance == null) {
			instance = new RevisionIDASDAO();
		}
		return instance;
	}

	public Map<Integer, RevisionIDAVistaBean> selectSarsEnIDARevitionData(List<SARRevisionIDABean> lista) {
		if(lista == null)
			return null;
		if(lista.isEmpty())
			return new HashMap<>();
		Map<Integer, RevisionIDAVistaBean> resultado = null;
		Connection con = null;
		try {
			if (lista == null || lista.size() == 0) {
				return null; // Si no hay algun folio a buscar regreso null
			}
			StringBuffer buf = new StringBuffer();
			for (int i = 0; i < lista.size(); i++) {
				if (i > 0) {
					buf.append(",'");
				} else {
					buf.append("'");
				}
				buf.append(lista.get(i).getFolio()).append("'");
			}
			con = ConexionDB.dameConexion();
			StringBuilder sql = new StringBuilder();
			sql.append("SELECT sar.folio ");
			sql.append("       , sar.fechaEmbarque ");
			sql.append("       , sar.etdFinal ");
			sql.append("       , sar.consolidado ");
			sql.append("       , sar.folioconsolidado ");
			sql.append("       , sar.puertosalida ");
			sql.append("       , sar.proveedor ");
			sql.append("       , sar.fechacreacion ");
			sql.append("       , sar.tipocontenedor ");
			sql.append("       , idaRev.aceptado ");
			sql.append("       , idaRev.ETDnuevo ");
			sql.append("       , idaRev.origenDeVista ");
			sql.append("FROM   cdisar sar ");
			sql.append("       LEFT JOIN cdisar_ida_revision idaRev ");
			sql.append("              ON sar.folio = idaRev.folio ");
			sql.append("WHERE  sar.folio IN (");
			sql.append(buf.toString()).append(")");
			try (PreparedStatement pst = con.prepareStatement(sql.toString())) {
				try (ResultSet rs = pst.executeQuery()) {
					resultado = new HashMap<>();
					RevisionIDAVistaBean bean = null;
					while (rs.next()) {
						bean = new RevisionIDAVistaBean();
						bean.setCc(rs.getInt("folioconsolidado"));
						bean.setContenedorInt(rs.getInt("tipocontenedor"));
						bean.setETDNuevo(rs.getInt("ETDnuevo"));
						
						int fechaEmbarque = rs.getInt("fechaEmbarque");
						int etdFinal = rs.getInt("etdFinal");
						int fechaEtdReal = SarHelper.getInstance().getFechaEtdReal(fechaEmbarque, etdFinal);
						bean.setFechaEmbarque(fechaEtdReal);
						
						bean.setFolio(rs.getInt("folio"));
						bean.setProveedor(rs.getString("proveedor"));
						bean.setTipo("1".equals(rs.getString("consolidado")));
						if (bean.isTipo() && bean.getCc() == 0) {
							bean.setCc(1);// Significa que es LCL, pero aun no esta asignado
						}
						bean.setPOD(rs.getString("puertosalida"));
						bean.setCreationDate(rs.getInt("fechacreacion"));
						bean.setAceptado(rs.getBoolean("aceptado"));
						bean.setOrigenDeVista(rs.getString("origenDeVista"));
						resultado.put(bean.getFolio(), bean);
					}
				}
			}
		} catch (SQLException sqle) {
			sqle.printStackTrace();
			log.error("selectSarsEnIDARevitionData: " + sqle.toString(), sqle);
			ConexionDB.renovar(con);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("selectSarsEnIDARevitionData: " + e.toString(), e);
		} finally {
			ConexionDB.devolver(con);
		}
		return resultado;
	}

	public Map<Integer, RevisionIDAVistaBean> selectSarConsolidado(List<SARRevisionIDABean> lista) {
		if(lista == null)
			return null;
		if(lista.isEmpty())
			return new HashMap<>();
		Map<Integer, RevisionIDAVistaBean> resultado = null;
		Connection con = null;
		try {
			StringBuffer buf = new StringBuffer();
			for (int i = 0; i < lista.size(); i++) {
				if (i > 0) {
					buf.append(",'");
				} else {
					buf.append("'");
				}
				buf.append(lista.get(i).getFolio()).append("'");
			}
			if (buf.length() == 0) {
				return new HashMap<>();
			}
			con = ConexionDB.dameConexion();
			StringBuilder sql = new StringBuilder();
			sql.append(" SELECT folio,fechaEmbarque,etdFinal, ");
			sql.append(" puertosalida, fechacreacion,tipocontenedor ");
			sql.append(" FROM cdiSARConsolidados ");
			sql.append(" WHERE folio in (");
			try (PreparedStatement pst = con.prepareStatement(sql.toString() + buf.toString() + ")")) {
				try (ResultSet rs = pst.executeQuery()) {
					resultado = new HashMap<>();
					RevisionIDAVistaBean bean = null;
					while (rs.next()) {
						bean = new RevisionIDAVistaBean();
						bean.setContenedorInt(rs.getInt("tipocontenedor"));
						
						int fechaEmbarque = rs.getInt("fechaEmbarque");
						int etdFinal = rs.getInt("etdFinal");
						int fechaEtdReal = SarHelper.getInstance().getFechaEtdReal(fechaEmbarque, etdFinal);
						bean.setFechaEmbarque(fechaEtdReal);
						
						bean.setFolio(rs.getInt("folio"));
						bean.setTipo(true);
						bean.setCc(bean.getFolio());
						bean.setPOD(rs.getString("puertosalida"));
						bean.setCreationDate(rs.getInt("fechacreacion"));
						resultado.put(bean.getFolio(), bean);
					}
				}
			}
		} catch (SQLException sqle) {
			sqle.printStackTrace();
			log.error("selectSarsEnIDARevitionData: " + sqle.toString(), sqle);
			ConexionDB.renovar(con);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("selectSarsEnIDARevitionData: " + e.toString(), e);
		} finally {
			ConexionDB.devolver(con);
		}
		return resultado;
	}

	public List<SARRevisionIDABean> selectSarEnIDARevition() {
		List<SARRevisionIDABean> resultado = null;
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();
			StringBuilder sql = new StringBuilder();
			sql.append(" SELECT folio,escc,etdNuevo,aceptado,fechavalidacion, createDate, userName, origenDeVista ");
			sql.append(" FROM CDISAR_IDA_REVISION ");
			sql.append(" WHERE aceptado = 0 ");
			try (PreparedStatement pst = con.prepareStatement(sql.toString())) {
				try (ResultSet rs = pst.executeQuery()) {
					resultado = new ArrayList<>();
					SARRevisionIDABean bean = null;
					while (rs.next()) {
						bean = new SARRevisionIDABean();
						bean.setAceptado(rs.getBoolean("aceptado"));
						bean.setETDNuevo(rs.getInt("etdNuevo"));
						Date createDate = UtilsSQL.getDateFromTimestamp(rs.getTimestamp("fechavalidacion"));
						bean.setFechaAccion(createDate);
						bean.setFolio(rs.getInt("folio"));
						bean.setCc(rs.getInt("escc"));
						bean.setCreateDate(rs.getDate("createDate"));
						bean.setUserName(rs.getString("userName"));
						bean.setOrigenDeVista(rs.getString("origenDeVista"));
						resultado.add(bean);
					}
				}
			}
		} catch (SQLException sqle) {
			sqle.printStackTrace();
			log.error("selectSarEnIDARevition: " + sqle.toString(), sqle);
			ConexionDB.renovar(con);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("selectSarEnIDARevition: " + e.toString(), e);
		} finally {
			ConexionDB.devolver(con);
		}
		return resultado;
	}

	public SARRevisionIDABean selectSarEnIDARevitionyFolio(int folio, int esCC) {
		SARRevisionIDABean resultado = null;
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();
			StringBuilder sql = new StringBuilder();
			sql.append(" SELECT folio,escc,etdNuevo,aceptado,fechavalidacion  ");
			sql.append(" FROM CDISAR_IDA_REVISION ");
			sql.append(" WHERE folio = ? ");
			sql.append(" AND esCC = ? ");
			try (PreparedStatement pst = con.prepareStatement(sql.toString())) {
				pst.setInt(1, folio);
				pst.setInt(2, esCC);
				try (ResultSet rs = pst.executeQuery()) {
					if (rs.next()) {
						resultado = new SARRevisionIDABean();
						resultado.setAceptado(rs.getBoolean("aceptado"));
						resultado.setETDNuevo(rs.getInt("etdNuevo"));
						Date createDate = UtilsSQL.getDateFromTimestamp(rs.getTimestamp("fechavalidacion"));
						resultado.setFechaAccion(createDate);
						resultado.setFolio(rs.getInt("folio"));
						resultado.setCc(rs.getInt("escc"));
					}
				}
			}
		} catch (SQLException sqle) {
			sqle.printStackTrace();
			log.error("selectSarEnIDARevition: " + sqle.toString(), sqle);
			ConexionDB.renovar(con);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("selectSarEnIDARevition: " + e.toString(), e);
		} finally {
			ConexionDB.devolver(con);
		}
		return resultado;
	}

	public Map<Integer, SARRevisionIDABean> selectSarEnIDAAcceptedIN(List<SarDetalleBO> lista) {
		if(lista == null)
			return null;
		if(lista.isEmpty())
			return new HashMap<>();
		Map<Integer, SARRevisionIDABean> resultado = new HashMap<>();
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();
			StringBuffer data = new StringBuffer();
			int cont = 0;
			for (SarDetalleBO tmp : lista) {
				if (cont > 0) {
					data.append(",");
				}
				data.append(tmp.getFolio());
				cont++;
			}
			StringBuilder sql = new StringBuilder();
			sql.append(" SELECT folio,escc,etdNuevo,aceptado,fechavalidacion  ");
			sql.append(" FROM CDISAR_IDA_REVISION ");
			sql.append(" WHERE aceptado = 1 AND escc = 1 AND folio in(");
			try (PreparedStatement pst = con.prepareStatement(sql.toString() + data.toString() + ")")) {
				try (ResultSet rs = pst.executeQuery()) {
					while (rs.next()) {
						SARRevisionIDABean bean = new SARRevisionIDABean();
						bean = new SARRevisionIDABean();
						bean.setAceptado(rs.getBoolean("aceptado"));
						bean.setETDNuevo(rs.getInt("etdNuevo"));
						Date createDate = UtilsSQL.getDateFromTimestamp(rs.getTimestamp("fechavalidacion"));
						bean.setFechaAccion(createDate);
						bean.setFolio(rs.getInt("folio"));
						bean.setCc(rs.getInt("escc"));
						resultado.put(bean.getFolio(), bean);
					}
				}
			}
		} catch (SQLException sqle) {
			sqle.printStackTrace();
			log.error("selectSarEnIDARevition: " + sqle.toString(), sqle);
			ConexionDB.renovar(con);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("selectSarEnIDARevition: " + e.toString(), e);
		} finally {
			ConexionDB.devolver(con);
		}
		return resultado.size() == 0 ? null : resultado;
	}

	public RevisionIDAVistaBean selectDataFromSAR(int folio) {
		RevisionIDAVistaBean resultado = null;
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();
			StringBuilder sql = new StringBuilder();
			sql.append(" SELECT folio,fechaEmbarque,etdFinal,consolidado, folioconsolidado  ");
			sql.append(" FROM CDISAR ");
			sql.append(" WHERE folio = ? ");
			try (PreparedStatement pst = con.prepareStatement(sql.toString())) {
				pst.setInt(1, folio);
				try (ResultSet rs = pst.executeQuery()) {
					if (rs.next()) {
						resultado = new RevisionIDAVistaBean();
						resultado.setFolio(rs.getInt("folio"));
						resultado.setTipo(rs.getBoolean("consolidado"));
						resultado.setCc(rs.getInt("folioconsolidado"));
						Integer ETDFinal = rs.getInt("etdFinal");
						if (rs.wasNull()) {
							ETDFinal = null;
						}
						Integer fechaEmbarque = rs.getInt("fechaEmbarque");
						resultado.setETDNuevo(ETDFinal != null && ETDFinal != 0 ? ETDFinal : fechaEmbarque);
					}
				}
			}
		} catch (SQLException sqle) {
			sqle.printStackTrace();
			log.error("selectDataFromSAR: " + sqle.toString(), sqle);
			ConexionDB.renovar(con);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("selectDataFromSAR: " + e.toString(), e);
		} finally {
			ConexionDB.devolver(con);
		}
		return resultado;
	}

	public Connection insertaRegistroRevisionIDA(SARRevisionIDABean bean) throws SQLException {
		int num_insert = 0;
		Connection con = null;
		Boolean isAutoCommit = null;
		try {
			con = ConexionDB.dameConexion();
			isAutoCommit = con.getAutoCommit();
			con.setAutoCommit(false);
			StringBuilder sql = new StringBuilder();
			sql.append("INSERT into CDISAR_IDA_REVISION ");
			sql.append(" (folio,escc,aceptado,etdNuevo, origenDeVista, userName) values (?,?,?,?,?,?)");
			try (PreparedStatement ps = con.prepareStatement(sql.toString());) {
				int cont = 1;
				ps.setInt(cont++, bean.getFolio());
				if (bean.getCc() == null) {
					ps.setInt(cont++, 0);
				} else {
					ps.setInt(cont++, bean.getCc());
				}
				ps.setBoolean(cont++, false);
				ps.setInt(cont++, bean.getETDNuevo());
				ps.setString(cont++, bean.getOrigenDeVista());
				ps.setString(cont++, bean.getUserName());
				num_insert = ps.executeUpdate();
				if (num_insert == 0) {
					throw new SQLException("Error, no se inserto registro alguno");
				}
			}
		} catch (Exception e) {
			log.error("Folio: " + bean.toString(), e);
			if (isAutoCommit != null) {
				con.setAutoCommit(isAutoCommit);
			}
			ConexionDB.renovar(con);
			ConexionDB.devolver(con);
			throw new SQLException(e);
		}
		return con;
	}

	public Connection insertaRegistroRevisionIDA(SARRevisionIDABean bean, Connection con) throws SQLException {
		int num_insert = 0;
		Boolean isAutoCommit = null;
		try {
			con = con != null ? con : ConexionDB.dameConexion();
			isAutoCommit = con.getAutoCommit();
			con.setAutoCommit(false);
			StringBuilder sql = new StringBuilder();
			sql.append("INSERT into CDISAR_IDA_REVISION ");
			sql.append(" (folio,escc,aceptado,etdNuevo) values (?,?,?,?)");
			try (PreparedStatement ps = con.prepareStatement(sql.toString());) {
				int cont = 1;
				ps.setInt(cont++, bean.getFolio());
				if (bean.getCc() == null) {
					ps.setInt(cont++, 0);
				} else if (bean.getCc().compareTo(bean.getFolio()) != 0) {
					ps.setInt(cont++, 1);
				} else {
					ps.setInt(cont++, bean.getCc());
				}
				ps.setBoolean(cont++, false);
				ps.setInt(cont++, bean.getETDNuevo());
				num_insert = ps.executeUpdate();
				if (num_insert == 0) {
					throw new SQLException("Error, no se inserto registro alguno");
				}
			}
		} catch (Exception e) {
			log.error("Folio: " + bean.toString(), e);
			if (isAutoCommit != null) {
				con.setAutoCommit(isAutoCommit);
			}
			ConexionDB.renovar(con);
			ConexionDB.devolver(con);
			throw new SQLException(e);
		}
		return con;
	}

	public int updateSARFULL(int folioSar, boolean revision, Connection conInner) throws SQLException {
		int num_update = 0;
		Connection con = conInner;
		try {
			con = con != null ? con : ConexionDB.dameConexion();
			StringBuilder sql = new StringBuilder();
			sql.append(" UPDATE CDISAR   ");
			sql.append(" SET enRevisionIDA = ?, bitacoraIDA = 1 ,bitacoraIDACerrada = 0 ");
			sql.append(" WHERE folio = ? ");
			try (PreparedStatement ps = con.prepareStatement(sql.toString());) {
				ps.setBoolean(1, revision);
				ps.setInt(2, folioSar);
				num_update = ps.executeUpdate();
				if (num_update > 0) {
					if (conInner != null) {
						con.commit();
						con.setAutoCommit(true);
					}
				} else {
					throw new SQLException("No se actualizo registro sar:" + folioSar);
				}
			}
		} catch (Exception e) {
			log.error("Folio: " + folioSar, e);
			if (conInner != null) {
				con.rollback();
				con.setAutoCommit(true);
			}
		} finally {
			ConexionDB.devolver(con);
		}
		return num_update;
	}

	public Connection updateSARCCs(List<SARRevisionIDABean> lista, boolean revision, Connection conInner)
			throws SQLException {
		int num_update = 0;
		Connection con = conInner;
		StringBuffer buff = new StringBuffer();
		try {
			for (int i = 0; i < lista.size(); i++) {
				if (i > 0) {
					buff.append(",");
				}
				buff.append(lista.get(i).getFolio());
			}
			con = con != null ? con : ConexionDB.dameConexion();
			StringBuilder sql = new StringBuilder();
			sql.append(" UPDATE CDISAR ");
			sql.append(" SET enRevisionIDA = ? , bitacoraIDA = 1,bitacoraIDACerrada = 0 ");
			sql.append(" WHERE folio in ( ");
			try (PreparedStatement ps = con.prepareStatement(sql.toString() + buff.toString() + ")");) {
				ps.setBoolean(1, revision);
				num_update = ps.executeUpdate();
				if (num_update == 0) {
					throw new SQLException("[updateSARCCs]No se actualizo registro sar:" + buff.toString());
				}
			}
		} catch (Exception e) {
			log.error("Folio: " + buff.toString(), e);
			if (conInner != null) {
				con.rollback();
				con.setAutoCommit(true);
			}
		}
		return con;
	}

	public Connection updateSAR_Revision_CCs(SARRevisionIDABean bean, boolean revision, Connection conInner)
			throws SQLException {
		int num_update = 0;
		Connection con = conInner;
		StringBuffer buff = new StringBuffer();
		try {
			con = con != null ? con : ConexionDB.dameConexion();
			StringBuilder sql = new StringBuilder();
			sql.append(" UPDATE CDISARCONSOLIDADOS   ");
			sql.append(" SET enRevisionIDA = ?,bitacoraIDA = 1,bitacoraIDACerrada = 0  ");
			sql.append(" WHERE folio = ? ");
			try (PreparedStatement ps = con.prepareStatement(sql.toString());) {
				ps.setBoolean(1, revision);
				ps.setInt(2, bean.getFolio());
				num_update = ps.executeUpdate();
				if (num_update == 0) {
					throw new SQLException("[updateSARCCs]No se actualizo registro sar:" + buff.toString());
				}
			}
		} catch (Exception e) {
			log.error("Folio: " + buff.toString(), e);
			if (conInner != null) {
				con.rollback();
				con.setAutoCommit(true);
			}
			throw new SQLException(e);
		}
		return con;
	}

	@SuppressWarnings("resource")
	public int updateSAR_Revision_CCs_Close(SARRevisionIDABean bean, Connection conInner) throws SQLException {
		int num_update = 0;
		Connection con = conInner;
		StringBuffer buff = new StringBuffer();
		try {
			con = con != null ? con : ConexionDB.dameConexion();
			StringBuilder sql = new StringBuilder();
			sql.append(" UPDATE CDISARCONSOLIDADOS   ");
			sql.append(" SET bitacoraIDACerrada = 1  ");
			sql.append(" WHERE folio = ? ");
			try (PreparedStatement ps = con.prepareStatement(sql.toString());) {
				ps.setInt(1, bean.getFolio());
				num_update = ps.executeUpdate();
				if (num_update > 0) {
					if (conInner != null) {
						con.setAutoCommit(true);
						con.commit();
					}
				} else {
					throw new SQLException(
							"[updateSAR_Revision_CCs_Close] No se actualizo registro sar:" + bean.toString());
				}
			}
		} catch (Exception e) {
			log.error("Folio: " + buff.toString(), e);
			if (conInner != null) {
				con.rollback();
				con.setAutoCommit(true);
			}
			throw new SQLException(e);
		} finally {
			ConexionDB.devolver(con);
		}
		return num_update;
	}

	public Connection deleteRevisionIDA(int folio, int esCC) throws SQLException {
		int num_insert = 0;
		Connection con = null;
		Boolean isAutoCommit = null;
		try {
			con = ConexionDB.dameConexion();
			isAutoCommit = con.getAutoCommit();
			con.setAutoCommit(false);
			StringBuilder sql = new StringBuilder();
			sql.append(" DELETE FROM  CDISAR_IDA_REVISION ");
			sql.append(" WHERE Folio = ? and esCC = ? ");
			try (PreparedStatement ps = con.prepareStatement(sql.toString());) {
				int cont = 1;
				ps.setInt(cont++, folio);
				ps.setInt(cont++, esCC);
				num_insert = ps.executeUpdate();
				if (num_insert == 0) {
					throw new SQLException("Error, no se Elimino registro alguno");
				}
			}
		} catch (Exception e) {
			log.error("Folio: " + folio + ", CC:" + esCC, e);
			if (isAutoCommit != null) {
				con.setAutoCommit(isAutoCommit);
			}
			ConexionDB.renovar(con);
			ConexionDB.devolver(con);
			throw new SQLException(e);
		}
		return con;
	}
	
	public Connection updateRevisionIDA(int folioSar, boolean statusAceptacion, int esCC) throws SQLException {
		int num_insert = 0;
		Connection con = null;
		Boolean isAutoCommit = null;
		try {
			con = ConexionDB.dameConexion();
			isAutoCommit = con.getAutoCommit();
			con.setAutoCommit(false);
			StringBuilder sql = new StringBuilder();
			sql.append(" UPDATE  CDISAR_IDA_REVISION ");
			sql.append(" SET aceptado = ? ");
			sql.append(" WHERE Folio = ? and esCC = ? ");
			try (PreparedStatement ps = con.prepareStatement(sql.toString());) {
				int cont = 1;
				ps.setBoolean(cont++, statusAceptacion);
				ps.setInt(cont++, folioSar);
				ps.setInt(cont++, esCC);
				num_insert = ps.executeUpdate();
				if (num_insert == 0) {
					throw new SQLException("Error, no se Actualizo registro alguno");
				}
			}
		} catch (Exception e) {
			log.error("Folio: " + folioSar + ", CC:" + esCC, e);
			if (isAutoCommit != null) {
				con.setAutoCommit(isAutoCommit);
			}
			ConexionDB.renovar(con);
			ConexionDB.devolver(con);
			throw new SQLException(e);
		}
		return con;
	}

	public Connection updateRevisionIDATransaction(int folioSar, boolean statusAceptacion, int etdNuevo, int esCC,
			Connection con, String origenDeVista, String userName) throws SQLException {
		int num_insert = 0;
		try {
			con = con == null ? ConexionDB.dameConexion() : con;
			con.setAutoCommit(false);
			StringBuilder sql = new StringBuilder();
			sql.append(" UPDATE  CDISAR_IDA_REVISION ");
			sql.append(" SET aceptado = ? , etdNuevo=?, fechaValidacion=GETDATE(), createDate=GETDATE(), origenDeVista=?, userName=? ");
			sql.append(" WHERE Folio = ? and esCC = ? ");
			try (PreparedStatement ps = con.prepareStatement(sql.toString());) {
				int cont = 1;
				ps.setBoolean(cont++, statusAceptacion);
				ps.setInt(cont++, etdNuevo);
				ps.setString(cont++, origenDeVista);
				ps.setString(cont++, userName);
				ps.setInt(cont++, folioSar);
				ps.setInt(cont++, esCC);
				num_insert = ps.executeUpdate();
				if (num_insert == 0) {
					throw new SQLException("Error, no se Actualiz� registro alguno");
				}
			}
			log.info("Actualizo regstro Folio: " + folioSar + ",statusACEPT:" + statusAceptacion + ",fechaNuevaETD:"
					+ etdNuevo + ",esCC:" + esCC);
		} catch (Exception e) {
			log.error("Folio: " + folioSar + ", CC:" + esCC, e);
			con.rollback();
			con.setAutoCommit(true);
			ConexionDB.renovar(con);
			ConexionDB.devolver(con);
			throw new SQLException(e);
		}
		return con;
	}

	public Map<Integer, RevisionIDAVistaBean> selectDataFromSARConsol(int folio) {
		Map<Integer, RevisionIDAVistaBean> resultado = new HashMap<>();
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();
			StringBuilder sql = new StringBuilder();
			sql.append("SELECT sar.folio ");
			sql.append("       , sar.fechaEmbarque ");
			sql.append("       , sar.etdFinal ");
			sql.append("       , sar.consolidado ");
			sql.append("       , sar.folioconsolidado ");
			sql.append("       , idaRev.aceptado ");
			sql.append("       , idaRev.ETDnuevo ");
			sql.append("       , idaRev.origenDeVista ");
			sql.append("FROM   cdisar sar ");
			sql.append("       LEFT JOIN cdisar_ida_revision idaRev ");
			sql.append("              ON sar.folioConsolidado = idaRev.folio ");
			sql.append("				AND sar.folioConsolidado = idaRev.esCC ");
			sql.append(" WHERE folioConsolidado = ? ");
			try (PreparedStatement pst = con.prepareStatement(sql.toString())) {
				pst.setInt(1, folio);
				try (ResultSet rs = pst.executeQuery()) {
					RevisionIDAVistaBean bean = null;
					while (rs.next()) {
						bean = new RevisionIDAVistaBean();
						bean.setFolio(rs.getInt("folio"));
						bean.setTipo(rs.getBoolean("consolidado"));
						bean.setCc(rs.getInt("folioconsolidado"));
						bean.setETDNuevo(rs.getInt("ETDnuevo"));

						int fechaEmbarque = rs.getInt("fechaEmbarque");
						int etdFinal = rs.getInt("etdFinal");
						int fechaEtdReal = SarHelper.getInstance().getFechaEtdReal(fechaEmbarque, etdFinal);
						bean.setFechaEmbarque(fechaEtdReal);

						bean.setAceptado(rs.getBoolean("aceptado"));
						bean.setOrigenDeVista(rs.getString("origenDeVista"));
						resultado.put(bean.getFolio(), bean);
					}
				}
			}
		} catch (SQLException sqle) {
			sqle.printStackTrace();
			log.error("selectDataFromSAR: " + sqle.toString(), sqle);
			ConexionDB.renovar(con);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("selectDataFromSAR: " + e.toString(), e);
		} finally {
			ConexionDB.devolver(con);
		}
		return resultado.size() > 0 ? resultado : null;
	}

	public Map<String, SARRevisionIDABean> selectTodasEnRevision(List<SARRevisionIDABean> lista) {
		Map<String, SARRevisionIDABean> resultado = new HashMap<>();
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();
			StringBuffer data = new StringBuffer();
			int cont = 0;
			for (SARRevisionIDABean tmp : lista) {
				if (cont > 0) {
					data.append(",");
				}
				data.append(tmp.getFolio());
				cont++;
			}
			StringBuilder sql = new StringBuilder();
			sql.append(" SELECT folio,escc,etdNuevo,aceptado,fechavalidacion  ");
			sql.append(" FROM CDISAR_IDA_REVISION ");
			sql.append(" WHERE folio in(");
			try (PreparedStatement pst = con.prepareStatement(sql.toString() + data.toString() + ")")) {
				try (ResultSet rs = pst.executeQuery()) {
					while (rs.next()) {
						SARRevisionIDABean bean = new SARRevisionIDABean();
						bean = new SARRevisionIDABean();
						bean.setAceptado(rs.getBoolean("aceptado"));
						bean.setETDNuevo(rs.getInt("etdNuevo"));
						Date createDate = UtilsSQL.getDateFromTimestamp(rs.getTimestamp("fechavalidacion"));
						bean.setFechaAccion(createDate);
						bean.setFolio(rs.getInt("folio"));
						bean.setCc(rs.getInt("escc"));
						resultado.put(bean.getFolio() + "_" + bean.getCc(), bean);
					}
				}
			}
		} catch (SQLException sqle) {
			sqle.printStackTrace();
			log.error("selectSarEnIDARevition: " + sqle.toString(), sqle);
			ConexionDB.renovar(con);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("selectSarEnIDARevition: " + e.toString(), e);
		} finally {
			ConexionDB.devolver(con);
		}
		return resultado;
	}

	public int updateSARFULL_close(int folioSar, Connection conInner) throws SQLException {
		int num_update = 0;
		Connection con = conInner;
		try {
			con = con != null ? con : ConexionDB.dameConexion();
			StringBuilder sql = new StringBuilder();
			sql.append(" UPDATE CDISAR   ");
			sql.append(" SET  bitacoraIDAcerrada = 1  ");
			sql.append(" WHERE folio = ? ");
			try (PreparedStatement ps = con.prepareStatement(sql.toString());) {
				ps.setInt(1, folioSar);
				num_update = ps.executeUpdate();
				if (num_update > 0) {
					if (conInner != null) {
						con.commit();
						con.setAutoCommit(true);
					}
				} else {
					throw new SQLException("No se actualizo registro sar:" + folioSar);
				}
			}
		} catch (Exception e) {
			log.error("Folio: " + folioSar, e);
			if (conInner != null) {
				con.rollback();
				con.setAutoCommit(true);
			}
		} finally {
			ConexionDB.devolver(con);
		}
		return num_update;
	}
	
	
	public void deleteRevisionIDANoTransaccional(int folio, int esCC) throws SQLException {
		int num_insert = 0;
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();
			StringBuilder sql = new StringBuilder();
			sql.append(" DELETE FROM  CDISAR_IDA_REVISION ");
			sql.append(" WHERE Folio = ? and esCC = ? ");
			try (PreparedStatement ps = con.prepareStatement(sql.toString());) {
				int cont = 1;
				ps.setInt(cont++, folio);
				ps.setInt(cont++, esCC);
				num_insert = ps.executeUpdate();
				if (num_insert == 0) {
					throw new SQLException("Error, no se Elimino registro alguno");
				}
			}
			ConexionDB.devolver(con);
		} catch (Exception e) {
			log.error("Folio: " + folio + ", CC:" + esCC, e);
			ConexionDB.renovar(con);
			ConexionDB.devolver(con);
			throw new SQLException(e);
		}
	}
	
	public Integer selectSAR(Integer folio) {
		Integer sar = null;
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();
			StringBuilder sql = new StringBuilder();
			sql.append(" SELECT folio,consolidado ");
			sql.append(" FROM CDISAR ");
			sql.append(" WHERE folio = ? ");
			try (PreparedStatement pst = con.prepareStatement(sql.toString())) {
				int cont = 1;
				pst.setInt(cont++, folio);
				try (ResultSet rs = pst.executeQuery()) {
					while (rs.next()) {
						sar = rs.getInt("consolidado");
					}
				}
			}
		} catch (SQLException sqle) {
			log.error("selectSAR: " + sqle.toString(), sqle);
			ConexionDB.renovar(con);
		} catch (Exception e) {
			log.error("selectSAR: " + e.toString(), e);
		} finally {
			ConexionDB.devolver(con);
		}
		return sar;
	}
	
	public List<Integer> selectSARConsolidado(Integer folio) {
		Integer sar = null;
		List<Integer> respuesta = null;
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();
			StringBuilder sql = new StringBuilder();
			sql.append(" SELECT folio,consolidado ");
			sql.append(" FROM CDISAR ");
			sql.append(" WHERE folioconsolidado  = ? ");
			try (PreparedStatement pst = con.prepareStatement(sql.toString())) {
				int cont = 1;
				pst.setInt(cont++, folio);
				try (ResultSet rs = pst.executeQuery()) {
					respuesta = new ArrayList<>();
					while (rs.next()) {
						sar = rs.getInt("folio");
						respuesta.add(sar);
					}
				}
			}
		} catch (SQLException sqle) {
			log.error("selectSAR: " + sqle.toString(), sqle);
			ConexionDB.renovar(con);
		} catch (Exception e) {
			log.error("selectSAR: " + e.toString(), e);
		} finally {
			ConexionDB.devolver(con);
		}
		return respuesta;
	}
	
}