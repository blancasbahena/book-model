package com.srm.pli.rest;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.srm.pli.dao.SAR_CDI_DAO;
import com.truper.businessEntity.BeanFactura;
import com.truper.infra.rs.BaseRS;


@Path("/proveedoresServicesRest")
public class ProveedoresServicesRest extends BaseRS{
	
	private static final long serialVersionUID = -3295258570394852215L;
	private static Gson gson = new GsonBuilder()
			.serializeSpecialFloatingPointValues().create();
	private static final Logger log = LogManager.getRootLogger();
	
	@GET
	@Path("/dameRutaInvoice")
	@Produces(MediaType.APPLICATION_JSON)
	public Response dameRutaInvoice(@Context UriInfo ui) {
		Response r = null;
		MultivaluedMap<String, String> map = ui.getQueryParameters();
		String id = map.getFirst("id");
		String condicion = map.getFirst("condicion");
		JSONObject jsonRestul = new JSONObject();
		try {
			BeanFactura fact = SAR_CDI_DAO.selectFacturaXId(Integer.parseInt(id), condicion);
			
			jsonRestul.put("ruta",fact.getRutaArchivo() );
			jsonRestul.put("errorCode", 0);
			jsonRestul.put("mensaje", "OK");
		}catch(Exception e) {
			jsonRestul.put("errorCode", 1);
			jsonRestul.put("mensaje", "Error: "+e.toString());
			r = buildErrorResponse(jsonRestul);
			log.error("[dameRutaInvoice] Error al obtener la ruta del archivo Invoice id:{}, condicion de pago:{} ",id,condicion, e.getMessage());
			return r;
		}
		r = buildOK_JSONResponse(jsonRestul.toString());
		return r;
	}
	
	
	
	
}
