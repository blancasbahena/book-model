package com.srm.pli.helper;

import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.SortedSet;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.srm.pli.dao.sql.PriceReleaseSQL;
import com.srm.pli.servlet.Proveedores;
import com.srm.pli.utils.FuncionesComunesPLI;
import com.srm.pli.utils.ProductoUtils;
import com.srm.pli.utils.UnidadNegocioUtils;
import com.truper.bpm.enums.TipoPosicionEnum;
import com.truper.businessEntity.BeanDetalleOrdenMaterial;
import com.truper.businessEntity.BeanPoPosicionWithOther;
import com.truper.businessEntity.BeanPriceRelease;
import com.truper.businessEntity.BeanPriceReleasePosicion;
import com.truper.businessEntity.ImportacionesProveedoresBean;
import com.truper.businessEntity.UnidadNegocio;
import com.truper.utils.string.UtilsString;

public class PriceReleaseHelper {

	private static final PriceReleaseHelper instance = new PriceReleaseHelper();
	private static final Logger LOGGER = LogManager.getRootLogger();
	public static final String TO_SPLIT = "F_&_R";

	public static PriceReleaseHelper getInstance() {
		return instance;
	}

	public void setPreciosSAP(Map<Integer, BeanPriceRelease> map, Map<String, List<BeanDetalleOrdenMaterial>> precios) {
		if (map == null || map.isEmpty() || precios == null || precios.isEmpty()) {
			return;
		}
		for (BeanPriceRelease iterable_element : map.values()) {
			SortedSet<BeanPriceReleasePosicion> posiciones = iterable_element.getPosiciones();
			if (posiciones == null || posiciones.isEmpty()) {
				continue;
			}
			for (Iterator<BeanPriceReleasePosicion> iterator = posiciones.iterator(); iterator.hasNext();) {
				BeanPriceReleasePosicion posicion = iterator.next();
				if (posicion.getTipo() == TipoPosicionEnum.OTHER_ITEM) {
					continue;
				}
				String po = posicion.getPo();
				if (!precios.containsKey(po)) {
					continue;
				}
				int posicion_po = posicion.getPosicion();
				if(posicion_po == 0)
					continue;
				List<BeanDetalleOrdenMaterial> item_price = precios.get(po);
				for (BeanDetalleOrdenMaterial item : item_price) {
					String posicion_item = item.getPosicion();
					if (posicion_item != null && posicion_item.equalsIgnoreCase(String.valueOf(posicion_po))) {
						posicion.setPrecioUnitarioSAP(item.getPrecioUnitario());
						posicion.setMoneda(item.getMoneda());
						posicion.setUnidadMedida(item.getUnidadMedida());
						break;
					}
				}
			}
		}
	}
	
	public void setPreciosSAP(SortedSet<BeanPoPosicionWithOther> posiciones,
			Map<String, List<BeanDetalleOrdenMaterial>> precios) {
		if (posiciones == null || posiciones.isEmpty() || precios == null || precios.isEmpty()) {
			return;
		}
		for (Iterator<BeanPoPosicionWithOther> iterator = posiciones.iterator(); iterator.hasNext();) {
			BeanPoPosicionWithOther posicion = iterator.next();
			if (posicion.getTipo() == TipoPosicionEnum.OTHER_ITEM) {
				continue;
			}
			String po = posicion.getPo();
			if (!precios.containsKey(po)) {
				continue;
			}
			int posicion_po = posicion.getPosicion();
			if(posicion_po == 0)
				continue;
			List<BeanDetalleOrdenMaterial> item_price = precios.get(po);
			for (BeanDetalleOrdenMaterial item : item_price) {
				String posicion_item = item.getPosicion();
				if (posicion_item != null && posicion_item.equalsIgnoreCase(String.valueOf(posicion_po))) {
					posicion.setPrecioUnitario(item.getPrecioUnitario());
					posicion.setMoneda(item.getMoneda());
					posicion.setUnidadMedida(item.getUnidadMedida());
					break;
				}
			}
		}
	}

	public void setValoresPriceRelease(BeanPriceRelease bean) {
		if (bean == null) {
			return;
		}
		ImportacionesProveedoresBean bean_prov = FuncionesComunesPLI.getProveedor(bean.getProveedor());
		if (bean_prov == null) {
			bean.setProveedor_nombre("-");
		} else {
			bean.setProveedor_nombre(bean_prov.getNombreProveedor());
		}
		HashSet<UnidadNegocio> buDirectores = new HashSet<UnidadNegocio>();
		HashSet<String> buGerentes = new HashSet<String>();
		HashSet<String> compradores = new HashSet<String>();
		HashSet<String> bus = new HashSet<String>();
		HashMap<Integer, String> folio_buDirector = new HashMap<>();
		int contador_pos = 0;
		int cont = 0;
		int numero_posiciones = bean.getPosiciones().size();
		for (BeanPriceReleasePosicion posicion : bean.getPosiciones()) {
			cont++;
			
			String others_with_bu = posicion.getPlaneador();
			boolean evalua_other_like_po = false;
			if (numero_posiciones == cont && contador_pos == 0 && others_with_bu != null && others_with_bu.contains(TO_SPLIT)) {
				evalua_other_like_po = true;
			}
			
			if (!evalua_other_like_po && posicion.getTipo() == TipoPosicionEnum.OTHER_ITEM) {
				continue;
			}
			contador_pos++;
			
			String material = posicion.getMaterial();
			String centro = posicion.getCentro();
			
			if (evalua_other_like_po) {
				String[] material_centro = others_with_bu.split(TO_SPLIT);
				material = material_centro[0];
				centro = material_centro[1];
			}
			
			String po = posicion.getPo();
			Integer linea = posicion.getPosicion();
			
			String bu_name = ProductoUtils.getInstance().getBUName(material, centro);
			bus.add(bu_name);
			String bu = ProductoUtils.getInstance().getBU(material, centro);
			posicion.setUnidadNegocio(bu);
			posicion.setUnidadNegocioNombre(bu_name);
			if (bu == null || ProductoUtils.NO_ENCONTRADO.equals(bu) || ProductoUtils.SIN_PRODUCTO_CENTRO.equals(bu)) {
				LOGGER.error("No se encontro BU | po: " + po + " | posicion: " + linea + " | material: " + material
						+ " | centro: " + centro);
				buGerentes.add("");
			} else {
				HashSet<String> compra = UnidadNegocioUtils.getInstance().getCompradoresNombre(bu);
				if (compra == null || compra.isEmpty()) {
					LOGGER.error("No se encontro comprador | po: " + po + " | posicion: " + linea + " | bu: " + bu);
				} else {
					compradores.addAll(compra);
				}
				UnidadNegocio unidad = UnidadNegocioUtils.getInstance().getUnidadNegocio(bu);
				if (unidad == null) {
					LOGGER.error("No se encontro UnidadNegocio | po: " + po + " | posicion: " + linea + " | bu: " + bu);
				} else {
					buDirectores.add(unidad);
				}
				if (posicion.getUpdateDate() != null) {
					if( folio_buDirector.containsKey(posicion.getFolio()) ) {
						folio_buDirector.put(posicion.getFolio(), folio_buDirector.get(posicion.getFolio()) + ", " + unidad.getCelulas());
					} else {
						folio_buDirector.put(posicion.getFolio(), unidad.getCelulas());
					}
				}
				HashSet<String> buGer = UnidadNegocioUtils.getInstance().getResponsablesNombre(bu);
				if (buGer == null || buGer.isEmpty()) {
					LOGGER.error("No se encontro Responsable/Gerente | po: " + po + " | posicion: " + linea + " | bu: " + bu);
				} else {
					buGerentes.addAll(buGer);
				}
			}
		}
		bean.setCompradores(compradores);
		bean.setBuGerentes(buGerentes);
		bean.setBuDirectores(buDirectores);
		bean.setBus(bus);
		bean.setFolio_buDirector(folio_buDirector);
	}

	public HashSet<String> getPoFromSet(SortedSet<BeanPoPosicionWithOther> posiciones) {
		HashSet<String> pos = new HashSet<>();
		for (Iterator<BeanPoPosicionWithOther> iterator = posiciones.iterator(); iterator.hasNext();) {
			BeanPoPosicionWithOther posicion = iterator.next();
			if (posicion.getTipo() == TipoPosicionEnum.OTHER_ITEM) {
				continue;
			}
			String po = posicion.getPo();
			pos.add(po);
		}
		return pos;
	}
	
	public HashSet<String> getPoFromSet(Collection<BeanPriceRelease> posiciones) {
		HashSet<String> pos = new HashSet<>();
		for (BeanPriceRelease beanPriceRelease : posiciones) {
			SortedSet<BeanPriceReleasePosicion> posiciones_reales = beanPriceRelease.getPosiciones();
			if( posiciones_reales == null || posiciones_reales.isEmpty() ) {
				continue;
			}
			for (Iterator<BeanPriceReleasePosicion> iterator = posiciones_reales.iterator(); iterator.hasNext();) {
				BeanPriceReleasePosicion posicion = iterator.next();
				if (posicion.getTipo() == TipoPosicionEnum.OTHER_ITEM) {
					continue;
				}
				String po = posicion.getPo();
				pos.add(po);
			}
		}
		return pos;
	}

	/**
	 * El valor de P proviene del query
	 * {@link PriceReleaseSQL #SELECT_SAR_PO_POSICION_WITH_OTHER_ITEM}
	 * 
	 * @param item
	 * @param tipo
	 */
	public void setTipo(BeanPoPosicionWithOther item, String tipo) {
		if (tipo.equalsIgnoreCase("P")) {
			item.setTipo(TipoPosicionEnum.PO);
		} else {
			item.setTipo(TipoPosicionEnum.OTHER_ITEM);
		}
	}

	public boolean isOtherItemWithPago(String tipo) {
		if (tipo == null)
			return false;
		switch (tipo) {
		case Proveedores.PAID_SAMPLES:
		case Proveedores.HANDLING_CHARGE:
		case Proveedores.IN_LAND_FREIGHT_TO_MOVE_TO_ANOTHER_PORT:
			return true;
		default:
			return false;
		}
	}

	public boolean isOtherItemService(String otherType) {
		if (otherType == null)
			return false;
		switch (otherType) {
		case Proveedores.HANDLING_CHARGE:
		case Proveedores.IN_LAND_FREIGHT_TO_MOVE_TO_ANOTHER_PORT:
			return true;
		default:
			return false;
		}
	}
}