package com.srm.pli.helper;

import java.io.File;
import java.util.GregorianCalendar;

import com.srm.pli.utils.FuncionesComunesPLI;

public class DocumentosHelper {

	private static String PATH_FILES = "C:"+ File.separator+"arch"+ File.separator+"Documents";
	private static final int numeroMaximoBooking = 80;
	
	
	public static final DocumentosHelper instance = new DocumentosHelper();
	
	private DocumentosHelper() {
		
	}
	
	
	public static DocumentosHelper getInstance() {
		return instance;
	}
	
	public  String formateaBooking(String booking) throws Exception {
		
		if(booking == null) {
			throw new Exception("The booking must be a valid String");
		}
		String tmp = booking.replaceAll("[^A-Za-z0-9]", "");
		
		if(tmp.length() > numeroMaximoBooking) {
			tmp = tmp.substring(numeroMaximoBooking);
		}
		
		return tmp;
		
	}
	
	public  String dameRutaArchivos(String proveedor,String booking ) throws Exception {
		GregorianCalendar greg = new GregorianCalendar();
		int year = FuncionesComunesPLI.gregorianCalendar2int(greg);
		year = year / 10000;
		StringBuffer ruta = new StringBuffer();
		ruta.append(PATH_FILES);
		ruta.append(File.separator);
		ruta.append(year);
		ruta.append(File.separator);
		ruta.append(proveedor);
		ruta.append(File.separator);
		ruta.append(formateaBooking(booking));
		ruta.append(File.separator);
		
		File nuevo = new File(ruta.toString());
		if(!nuevo.exists()){
			nuevo.mkdirs();
		} 
		
		return ruta.toString();
	}
	
	
}
