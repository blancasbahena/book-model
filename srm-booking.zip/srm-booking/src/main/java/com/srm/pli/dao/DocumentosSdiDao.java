package com.srm.pli.dao;

import static com.srm.pli.dao.sql.DocumentosSdiSql.SELECT_FOLIOS_ANALISIS_BOOKING;
import static com.srm.pli.dao.sql.DocumentosSdiSql.SELECT_FOLIOS_ANALISIS_CORRECION_BOOKING;
import static com.srm.pli.dao.sql.DocumentosSdiSql.SELECT_FOLIOS_CONFIRMACION_FINAL_MAYOR_1_DIA_SIN_PRIMER_ENVIO_DE_DOCUMENTOS;
import static com.srm.pli.dao.sql.DocumentosSdiSql.SELECT_FOLIO_ANALISIS;
import static com.srm.pli.dao.sql.DocumentosSdiSql.UPDATE_DISPONIBILIDAD_OTROS_DOCUMENTOS;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.srm.pli.bo.BeanRechazosSDI;
import com.srm.pli.dao.sql.DocumentosSdiSql;
import com.srm.pli.dao.sql.DocumentosSdiSql.DocumentosSdiDaoEnum;
import com.srm.pli.db.ConexionDB;
import com.truper.businessEntity.BeanDocumentoAnalisis;
import com.truper.businessEntity.BeanOtrosDocumentos;
import com.truper.utils.date.EnumFechas;
import com.truper.utils.date.UtilsFechas;

public class DocumentosSdiDao {

	private static final DocumentosSdiDao instance = new DocumentosSdiDao();
	private static final Logger LOGGER = LogManager.getRootLogger();

	private DocumentosSdiDao() {
	}

	public static DocumentosSdiDao getInstance() {
		return instance;
	}

	public BeanDocumentoAnalisis selectDocumentoEnAnalisis(Integer folio) {
		Connection con = null;
		BeanDocumentoAnalisis respuesta = null;
		try {
			con = ConexionDB.dameConexion();
			try (PreparedStatement pst = con.prepareStatement(SELECT_FOLIO_ANALISIS)) {
				pst.setInt(1, folio);
				try (ResultSet rs = pst.executeQuery()) {
					if (rs.next()) {
						respuesta = getBasicBeanDocumentoAnalisisFromRs(rs);
					}
				}
			}
		} catch (SQLException sqle) {
			sqle.printStackTrace();
			LOGGER.error("Folio: " + folio, sqle);
			ConexionDB.renovar(con);
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error("Folio: " + folio, e);
		} finally {
			ConexionDB.devolver(con);
		}
		return respuesta;
	}

	public HashMap<String, List<BeanDocumentoAnalisis>> selectDocumentoEnAnalisis(DocumentosSdiDaoEnum accion) {
		Connection con = null;
		HashMap<String, List<BeanDocumentoAnalisis>> respuesta = null;
		try {
			con = ConexionDB.dameConexion();
			String query = DocumentosSdiSql.getSelectFoliosAnalisisDias(accion);
			try (PreparedStatement pst = con.prepareStatement(query)) {
				try (ResultSet rs = pst.executeQuery()) {
					respuesta = new HashMap<>();
					BeanDocumentoAnalisis bean;
					while (rs.next()) {
						bean = getBasicBeanDocumentoAnalisisFromRs(rs);
						Integer folio = rs.getInt("folio");
						bean.setFolio(folio);
						String booking = bean.getBooking();
						if (respuesta.containsKey(booking)) {
							respuesta.get(booking).add(bean);
						} else {
							List<BeanDocumentoAnalisis> lista = new ArrayList<>();
							lista.add(bean);
							respuesta.put(booking, lista);
						}
					}
				}
			}
		} catch (SQLException sqle) {
			sqle.printStackTrace();
			LOGGER.error("Accion: " + accion.toString(), sqle);
			ConexionDB.renovar(con);
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error("Accion: " + accion.toString(), e);
		} finally {
			ConexionDB.devolver(con);
		}
		return respuesta;
	}
	
	public List<BeanDocumentoAnalisis> selectDocumentoEnAnalisis(String booking, String proveedor) {
		Connection con = null;
		List<BeanDocumentoAnalisis> respuesta = null;
		try {
			con = ConexionDB.dameConexion();
			try (PreparedStatement pst = con.prepareStatement(SELECT_FOLIOS_ANALISIS_BOOKING)) {
				pst.setString(1, booking);
				pst.setString(2, proveedor);
				try (ResultSet rs = pst.executeQuery()) {
					respuesta = new ArrayList<>();
					BeanDocumentoAnalisis bean;
					while (rs.next()) {
						bean = getBasicBeanDocumentoAnalisisFromRs(rs);
						Integer folio = rs.getInt("folio");
						bean.setFolio(folio);
						respuesta.add(bean);
					}
				}
			}
		} catch (SQLException sqle) {
			sqle.printStackTrace();
			LOGGER.error("booking: " + booking + ", proveedor: " + proveedor, sqle);
			ConexionDB.renovar(con);
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error("booking: " + booking + ", proveedor: " + proveedor, e);
		} finally {
			ConexionDB.devolver(con);
		}
		return respuesta;
	}
	
	public List<BeanDocumentoAnalisis> selectDocumentoEnAnalisisCorrecion(String booking, String proveedor) {
		Connection con = null;
		List<BeanDocumentoAnalisis> respuesta = null;
		try {
			con = ConexionDB.dameConexion();
			try (PreparedStatement pst = con.prepareStatement(SELECT_FOLIOS_ANALISIS_CORRECION_BOOKING)) {
				pst.setString(1, booking);
				pst.setString(2, proveedor);
				try (ResultSet rs = pst.executeQuery()) {
					respuesta = new ArrayList<>();
					BeanDocumentoAnalisis bean;
					while (rs.next()) {
						bean = getBasicBeanDocumentoAnalisisFromRs(rs);
						Integer folio = rs.getInt("folio");
						bean.setFolio(folio);
						String comentariosSdi = rs.getString("comentariosSDI");
						bean.setComentariosSdi(comentariosSdi);
						respuesta.add(bean);
					}
				}
			}
		} catch (SQLException sqle) {
			sqle.printStackTrace();
			LOGGER.error("booking: " + booking + ", proveedor: " + proveedor, sqle);
			ConexionDB.renovar(con);
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error("booking: " + booking + ", proveedor: " + proveedor, e);
		} finally {
			ConexionDB.devolver(con);
		}
		return respuesta;
	}

	public Map<String, List<BeanDocumentoAnalisis>> selectDocumentoEnAnalisisCorrecionMayorEnDias(
			DocumentosSdiDaoEnum accion) {
		Connection con = null;
		Map<String, List<BeanDocumentoAnalisis>> respuesta = null;
		try {
			con = ConexionDB.dameConexion();
			StringBuffer sql = new StringBuffer();
			sql.append("SELECT s.proveedor ");
			sql.append("       , s.booking ");
			sql.append("       , s.eta ");
			sql.append("       , s.folio ");
			sql.append("       , d.comentariosSDI ");
			sql.append(" FROM cdisar s ");
			sql.append("		LEFT JOIN cdidocumentossdi d ");
			sql.append("			ON s.proveedor = d.proveedor ");
			sql.append("                 AND s.booking = d.booking ");
			sql.append("                 AND s.versionsetdocumentos = d.versionsdi ");
			sql.append(" WHERE ISNULL(s.booking, '') <> '' ");
			sql.append("	AND d.fechaAceptaProveedor IS NULL ");
			sql.append("	AND d.fechaRechazo IS NOT NULL ");
			sql.append("	AND CONVERT(VARCHAR(8), d.fechaRechazo + ?, 112) <= CONVERT(VARCHAR(8), GETDATE(), 112) ");
			sql.append(" ORDER BY s.booking, s.folio DESC");
			try (PreparedStatement pst = con.prepareStatement(sql.toString())) {
				int dias = 0;
				if (DocumentosSdiDaoEnum.SOLICITUD_DOC_CORRECCION_AVISO_2_DIAS == accion) {
					dias = 2;
				}
				pst.setInt(1, dias);
				try (ResultSet rs = pst.executeQuery()) {
					respuesta = new HashMap<>();
					BeanDocumentoAnalisis bean;
					while (rs.next()) {
						bean = getBasicBeanDocumentoAnalisisFromRs(rs);
						Integer folio = rs.getInt("folio");
						bean.setFolio(folio);
						String comentariosSdi = rs.getString("comentariosSDI");
						bean.setComentariosSdi(comentariosSdi);
						String booking = bean.getBooking();
						if (respuesta.containsKey(booking)) {
							respuesta.get(booking).add(bean);
						} else {
							List<BeanDocumentoAnalisis> lista = new ArrayList<>();
							lista.add(bean);
							respuesta.put(booking, lista);
						}
					}
				}
			}
		} catch (SQLException sqle) {
			LOGGER.error("Accion: " + accion.toString(), sqle);
			ConexionDB.renovar(con);
		} catch (Exception e) {
			LOGGER.error("Accion: " + accion.toString(), e);
		} finally {
			ConexionDB.devolver(con);
		}
		return respuesta;
	}

	public ArrayList<BeanRechazosSDI> selectRegistrosReporteSDIRechazados() {
		Connection con = null;
		ArrayList<BeanRechazosSDI> respuesta = null; 
		try {
			con = ConexionDB.dameConexion();
			StringBuffer  sql = new StringBuffer();
			sql.append("SELECT a.proveedor ");
			sql.append("       , a.booking ");
			sql.append("	   , a.eta ");
			sql.append("	   , a.folio ");
			sql.append("	   , a.versionSetDocumentos ");
			sql.append("	   , b.fechaRechazo ");
			sql.append("	   , c.aprobado ");
			sql.append("	   , c.fechaAceptaProveedor ");
			sql.append("	   , c.analista ");
			sql.append("	   , a.prioridad ");
			sql.append("	   , d.esPedidoDirecto ");
			sql.append("	   , d.centro ");
			sql.append("	   , a.naviera ");
			sql.append("	   , d.material ");
			sql.append("	   , d.po ");
			sql.append("	   , d.posicion ");
			sql.append("	   , d.condicionPago ");
			sql.append("	   , a.consolidado ");
			sql.append("	   , DATEDIFF(day,b.fechaRechazo,getdate()) as fecRec ");
			sql.append("	   , b.comentariosSDI ");
			sql.append("	   , b.usuarioRechazo ");
			sql.append(" FROM   cdisar a ");
			sql.append("       INNER JOIN cdidocumentossdi b ");
			sql.append("               ON a.booking = b.booking ");
			sql.append("                  AND a.versionsetdocumentos = b.versionsdi ");
			sql.append("                  AND a.proveedor = b.proveedor ");
			sql.append("       INNER JOIN cdicontrolsdi c ");
			sql.append("               ON c.booking = b.booking ");
			sql.append("                  AND c.versionsdi = b.versionsdi - 1 ");
			sql.append("                  AND c.proveedor = b.proveedor ");
			sql.append("       INNER JOIN cdisardetalle d ");
			sql.append("               ON a.folio = d.folio ");
			sql.append("       INNER JOIN cdi_facturas f ");
			sql.append("               ON b.id = f.id ");
			sql.append("                  AND f.versiondocumento = b.versionfacturas ");
			sql.append("                  AND d.condicionpago = f.condicionpago ");
			sql.append(" ORDER  BY a.proveedor, a.booking, a.folio ASC ");
			try (PreparedStatement pst = con.prepareStatement(sql.toString())) {
				try (ResultSet rs = pst.executeQuery()) {
					respuesta = new ArrayList<BeanRechazosSDI>();
					BeanRechazosSDI bean;
					
					while (rs.next()) {
						bean = new BeanRechazosSDI();
						bean.setAnalista(rs.getString("analista"));
						bean.setBooking(rs.getString("booking"));
						bean.setCentro(rs.getString("centro"));
						bean.setConsolidado(rs.getBoolean("consolidado"));
						bean.setDiasVsRechazo(rs.getInt("fecRec"));
						bean.setETA(rs.getInt("eta"));
						bean.setFechaRechazo(
								UtilsFechas.setConvierteFechaToInt(rs.getTimestamp("fechaRechazo"), EnumFechas.FORMATO_YYYYMMDD));
						bean.setFolio(rs.getString("folio"));
						bean.setNaviera(rs.getInt("naviera"));
						bean.setPo(rs.getString("po"));
						bean.setPos(rs.getInt("posicion"));
						bean.setPrioridad(rs.getInt("prioridad"));
						bean.setProveedor(rs.getString("proveedor"));
						bean.setTerminoPago(rs.getString("condicionPago"));
						bean.setVersionSDI(rs.getInt("versionSetDocumentos"));
						bean.setFechaAceptadoProveedor(UtilsFechas.setConvierteFechaToInt(rs.getTimestamp("fechaAceptaProveedor"), EnumFechas.FORMATO_YYYYMMDD));//
						bean.setEsPedidoDirecto(rs.getBoolean("esPedidoDirecto"));
						bean.setMaterial(rs.getString("material"));
						bean.setComentarioSdi(rs.getString("comentariosSDI"));
						bean.setUsuarioRechazo(rs.getString("usuarioRechazo"));
						respuesta.add(bean);
					}
				}
			}
		} catch (SQLException sqle) {
			sqle.printStackTrace();
			LOGGER.error("selectRegistrosReporteSDIRechazados Error: " , sqle);
			ConexionDB.renovar(con);
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error("selectRegistrosReporteSDIRechazados Error: ", e);
		} finally {
			ConexionDB.devolver(con);
		}
		return respuesta;
	}
	
	public HashMap<String, List<BeanDocumentoAnalisis>> selectFoliosConfirmacionFinalMayor1DiaSinEnvioDocumentos() {
		Connection con = null;
		HashMap<String, List<BeanDocumentoAnalisis>> respuesta = null;
		try {
			con = ConexionDB.dameConexion();
			try (Statement st = con.createStatement()) {
				try (ResultSet rs = st
						.executeQuery(SELECT_FOLIOS_CONFIRMACION_FINAL_MAYOR_1_DIA_SIN_PRIMER_ENVIO_DE_DOCUMENTOS)) {
					respuesta = new HashMap<>();
					BeanDocumentoAnalisis bean;
					while (rs.next()) {
						bean = getBasicBeanDocumentoAnalisisFromRs(rs);
						Integer folio = rs.getInt("folio");
						bean.setFolio(folio);
						String booking = bean.getBooking();
						if (respuesta.containsKey(booking)) {
							respuesta.get(booking).add(bean);
						} else {
							List<BeanDocumentoAnalisis> lista = new ArrayList<>();
							lista.add(bean);
							respuesta.put(booking, lista);
						}
					}
				}
			}
		} catch (SQLException sqle) {
			sqle.printStackTrace();
			LOGGER.error("selectFoliosConfirmacionFinalMayor1DiaSinEnvioDocumentos", sqle);
			ConexionDB.renovar(con);
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error("selectFoliosConfirmacionFinalMayor1DiaSinEnvioDocumentos", e);
		} finally {
			ConexionDB.devolver(con);
		}
		return respuesta;
	}
	
	public int updateOtrosDocumentos(BeanOtrosDocumentos otro){
		Connection con = null;
		Statement st = null;
		StringBuffer insert = new StringBuffer();
		int result = 0;
		insert.append(" UPDATE cdi_otros_documentos SET ");
		insert.append("		fechaEliminado = getDate(), eliminado = 1 ");
		insert.append(" WHERE ");
		insert.append(" id = ").append(otro.getId());
		insert.append(" AND nombre = ").append("'").append(otro.getNombre()).append("'");
		try {
			con = ConexionDB.dameConexion();
			st = con.createStatement();
			result = st.executeUpdate(insert.toString());
			st.close();
			LOGGER.info("Se modifica el archivo otros de forma correcta. " + otro.getId() + " _ " + otro.getNombre());
		} catch (SQLException sqle) {
			LOGGER.error("[updateOtrosDocumentos] Error: ", sqle);
			ConexionDB.renovar(con);
		} catch (Exception e) {
			LOGGER.error("[updateOtrosDocumentos] Error: ", e);
		} finally {
			ConexionDB.devolver(con);
		}
		return result;
	}
	
	public int updateDisponibilidadOtrosDocumentos(Integer id) {
		int respuesta = 0;
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();
			try (PreparedStatement pst = con.prepareStatement(UPDATE_DISPONIBILIDAD_OTROS_DOCUMENTOS)) {
				pst.setInt(1, id);
				respuesta = pst.executeUpdate();
			}
		} catch (SQLException sqle) {
			sqle.printStackTrace();
			LOGGER.error(sqle);
			ConexionDB.renovar(con);
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error(e);
		} finally {
			ConexionDB.devolver(con);
		}
		return respuesta;
	}
	
	/**
	 * Obtiene los datos basicos del bean proveedor,booking y eta
	 * 
	 * @param rs
	 * @return
	 * @throws SQLException
	 */
	private BeanDocumentoAnalisis getBasicBeanDocumentoAnalisisFromRs(ResultSet rs) throws SQLException {
		String proveedor = rs.getString("proveedor");
		String booking = rs.getString("booking");
		Integer eta = rs.getInt("eta");
		BeanDocumentoAnalisis respuesta = new BeanDocumentoAnalisis();
		respuesta.setProveedor(proveedor);
		respuesta.setBooking(booking);
		respuesta.setEta(eta);
		return respuesta;
	}
}
