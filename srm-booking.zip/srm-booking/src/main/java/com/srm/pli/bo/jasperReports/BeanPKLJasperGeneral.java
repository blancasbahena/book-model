package com.srm.pli.bo.jasperReports;

import java.util.ArrayList;

import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

public class BeanPKLJasperGeneral {
	private ArrayList<BeanPKLJasperTotales> totales;
	
	
	public void setTotales(ArrayList<BeanPKLJasperTotales> totales) {
		this.totales = totales;
	}

	public JRDataSource getTotales() {
		return new JRBeanCollectionDataSource(totales);
	}
	
}
