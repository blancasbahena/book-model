package com.srm.pli.dao.sql;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.srm.pli.db.ConexionDB;
import com.truper.businessEntity.BeanFactura;

public final class SarDetailDaoSql {

	public static final String SELECT_SAR_DETAIL_PRICES;
	public static final String SELECT_SAR_DETAIL_TOP_1_MATERIAL_CENTRO, SELECT_SAR_DETAIL_MATERIAL_CENTRO;
	public static final String UPDATE_SAR_DETAIL_PRICES;
	public static final String SELECT_SAR_DETAIL_MATERIAL;
	public static final String UPDATE_SAR_DETAIL_ITEMS_DIRECTOS;
	public static final String BORRAR_SAR_DETAIL_ITEMS_DIRECTOS;
	public static final String OBTENER_ITEMS_SELECCIONADOS; 
	public static final String SELECT_FACTURA_BY_ID_AND_CONDITION= 
			new StringBuilder(" SELECT a.id, versionDocumento, condicionPago, nombre, madera,  ")
			.append(" paisorigen, b.fechaCreacion, rutaArchivo, tieneOtros ")
			.append(" FROM cdiDocumentosSDI a, cdi_facturas b WHERE  ")
			.append(" a.id = ? and a.id=b.id  and b.condicionPago  =? ").toString();
	private SarDetailDaoSql() {
	}

	static {
		StringBuilder sql = new StringBuilder();
		sql.append("SELECT folio");
		sql.append("      ,po");
		sql.append("      ,posicion");
		sql.append("      ,material");
		sql.append("      ,precioUnitario");
		sql.append(" FROM cdiSARDetalle");
		sql.append(" WHERE folio = ?");
		SELECT_SAR_DETAIL_PRICES = sql.toString();

		sql = new StringBuilder();
		sql.append(" SELECT TOP 1 material, centro FROM cdiSARDetalle ");
		sql.append(" WHERE folio = ? AND centro IS NOT NULL ");
		SELECT_SAR_DETAIL_TOP_1_MATERIAL_CENTRO = sql.toString();

		sql = new StringBuilder();
		sql.append("SELECT material, ");
		sql.append("       centro ");
		sql.append(" FROM   cdisardetalle ");
		sql.append(" WHERE  folio IN ? ");
		sql.append(" GROUP  BY material, ");
		sql.append("          centro");
		SELECT_SAR_DETAIL_MATERIAL_CENTRO = sql.toString();

		sql = new StringBuilder();
		sql.append("SELECT material, ");
		sql.append("       folio ");
		sql.append(" FROM   cdisardetalle ");
		sql.append(" WHERE  folio IN ? ");
		SELECT_SAR_DETAIL_MATERIAL = sql.toString();
		
		sql = new StringBuilder();
		sql.append(" UPDATE cdiSARDetalle SET precioUnitario = ?");
		sql.append(" WHERE folio = ? AND po = ? AND posicion = ? AND material = ?");
		UPDATE_SAR_DETAIL_PRICES = sql.toString();
		
		sql = new StringBuilder();
		sql.append(" UPDATE cdiSARDetalle SET eliminarProyeccion = ? where po = ? and posicion = ? and folio = ? ");
		UPDATE_SAR_DETAIL_ITEMS_DIRECTOS = sql.toString();
		
		sql = new StringBuilder();
		sql.append(" UPDATE cdiSARDetalle SET eliminarProyeccion = 0 where folio = ? ");
		BORRAR_SAR_DETAIL_ITEMS_DIRECTOS = sql.toString();
		
		sql = new StringBuilder();
		sql.append(" SELECT folio, po, posicion, eliminarProyeccion from cdiSARDetalle where folio = ? and eliminarProyeccion = 1");
		OBTENER_ITEMS_SELECCIONADOS = sql.toString();
	}
}
