package com.srm.pli.dao;

import static com.srm.pli.dao.sql.ShpmntsWODocsSql.SELECT_PUERTOS_DESCARGA_HOY;
import static com.srm.pli.dao.sql.ShpmntsWODocsSql.SELECT_SARS_CONFIRMACION_FINAL_SIN_DOCUMENTOS;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashSet;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.srm.pli.db.ConexionDB;
import com.srm.pli.utils.FuncionesComunesPLI;
import com.truper.businessEntity.BeanPedidoDirecto;
import com.truper.businessEntity.BeanSarConfirmacionFinalSinDocumentos;
import com.truper.businessEntity.ImportacionesProveedoresBean;

public class ShpmntsWODocsDao {

	private static final ShpmntsWODocsDao instance = new ShpmntsWODocsDao();
	private static final Logger LOGGER = LogManager.getRootLogger();

	private ShpmntsWODocsDao() {
	}

	public static ShpmntsWODocsDao getInstance() {
		return instance;
	}

	public HashSet<BeanPedidoDirecto> selectPuertosDescargaHastaHoy() {
		HashSet<BeanPedidoDirecto> respuesta = null;
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();
			try (Statement st = con.createStatement()) {
				try (ResultSet rs = st.executeQuery(SELECT_PUERTOS_DESCARGA_HOY)) {
					respuesta = new HashSet<>();
					BeanPedidoDirecto bean = null;
					while (rs.next()) {
						String puertoDescarga = rs.getString("puertoDescarga");
						boolean aereo = rs.getBoolean("esaereo");
						boolean pedidoDirecto = rs.getBoolean("esPedidoDirecto");

						bean = new BeanPedidoDirecto();
						bean.setPuertoDescarga(puertoDescarga);
						bean.setAereo(aereo);
						bean.setPedidoDirecto(pedidoDirecto);
						respuesta.add(bean);
					}
				}
			}
		} catch (SQLException sqle) {
			sqle.printStackTrace();
			LOGGER.error(sqle);
			ConexionDB.renovar(con);
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error(e);
		} finally {
			ConexionDB.devolver(con);
		}
		return respuesta;
	}

	public HashSet<BeanSarConfirmacionFinalSinDocumentos> selectReporteSarsConConfirmacionFinalSinDocumentos() {
		HashSet<BeanSarConfirmacionFinalSinDocumentos> respuesta = null;
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();
			try (Statement st = con.createStatement()) {
				try (ResultSet rs = st.executeQuery(SELECT_SARS_CONFIRMACION_FINAL_SIN_DOCUMENTOS)) {
					respuesta = new HashSet<>();
					BeanSarConfirmacionFinalSinDocumentos bean = null;
					while (rs.next()) {
						Integer folio = rs.getInt("folio");
						if (rs.wasNull() || folio.compareTo(0) != 1)
							continue;
						Integer fechaEtd = rs.getInt("etd");
						Integer fechaEta = rs.getInt("eta");
						String proveedor = rs.getString("proveedor");
						String proveedorNombre = null;
						ImportacionesProveedoresBean bean_prov = FuncionesComunesPLI.getProveedor(proveedor);
						if (bean_prov != null)
							proveedorNombre = bean_prov.getNombreProveedor();
						String booking = rs.getString("booking");
						Integer fechaConfirmacionFinal = rs.getInt("fechaConfirmacionFinal");
						Integer diasDesdeConfirmacionFinal = rs.getInt("diasDesdeConfirmacionFinal");

						String puertoDescarga = rs.getString("puertoDescarga");
						boolean aereo = rs.getBoolean("esaereo");
						boolean pedidoDirecto = rs.getBoolean("esPedidoDirecto");

						bean = new BeanSarConfirmacionFinalSinDocumentos();
						bean.setFolio(folio);
						bean.setFechaEtd(fechaEtd);
						bean.setFechaEta(fechaEta);
						bean.setProveedor(proveedor);
						bean.setProveedorNombre(proveedorNombre);
						bean.setBooking(booking);
						bean.setFechaConfirmacionFinal(fechaConfirmacionFinal);
						bean.setDiasDesdeConfirmacionFinal(diasDesdeConfirmacionFinal);
						bean.setPuertoDescarga(puertoDescarga);
						bean.setAereo(aereo);
						bean.setPedidoDirecto(pedidoDirecto);
						respuesta.add(bean);
					}
				}
			}
		} catch (SQLException sqle) {
			sqle.printStackTrace();
			LOGGER.error(sqle);
			ConexionDB.renovar(con);
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error(e);
		} finally {
			ConexionDB.devolver(con);
		}
		return respuesta;
	}

}
