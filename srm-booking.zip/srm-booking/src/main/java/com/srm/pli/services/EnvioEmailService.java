package com.srm.pli.services;

import java.util.Map;
import java.util.Set;
import com.srm.pli.bo.DataEmailBean;

public interface EnvioEmailService
{
	void enviarEmail(DataEmailBean dataEmailBean);
	void enviarEmailTemplate(String formatoHTML, String subject, String sender, Map<String, Set<String>> correosMap);
}
