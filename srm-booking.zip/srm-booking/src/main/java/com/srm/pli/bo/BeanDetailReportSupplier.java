package com.srm.pli.bo;

import java.io.Serializable;
import java.util.Date;
import java.util.Set;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BeanDetailReportSupplier implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private Date fechaInicio;
	private Integer folio;
	private Integer proveedor;
	private Date etd;
	private Integer naviera;
	private String booking;
	private String planeador;
	private Set<String> address;
	
}
