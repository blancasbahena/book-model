package com.srm.pli.dao;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.srm.pli.db.ConexionDB;
import com.truper.businessEntity.SeguimientoPOsSinSARBean;

public class POsSinSARDAO extends DAO {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3764849069502582717L;

	@Override
	public List<?> select(Object o) {
		SeguimientoPOsSinSARBean bean = SeguimientoPOsSinSARBean.class.cast(o);
		List<SeguimientoPOsSinSARBean> lstSeguimientoPOsSinSAR = new ArrayList<SeguimientoPOsSinSARBean>();

		Connection con = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		DAOUtils utils = new  DAOUtils();

		StringBuilder select = new StringBuilder("SELECT po, mes, proveedor, etd,");
		select.append(" montoBO, planningResponsible, fungRuiResponsible, onTime,");
		select.append(" comments, folio, status, pidate");
		select.append(" FROM seguimientoPOsSinSAR ");
		select.append(" WHERE 1=1 ");
		
		utils.setSelect(true);
		
		try {
			con = ConexionDB.dameConexion();
			
			if (bean.getModificationUser() != null && !"".equals(bean.getModificationUser())) {
				select.append(utils.ajustaColumna(" AND (planningResponsible = ? OR fungRuiResponsible = ?) "));
			}
			if (bean.getPo() != null && !"".equals(bean.getPo())) {
				select.append(utils.ajustaColumna(" AND po = ? "));
			}
			if (bean.getSupplier() != null && !"".equals(bean.getSupplier())) {
				select.append(utils.ajustaColumna(" AND proveedor = ? "));
			}
			if (bean.getFrom() != null && bean.getTo() != null) {
				select.append(utils.ajustaColumna(" AND etd BETWEEN ? AND ? "));
			}
			pst = con.prepareStatement(select.toString());
			
			int cont = 1;
			
			utils.inicializaQuery(select.toString());
			
			if (bean.getModificationUser() != null && !"".equals(bean.getModificationUser())) {
				utils.ajustaParametro(cont++, pst, bean.getModificationUser(), String.class);
				utils.ajustaParametro(cont++, pst, bean.getModificationUser(), String.class);
			}
			if (bean.getPo() != null && !"".equals(bean.getPo())) {
				utils.ajustaParametro(cont++, pst, bean.getPo(), String.class);
			}
			if (bean.getSupplier() != null && !"".equals(bean.getSupplier())) {
				utils.ajustaParametro(cont++, pst, bean.getSupplier(), String.class);
			}
			if (bean.getFrom() != null && bean.getTo() != null) {
				utils.ajustaParametro(cont++, pst, bean.getFrom(), Integer.class);
				utils.ajustaParametro(cont++, pst, bean.getTo(), Integer.class);
			}
			
			rs = pst.executeQuery();
			
			while (rs.next()) {
				String po = rs.getString("po");
				Integer mes = rs.getInt("mes");
				String proveedor = rs.getString("proveedor");
				Integer etd = rs.getInt("etd");
				BigDecimal montoBO = rs.getBigDecimal("montoBO");
				String planningResponsible = rs.getString("planningResponsible");
				String fungRuiResponsible = rs.getString("fungRuiResponsible");
				Integer onTime = rs.getBoolean("onTime") ? 1 : 2;
				if (rs.wasNull()) {
					onTime = Integer.valueOf(-1);
				}
				String comments = rs.getString("comments");
				Integer folio = rs.getInt("folio");
				Integer status = rs.getInt("status");
				if (rs.wasNull()) {
					status = Integer.valueOf(-1);
				}
				Integer piDate = rs.getInt("pidate");
				
				SeguimientoPOsSinSARBean poSinSAR = new SeguimientoPOsSinSARBean();
				poSinSAR.setPo(po);
				poSinSAR.setMes(mes);
				poSinSAR.setSupplier(proveedor);
				poSinSAR.setEtd(etd);
				poSinSAR.setMontoBO(montoBO);
				poSinSAR.setPlanningResponsible(planningResponsible);
				poSinSAR.setFungRuiResponsible(fungRuiResponsible);
				poSinSAR.setOnTime(onTime);
				poSinSAR.setComments(comments);
				poSinSAR.setFolio(folio);
				poSinSAR.setStatus(status);
				poSinSAR.setPiDate(piDate);
				
				lstSeguimientoPOsSinSAR.add(poSinSAR);
			}

			ConexionDB.devuelveConexion(con);

		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				BOOKING_LOGGER.error(ex.getMessage(), ex);
			}
			BOOKING_LOGGER.error(e.getMessage(), e);
		} catch (Exception e) {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				BOOKING_LOGGER.error(ex.getMessage(), ex);
			}
			BOOKING_LOGGER.error(e.getMessage(), e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				BOOKING_LOGGER.error(sqlEx2.getMessage(), sqlEx2);
			}
		}
		return lstSeguimientoPOsSinSAR;
	}

	@Override
	public boolean insert(Object o) {
		SeguimientoPOsSinSARBean bean = SeguimientoPOsSinSARBean.class.cast(o);
		Connection con = null;
		PreparedStatement pst = null;
		DAOUtils utilDao = new DAOUtils();
		
		StringBuilder insert = new StringBuilder("INSERT INTO seguimientoPOsSinSAR (po, mes, proveedor, etd,");
		insert.append(" montoBO, planningResponsible, fungRuiResponsible, modificationUser, modificationTimeStamp,");
		insert.append(" pidate)");
		insert.append(" VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
		
		boolean exito = false;

		try {
			con = ConexionDB.dameConexion();
			pst = con.prepareStatement(insert.toString());
			int cont = 1;
			utilDao.ajustaParametro(cont++, pst, bean.getPo(), String.class);
			utilDao.ajustaParametro(cont++, pst, bean.getMes(), Integer.class);			
			utilDao.ajustaParametro(cont++, pst, bean.getSupplier(), String.class);
			utilDao.ajustaParametro(cont++, pst, bean.getEtd(), Integer.class);
			utilDao.ajustaParametro(cont++, pst, bean.getMontoBO().setScale(2,BigDecimal.ROUND_UP), BigDecimal.class);
			utilDao.ajustaParametro(cont++, pst, bean.getPlanningResponsible(), String.class);
			utilDao.ajustaParametro(cont++, pst, bean.getFungRuiResponsible(), String.class);
			utilDao.ajustaParametro(cont++, pst, bean.getModificationUser(), String.class);
			utilDao.ajustaParametro(cont++, pst, System.currentTimeMillis(), Long.class);
			utilDao.ajustaParametro(cont++, pst, bean.getPiDate(), Integer.class);
			
			utilDao.inicializaQuery(insert.toString());		
			
			exito = pst.executeUpdate() > 0;
			
			ConexionDB.devuelveConexion(con);
		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				BOOKING_LOGGER.error(ex.getMessage(), ex);
			}
			BOOKING_LOGGER.error(e.getMessage(), e);
		} catch (Exception e) {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				BOOKING_LOGGER.error(ex.getMessage(), ex);
			}
			BOOKING_LOGGER.error(e.getMessage(), e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				BOOKING_LOGGER.error(sqlEx2.getMessage(), sqlEx2);
			}
		}

		return exito;
	}

	@Override
	public boolean update(Object o) {
		SeguimientoPOsSinSARBean bean = SeguimientoPOsSinSARBean.class.cast(o);
		Connection con = null;
		PreparedStatement pst = null;
		DAOUtils utilDao = new DAOUtils();
		
		StringBuilder update = new StringBuilder("UPDATE seguimientoPOsSinSAR SET");
				
		boolean exito = false;

		try {
			con = ConexionDB.dameConexion();
			
			if (bean.getEtd() != null) {
				update.append(utilDao.ajustaColumna(" etd = ?"));
			}
			if (bean.getMontoBO() != null) {
				update.append(utilDao.ajustaColumna(" montoBO = ?"));
			}
			if (bean.getPlanningResponsible() != null) {
				update.append(utilDao.ajustaColumna(" planningResponsible = ?"));
			}
			if (bean.getFungRuiResponsible() != null) {
				update.append(utilDao.ajustaColumna(" fungRuiResponsible = ?"));
			}
			if (bean.getOnTime() != null) {
				update.append(utilDao.ajustaColumna(" onTime = ?"));
			}
			if (bean.getComments() != null) {
				update.append(utilDao.ajustaColumna(" comments = ?"));
			}
			if (bean.getFolio() != null) {
				update.append(utilDao.ajustaColumna(" folio = ?"));
			}
			if (bean.getStatus() != null) {
				update.append(utilDao.ajustaColumna(" status = ?"));
			}
			if (bean.getPiDate() != null) {
				update.append(utilDao.ajustaColumna(" piDate = ?"));
			}
			
			update.append(utilDao.ajustaColumna(" modificationUser = ?"));
			update.append(utilDao.ajustaColumna(" modificationTimeStamp = ?"));
			
			update.append(" WHERE  ");
			update.append(" po = ?");
			update.append(" AND mes = ?");
			
			pst = con.prepareStatement(update.toString());
			int cont = 1;
			
			if (bean.getEtd() != null) {
				utilDao.ajustaParametro(cont++, pst, bean.getEtd(), Integer.class);
			}
			if (bean.getMontoBO() != null) {
				utilDao.ajustaParametro(cont++, pst, bean.getMontoBO().setScale(2,BigDecimal.ROUND_UP), BigDecimal.class);
			}
			if (bean.getPlanningResponsible() != null) {
				utilDao.ajustaParametro(cont++, pst, bean.getPlanningResponsible(), String.class);
			}
			if (bean.getFungRuiResponsible() != null) {
				utilDao.ajustaParametro(cont++, pst, bean.getFungRuiResponsible(), String.class);
			}
			if (bean.getOnTime() != null) {				
				utilDao.ajustaParametro(cont++, pst, bean.getOnTime() == 1 ? Boolean.TRUE : bean.getOnTime() == 2 ? Boolean.FALSE : null, Boolean.class);
			}
			if (bean.getComments() != null) {
				utilDao.ajustaParametro(cont++, pst, bean.getComments(), String.class);
			}
			if (bean.getFolio() != null) {
				utilDao.ajustaParametro(cont++, pst, bean.getFolio(), Integer.class);
			}
			if (bean.getStatus() != null) {
				utilDao.ajustaParametro(cont++, pst, bean.getStatus(), Integer.class);
			}
			if (bean.getPiDate() != null) {
				utilDao.ajustaParametro(cont++, pst, bean.getPiDate(), Integer.class);
			}
			
			utilDao.ajustaParametro(cont++, pst, bean.getModificationUser(), String.class);
			utilDao.ajustaParametro(cont++, pst, System.currentTimeMillis(), Long.class);
			utilDao.ajustaParametro(cont++, pst, bean.getPo(), String.class);
			utilDao.ajustaParametro(cont++, pst, bean.getMes(), Integer.class);
			
			utilDao.inicializaQuery(update.toString());		
			
			exito = pst.executeUpdate() > 0;
			ConexionDB.devuelveConexion(con);
		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				BOOKING_LOGGER.error(ex.getMessage(), ex);
			}
			BOOKING_LOGGER.error(e.getMessage(), e);
		} catch (Exception e) {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				BOOKING_LOGGER.error(ex.getMessage(), ex);
			}
			BOOKING_LOGGER.error(e.getMessage(), e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				BOOKING_LOGGER.error(sqlEx2.getMessage(), sqlEx2);
			}
		}

		return exito;
	}

}
