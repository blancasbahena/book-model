package com.srm.pli.bo;

import java.io.Serializable;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
public class HistoryLogBean implements Serializable
{
	private static final long serialVersionUID = 1L;
	private int Id;
	private int tipoAccion;
	private int folio;
	private String sarType;
	private String username;
	private String comentarios;
}
