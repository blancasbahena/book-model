package com.srm.pli.dao;

import static com.srm.pli.dao.sql.PriceReleaseSQL.DELETE_SAR_PRECIOS_EN_REVISION;
import static com.srm.pli.dao.sql.PriceReleaseSQL.INSERT_PRICE_RELEASE_FROM_REQUEST;
import static com.srm.pli.dao.sql.PriceReleaseSQL.INSERT_PRICE_RELEASE_REQUEST;
import static com.srm.pli.dao.sql.PriceReleaseSQL.SELECT_PROVEEDOR_CON_MATRIZ;
import static com.srm.pli.dao.sql.PriceReleaseSQL.SELECT_SAR_PO_POSICION_WITH_OTHER_ITEM;
import static com.srm.pli.dao.sql.PriceReleaseSQL.SELECT_SAR_PRECIOS_ACTUALIZADOS;
import static com.srm.pli.dao.sql.PriceReleaseSQL.SELECT_SAR_PRECIOS_EN_REVISION;
import static com.srm.pli.dao.sql.PriceReleaseSQL.SELECT_SAR_PRECIOS_EN_REVISION_FALTANTES_ACTUALIZADOS;
import static com.srm.pli.dao.sql.PriceReleaseSQL.SELECT_SAR_PRECIOS_EN_REVISION_REPORTE;
import static com.srm.pli.dao.sql.PriceReleaseSQL.SELECT_SAR_PRECIOS_EN_REVISION_TIEMPO_EXCEDIDO;
import static com.srm.pli.dao.sql.PriceReleaseSQL.UPDATE_IF_IS_REVISION_PRECIOS;
import static com.srm.pli.dao.sql.PriceReleaseSQL.UPDATE_OTHER_ITEM_PRICE;
import static com.srm.pli.dao.sql.PriceReleaseSQL.UPDATE_SAR_LIBERA_HACIA_CONFIRMACION_FINAL;
import static com.srm.pli.dao.sql.PriceReleaseSQL.UPDATE_SAR_LIBERA_HACIA_PLANEACION;
import static com.srm.pli.dao.sql.PriceReleaseSQL.UPDATE_SAR_PRECIOS_LIBERADOS;
import static com.srm.pli.dao.sql.PriceReleaseSQL.UPDATE_SAR_PRECIOS_REVISION;
import static com.srm.pli.dao.sql.PriceReleaseSQL.UPDATE_SAR_PRECIOS_REVISION_SEGUNDA_VEZ;
import static com.srm.pli.dao.sql.PriceReleaseSQL.UPDATE_SAR_REJECT;
import static com.srm.pli.dao.sql.PriceReleaseSQL.UPDATE_LIBERATION_BO_CONFIRMATION;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

import com.srm.pli.bo.BeanAuditoriaProveedorActualizado;
import com.srm.pli.bo.SarBO;
import com.srm.pli.bo.SarDetalleBO;
import com.srm.pli.bo.jasperReports.BeanReporteControlPrecioSar;
import com.srm.pli.db.ConexionDB;
import com.srm.pli.helper.FormatSAR;
import com.srm.pli.helper.PriceReleaseHelper;
import com.srm.pli.services.DatosTelService;
import com.srm.pli.utils.FuncionesComunesPLI;
import com.srm.pli.utils.ProductoUtils;
import com.srm.pli.utils.UnidadNegocioUtils;
import com.srm.pli.utils.UtilsSarSQL;
import com.truper.bpm.enums.EstatusAuditoriaEnum;
import com.truper.bpm.enums.TipoPosicionEnum;
import com.truper.businessEntity.BeanDatosTel;
import com.truper.businessEntity.BeanPoPosicionWithOther;
import com.truper.businessEntity.BeanPriceRelease;
import com.truper.businessEntity.BeanPriceReleasePosicion;
import com.truper.businessEntity.CompradoresBean;
import com.truper.businessEntity.ImportacionesProveedoresBean;
import com.truper.businessEntity.ProductoBean;
import com.truper.businessEntity.ProductoCentro;
import com.truper.businessEntity.UnidadNegocio;
import com.truper.utils.date.UtilsFechas;
import com.truper.utils.sql.UtilsSQL;
import com.truper.utils.string.UtilsString;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class PriceReleaseDAO {

	private static PriceReleaseDAO instance;

	private PriceReleaseDAO() {
	}

	public static PriceReleaseDAO getInstance() {
		if (instance == null) {
			instance = new PriceReleaseDAO();
		}
		return instance;
	}

	public SortedSet<BeanPoPosicionWithOther> selectPoPosicionWithOther(int folioSAR) {
		SortedSet<BeanPoPosicionWithOther> resultado = null;
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();
			try (PreparedStatement pst = con.prepareStatement(SELECT_SAR_PO_POSICION_WITH_OTHER_ITEM)) {
				pst.setInt(1, folioSAR);
				try (ResultSet rs = pst.executeQuery()) {
					resultado = new TreeSet<BeanPoPosicionWithOther>();
					BeanPoPosicionWithOther item = null;
					while (rs.next()) {
						String po = rs.getString("po");
						if (po != null)
							po = po.trim();
						int posicion = rs.getInt("posicion");
						String material = rs.getString("material");
						material = material.trim();
						int cantidad = rs.getInt("cantidad");
						BigDecimal precioUnitario = rs.getBigDecimal("preciounitario");
						String tipo = rs.getString("tipo");
						String subTipo = rs.getString("subtipo");
						subTipo = subTipo.trim();
						boolean preciosRevisados = rs.getBoolean("preciosRevisados");
						String planeador = rs.getString("planeador");
						String centro = rs.getString("centro");
						String unidadMedida = rs.getString("unidadMedida");
						item = new BeanPoPosicionWithOther(po, posicion, material, cantidad, precioUnitario);
						PriceReleaseHelper.getInstance().setTipo(item, tipo);
						item.setSubTipo(subTipo);
						boolean isPago = PriceReleaseHelper.getInstance().isOtherItemWithPago(subTipo);
						item.setPago(isPago);
						item.setPreciosRevisados(preciosRevisados);
						item.setPlaneador(planeador);
						item.setCentro(centro);
						item.setUnidadMedida(unidadMedida);
						String material_descripcion = material;
						if (item.getTipo() == TipoPosicionEnum.PO) {
							String desc = ProductoUtils.getInstance().getDescripcion(material, true);
							material_descripcion = UtilsString.append(material, " ", desc);
						}
						item.setMaterial_descripcion(material_descripcion);
						resultado.add(item);
					}
				}
			}
		} catch (SQLException sqle) {
			log.error("folio: {}", folioSAR, sqle);
			ConexionDB.renovar(con);
		} catch (Exception e) {
			log.error("folio: {}", folioSAR, e);
		} finally {
			ConexionDB.devolver(con);
		}
		return resultado;
	}

	public Map<Integer, BeanPriceRelease> selectPreciosEnRevision() {
		Map<Integer, BeanPriceRelease> resultado = null;
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();
			try (PreparedStatement pst = con.prepareStatement(SELECT_SAR_PRECIOS_EN_REVISION)) {
				try (ResultSet rs = pst.executeQuery()) {
					resultado = new HashMap<Integer, BeanPriceRelease>();
					BeanPriceRelease item = null;
					BeanPriceReleasePosicion posicion = null;
					while (rs.next()) {
						int folio = rs.getInt("folio");
						String po = rs.getString("po");
						if (po != null)
							po = po.trim();
						String proveedor = rs.getString("proveedor");
						if (proveedor != null) {
							proveedor = proveedor.trim();
						}
						String planeador = rs.getString("planeador");
						if (planeador != null) {
							planeador = planeador.trim();
						}
						int posicion_i = rs.getInt("posicion");
						String material = rs.getString("material");
						String centro = rs.getString("centro");
						material = material.trim();
						int cantidad = rs.getInt("cantidad");
						String tipo = rs.getString("tipo");
						TipoPosicionEnum eTipo;
						if (TipoPosicionEnum.PO.toString().equalsIgnoreCase(tipo)) {
							eTipo = TipoPosicionEnum.PO;
						} else {
							eTipo = TipoPosicionEnum.OTHER_ITEM;
						}
						String subTipo = rs.getString("subtipo");
						subTipo = subTipo.trim();
						boolean pago = rs.getBoolean("pago");
						BigDecimal precioUnitario = rs.getBigDecimal("preciounitario");
						BigDecimal precioUnitarioSolicitado = rs.getBigDecimal("preciounitariosolicitado");
						boolean matriz = rs.getBoolean("matriz");
						String disagreeComments = rs.getString("disagreeComments");
						Date createDate = UtilsSQL.getDateFromTimestamp(rs.getTimestamp("createdate"));
						Date updatedate = rs.getTimestamp("updatedate");
						if (resultado.containsKey(folio)) {
							item = resultado.get(folio);
						} else {
							item = new BeanPriceRelease();
							resultado.put(folio, item);
							item.setFolio(folio);
							item.setProveedor(proveedor);
							item.setCreateDate(createDate);
						}
						posicion = new BeanPriceReleasePosicion(folio, po, posicion_i, material, cantidad,
								precioUnitario, eTipo, subTipo, pago, precioUnitarioSolicitado, createDate);
						posicion.setPlaneador(planeador);
						posicion.setCentro(centro);
						posicion.setUpdateDate(updatedate);
						String material_descripcion = material;
						if (posicion.getTipo() == TipoPosicionEnum.PO) {
							String desc = ProductoUtils.getInstance().getDescripcion(material, true);
							material_descripcion = UtilsString.append(material, " ", desc);
						} else {
							String unidadMedida = rs.getString("unidadMedida");
							posicion.setUnidadMedida(unidadMedida);
						}
						posicion.setMaterial_descripcion(material_descripcion);
						posicion.setMatriz(matriz);
						posicion.setDisagreeComments(disagreeComments);
						
						ProductoBean p = FuncionesComunesPLI.productos.get(material);
						if(p != null){
							posicion.setSeasonal(p.isSeasonal());
							posicion.setTotalVar12Semanas(p.getTotalVar12Semanas());
							posicion.setTotalVar8Semanas(p.getTotalVar8Semanas());
							
							if(!p.isMateriaPrima()) {
								posicion.setAbc(Optional.ofNullable(p.getProductoCentro()).map(productoCentro -> productoCentro.get("P5")).map(p5 -> p5.getAbc()).orElse(' '));
							} else if(p.isMateriaPrima()) {
								posicion.setAbc(Optional.ofNullable(p.getProductoCentro())
										.map(productoCentro -> productoCentro.get(centro)).map(clas -> clas.getAbc()).orElse(' '));
							}
							
						}else{
							posicion.setSeasonal(false);
							posicion.setTotalVar12Semanas("ND");
							posicion.setTotalVar8Semanas("ND");
							posicion.setAbc(' ');
						}
						SarBO sar = UtilsSarSQL.getSar(String.valueOf(folio), false);
						List<SarDetalleBO> lstDet = new ArrayList<>();
						List<SarDetalleBO> listaDet = FuncionesComunesPLI.getDetalleSAR(sar);
						List<SarDetalleBO> listaDetOtros = SAR_CDI_DAO.consultaDetalleOtros(sar.getFolio().toString());
						FuncionesComunesPLI.sacaTotales(sar, (ArrayList<SarDetalleBO>) listaDet, listaDetOtros);
						sar.setDetalleBO((ArrayList<SarDetalleBO>) listaDet);
						sar.setDetalleOthers((ArrayList<SarDetalleBO>) listaDetOtros);

						FormatSAR format = new FormatSAR(sar, null);
						sar.setDetalleBO(lstDet);
						posicion.setPuertoOrigen(format.getPuertoOrigen());
						posicion.setOverStock(format.getOverStock());
						posicion.setOverStockPct(format.getOverStockPct());
						posicion.setMegaAltaVolumetria(false);
						posicion.setDaysAdvanced(-1);//Los d�as son positivos, por lo tanto no es un  retraso
						posicion.setDaysDelayed(1);//Los d�as son negativos, por lo tanto no es un adelanto
						
						if(listaDet != null && listaDet.size() > 0) {
							SarDetalleBO detSar = listaDet.get(0);
							posicion.setMegaAltaVolumetria(detSar.isMegaAltaVolumetria());
							posicion.setDaysAdvanced(detSar.getDaysAdvanced());
							posicion.setDaysDelayed(detSar.getDaysDelayed());
						}
						
						item.getPosiciones().add(posicion);
					}
				}
			}
		} catch (SQLException sqle) {
			log.error("SQL error", sqle);
			ConexionDB.renovar(con);
		} catch (Exception e) {
			log.error("Exception", e);
		} finally {
			ConexionDB.devolver(con);
		}
		return resultado;
	}

	public List<BeanReporteControlPrecioSar> selectPOsPIsPendientesDeRevisionCompras() {
		List<BeanReporteControlPrecioSar> respuesta = null;
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();
			try (PreparedStatement pst = con.prepareStatement(SELECT_SAR_PRECIOS_EN_REVISION_REPORTE)) {
				try (ResultSet rs = pst.executeQuery()) {
					respuesta = new ArrayList<>();
					BeanReporteControlPrecioSar bean = null;
					while (rs.next()) {
						bean = new BeanReporteControlPrecioSar();
						
						int folio = rs.getInt("folio");
						Date createDate = rs.getTimestamp("createDate");
						String po = rs.getString("po");
						Integer etd_i = rs.getInt("etd");
						Date etd = UtilsFechas.setConvierteFechaIntToDate(etd_i);
						Integer daysLeftForEtd = rs.getInt("daysLeftForEtd");
						String proveedor = rs.getString("proveedor");
						int material = rs.getInt("material");
						String centro = rs.getString("centro");
						String planeador = rs.getString("planeador");
						Integer daysLeftFromCreateDate = rs.getInt("daysLeftFromCreateDate");
						
						bean.setFolio(folio);
						bean.setCreateDate(createDate);
						bean.setPo(po);
						bean.setEtd(etd);
						bean.setDaysLeftForEtd(daysLeftForEtd);
						bean.setProveedor(proveedor);
						
						ImportacionesProveedoresBean bean_prov = FuncionesComunesPLI.getProveedor(proveedor);
						if (bean_prov != null)
							bean.setProveedorDescripcion(bean_prov.getNombreProveedor());
						String bu = ProductoUtils.getInstance().getBUName(String.valueOf(material), centro);
						if (!bu.isEmpty()) {
							bean.setBu(bu);
							String buClave = ProductoUtils.getInstance().getBU(String.valueOf(material), centro);
							bean.setBuClave(buClave);
							bean.setPlaneador(planeador == null ? null : planeador.trim());
							bean.setDaysLeftFromLogDate(daysLeftFromCreateDate);
							
							List<CompradoresBean> compradores = UnidadNegocioUtils.getInstance().getCompradores(buClave);
							UnidadNegocio director = UnidadNegocioUtils.getInstance().getUnidadNegocio(buClave);
							
							if(compradores != null && compradores.size() > 0) {
								int auxLength = 0;
								StringBuilder sbCompradores = new StringBuilder();
								for (CompradoresBean compradoresBean : compradores) {
									auxLength++;
									sbCompradores.append(compradoresBean.getNombre());
									if(compradores.size() > auxLength) {
										sbCompradores.append(";");
									}
								}
								bean.setComprador(sbCompradores.toString());
							}
							bean.setDirectorBU(director.getNombre());
							
							/**** IDA */
							SarBO bo = new SarBO();
							bo.setSarsABuscar(String.valueOf(bean.getFolio()));
							ArrayList<SarBO> listSars = SAR_CDI_DAO.selectSarDinamico(bo);
							//le indico al Webservice que voy a pedir estos detalles
							FuncionesComunesPLI.dameDatosCDIDetalle(listSars);
							List<SarDetalleBO> allDetails = new ArrayList<>();
									
							// Detalles
							for (SarBO tmpSar : listSars) {
								List<SarDetalleBO> aux = FuncionesComunesPLI.getDetalleSAR(tmpSar);
								tmpSar.setDetalleBO(aux);
								allDetails.addAll(aux);
							}
							
							BeanDatosTel datos = DatosTelService.getInstance().getIdaMinimoAndBackorderAlArribo(allDetails);
							if(datos != null) {
								bean.setIdaMinimo(datos.getIdaMinimo());
							}
							/********************/
							
							String comentarios = rs.getString("disagreeComments");
							bean.setLogDate(createDate);
							bean.setComentarios(comentarios);
							respuesta.add(bean);
						}
						
					}
				}
			}
		} catch (SQLException sqle) {
			log.error("SQL error", sqle);
			ConexionDB.renovar(con);
		} catch (Exception e) {
			log.error("Exception", e);
		} finally {
			ConexionDB.devolver(con);
		}
		return respuesta;
	}

	/**
	 * 
	 * @param folioSAR
	 * @return
	 *         <ul>
	 *         <li>Posicion 0 = faltantes</li>
	 *         <li>Posicion 1 = actualizados</li>
	 *         <li>Posicion 2 = actualizadosPO</li>
	 *         <li>Posicion 3 = actualizadosOthers</li>
	 *         </ul>
	 */
	public int[] selectFaltantesActualizadosLiberacion(int folioSAR) {
		int faltantes_actualizados[] = new int[4];
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();
			try (PreparedStatement pst = con.prepareStatement(SELECT_SAR_PRECIOS_EN_REVISION_FALTANTES_ACTUALIZADOS)) {
				pst.setInt(1, folioSAR);
				try (ResultSet rs = pst.executeQuery()) {
					if (rs.next()) {
						faltantes_actualizados[0] = rs.getInt("faltantes");
						faltantes_actualizados[1] = rs.getInt("actualizados");
						faltantes_actualizados[2] = rs.getInt("actualizadosPO");
						faltantes_actualizados[3] = rs.getInt("actualizadosOthers");
					}
				}
			}
		} catch (SQLException sqle) {
			log.error("Folio: {}", folioSAR, sqle);
			ConexionDB.renovar(con);
		} catch (Exception e) {
			log.error("Folio: {}", folioSAR, e);
		} finally {
			ConexionDB.devolver(con);
		}
		return faltantes_actualizados;
	}

	public BeanAuditoriaProveedorActualizado selectPreciosActualizados(int folioSAR) {
		BeanAuditoriaProveedorActualizado respuesta = null;
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();
			try (PreparedStatement pst = con.prepareStatement(SELECT_SAR_PRECIOS_ACTUALIZADOS)) {
				pst.setInt(1, folioSAR);
				try (ResultSet rs = pst.executeQuery()) {
					respuesta = new BeanAuditoriaProveedorActualizado();
					if (rs.next()) {
						String proveedor = rs.getString("proveedor");
						int actualizados = rs.getInt("actualizados");
						respuesta.setProveedor(proveedor);
						respuesta.setActualizados(actualizados);
					}
				}
			}
		} catch (SQLException sqle) {
			log.error("Folio: {}", folioSAR, sqle);
			ConexionDB.renovar(con);
		} catch (Exception e) {
			log.error("Folio: {}", folioSAR, e);
		} finally {
			ConexionDB.devolver(con);
		}
		return respuesta;
	}

	public Set<String> selectProveedorConMatriz(String proveedor, Set<String> codigos) {
		if (codigos == null || codigos.isEmpty()) {
			return codigos;
		}
		Set<String> codigos_respuesta = null;
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();
			try (Statement st = con.createStatement()) {
				StringBuilder sql = new StringBuilder(SELECT_PROVEEDOR_CON_MATRIZ);
				sql.replace(sql.indexOf("?"), sql.indexOf("?") + 1, proveedor);
				sql.replace(sql.lastIndexOf("?"), sql.lastIndexOf("?") + 1, UtilsSQL.convierteToIN(codigos));
				try (ResultSet rs = st.executeQuery(sql.toString())) {
					codigos_respuesta = new HashSet<>();
					while (rs.next()) {
						codigos_respuesta.add(rs.getString("codigo"));
					}
				}
			}
		} catch (SQLException sqle) {
			log.error("proveedor: {} | codigos: {} " + proveedor, codigos, sqle);
			ConexionDB.renovar(con);
		} catch (Exception e) {
			log.error("proveedor: {} | codigos: {} " + proveedor, codigos, e);
		} finally {
			ConexionDB.devolver(con);
		}
		return codigos_respuesta;
	}

	public Map<Integer, Set<String>> selectSAREnRevisionConTiempoExcedido() {
		Map<Integer, Set<String>> respuesta = null;
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();
			try (Statement st = con.createStatement()) {
				try (ResultSet rs = st.executeQuery(SELECT_SAR_PRECIOS_EN_REVISION_TIEMPO_EXCEDIDO)) {
					respuesta = new HashMap<>();
					while (rs.next()) {
						Integer folio = rs.getInt("folio");
						String material = rs.getString("material");
						String centro = rs.getString("centro");
						
						if (folio == null || !UtilsString.isStringValida(material) || !UtilsString.isStringValida(centro)) {
							continue;
						}
						material = material.trim();
						centro = centro.trim();
						
						String grupoCompras = null;
						
						ProductoBean prod = FuncionesComunesPLI.productos.get(material);
						if(prod != null ) {
							ProductoCentro pcentro = prod.getProductoCentro() != null ? prod.getProductoCentro().get(centro) : null;
							if( pcentro != null) {
								grupoCompras = pcentro.getCellCode();
								if(!UtilsString.isStringValida(grupoCompras)) {
									continue;
								}
							}
						}
						
						if (respuesta.containsKey(folio) ) {
							respuesta.get(folio).add(grupoCompras);
						} else {
							Set<String> gruposCompras = new HashSet<>();
							gruposCompras.add(grupoCompras);
							respuesta.put(folio, gruposCompras);
						}
					}
				}
			}
		} catch (SQLException sqle) {
			log.error("SQL error", sqle);
			ConexionDB.renovar(con);
		} catch (Exception e) {
			log.error("Exception", e);
		} finally {
			ConexionDB.devolver(con);
		}
		return respuesta;
	}

	public int insertRequestPrice(int folioSAR, SortedSet<BeanPoPosicionWithOther> posiciones) {
		int num_insert = 0;
		Connection con = null;
		Boolean autoCommit = null;
		try {
			con = ConexionDB.dameConexion();
			try (PreparedStatement ps = con.prepareStatement(INSERT_PRICE_RELEASE_REQUEST);) {
				autoCommit = con.getAutoCommit();
				con.setAutoCommit(false);
				for (BeanPoPosicionWithOther posicion : posiciones) {
					int i = 1;
					ps.setInt(i, folioSAR);
					ps.setString(++i, posicion.getPo());
					ps.setInt(++i, posicion.getPosicion());
					ps.setString(++i, posicion.getMaterial());
					ps.setInt(++i, posicion.getCantidad());
					ps.setString(++i, posicion.getTipo().toString());
					ps.setString(++i, posicion.getSubTipo());
					ps.setBoolean(++i, posicion.isPago());
					ps.setBigDecimal(++i, posicion.getPrecioUnitario());
					ps.setBigDecimal(++i, posicion.getPrecioUnitarioSolicitado());
					ps.addBatch();
				}
				int[] insert_counts = ps.executeBatch();
				con.commit();
				for (int i : insert_counts) {
					num_insert += i;
				}
			}
		} catch (SQLException sqle) {
			log.error("Folio: {} | posiciones: {}" + folioSAR, posiciones, sqle);
			ConexionDB.renovar(con);
		} catch (Exception e) {
			log.error("Folio: {} | posiciones: {}" + folioSAR, posiciones, e);
		} finally {
			if (autoCommit != null) {
				try {
					con.setAutoCommit(autoCommit);
				} catch (SQLException e) {
					log.error("Error al colocar {} en setAutoCommit", autoCommit.booleanValue(), e);
				}
			}
			ConexionDB.devolver(con);
		}
		return num_insert;
	}

	public int insertPriceReleaseFromRequest(int folioSAR) {
		int num_insert = 0;
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();
			try (PreparedStatement ps = con.prepareStatement(INSERT_PRICE_RELEASE_FROM_REQUEST);) {
				ps.setInt(1, folioSAR);
				num_insert = ps.executeUpdate();
			}
		} catch (SQLException sqle) {
			log.error("Folio: {}", folioSAR, sqle);
			ConexionDB.renovar(con);
		} catch (Exception e) {
			log.error("Folio: {}", folioSAR, e);
		} finally {
			ConexionDB.devolver(con);
		}
		return num_insert;
	}

	public int updateSARPreciosLiberados(boolean bandera, int folioSar) {
		int num_update = 0;
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();
			try (PreparedStatement ps = con.prepareStatement(UPDATE_SAR_PRECIOS_LIBERADOS);) {
				ps.setBoolean(1, bandera);
				ps.setInt(2, folioSar);
				num_update = ps.executeUpdate();
			}
		} catch (SQLException sqle) {
			log.error("Folio: {} | bandera {}" + folioSar, bandera, sqle);
			ConexionDB.renovar(con);
		} catch (Exception e) {
			log.error("Folio: {} | bandera {}" + folioSar, bandera, e);
		} finally {
			ConexionDB.devolver(con);
		}
		return num_update;
	}
	public int updateSARPreciosLiberadosConfirmacionBO(boolean bandera, int folioSar) {
		int num_update = 0;
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();
			try (PreparedStatement ps = con.prepareStatement(UPDATE_LIBERATION_BO_CONFIRMATION);) {
				ps.setBoolean(1, bandera);
				ps.setInt(2, folioSar);
				num_update = ps.executeUpdate();
			}
		} catch (SQLException sqle) {
			log.error("Folio: {} | bandera {}" + folioSar, bandera, sqle);
			ConexionDB.renovar(con);
		} catch (Exception e) {
			log.error("Folio: {} | bandera {}" + folioSar, bandera, e);
		} finally {
			ConexionDB.devolver(con);
		}
		return num_update;
	}

	public int updateSARPreciosEnRevision(boolean bandera, int folioSar) {
		int num_update = 0;
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();
			try (PreparedStatement ps = con.prepareStatement(UPDATE_SAR_PRECIOS_REVISION);) {
				ps.setBoolean(1, bandera);
				ps.setInt(2, folioSar);
				num_update = ps.executeUpdate();
			}
		} catch (SQLException sqle) {
			log.error("Folio: {} | bandera {}" + folioSar, bandera, sqle);
			ConexionDB.renovar(con);
		} catch (Exception e) {
			log.error("Folio: {} | bandera {}" + folioSar, bandera, e);
		} finally {
			ConexionDB.devolver(con);
		}
		return num_update;
	}

	public int updateSARLiberaHaciaPlaneacion(int folioSar, EstatusAuditoriaEnum estatus) {
		int num_update = 0;
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();
			try (PreparedStatement ps = con.prepareStatement(UPDATE_SAR_LIBERA_HACIA_PLANEACION);) {
				GregorianCalendar gc = new GregorianCalendar();
				long fecIniPlanning = gc.getTimeInMillis() / 1000;
				int tinyFecIniPlanning = FuncionesComunesPLI.gregorianCalendar2int(gc);
				ps.setLong(1, fecIniPlanning);
				ps.setInt(2, tinyFecIniPlanning);
				ps.setInt(3, estatus.getId());
				ps.setInt(4, folioSar);
				num_update = ps.executeUpdate();
			}
		} catch (SQLException sqle) {
			log.error("Folio: {} | estatus {}" + folioSar, estatus, sqle);
			ConexionDB.renovar(con);
		} catch (Exception e) {
			log.error("Folio: {} | estatus {}" + folioSar, estatus, e);
		} finally {
			ConexionDB.devolver(con);
		}
		return num_update;
	}

	public int marcaSARLiberaHaciaConfirmacionFinal(int folioSar, EstatusAuditoriaEnum estatus) {
		int num_update = 0;
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();
			try (PreparedStatement ps = con.prepareStatement(UPDATE_SAR_LIBERA_HACIA_CONFIRMACION_FINAL);) {
				ps.setInt(1, estatus.getId());
				ps.setInt(2, folioSar);
				num_update = ps.executeUpdate();
			}
		} catch (SQLException sqle) {
			log.error("Folio: {} | estatus {}" + folioSar, estatus, sqle);
			ConexionDB.renovar(con);
		} catch (Exception e) {
			log.error("Folio: {} | estatus {}" + folioSar, estatus, e);
		} finally {
			ConexionDB.devolver(con);
		}
		return num_update;
	}

	public int updatePrecioOtherItem(int folioSAR, String tipo, int posicion, BigDecimal precioUnitario) {
		int num_update = 0;
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();
			try (PreparedStatement ps = con.prepareStatement(UPDATE_OTHER_ITEM_PRICE);) {
				int i = 1;
				ps.setBigDecimal(i, precioUnitario);
				ps.setInt(++i, folioSAR);
				ps.setString(++i, tipo);
				ps.setInt(++i, posicion);
				num_update = ps.executeUpdate();
			}
		} catch (SQLException sqle) {
			log.error("Folio: {} | tipo: {} | precioUnitario: {} " + folioSAR + "|" + tipo, precioUnitario, sqle);
			ConexionDB.renovar(con);
		} catch (Exception e) {
			log.error("Folio: {} | tipo: {} | precioUnitario: {} " + folioSAR + "|" + tipo, precioUnitario, e);
		} finally {
			ConexionDB.devolver(con);
		}
		return num_update;
	}

	public int updateIfIsRevisionPrecios(int folioSAR) {
		int num_update = 0;
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();
			try (PreparedStatement ps = con.prepareStatement(UPDATE_IF_IS_REVISION_PRECIOS);) {
				int i = 1;
				ps.setInt(i, folioSAR);
				num_update = ps.executeUpdate();
			}
		} catch (SQLException sqle) {
			log.error("Folio: {}", folioSAR, sqle);
			ConexionDB.renovar(con);
		} catch (Exception e) {
			log.error("Folio: {}", folioSAR, e);
		} finally {
			ConexionDB.devolver(con);
		}
		return num_update;
	}

	public int updatePriceReleaseRequest(Set<BeanPriceReleasePosicion> posiciones) {
		int num_update = 0;
		Connection con = null;
		Boolean autoCommit = null;
		try {
			con = ConexionDB.dameConexion();
			StringBuilder sqlBasico = new StringBuilder();
			sqlBasico.append(" UPDATE cdiPriceReleaseRequest ");
			sqlBasico.append(" SET    pagadero = ? ");
			sqlBasico.append("       , precioActualizado = ? ");
			sqlBasico.append("       , preciounitarioactualizado = ? ");
			sqlBasico.append("       , updatedate = Getdate() ");
			sqlBasico.append(" WHERE  folio = ? ");
			sqlBasico.append("       AND subtipo = ? ");
			sqlBasico.append("       AND posicion = ?");
			
			StringBuilder sqlPos = new StringBuilder();
			sqlPos.append(sqlBasico);
			sqlPos.append("       AND po = ?");
			try (PreparedStatement ps = con.prepareStatement(sqlPos.toString());) {
				autoCommit = con.getAutoCommit();
				con.setAutoCommit(false);
				int posicionesPo = 0;
				for (BeanPriceReleasePosicion posicion : posiciones) {
					if (posicion.getTipo() == TipoPosicionEnum.PO) {
						int i = 1;
						ps.setBoolean(i, posicion.isPagadero());
						ps.setBoolean(++i, posicion.isPrecioActualizado());
						ps.setBigDecimal(++i, posicion.getPrecioUnitarioActualizado());
						ps.setInt(++i, posicion.getFolio());
						ps.setString(++i, posicion.getSubTipo());
						ps.setInt(++i, posicion.getPosicion());
						ps.setString(++i, posicion.getPo());
						ps.addBatch();
						posicionesPo++;
					}
				}
				if(posicionesPo > 0) {
					int[] update_counts = ps.executeBatch();
					for (int i : update_counts) {
						num_update += i;
					}
				}
			}
			
			try (PreparedStatement ps = con.prepareStatement(sqlBasico.toString());) {
				int posicionesOther = 0;
				for (BeanPriceReleasePosicion posicion : posiciones) {
					if (posicion.getTipo() == TipoPosicionEnum.OTHER_ITEM) {

						int i = 1;
						ps.setBoolean(i, posicion.isPagadero());
						ps.setBoolean(++i, posicion.isPrecioActualizado());
						ps.setBigDecimal(++i, posicion.getPrecioUnitarioActualizado());
						ps.setInt(++i, posicion.getFolio());
						ps.setString(++i, posicion.getSubTipo());
						ps.setInt(++i, posicion.getPosicion());
						ps.addBatch();
						posicionesOther++;
					}
				}
				if(posicionesOther > 0) {
					int[] update_counts = ps.executeBatch();
					for (int i : update_counts) {
						num_update += i;
					}
				}
			}
			con.commit();
		} catch (SQLException sqle) {
			log.error("Posiciones: {}", posiciones, sqle);
			ConexionDB.renovar(con);
		} catch (Exception e) {
			log.error("Posiciones: {}", posiciones, e);
		} finally {
			if (autoCommit != null) {
				try {
					con.setAutoCommit(autoCommit);
				} catch (SQLException e) {
					log.error("Error al colocar {} en setAutoCommit", autoCommit.booleanValue(), e);
				}
			}
			ConexionDB.devolver(con);
		}
		return num_update;
	}

	public int updatePriceReleaseSARdetalle(Set<BeanPriceReleasePosicion> posiciones) {
		int num_update = 0;
		Connection con = null;
		Boolean autoCommit = null;
		try {
			con = ConexionDB.dameConexion();
			StringBuilder sql = new StringBuilder();
			sql.append(" UPDATE cdiSARDetalle ");
			sql.append(" SET    precioUnitario = ? ");
			sql.append(" WHERE  folio = ? ");
			sql.append("       AND posicion = ?");
			sql.append("       AND po = ?");
			try (PreparedStatement ps = con.prepareStatement(sql.toString());) {
				autoCommit = con.getAutoCommit();
				con.setAutoCommit(false);
				int porActualizar = 0;
				for (BeanPriceReleasePosicion posicion : posiciones) {
					if (!posicion.isPrecioActualizado() || posicion.getTipo() == TipoPosicionEnum.OTHER_ITEM)
						continue;
					porActualizar++;
					int i = 1;
					ps.setBigDecimal(i, posicion.getPrecioUnitarioActualizado());
					ps.setInt(++i, posicion.getFolio());
					ps.setInt(++i, posicion.getPosicion());
					ps.setString(++i, posicion.getPo());
					ps.addBatch();
				}
				if (porActualizar > 0) {
					int[] update_counts = ps.executeBatch();
					con.commit();
					for (int i : update_counts) {
						num_update += i;
					}
				}
			}
		} catch (SQLException sqle) {
			log.error("Posiciones: {}", posiciones, sqle);
			ConexionDB.renovar(con);
		} catch (Exception e) {
			log.error("Posiciones: {}", posiciones, e);
		} finally {
			if (autoCommit != null) {
				try {
					con.setAutoCommit(autoCommit);
				} catch (SQLException e) {
					log.error("Error al colocar {} en setAutoCommit", autoCommit.booleanValue(), e);
				}
			}
			ConexionDB.devolver(con);
		}
		return num_update;
	}

	public int updateSARPreciosRevisadosSegundaVez(int folioSar) {
		int num_update = 0;
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();
			try (PreparedStatement ps = con.prepareStatement(UPDATE_SAR_PRECIOS_REVISION_SEGUNDA_VEZ);) {
				ps.setInt(1, folioSar);
				num_update = ps.executeUpdate();
			}
		} catch (SQLException sqle) {
			log.error("Folio: {}", folioSar, sqle);
			ConexionDB.renovar(con);
		} catch (Exception e) {
			log.error("Folio: {}", folioSar, e);
		} finally {
			ConexionDB.devolver(con);
		}
		return num_update;
	}

	public int deleteSARPreciosEnRevision(int folioSar) {
		int num_update = 0;
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();
			try (PreparedStatement ps = con.prepareStatement(DELETE_SAR_PRECIOS_EN_REVISION);) {
				ps.setInt(1, folioSar);
				num_update = ps.executeUpdate();
			}
		} catch (SQLException sqle) {
			log.error("Folio: {}", folioSar, sqle);
			ConexionDB.renovar(con);
		} catch (Exception e) {
			log.error("Folio: {}", folioSar, e);
		} finally {
			ConexionDB.devolver(con);
		}
		return num_update;
	}
	
	
	public int updateSARReject(int folio, String observaciones) {
		int num_update = 0;
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();
			try (PreparedStatement ps = con.prepareStatement(UPDATE_SAR_REJECT);) {
				ps.setString(1, observaciones);
				ps.setInt(2, folio);
				num_update = ps.executeUpdate();
			}
		} catch (SQLException sqle) {
			log.error("Folio: {} | obser {}" + folio, observaciones, sqle);
			ConexionDB.renovar(con);
		} catch (Exception e) {
			log.error("Folio: {} | bandera {}" + folio, observaciones, e);
		} finally {
			ConexionDB.devolver(con);
		}
		return num_update;
	}
	
	
}
