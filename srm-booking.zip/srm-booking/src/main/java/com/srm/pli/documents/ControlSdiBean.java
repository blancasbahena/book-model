package com.srm.pli.documents;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class ControlSdiBean {
	private Integer versionSdi;
	private String proveedor;
	private String booking;
	private Integer idDocumentos;
	private Date fechaAceptaProveedor;
	private String comentarioProveedor;
	private String analista;
	private Boolean aprobado;
	private Date fechaAprobadoSdi;
	private Date fechaAsignadoAnalista;
	private String tipoBl;
}