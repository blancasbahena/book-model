package com.srm.pli.services;

import static com.srm.pli.helper.CorreoHelper.MAILS_REPORTE_SARS_RELESED_PLANNING_SHIPPING_CC;
import static com.srm.pli.helper.CorreoHelper.MAIL_FR_HK_SYSTEM;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.net.URL;
import java.sql.SQLException;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.mail.MessagingException;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.servlet.ServletException;

import org.apache.commons.io.FileUtils;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.srm.fungandrui.itemsdirectos.dto.ItemsSeleccionados;
import com.srm.fungandrui.itemsdirectos.service.ItemsDirectosService;
import com.srm.fungandrui.itemsdirectos.service.impl.ItemsDirectosServiceImpl;
import com.srm.pli.bo.CdiDocumentBO;
import com.srm.pli.bo.FasesSARBO;
import com.srm.pli.bo.ReporteCambiosETDBooking;
import com.srm.pli.bo.SarBO;
import com.srm.pli.bo.SarDetalleBO;
import com.srm.pli.bo.SarDetalleReporte;
import com.srm.pli.dao.SAR_CDI_DAO;
import com.srm.pli.enums.HistoryLogAction;
import com.srm.pli.helper.CorreoHelper;
import com.srm.pli.helper.FormatHistoricoBooking;
import com.srm.pli.helper.FormatSAR;
import com.srm.pli.helper.PuertosHelper;
import com.srm.pli.helper.ReportesHelper;
import com.srm.pli.servlet.DocumentosSDIImpl;
import com.srm.pli.utils.CorreoUtils;
import com.srm.pli.utils.EmailUtilAsync;
import com.srm.pli.utils.EstatusUtils;
import com.srm.pli.utils.FuncionesComunesPLI;
import com.srm.pli.utils.MailUtils;
import com.srm.pli.utils.PropertiesDb;
import com.srm.pli.utils.Utilerias;
import com.truper.businessEntity.BeanAlertasSAR;
import com.truper.businessEntity.BeanPuerto;
import com.truper.businessEntity.BeanResponseEmail;
import com.truper.businessEntity.CompradoresBean;
import com.truper.businessEntity.EmailAsynBean;
import com.truper.businessEntity.ImportacionesProveedoresBean;
import com.truper.businessEntity.PlaneadorBean;
import com.truper.businessEntity.PoRedFlag;
import com.truper.businessEntity.ProductoBean;
import com.truper.businessEntity.ProductoCentro;
import com.truper.businessEntity.ReferenceNumberBean;
import com.truper.businessEntity.SAR;
import com.truper.businessEntity.SARDetalle;
import com.truper.businessEntity.SARHistoricoBooking;
import com.truper.businessEntity.SARHistoryLogBean;
import com.truper.businessEntity.UnidadNegocio;
import com.truper.businessEntity.UserBean;
import com.truper.helper.HtmlMailServices;
import com.truper.helper.MailServices;
import com.truper.helper.jr.JasperServices;
import com.truper.utils.string.UtilsString;

import lombok.extern.log4j.Log4j2;
import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

@Log4j2
public class CdiNotificationBuilderServices {
	
	private static CdiNotificationBuilderServices instance = null;
	
	
	private CdiNotificationBuilderServices() {
	}
	
	public static CdiNotificationBuilderServices getInstance() {
		if(instance == null) {
			instance = new CdiNotificationBuilderServices();
		}
		return instance;
	}
	
	@Autowired
	ItemsDirectosService itemsDirectosService = new ItemsDirectosServiceImpl();
	
	private static final String CORREO_DAVID = "drodriguezv@truper.com";
	private static final String CORREO_RENE = "rsantiagor@truper.com";
	private static final String CORREO_IALOPEZC = "ialopezc@truper.com";
	private static final String CORREO_EAMERAE = "eamerae@truper.com";
	public static final String CORREO_IVONNE = "itrueba@truper.com";
	private static final String CORREO_IGARCIAQ = "igarciaq@truper.com";
	private static final String CORREO_SYSTEM = "system@fung-rui.hk";
	private static final String CORREO_SHIPPING = "shipping@fung-rui.hk";
	private static final String CORREO_BOOKING = "booking@fung-rui.hk";
	private static final String CORREO_DOCUMENTS = "documents@fung-rui.hk";
	private static final String CORREO_EGUTIERREZJI = "egutierrezji@truper.com";
	private static final String CORREOS_SISTEMAS = "rsantiagor@truper.com;drodriguezv@truper.com;csuarez@truper.com";
	private static final String CORREOS_SHHGN = "szhou@shhgn.cn;awu@shhgn.cn;sqian@shhgn.cn";
	private static final String CORREOS_1 = "ialopezc@truper.com;amontesc@truper.com;jjuarezp@truper.com";

	private static final String RUTA_SARS_APPROVED = "C:\\arch\\MonitoreoSARS\\SARsApproved";
	private static final String RUTA_SARS_PENDING = "C:\\arch\\MonitoreoSARS\\SARsPending";
	private static final String RUTA_CAMBIO_ETD_BOOKING = "C:\\arch\\MonitoreoSARS\\cambiosETDBooking";
	private static final String RUTA_TEMPLATES = "C:\\arch\\MonitoreoSARS\\templates";
	private static final String RUTA_MONITOREO = "C:\\arch\\MonitoreoSARS\\monitoreo";
	private static final String RUTA_REPORTES = "C:\\arch\\reportes";

	private static final String TEXTO_SARS_W_BOOKING = "Sars with booking released by Booking";

	private static final String notifMsg = "<html><body><div style='width: 100%; align-content: center; font-family:Verdana;' align='center'><table style='font-size: 12px; text-align: justify; max-width: 850px;' align='center'><tr><td><b>Dear Supplier,<br></b></td></tr><tr><td>Please go to Fung & Rui system and upload your documents for booking# {1}. <br>For your ref. this vessel sailed on {2}.<br>Please confirm once copies are sent.<br><br></td></tr><tr><td style='color: blue;'><b>Please remember you have to send the full set of documents for revision process at the latest 5 days after the date of shipment departure,<br>You should have received an email from TEL system some days ago requesting documents for this shipment.<br>Please help us to follow the shipping policies of Truper everytime without fail.<br><br></b></td></tr><tr><td style='color: red;'><b>Shipping Policies says:</b><br></td></tr><tr><td><b>C) CHARGES</b><br>When required documents are received late, and/or with mistakes according to the policies of Truper above indicated, you will receive an e-mail from the Purchase Executive responsible for your account notifying the specific problem(late reception or error on documentation)<br><br><b><u>From the third notification and on, a $200.00 usd charge will be applied to cover administrative expenses incurred by us.</u></b><br><br><b><u>In addition to this charge, whenever demurrages and warehousing costs are caused from delayed or incorrect documentation, all charges will be applied to the Supplier.</u></b><br><br></td></tr><tr><td><table border='1' style='border-collapse: collapse; font-size: 12px; text-align: justify;'><tr><td><div align='center'><b>DELIVERY OF SHIPPING DOCUMENTS<br>SEND COPY OF FOLLOWING DOCUMENTS:<br></b></div><br><b><ul><li>Invoice<br></li><li>Packing List<br></li><li>Certificate of Origin <font color='blue'>(If the product is manufactured in China & shipped from China Port, then C/O is not required).</font><br></li><li>Bill of Lading / <font color='#FF7DBD'>Seaway Bill</font><br></li></ul></b><br>At the<b><font color='red'>LATEST 5 DAYS</font></b> after the date of shipment departure, <b>including the <font color='red'>FIVE</font> requested pictures of the container while being loaded</b> (first picture: empty container before loading, second picture: product placement at half loading, third picture: container loaded prior to closing doors, fourth picture: a close-up picture of the seals numbers once they are placed and the fifth: close container with door seal showing container number. The <b>FIVE</b> pictures must be sent always in .jpg files), to the following e-mail address:</td></tr></table><td></tr></table></div></body></html>";
	private static final String subjectMsg = "DOCUMENTS FOR REVIEW PROCESS - BOOKING# {1} - {2}.";

	private final MailServices<? extends MailServices<?>> ms = HtmlMailServices.getInstance();
	private static final String dateSeparator = "/";

	private static final Long milisecDay = 86400000l;

	private static final String tipoFAC = "FAC";
	private static final String tipoBL = "BL";
	private static final String tipoPKL = "PKL";

	private static int diasPreviosNotifSinBooking = 11;
	private static int diasPreviosNotifSinDoc = 4;
	private static int diasNotifSinDoc = 1;
	private static int diasPosterioresNotifSinDoc = -2;
	private static final int DIAS_ENVIO_BOOKING_REQUEST = 2;
	private static final int MESES_REPORTE_SARS_LIBERADOS_FROM = 2;
	private static final int MESES_REPORTE_SARS_LIBERADOS_TO = 4;
	private static final String MESES_REPORTE_SARS_LIBERADOS = "reporte.sars.aprobados.meses";
	private static final String MESES_REPORTE_BOOKING = "reporte.sars.in.booking.meses";

	private static final int TOLERANCIA_PLANEACION = 2;
	private static final int TOLERANCIA_EMBARQUES = 1;
	private static final int TOLERANCIA_CONSOLIDADOS = 14;
	private static final int TOLERANCIA_BOOKING = 30;
	private static final int TOLERANCIA_SDI = 3;

	private static final String ARCHIVO_CONFIG = "srm.booking.configuration.alerts.xml";

	private List<SarBO> lstAlertaPlanning;
	private List<SarBO> lstAlertaShipping;
	private List<SarBO> lstAlertaConsol;
	private List<SarBO> lstAlertaBooking;
	private List<SarBO> lstAlertaSDI;
	
	public static EmailAsynBean emailBean = null;
	public InternetAddress[] address = null;
	public static EmailUtilAsync sendAsync = new EmailUtilAsync();
	public static BeanResponseEmail response = new BeanResponseEmail();

	public static String armaNotificacionSolicitudDocumentosProveedores(String bookingNo, String sailedVesselDate) {
		String s = notifMsg;
		bookingNo = (bookingNo != null) ? bookingNo.trim() : "";
		sailedVesselDate = (sailedVesselDate != null) ? sailedVesselDate.trim() : "";
		s = s.replace("{1}", bookingNo);
		s = s.replace("{2}", sailedVesselDate);
		return s;
	}

	public static String armaAsuntoSolicitudDocumentosProveedores(String bookingNo, String providerName) {
		String s = subjectMsg;
		bookingNo = (bookingNo != null) ? bookingNo.trim() : "";
		providerName = (providerName != null) ? providerName.trim() : "";
		s = s.replace("{1}", bookingNo);
		s = s.replace("{2}", providerName);
		return s;
	}

	public void notificaProveedorSinDocumentacion(Integer folio)
			throws MessagingException, SQLException, ClassNotFoundException {
		SarBO tmp = new SarBO();
		tmp.setFolio(folio);
		boolean flagComponenteEmail = MailUtils.isEnviaCorreoWsMail();
		SarBO sar = FuncionesComunesPLI.dameSARByFolio(tmp);
		ImportacionesProveedoresBean proveedor = FuncionesComunesPLI.getProveedor(sar.getProveedor());

		if (MailUtils.isEnviaCorreos()) {
			String[] sa;
			String mail = "";
			if (MailUtils.isCorreosDebug()) {
				mail = CORREO_DAVID;
			} else {
				String proveedorMail = proveedor.getEmail();
				StringBuilder sb = new StringBuilder();
				sb.append(proveedorMail);
				mail = sb.toString();
			}
			sa = creaArrayCorreos(mail);
			String bookingNo = sar.getBooking();
			Integer etdFinal = sar.getEtdReal();
			boolean etdValida = (etdFinal != null);
			String etdFinalS = etdFinal.toString();
			String releaseDate = etdValida ? formateaFechaEtd(etdFinalS) : "";
			String providerName = proveedor.getNombreProveedor();
			String message = CdiNotificationBuilderServices.armaNotificacionSolicitudDocumentosProveedores(bookingNo,
					releaseDate);
			String asunto = CdiNotificationBuilderServices.armaAsuntoSolicitudDocumentosProveedores(bookingNo,
					providerName);
			try {
				if (flagComponenteEmail) { // Envio de correo asincrono
					address = CorreoUtils.getInstance().getAddress(sa);
					emailBean = new EmailAsynBean(address, null, null, asunto, message, null);
					sendAsync.createEmail(emailBean, null, null);
					log.info("El envio de mail se ha realizado por componente ");
				} else {
					// envio de respaldo
					ms.sendMail(sa, null, asunto, message);
					log
							.info("El envio de mail se ha realizado por metodo de respaldo [flagComponenteEmail]"
									+ flagComponenteEmail);
				}
			} catch (Exception e) {
				log.error(" fallo envio de mail - WS MAIL(" + flagComponenteEmail + ")" + e);
			}
		}
	}

	public void notificaProveedorSinBooking(Integer folio)
			throws MessagingException, SQLException, ClassNotFoundException {
		SarBO tmp = new SarBO();
		boolean flagComponenteEmail = MailUtils.isEnviaCorreoWsMail();
		tmp.setFolio(folio);
		SarBO sar = FuncionesComunesPLI.dameSARByFolio(tmp);
		ImportacionesProveedoresBean proveedor = FuncionesComunesPLI.getProveedor(sar.getProveedor());

		if (MailUtils.isEnviaCorreos()) {
			String[] sa;
			String mail = "";
			if (MailUtils.isCorreosDebug()) {
				sa = SarBO.MAIL_DEBUG;
			} else {
				String proveedorMail = proveedor.getEmail();
				StringBuilder sb = new StringBuilder();
				sb.append(proveedorMail);
				mail = sb.toString();
				sa = creaArrayCorreos(mail);
			}
			StringBuilder body = new StringBuilder();
			body.append(
					"<html><body><div style='width: 100%; align-content: center; font-family: Verdana;' align='center'>");
			body.append("<table style='font-size: 12px; text-align: justify; max-width: 850px;' align='center'>");
			body.append("<tr><td><b>Dear Supplier,<br></b></td></tr>");
			body.append("<tr><td>We have not received from you the booking number for approved SAR folio # "
					+ sar.getFolioCompleto() + ".</td></tr>");
			body.append("<tr><td>&nbsp;</td></tr>");
			body.append(
					"<tr><td>You must contact the carrier assigned for your shipment to obtain your booking number and pass this information to us.</td></tr>");
			body.append(
					"<tr><td>As a reminder, you must request to the carrier your booking number with at least 15 days grace period prior to the Voyage date.</td></tr>");
			body.append("<tr><td>&nbsp;</td></tr>");
			body.append(
					"<tr><td>Any incorrect or incomplete booking request with the carrier vs information given by us to you on your SAR Folio # ");
			body.append(sar.getFolioCompleto()
					+ ", will cause the booking to be placed on hold by the carrier until we are notified by them and clear with you, ");
			body.append("any inconsistance about the information you are providing to them.</td></tr>");
			body.append("<tr><td>&nbsp;</td></tr>");
			body.append(
					"<tr><td>If you have any issues related to obtaining your booking number with the carrier, please fill in the carrier trouble shoot data sheet ");
			body.append(
					"and send it immediately to your Planning Executive and Account Executive as well as to F&R so that we can assit you in solvoing the problem.</td></tr>");
			body.append("<tr><td>Best Regards.</td></tr>");
			body.append("</table>");
			body.append("</div></body></html>");
			String message = body.toString();
			String asunto = armaAsuntoRecordatorioSinBooking(sar);
			try {
				if (flagComponenteEmail) { // Envio de correo asincrono
					address = CorreoUtils.getInstance().getAddress(sa);
					emailBean = new EmailAsynBean(address, null, null, asunto, message, null);
					sendAsync.createEmail(emailBean, null, null);
					log.info("El envio de mail se ha realizado por componente ");
				} else {
					// envio de respaldo
					ms.sendMail(sa, null, asunto, message);
					log
							.info("El envio de mail se ha realizado por metodo de respaldo  [flagComponenteEmail]"
									+ flagComponenteEmail);
				}

			} catch (Exception e) {
				log.error(" fallo envio de mail - WS MAIL(" + flagComponenteEmail + ")" + e);
			}
		}
	}

	public void notificacionesSDIDocumentoRechazado() throws MessagingException, SQLException, ClassNotFoundException {
		HashMap<Integer, ArrayList<CdiDocumentBO>> mapa = DocumentosSDIImpl
				.dameSarsConDocumentosRechazadosParaCorreo(1);

		Set<Integer> setFolios = mapa.keySet();
		boolean flagComponenteEmail = MailUtils.isEnviaCorreoWsMail();

		for (Integer folio : setFolios) {
			if (MailUtils.isEnviaCorreos()) {
				String[] sa;
				String mail = "";

				// Obtengo datos a Utilizar
				ArrayList<CdiDocumentBO> doctos = mapa.get(folio);
				String factura = "";
				SAR_CDI_DAO dao = new SAR_CDI_DAO();
				SarBO sarBo = new SarBO();
				sarBo.setFolio(folio);
				ArrayList<SarBO> sars = dao.selectSar(sarBo, false);
				SarBO sarData = sars.get(0);
				long tiempoArchivo = 0;
				for (CdiDocumentBO doc : doctos) {
					if (doc.getFechaRechazo() != null && doc.getFechaRechazo() > 0) {
						if ("FAC".equals(doc.getTipo())) {
							if (!"".equals(factura)) {
								factura += ",";
							}
							factura += doc.getNumero();
						}

						tiempoArchivo = (doc.getFechaRechazoLong().longValue() < tiempoArchivo || tiempoArchivo == 0)
								? doc.getFechaRechazoLong().longValue()
								: tiempoArchivo;
					}
				}
				ImportacionesProveedoresBean dataProveedor = FuncionesComunesPLI.getProveedor(sarData.getProveedor());
				GregorianCalendar ahorita = new GregorianCalendar();
				GregorianCalendar archivo = new GregorianCalendar();
				archivo.setTimeInMillis(tiempoArchivo);
				double recordatorio = FuncionesComunesPLI.daysBetween(archivo, ahorita);

				StringBuffer cuerpoMail = new StringBuffer();
				cuerpoMail.append(
						"<html><body><div style='width: 100%; align-content: center; font-family: Verdana;' align='center'>");
				cuerpoMail.append("<p>Dear Vendor, </p><br>");
				cuerpoMail.append("<p>Please send copies amended asap, vessel is arriving.</p>");
				if (recordatorio > 3) {
					cuerpoMail.append("<p><font color=\"blue\">Suki / Anna / Sally,</font></p>");
					cuerpoMail.append("<p><font color=\"blue\">Your help please</font></p>");

				}

				cuerpoMail.append("</div></body></html>");

				// Aqui genero los destinatarios
				if (MailUtils.isCorreosDebug()) {
					mail = CORREO_DAVID;
					sa = creaArrayCorreos(mail);
				} else {
					mail = CORREOS_SISTEMAS;
					StringBuffer dest = new StringBuffer();
					dest = FuncionesComunesPLI.addEmail(dest, dataProveedor.getEmail());
					dest = FuncionesComunesPLI.addEmail(dest, CORREOS_SHHGN);
					dest = FuncionesComunesPLI.addEmail(dest, CORREOS_1);
					sa = creaArrayCorreos(dest.toString());
				}
				String asunto = "CORRECTIONS INV #" + factura + " - " + dataProveedor.getNombreProveedor() + " - ETA: "
						+ FuncionesComunesPLI.formateaFecha(sarData.getEta()) + " *** "
						+ FuncionesComunesPLI.formatea(recordatorio, 0) + "th REMINDER *** SAR:" + sarData.getFolio();
				try {
					if (flagComponenteEmail) { // Envio de correo asincrono
						address = CorreoUtils.getInstance().getAddress(sa);
						emailBean = new EmailAsynBean(address, null, null, asunto, cuerpoMail.toString(),
								CORREO_DOCUMENTS);
						sendAsync.createEmail(emailBean, null, null);
					} else {
						// envio de respaldo
						ms.sendMail(sa, null, asunto, cuerpoMail.toString(), null, CORREO_DOCUMENTS);
						log
								.info("El envio de mail se ha realizado por metodo de respaldo  [flagComponenteEmail]"
										+ flagComponenteEmail);
					}

				} catch (Exception e) {
					log.error(" fallo envio de mail - WS MAIL(" + flagComponenteEmail + ")" + e);
				}
			}
		}
	}

	/******
	 * Metodo que recibe una fecha en formato YYYYMMDD y lo cambia a
	 * DD(separador)MM(separado)YYYY
	 * 
	 * @param s fecha en formato YYYYMMDD
	 * 
	 * @return recha transformada a formato DD(separador)MM(separado)YYYY
	 **/

	public static String formateaFechaEtd(String s) {
		if (s != null && s.length() == 8) {
			String anio = s.substring(0, 4);
			String mes = s.substring(4, 6);
			String dia = s.substring(6, 8);
			StringBuilder sb = new StringBuilder();
			sb.append(dia);
			sb.append(dateSeparator);
			sb.append(mes);
			sb.append(dateSeparator);
			sb.append(anio);
			String formatedDate = sb.toString();
			return formatedDate;
		}
		return "";
	}

	/**
	 * @deprecated Este metodo ya no se debe usar ya que fue reemplazado por el
	 *             siguiente {@link CorreoUtils #creaArrayCorreos(String)}
	 * @param correos
	 * @return
	 */
	public static String[] creaArrayCorreos(String correos) {
		String[] ar;
		if (correos.contains(";")) {
			ar = correos.split(";");
		} else {
			ar = new String[1];
			ar[0] = correos;
		}
		for (String string : ar) {
			try {
				new InternetAddress(string);
			} catch (AddressException e) {
				continue;
			}
		}
		return ar;
	}

	/****
	 * Metodo que genera la fecha con el formato de la base de datos, es decir
	 * YYYYMMDD
	 * 
	 * @param days dias que se sumaran a la fecha del dia de hoy, si el numero es
	 *             negativo se restaran
	 **/
	public static String generaFechaConsulta(int days) {
		Calendar c = generateCalendarAddingDays(days);
		StringBuilder sb = new StringBuilder();
		sb.append(c.get(Calendar.YEAR));
		if (c.get(Calendar.MONTH) + 1 < 10) {
			sb.append("0");
		}
		int month = c.get(Calendar.MONTH);
		month++;
		sb.append(month);
		if (c.get(Calendar.DAY_OF_MONTH) < 10) {
			sb.append("0");
		}
		sb.append(c.get(Calendar.DAY_OF_MONTH));
		String fechaEta = sb.toString();
		return fechaEta;
	}

	private static Calendar generateCalendarAddingDays(int days) {
		Date d = new Date();
		Long milisecNewDate = d.getTime() + (milisecDay * days);
		Calendar c = new GregorianCalendar();
		c.setTimeInMillis(milisecNewDate);
		return c;
	}

	public List<SarBO> obtieneSarsCandidatos(int days) throws SQLException, ClassNotFoundException {
		SarBO sar = new SarBO();
		String fecString = generaFechaConsulta(days);
		boolean validStr = (fecString != null && !fecString.trim().equals(""));
		Integer etdF = validStr ? new Integer(fecString) : 0;
		sar.setEtdReal(etdF);
		SAR_CDI_DAO dao = new SAR_CDI_DAO();
		ArrayList<SarBO> lstSars = dao.selectSar(sar, false);
		return lstSars;
	}

	public List<Integer> filtraSars(List<SarBO> ls) {
		Map<String, Integer> mf = new HashMap<String, Integer>();
		List<Integer> li = new ArrayList<Integer>();
		for (SarBO sar : ls) {
			String s = sar.getBooking() + sar.getProveedor();
			mf.put(s, sar.getFolio());
		}
		li.addAll(mf.values());
		return li;
	}

	public List<SarBO> obtieneSarsConsolidadosCandidatos(Integer days) throws SQLException, ClassNotFoundException {
		List<SarBO> lstSars = new ArrayList<SarBO>();
		SAR_CDI_DAO dao = new SAR_CDI_DAO();
		String fecString = generaFechaConsulta(days);
		boolean validStr = (fecString != null && !fecString.trim().equals(""));
		Integer etdF = validStr ? new Integer(fecString) : 0;

		SarBO tmp = new SarBO();
		tmp.setConsolidado(true);
		tmp.setIncluyeSarConsol(true);
		tmp.setEtdReal(etdF);
		lstSars = dao.selectSar(tmp, false);

		return lstSars;
	}

	public boolean documentacionCompleta(Integer folioSar) throws SQLException, ClassNotFoundException {
		CdiDocumentBO doc2 = new CdiDocumentBO();
		doc2.setSar(folioSar);
		ArrayList<CdiDocumentBO> listaDo = DocumentosSDIImpl.dameUltimaversionDocumentos(doc2);
		boolean FAC = false;
		boolean BL = false;
		boolean PKL = false;
		for (CdiDocumentBO dc : listaDo) {
			String tipoDoc = (dc != null) ? dc.getTipo().trim() : "";
			if (tipoDoc.equals(tipoFAC)) {
				FAC = true;
			}
			if (tipoDoc.equals(tipoBL)) {
				BL = true;
			}
			if (tipoDoc.equals(tipoPKL)) {
				PKL = true;
			}
		}
		boolean documentacionValida = (FAC && BL && PKL);
		return documentacionValida;
	}

	public List<SarBO> filtraSinBooking(List<SarBO> ls) {
		List<SarBO> lsf = new ArrayList<SarBO>();
		for (SarBO s : ls) {
			String b = s.getBooking();
			String bf = (b != null) ? b.trim() : "";
			if (bf.equals("")) {
				lsf.add(s);
			}
		}
		return lsf;
	}

	public List<SarBO> buscaSars(List<Integer> folios) throws SQLException, ClassNotFoundException {
		List<SarBO> ls = new ArrayList<SarBO>();
		for (Integer f : folios) {
			SarBO tmp = new SarBO();
			tmp.setFolio(f);
			SarBO sar = FuncionesComunesPLI.dameSARByFolio(tmp);
			ls.add(sar);
		}
		return ls;
	}

	public void enviaNotificacionProveedorSinBooking() throws MessagingException, SQLException, ClassNotFoundException {
		try {
			FuncionesComunesPLI.cargaPropertiesCDI(false);
		} catch (ServletException e) {
			e.printStackTrace();
		}
		List<SarBO> ls = new ArrayList<SarBO>();
		List<SarBO> lsc = this.obtieneSarsCandidatos(diasPreviosNotifSinBooking);
		List<SarBO> lscc = this.obtieneSarsConsolidadosCandidatos(diasPreviosNotifSinBooking);
		ls.addAll(lsc);
		ls.addAll(lscc);
		List<SarBO> lssb = this.filtraSinBooking(ls);
		List<Integer> li = new ArrayList<Integer>();
		for (SarBO sar : lssb) {
			Integer fs = sar.getFolio();
			li.add(fs);
		}
		for (Integer i : li) {
			this.notificaProveedorSinBooking(i);
		}
	}

	public void enviaNotificacionProveedorSinDocumentacionPrevia()
			throws MessagingException, SQLException, ClassNotFoundException {
		this.enviaNotificacionProveedorSinDocumentacion(diasPreviosNotifSinDoc);
	}

	public void enviaNotificacionProveedorSinDocumentacion()
			throws MessagingException, SQLException, ClassNotFoundException {
		this.enviaNotificacionProveedorSinDocumentacion(diasNotifSinDoc);
	}

	public void enviaNotificacionProveedorSinDocumentacionPosterior()
			throws MessagingException, SQLException, ClassNotFoundException {
		this.enviaNotificacionProveedorSinDocumentacion(diasPosterioresNotifSinDoc);
	}

	private void enviaNotificacionProveedorSinDocumentacion(int dias)
			throws MessagingException, SQLException, ClassNotFoundException {
		List<SarBO> ls = new ArrayList<SarBO>();
		List<SarBO> lsc = this.obtieneSarsCandidatos(dias);
		List<SarBO> lscc = this.obtieneSarsConsolidadosCandidatos(dias);
		ls.addAll(lsc);
		ls.addAll(lscc);
		List<Integer> listaFolios = new ArrayList<Integer>();
		for (SarBO s : ls) {
			Integer i = s.getFolio();
			listaFolios.add(i);
		}
		for (Integer i : listaFolios) {
			boolean documentacionCompleta = this.documentacionCompleta(i);
			if (!documentacionCompleta) {
				this.notificaProveedorSinDocumentacion(i);
			}
		}
	}

	private String armaAsuntoRecordatorioSinBooking(SarBO sar) {
		StringBuilder asunto = new StringBuilder();
		asunto.append("Booking Request Reminder Folio #" + sar.getFolioCompleto());
		boolean consol = (sar.getConsolidado() != null) ? sar.getConsolidado() : false;
		String tipoFolio = consol ? "C" : "F";
		asunto.append(tipoFolio);
		asunto.append(sar.getFolio());
		String asuntoStr = asunto.toString();
		return asuntoStr;
	}

	public void recargaMapasPli() throws MessagingException, ServletException {
		FuncionesComunesPLI.recargaMapas();
	}

	public void releasedSARsByPlanningAndShipping() {
		log.info("Inicia envio de SARs liberados por Planning y Shipping jasper...");
		GregorianCalendar greg1 = new GregorianCalendar();
		try {
			FuncionesComunesPLI.cargaPropertiesCDI(false); 
			FuncionesComunesPLI.cargaProductos(false); 
			FuncionesComunesPLI.cargaUnidadesNeg(false); 
			FuncionesComunesPLI.cargaCompradores(false); 
			FuncionesComunesPLI.cargaMapaCelulasXUnidadNegocio(false); 
			FuncionesComunesPLI.cargaContenedores(false); 
			FuncionesComunesPLI.cargaNavieras(false); 
			FuncionesComunesPLI.cargaPuertosOrigen(false); 
			FuncionesComunesPLI.cargaPuertosDestino(false); 
			FuncionesComunesPLI.cargaPuertosDirectos(false); 
			FuncionesComunesPLI.cargaPlanners(false); 
			FuncionesComunesPLI.getProveedores(false); 
			FuncionesComunesPLI.cargaPlanners(false); 
		} catch (Exception e) {
			log.error("releasedSARsByPlanningAndShipping try", e);
		}

		SAR_CDI_DAO dao = new SAR_CDI_DAO();
		GregorianCalendar gc = new GregorianCalendar();
		int hoy = FuncionesComunesPLI.gregorianCalendar2int(gc);
		long hoySegundos = gc.getTimeInMillis() / 1000L;
		String mailFrom = CorreoHelper.getInstance().getEmail(MAIL_FR_HK_SYSTEM);
		String[] mailsTo = { CORREO_SHIPPING, CORREO_EGUTIERREZJI };
		Set<String> setCc = CorreoHelper.getInstance().getEmails(MAILS_REPORTE_SARS_RELESED_PLANNING_SHIPPING_CC);

		if(setCc == null)
			setCc = new HashSet<>();
		setCc.addAll(Arrays.asList(SarBO.MAIL_GRUPO_REPORTE_SARS));
		String[] mailsCC = CorreoHelper.getInstance().getArrayFromSet(setCc);
		List<SarDetalleReporte> detallesReporte = new ArrayList<>();
		// mando a llamar el metodo jasper
		try {
			GregorianCalendar mesPosterior = new GregorianCalendar();
			Integer mesesTo = MESES_REPORTE_SARS_LIBERADOS_TO;
			mesPosterior.add(Calendar.MONTH, mesesTo);
			int mesFrom = FuncionesComunesPLI.gregorianCalendar2int(mesPosterior);
			mesFrom = mesFrom / 100;
			mesFrom = (mesFrom * 100) + 32;
			GregorianCalendar mesAnterior = new GregorianCalendar();
			Integer meses = MESES_REPORTE_SARS_LIBERADOS_FROM;
			mesAnterior.add(Calendar.MONTH, -meses);;

			int mesTo = FuncionesComunesPLI.gregorianCalendar2int(mesAnterior);
			mesTo = mesTo / 100;
			mesTo = mesTo * 100;

			SarBO buscaSar = new SarBO();
			buscaSar.setIntervalosFechaEmbarcacion(
					"AND (((etdfinal IS NOT NULL AND etdfinal > 0)  AND (etdfinal <= "+ mesFrom + " AND etdfinal >= "+ mesTo + "))"+
							"OR (fechaembarque <= "+ mesFrom + " AND fechaembarque >= "+ mesTo + "));"
			);
			List<SarBO> lstSars = dao.selectSar(buscaSar, false);
			List<SarBO> lstSarsFiltrados = new ArrayList<SarBO>(2000);
			for (SarBO sarBean : lstSars) {
				if (sarBean.getStatus() == SarBO.STATUS_SIN_SOLICITUD_APROBACION
						|| sarBean.getStatus() == SarBO.STATUS_ESPERA_APROBACION_PLANEACION) {
					continue;
				}
				lstSarsFiltrados.add(sarBean);
			}
			// voy por las fechas de la ultima modificacion de ETD por SAR
			HashMap<Integer, SARHistoryLogBean> ultimaModificacionETDXSAR = new HashMap<Integer, SARHistoryLogBean>();
			List<SARHistoryLogBean> listaHistoricos = SAR_CDI_DAO.selectSARHistoryLogBulk(lstSars,
					buscaSar.getIntervalosFechaEmbarcacion());
			for (SARHistoryLogBean bean : listaHistoricos) {
				if (ultimaModificacionETDXSAR.containsKey(bean.getFolio())) {
					SARHistoryLogBean tmp = ultimaModificacionETDXSAR.get(bean.getFolio());
					if (bean.getModificationTimeStamp() > tmp.getModificationTimeStamp()
							&& !bean.getEtd().equals(tmp.getEtd())) {
						// Si es mayor la fecha y no es igual la ETD entonces es mas reciente el ETD y
						// es mi
						// nuevo elemento a considerar
						ultimaModificacionETDXSAR.put(bean.getFolio(), bean);
					}
				} else {
					// Si no esta en el mapa lo agrego, esa es mi primera ETD
					ultimaModificacionETDXSAR.put(bean.getFolio(), bean);
				}
			}
			// voy por las fechas de la ultima modificacion de ETD por SAR

			GregorianCalendar tiempoDetalle = new GregorianCalendar();
			// Voy al nuevo WS por la informacion
			FuncionesComunesPLI.dameDatosCDIDetalle(lstSarsFiltrados);
			GregorianCalendar tiempoDetalle2 = new GregorianCalendar();
			log.info("Tiempo Finalizando la consulta al ws de : {} en: {} Segundos", lstSarsFiltrados.size(),
					((tiempoDetalle2.getTimeInMillis() - tiempoDetalle.getTimeInMillis()) / 1000));

			for (SarBO sarBean : lstSarsFiltrados) {
				List<SarDetalleBO> lstDetalle = FuncionesComunesPLI.getDetalleSAR(sarBean);
				if (lstDetalle == null) {
					continue;
				}
				
				Integer eta= sarBean.getEta();
				String voyage =sarBean.getViaje();
				sarBean.setDetalleBO(lstDetalle);
				sarBean.setValorEmbarque(FuncionesComunesPLI.CERO);

				// Voy a recorrer 2 veces el detalle, 1 para sacar los totales y la otra para
				// pintar
				List<SarDetalleBO> listaDetOtros = SAR_CDI_DAO.consultaDetalleOtros(sarBean.getFolio().toString());
				// En este ciclo saco los totales, que se guardan en el SARBO, en el siguiente
				// ciclo se pintan datos, pero ya no se calcula nadaBigDecimal backOrderTotal =
				// FuncionesComunesPLI.CERO;
				
				FuncionesComunesPLI.sacaTotales(sarBean, (ArrayList<SarDetalleBO>) lstDetalle, listaDetOtros);

				for (SarDetalleBO detBean : lstDetalle) {
					
					// se consultan los totales por detalle del sar
					Set<String> setCompradores = new HashSet<String>();
					SarDetalleReporte detalleJas = new SarDetalleReporte();
					Integer ida = detBean.getInventaroAlArribo() == null ? 0 : detBean.getInventaroAlArribo();
					Integer piDateIDAmin = detBean.getDifDiasConfirm() == null ? 0
							: detBean.getDifDiasConfirm().intValue();
					String piDate = piDateIDAmin == 0 ? "N.D." : FuncionesComunesPLI.formateaFecha(piDateIDAmin);

					// buscar datos
					SARHistoryLogBean sARHistoryLogBean = new SARHistoryLogBean();
					sARHistoryLogBean.setFolio(detBean.getFolio());
					List<SARHistoryLogBean> historyList = SAR_CDI_DAO.selectSARHistoryLog(sARHistoryLogBean);
					Format dateIntegerFormat = new SimpleDateFormat("dd/MM/yyyy");
					detalleJas.setFechaReciboBooking("-");
					detalleJas.setFechaLibBooking("-");
					detalleJas.setFechaSolCon("-");
					detalleJas.setFechaSolTSR("-");
					detalleJas.setFechaCierreTSR("-"); 
					for (SARHistoryLogBean hist : historyList) {
						if (hist.getAction() == HistoryLogAction.BOOKING_REQUEST_BY_VENDOR.id()) {
							if(hist.getCreateDate() != null) {
								detalleJas.setFechaReciboBooking(dateIntegerFormat.format(hist.getCreateDate()));
							}else if(hist.getModificationDate() != null) {
								detalleJas.setFechaReciboBooking(convertDateIntToString(hist.getModificationDate().toString()));
							}
						}
					
						if (hist.getAction() == HistoryLogAction.BOOKING_REGISTERED.id()) {
							if(hist.getCreateDate() != null) {
								detalleJas.setFechaLibBooking(dateIntegerFormat.format(hist.getCreateDate()));
							}else if(hist.getModificationDate() != null) {
								detalleJas.setFechaLibBooking(convertDateIntToString(hist.getModificationDate().toString()));
							}
							
						}
						if (hist.getAction() == HistoryLogAction.EMPTY_CONTAINER_CONFIRMED.id()) {
							if(hist.getCreateDate() != null) {
								detalleJas.setFechaSolCon(dateIntegerFormat.format(hist.getCreateDate()));
							}else if(hist.getModificationDate() != null) {
								detalleJas.setFechaSolCon(convertDateIntToString(hist.getModificationDate().toString()));
							}
							
						}
						if (hist.getAction() == HistoryLogAction.SAR_WITH_TSR.id()) {
							if(hist.getCreateDate() != null) {
								detalleJas.setFechaSolTSR(dateIntegerFormat.format(hist.getCreateDate()));
							}else if(hist.getModificationDate() != null) {
								detalleJas.setFechaSolTSR(convertDateIntToString(hist.getModificationDate().toString()));
							}
							
						}
						if (hist.getAction() == HistoryLogAction.TSR_CLOSED.id() ) {
							if(hist.getCreateDate() != null) {
								detalleJas.setFechaCierreTSR(dateIntegerFormat.format(hist.getCreateDate()));
							}else if(hist.getModificationDate() != null) {
								detalleJas.setFechaCierreTSR(convertDateIntToString(hist.getModificationDate().toString()));
							}
						}
					}
					
					Integer folioSinFormato = sarBean.getFolio();
					HashMap<String, ItemsSeleccionados> listItems = itemsDirectosService.obtenerItemsSeleccionados(folioSinFormato);

					FormatSAR format = new FormatSAR(sarBean, null);
					detalleJas.setFolio(format.getFolio());
					detalleJas.setStatus(FuncionesComunesPLI.unescapeHtml(format.getStatus()));
					detalleJas.setMaterial(detBean.getMaterial() + "");
					detalleJas.setTipoEmbarque(sarBean.esAereo() ? "A" : (sarBean.getConsolidado() ? "C" : "F"));
					detalleJas.setFolioConsolidado(format.getFolioConsolidado());
					if (ultimaModificacionETDXSAR.get(detBean.getFolio()) != null) {
						detalleJas.setUltimaModificacionETD(FuncionesComunesPLI.formateaFecha(
								ultimaModificacionETDXSAR.get(detBean.getFolio()).getModificationDate()));
					}

					// Saco el email del usuario que acepto el folio para darle aviso
					UserBean u = new UserBean();
					u.setUserName(sarBean.getUsuarioApruebaPlanning());
					List<UserBean> usersList = new ArrayList<UserBean>();
					usersList = SAR_CDI_DAO.dameUsuarios(u);

					detalleJas
							.setConfirmador(
									usersList != null && usersList.size() > 0
											? (usersList.get(0) != null && usersList.get(0).getRealName() != null
													? usersList.get(0).getRealName()
													: "N.D")
											: "N.D");

					// Saco la celula de ventas que viene del producto
					ProductoBean p = FuncionesComunesPLI.productos.get(detBean.getMaterial() + "");
					String cellCode = "";
					if (p != null && p.getProductoCentro() != null) {
						Map<String, ProductoCentro> mapaProdCentro = p.getProductoCentro();
						String centro = p.isMateriaPrima() ? detalleJas.getCentro() : "P5";
						ProductoCentro prodCentro = mapaProdCentro.get(centro);
						if (prodCentro != null) {
							cellCode = prodCentro.getCellCode();
						}
					}
					String direcUnidadNeg = FuncionesComunesPLI.mapaCelulasUnidadNegocio.get(cellCode);

					if (direcUnidadNeg == null) {
						detalleJas.setDirectorBU("N.D");
						detalleJas.setComprado("N.D");
					} else {
						detalleJas.setDirectorBU(direcUnidadNeg == null ? "N.D" : direcUnidadNeg);
						Map<String, List<CompradoresBean>> mapaResponsablesCompras = FuncionesComunesPLI.mapaCompradorCelula
								.get("responsables");
						Map<String, List<CompradoresBean>> mapaCompradores = FuncionesComunesPLI.mapaCompradorCelula
								.get("compradores");

						if (mapaResponsablesCompras != null) {
							List<CompradoresBean> lstResponsables = mapaResponsablesCompras.get(cellCode);
							if (lstResponsables != null) {
								for (CompradoresBean responsablesCompras : lstResponsables) {
									setCompradores.add(responsablesCompras.getNombre());
								}
							}
						}
						if (mapaCompradores != null) {
							List<CompradoresBean> lstCompradores = mapaCompradores.get(cellCode);
							if (lstCompradores != null) {
								for (CompradoresBean compradores : lstCompradores) {
									setCompradores.add(compradores.getNombre());
								}
							}
						}

						if (setCompradores.isEmpty()) {
							detalleJas.setComprado("N.D");
						} else {
							int cont = 0;
							String compradores = "";
							for (String comprador : setCompradores) {
								if (cont > 0) {
									compradores += "; ";
								}
								compradores += comprador;
								cont++;
							}
							detalleJas.setComprado(compradores);
						}

					}
					detalleJas.setFechaSolicitudSAR(format.getFechaSolicitadoProveedor());
					detalleJas.setEtdSupplier(format.getEtdProveedor());
					detalleJas.setFechaLiberacionPlanner(format.getFechaAprobadoPlannning());
					detalleJas.setEta(eta.toString());
					if(eta!=null) {
						if(eta.intValue()>0) {
							try {
								String patternNuevo = "dd/MM/yyyy";
								String patternViejo = "yyyyMMdd";
								SimpleDateFormat simpleDateFormat = new SimpleDateFormat(patternViejo);
								Date date = simpleDateFormat.parse(eta.toString());
								simpleDateFormat = new SimpleDateFormat(patternNuevo);
								detalleJas.setEta(simpleDateFormat.format(date));
							}catch(Exception e) {log.error("Problemas conparseo de fecha");}
						}
					}
					
					detalleJas.setVoyage(voyage);
					int diasEnPlanning = 0;
					if (sarBean.getFecIniShipping() != null && sarBean.getFecIniShipping() > 0
							&& sarBean.getStatus() != 4 && sarBean.getStatus() != 7 && sarBean.getStatus() > 1) {
						diasEnPlanning = Utilerias.diasHabiles(sarBean.getFecIniPlanning(), sarBean.getFecIniShipping(),
								false);
					} else if (sarBean.getStatus() == 1) {
						diasEnPlanning = Utilerias.diasHabiles(sarBean.getFecIniPlanning(), hoySegundos, false);
					} else if (sarBean.getStatus() == 4
							&& (sarBean.getFecIniShipping() == null || sarBean.getFecIniShipping() == 0)
							&& sarBean.getTinyFecIniPlanning() != null) {
						diasEnPlanning = Utilerias.diasHabiles(sarBean.getTinyFecIniPlanning(),
								sarBean.getFechaUltimaAprobacionRechazo(), false);
					} else if (sarBean.getStatus() == 7
							&& (sarBean.getFecIniShipping() == null || sarBean.getFecIniShipping() == 0)
							&& sarBean.getTinyFecIniPlanning() != null) {
						int fechaRechazo = sarBean.getFechaUltimoRechazo() == null
								|| sarBean.getFechaUltimoRechazo() == 0 ? sarBean.getFechaUltimaAprobacionRechazo()
										: sarBean.getFechaUltimoRechazo();
						diasEnPlanning = Utilerias.diasHabiles(sarBean.getTinyFecIniPlanning(), fechaRechazo, false);
					} else {
						diasEnPlanning = 0;
					}

					detalleJas.setDiasSupplierToPlanner(diasEnPlanning + "");
					detalleJas.setVencidoPlaneacion((diasEnPlanning >= TOLERANCIA_PLANEACION) ? "SI" : "NO");

					int diasEnShipping = 0;
					if (sarBean.getConsolidado()) {
						if (sarBean.getTinyFecIniConsolidados() != null && sarBean.getTinyFecIniConsolidados() > 0
								&& sarBean.getStatus() != 4 && sarBean.getStatus() != 7 && sarBean.getStatus() > 2) {
							diasEnShipping = Utilerias.diasHabiles(sarBean.getFecIniShipping(),
									sarBean.getFecIniConsolidados(), false);
						} else if (sarBean.getStatus() == 2 && !sarBean.getNeedsAuthImpDir()) {
							diasEnShipping = Utilerias.diasHabiles(sarBean.getFecIniShipping(), hoySegundos, false);
						} else if (sarBean.getStatus() == 2 && sarBean.getNeedsAuthImpDir()) {
							diasEnShipping = Utilerias.diasHabiles(sarBean.getFechaAprobacionDirImportaciones(), hoy,
									false);
						} else if (sarBean.getStatus() == 4
								&& (sarBean.getTinyFecIniConsolidados() == null
										|| sarBean.getTinyFecIniConsolidados() == 0)
								&& sarBean.getTinyFecIniShipping() != null) {
							diasEnShipping = Utilerias.diasHabiles(sarBean.getTinyFecIniShipping(),
									sarBean.getFechaUltimaAprobacionRechazo(), false);
						} else if (sarBean.getStatus() == 7
								&& (sarBean.getTinyFecIniConsolidados() == null
										|| sarBean.getTinyFecIniConsolidados() == 0)
								&& sarBean.getTinyFecIniShipping() != null) {
							int fechaRechazo = sarBean.getFechaUltimoRechazo() == null
									|| sarBean.getFechaUltimoRechazo() == 0 ? sarBean.getFechaUltimaAprobacionRechazo()
											: sarBean.getFechaUltimoRechazo();
							diasEnShipping = Utilerias.diasHabiles(sarBean.getTinyFecIniShipping(), fechaRechazo,
									false);
						} else {
							diasEnShipping = 0;
						}
					} else {
						if (sarBean.getTinyFecIniBooking() != null && sarBean.getTinyFecIniBooking() > 0
								&& sarBean.getStatus() != 4 && sarBean.getStatus() != 7 && sarBean.getStatus() > 2) {
							diasEnShipping = Utilerias.diasHabiles(sarBean.getFecIniShipping(),
									sarBean.getFecIniBooking(), false);
						} else if (sarBean.getStatus() == 2 && !sarBean.getNeedsAuthImpDir()) {
							diasEnShipping = Utilerias.diasHabiles(sarBean.getFecIniShipping(), hoySegundos, false);
						} else if (sarBean.getStatus() == 2 && sarBean.getNeedsAuthImpDir()) {
							diasEnShipping = Utilerias.diasHabiles(sarBean.getFechaAprobacionDirImportaciones(), hoy,
									false);
						} else if (sarBean.getStatus() == 4
								&& (sarBean.getFecIniBooking() == null || sarBean.getFecIniBooking() == 0)
								&& sarBean.getTinyFecIniShipping() != null) {
							diasEnShipping = Utilerias.diasHabiles(sarBean.getTinyFecIniShipping(),
									sarBean.getFechaUltimaAprobacionRechazo(), false);
						} else if (sarBean.getStatus() == 7
								&& (sarBean.getFecIniBooking() == null || sarBean.getFecIniBooking() == 0)
								&& sarBean.getTinyFecIniShipping() != null) {
							int fechaRechazo = sarBean.getFechaUltimoRechazo() == null
									|| sarBean.getFechaUltimoRechazo() == 0 ? sarBean.getFechaUltimaAprobacionRechazo()
											: sarBean.getFechaUltimoRechazo();
							diasEnShipping = Utilerias.diasHabiles(sarBean.getTinyFecIniShipping(), fechaRechazo,
									false);
						} else {
							diasEnShipping = 0;
						}
					}

					detalleJas.setDiasPlannerToShipping(diasEnShipping + "");
					detalleJas.setFechaPI(piDate);
					detalleJas.setPO(detBean.getPo());

					detalleJas.setPosicion(detBean.getPosicion() + "");
					detalleJas.setProveedor(format.getProveedorClave());
					detalleJas.setNombreProveedor(format.getProveedor());
					detalleJas.setPlanner(detBean.getPlaneador());

					int etdReporte = (sarBean.getEtdReal() != null && sarBean.getEtdReal() > 0) ? sarBean.getEtdReal()
							: sarBean.getFechaEmbarque();

					detalleJas.setWeek(
							etdReporte == 0 ? "N.D" : FuncionesComunesPLI.numeroSemanaImportaciones(etdReporte) + "");
					detalleJas.setEtd(FuncionesComunesPLI.formateaFecha(etdReporte));
					detalleJas.setPuertoOrigen(format.getPuertoOrigen());
					detalleJas.setTipoContenedor(format.getTipoContenedor());
					detalleJas.setVolume(format.getVolumen());
					double varPeso = (sarBean.getDifPesoUserVSSystem() == null ? 0d : sarBean.getDifPesoUserVSSystem())
							* 100 / sarBean.getPeso();
					double varVol = (sarBean.getDifVolUserVSSystem() == null ? 0d : sarBean.getDifVolUserVSSystem())
							* 100 / sarBean.getVolumen();

					detalleJas.setVariacionVolumen(FuncionesComunesPLI.formatea(varVol, 0, false));
					detalleJas.setPeso(format.getPeso());
					detalleJas.setVariacionPeso(FuncionesComunesPLI.formatea(varPeso, 0, false));
					detalleJas.setNaviera(format.getNaviera());

					detalleJas.setVessel(format.getBarcoSugerido());
					detalleJas.setNumContenedor(format.getContenedor());
					detalleJas.setBooking(format.getBooking());
					detalleJas.setPuertoDestino(FuncionesComunesPLI.unescapeHtml(format.getPuertoDescarga()));
					detalleJas.setIDA(ida + "");
					
					ItemsSeleccionados item = listItems.get(folioSinFormato + "|" + detalleJas.getPO() + "|" + detalleJas.getPosicion());
					
					if(item != null) {
						detalleJas.setBackorder("0.00");
					} else {
						detalleJas.setBackorder(detBean.getBackorderPronosticado() == null ? "0"
								: FuncionesComunesPLI.formatea(detBean.getBackorderPronosticado().doubleValue(), 2, false));
					}
						
					detalleJas.setIndicadorRetraso(sarBean.getTipoRetraso() == null ? ""
							: FuncionesComunesPLI.getTipoRetraso() == null ? ""
									: FuncionesComunesPLI.getTipoRetraso().get(sarBean.getTipoRetraso()));

					if (sarBean.getAprobadoProveedor()) {

						detalleJas.setStatusConfirmacionFinal("With final confirmation");
						detalleJas.setDiasSinConfirmacionFinal("0");
					} else if (sarBean.getStatus() == SAR.STATUS_APROBADO
							|| sarBean.getStatus() == SAR.STATUS_EMBARCADO) {

						int fechaEtd = sarBean.getEtdReal() == null || sarBean.getEtdReal() == 0
								? sarBean.getFechaEmbarque()
								: sarBean.getEtdReal();
						int diasSinConfirmacionFinal = (int) FuncionesComunesPLI.daysBetween(hoy, fechaEtd);

						detalleJas.setStatusConfirmacionFinal("No");
						detalleJas.setDiasSinConfirmacionFinal(diasSinConfirmacionFinal + "");
					} else {

						detalleJas.setStatusConfirmacionFinal("No");
						detalleJas.setDiasSinConfirmacionFinal("0");
					}

					detalleJas.setPrioridad(format.getColorPrioridadTxt());
					detalleJas.setComentariosPlanerador(sarBean.getComentarioPlanner());
					detalleJas.setComentariosDirectorImports(sarBean.getImpDirComments());

					//Adding Reference Number Release Date of Shipping
					String referenceN = dao.findReferenceNumberByfolio(Integer.toString(sarBean.getFolio()));
					if(referenceN == null || referenceN.isEmpty()) detalleJas.setReferenceNumber("-");
					else detalleJas.setReferenceNumber(referenceN);
					
					//Adding Release Date of Shipping
					String sarsApprovedS = dao.getReleaseDateByShipping(Integer.toString(sarBean.getFolio())); 
					if(sarsApprovedS == null || sarsApprovedS.isEmpty()) 
						detalleJas.setFechaLiberacionShipping("N.D");
					else 
						detalleJas.setFechaLiberacionShipping(
								FuncionesComunesPLI.formateaFecha(
										Integer.parseInt(sarsApprovedS)));
					
					//Adding Goods Ready Date
					String fechaGDR = (sarBean.getGoodsReadyDateStr() == null || sarBean.getGoodsReadyDateStr().isEmpty())?
							"N.D": sarBean.getGoodsReadyDateStr();
							detalleJas.setFechaGDR(fechaGDR);
					if(sarBean.getReferenciaContenedorProveedor() == null || sarBean.getReferenciaContenedorProveedor().isEmpty()) {
						detalleJas.setReferenciaContenedorProveedor("-");
					}else {
						detalleJas.setReferenciaContenedorProveedor(sarBean.getReferenciaContenedorProveedor());
					}

					if(sarBean.getBl() == null || sarBean.getBl().isEmpty()){
						detalleJas.setBl("-");
					}else{
						detalleJas.setBl(sarBean.getBl());
					}

					detallesReporte.add(detalleJas);
				}
			} // Fin de for detalle
			
			
			
			InputStream jrxXmlInputStream = ReportesHelper.getInstance().getInputStream("sarsApproved1.jrxml");

			String path = RUTA_SARS_APPROVED + File.separator;

			String fileName = "SARsApproved_" + hoy + ".xls";
			
			JRDataSource jrDataSource = new JRBeanCollectionDataSource(detallesReporte);

			JasperServices js = new JasperServices(jrxXmlInputStream, jrDataSource, null);

			byte[] reporteBytes = js.getReportByteArray(JasperServices.XLS_TYPE);

			FileUtils.writeByteArrayToFile(new File(path + fileName), reporteBytes);
			File xls = new File(path + fileName);
			MailUtils.enviaCorreo(mailsTo, mailsCC, "SARs released by Planning & Shipping", mailFrom, "", xls);
			GregorianCalendar greg2 = new GregorianCalendar();
			log.info("FIN:: {} Segundos", ((greg2.getTimeInMillis() - greg1.getTimeInMillis()) / 1000));
			log.info("**Terminado envio de SARs liberados por Planning y Shipping {}",
					Calendar.getInstance().toString());
		} catch (Exception e) {
			log.error("Error al crear el reporte: ", e);
		}
	}
	
	private String convertDateIntToString(String data) {
		if( data !=null) {
			try {
				String patternNuevo = "dd/MM/yyyy";
				String patternViejo = "yyyyMMdd";
				SimpleDateFormat simpleDateFormat = new SimpleDateFormat(patternViejo);
				Date date = simpleDateFormat.parse(data);
				simpleDateFormat = new SimpleDateFormat(patternNuevo);
				return simpleDateFormat.format(date);
			}catch(Exception e) {log.error("Problemas con parseo de fecha");}
		}
		return "-";
	}

	public void reporteSARsPendingPlannerApproval() {
		try {
			FuncionesComunesPLI.cargaPropertiesCDI(false);
			FuncionesComunesPLI.cargaProductos(false);
			FuncionesComunesPLI.cargaUnidadesNeg(false);
			FuncionesComunesPLI.cargaCompradores(false);
			FuncionesComunesPLI.cargaMapaCelulasXUnidadNegocio(false);
			FuncionesComunesPLI.cargaContenedores(false);
			FuncionesComunesPLI.cargaNavieras(false);
			FuncionesComunesPLI.cargaPuertosOrigen(false);
			FuncionesComunesPLI.cargaPuertosDestino(false);
			FuncionesComunesPLI.cargaPuertosDirectos(false);
			FuncionesComunesPLI.cargaPlanners(false);
			FuncionesComunesPLI.getProveedores(false);
		} catch (Exception e) {
			e.printStackTrace();
		}
		log.info("Inicia envio de SARs pendientes de liberaci�n por Planning...");
		SAR_CDI_DAO dao = new SAR_CDI_DAO();
		GregorianCalendar gc = new GregorianCalendar();
		int hoy = FuncionesComunesPLI.gregorianCalendar2int(gc);
		long hoySegundos = gc.getTimeInMillis() / 1000L;
		String mailFrom = CorreoHelper.getInstance().getEmail(MAIL_FR_HK_SYSTEM);
		String[] mailsTo = { CORREO_SHIPPING };
		String[] mailsCC = { CORREO_IGARCIAQ, CORREO_RENE, CORREO_DAVID };

		ArrayList<SarDetalleReporte> detallesReporte = new ArrayList<SarDetalleReporte>();
		try {
			Map<String, PlaneadorBean> mapaPlanners = FuncionesComunesPLI.planners;

			SarBO buscaSar = new SarBO();
			buscaSar.setStatus(SAR.STATUS_ESPERA_APROBACION_PLANEACION);
			List<SarBO> lstSars = dao.selectSar(buscaSar, false);
			FuncionesComunesPLI.dameDatosCDIDetalle(lstSars);

			PlaneadorBean plannerBean = null;
			HashMap<String, SarDetalleBO> detalleSinRepetidos = null;
			for (SarBO sarBean : lstSars) {

				List<SarDetalleBO> lstDetalle = FuncionesComunesPLI.getDetalleSAR(sarBean);
				int diasEnPlanning = Utilerias.diasHabiles(sarBean.getFecIniPlanning(), hoySegundos, false);
				ImportacionesProveedoresBean ipb = FuncionesComunesPLI.getProveedor(sarBean.getProveedor());
				BeanPuerto ptoOrigen = FuncionesComunesPLI.mapaPuertosOrigen == null ? null
						: FuncionesComunesPLI.mapaPuertosOrigen.get(sarBean.getPuertoOrigen());
				BigDecimal backorderTmp = FuncionesComunesPLI.CERO;
				int idaTmp = 0;
				String pos = "";
				String planner = "";
				boolean posIncompletas = false;
				String etdPI = "";
				detalleSinRepetidos = new HashMap<String, SarDetalleBO>();
				for (SarDetalleBO detBean : lstDetalle) {
					if (!"".equals(pos)) {
						pos += ",";
					}
					if (!"".equals(etdPI)) {
						etdPI += ",";
					}
					pos += detBean.getPo();
					planner = detBean.getPlaneador();
					Integer ida = detBean.getInventaroAlArribo() == null ? 0 : detBean.getInventaroAlArribo();
					BigDecimal backOrder = detBean.getBackorderPronosticado() == null ? FuncionesComunesPLI.CERO
							: detBean.getBackorderPronosticado();

					if (idaTmp > ida) {
						idaTmp = ida;
						backorderTmp = backOrder;
					}
					if (!posIncompletas) {
						if (detBean.isNoEsPOCompleta()) {
							posIncompletas = true;
						}
					}
					etdPI += detBean.getFechaProforma() != null
							? FuncionesComunesPLI.formateaFecha(detBean.getFechaProforma())
							: "";

					if (detalleSinRepetidos.containsKey(detBean.getPo())) {
						SarDetalleBO datoEnMapa = detalleSinRepetidos.get(detBean.getPo());
						if (detBean.getInventaroAlArribo() != null && detBean.getInventaroAlArribo()
								.intValue() < datoEnMapa.getInventaroAlArribo().intValue()) {
							// reemplazo por el ida menor
							detalleSinRepetidos.put(detBean.getPo(), detBean);
						}

					} else {
						detalleSinRepetidos.put(detBean.getPo(), detBean);
					}
				}
				// Recorro primero todo el detalle saco los valores minimos y el planeador con
				// el IDA menor y pinto

				for (Entry<String, SarDetalleBO> entry : detalleSinRepetidos.entrySet()) {

					// Esto debe ir dentro de detalle por el momento no lo incluyo
					SarDetalleReporte beanRepo = new SarDetalleReporte();
					beanRepo.setFolio(sarBean.getFolioCompleto());
					beanRepo.setTipoEmbarque(sarBean.esAereo() ? "A" : sarBean.getConsolidado() ? "C" : "F");
					beanRepo.setFechaSolicitudSAR(FuncionesComunesPLI.formateaFecha(sarBean.getTinyFecIniPlanning()));
					beanRepo.setDiasSupplierToPlanner(diasEnPlanning + "");
					beanRepo.setPO(entry.getValue().getPo());
					beanRepo.setProveedor(sarBean.getProveedor());
					beanRepo.setNombreProveedor(ipb == null ? "-" : ipb.getNombreProveedor());
					beanRepo.setPlanner(entry.getValue().getPlaneador());
					beanRepo.setEtd((sarBean.getEtdReal() != null && sarBean.getEtdReal() > 0)
							? FuncionesComunesPLI.formateaFecha(sarBean.getEtdReal())
							: FuncionesComunesPLI.formateaFecha(sarBean.getFechaEmbarque()));
					beanRepo.setPuertoOrigen(ptoOrigen != null ? ptoOrigen.getNombre() : "-");

					plannerBean = mapaPlanners.get(entry.getValue().getPlaneador());

					beanRepo.setNombrePlaneador(plannerBean == null ? "-" : plannerBean.getNombre());/// confirmador
					beanRepo.setGerente(plannerBean == null ? "-"
							: plannerBean.getGerente() == null ? "" : plannerBean.getGerente());
					beanRepo.setIDA(entry.getValue().getInventaroAlArribo() != null
							? entry.getValue().getInventaroAlArribo() + ""
							: "0");
					beanRepo.setBackorder(entry.getValue().getBackorderPronosticado() != null ? FuncionesComunesPLI
							.formatea(entry.getValue().getBackorderPronosticado().doubleValue(), 2, false) : "0");
					beanRepo.setIndicadorVariacionCantidades(posIncompletas ? "SI" : "NO");
					beanRepo.setFechaPI(entry.getValue().getFechaProforma() != null
							? FuncionesComunesPLI.formateaFecha(entry.getValue().getFechaProforma())
							: "N.D");/// fechaproforma
					beanRepo.setDiasETDvsSolicitudSAR("" + Utilerias.diasHabiles(sarBean.getTinyFecIniPlanning(),
							(sarBean.getEtdReal() != null && sarBean.getEtdReal() > 0) ? sarBean.getEtdReal()
									: sarBean.getFechaEmbarque(),
							false));
					beanRepo.setQuemadoToleranciaPlanning((diasEnPlanning >= TOLERANCIA_PLANEACION) ? "SI" : "NO");

					detallesReporte.add(beanRepo);
				}
			}

			InputStream jrxXmlInputStream = getClass().getClassLoader().getResourceAsStream("sarsForApproval.jrxml");

			String path = RUTA_SARS_PENDING + File.separator;

			String fileName = "SARsPendingApproval_PLANNING_" + hoy + ".xls";

			JRDataSource jrDataSource = new JRBeanCollectionDataSource(detallesReporte);

			JasperServices js = new JasperServices(jrxXmlInputStream, jrDataSource, null);

			byte[] reporteBytes = js.getReportByteArray(JasperServices.XLS_TYPE);

			FileUtils.writeByteArrayToFile(new File(path + fileName), reporteBytes);
			File xls = new File(path + fileName);

			MailUtils.enviaCorreo(mailsTo, mailsCC, "SARs pending Approval by Planning", mailFrom, "", xls);
			log.info("**Terminado envio de SARs pendientes de liberación por Planning "
					+ Calendar.getInstance().toString());
		} catch (Exception e) {
			log.error("Error al crear el reporte pendientes de liberación por Planning : ", e);
			e.printStackTrace();
		}
	}

	public void generaReporteBooking() {
		try {
			FuncionesComunesPLI.cargaPropertiesCDI(false);
			FuncionesComunesPLI.cargaProductos(false);
			FuncionesComunesPLI.getProveedores(false);
			FuncionesComunesPLI.cargaNavieras(false);
			log.info("Inicia envio de reporte de cambios de ETD por Booking...");
			GregorianCalendar gc = new GregorianCalendar();
			int diasAntes = -1;
			if (gc.get(Calendar.DAY_OF_WEEK) == Calendar.MONDAY) {
				diasAntes = -3;
			}
			gc.add(Calendar.DAY_OF_MONTH, diasAntes);
			int ayer = FuncionesComunesPLI.gregorianCalendar2int(gc);
			String mailFrom = CorreoHelper.getInstance().getEmail(MAIL_FR_HK_SYSTEM);
			String[] mailsTo = SarBO.MAIL_GRUPO_REPORTE_CAMBIOS_ETD;

			List<ReporteCambiosETDBooking> lstCambiosEtd = SAR_CDI_DAO.cambiosETDBooking(ayer);

			for (ReporteCambiosETDBooking reporte : lstCambiosEtd) {
				SarBO sarBean = new SarBO();
				sarBean.setFolio(Integer.valueOf(reporte.getFolio()));
				List<SarDetalleBO> lstDetalles = FuncionesComunesPLI.getDetalleSAR(sarBean);
				List<SarDetalleBO> listaDetOtros = SAR_CDI_DAO.consultaDetalleOtros(sarBean.getFolio().toString());
				Set<String> setPlanners = new HashSet<String>();
				for (SarDetalleBO det : lstDetalles) {
					setPlanners.add(det.getPlaneador());
				}
				int contPlanners = 0;
				String planners = "";
				for (String planner : setPlanners) {
					if (contPlanners > 0) {
						planners += ", ";
					}
					planners += planner;
					contPlanners++;
				}
				reporte.setPlanner(planners);
				FuncionesComunesPLI.sacaTotales(sarBean, (ArrayList<SarDetalleBO>) lstDetalles, listaDetOtros);
				int contPOs = 0;
				String pos = "";
				for (String po : sarBean.getListaPos()) {
					if (contPOs > 0) {
						pos += ", ";
					}
					pos += po;
					contPOs++;
				}
				reporte.setPos(pos);
				reporte.setMinimumIDA(FuncionesComunesPLI.formatea(sarBean.getIda(), 0, false));
				reporte.setForecastedBO(
						FuncionesComunesPLI.formatea(sarBean.getBackorderPronosticadoTot().intValue(), 0, false));
			}

			InputStream jrxXmlInputStream = getClass().getClassLoader().getResourceAsStream("cambiosETDBooking.jrxml");

			String path = RUTA_CAMBIO_ETD_BOOKING + File.separator;

			String fileName = "CambiosETD_Booking_" + ayer + ".xls";

			JRDataSource jrDataSource = new JRBeanCollectionDataSource(lstCambiosEtd);

			JasperServices js = new JasperServices(jrxXmlInputStream, jrDataSource, null);

			byte[] reporteBytes = js.getReportByteArray(JasperServices.XLS_TYPE);

			FileUtils.writeByteArrayToFile(new File(path + fileName), reporteBytes);
			File xls = new File(path + fileName);

			MailUtils.enviaCorreo(mailsTo, null, "CambiosETD_Booking_" + ayer, mailFrom, "", xls);
			log.info("**Terminado envio de reporte de cambios de ETD por TruperBooking "
					+ Calendar.getInstance().toString());

		} catch (Exception e) {
			log.error("Error al crear el reporte de cambios de ETD por TruperBooking : ", e);
			e.printStackTrace();
		}

	}

	public void reporteSARsBooking() {
		log.info("Inicia envio de reporte de SARs in Booking");
		GregorianCalendar greg1 = new GregorianCalendar();
		log.info("ini: {}", greg1.getTimeInMillis());
		try {
			FuncionesComunesPLI.cargaPropertiesCDI(false);
			FuncionesComunesPLI.cargaProductos(false);
			FuncionesComunesPLI.cargaUnidadesNeg(false);
			FuncionesComunesPLI.cargaCompradores(false);
			FuncionesComunesPLI.cargaMapaCelulasXUnidadNegocio(false);
			FuncionesComunesPLI.cargaContenedores(false);
			FuncionesComunesPLI.cargaNavieras(false);
			FuncionesComunesPLI.cargaPuertosOrigen(false);
			FuncionesComunesPLI.cargaPuertosDestino(false);
			FuncionesComunesPLI.cargaPuertosDirectos(false);
			FuncionesComunesPLI.cargaPlanners(false);
			FuncionesComunesPLI.getProveedores(false);
			FuncionesComunesPLI.cargaPlanners(false);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}

		log.info("XXX fin carga init");
		SAR_CDI_DAO dao = new SAR_CDI_DAO();
		GregorianCalendar gc = new GregorianCalendar();
		int hoy = FuncionesComunesPLI.gregorianCalendar2int(gc);
		String mailFrom = CorreoHelper.getInstance().getEmail(MAIL_FR_HK_SYSTEM);
		String[] mailsTo = { CORREO_BOOKING };
		String[] mailsCC = { CORREO_IALOPEZC, CORREO_EAMERAE, CORREO_IVONNE, CORREO_RENE, CORREO_DAVID };
		ArrayList<SarDetalleReporte> detallesReporte = new ArrayList<SarDetalleReporte>();

		// mando a llamar el metodo jasper
		try {
			Integer meses = PropertiesDb.getInstance().getInteger(MESES_REPORTE_BOOKING);
			if (meses == null) {

				log.error("[reporteSARsBooking] No se crea el reporte el propertie {} no est� denifido.",
						MESES_REPORTE_BOOKING);
				return;
			}
			GregorianCalendar mesAnterior = new GregorianCalendar();
			mesAnterior.add(Calendar.MONTH, -meses);

			int mesFrom = FuncionesComunesPLI.gregorianCalendar2int(mesAnterior);
			mesFrom = mesFrom / 100;
			mesFrom = mesFrom * 100;

			SarBO buscaSar = new SarBO();
			String estatus = UtilsString.append(" sar.status IN (", SAR.STATUS_APROBADO, ", ", SAR.STATUS_EMBARCADO, ", ", SAR.STATUS_DOCUMENTOS_SDI, ") ");
			//String estatusSdiNoAprobado = UtilsString.append(" (sar.status = ", SAR.STATUS_INICIO_SDI , " AND (SELECT TOP 1 cdiCtrl.fechaAprobadoSDI FROM cdiControlSDI cdiCtrl WHERE cdiCtrl.proveedor = sar.proveedor AND cdiCtrl.booking = sar.booking) IS NULL )");
			String estatusSdiNoAprobado = UtilsString.append(" (sar.status = ", SAR.STATUS_INICIO_SDI , ")");
			String intervaloEstatus = UtilsString.append(" AND (", estatus, " OR ", estatusSdiNoAprobado, ")");
			buscaSar.setIntervaloEstatus(intervaloEstatus);
			String intervaloFechaCreacion = UtilsString.append(" AND CASE WHEN etdFinal is NULL OR etdFinal = 0 THEN fechaEmbarque ELSE etdFinal END >= ", mesFrom);
			buscaSar.setIntervalosFechaCreacion(intervaloFechaCreacion);
			List<SarBO> lstSars = dao.selectSar(buscaSar, false);

			log.info("XXX Query inicial");

			// voy por las fechas de la ultima modificacion de ETD por SAR
			HashMap<Integer, SARHistoryLogBean> ultimaModificacionETDXSAR = new HashMap<Integer, SARHistoryLogBean>();
			List<SARHistoryLogBean> listaHistoricos = SAR_CDI_DAO.selectSARHistoryLogBulk(lstSars,
					buscaSar.getIntervalosFechaCreacion());

			for (SARHistoryLogBean bean : listaHistoricos) {
				if (ultimaModificacionETDXSAR.containsKey(bean.getFolio())) {
					SARHistoryLogBean tmp = ultimaModificacionETDXSAR.get(bean.getFolio());
					if (bean.getModificationTimeStamp() > tmp.getModificationTimeStamp()
							&& !bean.getEtd().equals(tmp.getEtd())) {
						// Si es mayor la fecha y no es igual la ETD entonces es mas reciente el ETD y
						// es mi
						// nuevo elemento a considerar
						ultimaModificacionETDXSAR.put(bean.getFolio(), bean);
					}
				} else {
					// Si no esta en el mapa lo agrego, esa es mi primera ETD
					ultimaModificacionETDXSAR.put(bean.getFolio(), bean);
				}
			}

			GregorianCalendar tiempoDetalle = new GregorianCalendar();

			// Voy al nuevo WS por la informacion
			FuncionesComunesPLI.dameDatosCDIDetalle(lstSars);
			GregorianCalendar tiempoDetalle2 = new GregorianCalendar();
			log.info("Tiempo Finalizando la consulta al ws de : {} en: {} Segundos", lstSars.size(), ((tiempoDetalle2.getTimeInMillis() - tiempoDetalle.getTimeInMillis()) / 1000));

			for (SarBO sarBean : lstSars) {
				// Nuevo codigo para obtener los detalles.
				List<SarDetalleBO> lstDetalle = FuncionesComunesPLI.getDetalleSAR(sarBean);

				if (lstDetalle == null) {
					continue;
				}

				sarBean.setDetalleBO(lstDetalle);
				sarBean.setValorEmbarque(FuncionesComunesPLI.CERO);

				// Voy a recorrer 2 veces el detalle, 1 para sacar los totales y la otra para
				// pintar
				List<SarDetalleBO> listaDetOtros = SAR_CDI_DAO.consultaDetalleOtros(sarBean.getFolio().toString());
				// En este ciclo saco los totales, que se guardan en el SARBO, en el siguiente
				// ciclo se pintan datos, pero ya no se calcula nadaBigDecimal backOrderTotal =
				// FuncionesComunesPLI.CERO;
				FuncionesComunesPLI.sacaTotales(sarBean, (ArrayList<SarDetalleBO>) lstDetalle, listaDetOtros);

				SarDetalleReporte detalleJas = new SarDetalleReporte();
				StringBuilder compradores = new StringBuilder();
				StringBuilder unidadesNegocio = new StringBuilder();
				StringBuilder bu_descripciones = new StringBuilder();

				FormatSAR format = new FormatSAR(sarBean, null);
				detalleJas.setFolio(format.getFolio());
				detalleJas.setTipoEmbarque(sarBean.esAereo() ? "A" : (sarBean.getConsolidado() ? "C" : "F"));
				detalleJas.setFolioConsolidado(format.getFolioConsolidado());

				// Saco el email del usuario que acepto el folio para darle aviso
				UserBean u = new UserBean();
				u.setUserName(sarBean.getUsuarioApruebaPlanning());
				List<UserBean> usersList = new ArrayList<UserBean>();
				usersList = SAR_CDI_DAO.dameUsuarios(u);

				detalleJas
						.setConfirmador(
								usersList != null && usersList.size() > 0
										? (usersList.get(0) != null && usersList.get(0).getRealName() != null
												? usersList.get(0).getRealName()
												: "N.D")
										: "N.D");

				Set<String> cellCodes = new HashSet<String>();
				Set<String> setCompradores = new HashSet<String>();

				for (SarDetalleBO detBean : lstDetalle) {
					// Saco la celula de ventas que viene del producto
					ProductoBean p = FuncionesComunesPLI.productos.get(detBean.getMaterial() + "");

					if (p != null && p.getProductoCentro() != null) {
						Map<String, ProductoCentro> mapaProdCentro = p.getProductoCentro();
						ProductoCentro prodCentro = mapaProdCentro.get("P5");
						if (prodCentro != null) {
							cellCodes.add(prodCentro.getCellCode());
						}
					}
					log.info("XXX fin Detalle");
				}

				int contBU = 0;
				for (String cellCode : cellCodes) {
					String direcUnidadNeg = FuncionesComunesPLI.mapaCelulasUnidadNegocio.get(cellCode);
					if (direcUnidadNeg == null) {
						detalleJas.setDirectorBU("N.D");
						detalleJas.setComprado("N.D");
					} else {
						String bu = FuncionesComunesPLI.dameMapaCellNames().get(cellCode);
						if (!UtilsString.isStringValida(bu)) {
							bu = "(" + cellCode + " N.D)";
						}
						if (contBU > 0) {
							unidadesNegocio.append("; ");
							bu_descripciones.append("; ");
						}
						bu_descripciones.append(bu);
						unidadesNegocio.append(direcUnidadNeg == null ? "" : direcUnidadNeg);
						contBU++;
						Map<String, List<CompradoresBean>> mapaResponsablesCompras = FuncionesComunesPLI.mapaCompradorCelula
								.get("responsables");
						Map<String, List<CompradoresBean>> mapaCompradores = FuncionesComunesPLI.mapaCompradorCelula
								.get("compradores");

						if (mapaResponsablesCompras != null) {
							List<CompradoresBean> lstResponsables = mapaResponsablesCompras.get(cellCode);
							if (lstResponsables != null) {
								for (CompradoresBean responsablesCompras : lstResponsables) {
									setCompradores.add(responsablesCompras.getNombre());
								}
							}
						}
						if (mapaCompradores != null) {
							List<CompradoresBean> lstCompradores = mapaCompradores.get(cellCode);
							if (lstCompradores != null) {
								for (CompradoresBean compradoresBean : lstCompradores) {
									setCompradores.add(compradoresBean.getNombre());
								}
							}
						}

						if (setCompradores.isEmpty()) {
							detalleJas.setComprado("N.D");
						} else {
							int contComprador = 0;
							if (setCompradores != null) {
								for (String comprador : setCompradores) {
									if (comprador == null)
										continue;
									if (contComprador > 0) {
										compradores.append("; ");
									}
									compradores.append(comprador);
									contComprador++;
								}
							}
						}

					}
				}
				detalleJas.setBU(bu_descripciones.toString());
				detalleJas.setDirectorBU(unidadesNegocio.toString());
				detalleJas.setComprado(compradores.toString());
				detalleJas.setFechaLiberacionShipping(format.getFechaAprobadoShipping());
				String pos = "";
				int contPOs = 0;
				for (int i = 0; sarBean.getListaPos() != null && i < sarBean.getListaPos().size(); i++) {
					String po = sarBean.getListaPos().get(i);
					if (contPOs > 0) {
						pos = pos.concat(", ");
					}
					pos = pos.concat(po);
					contPOs++;
				}
				detalleJas.setPO(pos);
				detalleJas.setNombreProveedor(format.getProveedorClave() + " - " + format.getProveedor());
				int etdReporte = (sarBean.getEtdReal() != null && sarBean.getEtdReal() > 0) ? sarBean.getEtdReal()
						: sarBean.getFechaEmbarque();
				detalleJas.setWeek(
						etdReporte == 0 ? "N.D" : FuncionesComunesPLI.numeroSemanaImportaciones(etdReporte) + "");
				detalleJas.setEtd(format.getFechaEmbarque());
				detalleJas.setEtdFinal(format.getEtdReal());
				detalleJas.setEta(format.getEta());
				detalleJas.setPuertoOrigen(format.getPuertoOrigen());
				detalleJas.setTipoContenedor(format.getTipoContenedor());
				detalleJas.setVolume(format.getVolumen());
				detalleJas.setPeso(format.getPeso());
				detalleJas.setNaviera(format.getNaviera());
				detalleJas.setVessel(format.getBarcoSugerido());
				detalleJas.setNumContenedor(format.getContenedor());
				detalleJas.setBooking(format.getBooking());
				detalleJas.setPuertoDestino(FuncionesComunesPLI.unescapeHtml(format.getPuertoDescarga()));
				detalleJas.setBackorder(format.getBackOrderPron());
				detalleJas.setIDA(format.getIda());
				if (ultimaModificacionETDXSAR.get(sarBean.getFolio()) != null) {
					detalleJas.setUltimaModificacionETD(FuncionesComunesPLI
							.formateaFecha(ultimaModificacionETDXSAR.get(sarBean.getFolio()).getModificationDate()));
				}
				SARHistoricoBooking historico = new SARHistoricoBooking();
				historico.setFolio(sarBean.getFolio());
				historico.setTipoSar("F");
				ArrayList<SARHistoricoBooking> result = new ArrayList<SARHistoricoBooking>();
				result = dao.selectSarHistorico(historico);
				String commentariosBooking = "";
				int contHistBooking = 0;
				for (SARHistoricoBooking temp : result) {
					FormatHistoricoBooking formatHBooking = new FormatHistoricoBooking(temp);
					if (contHistBooking > 0) {
						commentariosBooking = commentariosBooking.concat(", ");
					}
					commentariosBooking = commentariosBooking.concat(formatHBooking.getFechaRegistroFormat())
							.concat(" - ").concat(formatHBooking.getComentario());
					contHistBooking++;
				}
				detalleJas.setComentariosBooking(commentariosBooking);
				detalleJas.setPrioridad(format.getColorPrioridadTxt());

				//complementar
				SAR_CDI_DAO.getInstance().getSarUltimaETD(detalleJas);
				
				detallesReporte.add(detalleJas);
			}

			InputStream jrxXmlInputStream = ReportesHelper.getInstance().getInputStream("reporteSARsBooking.jrxml");

			String path = RUTA_SARS_APPROVED + File.separator;

			String fileName = "reporteSARsBooking_" + hoy + ".xls";

			JRDataSource jrDataSource = new JRBeanCollectionDataSource(detallesReporte, false);

			JasperServices js = new JasperServices(jrxXmlInputStream, jrDataSource, null);

			byte[] reporteBytes = js.getReportByteArray(JasperServices.XLS_TYPE);

			FileUtils.writeByteArrayToFile(new File(path + fileName), reporteBytes);
			File xls = new File(path + fileName);

			MailUtils.enviaCorreo(mailsTo, mailsCC, "SARs in Booking", mailFrom, "", xls);
			GregorianCalendar greg2 = new GregorianCalendar();
			log.info("FIN:: {} Segundos", ((greg2.getTimeInMillis() - greg1.getTimeInMillis()) / 1000));
			log.info("**Terminado envio de reporte de SARs para Truperbooking {}", Calendar.getInstance());
		} catch (Exception e) {
			log.error("Error al crear el reporte: ", e);
		}
	}

	public void verificaEstatusSARs() {
		System.out.println("verificaEstatusSARs...");
		List<SarBO> lstSar = SAR_CDI_DAO.getEstadosFechasSARs();

		try {
			FuncionesComunesPLI.cargaPropertiesCDI(false);
			FuncionesComunesPLI.cargaProductos(false);
			FuncionesComunesPLI.cargaPlanners(false);
			FuncionesComunesPLI.getProveedores(false);
			FuncionesComunesPLI.cargaNavieras(false);

			FuncionesComunesPLI.dameDatosCDIDetalle(lstSar);

			GregorianCalendar gc = new GregorianCalendar();
			Integer hoy = FuncionesComunesPLI.gregorianCalendar2int(new GregorianCalendar());
			long lNow = gc.getTimeInMillis() / 1000;
			if (lstSar == null) {
				log.info("No existen SARs que alertar");
			} else {
				lstAlertaPlanning = new ArrayList<SarBO>();
				lstAlertaShipping = new ArrayList<SarBO>();
				lstAlertaConsol = new ArrayList<SarBO>();
				lstAlertaBooking = new ArrayList<SarBO>();
				lstAlertaSDI = new ArrayList<SarBO>();
				for (SarBO beanSar : lstSar) {
					List<SarDetalleBO> listaDet = FuncionesComunesPLI.getDetalleSAR(beanSar);
					beanSar.setDetalleBO(listaDet);
					int tolerancia = 0;
					switch (beanSar.getStatus()) {
					case 1:
						tolerancia = Utilerias.diasHabiles(beanSar.getFecIniPlanning(), lNow, false);
						beanSar.setDiasEnStatus(tolerancia);
						beanSar.setFechaEnStatus(beanSar.getTinyFecIniPlanning());
						if (tolerancia >= TOLERANCIA_PLANEACION) {
							lstAlertaPlanning.add(beanSar);
						}
						break;
					case 2:
						if (beanSar.getNeedsAuthImpDir()) {
							tolerancia = Utilerias.diasHabiles(beanSar.getFechaAprobacionDirImportaciones(), hoy,
									false);
						} else {
							tolerancia = Utilerias.diasHabiles(beanSar.getFecIniShipping(), lNow, false);
						}
						beanSar.setDiasEnStatus(tolerancia);
						beanSar.setFechaEnStatus(beanSar.getTinyFecIniShipping());
						if (tolerancia >= TOLERANCIA_EMBARQUES) {
							lstAlertaShipping.add(beanSar);
						}
						break;
					case 3:
						if (beanSar.getConsolidado()) {
							tolerancia = Utilerias.diasHabiles(hoy, beanSar.getFechaEmbarque(), false);
							int diasEnStatus = Utilerias.diasHabiles(beanSar.getFecIniConsolidados(), lNow, false);
							beanSar.setDiasEnStatus(diasEnStatus);
							beanSar.setFechaEnStatus(beanSar.getTinyFecIniConsolidados());
							if ((beanSar.getFolioConsolidado() == null || beanSar.getFolioConsolidado() == 0)
									&& tolerancia <= TOLERANCIA_CONSOLIDADOS) {
								lstAlertaConsol.add(beanSar);
							}
						} else {
							tolerancia = Utilerias.diasHabiles(hoy, beanSar.getFechaEmbarque(), false);
							beanSar.setDiasEnStatus(tolerancia);
							beanSar.setFechaEnStatus(beanSar.getTinyFecIniBooking());
							if (!UtilsString.isStringValida(beanSar.getBooking()) && tolerancia <= TOLERANCIA_BOOKING) {
								lstAlertaBooking.add(beanSar);
							}
						}
						break;
					case 6:
						tolerancia = Utilerias.diasHabiles(beanSar.getFecIniSDI(), lNow, false);
						beanSar.setDiasEnStatus(tolerancia);
						beanSar.setFechaEnStatus(beanSar.getTinyFecIniSDI());
						if (!beanSar.esAprobadoSDI() && tolerancia >= TOLERANCIA_SDI) {
							lstAlertaSDI.add(beanSar);
						}
						break;
					default:
						log.error("No se pudo obtener el estatus del SAR: " + beanSar.getFolio());
						break;
					}
				}
			}
			enviaAlertas();
		} catch (ServletException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public boolean enviaAlertas() {
		Map<String, BeanAlertasSAR> alertasMap = obtenerDatosEnvio();

		if (lstAlertaPlanning != null && !lstAlertaPlanning.isEmpty()) {
			BeanAlertasSAR alertas = alertasMap.get("PLANNING");
			if (alertas != null) {
				SAR_CDI_DAO.insertaRegistros("PLANNING", lstAlertaPlanning);
				File anexo = generaXLS(lstAlertaPlanning, "PLANNING");
				enviaCorreo(alertas, lstAlertaPlanning, anexo);
			}
		}
		if (lstAlertaShipping != null && !lstAlertaShipping.isEmpty()) {
			BeanAlertasSAR alertas = alertasMap.get("SHIPPING");
			if (alertas != null) {
				SAR_CDI_DAO.insertaRegistros("SHIPPING", lstAlertaShipping);
				File anexo = generaXLS(lstAlertaShipping, "SHIPPING");
				String cc = alertas.getMailCC();
				cc = UtilsString.append(cc, ";", SAR.EMAIL_IVAN_SHIPPING, ";", SAR.EMAIL_TONO_SHIPPING);
				alertas.setMailCC(cc);
				enviaCorreo(alertas, lstAlertaShipping, anexo);
			}
		}
		if (lstAlertaConsol != null && !lstAlertaConsol.isEmpty()) {
			BeanAlertasSAR alertas = alertasMap.get("CONSOLIDADOS");
			if (alertas != null) {
				SAR_CDI_DAO.insertaRegistros("CONSOLIDADOS", lstAlertaConsol);
				File anexo = generaXLS(lstAlertaConsol, "CONSOLIDADOS");
				enviaCorreo(alertas, lstAlertaConsol, anexo);
			}
		}
		if (lstAlertaBooking != null && !lstAlertaBooking.isEmpty()) {
			BeanAlertasSAR alertas = alertasMap.get("BOOKING");
			if (alertas != null) {
				SAR_CDI_DAO.insertaRegistros("BOOKING", lstAlertaBooking);
				File anexo = generaXLS(lstAlertaBooking, "BOOKING");
				enviaCorreo(alertas, lstAlertaBooking, anexo);
			}
		}
		if (lstAlertaSDI != null && !lstAlertaSDI.isEmpty()) {
			BeanAlertasSAR alertas = alertasMap.get("SDI");
			if (alertas != null) {
				SAR_CDI_DAO.insertaRegistros("SDI", lstAlertaSDI);
				File anexo = generaXLS(lstAlertaSDI, "SDI");
				enviaCorreo(alertas, lstAlertaSDI, anexo);
			}
		}
		return false;
	}

	public StringBuilder creaTablaSars(List<SarBO> lstSars, String estado) {
		StringBuilder sb = new StringBuilder();
		for (SarBO bean : lstSars) {
			if (bean.getDetalleBO() == null || bean.getDetalleBO().isEmpty()) {
				continue;
			}

			String folio = String.valueOf(bean.getFolio());
			String cveProveedor = bean.getProveedor();
			String nombreProveedor = FuncionesComunesPLI.getProveedor(bean.getProveedor()) == null ? ""
					: FuncionesComunesPLI.getProveedor(bean.getProveedor()).getNombreProveedor();
			int etdReporte = (bean.getEtdReal() != null && bean.getEtdReal() > 0) ? bean.getEtdReal()
					: bean.getFechaEmbarque();
			String diasEnStatus = String.valueOf(bean.getDiasEnStatus());
			String fechaEnStatus = FuncionesComunesPLI.formateaFecha(bean.getFechaEnStatus());
			String semanaETD = etdReporte == 0 ? "N.D" : FuncionesComunesPLI.numeroSemanaImportaciones(etdReporte) + "";
			String contenedor = bean.getContenedor() == null ? "" : bean.getContenedor();
			String booking = bean.getBooking() == null ? "" : bean.getBooking();
			String naviera = FuncionesComunesPLI.mapaNavieras.get(bean.getNaviera()) != null
					? FuncionesComunesPLI.mapaNavieras.get(bean.getNaviera()).getNombre()
					: "";
			Map<String, SarDetalleBO> mapaPOs = new HashMap<String, SarDetalleBO>();

			for (SarDetalleBO detalle : bean.getDetalleBO()) {
				BigDecimal backorder = detalle.getBackorderPronosticado() == null ? FuncionesComunesPLI.CERO
						: detalle.getBackorderPronosticado();
				Integer ida = detalle.getInventaroAlArribo() == null ? 0 : detalle.getInventaroAlArribo();
				String numeroOrden = detalle.getPo();
				if (detalle.isPedidoDirecto()) {
					bean.setTienePedidoDirecto(detalle.isPedidoDirecto());
				}
				bean.setAlmacen(detalle.getAlmacen());
				SarDetalleBO detTmp = mapaPOs.get(numeroOrden);
				if (detTmp == null) {
					detTmp = new SarDetalleBO();
					detTmp.setInventaroAlArribo(ida);
					detTmp.setBackorderPronosticado(backorder);
					detTmp.setPlaneador(detalle.getPlaneador());
					mapaPOs.put(numeroOrden, detTmp);
				} else {
					if (detTmp.getInventaroAlArribo() > ida) {
						detTmp.setInventaroAlArribo(ida);
						detTmp.setBackorderPronosticado(backorder);
						detTmp.setPlaneador(detalle.getPlaneador());
					}
				}
			}

			for (Entry<String, SarDetalleBO> orden : mapaPOs.entrySet()) {
				if ("BOOKING".equals(estado)) {
					sb.append("<tr class='texto'>");
					sb.append("<td>" + folio + "</td>");
					sb.append("<td>" + orden.getKey() + "</td>");
					sb.append("<td>" + cveProveedor + "</td>");
					sb.append("<td>" + nombreProveedor + "</td>");
					sb.append("<td>" + orden.getValue().getPlaneador() + "</td>");
					sb.append("<td>" + FuncionesComunesPLI.formateaFecha(etdReporte) + "</td>");
					sb.append("<td>" + diasEnStatus + "</td>");
					sb.append("<td>" + fechaEnStatus + "</td>");
					sb.append("<td>" + semanaETD + "</td>");
					sb.append(
							"<td>" + (bean.getTienePedidoDirecto() == null || !bean.getTienePedidoDirecto() ? "" : "D")
									+ "</td>");
					sb.append("<td>" + orden.getValue().getInventaroAlArribo() + "</td>");
					sb.append("<td>$ "
							+ (orden.getValue().getBackorderPronosticado() == null ? "N/D"
									: FuncionesComunesPLI.formatea(
											orden.getValue().getBackorderPronosticado().doubleValue(), 0, false))
							+ "</td>");
					sb.append("<td>" + contenedor + "</td>");
					sb.append("<td>" + booking + "</td>");
					sb.append("<td>" + naviera + "</td>");
					sb.append("</tr>");
				} else {
					sb.append("<tr class='texto'>");
					sb.append("<td>" + folio + "</td>");
					sb.append("<td>" + orden.getKey() + "</td>");
					sb.append("<td>" + cveProveedor + "</td>");
					sb.append("<td>" + orden.getValue().getPlaneador() + "</td>");
					sb.append("<td>" + FuncionesComunesPLI.formateaFecha(etdReporte) + "</td>");
					sb.append("<td>" + diasEnStatus + "</td>");
					sb.append("<td>" + fechaEnStatus + "</td>");
					sb.append("</tr>");
				}
			}
		}
		return sb;
	}

	public StringBuilder creaTablaEventos(String estado) {
		GregorianCalendar gc = new GregorianCalendar();
		StringBuilder sb = new StringBuilder();
		sb.append("<table>");
		sb.append("<tr class='texto'>");
		sb.append("<td>Eventos Ayer: </td>");
		sb.append("<td>" + SAR_CDI_DAO.getCantidadSARVencidos(-1, estado) + "</td>");
		sb.append("</tr>");
		for (int i = 0; i < 3; i++) {
			int mes = gc.get(Calendar.MONTH);
			sb.append("<tr class='texto'>");
			sb.append("<td>Eventos en " + Utilerias.monthsLarge[mes] + ": </td>");
			sb.append("<td>" + SAR_CDI_DAO.getCantidadSARVencidos(i, estado) + "</td>");
			sb.append("</tr>");
			gc.add(Calendar.MONTH, -1);
		}
		sb.append("</table>");
		return sb;
	}

	public Map<String, BeanAlertasSAR> obtenerDatosEnvio() {
		Map<String, BeanAlertasSAR> alertasMap = new HashMap<String, BeanAlertasSAR>();
		try {
			log.info("Cargando configuracion...\n---------------");

			BeanAlertasSAR alerta = null;
			String descripcion = null;
			String template = null;
			String mailFrom = null;
			String mailTo = null;
			String mailCC = null;
			boolean activo = PropertiesDb.getInstance().getBoolean("alerta.planning.activo");
			if (activo) {
				descripcion = PropertiesDb.getInstance().getStringTrim("alerta.planning.descripcion");
				if (descripcion != null) {
					alerta = new BeanAlertasSAR();
					alerta.setDescripcion(descripcion);
					template = PropertiesDb.getInstance().getStringTrim("alerta.planning.template");
					alerta.setTemplate(template);
					mailFrom = PropertiesDb.getInstance().getStringTrim("alerta.planning.mailFrom");
					alerta.setMailFrom(mailFrom);
					mailTo = PropertiesDb.getInstance().getStringTrim("alerta.planning.mailTo");
					alerta.setMailTo(mailTo);
					mailCC = PropertiesDb.getInstance().getStringTrim("alerta.planning.mailCC");
					alerta.setMailCC(mailCC);
					alertasMap.put(descripcion, alerta);
				}
			}
			activo = PropertiesDb.getInstance().getBoolean("alerta.shipping.activo");
			if (activo) {
				descripcion = PropertiesDb.getInstance().getStringTrim("alerta.shipping.descripcion");
				if (descripcion != null) {
					alerta = new BeanAlertasSAR();
					alerta.setDescripcion(descripcion);
					template = PropertiesDb.getInstance().getStringTrim("alerta.shipping.template");
					alerta.setTemplate(template);
					mailFrom = PropertiesDb.getInstance().getStringTrim("alerta.shipping.mailFrom");
					alerta.setMailFrom(mailFrom);
					mailTo = PropertiesDb.getInstance().getStringTrim("alerta.shipping.mailTo");
					alerta.setMailTo(mailTo);
					mailCC = PropertiesDb.getInstance().getStringTrim("alerta.shipping.mailCC");
					alerta.setMailCC(mailCC);
					alertasMap.put(descripcion, alerta);
				}
			}
			activo = PropertiesDb.getInstance().getBoolean("alerta.consol.activo");
			if (activo) {
				descripcion = PropertiesDb.getInstance().getStringTrim("alerta.consol.descripcion");
				if (descripcion != null) {
					alerta = new BeanAlertasSAR();
					alerta.setDescripcion(descripcion);
					template = PropertiesDb.getInstance().getStringTrim("alerta.consol.template");
					alerta.setTemplate(template);
					mailFrom = PropertiesDb.getInstance().getStringTrim("alerta.consol.mailFrom");
					alerta.setMailFrom(mailFrom);
					mailTo = PropertiesDb.getInstance().getStringTrim("alerta.consol.mailTo");
					alerta.setMailTo(mailTo);
					mailCC = PropertiesDb.getInstance().getStringTrim("alerta.consol.mailCC");
					alerta.setMailCC(mailCC);
					alertasMap.put(descripcion, alerta);
				}
			}
			activo = PropertiesDb.getInstance().getBoolean("alerta.booking.activo");
			if (activo) {
				descripcion = PropertiesDb.getInstance().getStringTrim("alerta.booking.descripcion");
				if (descripcion != null) {
					alerta = new BeanAlertasSAR();
					alerta.setDescripcion(descripcion);
					template = PropertiesDb.getInstance().getStringTrim("alerta.booking.template");
					alerta.setTemplate(template);
					mailFrom = PropertiesDb.getInstance().getStringTrim("alerta.booking.mailFrom");
					alerta.setMailFrom(mailFrom);
					mailTo = PropertiesDb.getInstance().getStringTrim("alerta.booking.mailTo");
					alerta.setMailTo(mailTo);
					mailCC = PropertiesDb.getInstance().getStringTrim("alerta.booking.mailCC");
					alerta.setMailCC(mailCC);
					alertasMap.put(descripcion, alerta);
				}
			}
			activo = PropertiesDb.getInstance().getBoolean("alerta.sdi.activo");
			if (activo) {
				descripcion = PropertiesDb.getInstance().getStringTrim("alerta.sdi.descripcion");
				if (descripcion != null) {
					alerta = new BeanAlertasSAR();
					alerta.setDescripcion(descripcion);
					template = PropertiesDb.getInstance().getStringTrim("alerta.sdi.template");
					alerta.setTemplate(template);
					mailFrom = PropertiesDb.getInstance().getStringTrim("alerta.sdi.mailFrom");
					alerta.setMailFrom(mailFrom);
					mailTo = PropertiesDb.getInstance().getStringTrim("alerta.sdi.mailTo");
					alerta.setMailTo(mailTo);
					mailCC = PropertiesDb.getInstance().getStringTrim("alerta.sdi.mailCC");
					alerta.setMailCC(mailCC);
					alertasMap.put(descripcion, alerta);
				}
			}
		} catch (Exception e) {
			log.error("No se pudo cargar el archivo: " + ARCHIVO_CONFIG, e);
		}

		return alertasMap;
	}

	/**
	 * 
	 * @param template
	 * @param contacto
	 * @param orden
	 * @return Array con el subject[0] y el cuerpo del correo[1]
	 */
	public String[] getTextTemplate(String template, String tablaSar, String estado) {
		String texto = "";
		String subject = "";
		try {
			FileReader fr = new FileReader(new File(RUTA_TEMPLATES + File.separatorChar + template));
			BufferedReader br = new BufferedReader(fr);
			String linea = null;
			while ((linea = br.readLine()) != null) {
				texto += linea;
			}
			br.close();
			texto = texto.replace("<POS>", tablaSar);
			String tablaEventos = creaTablaEventos(estado).toString();
			texto = texto.replace("<TABLA_EVENTOS>", tablaEventos);

			int ind1 = texto.indexOf("<title>");
			int ind2 = texto.indexOf("</title>");
			if (ind1 != -1 && ind2 != -1) {
				ind1 = texto.indexOf(">", ind1);
				subject = texto.substring(ind1 + 1, ind2);
				subject = subject.replace("<STATUS>", estado);
			}
		} catch (FileNotFoundException e) {
			log.error("No existe el archivo: " + template, e);
		} catch (IOException e) {
			log.error("Error al abrir el archivo: " + template, e);
		}
		return new String[] { subject, texto };
	}

	public static File generaXLS(List<SarBO> lstSAR, String estado) {
		GregorianCalendar gc = new GregorianCalendar();
		int hoy = FuncionesComunesPLI.gregorianCalendar2int(gc);
		String path = RUTA_MONITOREO + File.separator;
		File directorio = new File(path);
		if (!directorio.exists()) {
			directorio.mkdirs();
		}
		String fileName = "SARVencidos_" + estado + "_" + hoy + ".xls";
		File xls = new File(path + fileName);
		try {
			FileOutputStream fos = new FileOutputStream(xls);
			System.out.println("**Creando reporte" + Calendar.getInstance().toString());
			int rows = 0;
			int col = 0;

			HSSFWorkbook libro = new HSSFWorkbook();
			HSSFSheet hoja = libro.createSheet("SARs Vencidos");

			HSSFRow encabezado = hoja.createRow(rows++);
			addCell(encabezado, col++, "Folio", null);
			addCell(encabezado, col++, "PO", null);
			addCell(encabezado, col++, "Supplier", null);
			addCell(encabezado, col++, "Supplier Name", null);
			addCell(encabezado, col++, "Planner", null);
			addCell(encabezado, col++, "ETD", null);
			if ("CONSOLIDADOS".equals(estado)) {
				addCell(encabezado, col++, "Days without consolidate", null);
				addCell(encabezado, col++, "Shipping approval date", null);
			} else if ("BOOKING".equals(estado)) {
				addCell(encabezado, col++, "Days left to ETD", null);
				addCell(encabezado, col++, "Shipping approval date", null);
				addCell(encabezado, col++, "Week", null);
				addCell(encabezado, col++, "PO Status", null);
				addCell(encabezado, col++, "Minimum IDA", null);
				addCell(encabezado, col++, "Forecasted backorder", null);
				addCell(encabezado, col++, "Container", null);
				addCell(encabezado, col++, "Booking", null);
				addCell(encabezado, col++, "Carrier", null);
			} else {
				addCell(encabezado, col++, "Days in " + estado, null);
				addCell(encabezado, col++, estado + " approval date", null);
			}

			for (SarBO bean : lstSAR) {
				if (bean.getDetalleBO() == null || bean.getDetalleBO().isEmpty()) {
					continue;
				}

				String folio = String.valueOf(bean.getFolio());
				String cveProveedor = bean.getProveedor();
				String nombreProveedor = FuncionesComunesPLI.getProveedor(bean.getProveedor()) == null ? ""
						: FuncionesComunesPLI.getProveedor(bean.getProveedor()).getNombreProveedor();
				int etdReporte = (bean.getEtdReal() != null && bean.getEtdReal() > 0) ? bean.getEtdReal()
						: bean.getFechaEmbarque();
				String diasEnStatus = String.valueOf(bean.getDiasEnStatus());
				String fechaEnStatus = FuncionesComunesPLI.formateaFecha(bean.getFechaEnStatus());
				String semanaETD = etdReporte == 0 ? "N.D"
						: FuncionesComunesPLI.numeroSemanaImportaciones(etdReporte) + "";
				String contenedor = bean.getContenedor() == null ? "" : bean.getContenedor();
				String booking = bean.getBooking() == null ? "" : bean.getBooking();
				String naviera = FuncionesComunesPLI.mapaNavieras.get(bean.getNaviera()) != null
						? FuncionesComunesPLI.mapaNavieras.get(bean.getNaviera()).getNombre()
						: "";
				Map<String, SarDetalleBO> mapaPOs = new HashMap<String, SarDetalleBO>();

				for (SarDetalleBO detalle : bean.getDetalleBO()) {
					BigDecimal backorder = detalle.getBackorderPronosticado() == null ? FuncionesComunesPLI.CERO
							: detalle.getBackorderPronosticado();
					Integer ida = detalle.getInventaroAlArribo() == null ? 0 : detalle.getInventaroAlArribo();
					String numeroOrden = detalle.getPo();
					if (detalle.isPedidoDirecto()) {
						bean.setTienePedidoDirecto(detalle.isPedidoDirecto());
					}
					bean.setAlmacen(detalle.getAlmacen());
					SarDetalleBO detTmp = mapaPOs.get(numeroOrden);
					if (detTmp == null) {
						detTmp = new SarDetalleBO();
						detTmp.setInventaroAlArribo(ida);
						detTmp.setBackorderPronosticado(backorder);
						detTmp.setPlaneador(detalle.getPlaneador());
						mapaPOs.put(numeroOrden, detTmp);
					} else {
						if (detTmp.getInventaroAlArribo() > ida) {
							detTmp.setInventaroAlArribo(ida);
							detTmp.setBackorderPronosticado(backorder);
							detTmp.setPlaneador(detalle.getPlaneador());
						}
					}
				}

				for (Entry<String, SarDetalleBO> orden : mapaPOs.entrySet()) {
					col = 0;
					HSSFRow filasErrores = hoja.createRow(rows++);
					if ("BOOKING".equals(estado)) {
						addCell(filasErrores, col++, folio, null);
						addCell(filasErrores, col++, orden.getKey(), null);
						addCell(filasErrores, col++, cveProveedor, null);
						addCell(filasErrores, col++, nombreProveedor, null);
						addCell(filasErrores, col++, orden.getValue().getPlaneador(), null);
						addCell(filasErrores, col++, FuncionesComunesPLI.formateaFecha(etdReporte), null);
						addCell(filasErrores, col++, diasEnStatus, null);
						addCell(filasErrores, col++, fechaEnStatus, null);
						addCell(filasErrores, col++, semanaETD, null);
						addCell(filasErrores, col++,
								(bean.getTienePedidoDirecto() == null || !bean.getTienePedidoDirecto() ? "" : "D"),
								null);
						addCell(filasErrores, col++, orden.getValue().getInventaroAlArribo(), null);
						addCell(filasErrores, col++,
								(orden.getValue().getBackorderPronosticado() == null ? "N/D"
										: FuncionesComunesPLI.formatea(
												orden.getValue().getBackorderPronosticado().doubleValue(), 0, false)),
								null);
						addCell(filasErrores, col++, contenedor, null);
						addCell(filasErrores, col++, booking, null);
						addCell(filasErrores, col++, naviera, null);
					} else {
						addCell(filasErrores, col++, folio, null);
						addCell(filasErrores, col++, orden.getKey(), null);
						addCell(filasErrores, col++, cveProveedor, null);
						addCell(filasErrores, col++, nombreProveedor, null);
						addCell(filasErrores, col++, orden.getValue().getPlaneador(), null);
						addCell(filasErrores, col++, FuncionesComunesPLI.formateaFecha(etdReporte), null);
						addCell(filasErrores, col++, diasEnStatus, null);
						addCell(filasErrores, col++, fechaEnStatus, null);
					}
				}
			}

			libro.write(fos);
			fos.close();
			System.out.println("**Terminando reporte" + Calendar.getInstance().toString());
		} catch (FileNotFoundException e) {
			log.error("No existe la ruta especificada: " + path, e);
		} catch (IOException e) {
			log.error("No se pudo crear el archivo: " + path, e);
		} catch (Exception e) {
			log.error("Error al crear el reporte: " + path, e);
		}
		return xls;
	}

	public static void addCell(HSSFRow row, int column, String value, HSSFCellStyle style) {
		HSSFCell cell = row.createCell(column);
		if (style != null) {
			cell.setCellStyle(style);
			cell.setCellType(HSSFCell.CELL_TYPE_STRING);
		}
		cell.setCellType(HSSFCell.CELL_TYPE_STRING);
		cell.setCellValue(value);
	}

	public static void addCell(HSSFRow row, int column, double value, HSSFCellStyle style) {
		HSSFCell cell = row.createCell(column);
		if (style != null) {
			cell.setCellStyle(style);
			cell.setCellType(HSSFCell.CELL_TYPE_NUMERIC);
		}
		cell.setCellType(HSSFCell.CELL_TYPE_NUMERIC);
		cell.setCellValue(value);
	}

	public boolean enviaCorreo(BeanAlertasSAR alertas, List<SarBO> lstSars, File anexo) {
		String tablaSARs = creaTablaSars(lstSars, alertas.getDescripcion()).toString();
		String[] texto = getTextTemplate(alertas.getTemplate(), tablaSARs, alertas.getDescripcion());
		String mailFrom = alertas.getMailFrom();
		String[] mailsTo = alertas.getMailTo().split(";");
		String[] mailsCC = alertas.getMailCC().split(";");
		Boolean envioExitoso = MailUtils.enviaCorreo(mailsTo, mailsCC, texto[0], mailFrom, texto[1], anexo);
		return envioExitoso;
	}

	/**
	 * @deprecated Se deja de usar al pasarlo a properties en db.
	 * @see {@link PropertiesDb}
	 */
	private static String getTagValue(String sTag, Element eElement) {
		String tagVal = "";
		NodeList nlList = eElement.getElementsByTagName(sTag).item(0).getChildNodes();
		Node nValue = (Node) nlList.item(0);
		if (nValue != null) {
			tagVal = nValue.getNodeValue();
		}
		return tagVal;
	}

	public void generaReporteSARs() throws SQLException, ClassNotFoundException {
		List<SarBO> listaSARs = SAR_CDI_DAO.dameSARsParaReporte();
		boolean flagComponenteEmail = MailUtils.isEnviaCorreoWsMail();
		GregorianCalendar gc = new GregorianCalendar();
		int hoy = FuncionesComunesPLI.gregorianCalendar2int(gc);
		String path = RUTA_REPORTES + File.separator;
		File directorio = new File(path);
		if (!directorio.exists()) {
			directorio.mkdirs();
		}
		String fileName = "statusSARs_" + hoy + ".xls";
		File xls = new File(path + fileName);
		try {
			FuncionesComunesPLI.cargaPropertiesCDI(false);

			FileOutputStream fos = new FileOutputStream(xls);
			System.out.println("**Creando reporte" + Calendar.getInstance().toString());
			int rows = 0;
			int col = 0;
			int totalFolios = 0;
			int foliosFull = 0;
			int foliosLCL = 0;
			int foliosPlanning = 0;
			int foliosShipping = 0;

			HSSFWorkbook libro = new HSSFWorkbook();
			HSSFSheet hoja = libro.createSheet("Status SARs");

			HSSFRow encabezado = hoja.createRow(rows++);
			addCell(encabezado, col++, "Folio", null);
			addCell(encabezado, col++, "Fecha Creacion", null);
			addCell(encabezado, col++, "Proveedor", null);
			addCell(encabezado, col++, "Tipo SAR", null);
			addCell(encabezado, col++, "Estado", null);
			addCell(encabezado, col++, "Folio Consolidado", null);
			addCell(encabezado, col++, "Fecha de Inicio Planning", null);
			addCell(encabezado, col++, "Fecha de Inicio Shipping", null);
			addCell(encabezado, col++, "Fecha de Inicio Booking", null);
			addCell(encabezado, col++, "fecha de Inicio Consol", null);
			addCell(encabezado, col++, "Dias en Planning", null);
			addCell(encabezado, col++, "Dias en Shipping", null);
			addCell(encabezado, col++, "Fecha de Ultimo Rechazo", null);
			addCell(encabezado, col++, "Usuario del Ultimo Rechazo/Aceptacion", null);
			addCell(encabezado, col++, "Comentario de Cancelacion", null);
			addCell(encabezado, col++, "Fecha de la Ultima Aprobacion / Rechazo", null);
			addCell(encabezado, col++, "Usuario que Aprueba / Rechaza", null);
			addCell(encabezado, col++, "Aprobado por Planeacion", null);
			addCell(encabezado, col++, "Aprobado por Shipping", null);
			
			Locale locale = new Locale("es", "MX");
			
			List<SarBO> foliosList = new ArrayList<>();
			for (SarBO bean : listaSARs) {
				foliosList.add(bean);
			}
			
			Map<Integer, FasesSARBO> valores = EstatusUtils.datosAvanceSAR(foliosList, locale, false);
			
			for (SarBO bean : listaSARs) {
				
				FasesSARBO avancesFolio = valores.get(bean.getFolio());
				col = 0;
				HSSFRow filas = hoja.createRow(rows++);
				addCell(filas, col++, bean.getFolio(), null);
				addCell(filas, col++, FuncionesComunesPLI.formateaFecha(bean.getCreationDate()), null);
				addCell(filas, col++, bean.getProveedor(), null);
				if (bean.getConsolidado()) {
					addCell(filas, col++, "LCL", null);
					foliosLCL++;
				} else {
					addCell(filas, col++, "FULL", null);
					foliosFull++;
				}
				
				addCell(filas, col++, avancesFolio.getLeyenda(), null);
				addCell(filas, col++, bean.getFolioConsolidado(), null);
				addCell(filas, col++, FuncionesComunesPLI.formateaFecha(bean.getTinyFecIniPlanning()), null);
				addCell(filas, col++, FuncionesComunesPLI.formateaFecha(bean.getTinyFecIniShipping()), null);
				addCell(filas, col++, FuncionesComunesPLI.formateaFecha(bean.getTinyFecIniBooking()), null);
				addCell(filas, col++, FuncionesComunesPLI.formateaFecha(bean.getTinyFecIniConsolidados()), null);
				if (bean.getStatus() == SAR.STATUS_SIN_SOLICITUD_APROBACION) {
					addCell(filas, col++, 0, null);
					addCell(filas, col++, 0, null);
				}
				if (bean.getStatus() == SAR.STATUS_ESPERA_APROBACION_PLANEACION) {
					addCell(filas, col++, FuncionesComunesPLI.daysBetween(bean.getTinyFecIniPlanning(), hoy), null);
				} else if (bean.getStatus() > SAR.STATUS_ESPERA_APROBACION_PLANEACION
						&& bean.getStatus() != SAR.STATUS_CANCELADO && bean.getStatus() != SAR.STATUS_RECHAZADO) {
					addCell(filas, col++,
							FuncionesComunesPLI.daysBetween(bean.getTinyFecIniPlanning(), bean.getTinyFecIniShipping()),
							null);
				} else if (bean.getStatus() > SAR.STATUS_ESPERA_APROBACION_PLANEACION
						&& (bean.getStatus() == SAR.STATUS_CANCELADO || bean.getStatus() == SAR.STATUS_RECHAZADO)) {
					addCell(filas, col++, FuncionesComunesPLI.daysBetween(bean.getTinyFecIniPlanning(),
							bean.getFechaUltimaAprobacionRechazo()), null);
				}
				if (bean.getStatus() == SAR.STATUS_ESPERA_APROBACION_SHIPPING) {
					addCell(filas, col++, FuncionesComunesPLI.daysBetween(bean.getTinyFecIniShipping(), hoy), null);
				} else if (bean.getStatus() > SAR.STATUS_ESPERA_APROBACION_SHIPPING && !bean.getConsolidado()
						&& bean.getStatus() != SAR.STATUS_CANCELADO && bean.getStatus() != SAR.STATUS_RECHAZADO) {
					addCell(filas, col++,
							FuncionesComunesPLI.daysBetween(bean.getTinyFecIniShipping(), bean.getTinyFecIniBooking()),
							null);
				} else if (bean.getStatus() > SAR.STATUS_ESPERA_APROBACION_SHIPPING && bean.getConsolidado()
						&& bean.getStatus() != SAR.STATUS_CANCELADO && bean.getStatus() != SAR.STATUS_RECHAZADO) {
					addCell(filas, col++, FuncionesComunesPLI.daysBetween(bean.getTinyFecIniShipping(),
							bean.getTinyFecIniConsolidados()), null);
				} else if (bean.getStatus() > SAR.STATUS_ESPERA_APROBACION_SHIPPING
						&& (bean.getStatus() == SAR.STATUS_CANCELADO || bean.getStatus() == SAR.STATUS_RECHAZADO)) {
					addCell(filas, col++, FuncionesComunesPLI.daysBetween(bean.getTinyFecIniShipping(),
							bean.getFechaUltimaAprobacionRechazo()), null);
				}
				addCell(filas, col++, FuncionesComunesPLI.formateaFecha(bean.getFechaUltimoRechazo()), null);
				addCell(filas, col++, bean.getUsuarioAceptoRechazoSAR(), null);
				addCell(filas, col++, bean.getComentarioCancelacion(), null);
				addCell(filas, col++, FuncionesComunesPLI.formateaFecha(bean.getFechaUltimaAprobacionRechazo()), null);
				addCell(filas, col++, bean.getUsuarioApruebaRechaza(), null);
				if (bean.getTinyFecIniShipping() == null) {
					addCell(filas, col++, "NO", null);
				} else {
					addCell(filas, col++, "SI", null);
					foliosPlanning++;
				}
				if (bean.getConsolidado()) {
					if (bean.getTinyFecIniBooking() == null) {
						addCell(filas, col++, "NO", null);
					} else {
						addCell(filas, col++, "SI", null);
						foliosShipping++;
					}
				} else {
					if (bean.getTinyFecIniConsolidados() == null) {
						addCell(filas, col++, "NO", null);
					} else {
						addCell(filas, col++, "SI", null);
						foliosShipping++;
					}
				}
			}
			totalFolios = rows - 1;
			HSSFSheet hoja2 = libro.createSheet("Metricas SARs");
			HSSFRow filaTotal = hoja2.createRow(0);
			addCell(filaTotal, 0, "Total Folios", null);
			addCell(filaTotal, 1, totalFolios, null);
			filaTotal = hoja2.createRow(1);
			addCell(filaTotal, 0, "Folios Full", null);
			addCell(filaTotal, 1, foliosFull, null);
			filaTotal = hoja2.createRow(2);
			addCell(filaTotal, 0, "Folios LCL", null);
			addCell(filaTotal, 1, foliosLCL, null);
			filaTotal = hoja2.createRow(3);
			addCell(filaTotal, 0, "Folios Aprobados por Planeacion", null);
			addCell(filaTotal, 1, foliosPlanning, null);
			filaTotal = hoja2.createRow(4);
			addCell(filaTotal, 0, "Folios Aprobados por Shipping", null);
			addCell(filaTotal, 1, foliosShipping, null);

			libro.write(fos);
			fos.close();
			System.out.println("**Terminando reporte" + Calendar.getInstance().toString());

			String[] mailsTo = SarBO.MAIL_GRUPO_REPORTE_SARS;
			String[] mailsCC = SarBO.MAIL_DEBUG;
			Boolean envioExitoso = Boolean.FALSE;
			if (MailUtils.isEnviaCorreos()) {
				if (MailUtils.isCorreosDebug()) {
					mailsTo = SarBO.MAIL_DEBUG;
					mailsCC = null;
				}
				try {
					if (flagComponenteEmail) { // Envio de correo asincrono
						address = CorreoUtils.getInstance().getAddress(mailsTo);
						emailBean = new EmailAsynBean(address, mailsCC, null, "Reporte de estados SARs",
								"Reporte de estados SARs", null);
						sendAsync.createEmail(emailBean, xls, null); // .createEmail(emailBean , file, mapInLineImages);
					} else {
						// envio de respaldo
						ms.sendMail(mailsTo, mailsCC, "Reporte de estados SARs", "Reporte de estados SARs", xls);
						log
								.info("El envio de mail se ha realizado por metodo de respaldo  [flagComponenteEmail]"
										+ flagComponenteEmail);
					}

				} catch (Exception e) {
					log
					.error(" fallo envio de mail - WS MAIL("+ flagComponenteEmail+  ")" + e);
		}
			} else {
				log
						.info("Asunto: Reporte de estados SARs" + ", Mensaje: Reporte de estados SARs, To: "
								+ Arrays.toString(mailsTo) + ", CC: " + Arrays.toString(mailsCC));
			}
			envioExitoso = Boolean.TRUE;
		} catch (FileNotFoundException e) {
			log.error("No existe la ruta especificada: " + path, e);
		} catch (IOException e) {
			log.error("No se pudo crear el archivo: " + path, e);
		} catch (Exception e) {
			log.error("Error al crear el reporte: " + path, e);
		}
	}

	public void enviaRecordatorioRedFlagSinRespuesta() {
		try {
			FuncionesComunesPLI.cargaProductos(false);
			FuncionesComunesPLI.cargaPropertiesCDI(false);
			FuncionesComunesPLI.getProveedores(false);

		} catch (Exception e1) {
			log.error("Error al cargar productos", e1);
		}
		GregorianCalendar gc = new GregorianCalendar();
		int hoy = FuncionesComunesPLI.formateaFecha(gc);
		try {
			Map<String, PoRedFlag> mapaRedFlag = SAR_CDI_DAO.dameOrdenesConProblemas(null);
			if (mapaRedFlag != null) {
				for (Entry<String, PoRedFlag> entry : mapaRedFlag.entrySet()) {
					PoRedFlag prf = entry.getValue();
					SarBO sar = new SarBO();
					List<SarDetalleBO> lstDet = new ArrayList<SarDetalleBO>();
					sar.setProveedor(prf.getProveedor());
					for (SARDetalle detRedFlag : prf.getPoRedFlagDetalle()) {
						sar.setFechaEmbarque(detRedFlag.getFechaProforma());
						SarDetalleBO det = new SarDetalleBO();
						det.setPo(detRedFlag.getPo());
						det.setPosicion(Integer.valueOf(detRedFlag.getPosicion()));
						det.setPlaneador(detRedFlag.getPlaneador().trim());
						det.setCentro(detRedFlag.getCentro().trim());
						det.setMaterial(detRedFlag.getMaterial());
						det.setPesoPO(detRedFlag.getPesoPO());
						det.setVolumenPO(detRedFlag.getVolumenPO());
						det.setCantidad(detRedFlag.getCantidad());
						det.setFechaProforma(detRedFlag.getFechaProforma());
						lstDet.add(det);
					}
					sar.setDetalleBO(lstDet);
					if (Utilerias.diasHabiles(prf.getFechaCreacion(), hoy) > 2 && prf.getFechaRespuesta() == 0) {
						Map<String, Object> datosMail;
						try {
							datosMail = FuncionesComunesPLI.dameDatosDestinoMail(sar);
							FuncionesComunesPLI.enviaMailRedFlagSinRespuesta(prf, datosMail);
						} catch (Exception e) {
							log.error("Error al obtener direcciones", e);
						}
					}
				}
			}
		} catch (ClassNotFoundException e) {
			log.error("No se pudo consultar a la BD", e);
		}
	}

	/**
	 * Busca, genera y manda el correo a cada proveedor que tenga un SAR despues de
	 * 48 hrs de liberado por Shipping, y se repite cada dia que no se tenga booking
	 * despues de las primeras 48 hrs.
	 * 
	 * 
	 */
	public void recordatorioSolicitudBooking() {
		boolean flagComponenteEmail = MailUtils.isEnviaCorreoWsMail();

		try {
			FuncionesComunesPLI.cargaPropertiesCDI(false);
		} catch (ServletException e1) {
			e1.printStackTrace();
		}
		ArrayList<SarBO> lista;
		try {
			lista = FuncionesComunesPLI.dameFoliosSinBookingRegistrado(DIAS_ENVIO_BOOKING_REQUEST);

			if (lista == null || lista.size() == 0) {
				return;// En este caso, no hay ningun SAR que este en la busqueda, termino el metodo
						// sin enviar correos.
			}

			ImportacionesProveedoresBean proveedor = null;

			if (MailUtils.isEnviaCorreos()) {
				String[] sa;
				String mail = "";
				String sender = "";
				for (SarBO sar : lista) {
					proveedor = FuncionesComunesPLI.getProveedor(sar.getProveedor());
					if (MailUtils.isCorreosDebug()) {
						String proveedorMail = proveedor.getEmail();
						StringBuilder sb = new StringBuilder();
						sb.append(proveedorMail).append(";");
						// agrego los otros mails

						for (String mailTmp : SarBO.MAIL_GRUPO_SHIPPINGPLANNER) {
							sb.append(mailTmp).append(";");
						}

						for (String mailTmp : SarBO.MAIL_GRUPO_BOOKING) {
							sb.append(mailTmp).append(";");
						}

						sb.append(SarBO.EMAIL_SUKI).append(";");
						sb.append(SarBO.MAIL_GIL);
						Map<String, Object> mapaDirecciones = FuncionesComunesPLI.dameDatosDestinoMail(sar);
						sender = "";
						if (mapaDirecciones != null) {
							Map<String, UnidadNegocio> uNegData = (Map<String, UnidadNegocio>) mapaDirecciones
									.get("bu");
							if (uNegData != null) {
								for (Map.Entry<String, UnidadNegocio> tmp : uNegData.entrySet()) {
									sender = tmp.getValue().getMailContacto();
								}
							}
						}
						mail = sb.toString();
						mail = CORREO_DAVID;
					} else {
						String proveedorMail = proveedor.getEmail();
						StringBuilder sb = new StringBuilder();
						sb.append(proveedorMail).append(";");
						for (String mailTmp : SarBO.MAIL_GRUPO_SHIPPINGPLANNER) {

							sb.append(mailTmp).append(";");
						}

						for (String mailTmp : SarBO.MAIL_GRUPO_BOOKING) {

							sb.append(mailTmp).append(";");
						}

						sb.append(SarBO.EMAIL_SUKI).append(";");
						sb.append(SarBO.MAIL_GIL);

						Map<String, Object> mapaDirecciones = FuncionesComunesPLI.dameDatosDestinoMail(sar);
						sender = "";
						if (mapaDirecciones != null) {
							Map<String, UnidadNegocio> uNegData = (Map<String, UnidadNegocio>) mapaDirecciones
									.get("bu");
							if (uNegData != null) {
								for (Map.Entry<String, UnidadNegocio> tmp : uNegData.entrySet()) {
									sender = tmp.getValue().getMailContacto();
								}
							}
						}

						mail = sb.toString();
					}
					sa = creaArrayCorreos(mail);
					URL resource = getClass().getResource("/");
					String path = resource.getPath();

					File file = new File(path + "com/srm/pli/documents/Carrier_Troubleshoot_Data_Sheet.xls");
					String providerName = proveedor.getNombreProveedor();
					String message = FuncionesComunesPLI.generaCuerpoCorreoRecordatorioBooking();
					String asunto = "Booking number request Folio " + sar.getFolioCompleto() + " " + providerName;

					try {
						if (flagComponenteEmail) { // Envio de correo asincrono
							address = CorreoUtils.getInstance().getAddress(sa);
							emailBean = new EmailAsynBean(address, null, null, asunto, message, sender);
							sendAsync.createEmail(emailBean, file, null); // .createEmail(emailBean , file,
							// mapInLineImages);
						} else {
							// envio de respaldo
							ms.sendMail(sa, null, asunto, message, file, sender);
							log.info(
									"El envio de mail se ha realizado por metodo de respaldo  [flagComponenteEmail]"
											+ flagComponenteEmail);
						}
					} catch (Exception e) {
						log
						.error(" fallo envio de mail - WS MAIL("+ flagComponenteEmail+  ")" + e);
			}
					log
							.info("[Envio mails solicitud de booking] ok mail enviado.. SAR:" + sar.getFolio());
					break;
				}
			}
		} catch (Exception e) {
			log.error("[Envio mails solicitud de booking] error", e);
		}
	}

	public File sarsSinBooking() {
		try {
			FuncionesComunesPLI.cargaPropertiesCDI(false);
			FuncionesComunesPLI.cargaProductos(false);
			FuncionesComunesPLI.cargaNavieras(false);
			FuncionesComunesPLI.cargaPlanners(false);
			FuncionesComunesPLI.getProveedores(false);
		} catch (Exception e) {
			e.printStackTrace();
		}
		String mailFrom = CorreoHelper.getInstance().getEmail(MAIL_FR_HK_SYSTEM);
		GregorianCalendar gc = new GregorianCalendar();
		int hoy = FuncionesComunesPLI.gregorianCalendar2int(gc);
		String path = RUTA_MONITOREO + File.separator;
		File directorio = new File(path);
		if (!directorio.exists()) {
			directorio.mkdirs();
		}
		String fileName = "SARSinBooking_" + hoy + ".xls";
		File xls = new File(path + fileName);
		try {
			FileOutputStream fos = new FileOutputStream(xls);
			log.info("Creando reporte sarsSinBooking {}", fileName);
			int rows = 0;
			int col = 0;

			@SuppressWarnings("resource")
			HSSFWorkbook libro = new HSSFWorkbook();
			HSSFSheet hoja = libro.createSheet("SARs Vencidos");

			HSSFRow encabezado = hoja.createRow(rows++);
			addCell(encabezado, col++, "Folio", null);
			addCell(encabezado, col++, "POs", null);
			addCell(encabezado, col++, "Supplier Number", null);
			addCell(encabezado, col++, "Supplier Name", null);
			addCell(encabezado, col++, "Planner Code", null);
			addCell(encabezado, col++, "ETD", null);
			/// nuevos
			addCell(encabezado, col++, "Days left to ETD", null);
			addCell(encabezado, col++, "Reference Number", null);
			addCell(encabezado, col++, "Booking Request Date", null);
			addCell(encabezado, col++, "ETD Request", null);
			addCell(encabezado, col++, "Days without Booking release", null);
			addCell(encabezado, col++, "Booking release Date", null);
			addCell(encabezado, col++, "Week", null);
			addCell(encabezado, col++, "Minimun IDA", null);
			addCell(encabezado, col++, "Carrier", null);

			addCell(encabezado, col++, "Shipping Port", null);
			addCell(encabezado, col++, "POD", null);
			addCell(encabezado, col++, "Type of container", null);

			// Busco sars sin booking
			HashMap<Integer, ReferenceNumberBean> referenceMap = new HashMap<Integer, ReferenceNumberBean>();
			ArrayList<SarBO> lista = FuncionesComunesPLI.dameFoliosSinBookingRegistrado(0);
			FuncionesComunesPLI.dameDatosCDIDetalle(lista);

			Map<Integer, ReferenceNumberBean> mapRefNumbers = SAR_CDI_DAO.selectReferenceNumbers(lista);
			for (ReferenceNumberBean rf : mapRefNumbers.values()) {
				if (rf != null) {
					referenceMap.put(rf.getFolio(), rf);
				}
			}

			for (SarBO bean : lista) {
				List<SarDetalleBO> detalle = FuncionesComunesPLI.getDetalleSAR(bean);
				List<SarDetalleBO> detalleOthers = SAR_CDI_DAO.consultaDetalleOtros(bean.getFolio().toString());
				FuncionesComunesPLI.sacaTotales(bean, (ArrayList<SarDetalleBO>) detalle, detalleOthers);

				String folio = String.valueOf(bean.getFolioCompleto());
				String pos = "";
				int contPOs = 0;
				
				if(bean.getListaPos() != null) {
					for (String po : bean.getListaPos()) {
						if (contPOs > 0) {
							pos = pos.concat(",");
						}
						pos = pos.concat(po);
						contPOs++;
					}
				}
				
				String cveProveedor = bean.getProveedor();
				String nombreProveedor = FuncionesComunesPLI.getProveedor(bean.getProveedor()) == null ? ""
						: FuncionesComunesPLI.getProveedor(bean.getProveedor()).getNombreProveedor();
				int etdReporte = (bean.getEtdReal() != null && bean.getEtdReal() > 0) ? bean.getEtdReal()
						: bean.getFechaEmbarque();
				Set<String> lstPlanners = new HashSet<String>();
				
				if(detalle != null) {
					for (SarDetalleBO det : detalle) {
						String plannerCode = det.getPlaneador();
						lstPlanners.add(plannerCode);
					}
				}				
				
				String planners = "";
				int contPlanners = 0;
				
				if(lstPlanners != null) {
					for (String planner : lstPlanners) {
						if (contPlanners > 0) {
							planners = planners.concat(",");
						}
						planners = planners.concat(planner);
						contPlanners++;
					}
				}
				
				String semanaETD = etdReporte == 0 ? "N.D"
						: FuncionesComunesPLI.numeroSemanaImportaciones(etdReporte) + "";
				String naviera = FuncionesComunesPLI.mapaNavieras.get(bean.getNaviera()) != null
						? FuncionesComunesPLI.mapaNavieras.get(bean.getNaviera()).getNombre()
						: "";
				Integer ida = bean.getIda();

				String puertoOri = bean.getPuertoOrigen();
				String puertoOrigen = PuertosHelper.getInstance().getNombrePuertoOrigen(puertoOri);
				boolean tienePedidosDirectos = bean.tienePedidoDirecto();
				String pod = bean.getPuertoDescarga();
				String puertoDestino = PuertosHelper.getInstance().getNombrePuertoDestino(pod, tienePedidosDirectos);
				String tipoContenedor = ContenedorService.getInstance().getDescripcion(bean.getTipoContenedor());

				ReferenceNumberBean n = referenceMap.get(bean.getFolio());

				col = 0;
				HSSFRow filasErrores = hoja.createRow(rows++);
				addCell(filasErrores, col++, folio, null);
				addCell(filasErrores, col++, pos, null);
				addCell(filasErrores, col++, cveProveedor, null);
				addCell(filasErrores, col++, nombreProveedor, null);
				addCell(filasErrores, col++, planners, null);
				addCell(filasErrores, col++, FuncionesComunesPLI.formateaFecha(etdReporte), null);
				addCell(filasErrores, col++, (int) FuncionesComunesPLI.daysBetween(etdReporte, hoy), null);
				addCell(filasErrores, col++, n != null ? n.getReferenceNumber() : "", null);
				addCell(filasErrores, col++,
						n != null && n.getBookingRequestDateCompany() != null
								? FuncionesComunesPLI.formateaFecha(n.getBookingRequestDateCompany())
								: "",
						null);
				addCell(filasErrores, col++, n != null ? FuncionesComunesPLI.formateaFecha(n.getETD()) : "", null);
				if (n != null) {
					addCell(filasErrores, col++, (int) FuncionesComunesPLI.daysBetween(n.getFechaCreacion(), hoy),
							null);
				} else {
					// Si es consolidado tomo la fecha de liberacion de consol si no la de booking
					int fechaInicioBooking = bean.getTinyFecIniBooking();
					addCell(filasErrores, col++, (int) FuncionesComunesPLI.daysBetween(fechaInicioBooking, hoy), null);
				}
				addCell(filasErrores, col++, "", null);
				addCell(filasErrores, col++, semanaETD, null);
				addCell(filasErrores, col++, ida, null);
				addCell(filasErrores, col++, naviera, null);
				addCell(filasErrores, col++, puertoOrigen, null);
				addCell(filasErrores, col++, puertoDestino, null);
				addCell(filasErrores, col++, tipoContenedor, null);
			}

			libro.write(fos);
			fos.close();
			String[] sa;
			String[] mailsCC = { CORREO_DAVID };
			String mail = "";
			StringBuilder sb = new StringBuilder();
			for (String mailTmp : SarBO.MAIL_GRUPO_REPORTE_CAMBIOS_ETD) {
				sb.append(mailTmp).append(";");
			}
			sb.append(SarBO.EMAIL_SUKI).append(";");
			sb.append(SarBO.MAIL_GIL);

			mail = sb.toString();
			sa = creaArrayCorreos(mail);
			MailUtils.enviaCorreo(sa, mailsCC, TEXTO_SARS_W_BOOKING, mailFrom, "", xls);
			log.info("Terminando reporte sarsSinBooking {}", fileName);
		} catch (FileNotFoundException e) {
			log.error("No existe la ruta especificada: {}", path, e);
		} catch (IOException e) {
			log.error("No se pudo crear el archivo: {}", path, e);
		} catch (Exception e) {
			log.error("Error al crear el reporte: {}", path, e);
		}
		return xls;
	}

	public void testMail(String sender, String addressees) {
		try {
			FuncionesComunesPLI.cargaPropertiesCDI(false);
		} catch (ServletException e) {
			e.printStackTrace();
		}
		String[] addressees_a = CorreoUtils.getInstance().creaArrayCorreos(addressees);
		StringBuilder body = new StringBuilder();
		body.append(" <div style=\"width: 100%; height: 100%; background: #0093ff; padding: 2em;\"> ");
		body.append(
				" <p><img style=\"user-select: none; display: block; margin-left: auto; margin-right: auto;\" src=\"https://www.truperenlinea.com/srm_booking/common/css/providersStyle/images/logo.png\"/></p> ");
		body.append(" </div> ");
		String subject = "FungRui - Correo electr\u00F3nico de prueba.";
		MailUtils.enviaCorreo(addressees_a, null, subject, sender, body.toString(), null, null);
	}

	public void reinicaMapaDetalle() {
		FuncionesComunesPLI.reiniciaMapaDetalle();
	}
}
