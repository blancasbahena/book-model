package com.srm.pli.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;

import com.srm.pli.bo.BeanTSR;
import com.srm.pli.bo.SarBO;
import com.srm.pli.db.ConexionDB;
import com.srm.pli.utils.FuncionesComunesPLI;
import com.truper.businessEntity.ImportacionesProveedoresBean;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class TroubleShootingDAO {

	public static boolean agregarRegistroTSR(BeanTSR registro, String proveedor) throws ServletException {
		
		boolean exito = false;
		
		Connection con = null;
		PreparedStatement pst = null;
		DAOUtils utilDao = new DAOUtils();

		StringBuffer insert = new StringBuffer();
		insert.append("INSERT INTO cdiTsrReport\r\n"); 
		insert.append("           (folio\r\n");
		insert.append("           ,proveedor\r\n"); 
		insert.append("           ,referenceNumber\r\n"); 
		insert.append("           ,carrier\r\n"); 
		insert.append("           ,carrierContactName\r\n");
		insert.append("           ,issueDescription\r\n");
		insert.append("           ,fechaRegistro\r\n");
		insert.append("           ,timeRegistro\r\n");
		insert.append("           ,shippingPort\r\n");
		insert.append("           ,ETD\r\n");
		insert.append("           ,carrier_shippingReleased\r\n");
		insert.append("           ,pendiente\r\n");
		insert.append("           ,rechazado)\r\n"); 
		insert.append("     VALUES\r\n");
		insert.append("           (?, ?, ?, ?, ?, ?, CAST(CONVERT(varchar(8),GETDATE(),112) as int), GETDATE(), ?, ?, ?, 1, null)");

		try {
			con = ConexionDB.dameConexion();
			pst = con.prepareStatement(insert.toString());
			int cont = 1;
			utilDao.ajustaParametro(cont++, pst, registro.getFolio(), Integer.class);
			utilDao.ajustaParametro(cont++, pst, proveedor, String.class);
			utilDao.ajustaParametro(cont++, pst, registro.getReferenceNumber(), String.class);
			utilDao.ajustaParametro(cont++, pst, registro.getCarrier(), Integer.class);
			utilDao.ajustaParametro(cont++, pst, registro.getCarrierContactName(), String.class);
			utilDao.ajustaParametro(cont++, pst, registro.getIssueDescription(), String.class);
			utilDao.ajustaParametro(cont++, pst, registro.getShippingPort(), String.class);
			utilDao.ajustaParametro(cont++, pst, registro.getETD(), Integer.class);
			utilDao.ajustaParametro(cont++, pst, registro.getCarrier_shippingReleased(), Integer.class);

			utilDao.inicializaQuery(insert.toString());

			exito = pst.executeUpdate() > 0;

			ConexionDB.devuelveConexion(con);
		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
				throw new ServletException(ex);
			}
			log.error(e.getMessage(), e);
			throw new ServletException(e);
		} catch (Exception e) {
			e.printStackTrace();
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
				throw new ServletException(ex);
			}
			log.error(e.getMessage(), e);
			throw new ServletException(e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
				throw new ServletException(sqlEx2);
			}
		}
		return exito;
		
	}
	
	public static List<BeanTSR> dameTSRRegistros(BeanTSR filtro, boolean hoy) throws ServletException {
		
		List<BeanTSR> lstResultados = new ArrayList<BeanTSR>();
		Connection con = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		DAOUtils utils = new DAOUtils();

		StringBuilder select = new StringBuilder();
		select.append("SELECT folio\r\n");
		select.append("	,referenceNumber\r\n");
		select.append("	,carrier\r\n");
		select.append("	,carrierContactName\r\n");
		select.append("	,issueDescription\r\n");
		select.append("	,fechaRegistro\r\n"); 
		select.append("	,timeRegistro\r\n"); 
		select.append("	,shippingPort\r\n");
		select.append("	,ETD\r\n");
		select.append("	,carrier_shippingReleased\r\n");
		select.append("	,pendiente\r\n");
		select.append("	,rechazado\r\n");

		select.append("	,comentariosBooking\r\n");
		select.append("	,timeSolucion\r\n");
		select.append("	,usuarioBooking\r\n");
		
		select.append("FROM dbo.cdiTsrReport ");
		select.append("WHERE 1=1 ");
		
		if(filtro != null) {
			if(filtro.getFolio() != null && filtro.getFolio() > 0) {
				select.append(" AND folio = " +filtro.getFolio());
			}
			
			if(filtro.getPendiente() != null) {
				if(filtro.getPendiente()) {
					select.append(" AND pendiente = 1 ");
				}
				
			}
			
			if(hoy) {
				select.append(" AND fechaRegistro = CAST(CONVERT(varchar(8),GETDATE(),112) as int) ");
			}
			
		}
		
		select.append(" ORDER BY  fechaRegistro DESC ");
		
		utils.setSelect(true);

		try {
			
			con = ConexionDB.dameConexion();
			pst = con.prepareStatement(select.toString());
			utils.inicializaQuery(select.toString());
			rs = pst.executeQuery();

			while (rs.next()) {
				
				BeanTSR tsrBean = new BeanTSR();
				
				tsrBean.setFolio(rs.getInt("folio"));
				tsrBean.setReferenceNumber(rs.getString("referenceNumber"));
				tsrBean.setCarrier(rs.getInt("carrier"));
				tsrBean.setCarrierContactName(rs.getString("carrierContactName"));
				tsrBean.setIssueDescription(rs.getString("issueDescription"));
				tsrBean.setFechaRegistro(rs.getInt("fechaRegistro"));
				tsrBean.setTimeRegistro(rs.getDate("timeRegistro"));
				tsrBean.setShippingPort(rs.getString("shippingPort"));
				tsrBean.setETD(rs.getInt("ETD"));
				tsrBean.setCarrier_shippingReleased(rs.getInt("carrier_shippingReleased"));
				tsrBean.setPendiente(rs.getBoolean("pendiente"));
				tsrBean.setRechazado(rs.getBoolean("rechazado"));
				tsrBean.setComentariosBooking(rs.getString("comentariosBooking"));
				tsrBean.setTimeSolucion(rs.getDate("timeSolucion"));
				tsrBean.setUsuarioBooking(rs.getString("usuarioBooking"));
				
				lstResultados.add(tsrBean);
				
			}
			rs.close();
			pst.close();
			
		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
				throw new ServletException(ex);
			}
			log.error(e.getMessage(), e);
			throw new ServletException(e);
		} catch (Exception e) {
			e.printStackTrace();
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
				throw new ServletException(ex);
			}
			log.error(e.getMessage(), e);
			throw new ServletException(e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
				throw new ServletException(sqlEx2);
			}
		}
		return lstResultados;
	}
	
	public static SarBO tieneRegistrosTSR(Integer folio) throws ServletException {
		
		SarBO resultado = null;
		Connection con = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		DAOUtils utils = new DAOUtils();

		StringBuilder select = new StringBuilder();
		select.append("SELECT pendiente \r\n");
		select.append("FROM cdiTsrReport\r\n");
		select.append("WHERE folio = ? ");

		utils.setSelect(true);

		try {
			
			con = ConexionDB.dameConexion();
			pst = con.prepareStatement(select.toString());
			pst.setInt(1, folio);
			utils.inicializaQuery(select.toString());
			rs = pst.executeQuery();

			while (rs.next()) {
				resultado = new SarBO();
				if(rs.getInt(1) == 1) {
					resultado.setTieneTSRAbiertos(true);
				} else {
					resultado.setTieneTSRResueltos(true);
				}
			}
			rs.close();
			pst.close();
			
		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
				throw new ServletException(ex);
			}
			log.error(e.getMessage(), e);
			throw new ServletException(e);
		} catch (Exception e) {
			e.printStackTrace();
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
				throw new ServletException(ex);
			}
			log.error(e.getMessage(), e);
			throw new ServletException(e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
				throw new ServletException(sqlEx2);
			}
		}
		return resultado;
	}

	public static BeanTSR dameDatosReferenciaCDI_TSR(Integer folio) throws ServletException {
		
		BeanTSR res = null;
		Connection con = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		DAOUtils utils = new DAOUtils();

		StringBuilder select = new StringBuilder();
		select.append("SELECT T.folio, ");
		select.append("	T.carrier,");
		select.append("	T.referenceNumber,");
		select.append("	T.ETD,");
		select.append("	s.puertoSalida, ");
		select.append("	s.naviera\r\n");
		select.append("FROM cdiSAR s,\r\n");
		select.append("	(SELECT folio,\r\n"); 
		select.append("             carrier,\r\n"); 
		select.append("             referenceNumber,\r\n"); 
		select.append("			 ETD,\r\n");
		select.append("             row_number() OVER(PARTITION BY folio ORDER BY version DESC) AS rn\r\n"); 
		select.append("      FROM cdiReferenceNumber) AS T\r\n");
		select.append("WHERE rn = 1\r\n");
		select.append("AND s.folio = T.folio ");
		select.append("AND s.folio = ? ");

		utils.setSelect(true);

		try {
			
			con = ConexionDB.dameConexion();
			pst = con.prepareStatement(select.toString());
			pst.setInt(1, folio);
			utils.inicializaQuery(select.toString());
			rs = pst.executeQuery();

			while (rs.next()) {
				res = new BeanTSR();
				res.setFolio(rs.getInt("folio"));
				res.setCarrier(rs.getInt("carrier"));
				res.setReferenceNumber(rs.getString("referenceNumber"));
				res.setETD(rs.getInt("ETD"));
				res.setShippingPort(rs.getString("puertoSalida"));
				res.setCarrier_shippingReleased(rs.getInt("naviera"));
				
			}
			rs.close();
			pst.close();
			
		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
				throw new ServletException(ex);
			}
			log.error(e.getMessage(), e);
			throw new ServletException(e);
		} catch (Exception e) {
			e.printStackTrace();
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
				throw new ServletException(ex);
			}
			log.error(e.getMessage(), e);
			throw new ServletException(e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
				throw new ServletException(sqlEx2);
			}
		}
		return res;
	}

	public static boolean cerrarRegistroTSR(Integer folio, Boolean approval, String comments, String userName) throws ServletException {
		
		boolean exito = false;
		
		Connection con = null;
		PreparedStatement pst = null;
		DAOUtils utilDao = new DAOUtils();

		StringBuffer insert = new StringBuffer();
		insert.append("UPDATE cdiTsrReport\r\n");
		insert.append("SET pendiente = 0,\r\n");
		insert.append("	rechazado = ?,\r\n");
		insert.append("	comentariosBooking = ?,\r\n");
		insert.append("	timeSolucion = GETDATE(),\r\n");
		insert.append("	usuarioBooking = ? \r\n");
		insert.append("WHERE folio = ?");

		try {
			con = ConexionDB.dameConexion();
			pst = con.prepareStatement(insert.toString());
			int cont = 1;
			utilDao.ajustaParametro(cont++, pst, !approval, Boolean.class);
			utilDao.ajustaParametro(cont++, pst, comments, String.class);
			utilDao.ajustaParametro(cont++, pst, userName, String.class);
			utilDao.ajustaParametro(cont++, pst, folio, Integer.class);

			utilDao.inicializaQuery(insert.toString());

			exito = pst.executeUpdate() > 0;
			
			ConexionDB.devuelveConexion(con);
		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
				throw new ServletException(ex);
			}
			log.error(e.getMessage(), e);
			throw new ServletException(e);
		} catch (Exception e) {
			e.printStackTrace();
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
				throw new ServletException(ex);
			}
			log.error(e.getMessage(), e);
			throw new ServletException(e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
				throw new ServletException(sqlEx2);
			}
		}
		return exito;
		
	}
	
	public static List<BeanTSR> dameTSRPendientesMas24Hrs() throws ServletException {
		
		List<BeanTSR> lstResultados = new ArrayList<BeanTSR>();
		Connection con = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		DAOUtils utils = new DAOUtils();

		StringBuilder select = new StringBuilder();
		select.append("SELECT folio\r\n");
		select.append("	,referenceNumber\r\n");
		select.append("	,proveedor\r\n");
		select.append("	,carrier\r\n");
		select.append("	,carrierContactName\r\n");
		select.append("	,issueDescription\r\n");
		select.append("	,fechaRegistro\r\n"); 
		select.append("	,timeRegistro\r\n"); 
		select.append("	,shippingPort\r\n");
		select.append("	,ETD\r\n");
		select.append("	,carrier_shippingReleased\r\n");
		select.append("	,pendiente\r\n");
		select.append("	,rechazado\r\n");
		select.append("FROM dbo.cdiTsrReport ");
		select.append("WHERE timeRegistro < DATEADD(day, -1, GETDATE()) ");
		select.append("AND pendiente = 1 ");
		select.append(" ORDER BY  fechaRegistro DESC ");
		
		utils.setSelect(true);

		try {
			
			con = ConexionDB.dameConexion();
			pst = con.prepareStatement(select.toString());
			utils.inicializaQuery(select.toString());
			rs = pst.executeQuery();

			while (rs.next()) {
				
				BeanTSR tsrBean = new BeanTSR();
				ImportacionesProveedoresBean proveedor = FuncionesComunesPLI.getProveedor(
						String.valueOf(rs.getString("proveedor")));
				
				tsrBean.setFolio(rs.getInt("folio"));
				tsrBean.setReferenceNumber(rs.getString("referenceNumber"));
				tsrBean.setProveedor(rs.getString("proveedor"));
				tsrBean.setCarrier(rs.getInt("carrier"));
				tsrBean.setCarrierContactName(rs.getString("carrierContactName"));
				tsrBean.setIssueDescription(rs.getString("issueDescription"));
				tsrBean.setFechaRegistro(rs.getInt("fechaRegistro"));
				tsrBean.setTimeRegistro(rs.getDate("timeRegistro"));
				tsrBean.setShippingPort(rs.getString("shippingPort"));
				tsrBean.setETD(rs.getInt("ETD"));
				tsrBean.setCarrier_shippingReleased(rs.getInt("carrier_shippingReleased"));
				tsrBean.setPendiente(rs.getBoolean("pendiente"));
				tsrBean.setRechazado(rs.getBoolean("rechazado"));
				tsrBean.setNombreProveedor(proveedor.getNombreProveedor());
				lstResultados.add(tsrBean);
				
			}
			rs.close();
			pst.close();
			
		} catch (SQLException e) {
			try {
				ConexionDB.renuevaConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
				throw new ServletException(ex);
			}
			log.error(e.getMessage(), e);
			throw new ServletException(e);
		} catch (Exception e) {
			e.printStackTrace();
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
				throw new ServletException(ex);
			}
			log.error(e.getMessage(), e);
			throw new ServletException(e);
		} finally {
			try {
				ConexionDB.devuelveConexion(con);
			} catch (Exception sqlEx2) {
				log.error(sqlEx2.getMessage(), sqlEx2);
				throw new ServletException(sqlEx2);
			}
		}
		return lstResultados;
	}
	
}
