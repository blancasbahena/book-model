package com.srm.pli.constants;

public class SRMManagerConstants
{
	public static final String IDAS_PENDIENTES_PLANNING = "IdasPendientesPlanning";
	public static final String SUPPLIER_CHANGE_REQUEST = "supplierChangerequestReport";
	public static final String REPORTE_SEMANAL_INCIDENCIA = "reporteSemanalIncidencia";
	
	public static final Object HEBREO = "HE";
	public static final Object LETONIANO = "LV";
}
