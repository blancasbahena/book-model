package com.srm.pli.bo;

import java.io.Serializable;
import java.util.Date;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ReporteRequestForChanges implements Serializable
{
	private static final long serialVersionUID = 1L;
	
	private String sar;
	private String reason;
	private String booking;
	private Integer numeroDeCambiosByETD;	
	private String lastETARegistered;
	private Integer currentETARegistered;
	private String lastETD;
	private String etdSolicitada;
	private Integer currentETDRegistered;
	private String vessel;
	private String voyage;
	private String pol;
	private String pod;
	private String carrier;
	private String nombreNavieraByClave;
	private String supplier;
	private String nombreProveedor;
	private Integer tipoContenedor;
	private String nombreContenedorByClave;
	private String contenedor;
	private String bl;
	private String action;
	private Integer idAction;
	private String estatusRM;
	private Date createDate;
	private Date fechaSolicitado;
}
