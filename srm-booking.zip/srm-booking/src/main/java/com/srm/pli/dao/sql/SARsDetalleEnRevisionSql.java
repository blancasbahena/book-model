package com.srm.pli.dao.sql;

public class SARsDetalleEnRevisionSql {
	public static final String INSERT = new StringBuilder("").toString();
		
}
