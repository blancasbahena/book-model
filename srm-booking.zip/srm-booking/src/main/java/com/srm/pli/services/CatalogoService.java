package com.srm.pli.services;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashSet;

import com.srm.pli.constants.SRMManagerConstants;
import com.srm.pli.dao.DocumentosDao;
import com.srm.pli.helper.PriceReleaseHelper;
import com.srm.pli.utils.CatalogosUtils;
import com.srm.pli.utils.PropertiesDb;
import com.truper.businessEntity.BeanLetoniano;
import com.truper.infra.loggers.BaseLogger;

public class CatalogoService {

	private static final CatalogoService instance = new CatalogoService();
	private static DocumentosDao dao = new DocumentosDao();
	private static String line = "";
	BeanLetoniano letoniano = new BeanLetoniano();

	public CatalogoService() {
	}

	public static CatalogoService getInstance() {
		return instance;
	}

	public HashSet<String> getUnidadesDeMedida(String otherType) {
		HashSet<String> unidades = new HashSet<>();
		boolean isService = PriceReleaseHelper.getInstance().isOtherItemService(otherType);
		if (isService) {
			unidades.add(CatalogosUtils.UNIDAD_MEDIDA_SERVICIO);
		} else {
			unidades = CatalogosUtils.getInstance().getUnidadesMedida();
			unidades.remove(CatalogosUtils.UNIDAD_MEDIDA_SERVICIO);
		}
		return unidades;
	}

	public void cargaLetoniano() throws FileNotFoundException {
		String urlProductos = PropertiesDb.getInstance().getString("srm.carga.letoniano");
		
		File file = new File(urlProductos);
		BufferedReader br = new BufferedReader(new FileReader(file));
		try {
			BaseLogger.BOOKING_LOGGER.info("Inicia carga de descripciones letoniano>>> " + urlProductos);
			while ((line = br.readLine()) != null) {
				if (line.length() >= 1450) {
					String item = line.substring(0, 6);
					String desc = line.substring(1290, 1450);
					if (itemValid(item, desc))
						dao.insertLetoniano(letoniano);
				}
			}
			BaseLogger.BOOKING_LOGGER.info("Finaliza carga de descripciones letoniano");
		} catch (IOException e) {
			BaseLogger.BOOKING_LOGGER.error("Error durante la carga de descripciones letoniano  " + e);
		}
	}

	///cargar desde aqui letoniano y hebreo 
	public void cargaHebreo() throws FileNotFoundException {
		String urlProductos = PropertiesDb.getInstance().getString("srm.carga.hebreo");
		File file = new File(urlProductos);
		BufferedReader br = null;
		try {
			br = new BufferedReader(new InputStreamReader(new FileInputStream(file), "utf-8"));
			HashSet<BeanLetoniano> lkdListLetoniano = new HashSet<>(0);
			HashSet<BeanLetoniano> lkdListHebreo = new HashSet<>(0);
			BaseLogger.BOOKING_LOGGER.info("Inicia carga de descripciones Hebreo>>> " + urlProductos);
			while ((line = br.readLine()) != null) {
				if (line.length() >= 277) {
					String material = line.substring(0, 18);
					String idioma = line.substring(19, 21);
					String desc = line.substring(22, 277);
					BeanLetoniano letoniano = new BeanLetoniano();
					if(itemValidByLeng(material, idioma, desc, SRMManagerConstants.HEBREO, letoniano)){
						lkdListHebreo.add(letoniano);
					}else if (itemValidByLeng(material, idioma, desc, SRMManagerConstants.LETONIANO, letoniano)) {
						lkdListLetoniano.add(letoniano);
					}
						
				}
			}
			
			dao.insertLetoniano(lkdListLetoniano);
			dao.insertHebreo(lkdListHebreo);
			
			
			BaseLogger.BOOKING_LOGGER.info("Finaliza carga de descripciones Hebreo/Letoniano");
		} catch (IOException e) {
			BaseLogger.BOOKING_LOGGER.error("Error durante la carga de descripciones Hebreo/Letoniano  " + e);
		} finally {
			try {
				br.close();
			} catch (IOException e) {
				BaseLogger.BOOKING_LOGGER.error("Error al cerrar el archivo " + e);
			}
		}
	}

	public Boolean itemValidByLeng(String material, String idioma, String desc, Object idiomaValido, BeanLetoniano letoniano) {
		if (desc.trim().length()>0  &&  material.matches("-?\\d+(\\.\\d+)?") && idioma.equals(idiomaValido)) {
			letoniano.setItem(Integer.parseInt(material));
			letoniano.setDescripcion(desc);
			return true;
		}
		return false;
	}

	public Boolean itemValid(String strNum, String desc) {
		if (desc.trim().length()>0  &&  strNum.matches("-?\\d+(\\.\\d+)?")) {
			letoniano.setItem(Integer.parseInt(strNum));
			letoniano.setDescripcion(desc);
			return true;
		}
		return false;
	}
}
