package com.srm.pli.helper;

import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.servlet.ServletException;

import com.srm.pli.bo.SarBO;
import com.srm.pli.dao.CorreoDao;
import com.srm.pli.dao.sql.DocumentosSdiSql.DocumentosSdiDaoEnum;
import com.srm.pli.enums.TipoCorreoEnum;
import com.srm.pli.services.CorreoServices;
import com.srm.pli.utils.CorreoUtils;
import com.srm.pli.utils.FuncionesComunesPLI;
import com.srm.pli.utils.FuncionesWebservises;
import com.srm.pli.utils.PropertiesDb;
import com.truper.businessEntity.BeanCompradores;
import com.truper.businessEntity.BeanConfirmador;
import com.truper.businessEntity.SAR;
import com.truper.utils.date.UtilsFechas;
import com.truper.utils.string.UtilsString;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class CorreoHelper {

	public static final String MAIL_FR_HK_NOTIFICATIONS = "email.sender.notifications";
	public static final String MAIL_FR_HK_PRICE_ADJUSTMENT = "email.sender.price.adjustment";
	public static final String MAIL_FR_HK_DOCUMENTS_REQUEST = "email.sender.sdi.request";
	public static final String MAIL_FR_HK_DOCUMENTS_REJECT = "email.sender.sdi.reject";
	public static final String MAIL_FR_HK_AUDIT = "email.sender.audit";
	public static final String MAIL_FR_HK_MATRIX = "email.sender.matrix";
	public static final String MAIL_FR_HK_SYSTEM = "email.sender.system";
	public static final String EMAIL_GERENTE_INVENTARIOS = "email.gerente.inventarios";
	public static final String MAIL_MATRIX_REJECTED = "emails.reporte.matriz.rejected";
	public static final String MAIL_GRUPO_SDI = "email.grupo.sdi";
	public static final String MAILS_REPORTE_SDI_DOCS_INDICADORES = "emails.reporte.sdi.documentos.indicadores";
	public static final String MAILS_REPORTE_SARS_RELESED_PLANNING_SHIPPING_CC = "emails.reporte.releasedSarsByPlanningAndShipping.cc";

	public static final String MAIL_TO = "TO";
	public static final String MAIL_CC = "CC";
	public static final String MAIL_CCO = "CCO";

	public static final String SALUDO_PROVEEDOR = "Dear Supplier,";
	public static final String SALUDO_TODOS = "Dear all,";
	public static final String SALUDO_TODOS_ESP = "Estimados,";
	public static final String SALUDO_CORRESPONDA = "To whom it may concern,";
	public static final String LOGIN_FR = "Login F&R";
	
	public static final String SIN_INFORMACION = "There is no information to report.";
	public static final String INFORMACION_AUTOMATICA = "This information was generated automatically";

	public static final String PRIORIDAD_NORMAL = "#00A9BF";
	public static final String PRIORIDAD_INTERMEDIA = "#e2c50b";
	public static final String PRIORIDAD_URGENTE = "red";
	public static final String PRIORIDAD_SIN_INFORMACION = "rosybrown";

	private static Set<String> FR_GERENTE = new HashSet<>();
	private static int FR_GERENTE_FECHA = 0;

	private static CorreoHelper instance = null;

	private CorreoHelper() {
		FuncionesComunesPLI.getProveedores(false);
		try {
			FuncionesComunesPLI.cargaPropertiesCDI(false);
		} catch (ServletException e) {
			log.error("FuncionesComunesPLI.cargaPropertiesCDI(false)", e);
		}
		cargaMapaGerentesFR(false);
	}

	public static CorreoHelper getInstance() {
		if (instance == null)
			instance = new CorreoHelper();
		return instance;
	}

	public String[] getArrayFromSet(Set<String> correos_set) {
		if (correos_set == null || correos_set.isEmpty())
			return null;
		String[] correos = new String[correos_set.size()];
		correos_set.toArray(correos);
		return correos;
	}

	public String[] getCorreosArrayFrom(Map<String, Set<String>> correos, String mail_type) {
		if (correos == null || !correos.containsKey(mail_type) || correos.get(mail_type).isEmpty()) {
			return null;
		}
		Set<String> aux = correos.get(mail_type);
		String[] r = getArrayFromSet(aux);
		return r;
	}

	public Set<String> getCorreosHashSetFrom(Map<String, Set<String>> correos, String mail_type) {
		if (correos == null || !correos.containsKey(mail_type) || correos.get(mail_type).isEmpty()) {
			return null;
		}
		Set<String> r = correos.get(mail_type);
		return r;
	}

	public Map<String, Set<String>> buildCorreosProveedorSolicitaRevisionDePrecios(Set<String> bus_set,
			boolean tieneMatriz) {
		Map<String, Set<String>> correos = new HashMap<>();
		Set<String> correos_to = new HashSet<>();
		Set<String> correos_cc = new HashSet<>();
		correos_cc.add(SAR.EMAIL_OMAR_MORALES);
		for (String bu : bus_set) {
			Set<String> aux = CorreoServices.getInstance().getCorreosDirectorBu(bu);
			setCorreos(correos_to, aux);
			aux = CorreoServices.getInstance().getCorreosGerenteBu(bu);
			setCorreos(correos_cc, aux);
		}
		if (tieneMatriz) {
			correos_cc.add(SarBO.EMAIL_GERENTE_MATRIZ);
		}
		correos.put(MAIL_TO, correos_to);
		correos.put(MAIL_CC, correos_cc);
		return correos;
	}

	public Set<String> buildCorreosProveedorSolicitaRevisionDePrecios(String grupoDeCompras) {
		Set<String> correos_set = new HashSet<>();
		correos_set.add(SAR.EMAIL_OMAR_MORALES);
		correos_set.add(SAR.EMAIL_GERENTE_AUDITORIA);
		Set<String> aux = CorreoServices.getInstance().getCorreosDirectorBu(grupoDeCompras);
		setCorreos(correos_set, aux);
		aux = CorreoServices.getInstance().getCorreosGerenteBu(grupoDeCompras);
		setCorreos(correos_set, aux);
		return correos_set;
	}

	public Map<String, Set<String>> buildCorreosDocumentosSolicitud(DocumentosSdiDaoEnum accion, String proveedor,
			Set<String> celulas) {
		Map<String, Set<String>> correos = new HashMap<>();
		Set<String> correos_to = new HashSet<>();
		Set<String> correos_cc = new HashSet<>();
		Set<String> correos_aux = CorreoServices.getInstance().getCorreosProveedor(proveedor);
		setCorreos(correos_to, correos_aux);
		if (DocumentosSdiDaoEnum.SOLICITUD_DOC_AVISO_3_DIAS == accion
				|| DocumentosSdiDaoEnum.SOLICITUD_DOC_AVISO_5_DIAS == accion) {
			correos_cc.add(SAR.EMAIL_OMAR_MORALES);
			addDirectorGerenteComprador(celulas, correos_cc);
		}
		if (DocumentosSdiDaoEnum.SOLICITUD_DOC_AVISO_5_DIAS == accion) {
			Collections.addAll(correos_cc, SAR.EMAILS_FR_CHINA_GERENTE);
		}
		correos.put(MAIL_TO, correos_to);
		correos.put(MAIL_CC, correos_cc);
		return correos;
	}

	public Map<String, Set<String>> buildCorreosDocumentosSolicitudCorreccion(DocumentosSdiDaoEnum accion,
			String proveedor, Set<String> celulas) {
		Map<String, Set<String>> correos = new HashMap<>();
		Set<String> correos_to = new HashSet<>();
		Set<String> correos_cc = new HashSet<>();
		Set<String> correos_aux = CorreoServices.getInstance().getCorreosProveedor(proveedor);
		setCorreos(correos_to, correos_aux);
		if (DocumentosSdiDaoEnum.SOLICITUD_DOC_CORRECCION_AVISO_0_DIAS == accion) {
			correos_cc.add(SAR.EMAIL_DOCUMENTOS);
		}
		if (DocumentosSdiDaoEnum.SOLICITUD_DOC_CORRECCION_AVISO_2_DIAS == accion) {
			addDirectorGerente(celulas, correos_cc);
			Collections.addAll(correos_cc, SAR.MAIL_GRUPO_SDI);
		}
		if (DocumentosSdiDaoEnum.SOLICITUD_DOC_CORRECCION_AVISO_4_DIAS == accion) {
			addDirectorGerenteComprador(celulas, correos_cc);
			correos_cc.add(SAR.EMAIL_FR_CHINA_DIRECTOR);
		}
		if (DocumentosSdiDaoEnum.SOLICITUD_DOC_CORRECCION_AVISO_2_DIAS == accion
				|| DocumentosSdiDaoEnum.SOLICITUD_DOC_CORRECCION_AVISO_4_DIAS == accion) {
			Collections.addAll(correos_cc, SAR.EMAILS_FR_CHINA_GERENTE);
			correos_cc.add(SAR.EMAIL_OMAR_MORALES);
		}
		correos.put(MAIL_TO, correos_to);
		correos.put(MAIL_CC, correos_cc);
		return correos;
	}

	public Map<String, Set<String>> buildCorreosRechazoAuditoria(Set<String> celulas) {
		Map<String, Set<String>> correos = buildCorreosAuditoriaMatriz(celulas);
		addEmails(correos, MAIL_CC, SAR.MAIL_GIL);
		addEmails(correos, MAIL_CC, SAR.EMAIL_GERENTE_AUDITORIA);
		return correos;
	}

	public Map<String, Set<String>> buildCorreosRechazoMatriz(Set<String> celulas) {
		Map<String, Set<String>> correos = buildCorreosAuditoriaMatriz(celulas);
		addEmails(correos, MAIL_CC, SAR.MAIL_GIL);
		addEmails(correos, MAIL_CC, SAR.EMAIL_GERENTE_MATRIZ);
		return correos;
	}

	public Map<String, Set<String>> buildCorreosLiberacionMatriz(Set<String> celulas) {
		Map<String, Set<String>> correos = buildCorreosAuditoriaMatriz(celulas);
		addEmails(correos, MAIL_CC, SAR.EMAIL_GERENTE_MATRIZ);
		return correos;
	}

	private Map<String, Set<String>> buildCorreosAuditoriaMatriz(Set<String> celulas) {
		Map<String, Set<String>> correos = new HashMap<>();
		Set<String> correos_to = new HashSet<>();
		correos_to.add(SAR.EMAIL_OMAR_MORALES);
		Collections.addAll(correos_to, SAR.MAIL_GRUPO_GERENTES_PLANNING);
		addDirectorGerente(celulas, correos_to);
		correos.put(MAIL_TO, correos_to);
		return correos;
	}

	/**
	 * @param celulas
	 * @param correos_cc
	 */
	private void addDirectorGerenteComprador(Set<String> celulas, Set<String> correos_cc) {
		if (celulas == null || celulas.isEmpty())
			return;
		Set<String> correos_aux;
		for (String celula : celulas) {
			correos_aux = CorreoServices.getInstance().getCorreosDirectorBu(celula);
			setCorreos(correos_cc, correos_aux);
			correos_aux = CorreoServices.getInstance().getCorreosGerenteBu(celula);
			setCorreos(correos_cc, correos_aux);
			correos_aux = CorreoServices.getInstance().getCompradoresCorreos(celula);
			setCorreos(correos_cc, correos_aux);
		}
	}

	/**
	 * @param celulas
	 * @param correos_cc
	 */
	private void addDirectorGerente(Set<String> celulas, Set<String> correos_cc) {
		if (celulas == null || celulas.isEmpty())
			return;
		Set<String> correos_aux;
		for (String celula : celulas) {
			correos_aux = CorreoServices.getInstance().getCorreosDirectorBu(celula);
			setCorreos(correos_cc, correos_aux);
			correos_aux = CorreoServices.getInstance().getCorreosGerenteBu(celula);
			setCorreos(correos_cc, correos_aux);
		}
	}

	/**
	 * @param correos_cc
	 * @param correos_aux
	 */
	private void setCorreos(Set<String> correos_destino, Set<String> correos_origen) {
		if (correos_origen == null || correos_origen.isEmpty())
			return;
		correos_destino.addAll(correos_origen);
	}

	public void cargaMapaGerentesFR(boolean cargar) {
		if (!cargar && FR_GERENTE_FECHA == UtilsFechas.getFechaActual_yyyyMMdd())
			return;
		Set<String> correos;
		try {
			correos = CorreoDao.getInstance().getCorreos(TipoCorreoEnum.FR_GERENTE);
			if (correos != null) {
				FR_GERENTE.clear();
				FR_GERENTE = correos;
				FR_GERENTE_FECHA = UtilsFechas.getFechaActual_yyyyMMdd();
			}
		} catch (Exception e) {
			log.error("cargaMapaGerentesFR(boolean cargar) {}", cargar, e);
		}
	}

	public Set<String> getMapaGerentesFR() {
		Set<String> copy = new HashSet<>(FR_GERENTE);
		return copy;
	}

	/**
	 * @param correos
	 * @return
	 */
	private void addEmails(Map<String, Set<String>> correos, String to_cc_cco, String... emails) {
		Set<String> correos_to_cc_cco = correos.get(to_cc_cco);
		if (correos_to_cc_cco == null) {
			correos_to_cc_cco = new HashSet<>();
			correos.put(to_cc_cco, correos_to_cc_cco);
		}
		for (String email : emails) {
			boolean valido = CorreoUtils.getInstance().isCorreoValido(email);
			if (!valido) {
				continue;
			}
			correos_to_cc_cco.add(email.trim());
		}
	}

	public Map<String, Set<String>> buildCorreosAjustePrecios(Set<String> celulas) {
		Map<String, Set<String>> correos = new HashMap<>();
		addEmails(correos, MAIL_TO, SAR.MAIL_GRUPO_GERENTES_PLANNING);
		Set<String> correos_cc = new HashSet<>();
		addDirectorGerente(celulas, correos_cc);
		correos.put(MAIL_CC, correos_cc);
		return correos;
	}

	public Map<String, Set<String>> buildCorreosReporteSarsConfirmacionFinal() {
		Map<String, Set<String>> correos = new HashMap<>();
		addEmails(correos, MAIL_TO, SAR.MAIL_GRUPO_GERENTES_PLANNING);
		addEmails(correos, MAIL_TO, SarBO.EMAIL_SHIPPING); 
		addEmails(correos, MAIL_TO, SarBO.EMAIL_EISEN_SHIPPING); 
		return correos;
	}
	
	public Map<String, Set<String>> buildCorreosIdaConsol() {
		Map<String, Set<String>> correos = new HashMap<>();
		addEmails(correos, MAIL_TO, SAR.MAIL_GRUPO_GERENTES_PLANNING);
		addEmails(correos, MAIL_TO, SarBO.MAIL_GRUPO_CONSOL);
		addEmails(correos, MAIL_TO, getEmail(EMAIL_GERENTE_INVENTARIOS));
		return correos;
	}
	
	/**
	 * Regresa correo de gerente, comprador y asesor en un solo arreglo
	 * @param planners
	 * @return
	 */
	public Set<String> dameTodoComprasByPlanner(Set<String> planners){
		Map<String, BeanCompradores> datosCompradores = FuncionesWebservises.getDatosCompradoresByPlanner(planners);
		if(datosCompradores == null || datosCompradores.isEmpty()) {
			return null;
		}else {
			Set<String> arregloDirecciones = new HashSet<>();
			for(Entry<String, BeanCompradores> entry : datosCompradores.entrySet()) {
				BeanCompradores bean = entry.getValue();
				if(UtilsString.isStringValida(bean.getMailGerente())) {
					arregloDirecciones.add(bean.getMailGerente());
				}
				if(UtilsString.isStringValida(bean.getMailComprador())) {
					arregloDirecciones.add(bean.getMailComprador());
				}
				if(UtilsString.isStringValida(bean.getMailAsistente())) {
					arregloDirecciones.add(bean.getMailAsistente());
				}
				return arregloDirecciones;
			}
		}
		return null;
	}
	
	/**
	 * @see PropertiesDb #getStringTrim(String)
	 */
	public String getEmail(String llave) {
		return PropertiesDb.getInstance().getStringTrim(llave);
	}
	
	/**
	 * Regresa un set de correos validos con base en un propertie
	 * 
	 * @param llave
	 * @return
	 */
	public Set<String> getEmails(String llave) {
		String correos = PropertiesDb.getInstance().getStringTrim(llave);
		if (correos == null)
			return null;
		if(correos.isEmpty())
			return new HashSet<>();
		Set<String> correosValidos = CorreoUtils.getInstance().splitCorreos(correos, PropertiesDb.SEPARADOR_ARRAY);
		return correosValidos;
	}
	
	public Map<String, Set<String>> buildCorreosSolicitudRevokeFinalConfirmation(Set<Integer> sars,
			Set<String> celulas) {
		Map<String, Set<String>> correos = new HashMap<>();
		Set<String> correos_to = new HashSet<>();
		Set<String> correos_cc = new HashSet<>();

		
		addDirectorGerenteComprador(celulas, correos_to);
		Map<Integer, BeanConfirmador> confirmadores = CorreoServices.getInstance().getConfirmadorSar(sars);
		if(confirmadores != null && !confirmadores.isEmpty()) {
			for (BeanConfirmador bean : confirmadores.values()) {
				correos_cc.add(bean.getCorreo());
			}
		}
		
		
    	Set<String> adicionales = CorreoHelper.getInstance().getEmails("emails.sdi.revoke.additional");
    	if (adicionales != null && !adicionales.isEmpty()) {
    		correos_to.addAll(adicionales);
    	}
		
		
		correos.put(MAIL_TO, correos_to);
		correos.put(MAIL_CC, correos_cc);
		return correos;
	}
}