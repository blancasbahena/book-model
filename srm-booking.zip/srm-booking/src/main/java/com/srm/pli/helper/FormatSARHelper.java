package com.srm.pli.helper;

import java.sql.SQLException;
import java.util.List;
import java.util.Set;

import javax.servlet.ServletException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.srm.pli.bo.SarBO;
import com.srm.pli.bo.SarDetalleBO;
import com.srm.pli.dao.SAR_CDI_DAO;
import com.srm.pli.services.DetallesServices;
import com.srm.pli.utils.FuncionesComunesPLI;
import com.truper.businessEntity.SAR;

/**
 * Se crea esta clase con el fin de eliminar el uso de la clase FormatSAR
 * para solo usar los datos necesarios y no la carga completa de informacion como 
 * se hace actualmente.
 * Si se requiere cargar algun mapa se solicita la carga de este en el constructor.
 * 
 * @author drodriguezv
 *
 */
public class FormatSARHelper {
	private static FormatSARHelper instance;
	private SAR_CDI_DAO dao = new SAR_CDI_DAO();
	private static final String CONSOLIDADO_PREFIJO = "C";
	private static final String FULL_PREFIJO = "F";
	private static final String REVISION_PREFIJO = "R";
	private static final String CAMBIO_PREFIJO = "M";
	private static Set<String> ALMACENES_DIRECTOS = null;
	private static Set<String> CENTROS_DIRECTOS = null;
	
	public static final Logger log = LogManager.getRootLogger();
	
	//constrictor privado, lo usare para cargar mapas la primera vez
	private FormatSARHelper() {
		try {
			FuncionesComunesPLI.cargaPlanners(false);
			FuncionesComunesPLI.cargaContenedores(false);
			FuncionesComunesPLI.cargaMapaCelulasXUnidadNegocio(false);
			FuncionesComunesPLI.cargaPuertosDestino(false);
			FuncionesComunesPLI.cargaAerolineasYPuertos(false);
			FuncionesComunesPLI.cargaPuertosOrigen(false);
			FuncionesComunesPLI.cargaMapaBloqueos(false);
			FuncionesComunesPLI.cargaPuertosDirectos(false);
			FuncionesComunesPLI.cargaNavieras(false);
		} catch (ServletException e) {
			log.error("[FormatSARHelper - constructor] Error al cargar los mapas", e.toString());
		}
	}
	
	static {
		instance = new FormatSARHelper();
	}
	
	public static FormatSARHelper getInstance() {
		return instance;
	}
	
	
	/**
	 * Regresa el nombre de la naviera, tengo que consultar el sar en tablas e ir por 
	 * su detalle para saber si es directo para saber que mapa afectar
	 * 
	 * 
	 * 
	 * @param folio
	 * @return
	 * @throws SQLException 
	 * @throws ClassNotFoundException 
	 */
	public String dameNombreNaviera(int folio) throws ClassNotFoundException, SQLException {
		SarBO bo = new SarBO();
		bo.setFolio(folio);
		List<SarBO> lista = dao.selectSar(bo,false);
		if(lista == null || lista.size() == 0) {
			return null;
		}
		String naviera = "";
		bo = lista.get(0);//Como consulto por Folio solo debe tener 1 el indice 0
		if (bo.getNaviera() == null) {
			naviera = "-";
		} else {
			naviera = FuncionesComunesPLI.mapaNavieras.get(bo.getNaviera()) != null ? FuncionesComunesPLI
					.mapaNavieras.get(bo.getNaviera()).getNombre()
					: "-";
		}
		return naviera;
	}
	
	//TODO generar el metodo que recibe el bean revisar si tiene su detalle para no ir a tablas
	public String dameNombreNaviera(SarBO sar) {
		return null;
	}
	
	public String dameSARPreSufijo(SarBO bean) throws ClassNotFoundException, SQLException {
		Boolean sarImportado = FuncionesComunesPLI.elSarEsImportado(bean);
		
		StringBuilder sb = new StringBuilder();
		sb.append(bean.getConsolidado() != null && bean.getConsolidado() ? CONSOLIDADO_PREFIJO : FULL_PREFIJO);
		sb.append(bean.getFolio());
		sb.append((sarImportado != null && sarImportado) ? SAR.detMercImportado
				: SAR.detMercNoImportado);
		if(bean.getRevision() != null && bean.getRevision() > 0  ){
			sb.append(REVISION_PREFIJO+bean.getRevision());
		}
		
		if(bean.getNumRevFinal() != null && bean.getNumRevFinal() > 0) {
			sb.append(CAMBIO_PREFIJO+bean.getNumRevFinal());
		}
		return sb.toString();
	}
	
	public String dameSARPreSufijo(int folio) throws ClassNotFoundException, SQLException {
		SarBO bo = new SarBO();
		bo.setFolio(folio);
		List<SarBO> lista = dao.selectSar(bo,false);
		if(lista == null || lista.size() == 0) {
			return null;
		}
		return dameSARPreSufijo(lista.get(0));
	}
	
	/**
	 * 
	 * @param bo
	 * @return
	 */
	public boolean tienePedioDirecto(SarBO bo) {
		try {
			if(bo == null) {
				return false;
			}
			ALMACENES_DIRECTOS =  DirectosHelper.getInstance().getAlmacenes();
			CENTROS_DIRECTOS   =  DirectosHelper.getInstance().getCentros();
			
			List<SarDetalleBO> detalles = null;
			if(bo.getDetalleBO() == null || bo.getDetalleBO().isEmpty()) {
				DetallesServices.getInstance().cargaDatosSARs(bo);
				detalles = DetallesServices.getInstance().getDetalleSAR(bo);
			}else {
				detalles = bo.getDetalleBO();
			}
			
			if(detalles == null || detalles.isEmpty()) {
				return false;
			}
			
			for(SarDetalleBO det : detalles) {
				if(det.isPedidoDirecto()) {
					return true; 
				}
				if(ALMACENES_DIRECTOS != null && ALMACENES_DIRECTOS.contains(det.getAlmacen())) {
					return true;
				}
				if(CENTROS_DIRECTOS != null && CENTROS_DIRECTOS.contains(det.getCentro())) {
					return true;
				}
			}
		}catch (Exception e) {
			log.error("Error validar si un sar es directo. SAR#{}",bo.getFolio(),e);
		}
		//Si no hay algun directo regreso false
		return false;
	}
	
	public boolean tienePedioDirecto(int sar) {
		SarBO bo = new SarBO();
		bo.setFolio(sar);
		return tienePedioDirecto(bo);
	}
	
}
