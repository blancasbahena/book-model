package com.srm.pli.bo;

import java.util.UUID;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
@AllArgsConstructor
public class ResponseWsPlanners {
	private String mensaje;
	private String tipoMensaje;
	private String folio;
	private String descripcionError;
	
	
	public ResponseWsPlanners(String tipo, String msg, String descError) {
		this.mensaje = msg;
		this.tipoMensaje = tipo;
		this.descripcionError = descError;
		this.folio = UUID.randomUUID().toString();
	}
}
