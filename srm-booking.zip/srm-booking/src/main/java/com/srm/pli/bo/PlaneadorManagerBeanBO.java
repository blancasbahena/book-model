package com.srm.pli.bo;

import java.io.Serializable;
import java.util.Objects;

import lombok.Data;

@Data
public class PlaneadorManagerBeanBO implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String idPlaneador;
	private String nombre;
	private String [] correos;
	private String gerente;
	private String correoGerente;
	private String identificadorPlaneador;
	private String identificadorGerente;
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PlaneadorManagerBeanBO other = (PlaneadorManagerBeanBO) obj;
		return Objects.equals(gerente, other.gerente);
	}
	
	@Override
	public int hashCode() {
		return Objects.hash(gerente);
	} 
	
}
