package com.srm.pli.process;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.Collections;
import java.util.GregorianCalendar;
import java.util.List;

import javax.servlet.ServletException;

import org.apache.commons.io.FileUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;

import com.srm.fungandrui.facturacion.dto.ReporteProcesoSifeDTO;
import com.srm.pli.bo.BeanFiltroMatriz;
import com.srm.pli.bo.BeanMatrizCabecera;
import com.srm.pli.bo.BeanMatrizVistaCabecera;
import com.srm.pli.bo.jasperReports.BeanReporteControlPrecio;
import com.srm.pli.dao.MatricesDAO;
import com.srm.pli.helper.MatricesHelper;
import com.srm.pli.helper.ReportesHelper;
import com.srm.pli.services.ExcelWriter;
import com.srm.pli.utils.FuncionesComunesPLI;
import com.srm.pli.utils.MailUtils;
import com.truper.businessEntity.BeanXdias;
import com.truper.helper.jr.JasperServices;
import com.truper.utils.date.UtilsFechas;

import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
public class GeneraReportesMatriz  {
	private static final Logger log = LogManager.getRootLogger();
	public static String PATH_FILES = "C:"+ File.separator+"arch"+ File.separator+"Reports"+File.separator+"Matriz";
	public static String PENDIENTES = "PPL";
	public static String LIBERADOS = "REL";
	public static String EXITOSOS_SIFE = "PROEX";
	public static String RECHAZADOS = "REJ";
	public static String GENERAL = "general";
	public static String SEPARADOR_FECHAS = "/";
	public static String VACIO = "";
	
	private static final GeneraReportesMatriz instance = new GeneraReportesMatriz();
	
	private GeneraReportesMatriz() {
	}

	public static GeneraReportesMatriz getInstance() {
		return instance;
	}
	
	
	public File generaReportesMatriz(String inicio, String fin, String tipo, String po, String supplier) throws JRException, IOException {
		String path = dameRutaArchivos();
		InputStream mrpFile = null;
		
		BeanFiltroMatriz filtro = new BeanFiltroMatriz();
		int inicioInt = VACIO.equals(inicio) ? 0  : FuncionesComunesPLI.fechaJquery2int(inicio, "/");
		int finInt = VACIO.equals(fin) ? 0  : FuncionesComunesPLI.fechaJquery2int(fin, "/");
		filtro.setPo(( po == null ||  "".equals(po) ) ? null : po );
		filtro.setProveedor(( supplier == null ||  "".equals(supplier) ) ? null : supplier);
		List<BeanMatrizCabecera> listaCabeceras = null;
		
		String nombreArchivo="";
		if(PENDIENTES.equals(tipo)) {
			mrpFile = getClass().getClassLoader().getResourceAsStream("MatrizLiberar.jrxml");
			filtro.setLogIni(inicioInt == 0 ? null : UtilsFechas.setConvierteFechaIntToDate(inicioInt));
			filtro.setLogFin(finInt == 0 ? null : UtilsFechas.setConvierteFechaIntToDate(finInt));
			filtro.setStatus(PENDIENTES);
			nombreArchivo = "Missing_TORealease.xls";
		}else if(LIBERADOS.equals(tipo)) {
			mrpFile = getClass().getClassLoader().getResourceAsStream("MatrizLiberadas.jrxml");
			filtro.setModIni(inicioInt == 0 ? null : UtilsFechas.setConvierteFechaIntToDate(inicioInt));
			filtro.setModFin(finInt == 0 ? null : UtilsFechas.setConvierteFechaIntToDate(finInt));
			filtro.setStatus(LIBERADOS);
			nombreArchivo = "Matrix_Released.xls";
		}else {
			mrpFile = getClass().getClassLoader().getResourceAsStream("MatrizRechazadas2.jrxml");
			filtro.setModIni(inicioInt == 0 ? null : UtilsFechas.setConvierteFechaIntToDate(inicioInt));
			filtro.setModFin(finInt == 0 ? null : UtilsFechas.setConvierteFechaIntToDate(finInt));
			filtro.setStatus(RECHAZADOS);
			nombreArchivo = "Matrix_rejected.xls";
		}
		
    	JRDataSource jrdatasource = null;
    	listaCabeceras = MatricesDAO.getInstance().selectRegistrosMatriz(filtro);
		if(listaCabeceras == null || listaCabeceras.isEmpty()) {
			return null;
		}
		Collections.sort(listaCabeceras, MatricesHelper.getInstance().ordenaResultadosVista());
		List<BeanMatrizVistaCabecera> listaRrportes = MatricesHelper.getInstance().generaBeanVista(listaCabeceras);
		jrdatasource = new JRBeanCollectionDataSource(listaRrportes);
        JasperServices js = new JasperServices(mrpFile, jrdatasource, null);
        byte[] pdfBytes = js.getReportByteArray(JasperServices.XLS_TYPE);
        File toSave = new File(path+nombreArchivo);
        FileUtils.writeByteArrayToFile(toSave, pdfBytes);
        log.info("Se genero archivo {}  mailReportesDocumentoProcesadosExitosamente ",path+nombreArchivo );
		return toSave;
	}
	public File generaReportesSife(String tipo,String nombreArchivoSife,String numeroDiasRestadosSife){
		ExcelWriter ex= new ExcelWriter();
		String path = dameRutaArchivos();
		String nombreHoja="ReportSife";
		File toSave = null; 
		if(EXITOSOS_SIFE.equals(tipo)) { 
			log.info("INICIO obtiene archivo : {}  generaReportesSife ",nombreArchivoSife+".xls" );
			nombreArchivoSife  = nombreArchivoSife+".xls";
    		List<ReporteProcesoSifeDTO> listaDatosDeHoy=MatricesDAO.getInstance().selectRegistrosSife(numeroDiasRestadosSife);
    		log.info("INICIO se muestra numero de registros : {}  generaReportesSife ",listaDatosDeHoy.size() );
    		if(listaDatosDeHoy.size()==0) {
    			nombreArchivoSife = "Empty.xlsx";
    			nombreHoja="Empty Report";
    		}
    		try {
				toSave= ex.getReporteSife(listaDatosDeHoy,nombreArchivoSife,nombreHoja,path);
			} catch (InvalidFormatException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    	} 
		return toSave;
	}
	
	public File generaReportesAuditoria(List<BeanReporteControlPrecio> listaRrportes) throws JRException, IOException {
		InputStream mrpFile = getClass().getClassLoader().getResourceAsStream("AuditoriaPendientesLiberar.jrxml");
		String path = dameRutaArchivos();
    	JRDataSource jrdatasource = new JRBeanCollectionDataSource(listaRrportes);
        JasperServices js = new JasperServices(mrpFile, jrdatasource, null);
        byte[] pdfBytes = js.getReportByteArray(JasperServices.XLS_TYPE);
        File toSave = new File(path + "PosConPbPendientesDeLiberarConMatriz.xls");
        FileUtils.writeByteArrayToFile(toSave, pdfBytes);
		return toSave;
	}
	
	public File generaReportePOsPIsPendientesDeRevisionCompras(List<BeanReporteControlPrecio> listaRrportes) throws JRException, IOException {
    	InputStream mrpFile = ReportesHelper.getInstance().getInputStream("ModuloComprasReporte.jrxml");
		String path = dameRutaArchivos();
    	JRDataSource jrdatasource = new JRBeanCollectionDataSource(listaRrportes);
        JasperServices js = new JasperServices(mrpFile, jrdatasource, null);
        byte[] pdfBytes = js.getReportByteArray(JasperServices.XLS_TYPE);
        File toSave = new File(path + "ReportePOsPIsPendientesDeRevisionCompras.xls");
        FileUtils.writeByteArrayToFile(toSave, pdfBytes);
		return toSave;
	}
	
	public void generaReporteXdias(String subject,String[] mailsTo,String[] mailsCC) throws ServletException {
		List<BeanXdias> lista = MatricesDAO.getInstance().posConRecordatorioXDias();
		MailUtils.mandaMailRecordatorioXDias(lista, subject, mailsTo, mailsCC);
	}
	
	
	public  String dameRutaArchivos()  {
		GregorianCalendar greg = new GregorianCalendar();
		int year = FuncionesComunesPLI.gregorianCalendar2int(greg);
		year = year / 10000;
		StringBuffer ruta = new StringBuffer();
		ruta.append(PATH_FILES);
		ruta.append(File.separator);
		ruta.append(year);
		ruta.append(File.separator);
		return ruta.toString();
	}
			
}
