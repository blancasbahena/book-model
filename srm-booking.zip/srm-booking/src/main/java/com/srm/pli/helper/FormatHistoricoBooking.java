package com.srm.pli.helper;

import org.apache.commons.lang3.StringEscapeUtils;

import com.srm.pli.utils.FuncionesComunesPLI;
import com.truper.businessEntity.SARHistoricoBooking;

public class FormatHistoricoBooking {
	
	private String folio;
	private Integer folioRaw;
	private String tipoSar;
	private String booking;
	private String barcoSugerido;
	private String etd;
	private String eta;
	private String contenedor;
	private String usuario;
	private String usuarioString;
	private Integer fechaRegistro;
	private String fechaRegistroFormat;
	private double fechaLong;
	private String viaje;
	private String comentario;
	private Integer naviera;
	private String navieraDesc;
	private String puertoOrigen;
	private String puertoOrigenDesc;
	private String puertoDestino;
	private String puertoDestinoDesc;
	private String tipoContenedor;
	
	public FormatHistoricoBooking(SARHistoricoBooking hist) {
		FuncionesComunesPLI.cargaPuertosOrigen(false);
		FuncionesComunesPLI.cargaPuertosDestino(false);
		FuncionesComunesPLI.cargaNavieras(false);
		folio = "F".equals(hist.getTipoSar()) ? "F" + hist.getFolio() : "CC" + hist.getFolio();
		folioRaw = hist.getFolio();
		tipoSar = hist.getTipoSar();
		booking = hist.getBooking();
		barcoSugerido = hist.getBarcoSugerido();
		String etdV;
		if ((hist.getEtd() == null || hist.getEtd() == 0)) {
			etdV = "-";
		} else {
			etdV = FuncionesComunesPLI.formateaFechaYYYYMMDD(hist.getEtd());
		}
		etd = etdV;
		String etaV;
		if (hist.getEta() == null || hist.getEta() == 0) {
			etaV = "-";
		} else {
			etaV = FuncionesComunesPLI.formateaFechaYYYYMMDD(hist.getEta());
		}
		eta = etaV;
		contenedor = hist.getContenedor() == null ? "-" : hist.getContenedor();
		usuario = hist.getUsuario();
		usuarioString = StringEscapeUtils.escapeHtml3(hist.getUsuarioString());
		fechaRegistro = hist.getFechaRegistro();
		String fechaRegistroFormatV = FuncionesComunesPLI.formateaFechaYYYYMMDD(hist.getFechaRegistro());
		fechaRegistroFormat = fechaRegistroFormatV;
		fechaLong = hist.getFechaLong();
		viaje = hist.getViaje();
		String comentarioV = hist.getComentarioTruperBooking() != null ? 
				StringEscapeUtils.escapeHtml3(hist.getComentarioTruperBooking().toString()) : "";
		comentario = comentarioV;
		naviera = hist.getNaviera();
		String navieraDescr = hist.getNaviera() != null
				&& FuncionesComunesPLI.mapaNavieras.get(hist.getNaviera()) != null ? 
				FuncionesComunesPLI.mapaNavieras.get(hist.getNaviera()).getNombre() : "-";
		navieraDesc = navieraDescr;
		puertoOrigen = hist.getPuertoOrigen();
		String puertoOrigenDescr = FuncionesComunesPLI.mapaPuertosOrigen.get(hist.getPuertoOrigen()) != null ? 
				StringEscapeUtils.escapeHtml3(FuncionesComunesPLI.mapaPuertosOrigen.get(hist.getPuertoOrigen()).getNombre()) : "-";
		puertoOrigenDesc = puertoOrigenDescr;
		puertoDestino = hist.getPuertoDestino();
		String puertoDestinoDescr = FuncionesComunesPLI.mapaPuertosDestino.get(hist.getPuertoDestino()) != null ? StringEscapeUtils
				.escapeHtml3(FuncionesComunesPLI.mapaPuertosDestino.get(hist.getPuertoDestino()).getNombre()) : "-";
		puertoDestinoDesc = puertoDestinoDescr;
		if(hist.getTipoContenedor() != null && hist.getTipoContenedor().intValue() != 0){
			tipoContenedor = FuncionesComunesPLI.mapaContenedores.get(hist.getTipoContenedor()).getNombre();
		}else{
			tipoContenedor = "N.D";
		}
		
		
	}

	/**
	 * @return the folio
	 */
	public String getFolio() {
		return folio;
	}

	/**
	 * @param folio the folio to set
	 */
	public void setFolio(String folio) {
		this.folio = folio;
	}

	/**
	 * @return the folioRaw
	 */
	public Integer getFolioRaw() {
		return folioRaw;
	}

	/**
	 * @param folioRaw the folioRaw to set
	 */
	public void setFolioRaw(Integer folioRaw) {
		this.folioRaw = folioRaw;
	}

	/**
	 * @return the tipoSar
	 */
	public String getTipoSar() {
		return tipoSar;
	}

	/**
	 * @param tipoSar the tipoSar to set
	 */
	public void setTipoSar(String tipoSar) {
		this.tipoSar = tipoSar;
	}

	/**
	 * @return the booking
	 */
	public String getBooking() {
		return booking;
	}

	/**
	 * @param booking the booking to set
	 */
	public void setBooking(String booking) {
		this.booking = booking;
	}

	/**
	 * @return the barcoSugerido
	 */
	public String getBarcoSugerido() {
		return barcoSugerido;
	}

	/**
	 * @param barcoSugerido the barcoSugerido to set
	 */
	public void setBarcoSugerido(String barcoSugerido) {
		this.barcoSugerido = barcoSugerido;
	}

	/**
	 * @return the etd
	 */
	public String getEtd() {
		return etd;
	}

	/**
	 * @param etd the etd to set
	 */
	public void setEtd(String etd) {
		this.etd = etd;
	}

	/**
	 * @return the eta
	 */
	public String getEta() {
		return eta;
	}

	/**
	 * @param eta the eta to set
	 */
	public void setEta(String eta) {
		this.eta = eta;
	}

	/**
	 * @return the contenedor
	 */
	public String getContenedor() {
		return contenedor;
	}

	/**
	 * @param contenedor the contenedor to set
	 */
	public void setContenedor(String contenedor) {
		this.contenedor = contenedor;
	}

	/**
	 * @return the usuario
	 */
	public String getUsuario() {
		return usuario;
	}

	/**
	 * @param usuario the usuario to set
	 */
	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}

	/**
	 * @return the usuarioString
	 */
	public String getUsuarioString() {
		return usuarioString;
	}

	/**
	 * @param usuarioString the usuarioString to set
	 */
	public void setUsuarioString(String usuarioString) {
		this.usuarioString = usuarioString;
	}

	/**
	 * @return the fechaRegistro
	 */
	public Integer getFechaRegistro() {
		return fechaRegistro;
	}

	/**
	 * @param fechaRegistro the fechaRegistro to set
	 */
	public void setFechaRegistro(Integer fechaRegistro) {
		this.fechaRegistro = fechaRegistro;
	}

	/**
	 * @return the fechaRegistroFormat
	 */
	public String getFechaRegistroFormat() {
		return fechaRegistroFormat;
	}

	/**
	 * @param fechaRegistroFormat the fechaRegistroFormat to set
	 */
	public void setFechaRegistroFormat(String fechaRegistroFormat) {
		this.fechaRegistroFormat = fechaRegistroFormat;
	}

	/**
	 * @return the fechaLong
	 */
	public double getFechaLong() {
		return fechaLong;
	}

	/**
	 * @param fechaLong the fechaLong to set
	 */
	public void setFechaLong(double fechaLong) {
		this.fechaLong = fechaLong;
	}

	/**
	 * @return the viaje
	 */
	public String getViaje() {
		return viaje;
	}

	/**
	 * @param viaje the viaje to set
	 */
	public void setViaje(String viaje) {
		this.viaje = viaje;
	}

	/**
	 * @return the comentario
	 */
	public String getComentario() {
		return comentario;
	}

	/**
	 * @param comentario the comentario to set
	 */
	public void setComentario(String comentario) {
		this.comentario = comentario;
	}

	/**
	 * @return the naviera
	 */
	public Integer getNaviera() {
		return naviera;
	}

	/**
	 * @param naviera the naviera to set
	 */
	public void setNaviera(Integer naviera) {
		this.naviera = naviera;
	}

	/**
	 * @return the navieraDesc
	 */
	public String getNavieraDesc() {
		return navieraDesc;
	}

	/**
	 * @param navieraDesc the navieraDesc to set
	 */
	public void setNavieraDesc(String navieraDesc) {
		this.navieraDesc = navieraDesc;
	}

	/**
	 * @return the puertoOrigen
	 */
	public String getPuertoOrigen() {
		return puertoOrigen;
	}

	/**
	 * @param puertoOrigen the puertoOrigen to set
	 */
	public void setPuertoOrigen(String puertoOrigen) {
		this.puertoOrigen = puertoOrigen;
	}

	/**
	 * @return the puertoOrigenDesc
	 */
	public String getPuertoOrigenDesc() {
		return puertoOrigenDesc;
	}

	/**
	 * @param puertoOrigenDesc the puertoOrigenDesc to set
	 */
	public void setPuertoOrigenDesc(String puertoOrigenDesc) {
		this.puertoOrigenDesc = puertoOrigenDesc;
	}

	/**
	 * @return the puertoDestino
	 */
	public String getPuertoDestino() {
		return puertoDestino;
	}

	/**
	 * @param puertoDestino the puertoDestino to set
	 */
	public void setPuertoDestino(String puertoDestino) { 
		this.puertoDestino = puertoDestino;
	}

	/**
	 * @return the puertoDestinoDesc
	 */
	public String getPuertoDestinoDesc() {
		return puertoDestinoDesc;
	}

	/**
	 * @param puertoDestinoDesc the puertoDestinoDesc to set
	 */
	public void setPuertoDestinoDesc(String puertoDestinoDesc) {
		this.puertoDestinoDesc = puertoDestinoDesc;
	}

	public String getTipoContenedor() {
		return tipoContenedor;
	}

	public void setTipoContenedor(String tipoContenedor) {
		this.tipoContenedor = tipoContenedor;
	}

}
