package com.srm.pli.rest;

import java.util.ArrayList;

import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.srm.pli.bo.SarBO;
import com.srm.pli.dao.SAR_CDI_DAO;
import com.srm.pli.utils.FuncionesComunesPLI;
import com.truper.businessEntity.SAR;
import com.truper.infra.rs.BaseRS;


@Path("/bookingService")
public class PLIServices extends BaseRS{
	
	Gson g = new GsonBuilder().serializeSpecialFloatingPointValues().create();
	
	/**
	 * Metodo de consulta, se utiliza para todos los tipos de selects, por medio de la clase define que metodo usar.
	 * Regresa un json que sera enviado por medio del servicio Rest
	 * 
	 * @param clazz Tipo de la clase que se envia
	 * @param jsonObject El json en sting
	 * @param accion la accion, por si no es suficiente con la clase para identificar
	 * @return Response
	 */
	@POST
	@Path("/selectData")
	@Produces(MediaType.APPLICATION_JSON)
	public Response selectData(@FormParam("clazz") String clazz,@FormParam("jsonObject") String jsonObject, @FormParam("accion") String accion) {
		log.info("requested class: "+clazz+" JsonObject: "+jsonObject + " accion: "+ accion);
		String result = ""; 
		Gson g = new GsonBuilder().serializeSpecialFloatingPointValues().create();
		try {
			Class<?> c = null;
			Object o = null;
			if(clazz != null || jsonObject != null) {
				c = Class.forName(clazz);
				o = new Gson().fromJson(jsonObject, c);						
				if(o == null){
					throw new Exception("Error al tratar de hacer el cast del objeto");
				}
			}
			
			Response r = null; 
			
			////aqui se indica que metodo debo usar
			if(accion == null || "".equals(accion)){
				if(o instanceof SAR){
					SAR_CDI_DAO dao = new SAR_CDI_DAO();
					SarBO sar = new SarBO();
					SAR tmp = (SAR) o;
					sar.setEtdReal(tmp.getEtdReal());
					ArrayList<SarBO> lstSars = dao.selectSar(sar,false);
					
					result = g.toJson(lstSars);
					r = buildOKResponse(result);				
				} else {
					r = buildOKResponse("OK, clase no definida");
				}
			}else{
//				///Si no se manda objeto entonces se manda un tipo de accion, este define el metodo
				if("recargaMapas".equals(accion)){
					boolean resp = FuncionesComunesPLI.recargaMapas();
					result = g.toJson(resp);
					r = buildOKResponse(result);
				} else {
					r = buildOKResponse("OK, Accion no definida");
				}
			}
			
			return r;
		} catch (ClassNotFoundException e) {
			log.error("[dameImportacionesNotificaciones] Error con datos: "+ result+"--> "+ e.getMessage());
			Response r = buildErrorResponse(e.getMessage());
			return r;
		}catch (Exception e) {
			log.error("[dameImportacionesNotificaciones] Error con datos: "+ result+"--> "+ e.getMessage());
			Response r = buildErrorResponse(e.getMessage());
			return r;
		}
		
	}
	
}
