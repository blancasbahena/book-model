package com.srm.pli.services;

import static com.srm.pli.helper.CorreoHelper.MAIL_FR_HK_MATRIX;
import static com.srm.pli.helper.CorreoHelper.SALUDO_TODOS;

import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.srm.pli.format.email.CorreoFormatoGeneral;
import com.srm.pli.helper.CorreoHelper;
import com.srm.pli.utils.FuncionesComunesPLI;
import com.truper.bpm.enums.StatusControlMatricesEnum;
import com.truper.businessEntity.BeanAuditoriaSinMatrizDetalleProveedor;
import com.truper.utils.date.EnumFechas;
import com.truper.utils.date.UtilsFechas;

public class CorreoMatriz {

	private static final CorreoMatriz instance = new CorreoMatriz();

	private CorreoMatriz() {
	}

	public static CorreoMatriz getInstance() {
		return instance;
	}

	public void enviaRechazoMatriz(String po, Date fechaInsert, String comentario, StatusControlMatricesEnum enum_estatus) {
		List<BeanAuditoriaSinMatrizDetalleProveedor> detallePo;
		detallePo = AuditoriaService.getInstance().getDetalleOrdenConMatriz(fechaInsert, po);
		
		Date minETD = null;
		String proveedor = null;
		Set<String> celulas = new HashSet<>();
		for (BeanAuditoriaSinMatrizDetalleProveedor b : detallePo) {
			if (b.getEtd() != null && (minETD == null || b.getEtd().before(minETD))) {
				minETD = b.getEtd();
				proveedor = b.getProveedor();
			}
			celulas.add(b.getBuClave());
		}
		String proveedor_full = FuncionesComunesPLI.getProveedorFullName(proveedor);
		
		StringBuilder parrafo = new StringBuilder("The PI ");
		parrafo.append(po).append(" from Supplier ");
		parrafo.append(proveedor_full).append(" with shipment date ");
		parrafo.append(UtilsFechas.setConvierteFechaToString(minETD, EnumFechas.FORMATO_YYYY_MM_DD));
		parrafo.append(", is rejected by the Matrix Area due to (");
		parrafo.append(enum_estatus.getDescripcion()).append(") : ").append(comentario);
		parrafo.append("<br><br>Please review immediately and let us know the next step.");
		
		String preview = "Rejected PO";
		String table = CorreoMatrizFormato.getInstance().buildTableDetalleOrden(detallePo);
		String formatoHTML = CorreoFormatoGeneral.getInstance().getFormatoFR(SALUDO_TODOS, parrafo.toString(), preview, null, table);
		
		StringBuilder subject = new StringBuilder("Rejected Matrix Area PI ").append(po);
		Map<String, Set<String>> correos;
		correos = CorreoHelper.getInstance().buildCorreosRechazoMatriz(celulas);
		String sender = CorreoHelper.getInstance().getEmail(MAIL_FR_HK_MATRIX);
		CorreoServices.getInstance().enviaCorreo(formatoHTML, subject.toString(), sender, correos);
	}
	
	public void enviaLiberacionMatriz(String po, Date fechaInsert, StatusControlMatricesEnum enum_estatus) {
		List<BeanAuditoriaSinMatrizDetalleProveedor> detallePo;
		detallePo = AuditoriaService.getInstance().getDetalleOrdenConMatriz(fechaInsert, po);
		
		Date minETD = null;
		String proveedor = null;
		Set<String> celulas = new HashSet<>();
		for (BeanAuditoriaSinMatrizDetalleProveedor b : detallePo) {
			if (b.getEtd() != null && (minETD == null || b.getEtd().before(minETD))) {
				minETD = b.getEtd();
				proveedor = b.getProveedor();
			}
			celulas.add(b.getBuClave());
		}
		String proveedor_full = FuncionesComunesPLI.getProveedorFullName(proveedor);
		
		StringBuilder parrafo = new StringBuilder("The PI ");
		parrafo.append(po).append(" from Supplier ");
		parrafo.append(proveedor_full).append(" with shipment date ");
		parrafo.append(UtilsFechas.setConvierteFechaToString(minETD, EnumFechas.FORMATO_YYYY_MM_DD));
		parrafo.append(", is released by the Matrix area (").append(enum_estatus.getDescripcion()).append(").");
		parrafo.append("<br><br>Please take the next steps to forward PI to supplier.");
		
		String preview = "Released PO";
		String table = CorreoMatrizFormato.getInstance().buildTableDetalleOrden(detallePo);
		String formatoHTML = CorreoFormatoGeneral.getInstance().getFormatoFR(SALUDO_TODOS, parrafo.toString(), preview, null, table);
		
		StringBuilder subject = new StringBuilder("Released the Matrix Area PI ").append(po);
		Map<String, Set<String>> correos = CorreoHelper.getInstance().buildCorreosRechazoMatriz(celulas);
		String sender = CorreoHelper.getInstance().getEmail(MAIL_FR_HK_MATRIX);
		CorreoServices.getInstance().enviaCorreo(formatoHTML, subject.toString(), sender, correos);
	}
}
