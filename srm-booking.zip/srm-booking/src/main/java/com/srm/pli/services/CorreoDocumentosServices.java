package com.srm.pli.services;

import static com.srm.pli.helper.CorreoHelper.LOGIN_FR;
import static com.srm.pli.helper.CorreoHelper.MAIL_FR_HK_DOCUMENTS_REJECT;
import static com.srm.pli.helper.CorreoHelper.MAIL_FR_HK_DOCUMENTS_REQUEST;
import static com.srm.pli.helper.CorreoHelper.PRIORIDAD_URGENTE;
import static com.srm.pli.helper.CorreoHelper.SALUDO_PROVEEDOR;
import static com.srm.pli.helper.CorreoHelper.SALUDO_TODOS;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang.StringEscapeUtils;

import com.srm.pli.bo.SarBO;
import com.srm.pli.dao.DocumentosSdiDao;
import com.srm.pli.dao.sql.DocumentosSdiSql.DocumentosSdiDaoEnum;
import com.srm.pli.documents.BloqueoDocumentosService;
import com.srm.pli.format.email.CorreoFormatoDocumentos;
import com.srm.pli.format.email.CorreoFormatoGeneral;
import com.srm.pli.helper.CorreoHelper;
import com.srm.pli.helper.SarDetailHelper;
import com.srm.pli.supplier.documents.helper.DocumentosProveedorHelper;
import com.srm.pli.utils.CatalogosUtils;
import com.srm.pli.utils.FuncionesComunesPLI;
import com.srm.pli.utils.MailUtils;
import com.srm.pli.utils.TelServiceClient;
import com.srm.pli.utils.UnidadNegocioUtils;
import com.truper.businessEntity.BeanDocumentoAnalisis;
import com.truper.businessEntity.ImportacionesProveedoresBean;
import com.truper.businessEntity.UserBean;
import com.truper.utils.date.EnumFechas;
import com.truper.utils.date.UtilsFechas;
import com.truper.utils.string.UtilsString;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class CorreoDocumentosServices {

	private static CorreoDocumentosServices instance = null;
	private static DocumentosProveedorHelper documentosProveedorHelper = null;
	private static BloqueoDocumentosService bloqueoDocumentosService = null;

	private CorreoDocumentosServices() {
		documentosProveedorHelper = DocumentosProveedorHelper.getInstance();
		bloqueoDocumentosService = BloqueoDocumentosService.getInstance();
	}

	public static CorreoDocumentosServices getInstance() {
		if (instance == null)
			instance = new CorreoDocumentosServices();
		return instance;
	}

	public void enviaAvisosCorrecciones() {
		try {
			enviaRecordatorioCertificadoDeCalidad();
			procesaCorreosSegundoAviso();
			procesaCorreosTercerAviso();
			procesaCorreosCorrecionAvisoDesdeDosDias();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void procesaCorreoPrimerAviso(String booking, String proveedor) {
		if (!UtilsString.isStringsValidas(booking, proveedor)) {
			return;
		}
		boolean isModuleSupplier = CatalogosUtils.getInstance().isProveedorModulo(proveedor);
		if (!isModuleSupplier) {
			return;
		}
		List<BeanDocumentoAnalisis> documentos;
		documentos = DocumentosSdiDao.getInstance().selectDocumentoEnAnalisis(booking, proveedor);

		boolean containsFoliosBloqueados = containsFoliosBloqueados(documentos);
		if (containsFoliosBloqueados)
			return;
		enviaCorreoSolicitudDocumentosPrimerAviso(booking, documentos);
	}

	private boolean containsFoliosBloqueados(List<BeanDocumentoAnalisis> documentos) {
		Set<Integer> folios = documentosProveedorHelper.getFolios(documentos);
		boolean containsFoliosBloqueados = bloqueoDocumentosService.containsFoliosBloqueados(folios);
		return containsFoliosBloqueados;
	}

	@Deprecated
	public void procesaCorreosPrimerAviso() {
		DocumentosSdiDaoEnum accion = DocumentosSdiDaoEnum.SOLICITUD_DOC_AVISO_0_DIAS;
		Map<String, List<BeanDocumentoAnalisis>> avisos = DocumentosSdiDao.getInstance()
				.selectDocumentoEnAnalisis(accion);
		for (String booking : avisos.keySet()) {
			List<BeanDocumentoAnalisis> folios = avisos.get(booking);
			enviaCorreoSolicitudDocumentosPrimerAviso(booking, folios);
		}
	}

	public void procesaCorreosSegundoAviso() {
		DocumentosSdiDaoEnum accion = DocumentosSdiDaoEnum.SOLICITUD_DOC_AVISO_3_DIAS;
		Map<String, List<BeanDocumentoAnalisis>> avisos = DocumentosSdiDao.getInstance()
				.selectDocumentoEnAnalisis(accion);
		for (String booking : avisos.keySet()) {
			List<BeanDocumentoAnalisis> folios = avisos.get(booking);
			boolean containsFoliosBloqueados = containsFoliosBloqueados(folios);
			if(containsFoliosBloqueados)
				continue;
			enviaCorreoSolicitudDocumentosSegundoAviso(booking, folios);
		}
	}

	public void procesaCorreosTercerAviso() {
		DocumentosSdiDaoEnum accion = DocumentosSdiDaoEnum.SOLICITUD_DOC_AVISO_0_DIAS;
		Map<String, List<BeanDocumentoAnalisis>> avisos = DocumentosSdiDao.getInstance()
				.selectDocumentoEnAnalisis(accion);
		for (String booking : avisos.keySet()) {
			List<BeanDocumentoAnalisis> folios = avisos.get(booking);
			boolean containsFoliosBloqueados = containsFoliosBloqueados(folios);
			if(containsFoliosBloqueados)
				continue;
			enviaCorreoSolicitudDocumentosTercerAviso(booking, folios);
		}
	}

	@Deprecated
	public void procesaCorreosCorrecionPrimerAviso(String booking, String proveedor) {
		List<BeanDocumentoAnalisis> folios = DocumentosSdiDao.getInstance().selectDocumentoEnAnalisisCorrecion(booking,
				proveedor);
		enviaCorreoSolicitudDocumentosCorrecionPrimerAviso(booking, folios);
	}

	@Deprecated
	public void procesaCorreosCorrecionPrimerAviso() {
		DocumentosSdiDaoEnum accion = DocumentosSdiDaoEnum.SOLICITUD_DOC_CORRECCION_AVISO_0_DIAS;
		Map<String, List<BeanDocumentoAnalisis>> correciones;
		correciones = DocumentosSdiDao.getInstance().selectDocumentoEnAnalisisCorrecionMayorEnDias(accion);
		for (String booking : correciones.keySet()) {
			List<BeanDocumentoAnalisis> folios = correciones.get(booking);
			enviaCorreoSolicitudDocumentosCorrecionPrimerAviso(booking, folios);
		}
	}

	public void procesaCorreosCorrecionAvisoDesdeDosDias() {
		DocumentosSdiDaoEnum accion = DocumentosSdiDaoEnum.SOLICITUD_DOC_CORRECCION_AVISO_2_DIAS;
		Map<String, List<BeanDocumentoAnalisis>> correciones = DocumentosSdiDao.getInstance()
				.selectDocumentoEnAnalisisCorrecionMayorEnDias(accion);
		for (String booking : correciones.keySet()) {
			List<BeanDocumentoAnalisis> folios = correciones.get(booking);
			boolean containsFoliosBloqueados = containsFoliosBloqueados(folios);
			if(containsFoliosBloqueados)
				continue;
			enviaCorreoSolicitudDocumentosCorrecionSegundoAviso(booking, folios);
		}
	}

	/**
	 * @deprecated Se deja de usar ya que se pidio que en lugar de mandar a los 4
	 *             dias sea a partir de los 2 dias cada 24 hrs, revisar metodo
	 *             {@link #procesaCorreosCorrecionAvisoDesdeDosDias()}
	 */
	public void procesaCorreosCorrecionTercerAviso() {
		DocumentosSdiDaoEnum accion = DocumentosSdiDaoEnum.SOLICITUD_DOC_CORRECCION_AVISO_4_DIAS;
		Map<String, List<BeanDocumentoAnalisis>> correciones = DocumentosSdiDao.getInstance()
				.selectDocumentoEnAnalisisCorrecionMayorEnDias(accion);
		for (String booking : correciones.keySet()) {
			List<BeanDocumentoAnalisis> folios = correciones.get(booking);
			enviaCorreoSolicitudDocumentosCorrecionTercerAviso(booking, folios);
		}
	}

	public String getFormatoSolicitudDocumentosPrimerAviso() {
		String parrafo = "Please remember that you have to upload the full set of documents (invoice, packing list, BL and container pictures) for revision process the latest 5 days after the shipment leaves port of origin.";
		String preview = "Reminder to upload documents";
		String formatoHTML = CorreoFormatoDocumentos.getInstance().getSolicitudDocumentos(SALUDO_PROVEEDOR, parrafo,
				TelServiceClient.baseUri, LOGIN_FR, preview, null);
		return formatoHTML;
	}

	public String getFormatoSolicitudDocumentosSegundoAviso() {
		String parrafo = "Please remember that you have to upload the full set of documents (invoice, packing list, BL and container pictures) for revision process at the latest 5 days after the shipment leaves the port of origin, to date, we have yet to receive your documents, please upload it ASAP";
		String preview = "2nd Reminder to upload documents";
		String formatoHTML = CorreoFormatoDocumentos.getInstance().getSolicitudDocumentos(SALUDO_PROVEEDOR, parrafo,
				TelServiceClient.baseUri, LOGIN_FR, preview, CorreoHelper.PRIORIDAD_INTERMEDIA);
		return formatoHTML;
	}

	public String getFormatoSolicitudDocumentosTercerAviso() {
		StringBuilder parrafo = new StringBuilder();
		parrafo.append("It is urgent that you upload a copy of the shipping documents in ");
		parrafo.append("Fung & Rui system for us to start our revision process.");
		parrafo.append("<br>You are late in this process and your delay may cause delays on our ");
		parrafo.append("importation process when the shipment arrive at the Port of destination.");
		parrafo.append("<br>Please be informed that any demurrage charges that may take place due to the late ");
		parrafo.append("uploading of documents for our review and release, will be your responsibility.");
		String preview = "3rd Reminder to upload documents";
		String formatoHTML = CorreoFormatoDocumentos.getInstance().getSolicitudDocumentos(SALUDO_PROVEEDOR,
				parrafo.toString(), TelServiceClient.baseUri, LOGIN_FR, preview, PRIORIDAD_URGENTE);
		return formatoHTML;
	}

	public String getFormatoSolicitudDocumentosCorrecion(BeanDocumentoAnalisis bean, String preview, String prioridad) {
		String parrafo = "Your documentation contains errors that must be corrected.<br><br>Please go to your view and do the corrections we are requesting.";
		String comentariosSdi = bean.getComentariosSdi();
		if (bean != null && UtilsString.isStringValida(comentariosSdi)) {
			parrafo += "<br><br>SDI comments:<br><br>" + comentariosSdi;
		}
		String formatoHTML = CorreoFormatoDocumentos.getInstance().getSolicitudDocumentos(SALUDO_PROVEEDOR, parrafo,
				TelServiceClient.baseUri, LOGIN_FR, preview, prioridad);
		return formatoHTML;
	}

	public boolean enviaCorreoSolicitudDocumentosPrimerAviso(String booking, List<BeanDocumentoAnalisis> folios) {
		BeanDocumentoAnalisis bean = folios.get(0);
		Set<String> correos_set = CorreoServices.getInstance().getCorreosProveedor(bean.getProveedor());
		String[] correos_to = CorreoHelper.getInstance().getArrayFromSet(correos_set);
		String texto = "Please upload copy of shipping documents for revision";
		String subject = buildSubject(booking, folios, texto);
		String html = getFormatoSolicitudDocumentosPrimerAviso();
		String sender = CorreoHelper.getInstance().getEmail(MAIL_FR_HK_DOCUMENTS_REQUEST);
		MailUtils.enviaCorreo(correos_to, null, subject, sender, html, null);
		return true;
	}

	public boolean enviaCorreoSolicitudDocumentosSegundoAviso(String booking, List<BeanDocumentoAnalisis> folios) {
		BeanDocumentoAnalisis bean = folios.get(0);
		String proveedor = bean.getProveedor();
		DocumentosSdiDaoEnum accion = DocumentosSdiDaoEnum.SOLICITUD_DOC_AVISO_3_DIAS;

		Set<Integer> folios_set = SarDetailHelper.getFolios(folios);
		Set<String> celulas = UnidadNegocioUtils.getInstance().getCelulas(folios_set);
		Map<String, Set<String>> correos = CorreoHelper.getInstance().buildCorreosDocumentosSolicitud(accion, proveedor,
				celulas);
		String[] correos_to = CorreoHelper.getInstance().getCorreosArrayFrom(correos, CorreoHelper.MAIL_TO);
		String[] correos_cc = CorreoHelper.getInstance().getCorreosArrayFrom(correos, CorreoHelper.MAIL_CC);

		String texto = "2nd Reminder Missing copy of shipping documents to be uploaded for our revision";
		String subject = buildSubject(booking, folios, texto);
		String html = getFormatoSolicitudDocumentosSegundoAviso();
		String sender = CorreoHelper.getInstance().getEmail(MAIL_FR_HK_DOCUMENTS_REQUEST);
		MailUtils.enviaCorreo(correos_to, correos_cc, subject, sender, html, null);
		return true;
	}

	public boolean enviaCorreoSolicitudDocumentosTercerAviso(String booking, List<BeanDocumentoAnalisis> folios) {
		BeanDocumentoAnalisis bean = folios.get(0);
		String proveedor = bean.getProveedor();
		DocumentosSdiDaoEnum accion = DocumentosSdiDaoEnum.SOLICITUD_DOC_AVISO_5_DIAS;

		Set<Integer> folios_set = SarDetailHelper.getFolios(folios);
		Set<String> celulas = UnidadNegocioUtils.getInstance().getCelulas(folios_set);
		Map<String, Set<String>> correos = CorreoHelper.getInstance().buildCorreosDocumentosSolicitud(accion, proveedor,
				celulas);
		String[] correos_to = CorreoHelper.getInstance().getCorreosArrayFrom(correos, CorreoHelper.MAIL_TO);
		String[] correos_cc = CorreoHelper.getInstance().getCorreosArrayFrom(correos, CorreoHelper.MAIL_CC);

		String texto = "Urgent 3rd reminder!! Missing documents uploaded for our revision";
		String subject = buildSubject(booking, folios, texto);
		String html = getFormatoSolicitudDocumentosTercerAviso();
		String sender = CorreoHelper.getInstance().getEmail(MAIL_FR_HK_DOCUMENTS_REQUEST);
		MailUtils.enviaCorreo(correos_to, correos_cc, subject, sender, html, null);
		return true;
	}

	public boolean enviaCorreoSolicitudDocumentosCorrecionPrimerAviso(String booking,
			List<BeanDocumentoAnalisis> folios) {
		DocumentosSdiDaoEnum accion = DocumentosSdiDaoEnum.SOLICITUD_DOC_CORRECCION_AVISO_0_DIAS;
		BeanDocumentoAnalisis bean = folios.get(0);
		String proveedor = bean.getProveedor();

		Map<String, Set<String>> correos = CorreoHelper.getInstance().buildCorreosDocumentosSolicitudCorreccion(accion,
				proveedor, null);
		String[] correos_to = CorreoHelper.getInstance().getCorreosArrayFrom(correos, CorreoHelper.MAIL_TO);
		String[] correos_cc = CorreoHelper.getInstance().getCorreosArrayFrom(correos, CorreoHelper.MAIL_CC);
		String texto = "Shipping Documents Corrections Request";
		String subject = buildSubject(booking, folios, texto);
		String html = getFormatoSolicitudDocumentosCorrecion(bean, texto, null);
		String sender = CorreoHelper.getInstance().getEmail(MAIL_FR_HK_DOCUMENTS_REQUEST);
		MailUtils.enviaCorreo(correos_to, correos_cc, subject, sender, html, null);
		return true;
	}

	public boolean enviaCorreoSolicitudDocumentosCorrecionSegundoAviso(String booking,
			List<BeanDocumentoAnalisis> folios) {
		DocumentosSdiDaoEnum accion = DocumentosSdiDaoEnum.SOLICITUD_DOC_CORRECCION_AVISO_2_DIAS;
		BeanDocumentoAnalisis bean = folios.get(0);
		String proveedor = bean.getProveedor();

		Set<Integer> folios_set = SarDetailHelper.getFolios(folios);
		Set<String> celulas = UnidadNegocioUtils.getInstance().getCelulas(folios_set);

		Map<String, Set<String>> correos = CorreoHelper.getInstance().buildCorreosDocumentosSolicitudCorreccion(accion,
				proveedor, celulas);
		String[] correos_to = CorreoHelper.getInstance().getCorreosArrayFrom(correos, CorreoHelper.MAIL_TO);
		String[] correos_cc = CorreoHelper.getInstance().getCorreosArrayFrom(correos, CorreoHelper.MAIL_CC);
		String texto = "REMINDER Shipping documents corrections Request";
		String subject = buildSubject(booking, folios, texto);
		String html = getFormatoSolicitudDocumentosCorrecion(bean, texto, CorreoHelper.PRIORIDAD_INTERMEDIA);
		String sender = CorreoHelper.getInstance().getEmail(MAIL_FR_HK_DOCUMENTS_REQUEST);
		MailUtils.enviaCorreo(correos_to, correos_cc, subject, sender, html, null);
		return true;
	}

	public boolean enviaCorreoSolicitudDocumentosCorrecionTercerAviso(String booking,
			List<BeanDocumentoAnalisis> folios) {
		DocumentosSdiDaoEnum accion = DocumentosSdiDaoEnum.SOLICITUD_DOC_CORRECCION_AVISO_4_DIAS;
		BeanDocumentoAnalisis bean = folios.get(0);
		String proveedor = bean.getProveedor();

		Set<Integer> folios_set = SarDetailHelper.getFolios(folios);
		Set<String> celulas = UnidadNegocioUtils.getInstance().getCelulas(folios_set);

		Map<String, Set<String>> correos = CorreoHelper.getInstance().buildCorreosDocumentosSolicitudCorreccion(accion,
				proveedor, celulas);
		String[] correos_to = CorreoHelper.getInstance().getCorreosArrayFrom(correos, CorreoHelper.MAIL_TO);
		String[] correos_cc = CorreoHelper.getInstance().getCorreosArrayFrom(correos, CorreoHelper.MAIL_CC);
		String texto = "3rd REMINDER Shipping Documents Corrections Request";
		String subject = buildSubject(booking, folios, texto);
		String html = getFormatoSolicitudDocumentosCorrecion(bean, texto, PRIORIDAD_URGENTE);
		String sender = CorreoHelper.getInstance().getEmail(MAIL_FR_HK_DOCUMENTS_REQUEST);
		MailUtils.enviaCorreo(correos_to, correos_cc, subject, sender, html, null);
		return true;
	}

	public boolean enviaRecordatorioCertificadoDeCalidad() {
		Map<String, List<BeanDocumentoAnalisis>> avisos = DocumentosSdiDao.getInstance()
				.selectFoliosConfirmacionFinalMayor1DiaSinEnvioDocumentos();
		StringBuilder parrafo = new StringBuilder();
		parrafo.append("Please remember that you have to upload the full set of documents ");
		parrafo.append("(invoice, packing list, BL and container pictures) for revision process the latest ");
		parrafo.append("5 days after the shipment leaves port of origin.");
		parrafo.append("<b><font color =\"#f52b09\" style=\"margin-top: 1em;display: inline-flex;\">");
		parrafo.append("Make sure to upload the quality certificate of goods in ");
		parrafo.append("\"Additional shipping documents\" section.");
		parrafo.append("</font></b>");
		String html = CorreoFormatoGeneral.getInstance().getFormatoFR(SALUDO_PROVEEDOR, parrafo.toString(),
				"The quality certificate of goods is required");
		for (String booking : avisos.keySet()) {
			List<BeanDocumentoAnalisis> folios = avisos.get(booking);
			boolean containsFoliosBloqueados = containsFoliosBloqueados(folios);
			if(containsFoliosBloqueados)
				continue;
			BeanDocumentoAnalisis i = folios.get(0);
			if (i == null || !UtilsString.isStringValida(i.getProveedor()))
				continue;
			try {
				String subject = buildSubject(booking, folios, "QUALITY CERTIFICATE REQUIRED");
				Set<String> correos_aux = CorreoServices.getInstance().getCorreosProveedor(i.getProveedor());
				String[] correos = CorreoHelper.getInstance().getArrayFromSet(correos_aux);
				String sender = CorreoHelper.getInstance().getEmail(MAIL_FR_HK_DOCUMENTS_REQUEST);
				MailUtils.enviaCorreo(correos, null, subject, sender, html, null);
			} catch (Exception e) {
				log.error("Error al enviar correo de certificados para el bean: " + i.toString(), e);
				e.printStackTrace();
			}
		}
		return true;
	}

	private String buildSubject(String booking, List<BeanDocumentoAnalisis> folios, String texto) {
		BeanDocumentoAnalisis bean = folios.get(0);
		String numeroProveedor = bean.getProveedor();
		numeroProveedor = numeroProveedor.trim();
		ImportacionesProveedoresBean proveedorBean = FuncionesComunesPLI.getProveedor(numeroProveedor);
		String nombreProveedor = proveedorBean.getNombreProveedor();

		if (!UtilsString.isStringsValidas(nombreProveedor, booking))
			return null;

		int numero_folios = folios.size();
		StringBuilder folio = new StringBuilder();
		if (numero_folios > 1) {
			folio.append(" Folios: ");
		} else {
			folio.append(" Folio: ");
		}
		for (int i = 0; i < numero_folios; i++) {
			BeanDocumentoAnalisis f = folios.get(i);
			if (i > 0) {
				folio.append(", ");
			}
			folio.append(f.getFolio());
		}
		nombreProveedor = nombreProveedor.trim();
		booking = booking.trim();

		Date eta = UtilsFechas.setConvierteFechaIntToDate(bean.getEta());
		StringBuilder subject = new StringBuilder();
		subject.append(texto);
		subject.append(" Booking#").append(booking);
		subject.append(" - ").append(nombreProveedor);
		subject.append(" ETA: ")
				.append(UtilsFechas.setConvierteFechaToString(eta, EnumFechas.FORMATO_YYYY_MM_DD_SLASH));
		subject.append(folio);
		return subject.toString();
	}

	public void enviaSolicitudRevokeFinalConfirmation(Set<Integer> sars) {
		Set<String> celulas = UnidadNegocioUtils.getInstance().getCelulas(sars);
		Map<String, Set<String>> correos = CorreoHelper.getInstance().buildCorreosSolicitudRevokeFinalConfirmation(sars,
				celulas);
		String[] correos_to = CorreoHelper.getInstance().getCorreosArrayFrom(correos, CorreoHelper.MAIL_TO);
		String[] correos_cc = CorreoHelper.getInstance().getCorreosArrayFrom(correos, CorreoHelper.MAIL_CC);
		String sarsString = sars.toString().replace("[", "").replace("]", "");
		String parrafo = UtilsString.append("Please help us revoke the final confirmation of SAR ", sarsString);
		String subject = UtilsString.append("Revoke Final Confirmation SARs: ", sarsString);
		String html = CorreoFormatoGeneral.getInstance().getFormatoFR(SALUDO_TODOS, parrafo, subject,
				PRIORIDAD_URGENTE);
		String sender = CorreoHelper.getInstance().getEmail(MAIL_FR_HK_DOCUMENTS_REJECT);
		MailUtils.enviaCorreo(correos_to, correos_cc, subject, sender, html, null);
	}
}
