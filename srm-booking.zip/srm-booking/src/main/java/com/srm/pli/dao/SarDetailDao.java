package com.srm.pli.dao;

import static com.srm.pli.dao.sql.SarDetailDaoSql.SELECT_SAR_DETAIL_MATERIAL_CENTRO;
import static com.srm.pli.dao.sql.SarDetailDaoSql.SELECT_SAR_DETAIL_PRICES;
import static com.srm.pli.dao.sql.SarDetailDaoSql.SELECT_SAR_DETAIL_TOP_1_MATERIAL_CENTRO;
import static com.srm.pli.dao.sql.SarDetailDaoSql.UPDATE_SAR_DETAIL_PRICES;
import static com.srm.pli.dao.sql.SarDetailDaoSql.SELECT_SAR_DETAIL_MATERIAL; 
import static com.srm.pli.dao.sql.SarDetailDaoSql.UPDATE_SAR_DETAIL_ITEMS_DIRECTOS;
import static com.srm.pli.dao.sql.SarDetailDaoSql.BORRAR_SAR_DETAIL_ITEMS_DIRECTOS;
import static com.srm.pli.dao.sql.SarDetailDaoSql.OBTENER_ITEMS_SELECCIONADOS;


import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.srm.fungandrui.imports.dto.TuplaFolioMaterial;
import com.srm.fungandrui.itemsdirectos.dto.ItemsSeleccionados;
import com.srm.pli.db.ConexionDB;
import com.truper.businessEntity.BeanMaterialCentro;
import com.truper.businessEntity.CdiManagersPlanners;
import com.truper.businessEntity.PricePosition;
import com.truper.businessEntity.SmallProduct;
import com.truper.businessEntity.UpdateDataDetail;
import com.truper.businessEntity.UpdatePricesBean;
import com.truper.utils.sql.UtilsSQL;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class SarDetailDao {

	private static final SarDetailDao instance = new SarDetailDao();

	private SarDetailDao() {
	}

	public static SarDetailDao getInstance() {
		return instance;
	}

	public Map<String, List<PricePosition>> selectSarDetailPrices(Integer folio) {
		Map<String, List<PricePosition>> result = null;
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();
			try (PreparedStatement ps = con.prepareStatement(SELECT_SAR_DETAIL_PRICES)) {
				ps.setInt(1, folio);
				try (ResultSet rs = ps.executeQuery()) {
					result = new HashMap<>();
					while (rs.next()) {
						String po = rs.getString("po");
						Integer position = rs.getInt("posicion");
						Integer material = rs.getInt("material");
						BigDecimal unitPrice = rs.getBigDecimal("precioUnitario");
						if (po == null) {
							continue;
						}
						po = po.trim();
						PricePosition p = new PricePosition();
						p.setPo(po);
						p.setPosition(position);
						p.setMaterial(material);
						p.setUnitPrice(unitPrice);

						List<PricePosition> aux = null;
						if (result.containsKey(po)) {
							aux = result.get(po);
						} else {
							aux = new ArrayList<>();
							result.put(po, aux);
						}
						aux.add(p);
					}
				}
			}
		} catch (SQLException sqle) {
			sqle.printStackTrace();
			log.error("Error",sqle);
			ConexionDB.renovar(con);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("Error",e);
		} finally {
			ConexionDB.devolver(con);
		}
		return result;
	}

	/**
	 * 
	 * @param folio
	 * @return
	 */
	public Map<String, List<UpdateDataDetail>> selectSarDetailUpdatePrices(Integer folio) { 
		Map<String, List<UpdateDataDetail>> result = null;
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();
			StringBuilder sql = new StringBuilder();			
			sql.append("SELECT folio");
			sql.append("      ,po");
			sql.append("      ,posicion");
			sql.append("      ,material");
			sql.append("      ,precioUnitario");
			sql.append("      ,moneda");
			sql.append("      ,condicionPago ");
			sql.append(" FROM cdiSARDetalle");
			sql.append(" WHERE folio = ?");
			
			
			try (PreparedStatement ps = con.prepareStatement(sql.toString())) {
				ps.setInt(1, folio);
				try (ResultSet rs = ps.executeQuery()) {
					result = new HashMap<>();
					while (rs.next()) {
						String po = rs.getString("po");
						Integer position = rs.getInt("posicion");
						Integer material = rs.getInt("material");
						BigDecimal unitPrice = rs.getBigDecimal("precioUnitario");
						String moneda = rs.getString("moneda");
						String condPago = rs.getString("condicionPago");
						if (po == null) {
							continue;
						}
						
						po = po.trim();
						UpdateDataDetail p = new UpdateDataDetail();
						p.setPo(po);
						p.setPosition(position);
						p.setMaterial(material);
						p.setUnitPrice(unitPrice);
						p.setFolio(folio);
						p.setMoneda(moneda);
						p.setCondPago(condPago);

						List<UpdateDataDetail> aux = null;
						if (result.containsKey(po)) {
							aux = result.get(po);
						} else {
							aux = new ArrayList<>();
							result.put(po, aux);
						}
						aux.add(p);
					}
				}
			}
		} catch (SQLException sqle) {
			sqle.printStackTrace();
			log.error("Error",sqle);
			ConexionDB.renovar(con);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("Error",e);
		} finally {
			ConexionDB.devolver(con);
		}
		return result;
	}
	
	public SmallProduct selectMaterialCentroFirst(Integer folioSAR) {
		if (folioSAR == null)
			return null;
		SmallProduct obj = null;
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();
			try (PreparedStatement pst = con.prepareStatement(SELECT_SAR_DETAIL_TOP_1_MATERIAL_CENTRO)) {
				pst.setInt(1, folioSAR);
				try (ResultSet rs = pst.executeQuery()) {
					if (rs.next()) {
						Integer material = rs.getInt("material");
						String centro = rs.getString("centro");
						if (material == null || centro == null)
							return null;
						centro = centro.trim();
						obj = new SmallProduct(material, centro);
					}
				}
			}
		} catch (SQLException sqle) {
			sqle.printStackTrace();
			log.error("Folio: " + folioSAR, sqle);
			ConexionDB.renovar(con);
		} catch (Exception e) {
			log.error("Folio: " + folioSAR, e);
			e.printStackTrace();
		} finally {
			ConexionDB.devolver(con);
		}
		return obj;
	}
	
	public Set<BeanMaterialCentro> selectMaterialCentro(Set<Integer> folios) {
		if (folios == null)
			return null;
		Set<BeanMaterialCentro> respuesta = null;
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();
			String in = UtilsSQL.convierteToIN(folios);
			String query = SELECT_SAR_DETAIL_MATERIAL_CENTRO.replace("?", in);
			try (PreparedStatement pst = con.prepareStatement(query)) {
				try (ResultSet rs = pst.executeQuery()) {
					respuesta = new HashSet<>();
					BeanMaterialCentro obj = null;
					if (rs.next()) {
						Integer material = rs.getInt("material");
						String centro = rs.getString("centro");
						if (material == null || centro == null)
							return null;
						centro = centro.trim();
						obj = new BeanMaterialCentro();
						obj.setMaterial(material);
						obj.setCentro(centro);
						respuesta.add(obj);
					}
				}
			}
		} catch (SQLException sqle) {
			sqle.printStackTrace();
			log.error("Folios: " + folios, sqle);
			ConexionDB.renovar(con);
		} catch (Exception e) {
			log.error("Folios: " + folios, e);
			e.printStackTrace();
		} finally {
			ConexionDB.devolver(con);
		}
		return respuesta;
	}
	
	public Set<TuplaFolioMaterial> getMaterialbyFolio(Set<String> folios) {
		if (folios == null)
			return null;
		Set<TuplaFolioMaterial> respuesta = null;
		Connection con = null;
		try {
			con = ConexionDB.dameConexion();
			String in = UtilsSQL.convierteToIN(folios);
			String query = SELECT_SAR_DETAIL_MATERIAL.replace("?", in);
			try (PreparedStatement pst = con.prepareStatement(query)) {
				try (ResultSet rs = pst.executeQuery()) {
					respuesta = new HashSet<>();
					while (rs.next()) {
						TuplaFolioMaterial obj = new TuplaFolioMaterial();
						Integer material = rs.getInt("material");
						String  folio = rs.getString("folio");
						obj.setMaterial(material);
						obj.setFolio(folio);
						respuesta.add(obj);
					}
				}
			}
		} catch (SQLException sqle) {
			sqle.printStackTrace();
			log.error("Folios: " + folios, sqle);
			ConexionDB.renovar(con);
		} catch (Exception e) {
			log.error("Folios: " + folios, e);
			e.printStackTrace();
		} finally {
			ConexionDB.devolver(con);
		}
		return respuesta;
	}

	public int updateSarDetailPrices(Integer folio, List<PricePosition> positions) {
		int num_update = 0;
		Connection con = null;
		Boolean autoCommit = null;
		try {
			con = ConexionDB.dameConexion();
			try (PreparedStatement ps = con.prepareStatement(UPDATE_SAR_DETAIL_PRICES);) {
				autoCommit = con.getAutoCommit();
				con.setAutoCommit(false);
				int c = 0;
				for (PricePosition p : positions) {
					int i = 1;
					ps.setBigDecimal(i, p.getUnitPrice());
					ps.setInt(++i, folio);
					ps.setString(++i, p.getPo());
					ps.setInt(++i, p.getPosition());
					ps.setInt(++i, p.getMaterial());
					ps.addBatch();
					log.info("[" + c++ + "] Update Sar Detail Prices: " + p);
				}
				int[] update_counts = ps.executeBatch();
				con.commit();
				boolean error = false;
				for (int i : update_counts) {
					if (i == 0)
						error = true;
					else
						num_update++;
				}
				if (error)
					log.error("[Result] Update Sar Detail Prices: " + Arrays.toString(update_counts));
			}
		} catch (SQLException sqle) {
			sqle.printStackTrace();
			log.error("Folio: " + folio + " | Positions: " + positions == null ? "NULL" : positions.toString(),
					sqle);
			ConexionDB.renovar(con);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("Folio: " + folio + " | Positions: " + positions == null ? "NULL" : positions.toString(), e);
		} finally {
			if (autoCommit != null) {
				try {
					con.setAutoCommit(autoCommit);
				} catch (SQLException e) {
					e.printStackTrace();
					log.error("Error al colocar " + autoCommit.toString() + " en setAutoCommit", e);
				}
			}
			ConexionDB.devolver(con);
		}
		return num_update;
	}

	
	public List<UpdatePricesBean> updateSarDetailPrices(List<UpdatePricesBean> prices) {
		Connection con = null;
		Boolean autoCommit = null;
		try {
			con = ConexionDB.dameConexion();
			try (PreparedStatement ps = con.prepareStatement(UPDATE_SAR_DETAIL_PRICES);) {
				autoCommit = con.getAutoCommit();
				con.setAutoCommit(false);
				int c = 0;
				for (UpdatePricesBean p : prices) {
					int i = 1;
					ps.setBigDecimal(i++, p.getUnitPrice());
					ps.setInt(i++, p.getFolio());
					ps.setString(i++, p.getPo());
					ps.setInt(i++, p.getPosition());
					ps.setInt(i++, p.getMaterial());
					ps.addBatch();
					log.info("[" + c++ + "] Update Sar Detail Prices: " + p);
				}
				int[] update_counts = ps.executeBatch();
				con.commit();
				boolean error = false;
				int cont = 0;
				for (int i : update_counts) {
					if (i == 0) {
						error = true;
						
					}
					prices.get(cont++).setResult(i == 1);
				}
				if (error) {
					log.error("[Result] Update Sar Detail Prices: " + Arrays.toString(update_counts));
				}
			}
		} catch (SQLException sqle) {
			sqle.printStackTrace();
			log.error(" Positions: " + prices == null ? "NULL" : prices.toString(),
					sqle);
			ConexionDB.renovar(con);
		} catch (Exception e) {
			e.printStackTrace();
			log.error(" Positions: " + prices == null ? "NULL" : prices.toString(), e);
		} finally {
			if (autoCommit != null) {
				try {
					con.setAutoCommit(autoCommit);
				} catch (SQLException e) {
					e.printStackTrace();
					log.error("Error al colocar " + autoCommit.toString() + " en setAutoCommit", e);
				}
			}
			ConexionDB.devolver(con);
		}
		return prices;
	}
	
	
	/**
	 * Actualiza datos del detalle de un SAR
	 * Moneda
	 * Condicion pago
	 * precio unitario
	 * 
	 * @param prices
	 * @throws SQLException 
	 */
	public void updateSarData(List<UpdateDataDetail> prices) throws SQLException {
		Connection con = null;
		Boolean autoCommit = null;
		try {
			con = ConexionDB.dameConexion();
			StringBuilder sql = new StringBuilder();
			sql.append(" UPDATE cdiSARDetalle SET precioUnitario = ?, moneda = ? , condicionPago = ? ");
			sql.append(" WHERE folio = ? AND po = ? AND posicion = ? ");
			
			try (PreparedStatement ps = con.prepareStatement(sql.toString());) {
				autoCommit = con.getAutoCommit();
				con.setAutoCommit(false);
				int c = 0;
				for (UpdateDataDetail p : prices) {
					int i = 1;
					ps.setBigDecimal(i++, p.getUnitPrice());
					ps.setString(i++,p.getMoneda() );
					ps.setString(i++,p.getCondPago() );
					ps.setInt(i++, p.getFolio());
					ps.setString(i++, p.getPo());
					ps.setInt(i++, p.getPosition());
					ps.addBatch();
					log.info("[" + c++ + "] Update Sar Detail : " + p);
				}
				int[] update_counts = ps.executeBatch();
				con.commit();
				boolean error = false;
				int cont = 0;
				for (int i : update_counts) {
					if (i == 0) {
						error = true;
					}
					prices.get(cont++).setResult(i == 1);
				}
				if (error) {
					log.error("[Result] Update Sar Detail : " + Arrays.toString(update_counts));
					throw new SQLException("[Result] Update Sar Detail : " + Arrays.toString(update_counts));
				}
			}
			
			if (autoCommit != null) {
				try {
					con.setAutoCommit(autoCommit);
				} catch (SQLException e) {
					log.error("Error al colocar " + autoCommit.toString() + " en setAutoCommit", e);
				}
			}
			ConexionDB.devolver(con);
		} catch (Exception e) {
			log.error(" Positions: " + prices == null ? "NULL" : prices.toString(), e);
			if (autoCommit != null) {
				try {
					con.setAutoCommit(autoCommit);
				} catch (SQLException s) {
					log.error("Error al colocar " + autoCommit.toString() + " en setAutoCommit", s);
				}
				ConexionDB.devuelveConexion(con);
			}
			throw new SQLException(e);
		}
	}
	
	public Integer marcarProyeccionBOItemsDirectos(boolean bandera, String po, int posicion, int folio) {

		Connection con = null;
		int response = 0; 
		
		try {
			
			con = ConexionDB.dameConexion();
			try (PreparedStatement pst = con.prepareStatement(UPDATE_SAR_DETAIL_ITEMS_DIRECTOS)) {
				
				pst.setBoolean(1, bandera);
				pst.setString(2, po);
				pst.setInt(3, posicion);
				pst.setInt(4, folio);
				
				response = pst.executeUpdate();
			}
			
		} catch (Exception e) {
			log.error("Ocurrio un error al intentar marcar los items: {} {} ", e, e.getMessage());
			ConexionDB.renovar(con);
		} finally {
			ConexionDB.devolver(con);
		}
		
		return response;
	}
	
	public Integer borrarProyeccionBOItemsDirectos(int folio) {

		Connection con = null;
		int response = 0; 
		
		try {
			
			con = ConexionDB.dameConexion();
			try (PreparedStatement pst = con.prepareStatement(BORRAR_SAR_DETAIL_ITEMS_DIRECTOS)) {
				pst.setInt(1, folio);
				response = pst.executeUpdate();
			}
			
		} catch (Exception e) {
			log.error("Ocurrio un error al intentar borrar los items: {} {} ", e, e.getMessage());
			ConexionDB.renovar(con);
		} finally {
			ConexionDB.devolver(con);
		}
		
		return response;
	}
	
	
	public static List<ItemsSeleccionados> obtenerItemsSeleccionados (Integer folio) {	
		
		List<ItemsSeleccionados> lstItems = new ArrayList<ItemsSeleccionados>();
		Connection con = null;	
			
		try {	
			con = ConexionDB.dameConexion();	
			ResultSet rs = null;	
			PreparedStatement pst = null;	
			pst = con.prepareStatement(OBTENER_ITEMS_SELECCIONADOS);	
			pst.setInt(1, folio);
			rs = pst.executeQuery();	
			
			while (rs.next()) {	
				
				ItemsSeleccionados item = new ItemsSeleccionados();
				item.setFolio(rs.getInt("folio"));
				item.setEliminarProyeccion(rs.getBoolean("eliminarProyeccion"));
				item.setPo(rs.getString("po").trim());
				item.setPosicion(rs.getInt("posicion"));
				lstItems.add(item);
				
			}	
				
			rs.close();	
			pst.close();	
			
		} catch (Exception exception) {	
			ConexionDB.renovar(con);
			log.error(exception.getMessage(), exception);	
		} finally {	
			ConexionDB.devolver(con);
		}	
		
		return lstItems;	
	}	
}