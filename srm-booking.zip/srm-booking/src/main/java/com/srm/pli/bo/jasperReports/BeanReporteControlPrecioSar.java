package com.srm.pli.bo.jasperReports;

import com.truper.utils.date.EnumFechas;
import com.truper.utils.date.UtilsFechas;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BeanReporteControlPrecioSar extends BeanReporteControlPrecio {

	private String buClave;
	private int folio;

	public String getBuClave() {
		return buClave;
	}

	public void setBuClave(String buClave) {
		this.buClave = buClave;
	}

	public String getLLave() {
		return UtilsFechas.setConvierteFechaToInt(getLogDate(), EnumFechas.FORMATO_YYYYMMDD) + getPo();
	}

}
