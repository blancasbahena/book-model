package com.srm.pli.schedulers.jobs;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import com.srm.pli.services.RequestBookingService;
import com.srm.pli.utils.PropertiesDb;

import lombok.extern.slf4j.Slf4j;
@Slf4j
public class EnviaMailRequestBookingJob implements Job {
	
	@Override
	public void execute(JobExecutionContext arg0) throws JobExecutionException {
		log.info("Iniciando proceso de envio automatico de request booking");
		boolean esProcesoActivo = PropertiesDb.getInstance().getBoolean("email.job.request.booking");
		if(esProcesoActivo) {
			RequestBookingService.getInstance().enviaMailsRequestBooking();
		}else {
			log.info("El proceso esta inactivo no se mandan correos.");
		}
		
		log.info("Finalizando proceso de envio automatico de request booking");
	}

}
