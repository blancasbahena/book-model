package com.srm.pli.db;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DB_JNDI {
	/**************************************************************************************************************************
	 * Pool de Conexiones JNDI
	 * 
	 * @author csuarez
	 * @since 04/07/2019
	 ***************************************************************************************************************************/

	private static DB_JNDI dataSource;
	private static DataSource ds;
	private static final Logger log = LoggerFactory.getLogger(DB_JNDI.class.getName());
	
	static {
		try {
			log.info("Obteniendo conexion de JNDI F&R");
			Context initContext = new InitialContext();
			Context envContext  = (Context)initContext.lookup("java:/comp/env");
			ds = (DataSource)envContext.lookup("jdbc/frDB");
			
		} catch (NamingException e1) {
			e1.printStackTrace();
			log.error("Conectando con BD TEL",e1);
		}catch(Exception e) {
			e.printStackTrace();
			log.error("Conectando con BD TEL",e);
		}
	}

	public static DB_JNDI getInstance() {
		if (dataSource == null)
			dataSource = new DB_JNDI();
		return dataSource;
	}

	public Connection getConnection() throws SQLException {
		return this.ds.getConnection();
	}

	public void closeConnection(Connection con) {
		try {
			if (con == null) {
				return;
			}
			if (!con.isClosed()) {
				con.close();
			}
			con = null;
		} catch (Exception e) {
			log.error("closeConnection {}", con, e);
		}
	}
}
