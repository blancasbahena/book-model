package com.srm.pli.bo;

import java.util.List;

import lombok.Data;

@Data
public class BeanUserPlannerManager {

	private String user;
	private List<BeanPlanners> listPlannersManagers;
}
