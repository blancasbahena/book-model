package com.srm.pli.dao;

import static com.srm.pli.dao.sql.CorreoSql.SELECT_CORREOS_TIPO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.srm.pli.db.ConexionDB;
import com.srm.pli.enums.TipoCorreoEnum;
import com.srm.pli.utils.CorreoUtils;
import com.truper.businessEntity.BeanRowFileCarrier;
import com.truper.businessEntity.SAR;

public class Navieras_DAO {

	private static Navieras_DAO instance = null;
	private static final Logger LOGGER = LogManager.getRootLogger();

	public Navieras_DAO() {
	}

	public static Navieras_DAO getInstance() {
		if(instance == null) {
			instance = new Navieras_DAO();
		}
		return instance;
	}

	public HashMap<String,ArrayList<BeanRowFileCarrier>> dameRelacionDeFileADB(ArrayList<BeanRowFileCarrier> lista) {
		HashMap<String,ArrayList<BeanRowFileCarrier>> respuesta = null;
		Connection con = null;
		StringBuffer query = new StringBuffer();
		/*
		query.append(" SELECT     folio, proveedor, puertoSalida, naviera, fechaEmbarque, consolidado, status, fechaSolAprobacion,   ");
			query.append(" usuarioSolAprobacion, fechaUltAprobRechazo, usuarioApruebaRechaza, tipoContenedor, prioridad, ");
			query.append(" barcoSugerido, viaje, puertoDescarga, contenedor, booking, etd,etdFinal, comentarioCancelacion,folioConsolidado,transporte, ");
			query.append(" comentarioPlanner, comentarioShipping, esSinPO, eta, bl, aprobadoPorCompras, tipoRetraso, fechaCreacion, esAereo, ");
			query.append(" fueModificadoProveedor, aerolinea, avion, llegadaavion, aceptadoConDiferencias, paisDestino, cargoAProveedor, ");
			query.append(" otraAerolinea,aprobadoProveedor,esmultiple,mandante, aprobadoSDI,cerradoDocumentosProveedor,");
			query.append(" fechaCierreDocumentosProveedor,fechaAprobadoSDI, comentarioTruperBooking,fechaUltimoRechazo,  ");
			query.append(" fechaUltimaCorreccion, usuarioUltimoRechazoAceptacion, revision, fecIniPlanning, tinyFecIniPlanning, ");
			query.append(" fecIniShipping, tinyFecIniShipping, fecIniConsol, tinyFecIniConsol, fecIniBooking, tinyFecIniBooking, ");
			query.append(" fecIniSDI, tinyFecIniSDI, fecIniEmbarque, tinyFecIniEmbarque, enRevisionConfirmFinal, numRevFinal");
			query.append(" FROM         cdiSAR ");
			query.append(" WHERE   	status =").append(status);
			query.append(" AND   	booking is not  NULL ");
		*/
		try {
			query.append("SELECT folio, proveedor, puertoSalida, consolidado, status, ");
			query.append("barcoSugerido, viaje, puertoDescarga, contenedor, booking, etd,etdFinal,  ");
			query.append(" eta, bl   ");
//			query.append(", , , , , , , ");
//			query.append(",,,, aprobadoSDI,cerradoDocumentosProveedor,");
			query.append(" FROM         cdiSAR ");
			query.append(" WHERE   	status = ? ");
			query.append(" AND   	naviera = 25 ");//25 es K+N
			query.append(" AND   	booking in( ");
			for(int i = 0 ; i <lista.size() ; i++) {
				query.append("?");
				if(i+1 < lista.size()) {
					query.append(",");
				}
			}
			query.append(")");
			con = ConexionDB.dameConexion();
			try (PreparedStatement pst = con.prepareStatement(query.toString())) {
				int x = 1;
				pst.setInt(x++, SAR.STATUS_APROBADO);
				for(int i = 0 ; i <lista.size() ; i++) {
					pst.setString(x++, lista.get(i).getBooking());
				}
				
				try (ResultSet rs = pst.executeQuery()) {
					respuesta = new HashMap<String,ArrayList<BeanRowFileCarrier>>();
					while (rs.next()) {
						BeanRowFileCarrier nuevoBean = new BeanRowFileCarrier();
						String booking = rs.getString("booking");
						nuevoBean.setSar(rs.getInt("folio"));
						nuevoBean.setBooking(booking);
						nuevoBean.setBl(rs.getString("bl"));
						nuevoBean.setContenedor(rs.getString("contenedor"));
						nuevoBean.setEtd(rs.getInt("etdFinal"));
						nuevoBean.setEta(rs.getInt("eta"));
						nuevoBean.setBarco(rs.getString("barcoSugerido"));
						nuevoBean.setViaje(rs.getString("viaje"));
						nuevoBean.setPol(rs.getString("puertoSalida"));
						nuevoBean.setPod(rs.getString("puertoDescarga"));
						if(respuesta.containsKey(booking)) {
							ArrayList<BeanRowFileCarrier> arreglo = respuesta.get(booking);
							arreglo.add(nuevoBean);
							respuesta.put(booking, arreglo);
						}else {
							ArrayList<BeanRowFileCarrier> arreglo = new ArrayList<>();
							arreglo.add(nuevoBean);
							respuesta.put(booking, arreglo);
						}
					}
				}
			}
			
		} catch (SQLException sqle) {
			sqle.printStackTrace();
			LOGGER.error(sqle);
			ConexionDB.renovar(con);
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error(e);
		} finally {
			ConexionDB.devolver(con);
		}
		return respuesta;
	}

}
