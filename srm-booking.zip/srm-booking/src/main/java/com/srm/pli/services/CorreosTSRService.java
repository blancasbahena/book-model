package com.srm.pli.services;

import static com.srm.pli.helper.CorreoHelper.SALUDO_TODOS;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang.StringEscapeUtils;

import com.srm.pli.bo.BeanTSR;
import com.srm.pli.bo.SarBO;
import com.srm.pli.bo.SarDetalleBO;
import com.srm.pli.dao.SAR_CDI_DAO;
import com.srm.pli.format.email.CorreoFormatoGeneral;
import com.srm.pli.helper.CorreoHelper;
import com.srm.pli.utils.FuncionesComunesPLI;
import com.srm.pli.utils.MailUtils;
import com.srm.pli.utils.ProductoUtils;
import com.srm.pli.utils.Utilerias;
import com.truper.businessEntity.PlaneadorBean;
import com.truper.businessEntity.UnidadNegocio;
import com.truper.utils.string.UtilsString;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class CorreosTSRService {
	
	private static final CorreosTSRService instance = new CorreosTSRService();
	
	private CorreosTSRService() {
	}

	public static CorreosTSRService getInstance() {
		return instance;
	}

	public boolean mailCreacionTSR(BeanTSR registro, String proveedor) throws Exception {
		
		log.info("INICIO mailCreacionTSR ");
		
		List<BeanTSR> folios = new ArrayList<>();
		folios.add(registro);
		List<String > mailTo = obtenerListaCorreosTSR(folios);
       
        StringBuilder sBuilder = new StringBuilder();
        sBuilder.append("<html>");
		sBuilder.append("<head>");
		sBuilder.append("</head>");
  		sBuilder.append("<body>");
  		sBuilder.append("<style type='text/css'>");
  		sBuilder.append(".ctst{");
		sBuilder.append("    FONT-SIZE: 10pt;");
		sBuilder.append("    LINE-HEIGHT: 12pt;");
		sBuilder.append("    FONT-FAMILY: Arial;");
		sBuilder.append("}");
		sBuilder.append(".tableSimpleRow{");
		sBuilder.append("color: #FFF;");
		sBuilder.append("background: #3b8c86;");
		sBuilder.append("padding: 3px 3px;");
		sBuilder.append("font-weight: bold;");
		sBuilder.append("border: 1px solid #3b8c86;");
		sBuilder.append("}");
  		sBuilder.append("</style>");
		
  		sBuilder.append("<p><h2>A TSR has been created for the  SAR #:" + registro.getFolio() + "<br></h2>");
  		sBuilder.append("</body></html>");
		
  		String[] mailsTo = new String[mailTo.size()];
		mailTo.toArray(mailsTo);
		
		boolean exitoso = MailUtils.enviaCorreo(mailsTo, null, "TSR created for SAR #:" +registro.getFolio(), MailUtils.sender, sBuilder.toString(), null);
		log.info("Correo de noficacion - Creación de TSR enviado a usuarios");
		
		return exitoso;
	}
	
	public boolean enviaReportesAutomaticosTSRPendientes(List<BeanTSR> listaRegistros) {
		
		log.info("INICIO mail TSR's Pendientes ");
		
		List<String > mailTo = obtenerListaCorreosTSR(listaRegistros);
       
  		StringBuilder table = new StringBuilder();
		table.append(CorreoFormatoGeneral.getInstance().getTrHeader());
		table.append(CorreoFormatoGeneral.getInstance().getThHeader("SAR"));
		table.append(CorreoFormatoGeneral.getInstance().getThHeader("Supplier"));
		table.append(CorreoFormatoGeneral.getInstance().getThHeader("Reference"));
		table.append(CorreoFormatoGeneral.getInstance().getThHeader("Since"));
		table.append("</tr>");

  		
		for (int i = 0; i < listaRegistros.size(); i++) {

			BeanTSR registro = listaRegistros.get(i);
			
  			if (i % 2 == 0) {
				table.append(CorreoFormatoGeneral.getInstance().getTrEven());
			} else {
				table.append(CorreoFormatoGeneral.getInstance().getTrOdd());
			}
			table.append(CorreoFormatoGeneral.getInstance().getTd(registro.getFolio()));
			table.append(CorreoFormatoGeneral.getInstance().getTd(StringEscapeUtils.escapeHtml(registro.getNombreProveedor())));
			table.append(CorreoFormatoGeneral.getInstance().getTd(StringEscapeUtils.escapeHtml(registro.getReferenceNumber())));
			table.append(CorreoFormatoGeneral.getInstance().getTd(Utilerias.fechaInt2Jquery(registro.getFechaRegistro())));
			table.append("</tr>");

  		}
  		
  		Collections.addAll(mailTo, CdiNotificationBuilderServices.CORREO_IVONNE);
  		
  		String[] mailsTo = new String[mailTo.size()];
		mailTo.toArray(mailsTo);
		
		String fomrmatoHTML = CorreoFormatoGeneral.getInstance().getFormatoFR(
				SALUDO_TODOS, "List of TSRs that have not been resolved", "PendingTSRs", CorreoHelper.PRIORIDAD_NORMAL, table.toString());
		
		
		boolean exitoso = MailUtils.enviaCorreo(mailsTo, null, "Pending TSRs", MailUtils.sender, fomrmatoHTML, null);
		log.info("Correo de noficacion - TSR's pendientes, enviado a usuarios");
		
		return exitoso;
	}
	
	public boolean mailCierreTSR(Integer folio, Boolean approval, String comments, String mailProveedor) {

		log.info("INICIO mailCreacionTSR ");
		
		List<BeanTSR> folios = new ArrayList<>();
		BeanTSR reg = new BeanTSR();
		reg.setFolio(folio);
		folios.add(reg);
		List<String > mailTo = obtenerListaCorreosTSR(folios);
       
        StringBuilder sBuilder = new StringBuilder();
        sBuilder.append("<html>");
		sBuilder.append("<head>");
		sBuilder.append("</head>");
  		sBuilder.append("<body>");
  		sBuilder.append("<style type='text/css'>");
  		sBuilder.append(".ctst{");
		sBuilder.append("    FONT-SIZE: 10pt;");
		sBuilder.append("    LINE-HEIGHT: 12pt;");
		sBuilder.append("    FONT-FAMILY: Arial;");
		sBuilder.append("}");
		sBuilder.append(".tableSimpleRow{");
		sBuilder.append("color: #FFF;");
		sBuilder.append("background: #3b8c86;");
		sBuilder.append("padding: 3px 3px;");
		sBuilder.append("font-weight: bold;");
		sBuilder.append("border: 1px solid #3b8c86;");
		sBuilder.append("}");
  		sBuilder.append("</style>");
		
  		sBuilder.append("<p><h2>A TSR has been closed for the  SAR #:" + folio + "<br></h2>");
  		sBuilder.append(comments);
  		sBuilder.append("</body></html>");
		
  		mailTo.add(mailProveedor);
  		
  		String[] mailsTo = new String[mailTo.size()];
		mailTo.toArray(mailsTo);
		
		boolean exitoso = MailUtils.enviaCorreo(mailsTo, null, "TSR closed for SAR #:" +folio, MailUtils.sender, sBuilder.toString(), null);
		log.info("Correo de noficacion - Aviso de TSR cerrado, enviado a usuarios");
		
		return exitoso;
	}
	

	private List<String> obtenerListaCorreosTSR(List<BeanTSR> folios) {
		
		List<String> resultado = new ArrayList<>();
		
		try {
			for(BeanTSR registro : folios) {
				SAR_CDI_DAO dao = new SAR_CDI_DAO();
				SarBO filtro = new SarBO();
				filtro.setFolio(registro.getFolio());
				ArrayList<SarBO> listaSars = dao.selectSar(filtro , false);
			
				SarBO bean = listaSars.get(0);
				List<SarDetalleBO> detalles = DetallesServices.getInstance().getDetalleSAR(bean);
				bean.setDetalleBO(detalles);
				
				Map<String, Object> correosSAR = MailUtils.dameDatosDestinoMail(bean);
				@SuppressWarnings("unchecked")
				Map<String, UnidadNegocio> correosBU = (Map<String, UnidadNegocio>) correosSAR.get("bu");
				

				List<String> listaCelulas = new ArrayList<>();
				
				for(SarDetalleBO det : detalles) {
					
					String bu = ProductoUtils.getInstance().getBU(det.getMaterial().toString(), det.getCentro().trim());
					if (!UtilsString.isStringValida(bu) || ProductoUtils.SIN_PRODUCTO_CENTRO.equalsIgnoreCase(bu)
							|| ProductoUtils.NO_ENCONTRADO.equalsIgnoreCase(bu)) {
						
						continue;
					}
					
					listaCelulas.add(bu);
				}
				
				//Mapa Gerentes confirmación
				if (detalles != null && detalles.get(0) != null) {
					
					String plannerCode = detalles.get(0).getPlaneador();
					PlaneadorBean planner = FuncionesComunesPLI.planners.get(plannerCode);
					
					if(planner != null && planner.getCorreoGerente() != null && !"".equals(planner.getCorreoGerente())) {
						if(!resultado.contains(planner.getCorreoGerente())) {
							resultado.add(planner.getCorreoGerente());
							
						}
						
					}
					
				}
				
				//Mapa gerentes BU
				for(String celula : listaCelulas) {
					
					Set<String> gerentes = CorreoServices.getInstance().getCorreosGerenteBu(celula);
					
					for(String g : gerentes) {
						if(!resultado.contains(g)) {
							resultado.add(g);
						}
					}
					
				}
				
				if (correosBU != null) {
					for (Map.Entry<String, UnidadNegocio> tmp : correosBU.entrySet()) {
						
						if(!resultado.contains(tmp.getValue().getMailContacto())) {
							Collections.addAll(resultado,tmp.getValue().getMailContacto());
						}
						
					}
				}
				
			}
		} catch (Exception e) {
			log.error("No fue posible obtener la lista de correos de TSR " +e.getMessage());
		}
		

  		Collections.addAll(resultado, SarBO.MAIL_GRUPO_BOOKING);
  		Collections.addAll(resultado, SarBO.EMAIL_SHIPPING);
  		Collections.addAll(resultado, SarBO.MAIL_GIL);
  		Collections.addAll(resultado, SarBO.EMAIL_OMAR_MORALES);
  		
		return resultado;
	}
}
