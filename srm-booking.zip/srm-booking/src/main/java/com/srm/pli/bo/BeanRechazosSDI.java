package com.srm.pli.bo;

public class BeanRechazosSDI {
	private String proveedor;
	private String booking;
	private int versionSDI;
	private String folio;
	private int naviera;
	private int prioridad;
	private int ETA;
	private int diasVsRechazo;
	private int fechaRechazo;
	private int fechaAceptadoProveedor;
	private String po;
	private int pos;
	private String analista;
	private String terminoPago;
	private String centro;
	private boolean consolidado;
	private boolean esPedidoDirecto;
	private String material;
	private String comentarioSdi;
	private String usuarioRechazo;

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((booking == null) ? 0 : booking.hashCode());
		result = prime * result + ((proveedor == null) ? 0 : proveedor.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BeanRechazosSDI other = (BeanRechazosSDI) obj;
		if (booking == null) {
			if (other.booking != null)
				return false;
		} else if (!booking.equals(other.booking))
			return false;
		if (proveedor == null) {
			if (other.proveedor != null)
				return false;
		} else if (!proveedor.equals(other.proveedor))
			return false;
		return true;
	}

	public String getProveedor() {
		return proveedor;
	}

	public void setProveedor(String proveedor) {
		this.proveedor = proveedor;
	}

	public String getBooking() {
		return booking;
	}

	public void setBooking(String booking) {
		this.booking = booking;
	}

	public int getVersionSDI() {
		return versionSDI;
	}

	public void setVersionSDI(int versionSDI) {
		this.versionSDI = versionSDI;
	}

	public String getFolio() {
		return folio;
	}

	public void setFolio(String folio) {
		this.folio = folio;
	}

	public int getNaviera() {
		return naviera;
	}

	public void setNaviera(int naviera) {
		this.naviera = naviera;
	}

	public int getPrioridad() {
		return prioridad;
	}

	public void setPrioridad(int prioridad) {
		this.prioridad = prioridad;
	}

	public int getETA() {
		return ETA;
	}

	public void setETA(int eTA) {
		ETA = eTA;
	}

	public int getDiasVsRechazo() {
		return diasVsRechazo;
	}

	public void setDiasVsRechazo(int diasVsRechazo) {
		this.diasVsRechazo = diasVsRechazo;
	}

	public int getFechaRechazo() {
		return fechaRechazo;
	}

	public void setFechaRechazo(int fechaRechazo) {
		this.fechaRechazo = fechaRechazo;
	}

	public int getFechaAceptadoProveedor() {
		return fechaAceptadoProveedor;
	}

	public void setFechaAceptadoProveedor(int fechaAceptadoProveedor) {
		this.fechaAceptadoProveedor = fechaAceptadoProveedor;
	}

	public String getPo() {
		return po;
	}

	public void setPo(String po) {
		this.po = po;
	}

	public int getPos() {
		return pos;
	}

	public void setPos(int pos) {
		this.pos = pos;
	}

	public String getAnalista() {
		return analista;
	}

	public void setAnalista(String analista) {
		this.analista = analista;
	}

	public String getTerminoPago() {
		return terminoPago;
	}

	public void setTerminoPago(String terminoPago) {
		this.terminoPago = terminoPago;
	}

	public String getCentro() {
		return centro;
	}

	public void setCentro(String centro) {
		this.centro = centro;
	}

	public boolean isConsolidado() {
		return consolidado;
	}

	public void setConsolidado(boolean consolidado) {
		this.consolidado = consolidado;
	}

	public boolean isEsPedidoDirecto() {
		return esPedidoDirecto;
	}

	public void setEsPedidoDirecto(boolean esPedidoDirecto) {
		this.esPedidoDirecto = esPedidoDirecto;
	}

	public String getMaterial() {
		return material;
	}

	public void setMaterial(String material) {
		this.material = material;
	}

	public String getComentarioSdi() {
		return comentarioSdi;
	}

	public void setComentarioSdi(String comentarioSdi) {
		this.comentarioSdi = comentarioSdi;
	}

	public String getUsuarioRechazo() {
		return usuarioRechazo;
	}

	public void setUsuarioRechazo(String usuarioRechazo) {
		this.usuarioRechazo = usuarioRechazo;
	}
}