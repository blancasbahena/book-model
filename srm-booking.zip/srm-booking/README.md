Proyecto srm-booking
Necesita en el servidor una carpeta con el nombre ReportesFR en la ruta C:/
Ahi se ingresan todos los reportes o archivos jrxml y jasper.