package com.truper.infra.sap.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Table;

/**
 * Clase que representa la relacion entre la orden de contra y el BPM.
 * 
 * @author Pablo Cruz Santos
 * @version 1.0
 * @date 04/11/2015
 */
@Entity
@Table(name = "srm_PO_BPM")
public class SAP_PO_BPM {

	@Id
	@Column(name = "ID", updatable = false, unique = true, insertable = false)
	private Integer id;

	@Column(name = "ID_PO")
	private Integer idPO;

	@Column(name = "ID_BPM")
	private Long idBPM;

	@JoinColumn(table = "srm_SAP_PO", name = "ID_PO", referencedColumnName = "ID")
	private SAP_PO po;

	public SAP_PO_BPM() {
		super();
	}

	public SAP_PO_BPM(Integer idPO, Long idBPM) {
		super();
		this.idPO = idPO;
		this.idBPM = idBPM;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getIdPO() {
		return idPO;
	}

	public void setIdPO(Integer idPO) {
		this.idPO = idPO;
	}

	public Long getIdBPM() {
		return idBPM;
	}

	public void setIdBPM(Long idBPM) {
		this.idBPM = idBPM;
	}

	public SAP_PO getPo() {
		return po;
	}

	public void setPo(SAP_PO po) {
		this.po = po;
	}
}
