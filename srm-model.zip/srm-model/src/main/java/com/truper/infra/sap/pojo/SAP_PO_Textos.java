package com.truper.infra.sap.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.truper.infra.sap.SAP_FieldMapping;

@Entity
@Table(name = "srm_SAP_PO_TEXTOS")
public class SAP_PO_Textos {

	@Id
	@Column(name = "ID", updatable = false, unique = true, insertable = false)
	private Integer id;

	@Column(name = "MANDANTE")
	@SAP_FieldMapping(componente = "MANDT", tipoDeDato = "CLNT", longitud = 3, decimalDato = 0)
	private String mandante;
	
	@Column(name = "NUMERO_OC")
	@SAP_FieldMapping(componente = "EBELN", tipoDeDato = "CHAR", longitud = 10, decimalDato = 0)
	private String numeroOC;
	
	@Column(name = "FECHA_MODIFICACION")
	@SAP_FieldMapping(componente = "AEDTM", tipoDeDato = "DATS", longitud = 8, decimalDato = 0)
	private String fechaModificacion;
	
	@Column(name = "HORA_MODIFICACION")
	@SAP_FieldMapping(componente = "UTIME", tipoDeDato = "TIMS", longitud = 6, decimalDato = 0)
	private String horaModificacion;
	
	@Column(name = "NUMERO_DE_LINEA")
	@SAP_FieldMapping(componente = "NLINE", tipoDeDato = "NUMC", longitud = 3, decimalDato = 0)
	private String numeroDeLinea;
	
	@Column(name = "LINEA_DE_TEXTO")
	@SAP_FieldMapping(componente = "TDLINE", tipoDeDato = "CHAR", longitud = 132, decimalDato = 0)
	private String lineaDeTexto;
	
	@Column(name = "INDICADOR_DE_BORRADO")
	@SAP_FieldMapping(componente = "LOEVM", tipoDeDato = "CHAR", longitud = 1, decimalDato = 0)
	private String indicadorDeBorrado;
	
	/*************************************************************************/
	
	@Column(name = "INDICADOR_PROCESO")
	@SAP_FieldMapping(componente = "STEP1", tipoDeDato = "CHAR", longitud = 1, decimalDato = 0)
	private String indicadorProceso;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getMandante() {
		return mandante;
	}

	public void setMandante(String mandante) {
		this.mandante = mandante;
	}

	public String getNumeroOC() {
		return numeroOC;
	}

	public void setNumeroOC(String numeroOC) {
		this.numeroOC = numeroOC;
	}

	public String getFechaModificacion() {
		return fechaModificacion;
	}

	public void setFechaModificacion(String fechaModificacion) {
		this.fechaModificacion = fechaModificacion;
	}

	public String getHoraModificacion() {
		return horaModificacion;
	}

	public void setHoraModificacion(String horaModificacion) {
		this.horaModificacion = horaModificacion;
	}

	public String getNumeroDeLinea() {
		return numeroDeLinea;
	}

	public void setNumeroDeLinea(String numeroDeLinea) {
		this.numeroDeLinea = numeroDeLinea;
	}

	public String getLineaDeTexto() {
		return lineaDeTexto;
	}

	public void setLineaDeTexto(String lineaDeTexto) {
		this.lineaDeTexto = lineaDeTexto;
	}

	public String getIndicadorDeBorrado() {
		return indicadorDeBorrado;
	}

	public void setIndicadorDeBorrado(String indicadorDeBorrado) {
		this.indicadorDeBorrado = indicadorDeBorrado;
	}

	public String getIndicadorProceso() {
		return indicadorProceso;
	}

	public void setIndicadorProceso(String indicadorProceso) {
		this.indicadorProceso = indicadorProceso;
	}
}
