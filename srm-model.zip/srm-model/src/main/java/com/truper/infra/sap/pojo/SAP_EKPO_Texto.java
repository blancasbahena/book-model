package com.truper.infra.sap.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.truper.infra.businessEntities.BaseBusinessEntity;
import com.truper.infra.sap.SAP_FieldMapping;

/**
 * @author Pablo Cruz Santos
 * @version 1.0
 * @date 29/10/2015
 */
@Entity
@Table(name = "srm_SAP_EKPO_TEXTOS")
public class SAP_EKPO_Texto extends BaseBusinessEntity {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "ID", updatable = false, unique = true, insertable = false)
	private Integer id;

	@Column(name = "MANDANTE")
	@SAP_FieldMapping(componente = "MANDT", tipoDeDato = "CLNT", longitud = 3, decimalDato = 0)
	private String mandante;

	@Column(name = "NUMERO_DOCUMENTO")
	@SAP_FieldMapping(componente = "EBELN", tipoDeDato = "CHAR", longitud = 10, decimalDato = 0)
	private String numeroDocumento;

	@Column(name = "NUMERO_POSICION_DOCUMENTO")
	@SAP_FieldMapping(componente = "EBELP", tipoDeDato = "NUMC", longitud = 5, decimalDato = 0)
	private String numeroPosicionDocumento;

	@Column(name = "FECHA_MODIFICACION")
	@SAP_FieldMapping(componente = "AEDTM", tipoDeDato = "DATS", longitud = 8, decimalDato = 0)
	private String fechaModificacion;

	@Column(name = "HORA_MODIFICACION")
	@SAP_FieldMapping(componente = "UTIME", tipoDeDato = "TIMS", longitud = 6, decimalDato = 0)
	private String horaModificacion;

	@Column(name = "NUMERO_LINEA")
	@SAP_FieldMapping(componente = "NLINE", tipoDeDato = "NUMC", longitud = 3, decimalDato = 0)
	private String numeroLinea;

	@Column(name = "LINEA_TEXTO")
	@SAP_FieldMapping(componente = "TDLINE", tipoDeDato = "CHAR", longitud = 132, decimalDato = 0)
	private String lineaTexto;

	@Column(name = "INDICADOR_PROCESO")
	@SAP_FieldMapping(componente = "STEP1", tipoDeDato = "CHAR", longitud = 1, decimalDato = 0)
	private String indicadorProceso;

	@Column(name = "INDICADOR_BORRADO")
	@SAP_FieldMapping(componente = "LOEVM", tipoDeDato = "CHAR", longitud = 1, decimalDato = 0)
	private String indicadorBorrado;

	public SAP_EKPO_Texto() {
		super();
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getMandante() {
		return mandante;
	}

	public void setMandante(String mandante) {
		this.mandante = mandante;
	}

	public String getNumeroDocumento() {
		return numeroDocumento;
	}

	public void setNumeroDocumento(String numeroDocumento) {
		this.numeroDocumento = numeroDocumento;
	}

	public String getNumeroPosicionDocumento() {
		return numeroPosicionDocumento;
	}

	public void setNumeroPosicionDocumento(String numeroPosicionDocumento) {
		this.numeroPosicionDocumento = numeroPosicionDocumento;
	}

	public String getFechaModificacion() {
		return fechaModificacion;
	}

	public void setFechaModificacion(String fechaModificacion) {
		this.fechaModificacion = fechaModificacion;
	}

	public String getHoraModificacion() {
		return horaModificacion;
	}

	public void setHoraModificacion(String horaModificacion) {
		this.horaModificacion = horaModificacion;
	}

	public String getNumeroLinea() {
		return numeroLinea;
	}

	public void setNumeroLinea(String numeroLinea) {
		this.numeroLinea = numeroLinea;
	}

	public String getLineaTexto() {
		return lineaTexto;
	}

	public void setLineaTexto(String lineaTexto) {
		this.lineaTexto = lineaTexto;
	}

	public String getIndicadorProceso() {
		return indicadorProceso;
	}

	public void setIndicadorProceso(String indicadorProceso) {
		this.indicadorProceso = indicadorProceso;
	}

	public String getIndicadorBorrado() {
		return indicadorBorrado;
	}

	public void setIndicadorBorrado(String indicadorBorrado) {
		this.indicadorBorrado = indicadorBorrado;
	}
}
