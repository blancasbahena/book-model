package com.truper.infra.sap.pojo;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.Table;

import com.truper.infra.businessEntities.BaseBusinessEntity;
import com.truper.infra.sap.SAP_FieldInnerObject;
import com.truper.infra.sap.SAP_FieldMapping;

@Entity
@Table(name = "srm_SAP_PO")
public class SAP_PO extends BaseBusinessEntity {

	private static final long serialVersionUID = 7366399821128306086L;

	@Id
	@Column(name = "ID", updatable = false, unique = true, insertable = false)
	private Integer id;

	@Column(name = "NUMERO_OC")
	@SAP_FieldMapping(componente = "EBELN", tipoDeDato = "CHAR", longitud = 10, decimalDato = 0)
	private String numeroOc;

	@Column(name = "FECHA_MODIFICACION")
	@SAP_FieldMapping(componente = "AEDTM", tipoDeDato = "DATS", longitud = 8, decimalDato = 0)
	private String fechaModificacion;

	@Column(name = "HORA_MODIFICACION")
	@SAP_FieldMapping(componente = "UTIME", tipoDeDato = "TIMS", longitud = 6, decimalDato = 0)
	private String horaModificacion;

	@Column(name = "SOCIEDAD")
	@SAP_FieldMapping(componente = "BUKRS", tipoDeDato = "CHAR", longitud = 4, decimalDato = 0)
	private String sociedad;

	@Column(name = "TIPO_DOCUMENTO_COMPRAS")
	@SAP_FieldMapping(componente = "BSART", tipoDeDato = "CHAR", longitud = 4, decimalDato = 0)
	private String tipoDocumentoCompras;

	@Column(name = "FECHA_CREACION")
	@SAP_FieldMapping(componente = "AEDAT", tipoDeDato = "DATS", longitud = 8, decimalDato = 0)
	private String fechaCreacion;

	@Column(name = "NUMERO_CUENTA_PROVEEDOR")
	@SAP_FieldMapping(componente = "LIFNR", tipoDeDato = "CHAR", longitud = 10, decimalDato = 0)
	private String numeroCuentaProveedor;

	@Column(name = "NOMBRE_PROVEEDOR")
	@SAP_FieldMapping(componente = "NAME1", tipoDeDato = "CHAR", longitud = 30, decimalDato = 0)
	private String nombreProveedor;

	@Column(name = "CLAVE_CONDICIONES_PAGO")
	@SAP_FieldMapping(componente = "ZTERM", tipoDeDato = "CHAR", longitud = 4, decimalDato = 0)
	private String claveCondicionesPago;

	@Column(name = "ACLARACION_PROPIA_CONDICIONES_PAGO")
	@SAP_FieldMapping(componente = "TEXT1", tipoDeDato = "CHAR", longitud = 50, decimalDato = 0)
	private String aclaracionPropiaCondicionesPago;

	@Column(name = "CELULA_COMPRAS")
	@SAP_FieldMapping(componente = "EKORG", tipoDeDato = "CHAR", longitud = 4, decimalDato = 0)
	private String celulaCompras;

	@Column(name = "DENOMINACION_COMPRAS")
	@SAP_FieldMapping(componente = "EKOTX", tipoDeDato = "CHAR", longitud = 20, decimalDato = 0)
	private String denominacionCompras;

	@Column(name = "GRUPO_COMPRAS")
	@SAP_FieldMapping(componente = "EKGRP", tipoDeDato = "CHAR", longitud = 3, decimalDato = 0)
	private String grupoCompras;

	@Column(name = "NOMBRE_COMPRADOR")
	@SAP_FieldMapping(componente = "EKCOM", tipoDeDato = "CHAR", longitud = 80, decimalDato = 0)
	private String nombreComprador;

	@Column(name = "MAIL_COMPRADOR")
	@SAP_FieldMapping(componente = "EKURL", tipoDeDato = "CHAR", longitud = 132, decimalDato = 0)
	private String mailComprador;

	@Column(name = "REFERENCIA")
	@SAP_FieldMapping(componente = "IHREZ", tipoDeDato = "CHAR", longitud = 12, decimalDato = 0)
	private String referencia;

	@Column(name = "INCOTERMS1")
	@SAP_FieldMapping(componente = "INCO1", tipoDeDato = "CHAR", longitud = 3, decimalDato = 0)
	private String incoterms1;

	@Column(name = "INCOTERMS2")
	@SAP_FieldMapping(componente = "INCO2", tipoDeDato = "CHAR", longitud = 28, decimalDato = 0)
	private String incoterms2;

	@Column(name = "TIPO_CONTENEDOR")
	@SAP_FieldMapping(componente = "SUBMI", tipoDeDato = "CHAR", longitud = 10, decimalDato = 0)
	private String tipoContenedor;

	@Column(name = "VALOR_NETO_MONEDA_DOC")
	@SAP_FieldMapping(componente = "NETWR", tipoDeDato = "CURR", longitud = 15, decimalDato = 2)
	private String valorNetoMonedaDoc;

	@Column(name = "CLAVE_MONEDA")
	@SAP_FieldMapping(componente = "WAERS", tipoDeDato = "CUKY", longitud = 5, decimalDato = 0)
	private String claveMoneda;

	@Column(name = "CONTENEDOR_IDEAL")
	@SAP_FieldMapping(componente = "SFRGR", tipoDeDato = "CHAR", longitud = 4, decimalDato = 0)
	private String contenedorIdeal;

	@Column(name = "PESO_CONTENEDOR")
	@SAP_FieldMapping(componente = "SFRWH", tipoDeDato = "QUAN", longitud = 15, decimalDato = 3)
	private String pesoContenedor;

	@Column(name = "VOLUMEN_CONTENEDOR")
	@SAP_FieldMapping(componente = "SFRVL", tipoDeDato = "QUAN", longitud = 13, decimalDato = 3)
	private String volumenContenedor;

	@Column(name = "PESO_ACTUAL")
	@SAP_FieldMapping(componente = "WEIGHT", tipoDeDato = "QUAN", longitud = 15, decimalDato = 3)
	private String pesoActual;

	@Column(name = "VOLUMEN_ACTUAL")
	@SAP_FieldMapping(componente = "VOLUM", tipoDeDato = "QUAN", longitud = 13, decimalDato = 3)
	private String volumenActual;

	@Column(name = "PAIS_EMISOR_CERTIFICADO_ORIGEN")
	@SAP_FieldMapping(componente = "URZLA", tipoDeDato = "CHAR", longitud = 3, decimalDato = 0)
	private String paisEmisorCertificadoOrigen;

	@Column(name = "REGION")
	@SAP_FieldMapping(componente = "REGIO", tipoDeDato = "CHAR", longitud = 3, decimalDato = 0)
	private String region;

	@Column(name = "DENOMINACION_REGION")
	@SAP_FieldMapping(componente = "BEZEI", tipoDeDato = "CHAR", longitud = 20, decimalDato = 0)
	private String denominacionRegion;

	@Column(name = "JUSTIFICACION_PRECIO")
	@SAP_FieldMapping(componente = "WGLIF", tipoDeDato = "CHAR", longitud = 18, decimalDato = 0)
	private String justificacionPrecio;

	@Column(name = "PLANIFICADOR_NECESIDADES")
	@SAP_FieldMapping(componente = "DISPO", tipoDeDato = "CHAR", longitud = 3, decimalDato = 0)
	private String planificadorNecesidades;

	@Column(name = "DESCRIPCION_PLANIFICADOR_NECESIDADES")
	@SAP_FieldMapping(componente = "DSNAM", tipoDeDato = "CHAR", longitud = 18, decimalDato = 0)
	private String descripcionPlanificadorNecesidades;

	@Column(name = "CORREO_PLANIFICADOR")
	@SAP_FieldMapping(componente = "DSKEY", tipoDeDato = "CHAR", longitud = 70, decimalDato = 0)
	private String correoPlanificador;

	@Column(name = "SEMAFORO_PROVEEDOR")
	@SAP_FieldMapping(componente = "XLIFN", tipoDeDato = "CHAR", longitud = 1, decimalDato = 0)
	private String semaforoProveedor;

	@Column(name = "SEMAFORO_FABRICA")
	@SAP_FieldMapping(componente = "XLFFA", tipoDeDato = "CHAR", longitud = 1, decimalDato = 0)
	private String semaforoFabrica;

	@Column(name = "SEMAFORO_TERMINO_PAGO")
	@SAP_FieldMapping(componente = "XZTER", tipoDeDato = "CHAR", longitud = 1, decimalDato = 0)
	private String semaforoTerminoPago;

	@Column(name = "SEMAFORO_MONEDA")
	@SAP_FieldMapping(componente = "XWAER", tipoDeDato = "CHAR", longitud = 1, decimalDato = 0)
	private String semaforoMoneda;

	@Column(name = "TIPO_OPERACION")
	@SAP_FieldMapping(componente = "IUDOP", tipoDeDato = "CHAR", longitud = 1, decimalDato = 0)
	private String tipoOperacion;

	@Column(name = "NUMERO_CONDICION_DOCUMENTO")
	@SAP_FieldMapping(componente = "KNUMV", tipoDeDato = "CHAR", longitud = 10, decimalDato = 0)
	private String numeroCondicionDocumento;

	@Column(name = "INDICADOR_BORRADO")
	@SAP_FieldMapping(componente = "LOEVM", tipoDeDato = "CHAR", longitud = 1, decimalDato = 0)
	private String indicadorDeBorrado;

	@Column(name = "NOMBRE_USUARIO")
	@SAP_FieldMapping(componente = "UNAME", tipoDeDato = "CHAR", longitud = 12, decimalDato = 0)
	private String nombreUsuario;

	@JoinColumns({
			@JoinColumn(table = "srm_SAP_PO_TEXTOS", name = "NUMERO_OC", referencedColumnName = "NUMERO_OC"),
			@JoinColumn(table = "srm_SAP_PO_TEXTOS", name = "FECHA_MODIFICACION", referencedColumnName = "FECHA_MODIFICACION"),
			@JoinColumn(table = "srm_SAP_PO_TEXTOS", name = "HORA_MODIFICACION", referencedColumnName = "HORA_MODIFICACION") })
	@SAP_FieldInnerObject(componente = "NT_TEXT")
	private List<SAP_PO_Textos> textos;

	@JoinColumns({
			@JoinColumn(table = "srm_SAP_PO_INTERLOCUTORES", name = "NUMERO_OC", referencedColumnName = "NUMERO_OC"),
			@JoinColumn(table = "srm_SAP_PO_INTERLOCUTORES", name = "FECHA_MODIFICACION", referencedColumnName = "FECHA_MODIFICACION"),
			@JoinColumn(table = "srm_SAP_PO_INTERLOCUTORES", name = "HORA_MODIFICACION", referencedColumnName = "HORA_MODIFICACION") })
	@SAP_FieldInnerObject(componente = "NT_EKPA")
	private List<SAP_PO_Interlocutores> interlocutores;

	/*************************************************************************/

	@Column(name = "CONDICIONES_PAGO_PROVEEDOR")
	@SAP_FieldMapping(componente = "ZTERP", tipoDeDato = "CHAR", longitud = 4, decimalDato = 0)
	private String condicionesPagoProveedor;

	@Column(name = "DESCRIPCION_CONDICIONES_PAGO_PROVEEDOR")
	@SAP_FieldMapping(componente = "TEXTP", tipoDeDato = "CHAR", longitud = 50, decimalDato = 0)
	private String descripcionCondicionesPagoProveedor;

	@Column(name = "GERENTE_COMPRAS")
	@SAP_FieldMapping(componente = "EKGRT", tipoDeDato = "CHAR", longitud = 3, decimalDato = 0)
	private String gerenteCompras;

	@Column(name = "NOMBRE_GERENTE_COMPRAS")
	@SAP_FieldMapping(componente = "TKGRT", tipoDeDato = "CHAR", longitud = 80, decimalDato = 0)
	private String nombreGerenteCompras;

	@Column(name = "EMAIL_GERENTE_COMPRAS")
	@SAP_FieldMapping(componente = "URLGR", tipoDeDato = "CHAR", longitud = 132, decimalDato = 0)
	private String mailGerenteCompras;

	@Column(name = "CLAVE_MONEDA_PROVEEDOR")
	@SAP_FieldMapping(componente = "WAERP", tipoDeDato = "CUKY", longitud = 5, decimalDato = 0)
	private String claveMonedaProveedor;

	@Column(name = "INDICADOR_PROCESO")
	@SAP_FieldMapping(componente = "STEP1", tipoDeDato = "CHAR", longitud = 1, decimalDato = 0)
	private String indicadorProceso;

	// proveedor con mas de una moneda
	@Column(name = "INDICADOR_MONEDAS")
	@SAP_FieldMapping(componente = "WAERN", tipoDeDato = "CHAR", longitud = 1, decimalDato = 0)
	private String indicadorMasDeUnaMoneda;

	// orden de compra nacional o importada
	@Column(name = "ORIGEN_OC")
	@SAP_FieldMapping(componente = "ORIGN", tipoDeDato = "CHAR", longitud = 3, decimalDato = 0)
	private String origenOC;

	private List<SAP_EKPO> partidas;

	@Column(name = "DESCRIPCION_PAIS")
	@SAP_FieldMapping(componente = "LANDX", tipoDeDato = "CHAR", longitud = 15, decimalDato = 0)
	private String descripcionPais;

	@Column(name = "VOLUMEN_MINIMO")
	@SAP_FieldMapping(componente = "MINVL", tipoDeDato = "QUAN", longitud = 17, decimalDato = 3)
	private String volumenMinimo;

	@Column(name = "VOLUMEN_MAXIMO")
	@SAP_FieldMapping(componente = "MAXVL", tipoDeDato = "QUAN", longitud = 17, decimalDato = 3)
	private String volumenMaximo;

	@Column(name = "SEMAFORO_VOLUMEN")
	@SAP_FieldMapping(componente = "XVL", tipoDeDato = "CHAR", longitud = 1, decimalDato = 0)
	private String semaforoVolumen;

	@Column(name = "PESO_NETO_MINIMO")
	@SAP_FieldMapping(componente = "MINWH", tipoDeDato = "QUAN", longitud = 17, decimalDato = 3)
	private String pesoNetoMinimo;

	@Column(name = "PESO_NETO_MAXIMO")
	@SAP_FieldMapping(componente = "MAXWH", tipoDeDato = "QUAN", longitud = 17, decimalDato = 3)
	private String pesoNetoMaximo;

	@Column(name = "SEMAFORO_PESO")
	@SAP_FieldMapping(componente = "XWH", tipoDeDato = "CHAR", longitud = 1, decimalDato = 0)
	private String semaforoPeso;

	@Column(name = "TIPO_DATOS")
	@SAP_FieldMapping(componente = "MEMORYTYPE", tipoDeDato = "CHAR", longitud = 1, decimalDato = 0)
	private String tipoDeDatos;
	
	@Column(name = "LIBERACION")
	@SAP_FieldMapping(componente = "FRGKE", tipoDeDato = "CHAR", longitud = 1, decimalDato = 0)
	private String liberacion;

	private String nombreFabrica;
	private boolean trialOrder;
	private String terminosDePago;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getNumeroOc() {
		return numeroOc;
	}

	public void setNumeroOc(String numeroOc) {
		this.numeroOc = numeroOc;
	}

	public String getFechaModificacion() {
		return fechaModificacion;
	}

	public void setFechaModificacion(String fechaModificacion) {
		this.fechaModificacion = fechaModificacion;
	}

	public String getHoraModificacion() {
		return horaModificacion;
	}

	public void setHoraModificacion(String horaModificacion) {
		this.horaModificacion = horaModificacion;
	}

	public String getSociedad() {
		return sociedad;
	}

	public void setSociedad(String sociedad) {
		this.sociedad = sociedad;
	}

	public String getTipoDocumentoCompras() {
		return tipoDocumentoCompras;
	}

	public void setTipoDocumentoCompras(String tipoDocumentoCompras) {
		this.tipoDocumentoCompras = tipoDocumentoCompras;
	}

	public String getFechaCreacion() {
		return fechaCreacion;
	}

	public void setFechaCreacion(String fechaCreacion) {
		this.fechaCreacion = fechaCreacion;
	}

	public String getNumeroCuentaProveedor() {
		return numeroCuentaProveedor;
	}

	public void setNumeroCuentaProveedor(String numeroCuentaProveedor) {
		this.numeroCuentaProveedor = numeroCuentaProveedor;
	}

	public String getNombreProveedor() {
		return nombreProveedor;
	}

	public void setNombreProveedor(String nombreProveedor) {
		this.nombreProveedor = nombreProveedor;
	}

	public String getClaveCondicionesPago() {
		return claveCondicionesPago;
	}

	public void setClaveCondicionesPago(String claveCondicionesPago) {
		this.claveCondicionesPago = claveCondicionesPago;
	}

	public String getAclaracionPropiaCondicionesPago() {
		return aclaracionPropiaCondicionesPago;
	}

	public void setAclaracionPropiaCondicionesPago(
			String aclaracionPropiaCondicionesPago) {
		this.aclaracionPropiaCondicionesPago = aclaracionPropiaCondicionesPago;
	}

	public String getCelulaCompras() {
		return celulaCompras;
	}

	public void setCelulaCompras(String celulaCompras) {
		this.celulaCompras = celulaCompras;
	}

	public String getDenominacionCompras() {
		return denominacionCompras;
	}

	public void setDenominacionCompras(String denominacionCompras) {
		this.denominacionCompras = denominacionCompras;
	}

	public String getGrupoCompras() {
		return grupoCompras;
	}

	public void setGrupoCompras(String grupoCompras) {
		this.grupoCompras = grupoCompras;
	}

	public String getNombreComprador() {
		return nombreComprador;
	}

	public void setNombreComprador(String nombreComprador) {
		this.nombreComprador = nombreComprador;
	}

	public String getMailComprador() {
		return mailComprador;
	}

	public void setMailComprador(String mailComprador) {
		this.mailComprador = mailComprador;
	}

	public String getReferencia() {
		return referencia;
	}

	public void setReferencia(String referencia) {
		this.referencia = referencia;
	}

	public String getIncoterms1() {
		return incoterms1;
	}

	public void setIncoterms1(String incoterms1) {
		this.incoterms1 = incoterms1;
	}

	public String getIncoterms2() {
		return incoterms2;
	}

	public void setIncoterms2(String incoterms2) {
		this.incoterms2 = incoterms2;
	}

	public String getTipoContenedor() {
		return tipoContenedor;
	}

	public void setTipoContenedor(String tipoContenedor) {
		this.tipoContenedor = tipoContenedor;
	}

	public String getValorNetoMonedaDoc() {
		return valorNetoMonedaDoc;
	}

	public void setValorNetoMonedaDoc(String valorNetoMonedaDoc) {
		this.valorNetoMonedaDoc = valorNetoMonedaDoc;
	}

	public String getClaveMoneda() {
		return claveMoneda;
	}

	public void setClaveMoneda(String claveMoneda) {
		this.claveMoneda = claveMoneda;
	}

	public String getContenedorIdeal() {
		return contenedorIdeal;
	}

	public void setContenedorIdeal(String contenedorIdeal) {
		this.contenedorIdeal = contenedorIdeal;
	}

	public String getPesoContenedor() {
		return pesoContenedor;
	}

	public void setPesoContenedor(String pesoContenedor) {
		this.pesoContenedor = pesoContenedor;
	}

	public String getVolumenContenedor() {
		return volumenContenedor;
	}

	public void setVolumenContenedor(String volumenContenedor) {
		this.volumenContenedor = volumenContenedor;
	}

	public String getPesoActual() {
		return pesoActual;
	}

	public void setPesoActual(String pesoActual) {
		this.pesoActual = pesoActual;
	}

	public String getVolumenActual() {
		return volumenActual;
	}

	public void setVolumenActual(String volumenActual) {
		this.volumenActual = volumenActual;
	}

	public String getPaisEmisorCertificadoOrigen() {
		return paisEmisorCertificadoOrigen;
	}

	public void setPaisEmisorCertificadoOrigen(
			String paisEmisorCertificadoOrigen) {
		this.paisEmisorCertificadoOrigen = paisEmisorCertificadoOrigen;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getDenominacionRegion() {
		return denominacionRegion;
	}

	public void setDenominacionRegion(String denominacionRegion) {
		this.denominacionRegion = denominacionRegion;
	}

	public String getJustificacionPrecio() {
		return justificacionPrecio;
	}

	public void setJustificacionPrecio(String justificacionPrecio) {
		this.justificacionPrecio = justificacionPrecio;
	}

	public String getPlanificadorNecesidades() {
		return planificadorNecesidades;
	}

	public void setPlanificadorNecesidades(String planificadorNecesidades) {
		this.planificadorNecesidades = planificadorNecesidades;
	}

	public String getDescripcionPlanificadorNecesidades() {
		return descripcionPlanificadorNecesidades;
	}

	public void setDescripcionPlanificadorNecesidades(
			String descripcionPlanificadorNecesidades) {
		this.descripcionPlanificadorNecesidades = descripcionPlanificadorNecesidades;
	}

	public String getCorreoPlanificador() {
		return correoPlanificador;
	}

	public void setCorreoPlanificador(String correoPlanificador) {
		this.correoPlanificador = correoPlanificador;
	}

	public String getSemaforoProveedor() {
		return semaforoProveedor;
	}

	public void setSemaforoProveedor(String semaforoProveedor) {
		this.semaforoProveedor = semaforoProveedor;
	}

	public String getSemaforoFabrica() {
		return semaforoFabrica;
	}

	public void setSemaforoFabrica(String semaforoFabrica) {
		this.semaforoFabrica = semaforoFabrica;
	}

	public String getSemaforoTerminoPago() {
		return semaforoTerminoPago;
	}

	public void setSemaforoTerminoPago(String semaforoTerminoPago) {
		this.semaforoTerminoPago = semaforoTerminoPago;
	}

	public String getSemaforoMoneda() {
		return semaforoMoneda;
	}

	public void setSemaforoMoneda(String semaforoMoneda) {
		this.semaforoMoneda = semaforoMoneda;
	}

	public String getTipoOperacion() {
		return tipoOperacion;
	}

	public void setTipoOperacion(String tipoOperacion) {
		this.tipoOperacion = tipoOperacion;
	}

	public String getNumeroCondicionDocumento() {
		return numeroCondicionDocumento;
	}

	public void setNumeroCondicionDocumento(String numeroCondicionDocumento) {
		this.numeroCondicionDocumento = numeroCondicionDocumento;
	}

	public String getIndicadorDeBorrado() {
		return indicadorDeBorrado;
	}

	public void setIndicadorDeBorrado(String indicadorDeBorrado) {
		this.indicadorDeBorrado = indicadorDeBorrado;
	}

	public String getNombreUsuario() {
		return nombreUsuario;
	}

	public void setNombreUsuario(String nombreUsuario) {
		this.nombreUsuario = nombreUsuario;
	}

	public List<SAP_PO_Textos> getTextos() {
		return textos;
	}

	public void setTextos(List<SAP_PO_Textos> textos) {
		this.textos = textos;
	}

	public List<SAP_PO_Interlocutores> getInterlocutores() {
		return interlocutores;
	}

	public void setInterlocutores(List<SAP_PO_Interlocutores> interlocutores) {
		this.interlocutores = interlocutores;
	}

	public String getCondicionesPagoProveedor() {
		return condicionesPagoProveedor;
	}

	public void setCondicionesPagoProveedor(String condicionesPagoProveedor) {
		this.condicionesPagoProveedor = condicionesPagoProveedor;
	}

	public String getDescripcionCondicionesPagoProveedor() {
		return descripcionCondicionesPagoProveedor;
	}

	public void setDescripcionCondicionesPagoProveedor(
			String descripcionCondicionesPagoProveedor) {
		this.descripcionCondicionesPagoProveedor = descripcionCondicionesPagoProveedor;
	}

	public String getGerenteCompras() {
		return gerenteCompras;
	}

	public void setGerenteCompras(String gerenteCompras) {
		this.gerenteCompras = gerenteCompras;
	}

	public String getNombreGerenteCompras() {
		return nombreGerenteCompras;
	}

	public void setNombreGerenteCompras(String nombreGerenteCompras) {
		this.nombreGerenteCompras = nombreGerenteCompras;
	}

	public String getMailGerenteCompras() {
		return mailGerenteCompras;
	}

	public void setMailGerenteCompras(String mailGerenteCompras) {
		this.mailGerenteCompras = mailGerenteCompras;
	}

	public String getClaveMonedaProveedor() {
		return claveMonedaProveedor;
	}

	public void setClaveMonedaProveedor(String claveMonedaProveedor) {
		this.claveMonedaProveedor = claveMonedaProveedor;
	}

	public String getIndicadorProceso() {
		return indicadorProceso;
	}

	public void setIndicadorProceso(String indicadorProceso) {
		this.indicadorProceso = indicadorProceso;
	}

	public String getIndicadorMasDeUnaMoneda() {
		return indicadorMasDeUnaMoneda;
	}

	public void setIndicadorMasDeUnaMoneda(String indicadorMasDeUnaMoneda) {
		this.indicadorMasDeUnaMoneda = indicadorMasDeUnaMoneda;
	}

	public String getOrigenOC() {
		return origenOC;
	}

	public void setOrigenOC(String origenOC) {
		this.origenOC = origenOC;
	}

	public List<SAP_EKPO> getPartidas() {
		return partidas;
	}

	public void setPartidas(List<SAP_EKPO> partidas) {
		this.partidas = partidas;
	}

	public Boolean getSemaforoComprador() {
		if ((this.getSemaforoTerminoPago() != null && this
				.getSemaforoTerminoPago().equals("V"))
				&& (this.getSemaforoMoneda() != null && this
						.getSemaforoMoneda().equals("V"))) {
			if (this.getInterlocutores() != null) {
				for (SAP_PO_Interlocutores interlocutor : this
						.getInterlocutores()) {
					if (interlocutor.getFuncionInterlocutor().equals("HR")) {
						if (this.getSemaforoFabrica().equals("R")) {
							return false;
						}
						break;
					}
				}
			}
			if (this.getPartidas() != null) {
				for (SAP_EKPO partida : this.getPartidas()) {
					if (partida.getActivosFijos().isEmpty()) {
						if (!partida.getSemaforoComprador()) {
							return false;
						}
					}
				}
			}
			return true;
		}
		return false;
	}

	public Boolean getSemaforoPlaneador() {
		if (this.getSemaforoMoneda().equals("V")) {
			for (SAP_EKPO partida : this.getPartidas()) {
				if (partida.getActivosFijos().isEmpty()) {
					if (!partida.getSemaforoPlaneador()) {
						return false;
					}
				}
			}
			return true;
		}
		return false;
	}

	public String getDescripcionPais() {
		return descripcionPais;
	}

	public void setDescripcionPais(String descripcionPais) {
		this.descripcionPais = descripcionPais;
	}

	public String getNombreFabrica() {
		return nombreFabrica;
	}

	public void setNombreFabrica(String nombreFabrica) {
		this.nombreFabrica = nombreFabrica;
	}

	public boolean isTrialOrder() {
		return trialOrder;
	}

	public void setTrialOrder(boolean trialOrder) {
		this.trialOrder = trialOrder;
	}

	public String getTerminosDePago() {
		return terminosDePago;
	}

	public void setTerminosDePago(String terminosDePago) {
		this.terminosDePago = terminosDePago;
	}

	public String getVolumenMinimo() {
		return volumenMinimo;
	}

	public void setVolumenMinimo(String volumenMinimo) {
		this.volumenMinimo = volumenMinimo;
	}

	public String getVolumenMaximo() {
		return volumenMaximo;
	}

	public void setVolumenMaximo(String volumenMaximo) {
		this.volumenMaximo = volumenMaximo;
	}

	public String getSemaforoVolumen() {
		return semaforoVolumen;
	}

	public void setSemaforoVolumen(String semaforoVolumen) {
		this.semaforoVolumen = semaforoVolumen;
	}

	public String getPesoNetoMinimo() {
		return pesoNetoMinimo;
	}

	public void setPesoNetoMinimo(String pesoNetoMinimo) {
		this.pesoNetoMinimo = pesoNetoMinimo;
	}

	public String getPesoNetoMaximo() {
		return pesoNetoMaximo;
	}

	public void setPesoNetoMaximo(String pesoNetoMaximo) {
		this.pesoNetoMaximo = pesoNetoMaximo;
	}

	public String getSemaforoPeso() {
		return semaforoPeso;
	}

	public void setSemaforoPeso(String semaforoPeso) {
		this.semaforoPeso = semaforoPeso;
	}

	public String getTipoDeDatos() {
		return tipoDeDatos;
	}

	public void setTipoDeDatos(String tipoDeDatos) {
		this.tipoDeDatos = tipoDeDatos;
	}

	public String getLiberacion() {
		return liberacion;
	}

	public void setLiberacion(String liberacion) {
		this.liberacion = liberacion;
	}
}
