package com.truper.infra.sap.pojo;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.Table;

import com.truper.infra.businessEntities.BaseBusinessEntity;
import com.truper.infra.sap.SAP_FieldInnerObject;
import com.truper.infra.sap.SAP_FieldMapping;

/**
 * @author Pablo Cruz Santos
 * @version 1.0
 * @date 29/10/2015
 */
@Entity
@Table(name = "srm_SAP_EKPO")
public class SAP_EKPO extends BaseBusinessEntity {

	private static final long serialVersionUID = 4127069053587844621L;

	@Id
	@Column(name = "ID", updatable = false, unique = true, insertable = false)
	private Integer id;

	@Column(name = "MANDANTE")
	@SAP_FieldMapping(componente = "MANDT", tipoDeDato = "CLNT", longitud = 3, decimalDato = 0)
	private String mandante;

	@Column(name = "DOCUMENTO_COMPRAS")
	@SAP_FieldMapping(componente = "EBELN", tipoDeDato = "CHAR", longitud = 10, decimalDato = 0)
	private String documentoCompras;

	@Column(name = "FECHA_MODIFICACION")
	@SAP_FieldMapping(componente = "AEDTM", tipoDeDato = "DATS", longitud = 8, decimalDato = 0)
	private String fechaModificacion;

	@Column(name = "HORA_MODIFICACION")
	@SAP_FieldMapping(componente = "UTIME", tipoDeDato = "TIMS", longitud = 6, decimalDato = 0)
	private String horaModificacion;

	@Column(name = "NUMERO_POSICION")
	@SAP_FieldMapping(componente = "EBELP", tipoDeDato = "NUMC", longitud = 5, decimalDato = 0)
	private String numeroPosicion;

	@Column(name = "ACTIVOS_FIJOS")
	@SAP_FieldMapping(componente = "LOEKZ", tipoDeDato = "CHAR", longitud = 1, decimalDato = 0)
	private String activosFijos;

	@Column(name = "TIPO_IMPUTACION")
	@SAP_FieldMapping(componente = "KNTTP", tipoDeDato = "CHAR", longitud = 1, decimalDato = 0)
	private String tipoImputacion;

	@Column(name = "TIPO_POSICION")
	@SAP_FieldMapping(componente = "PSTYP", tipoDeDato = "CHAR", longitud = 1, decimalDato = 0)
	private String tipoPosicion;

	@Column(name = "NUMERO_MATERIAL")
	@SAP_FieldMapping(componente = "MATNR", tipoDeDato = "CHAR", longitud = 18, decimalDato = 0)
	private String numeroMaterial;

	@Column(name = "TEXTO_MATERIAL")
	@SAP_FieldMapping(componente = "MAKTX", tipoDeDato = "CHAR", longitud = 40, decimalDato = 0)
	private String textoMaterial;

	@Column(name = "CANTIDAD_PEDIDO")
	@SAP_FieldMapping(componente = "MENGE", tipoDeDato = "QUAN", longitud = 13, decimalDato = 3)
	private String cantidadPedido;

	@Column(name = "UNIDAD_MEDIDA_PEDIDO")
	@SAP_FieldMapping(componente = "MEINS", tipoDeDato = "UNIT", longitud = 3, decimalDato = 0)
	private String unidadMedidaPedido;

	@Column(name = "TIPO_FECHA_ENTREGA")
	@SAP_FieldMapping(componente = "LPEIN", tipoDeDato = "CHAR", longitud = 1, decimalDato = 0)
	private String tipoFechaEntrega;

	@Column(name = "FECHA_ENTREGA")
	@SAP_FieldMapping(componente = "EINDT", tipoDeDato = "DATS", longitud = 8, decimalDato = 0)
	private String fechaEntrega;

	@Column(name = "PRECIO_NETO")
	@SAP_FieldMapping(componente = "NETPR", tipoDeDato = "CURR", longitud = 11, decimalDato = 2)
	private String precioNeto;

	@Column(name = "CLAVE_MONEDA")
	@SAP_FieldMapping(componente = "WAERS", tipoDeDato = "CUKY", longitud = 5, decimalDato = 0)
	private String claveMoneda;

	@Column(name = "CANTIDAD_BASE")
	@SAP_FieldMapping(componente = "PEINH", tipoDeDato = "DEC", longitud = 5, decimalDato = 0)
	private String cantidadBase;

	@Column(name = "UNIDAD_MEDIDA_PRECIO")
	@SAP_FieldMapping(componente = "BPRME", tipoDeDato = "UNIT", longitud = 3, decimalDato = 0)
	private String unidadMedidaPrecio;

	@Column(name = "GRUPO_ARTICULOS")
	@SAP_FieldMapping(componente = "MATKL", tipoDeDato = "CHAR", longitud = 9, decimalDato = 0)
	private String grupoArticulos;

	@Column(name = "DENOMINACION_GRUPO_ARTICULOS")
	@SAP_FieldMapping(componente = "WGBEZ", tipoDeDato = "CHAR", longitud = 20, decimalDato = 0)
	private String denominacionGrupoArticulos;

	@Column(name = "CENTRO")
	@SAP_FieldMapping(componente = "WERKS", tipoDeDato = "CHAR", longitud = 4, decimalDato = 0)
	private String centro;

	@Column(name = "NOMBRE")
	@SAP_FieldMapping(componente = "NAME1", tipoDeDato = "CHAR", longitud = 30, decimalDato = 0)
	private String nombre;

	@Column(name = "ALMACEN")
	@SAP_FieldMapping(componente = "LGORT", tipoDeDato = "CHAR", longitud = 4, decimalDato = 0)
	private String almacen;

	@Column(name = "DENOMINACION_ALMACEN")
	@SAP_FieldMapping(componente = "LGOBE", tipoDeDato = "CHAR", longitud = 16, decimalDato = 0)
	private String denominacionAlmacen;

	@Column(name = "NUMERO_LOTE")
	@SAP_FieldMapping(componente = "CHARG", tipoDeDato = "CHAR", longitud = 10, decimalDato = 0)
	private String numeroLote;

	@Column(name = "NUMERO_NECESIDAD")
	@SAP_FieldMapping(componente = "BEDNR", tipoDeDato = "CHAR", longitud = 10, decimalDato = 0)
	private String numeroNecesidad;

	@Column(name = "NOMBRE_SOLICITANTE")
	@SAP_FieldMapping(componente = "AFNAM", tipoDeDato = "CHAR", longitud = 12, decimalDato = 0)
	private String nombreSolicitante;

	@Column(name = "NUMERO_REGISTRO")
	@SAP_FieldMapping(componente = "INFNR", tipoDeDato = "CHAR", longitud = 10, decimalDato = 0)
	private String numeroRegistro;

	@Column(name = "POSICION_DEVOLUCION")
	@SAP_FieldMapping(componente = "RETPO", tipoDeDato = "CHAR", longitud = 1, decimalDato = 0)
	private String posicionDevolucion;

	@Column(name = "POSICION_SIN_CARGO")
	@SAP_FieldMapping(componente = "UMSON", tipoDeDato = "CHAR", longitud = 1, decimalDato = 0)
	private String posicionSinCargo;

	@Column(name = "NUMERO_SOLICITUD")
	@SAP_FieldMapping(componente = "BANFN", tipoDeDato = "CHAR", longitud = 10, decimalDato = 0)
	private String numeroSolicitud;

	@Column(name = "NUMERO_POSICION_SOLICITUD")
	@SAP_FieldMapping(componente = "BNFPO", tipoDeDato = "NUMC", longitud = 5, decimalDato = 0)
	private String numeroPosicionSolicitud;

	@Column(name = "NUMERO_CONTRATO")
	@SAP_FieldMapping(componente = "KONNR", tipoDeDato = "CHAR", longitud = 10, decimalDato = 0)
	private String numeroContrato;

	@Column(name = "NUMERO_POSICION_CONTRATO")
	@SAP_FieldMapping(componente = "KTPNR", tipoDeDato = "NUMC", longitud = 5, decimalDato = 0)
	private String numeroPosicionContrato;

	@Column(name = "NUMERO_PETICION")
	@SAP_FieldMapping(componente = "ANFNR", tipoDeDato = "CHAR", longitud = 10, decimalDato = 0)
	private String numeroPeticion;

	@Column(name = "NUMERO_POSICION_PETICION")
	@SAP_FieldMapping(componente = "ANFPS", tipoDeDato = "NUMC", longitud = 5, decimalDato = 0)
	private String numeroPosicionPeticion;

	@Column(name = "NUMERO_DOCUMENTO")
	@SAP_FieldMapping(componente = "REFBS", tipoDeDato = "CHAR", longitud = 10, decimalDato = 0)
	private String numeroDocumento;

	@Column(name = "NUMERO_POSICION_DOCUMENTO")
	@SAP_FieldMapping(componente = "REFPS", tipoDeDato = "NUMC", longitud = 5, decimalDato = 0)
	private String numeroPosicionDocumento;

	@Column(name = "POSICION_SUPERIOR_DOCUMENTO")
	@SAP_FieldMapping(componente = "UEBPO", tipoDeDato = "NUMC", longitud = 5, decimalDato = 0)
	private String posicionSuperiorDocumento;

	@Column(name = "TIPO_SUBPOSICION_DOCUMENTO")
	@SAP_FieldMapping(componente = "UPTYP", tipoDeDato = "CHAR", longitud = 1, decimalDato = 0)
	private String tipoSubPosicionDocumento;

	@Column(name = "PRECIO_UNITARIO")
	@SAP_FieldMapping(componente = "UNIPR", tipoDeDato = "CURR", longitud = 11, decimalDato = 2)
	private String precioUnitario;

	@Column(name = "INCOTERMS1")
	@SAP_FieldMapping(componente = "INCO1", tipoDeDato = "CHAR", longitud = 3, decimalDato = 0)
	private String incoterms1;

	@Column(name = "INCOTERMS2")
	@SAP_FieldMapping(componente = "INCO2", tipoDeDato = "CHAR", longitud = 28, decimalDato = 0)
	private String incoterms2;

	@Column(name = "VALOR_NETO")
	@SAP_FieldMapping(componente = "NETWR", tipoDeDato = "CURR", longitud = 15, decimalDato = 2)
	private String valorNeto;

	@Column(name = "INDICADOR_IVA")
	@SAP_FieldMapping(componente = "MWSKZ", tipoDeDato = "CHAR", longitud = 2, decimalDato = 0)
	private String indicadorIva;

	@Column(name = "VALOR_REDONDEO")
	@SAP_FieldMapping(componente = "BSTRF", tipoDeDato = "QUAN", longitud = 13, decimalDato = 3)
	private String valorRedondeo;

	@Column(name = "PLAZO_ENTREGA")
	@SAP_FieldMapping(componente = "PLIFZ", tipoDeDato = "DEC", longitud = 5, decimalDato = 0)
	private String plazoEntrega;

	@Column(name = "UNIDAD_VOLUMEN")
	@SAP_FieldMapping(componente = "VOLEH", tipoDeDato = "UNIT", longitud = 3, decimalDato = 0)
	private String unidadVolumen;

	@Column(name = "DIAS_QUEMADA")
	@SAP_FieldMapping(componente = "DQUEM", tipoDeDato = "DEC", longitud = 5, decimalDato = 0)
	private String diasQuemada;

	@Column(name = "SEMAFORO_QUEMADA")
	@SAP_FieldMapping(componente = "XQUEM", tipoDeDato = "CHAR", longitud = 1, decimalDato = 0)
	private String semaforoQuemada;

	@Column(name = "SEMAFORO_CANTIDAD")
	@SAP_FieldMapping(componente = "XMNGE", tipoDeDato = "CHAR", longitud = 1, decimalDato = 0)
	private String semaforoCantidad;

	@Column(name = "SEMAFORO_PRECIO_NETO")
	@SAP_FieldMapping(componente = "XNTPR", tipoDeDato = "CHAR", longitud = 1, decimalDato = 0)
	private String semaforoPrecioNeto;

	@Column(name = "SEMAFORO_MONEDA")
	@SAP_FieldMapping(componente = "XWAER", tipoDeDato = "CHAR", longitud = 1, decimalDato = 0)
	private String semaforoMoneda;

	@Column(name = "INDICADOR_PROCESO")
	@SAP_FieldMapping(componente = "STEP1", tipoDeDato = "CHAR", longitud = 1, decimalDato = 0)
	private String indicadorProceso;

	@Column(name = "INDICADOR_BORRADO")
	@SAP_FieldMapping(componente = "LOEVM", tipoDeDato = "CHAR", longitud = 1, decimalDato = 0)
	private String indicadorBorrado;

	@Column(name = "PESO_NETO")
	@SAP_FieldMapping(componente = "NTGEW", tipoDeDato = "QUAN", longitud = 13, decimalDato = 3)
	private String pesoNeto;

	@Column(name = "UNIDAD_PESO")
	@SAP_FieldMapping(componente = "GEWEI", tipoDeDato = "UNIT", longitud = 3, decimalDato = 0)
	private String unidadPeso;

	@Column(name = "VOLUMEN")
	@SAP_FieldMapping(componente = "VOLUM", tipoDeDato = "QUAN", longitud = 13, decimalDato = 3)
	private String volumen;

	// @OneToMany
	// @JoinColumn(name = "ID_SAP_EKPO")
	@SAP_FieldInnerObject(componente = "NT_TEXT")
	private List<SAP_EKPO_Texto> textos;

	/*************************************************************************/

	@Column(name = "LOTE_MINIMO")
	@SAP_FieldMapping(componente = "BSTMI", tipoDeDato = "QUAN", longitud = 13, decimalDato = 3)
	private String loteMinimo;

	@Column(name = "PRECIO_NETO_REGISTRO")
	@SAP_FieldMapping(componente = "NETPL", tipoDeDato = "CURR", longitud = 11, decimalDato = 2)
	private String precioNetoRegistro;

	@Column(name = "CLAVE_MONEDA_REGISTRO")
	@SAP_FieldMapping(componente = "WAERL", tipoDeDato = "CUKY", longitud = 5, decimalDato = 0)
	private String claveMonedaRegistro;

	@Column(name = "ENTREGA_FINAL")
	@SAP_FieldMapping(componente = "ELIKZ", tipoDeDato = "CHAR", longitud = 1, decimalDato = 0)
	private String entregaFinal;

	@Column(name = "TIPO_MATERIAL")
	@SAP_FieldMapping(componente = "MTART", tipoDeDato = "CHAR", longitud = 4, decimalDato = 0)
	private String tipoMaterial;

	// MAKTX_EN CHAR 40 Texto breve de material en Ingles
	@Column(name = "TEXTO_MATERIAL_EN")
	@SAP_FieldMapping(componente = "MAKTX_EN", tipoDeDato = "CHAR", longitud = 40, decimalDato = 0)
	private String textoMaterialEN;

	// MAKTX_FI CHAR 40 Clave
	@Column(name = "CLAVE_MATERIAL")
	@SAP_FieldMapping(componente = "MAKTX_FI", tipoDeDato = "CHAR", longitud = 40, decimalDato = 0)
	private String claveMaterial;

	@JoinColumns({
			@JoinColumn(table = "srm_SAP_PO_CALC", name = "DOCUMENTO_COMPRAS", referencedColumnName = "DOCUMENTO_COMPRAS"),
			@JoinColumn(table = "srm_SAP_PO_CALC", name = "NUMERO_POSICION", referencedColumnName = "POSICION_DOCUMENTO_COMPRAS"),
			@JoinColumn(table = "srm_SAP_PO_CALC", name = "FECHA_MODIFICACION", referencedColumnName = "FECHA_MODIFICACION"),
			@JoinColumn(table = "srm_SAP_PO_CALC", name = "HORA_MODIFICACION", referencedColumnName = "HORA_MODIFICACION") })
	private SAP_PO_Calc calc;

	// NT_EKES
	@JoinColumns({
			@JoinColumn(table = "srm_SAP_PO_PROFORMA", name = "DOCUMENTO_COMPRAS", referencedColumnName = "NUMERO_OC"),
			@JoinColumn(table = "srm_SAP_PO_PROFORMA", name = "FECHA_MODIFICACION", referencedColumnName = "FECHA_MODIFICACION"),
			@JoinColumn(table = "srm_SAP_PO_PROFORMA", name = "HORA_MODIFICACION", referencedColumnName = "HORA_MODIFICACION") })
	@SAP_FieldInnerObject(componente = "NT_EKES")
	private transient List<SAP_PO_Proforma> confirmaciones;

	public SAP_EKPO() {
		super();
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getMandante() {
		return mandante;
	}

	public void setMandante(String mandante) {
		this.mandante = mandante;
	}

	public String getDocumentoCompras() {
		return documentoCompras;
	}

	public void setDocumentoCompras(String documentoCompras) {
		this.documentoCompras = documentoCompras;
	}

	public String getFechaModificacion() {
		return fechaModificacion;
	}

	public void setFechaModificacion(String fechaModificacion) {
		this.fechaModificacion = fechaModificacion;
	}

	public String getHoraModificacion() {
		return horaModificacion;
	}

	public void setHoraModificacion(String horaModificacion) {
		this.horaModificacion = horaModificacion;
	}

	public String getNumeroPosicion() {
		return numeroPosicion;
	}

	public void setNumeroPosicion(String numeroPosicion) {
		this.numeroPosicion = numeroPosicion;
	}

	public String getActivosFijos() {
		return activosFijos;
	}

	public void setActivosFijos(String activosFijos) {
		this.activosFijos = activosFijos;
	}

	public String getTipoImputacion() {
		return tipoImputacion;
	}

	public void setTipoImputacion(String tipoImputacion) {
		this.tipoImputacion = tipoImputacion;
	}

	public String getTipoPosicion() {
		return tipoPosicion;
	}

	public void setTipoPosicion(String tipoPosicion) {
		this.tipoPosicion = tipoPosicion;
	}

	public String getNumeroMaterial() {
		return numeroMaterial;
	}

	public void setNumeroMaterial(String numeroMaterial) {
		this.numeroMaterial = numeroMaterial;
	}

	public String getTextoMaterial() {
		return textoMaterial;
	}

	public void setTextoMaterial(String textoMaterial) {
		this.textoMaterial = textoMaterial;
	}

	public String getCantidadPedido() {
		return cantidadPedido;
	}

	public void setCantidadPedido(String cantidadPedido) {
		this.cantidadPedido = cantidadPedido;
	}

	public String getUnidadMedidaPedido() {
		return unidadMedidaPedido;
	}

	public void setUnidadMedidaPedido(String unidadMedidaPedido) {
		this.unidadMedidaPedido = unidadMedidaPedido;
	}

	public String getTipoFechaEntrega() {
		return tipoFechaEntrega;
	}

	public void setTipoFechaEntrega(String tipoFechaEntrega) {
		this.tipoFechaEntrega = tipoFechaEntrega;
	}

	public String getFechaEntrega() {
		return fechaEntrega;
	}

	public void setFechaEntrega(String fechaEntrega) {
		this.fechaEntrega = fechaEntrega;
	}

	public String getPrecioNeto() {
		return precioNeto;
	}

	public void setPrecioNeto(String precioNeto) {
		this.precioNeto = precioNeto;
	}

	public String getClaveMoneda() {
		return claveMoneda;
	}

	public void setClaveMoneda(String claveMoneda) {
		this.claveMoneda = claveMoneda;
	}

	public String getCantidadBase() {
		return cantidadBase;
	}

	public void setCantidadBase(String cantidadBase) {
		this.cantidadBase = cantidadBase;
	}

	public String getUnidadMedidaPrecio() {
		return unidadMedidaPrecio;
	}

	public void setUnidadMedidaPrecio(String unidadMedidaPrecio) {
		this.unidadMedidaPrecio = unidadMedidaPrecio;
	}

	public String getGrupoArticulos() {
		return grupoArticulos;
	}

	public void setGrupoArticulos(String grupoArticulos) {
		this.grupoArticulos = grupoArticulos;
	}

	public String getDenominacionGrupoArticulos() {
		return denominacionGrupoArticulos;
	}

	public void setDenominacionGrupoArticulos(String denominacionGrupoArticulos) {
		this.denominacionGrupoArticulos = denominacionGrupoArticulos;
	}

	public String getCentro() {
		return centro;
	}

	public void setCentro(String centro) {
		this.centro = centro;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getAlmacen() {
		return almacen;
	}

	public void setAlmacen(String almacen) {
		this.almacen = almacen;
	}

	public String getDenominacionAlmacen() {
		return denominacionAlmacen;
	}

	public void setDenominacionAlmacen(String denominacionAlmacen) {
		this.denominacionAlmacen = denominacionAlmacen;
	}

	public String getNumeroLote() {
		return numeroLote;
	}

	public void setNumeroLote(String numeroLote) {
		this.numeroLote = numeroLote;
	}

	public String getNumeroNecesidad() {
		return numeroNecesidad;
	}

	public void setNumeroNecesidad(String numeroNecesidad) {
		this.numeroNecesidad = numeroNecesidad;
	}

	public String getNombreSolicitante() {
		return nombreSolicitante;
	}

	public void setNombreSolicitante(String nombreSolicitante) {
		this.nombreSolicitante = nombreSolicitante;
	}

	public String getNumeroRegistro() {
		return numeroRegistro;
	}

	public void setNumeroRegistro(String numeroRegistro) {
		this.numeroRegistro = numeroRegistro;
	}

	public String getPosicionDevolucion() {
		return posicionDevolucion;
	}

	public void setPosicionDevolucion(String posicionDevolucion) {
		this.posicionDevolucion = posicionDevolucion;
	}

	public String getPosicionSinCargo() {
		return posicionSinCargo;
	}

	public void setPosicionSinCargo(String posicionSinCargo) {
		this.posicionSinCargo = posicionSinCargo;
	}

	public String getNumeroSolicitud() {
		return numeroSolicitud;
	}

	public void setNumeroSolicitud(String numeroSolicitud) {
		this.numeroSolicitud = numeroSolicitud;
	}

	public String getNumeroPosicionSolicitud() {
		return numeroPosicionSolicitud;
	}

	public void setNumeroPosicionSolicitud(String numeroPosicionSolicitud) {
		this.numeroPosicionSolicitud = numeroPosicionSolicitud;
	}

	public String getNumeroContrato() {
		return numeroContrato;
	}

	public void setNumeroContrato(String numeroContrato) {
		this.numeroContrato = numeroContrato;
	}

	public String getNumeroPosicionContrato() {
		return numeroPosicionContrato;
	}

	public void setNumeroPosicionContrato(String numeroPosicionContrato) {
		this.numeroPosicionContrato = numeroPosicionContrato;
	}

	public String getNumeroPeticion() {
		return numeroPeticion;
	}

	public void setNumeroPeticion(String numeroPeticion) {
		this.numeroPeticion = numeroPeticion;
	}

	public String getNumeroPosicionPeticion() {
		return numeroPosicionPeticion;
	}

	public void setNumeroPosicionPeticion(String numeroPosicionPeticion) {
		this.numeroPosicionPeticion = numeroPosicionPeticion;
	}

	public String getNumeroDocumento() {
		return numeroDocumento;
	}

	public void setNumeroDocumento(String numeroDocumento) {
		this.numeroDocumento = numeroDocumento;
	}

	public String getNumeroPosicionDocumento() {
		return numeroPosicionDocumento;
	}

	public void setNumeroPosicionDocumento(String numeroPosicionDocumento) {
		this.numeroPosicionDocumento = numeroPosicionDocumento;
	}

	public String getPosicionSuperiorDocumento() {
		return posicionSuperiorDocumento;
	}

	public void setPosicionSuperiorDocumento(String posicionSuperiorDocumento) {
		this.posicionSuperiorDocumento = posicionSuperiorDocumento;
	}

	public String getTipoSubPosicionDocumento() {
		return tipoSubPosicionDocumento;
	}

	public void setTipoSubPosicionDocumento(String tipoSubPosicionDocumento) {
		this.tipoSubPosicionDocumento = tipoSubPosicionDocumento;
	}

	public String getPrecioUnitario() {
		return precioUnitario;
	}

	public void setPrecioUnitario(String precioUnitario) {
		this.precioUnitario = precioUnitario;
	}

	public String getIncoterms1() {
		return incoterms1;
	}

	public void setIncoterms1(String incoterms1) {
		this.incoterms1 = incoterms1;
	}

	public String getIncoterms2() {
		return incoterms2;
	}

	public void setIncoterms2(String incoterms2) {
		this.incoterms2 = incoterms2;
	}

	public String getValorNeto() {
		return valorNeto;
	}

	public void setValorNeto(String valorNeto) {
		this.valorNeto = valorNeto;
	}

	public String getIndicadorIva() {
		return indicadorIva;
	}

	public void setIndicadorIva(String indicadorIva) {
		this.indicadorIva = indicadorIva;
	}

	public String getValorRedondeo() {
		return valorRedondeo;
	}

	public void setValorRedondeo(String valorRedondeo) {
		this.valorRedondeo = valorRedondeo;
	}

	public String getPlazoEntrega() {
		return plazoEntrega;
	}

	public void setPlazoEntrega(String plazoEntrega) {
		this.plazoEntrega = plazoEntrega;
	}

	public String getUnidadVolumen() {
		return unidadVolumen;
	}

	public void setUnidadVolumen(String unidadVolumen) {
		this.unidadVolumen = unidadVolumen;
	}

	public String getDiasQuemada() {
		return diasQuemada;
	}

	public void setDiasQuemada(String diasQuemada) {
		this.diasQuemada = diasQuemada;
	}

	public String getSemaforoQuemada() {
		return semaforoQuemada;
	}

	public void setSemaforoQuemada(String semaforoQuemada) {
		this.semaforoQuemada = semaforoQuemada;
	}

	public String getSemaforoCantidad() {
		return semaforoCantidad;
	}

	public void setSemaforoCantidad(String semaforoCantidad) {
		this.semaforoCantidad = semaforoCantidad;
	}

	public String getSemaforoPrecioNeto() {
		return semaforoPrecioNeto;
	}

	public void setSemaforoPrecioNeto(String semaforoPrecioNeto) {
		this.semaforoPrecioNeto = semaforoPrecioNeto;
	}

	public String getSemaforoMoneda() {
		return semaforoMoneda;
	}

	public void setSemaforoMoneda(String semaforoMoneda) {
		this.semaforoMoneda = semaforoMoneda;
	}

	public String getIndicadorProceso() {
		return indicadorProceso;
	}

	public void setIndicadorProceso(String indicadorProceso) {
		this.indicadorProceso = indicadorProceso;
	}

	public String getIndicadorBorrado() {
		return indicadorBorrado;
	}

	public void setIndicadorBorrado(String indicadorBorrado) {
		this.indicadorBorrado = indicadorBorrado;
	}

	public String getPesoNeto() {
		return pesoNeto;
	}

	public void setPesoNeto(String pesoNeto) {
		this.pesoNeto = pesoNeto;
	}

	public String getUnidadPeso() {
		return unidadPeso;
	}

	public void setUnidadPeso(String unidadPeso) {
		this.unidadPeso = unidadPeso;
	}

	public String getVolumen() {
		return volumen;
	}

	public void setVolumen(String volumen) {
		this.volumen = volumen;
	}

	public List<SAP_EKPO_Texto> getTextos() {
		return textos;
	}

	public void setTextos(List<SAP_EKPO_Texto> textos) {
		this.textos = textos;
	}

	public String getLoteMinimo() {
		return loteMinimo;
	}

	public void setLoteMinimo(String loteMinimo) {
		this.loteMinimo = loteMinimo;
	}

	public String getPrecioNetoRegistro() {
		return precioNetoRegistro;
	}

	public void setPrecioNetoRegistro(String precioNetoRegistro) {
		this.precioNetoRegistro = precioNetoRegistro;
	}

	public String getClaveMonedaRegistro() {
		return claveMonedaRegistro;
	}

	public void setClaveMonedaRegistro(String claveMonedaRegistro) {
		this.claveMonedaRegistro = claveMonedaRegistro;
	}

	public SAP_PO_Calc getCalc() {
		return calc;
	}

	public void setCalc(SAP_PO_Calc calc) {
		this.calc = calc;
	}

	public List<SAP_PO_Proforma> getConfirmaciones() {
		return confirmaciones;
	}

	public void setConfirmaciones(List<SAP_PO_Proforma> confirmaciones) {
		this.confirmaciones = confirmaciones;
	}

	public Boolean getSemaforoComprador() {
		if (this.getSemaforoPrecioNeto().equals("V") && this.getCalc() != null
				&& this.getCalc().getSemaforoDiasInventario().equals("V")
				&& this.getCalc().getSemaforoInventarioArribo().equals("V")
				&& this.getCalc().getSemaforoPicoArribo().equals("V")) {
			return true;
		}
		return false;
	}

	public Boolean getSemaforoPlaneador() {
		if (this.getSemaforoCantidad().equals("V") && this.getCalc() != null
				&& this.getCalc().getSemaforoDiasInventario().equals("V")
				&& this.getCalc().getSemaforoInventarioArribo().equals("V")
				&& this.getCalc().getSemaforoPicoArribo().equals("V")) {
			return true;
		}
		return false;
	}

	public String getTipoMaterial() {
		return tipoMaterial;
	}

	public void setTipoMaterial(String tipoMaterial) {
		this.tipoMaterial = tipoMaterial;
	}

	public String getEntregaFinal() {
		return entregaFinal;
	}

	public void setEntregaFinal(String entregaFinal) {
		this.entregaFinal = entregaFinal;
	}

	public String getTextoMaterialEN() {
		return textoMaterialEN;
	}

	public void setTextoMaterialEN(String textoMaterialEN) {
		this.textoMaterialEN = textoMaterialEN;
	}

	public String getClaveMaterial() {
		return claveMaterial;
	}

	public void setClaveMaterial(String claveMaterial) {
		this.claveMaterial = claveMaterial;
	}

}
