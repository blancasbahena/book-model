package com.truper.infra.sap.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.truper.infra.sap.SAP_FieldMapping;

@Entity
@Table(name = "srm_SAP_PO_INTERLOCUTORES")
public class SAP_PO_Interlocutores {

	@Id
	@Column(name = "ID", updatable = false, unique = true, insertable = false)
	private Integer id;

	@Column(name = "MANDANTE")
	@SAP_FieldMapping(componente = "MANDT", tipoDeDato = "CLNT", longitud = 3, decimalDato = 0)
	private String mandante;
	
	@Column(name = "NUMERO_OC")
	@SAP_FieldMapping(componente = "EBELN", tipoDeDato = "CHAR", longitud = 10, decimalDato = 0)
	private String numeroOC;
	
	@Column(name = "FECHA_MODIFICACION")
	@SAP_FieldMapping(componente = "AEDTM", tipoDeDato = "DATS", longitud = 8, decimalDato = 0)
	private String fechaModificacion;
	
	@Column(name = "HORA_MODIFICACION")
	@SAP_FieldMapping(componente = "UTIME", tipoDeDato = "TIMS", longitud = 6, decimalDato = 0)
	private String horaModificacion;
	
	@Column(name = "FUNCION_INTERLOCUTOR")
	@SAP_FieldMapping(componente = "PARVW", tipoDeDato = "CHAR", longitud = 2, decimalDato = 0)
	private String funcionInterlocutor;
	
	@Column(name = "DENOMINACION")
	@SAP_FieldMapping(componente = "VTEXT", tipoDeDato = "CHAR", longitud = 20, decimalDato = 0)
	private String denominacion;
	
	@Column(name = "REFERENCIA_OTRO_PROVEEDOR")
	@SAP_FieldMapping(componente = "LIFN2", tipoDeDato = "CHAR", longitud = 10, decimalDato = 0)
	private String referenciaOtroProveedor;
	
	@Column(name = "NOMBRE")
	@SAP_FieldMapping(componente = "NAME1", tipoDeDato = "CHAR", longitud = 30, decimalDato = 0)
	private String nombre;
	
	@Column(name = "INIDICADOR_BORRADO")
	@SAP_FieldMapping(componente = "LOEVM", tipoDeDato = "CHAR", longitud = 1, decimalDato = 0)
	private String indicadorBorrado;
	
	/*************************************************************************/
	
	@Column(name = "INDICADOR_PROCESO")
	@SAP_FieldMapping(componente = "STEP1", tipoDeDato = "CHAR", longitud = 1, decimalDato = 0)
	private String indicadorProceso;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getMandante() {
		return mandante;
	}

	public void setMandante(String mandante) {
		this.mandante = mandante;
	}

	public String getNumeroOC() {
		return numeroOC;
	}

	public void setNumeroOC(String numeroOC) {
		this.numeroOC = numeroOC;
	}

	public String getFechaModificacion() {
		return fechaModificacion;
	}

	public void setFechaModificacion(String fechaModificacion) {
		this.fechaModificacion = fechaModificacion;
	}

	public String getHoraModificacion() {
		return horaModificacion;
	}

	public void setHoraModificacion(String horaModificacion) {
		this.horaModificacion = horaModificacion;
	}

	public String getFuncionInterlocutor() {
		return funcionInterlocutor;
	}

	public void setFuncionInterlocutor(String funcionInterlocutor) {
		this.funcionInterlocutor = funcionInterlocutor;
	}

	public String getDenominacion() {
		return denominacion;
	}

	public void setDenominacion(String denominacion) {
		this.denominacion = denominacion;
	}

	public String getReferenciaOtroProveedor() {
		return referenciaOtroProveedor;
	}

	public void setReferenciaOtroProveedor(String referenciaOtroProveedor) {
		this.referenciaOtroProveedor = referenciaOtroProveedor;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getIndicadorBorrado() {
		return indicadorBorrado;
	}

	public void setIndicadorBorrado(String indicadorBorrado) {
		this.indicadorBorrado = indicadorBorrado;
	}

	public String getIndicadorProceso() {
		return indicadorProceso;
	}

	public void setIndicadorProceso(String indicadorProceso) {
		this.indicadorProceso = indicadorProceso;
	}
}
