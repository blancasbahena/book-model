package com.truper.infra.sap.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.truper.infra.businessEntities.BaseBusinessEntity;
import com.truper.infra.sap.SAP_FieldMapping;

/**
 * @author Pablo Cruz Santos
 * @version 1.0
 * @date 06/11/2015
 */
@Entity
@Table(name = "srm_SAP_PO_CALC")
public class SAP_PO_Calc extends BaseBusinessEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = -78788821867211424L;

	@Id
	@Column(name = "ID", updatable = false, unique = true, insertable = false)
	private Integer id;

	@Column(name = "MANDANTE")
	@SAP_FieldMapping(componente = "MANDT", tipoDeDato = "CLNT", longitud = 3, decimalDato = 0)
	private String mandante;

	@Column(name = "DOCUMENTO_COMPRAS")
	@SAP_FieldMapping(componente = "EBELN", tipoDeDato = "CHAR", longitud = 10, decimalDato = 0)
	private String documentoCompras;

	@Column(name = "POSICION_DOCUMENTO_COMPRAS")
	@SAP_FieldMapping(componente = "EBELP", tipoDeDato = "NUMC", longitud = 5, decimalDato = 0)
	private String posicionDocumentoCompras;

	@Column(name = "FECHA_MODIFICACION")
	@SAP_FieldMapping(componente = "AEDTM", tipoDeDato = "DATS", longitud = 8, decimalDato = 0)
	private String fechaModificacion;

	@Column(name = "HORA_MODIFICACION")
	@SAP_FieldMapping(componente = "UTIME", tipoDeDato = "TIMS", longitud = 6, decimalDato = 0)
	private String horaModificacion;

	@Column(name = "DIAS_PO")
	@SAP_FieldMapping(componente = "ID", tipoDeDato = "INT4", longitud = 14, decimalDato = 0)
	private String diasPO;

	@Column(name = "DIAS_INVENTARIO_ARRIBO")
	@SAP_FieldMapping(componente = "IDA", tipoDeDato = "INT4", longitud = 14, decimalDato = 0)
	private String diasInventarioArribo;

	@Column(name = "PA")
	@SAP_FieldMapping(componente = "PA", tipoDeDato = "INT4", longitud = 14, decimalDato = 0)
	private String picoArribo;

	@Column(name = "PT")
	@SAP_FieldMapping(componente = "PT", tipoDeDato = "INT4", longitud = 14, decimalDato = 0)
	private String picoTeorico;

	@Column(name = "XID")
	@SAP_FieldMapping(componente = "XID", tipoDeDato = "CHAR", longitud = 1, decimalDato = 0)
	private String semaforoDiasInventario;

	@Column(name = "XIDA")
	@SAP_FieldMapping(componente = "XIDA", tipoDeDato = "CHAR", longitud = 1, decimalDato = 0)
	private String semaforoInventarioArribo;

	@Column(name = "XPA")
	@SAP_FieldMapping(componente = "XPA", tipoDeDato = "CHAR", longitud = 1, decimalDato = 0)
	private String semaforoPicoArribo;

	@Column(name = "XPT")
	@SAP_FieldMapping(componente = "XPT", tipoDeDato = "CHAR", longitud = 1, decimalDato = 0)
	private String semaforoPicoTeorico;

	@Column(name = "LOEVM")
	@SAP_FieldMapping(componente = "LOEVM", tipoDeDato = "CHAR", longitud = 1, decimalDato = 0)
	private String indicadorBorrado;

	/**************************************************************************/

	@Column(name = "LIMITE_SUPERIOR")
	@SAP_FieldMapping(componente = "IDLS", tipoDeDato = "DEC", longitud = 4, decimalDato = 0)
	private String limiteSuperior;

	@Column(name = "LIMITE_INFERIOR_DIAS")
	@SAP_FieldMapping(componente = "IDALI", tipoDeDato = "DEC", longitud = 4, decimalDato = 0)
	private String limiteInferiorDias;

	@Column(name = "LIMITE_SUPERIOR_DIAS")
	@SAP_FieldMapping(componente = "IDALS", tipoDeDato = "DEC", longitud = 4, decimalDato = 0)
	private String limiteSuperiorDias;

	@Column(name = "LIMITE_INFERIOR_PICO")
	@SAP_FieldMapping(componente = "PALI", tipoDeDato = "DEC", longitud = 4, decimalDato = 0)
	private String limiteInferiorPico;

	@Column(name = "LIMITE_SUPERIOR_PICO")
	@SAP_FieldMapping(componente = "PALS", tipoDeDato = "DEC", longitud = 4, decimalDato = 0)
	private String limiteSuperiorPico;

	@Column(name = "DIAS_SAFETY_STOCK")
	@SAP_FieldMapping(componente = "DIAS_SS", tipoDeDato = "INT4", longitud = 11, decimalDato = 0)
	private String diasSafetyStock;
	
	@Column(name = "MONTO_SOBREINVENTARIO")
	@SAP_FieldMapping(componente = "SOBREINV", tipoDeDato = "DEC", longitud = 18, decimalDato = 2)
	private String montoDeSobreinventario;

	public SAP_PO_Calc() {
		super();
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getMandante() {
		return mandante;
	}

	public void setMandante(String mandante) {
		this.mandante = mandante;
	}

	public String getDocumentoCompras() {
		return documentoCompras;
	}

	public void setDocumentoCompras(String documentoCompras) {
		this.documentoCompras = documentoCompras;
	}

	public String getPosicionDocumentoCompras() {
		return posicionDocumentoCompras;
	}

	public void setPosicionDocumentoCompras(String posicionDocumentoCompras) {
		this.posicionDocumentoCompras = posicionDocumentoCompras;
	}

	public String getFechaModificacion() {
		return fechaModificacion;
	}

	public void setFechaModificacion(String fechaModificacion) {
		this.fechaModificacion = fechaModificacion;
	}

	public String getHoraModificacion() {
		return horaModificacion;
	}

	public void setHoraModificacion(String horaModificacion) {
		this.horaModificacion = horaModificacion;
	}

	public String getDiasPO() {
		return diasPO;
	}

	public void setDiasPO(String diasPO) {
		this.diasPO = diasPO;
	}

	public String getDiasInventarioArribo() {
		return diasInventarioArribo;
	}

	public void setDiasInventarioArribo(String diasInventarioArribo) {
		this.diasInventarioArribo = diasInventarioArribo;
	}

	public String getPicoArribo() {
		return picoArribo;
	}

	public void setPicoArribo(String picoArribo) {
		this.picoArribo = picoArribo;
	}

	public String getPicoTeorico() {
		return picoTeorico;
	}

	public void setPicoTeorico(String picoTeorico) {
		this.picoTeorico = picoTeorico;
	}

	public String getSemaforoDiasInventario() {
		return semaforoDiasInventario;
	}

	public void setSemaforoDiasInventario(String semaforoDiasInventario) {
		this.semaforoDiasInventario = semaforoDiasInventario;
	}

	public String getSemaforoInventarioArribo() {
		return semaforoInventarioArribo;
	}

	public void setSemaforoInventarioArribo(String semaforoInventarioArribo) {
		this.semaforoInventarioArribo = semaforoInventarioArribo;
	}

	public String getSemaforoPicoArribo() {
		return semaforoPicoArribo;
	}

	public void setSemaforoPicoArribo(String semaforoPicoArribo) {
		this.semaforoPicoArribo = semaforoPicoArribo;
	}

	public String getSemaforoPicoTeorico() {
		return semaforoPicoTeorico;
	}

	public void setSemaforoPicoTeorico(String semaforoPicoTeorico) {
		this.semaforoPicoTeorico = semaforoPicoTeorico;
	}

	public String getIndicadorBorrado() {
		return indicadorBorrado;
	}

	public void setIndicadorBorrado(String indicadorBorrado) {
		this.indicadorBorrado = indicadorBorrado;
	}

	public String getLimiteSuperior() {
		return limiteSuperior;
	}

	public void setLimiteSuperior(String limiteSuperior) {
		this.limiteSuperior = limiteSuperior;
	}

	public String getLimiteInferiorDias() {
		return limiteInferiorDias;
	}

	public void setLimiteInferiorDias(String limiteInferiorDias) {
		this.limiteInferiorDias = limiteInferiorDias;
	}

	public String getLimiteSuperiorDias() {
		return limiteSuperiorDias;
	}

	public void setLimiteSuperiorDias(String limiteSuperiorDias) {
		this.limiteSuperiorDias = limiteSuperiorDias;
	}

	public String getLimiteInferiorPico() {
		return limiteInferiorPico;
	}

	public void setLimiteInferiorPico(String limiteInferiorPico) {
		this.limiteInferiorPico = limiteInferiorPico;
	}

	public String getLimiteSuperiorPico() {
		return limiteSuperiorPico;
	}

	public void setLimiteSuperiorPico(String limiteSuperiorPico) {
		this.limiteSuperiorPico = limiteSuperiorPico;
	}

	public String getDiasSafetyStock() {
		return diasSafetyStock;
	}

	public void setDiasSafetyStock(String diasSafetyStock) {
		this.diasSafetyStock = diasSafetyStock;
	}

	public String getMontoDeSobreinventario() {
		return montoDeSobreinventario;
	}

	public void setMontoDeSobreinventario(String montoDeSobreinventario) {
		this.montoDeSobreinventario = montoDeSobreinventario;
	}

}
