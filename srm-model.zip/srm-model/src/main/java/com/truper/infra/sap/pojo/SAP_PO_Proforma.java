package com.truper.infra.sap.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.truper.infra.sap.SAP_FieldMapping;

@Entity
@Table(name = "srm_SAP_PO_PROFORMA")
public class SAP_PO_Proforma {

	@Id
	@Column(name = "ID", updatable = false, unique = true, insertable = false)
	private Integer id;

	// Mandante
	@Column(name = "MANDANTE")
	@SAP_FieldMapping(componente = "MANDT", tipoDeDato = "CLNT", longitud = 3, decimalDato = 0)
	private String mandante;

	// Numero del documento de compras
	@Column(name = "NUMERO_OC")
	@SAP_FieldMapping(componente = "EBELN", tipoDeDato = "CHAR", longitud = 10, decimalDato = 0)
	private String numeroDocumentoCompras;

	// Fecha de modificacion
	@Column(name = "FECHA_MODIFICACION")
	@SAP_FieldMapping(componente = "AEDTM", tipoDeDato = "DATS", longitud = 8, decimalDato = 0)
	private String fechaModificacion;

	// Hora de la  ultima modificacion
	@Column(name = "HORA_MODIFICACION")
	@SAP_FieldMapping(componente = "UTIME", tipoDeDato = "TIMS", longitud = 6, decimalDato = 0)
	private String horaUltimaModificacion;

	// Numero de posicion del documento de compras
	@Column(name = "NUMERO_POSICION")
	@SAP_FieldMapping(componente = "EBELP", tipoDeDato = "NUMC", longitud = 5, decimalDato = 0)
	private String numPosicionDocCompras;

	// Numero actual de la confirmacion de pedido
	@Column(name = "NUMERO_CONFIRMACION")
	@SAP_FieldMapping(componente = "ETENS", tipoDeDato = "NUMC", longitud = 4, decimalDato = 0)
	private String numActualConfirmacionPedido;

	// Tipo de confirmacion
	@Column(name = "TIPO_CONFIRMACION")
	@SAP_FieldMapping(componente = "EBTYP", tipoDeDato = "CHAR", longitud = 2, decimalDato = 0)
	private String tipoConfirmacion;

	// Fecha de entrega de confirmacion de pedido
	@Column(name = "FECHA_ENTREGA_CONFIRMACION")
	@SAP_FieldMapping(componente = "EINDT", tipoDeDato = "DATS", longitud = 8, decimalDato = 0)
	private String fechaEntrega;

	// Tipo de fecha de la fecha de entrega de la confirm. pedido
	@Column(name = "TIPO_FECHA_ENTREGA_CONFIRMACION")
	@SAP_FieldMapping(componente = "LPEIN", tipoDeDato = "CHAR", longitud = 1, decimalDato = 0)
	private String tipoFechaEnrtega;

	// Hora de fecha-entrega de confirmacion de pedido
	@Column(name = "HORA_ENTREGA_CONFIRMACION")
	@SAP_FieldMapping(componente = "UZEIT", tipoDeDato = "TIMS", longitud = 6, decimalDato = 0)
	private String horaFechaEntregaConfirmacionPedido;

	// Fecha de creaci�n de confirmacion de pedido
	@Column(name = "FECHA_CREACION_CONFIRMACION")
	@SAP_FieldMapping(componente = "ERDAT", tipoDeDato = "DATS", longitud = 8, decimalDato = 0)
	private String fechaConfirmacionPedido;

	// Hora de creaci�n de confirmacion  de pedido
	@Column(name = "HORA_CREACION_CONFIRMACION")
	@SAP_FieldMapping(componente = "EZEIT", tipoDeDato = "TIMS", longitud = 6, decimalDato = 0)
	private String horaConfirmacionPedido;

	// Cantidad de la confirmacion de pedido
	@Column(name = "CANTIDAD_CONFIRMACION")
	@SAP_FieldMapping(componente = "MENGE", tipoDeDato = "QUAN", longitud = 13, decimalDato = 3)
	private String cantidadConfirmacionPedido;

	// Cantidad reducida desde el punto de vista MRP
	@Column(name = "CANTIDAD_REDUCIDA_MRP")
	@SAP_FieldMapping(componente = "DABMG", tipoDeDato = "QUAN", longitud = 13, decimalDato = 3)
	private String cantidadReducidaMRP;

	// Indicador de creaci�n de la confirmacion de pedido
	@Column(name = "CREACION_CONFIRMACION_PEDIDO")
	@SAP_FieldMapping(componente = "ESTKZ", tipoDeDato = "CHAR", longitud = 1, decimalDato = 0)
	private String creacionConfirmacionPedido;

	// Indicador de borrado de confirmacion de pedido
	@Column(name = "BORRADO_CONFIRMACION_PEDIDO")
	@SAP_FieldMapping(componente = "LOEKZ", tipoDeDato = "CHAR", longitud = 1, decimalDato = 0)
	private String borradoConfirmacionPedido;

	// Indicador confirmacion pedido relevante p.planif.necesidades
	@Column(name = "PEDIDO_PLANEACION")
	@SAP_FieldMapping(componente = "KZDIS", tipoDeDato = "CHAR", longitud = 1, decimalDato = 0)
	private String pedidoPlaneacion;

	// N�mero documento referencia (dependencias  base texto expl.)
	@Column(name = "NUM_DOC_REFERENCIA")
	@SAP_FieldMapping(componente = "XBLNR", tipoDeDato = "CHAR", longitud = 35, decimalDato = 0)
	private String numDocReferencia;

	// Entrega
	@Column(name = "ENTREGA")
	@SAP_FieldMapping(componente = "VBELN", tipoDeDato = "CHAR", longitud = 10, decimalDato = 0)
	private String entrega;

	// Posici�n de entrega
	@Column(name = "POSICION_ENTREGA")
	@SAP_FieldMapping(componente = "VBELP", tipoDeDato = "NUMC", longitud = 6, decimalDato = 0)
	private String posicionEntrega;

	// Perfil piezas fabricante
	@Column(name = "PERFIL_PIEZAS_FABRICANTE")
	@SAP_FieldMapping(componente = "MPROF", tipoDeDato = "CHAR", longitud = 4, decimalDato = 0)
	private String perfilPiezasFabricante;

	// Numero material p.num.pieza fabricante
	@Column(name = "NUM_MATERIAL_PIEZA_FABRICANTE")
	@SAP_FieldMapping(componente = "EMATN", tipoDeDato = "CHAR", longitud = 18, decimalDato = 0)
	private String numMaterialPorPiezaFabricante;

	// Numero de reclamaciones
	@Column(name = "NUM_RECLAMACIONES")
	@SAP_FieldMapping(componente = "MAHNZ", tipoDeDato = "DEC", longitud = 3, decimalDato = 0)
	private String numeroReclamaciones;

	// N�mero de lote
	@Column(name = "NUM_LOTE")
	@SAP_FieldMapping(componente = "CHARG", tipoDeDato = "CHAR", longitud = 10, decimalDato = 0)
	private String numeroLote;

	// Posicion superior de la posici�n de particion de lotes
	@Column(name = "POSICION_PARTICIONES_LOTES")
	@SAP_FieldMapping(componente = "UECHA", tipoDeDato = "NUMC", longitud = 6, decimalDato = 0)
	private String posicionParticionLotes;

	// Numero actual de la confirmacion de pedido
	@Column(name = "NUM_ACTUAL_CONFIRMACION_PEDIDO")
	@SAP_FieldMapping(componente = "REF_ETENS", tipoDeDato = "NUMC", longitud = 4, decimalDato = 0)
	private String numeroActualConfirmacionPedido;

	// Entrega entrante en status "En centro"
	@Column(name = "STATUS_EN_CENTRO")
	@SAP_FieldMapping(componente = "IMWRK", tipoDeDato = "CHAR", longitud = 1, decimalDato = 0)
	private String statusEnCentro;

	// Indicador proceso de Datos Generales PO concluido
	@Column(name = "PROCESO_DATOS_GENERALES_CONCLUIDO")
	@SAP_FieldMapping(componente = "STEP1", tipoDeDato = "CHAR", longitud = 1, decimalDato = 0)
	private String procesoDatosGeneralesConcluido;

	// Indicador proceso env�o completo (Datos maestros y calculos)
	@Column(name = "ENVIO_COMPLETO")
	@SAP_FieldMapping(componente = "LOEVM", tipoDeDato = "CHAR", longitud = 1, decimalDato = 0)
	private String envioCompleto;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getMandante() {
		return mandante;
	}

	public void setMandante(String mandante) {
		this.mandante = mandante;
	}

	public String getNumeroDocumentoCompras() {
		return numeroDocumentoCompras;
	}

	public void setNumeroDocumentoCompras(String numeroDocumentoCompras) {
		this.numeroDocumentoCompras = numeroDocumentoCompras;
	}

	public String getFechaModificacion() {
		return fechaModificacion;
	}

	public void setFechaModificacion(String fechaModificacion) {
		this.fechaModificacion = fechaModificacion;
	}

	public String getHoraUltimaModificacion() {
		return horaUltimaModificacion;
	}

	public void setHoraUltimaModificacion(String horaUltimaModificacion) {
		this.horaUltimaModificacion = horaUltimaModificacion;
	}

	public String getNumPosicionDocCompras() {
		return numPosicionDocCompras;
	}

	public void setNumPosicionDocCompras(String numPosicionDocCompras) {
		this.numPosicionDocCompras = numPosicionDocCompras;
	}

	public String getNumActualConfirmacionPedido() {
		return numActualConfirmacionPedido;
	}

	public void setNumActualConfirmacionPedido(
			String numActualConfirmacionPedido) {
		this.numActualConfirmacionPedido = numActualConfirmacionPedido;
	}

	public String getTipoConfirmacion() {
		return tipoConfirmacion;
	}

	public void setTipoConfirmacion(String tipoConfirmacion) {
		this.tipoConfirmacion = tipoConfirmacion;
	}

	public String getFechaEntrega() {
		return fechaEntrega;
	}

	public void setFechaEntrega(String fechaEntrega) {
		this.fechaEntrega = fechaEntrega;
	}

	public String getTipoFechaEnrtega() {
		return tipoFechaEnrtega;
	}

	public void setTipoFechaEnrtega(String tipoFechaEnrtega) {
		this.tipoFechaEnrtega = tipoFechaEnrtega;
	}

	public String getHoraFechaEntregaConfirmacionPedido() {
		return horaFechaEntregaConfirmacionPedido;
	}

	public void setHoraFechaEntregaConfirmacionPedido(
			String horaFechaEntregaConfirmacionPedido) {
		this.horaFechaEntregaConfirmacionPedido = horaFechaEntregaConfirmacionPedido;
	}

	public String getFechaConfirmacionPedido() {
		return fechaConfirmacionPedido;
	}

	public void setFechaConfirmacionPedido(String fechaConfirmacionPedido) {
		this.fechaConfirmacionPedido = fechaConfirmacionPedido;
	}

	public String getHoraConfirmacionPedido() {
		return horaConfirmacionPedido;
	}

	public void setHoraConfirmacionPedido(String horaConfirmacionPedido) {
		this.horaConfirmacionPedido = horaConfirmacionPedido;
	}

	public String getCantidadConfirmacionPedido() {
		return cantidadConfirmacionPedido;
	}

	public void setCantidadConfirmacionPedido(String cantidadConfirmacionPedido) {
		this.cantidadConfirmacionPedido = cantidadConfirmacionPedido;
	}

	public String getCantidadReducidaMRP() {
		return cantidadReducidaMRP;
	}

	public void setCantidadReducidaMRP(String cantidadReducidaMRP) {
		this.cantidadReducidaMRP = cantidadReducidaMRP;
	}

	public String getCreacionConfirmacionPedido() {
		return creacionConfirmacionPedido;
	}

	public void setCreacionConfirmacionPedido(String creacionConfirmacionPedido) {
		this.creacionConfirmacionPedido = creacionConfirmacionPedido;
	}

	public String getBorradoConfirmacionPedido() {
		return borradoConfirmacionPedido;
	}

	public void setBorradoConfirmacionPedido(String borradoConfirmacionPedido) {
		this.borradoConfirmacionPedido = borradoConfirmacionPedido;
	}

	public String getPedidoPlaneacion() {
		return pedidoPlaneacion;
	}

	public void setPedidoPlaneacion(String pedidoPlaneacion) {
		this.pedidoPlaneacion = pedidoPlaneacion;
	}

	public String getNumDocReferencia() {
		return numDocReferencia;
	}

	public void setNumDocReferencia(String numDocReferencia) {
		this.numDocReferencia = numDocReferencia;
	}

	public String getEntrega() {
		return entrega;
	}

	public void setEntrega(String entrega) {
		this.entrega = entrega;
	}

	public String getPosicionEntrega() {
		return posicionEntrega;
	}

	public void setPosicionEntrega(String posicionEntrega) {
		this.posicionEntrega = posicionEntrega;
	}

	public String getPerfilPiezasFabricante() {
		return perfilPiezasFabricante;
	}

	public void setPerfilPiezasFabricante(String perfilPiezasFabricante) {
		this.perfilPiezasFabricante = perfilPiezasFabricante;
	}

	public String getNumMaterialPorPiezaFabricante() {
		return numMaterialPorPiezaFabricante;
	}

	public void setNumMaterialPorPiezaFabricante(
			String numMaterialPorPiezaFabricante) {
		this.numMaterialPorPiezaFabricante = numMaterialPorPiezaFabricante;
	}

	public String getNumeroReclamaciones() {
		return numeroReclamaciones;
	}

	public void setNumeroReclamaciones(String numeroReclamaciones) {
		this.numeroReclamaciones = numeroReclamaciones;
	}

	public String getNumeroLote() {
		return numeroLote;
	}

	public void setNumeroLote(String numeroLote) {
		this.numeroLote = numeroLote;
	}

	public String getPosicionParticionLotes() {
		return posicionParticionLotes;
	}

	public void setPosicionParticionLotes(String posicionParticionLotes) {
		this.posicionParticionLotes = posicionParticionLotes;
	}

	public String getNumeroActualConfirmacionPedido() {
		return numeroActualConfirmacionPedido;
	}

	public void setNumeroActualConfirmacionPedido(
			String numeroActualConfirmacionPedido) {
		this.numeroActualConfirmacionPedido = numeroActualConfirmacionPedido;
	}

	public String getStatusEnCentro() {
		return statusEnCentro;
	}

	public void setStatusEnCentro(String statusEnCentro) {
		this.statusEnCentro = statusEnCentro;
	}

	public String getProcesoDatosGeneralesConcluido() {
		return procesoDatosGeneralesConcluido;
	}

	public void setProcesoDatosGeneralesConcluido(
			String procesoDatosGeneralesConcluido) {
		this.procesoDatosGeneralesConcluido = procesoDatosGeneralesConcluido;
	}

	public String getEnvioCompleto() {
		return envioCompleto;
	}

	public void setEnvioCompleto(String envioCompleto) {
		this.envioCompleto = envioCompleto;
	}

}
