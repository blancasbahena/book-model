package com.truper.ws_trafico.dto.importaciones;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ArriboUsuarioDTO implements Serializable { 
	private static final long serialVersionUID = 6303454280407253287L;
	@JsonIgnore
	private Integer id ;
	private String token;
	private String fechaInicio;
	private String fechaTermino;
    private Integer activo;
    private UsuarioDTO usuario; 	
}
