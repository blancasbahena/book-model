package com.truper.ws_trafico.dto.importaciones;

import java.io.Serializable;

import javax.persistence.Entity;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Data
@Getter
@Setter
@Entity
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class ImpDocumentoDTO implements Serializable{ 
	private static final long serialVersionUID = -7163578628631123819L;
	private Integer id ;
	private String nombre;
	private Integer idDoc;
	@JsonIgnore
	private ImpFolioDTO importacion;
}
