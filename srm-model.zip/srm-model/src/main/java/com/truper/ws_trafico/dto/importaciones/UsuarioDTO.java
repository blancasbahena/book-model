 package com.truper.ws_trafico.dto.importaciones;
import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class UsuarioDTO implements Serializable{
	private static final long serialVersionUID = 3178941095276606468L;
	private Integer id;
	private String usuario;
	private String password;
	private String nombre;
	@JsonIgnore
	private Date inicio;
	@JsonIgnore
	private Date fin;
    
}
