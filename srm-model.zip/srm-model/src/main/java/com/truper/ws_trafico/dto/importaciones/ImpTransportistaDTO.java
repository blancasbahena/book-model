package com.truper.ws_trafico.dto.importaciones;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Data
@Getter
@Setter
@Entity 
@ToString
public class ImpTransportistaDTO implements Serializable{ 
	private static final long serialVersionUID = -5546600272685709627L;
	private Integer id ;
	@NotBlank
	@Size(max = 200, message = "El campo nombre tiene un tamaño maximo [200] para transportista")
	private String nombre;
	@NotBlank
	@Size(max = 100, message = "El campo numero operador tiene un tamanno maximo [100] para transportista")
	private String numeroOperador;
	@NotBlank
	@Size(max = 50, message = "El campo telefono tiene un tamanno maximo [50] para transportista")
	private String telefono;
	@NotBlank
	@Size(max = 50, message = "El campo linea transportista tiene un tamano maximo [50] para transportista")
	private String lineaTransportista;
	@NotBlank
	@Size(max = 10, message = "El campo matricula unidad tiene un tamano maximo [10] para transportista")
	private String matriculaUnidad;
	@NotBlank
	@Size(max = 5, message = "El campo tipo de Unidad tiene un tamanno maximo [5] para folio-importacion")
	private String tipoUnidad;
	@NotBlank
	@Size(max = 10, message = "El campo almacen de Destino tiene un tamanno maximo [10] para folio-importacion")
	private String almacenDestino;
	public ImpTransportistaDTO() {
		super();
		String vacio ="";
		this.nombre = vacio;
		this.numeroOperador = vacio;
		this.telefono = vacio;
		this.lineaTransportista = vacio;
		this.matriculaUnidad = vacio;
		this.tipoUnidad = vacio;
		this.almacenDestino = vacio;
	}
	
}
