package com.truper.ws_trafico.dto.importaciones;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class ArriboFecha implements Serializable {
	private String fecha;
	private String formato;
	private String usuario;
}
