package com.truper.ws_trafico.dto.importaciones;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Data
@Getter
@Setter
@Entity
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class CatalogoEstatusDTO implements Serializable {
	private static final long serialVersionUID = -2275799461632112665L;
	private Integer id ;
	@NotBlank
	@Size(max =20, message = "El campo estatus tiene un tamaño maximo [20] para catalogo estatus")
	private String estatus;
	@NotBlank
	@Size(max = 200, message = "El campo descripcion tiene un tamaño maximo [200] para catalogo estatus")
	private String descripcion;
	public CatalogoEstatusDTO(Integer id) {
		super();
		this.id = id;
	}
	
}
