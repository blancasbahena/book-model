package com.truper.ws_trafico.dto.importaciones;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Data
@Getter
@Setter
@Entity
@ToString
public class ImpGpsDTO implements Serializable{ 
	private static final long serialVersionUID = 690272793549228069L;
	private Integer id ;
	@NotBlank
	@Size(max = 20, message = "El campo numero tiene un tamaño maximo [20] para gps-transportista")
	private String numero;
	public ImpGpsDTO() {
		super();
		this.numero = "";
	}
	
}
