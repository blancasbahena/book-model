package com.truper.ws_trafico.dto.importaciones;

import java.io.Serializable;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
@Data
@Getter
@Setter
@Entity
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class ImpFolioDTO implements Serializable{ 
	private static final long serialVersionUID = 8763682781721707728L;
	private Integer id ;
	@NotBlank
	@Size(max = 10, message = "El campo terminalFcc tiene un tamaño maximo [10] para folio-importacion")
	private String terminalFcc;
	@NotBlank
	@Size(max = 10, message = "El campo prioridad de Seguridad tiene un tamaño maximo [10] para folio-importacion")
	private String prioridadSeguridad;
	@NotBlank
	@Size(max = 4, message = "El campo cuenta Espejo tiene un tamaño maximo [4] para folio-importacion")
	private String cuentaEspejo;
	@NotBlank
	@Size(max = 15, message = "El campo alerta Por Estadias tiene un tamaño maximo [15] para folio-importacion")
	private String alertaPorEstadias;
	@NotBlank
	@Size(max = 15, message = "El campo alerta Por Demoras tiene un tamaño maximo [15] para folio-importacion")
	private String alertaPorDemoras;
	@NotBlank
	@Size(max = 30, message = "El campo producto tiene un tamaño maximo [30] para folio-importacion")
	private String producto;
	@NotBlank
	@Size(max = 12, message = "El campo FechaEir tiene un tamaño maximo [15] para folio-importacion") 
	private String fechaEir;
	@NotBlank
	@Size(max = 50, message = "El campo tipoMaterial tiene un tamaño maximo [50] para folio-importacion") 
	private String tipoMaterial;
	@NotBlank
	@Size(max = 20, message = "El campo modalidad tiene un tamaño maximo [20] para folio-importacion") 
	private String modalidad;
    private CatalogoEstatusDTO  estatus;
	private ImpComentarioDTO comentarios;
	private ImpGpsDTO gps;
	private ImpTiemposDTO tiempos;
	private ImpTransportistaDTO transportista;
	
	private Integer idEstadias;
	
	private Integer idDemoras;
	
	private Boolean actEstadias;
	
	private Boolean actDemoras;
	
	private Boolean actNotificacionContenedor;
	private Date fechaNotificacionContenedor;
	private String usuarioNotificacionContenedor;
	
	private List<ImpDocumentoDTO> documentos;
	public ImpFolioDTO(Integer id) {
		super();
		this.id = id;
	}
	public ImpFolioDTO(CatalogoEstatusDTO estatus, ImpComentarioDTO comentarios, ImpGpsDTO gps,
			ImpTiemposDTO tiempos, ImpTransportistaDTO transportista) {
		super();
		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		String vacio ="";
		this.terminalFcc = vacio;
		this.prioridadSeguridad = vacio;
		this.cuentaEspejo = vacio;
		this.alertaPorEstadias = vacio;
		this.alertaPorDemoras = vacio;
		this.producto = vacio;
		this.fechaEir =dateFormat.format(new Date());
		this.tipoMaterial = vacio;
		this.modalidad = vacio;
		this.estatus = estatus;
		this.comentarios = comentarios;
		this.gps = gps;
		this.tiempos = tiempos;
		this.transportista = transportista;
		this.idEstadias = 0;
		this.idDemoras = 0;
		this.actEstadias = false;
		this.actDemoras = false;
		this.actNotificacionContenedor = false;
		this.usuarioNotificacionContenedor = vacio;
		this.documentos = null;
	}
	
	
}
