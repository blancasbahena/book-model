package com.truper.ws_trafico.dto.importaciones;

import java.io.Serializable;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
@Getter
@Setter 
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class TiempoArribo implements Serializable { 
	private static final long serialVersionUID = -3256648420140103036L;
	private Integer  id;
	private Integer  folio;
	private String   contenedor;
	private String   fechaLlegadaDestino;
	private String   fechaIngresoAPlanta;
	private String   fechaEnrampeContenedor;
	private String   fechaSalidaAnden;
	private boolean  existeFechaLlegadaDestino;
	private boolean  existeFechaIngresoAPlanta;
	private boolean  existeFechaEnrampeContenedor;
	private boolean  existeFechaSalidaAnden;	
	private String   almacenDestino;
	private String   fechaSalidaDeTerminal;
	private String   fechaSalidaDeAduana;
	private String   nombreOperador;
	private String   tipoDeUnidad;
	private String   matriculaDeUnidad;
	private String   horaInicioRuta;
	private String   comentarioCOT;
	private String   observaciones;
	private String   ruta;
	private String   blContenedor;
	private String   div;
	private List<ImpDocumentoDTO> documentos;
	
}
