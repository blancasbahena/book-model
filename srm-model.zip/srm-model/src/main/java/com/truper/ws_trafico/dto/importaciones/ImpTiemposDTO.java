package com.truper.ws_trafico.dto.importaciones;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
 
@Getter
@Setter
@Entity
@ToString
public class ImpTiemposDTO implements Serializable { 
	private static final long serialVersionUID = 9056099695713757193L;
	private Integer id ;
	@JsonFormat(pattern="yyyy-MM-dd'T'HH:mm")
	private Date fechaSalidaAduana;
	@JsonFormat(pattern="yyyy-MM-dd'T'HH:mm")
	private Date fechaLlegadaTerminal;
	@JsonFormat(pattern="yyyy-MM-dd'T'HH:mm")
	private Date fechaDisponibilidadCargaTerminal;
	@JsonFormat(pattern="yyyy-MM-dd'T'HH:mm")
	private Date fechaSalidaTerminal;
	private String fechaLlegadaDestino;
	private String fechaIngresoAPlanta;
	private String fechaEnrampeContenedor;
	private String fechaSalidaAnden;
	private String usuarioModificaLlegadaDestino;
	private String usuarioModificaIngresoAPlanta;
	private String usuarioModificaEnrampeContenedor;
	private String usuarioModificaSalidaAnden;
	private String horaInicioRuta;
	public ImpTiemposDTO() {
		super();
		String vacio ="";
		this.fechaLlegadaDestino = vacio;
		this.fechaIngresoAPlanta = vacio;
		this.fechaEnrampeContenedor = vacio;
		this.fechaSalidaAnden = vacio;
		this.usuarioModificaLlegadaDestino = vacio;
		this.usuarioModificaIngresoAPlanta = vacio;
		this.usuarioModificaEnrampeContenedor = vacio;
		this.usuarioModificaSalidaAnden = vacio;
		this.horaInicioRuta = vacio;
	}
	
}
