package com.truper.ws_trafico.dto.importaciones;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Data
@Getter
@Setter
@Entity
@ToString
public class ImpComentarioDTO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -4243862765348688714L;
	private Integer id ;
	@NotBlank
	@Size(max = 400, message = "El campo comentarios tiene un tamaño maximo [400] para transportista")
	private String comentarios;
	private String observaciones; 
	public ImpComentarioDTO() {
		super();
		this.comentarios = "";
		this.observaciones="";
	}
}
