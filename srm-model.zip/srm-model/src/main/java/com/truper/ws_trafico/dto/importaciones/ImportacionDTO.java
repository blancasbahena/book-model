package com.truper.ws_trafico.dto.importaciones;

import java.io.Serializable;

import javax.persistence.Entity;

import com.truper.trafico.ConsolidacionFolioDto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
 
@Getter
@Setter
@Entity
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class ImportacionDTO implements Serializable {
    private ConsolidacionFolioDto folio;
    private ImpFolioDTO importacion;
}
