package com.truper.ws_trafico.dto.importaciones;

import java.io.Serializable;

import com.truper.expediente.ExpedientePerfilDTO;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class MockMultiPart implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	String encodedString;
	Integer folio;
	ExpedientePerfilDTO dto;
}