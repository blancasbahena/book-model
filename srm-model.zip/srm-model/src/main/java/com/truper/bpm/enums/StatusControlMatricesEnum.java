package com.truper.bpm.enums;
/**
 * Este enum esta ligado a la tabla SQL cdiCatalogoControlMatrices
 * Si se agrega una propiedad a este enum, esta debe agregarse a la tabla para mantener 
 * la integridad de los datos.
 * 
 * @author drodriguezv
 *
 */
public enum StatusControlMatricesEnum {

	PENDING_PRICE_UPDATE("PPU","Pending Price Update",1,true,false),
	RELEASED("R","Released",1,true,false),
	DAYS_VS_ETD("X","Days vs. ETD",2,true,false),
	MATRIX_SEAL_PRICE("MS","Matrix seal Price",2,true,false),
	REDUCTION_PRICE("RP","Reduction Price",2,true,false),
	MISSING_INFORMATION("MI","Missing information",2,true,false),
	NEW("NEW","New at pool",0,true,false),
	RJPPU("RJPPU","Reject audit from PPU", 2,false,true),
	REREJ("REREJ","Release audit from rejected", 1,false,true),
	REPPU("REPPU","Release audit from PPU", 1,false,true);
	

	private final String id;
	private final String descripcion;
	// 0 - Nuevo , 1 aprobado,  2 rechazado
	private final int rechazado;
	private final boolean isMatriz;
	private final boolean isAuditoria;
	
	
	StatusControlMatricesEnum(String id,String descripcion, int rechazado,boolean isMatriz, boolean isAuditoria) {
		this.id = id;
		this.descripcion = descripcion;
		this.rechazado = rechazado;
		this.isMatriz = isMatriz;
		this.isAuditoria = isAuditoria;
	}

	public String id() {
		return id;
	}
	public String getDescripcion() {
		return descripcion;
	}
	public int isRechazado() {
		return rechazado;
	}

	public boolean isMatriz() {
		return isMatriz;
	}

	public boolean isAuditoria() {
		return isAuditoria;
	}
	
	
	
}
