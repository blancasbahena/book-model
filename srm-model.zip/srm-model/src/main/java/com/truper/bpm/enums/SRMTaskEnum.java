package com.truper.bpm.enums;

public enum SRMTaskEnum {
	
	TASK_COMP(3),
	TASK_CP(6),
	TASK_GC(11),
	TASK_DC(12),
	TASK_PLAN(2),
	TASK_GP(5),
	TASK_DP(8),
	TASK_DO(14),
	TASK_DG(16),
	TASK_PROV(17),
	TASK_COMP_CLOSE(21),
	TASK_PLAN_CLOSE(22),
	TASK_GP_PRORROGA(29),
	TASK_DC_PRORROGA(30),
	TASK_PROV_CONF(32),
	TASK_PRORROGA(33);
	
	private int taskType;
	
	private SRMTaskEnum(int taskType) {
		this.taskType = taskType;
	}
	
	public int getTaskType() {
		return this.taskType;
	}

}
