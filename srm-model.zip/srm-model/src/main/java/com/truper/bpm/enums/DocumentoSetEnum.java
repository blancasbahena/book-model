package com.truper.bpm.enums;

public enum DocumentoSetEnum {

	FACTURA, PKL, BL, PBL, OTRO

}
