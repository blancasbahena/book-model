package com.truper.bpm.enums;

import com.google.gson.annotations.SerializedName;

/**
 * Ligado a la tabla SQL cdiCatalogoEstatusAuditoria
 * 
 * @author rsantiagor
 *
 */
public enum EstatusAuditoriaEnum {

	@SerializedName("10") NEW(10, "New")
	, @SerializedName("20") RELEASE(20, "Release")
	, @SerializedName("30") REJECT(30, "Reject")
	, @SerializedName("40") RELEASED_PPU(40, "Released from PPU")
	, @SerializedName("50") REJECTED_PPU(50, "Rejected from PPU")
	, @SerializedName("60") RELEASED_REJECTED(60, "Released from rejected")
	, @SerializedName("70") RELEASED_WITHOUT_AUDIT(70, "Released without audit");

	private int id;
	private String descripcion;

	private EstatusAuditoriaEnum(int id, String descripcion) {
		this.id = id;
		this.descripcion = descripcion;
	}

	public int getId() {
		return id;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public static EstatusAuditoriaEnum getEnum(int value) {
		for (EstatusAuditoriaEnum v : values())
			if (v.getId() == value)
				return v;
		throw new IllegalArgumentException();
	}
}
