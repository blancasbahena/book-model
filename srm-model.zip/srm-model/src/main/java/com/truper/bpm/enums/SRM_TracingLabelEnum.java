package com.truper.bpm.enums;

public class SRM_TracingLabelEnum {

	private String nombre;
	private String glyphicon;
	private String colorStyle;
	private int total;
	private int posicion;

	public static final SRM_TracingLabelEnum EN_CURSO;
	public static final SRM_TracingLabelEnum QUEMADA;
	public static final SRM_TracingLabelEnum URGENTE;
	public static final SRM_TracingLabelEnum TRIAL;
	public static final SRM_TracingLabelEnum REACTIVADA;
	public static final SRM_TracingLabelEnum IDA_MENOR_0;
	public static final SRM_TracingLabelEnum PICO_MAYOR_360;

	public static final SRM_TracingLabelEnum ACEPTADA;
	public static final SRM_TracingLabelEnum RECHAZADA;
	public static final SRM_TracingLabelEnum NEGOCIADA;

	private static final SRM_TracingLabelEnum[] values;
	private static final SRM_TracingLabelEnum[] valuesPro;

	private SRM_TracingLabelEnum(String nombre, String glyphicon,
			String colorStyle, int posicion) {
		this.glyphicon = glyphicon;
		this.nombre = nombre;
		this.colorStyle = colorStyle;
		this.total = 0;
		this.posicion = posicion;
	}

	public static SRM_TracingLabelEnum[] getValues() {
		return values;
	}

	public static SRM_TracingLabelEnum[] getValuesPro() {
		return valuesPro;
	}

	public static SRM_TracingLabelEnum getLabelByPosicion(Integer posicion) {
		if (posicion == null) {
			return null;
		}
		SRM_TracingLabelEnum[] vals = getValues();
		for (SRM_TracingLabelEnum v : vals) {
			boolean isLabel = posicion.equals(v.getPosicion());
			if (isLabel) {
				return v;
			}
		}
		SRM_TracingLabelEnum[] valsP = getValuesPro();
		for (SRM_TracingLabelEnum v : valsP) {
			boolean isLabel = posicion.equals(v.getPosicion());
			if (isLabel) {
				return v;
			}
		}
		return null;
	}

	static {
		EN_CURSO = new SRM_TracingLabelEnum("En curso",
				"glyphicon glyphicon-circle-arrow-right", "#6CC57C", 6);
		// Quemada
		QUEMADA = new SRM_TracingLabelEnum("Quemada",
				"glyphicon glyphicon-fire", "#B91827", 1);
		// Urgente glyphicon glyphicon-alert
		URGENTE = new SRM_TracingLabelEnum("Urgente",
				"glyphicon glyphicon-exclamation-sign", "#953CCC", 2);
		TRIAL = new SRM_TracingLabelEnum("Trial",
				"glyphicon glyphicon-asterisk", "#DFAF2C", 3);
		// Reactivada glyphicon glyphicon-registration-mark
		REACTIVADA = new SRM_TracingLabelEnum("Reactivada",
				"glyphicon glyphicon-repeat", "#3F515A", 10);
		// I.D.A. <= 0 glyphicon glyphicon-minus-sign glyphicon
		// glyphicon-circle-arrow-down
		IDA_MENOR_0 = new SRM_TracingLabelEnum("I.D.A. <= 0",
				"glyphicon glyphicon-circle-arrow-down", "#8a6d3b", 4);
		// Pico >= 360
		PICO_MAYOR_360 = new SRM_TracingLabelEnum("Pico > 360",
				"glyphicon glyphicon-signal", "#028686", 5);
		/** TRIAL, **/
		SRM_TracingLabelEnum[] data = new SRM_TracingLabelEnum[] { EN_CURSO,
				QUEMADA, URGENTE, REACTIVADA, IDA_MENOR_0, PICO_MAYOR_360 };
		values = data;

		ACEPTADA = new SRM_TracingLabelEnum("Aceptadas",
				"glyphicon glyphicon-thumbs-up", "#04B404", 9);
		RECHAZADA = new SRM_TracingLabelEnum("Rechazadas",
				"glyphicon glyphicon-thumbs-down", "#B40404", 7);
		NEGOCIADA = new SRM_TracingLabelEnum("En Negociacion",
				"glyphicon glyphicon-transfer", "#0174DF", 8);
		valuesPro = new SRM_TracingLabelEnum[] { ACEPTADA, RECHAZADA, NEGOCIADA };
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getGlyphicon() {
		return glyphicon;
	}

	public void setGlyphicon(String glyphicon) {
		this.glyphicon = glyphicon;
	}

	public String getColorStyle() {
		return colorStyle;
	}

	public void setColorStyle(String colorStyle) {
		this.colorStyle = colorStyle;
	}

	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total = total;
	}

	public int getPosicion() {
		return posicion;
	}

	public void setPosicion(int posicion) {
		this.posicion = posicion;
	}
}
