package com.truper.bpm.enums;

public enum TipoEta {
	/**
	 * Calculada con base en ETD
	 */
	CALCULADA("CALC"),
	/**
	 * Arribo Transporte
	 */
	AT("AT"),
	/**
	 * Arribo Forzado
	 */
	AF("AF");

	private String id;

	private TipoEta(String id) {
		this.id = id;
	}

	public String getId() {
		return id;
	}
}