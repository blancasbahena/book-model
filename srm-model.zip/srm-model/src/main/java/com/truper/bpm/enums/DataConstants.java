package com.truper.bpm.enums;

public class DataConstants
{
	public static final Integer MIN_ZERO = 0;
	public static final Integer BUNCH_SIZE_DIEZ = 10;
	public static final int DEFAULT_PAGE = 1;
	public static final int DEFAULT_PAGE_SIZE = 20;
	public static final String USER_FR = "F&R";
	public static final String TODOS = "TODOS";
	public static final String FILTRO_CONTENEDOR = "CONTENEDOR";
	public static final String FILTRO_FOLIO ="FOLIO";
	public static final String FILTRO_BL = "BL";
	public static final String FILTRO_ID = "ID";
	public static final String FILTRO_SAR = "SAR";
	public static final String FILTRO_NO_FACTURA_PROVEEDOR = "#FACTURA PROVEEDOR";
	public static final String FILTRO_NO_FACTURA_PARCEMOBI = "#FACTURA PARCEMOBI";
	public static final String FILTRO_FECHA_TOQUE_DE_PISO = "FECHA TOQUE DE PISO";
	
	public static final String FILTRO_FECHA_DE_LLEGADA_A_DESTINO = "LLEGADA_A_DESTINO";
	public static final String FILTRO_FECHA_DE_INGRESO_A_PLANTA = "INGRESO_A_PLANTA";
	public static final String FILTRO_FECHA_DE_ENRAMPE_CONTENEDOR = "ENRAMPE_DE_CONTENEDOR";
	public static final String FILTRO_FECHA_DE_SALIDA_ANDEN = "SALIDA_DE_ANDEN";
	
	public static final String AGENTE_ADUANAL = "AA";
	public static final String TRAFICO = "TRAFICO";
	public static final String MSG_ERROR_SEND_EMAIL = "Hubo un error al enviar el email";
	public static final String MSG_NOT_FOUND_TIPO_ACTIVIDAD = "No se pudo enviar el Email/No se encontró el 'Tipo de actividad': ";
	public static final String MSG_NOT_FOUND_AGENTE_ADUANAL = "No se pudo enviar el Email/No se encontró el 'Agente Aduanal': ";
	public static final String MSG_ERROR_GET_TIPO_ACTIVIDAD = "Hubo un error al tratar de obtener el 'Tipo de Actividad': ";
	public static final String BEARER = "Bearer ";
	public static final String CONST_CONTENEDOR = "CONST_CONTENEDOR";
	public static final String MSG_RECHAZO = "MSG_RECHAZO";
	public static final String CONST_INCIDENCIAS = "CONST_INCIDENCIAS";
	public static final String CONST_NOMBRE_AGENTE_ADUANAL = "CONST_NOMBRE_AGENTE_ADUANAL";
}
