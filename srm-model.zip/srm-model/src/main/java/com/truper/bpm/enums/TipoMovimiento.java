package com.truper.bpm.enums;

public enum TipoMovimiento {
	AGREGAR(1), MODIFICAR(2), ELIMINAR(3);

	private int movimiento;

	private TipoMovimiento(int n) {
		this.movimiento = n;
	}

	public int value() {
		return this.movimiento;
	}
}
