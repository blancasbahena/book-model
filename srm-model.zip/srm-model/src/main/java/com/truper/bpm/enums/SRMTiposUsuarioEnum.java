package com.truper.bpm.enums;

public enum SRMTiposUsuarioEnum {

	COMPRADOR(1), PLANEADOR(2), DIRECTOR(3), PROVEEDOR(4);

	private final int id;

	private SRMTiposUsuarioEnum(int id) {
		this.id = id;
	}

	public int getId() {
		return id;
	}

}
