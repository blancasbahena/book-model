package com.truper.bpm.enums;

public enum ErrorValidacionEtdEta {
	/**
	 * Tiene arribo de transporte
	 */
	TIENE_AT(1, "La ETA tiene arribo de transporte", "ETA is originated by an AT confirmation"),
	/**
	 * Tiene arribo forzado
	 */
	TIENE_AF(2, "La ETA tiene arribo forzado", "ETA is originated by a forced arrival"),
	/**
	 * Eta menor
	 */
	ETA_MENOR(3, "La ETA es menor a hoy", "ETA ocurrs in the past"),
	/**
	 * Nueva ETD mayor a 5 dias naturales y nuevo IDA menor a 10
	 */
	ETD_MAYOR_DIAS_NATURALES_Y_IDA_MENOR(4, "La nueva ETD es mayor a 7 dias naturales y el nuevo IDA es menor a 10", "New ETD is greater than 7 days and new IDA is less than 10 days"),
	/**
	 * Significa que no ha corrido el proceso que actualiza las IDAs en TEL, este proceso corre normalmente cada 2 hrs
	 */
	ETD_MAYOR_DIAS_NATURALES_Y_SIN_IDA(5, "La nueva ETD es mayor a 7 dias naturales y el IDA no se ha actualizado desde el ultimo cambio de ETD", "New ETD is greater than 7 days and IDA has not been updated since last ETD modification");

	private int id;
	private String error;
	private String errorEspecial;

	private ErrorValidacionEtdEta(int id, String error, String errorEspecial) {
		this.id = id;
		this.error = error;
		this.errorEspecial = errorEspecial;
	}

	public int getId() {
		return id;
	}

	public String getError() {
		return error;
	}
	
	public String getErrorEspecial() {
		return errorEspecial;
	}

	public static ErrorValidacionEtdEta getEnum(Integer value) {
		if (value == null)
			return null;
		for (ErrorValidacionEtdEta v : values())
			if (v.getId() == value)
				return v;
		throw new IllegalArgumentException();
	}
}
