package com.truper.bpm.enums;

public enum TipoPosicionEnum {
	PO,
	OTHER_ITEM
}
