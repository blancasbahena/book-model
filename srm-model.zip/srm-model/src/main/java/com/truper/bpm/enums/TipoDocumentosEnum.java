
package com.truper.bpm.enums;
import java.util.Date;

import lombok.Getter;
@Getter
public enum TipoDocumentosEnum {

	FACTURA_PARCELMOBI("Factura ParcelMobi",1,"EXT"),	
	FACTURA_PROVEEDOR("Factura Proveedores",2,"EXT"),
	BL("BL",3,"TOP"),
	PL("PL",4,"TOP"),
	OTROS_PROVEEDOR("Otros Proveedores",5,"ALL"),
	OTROS("Otros",6,"ALL"),
	PREBL("PRE-BL",7,"EXT"),
	IMG_SUPPLIER("IMGSupplier",18,"TOP");

	private final String descripcion;
	private final int id;
	private final String tipoCarga;
	
	private Boolean actNotificacionContenedor;	
	private Date fechaNotificacionContenedor;
	private String usuarioNotificacionContenedor;
	
	TipoDocumentosEnum(String descripcion,int id,String tipoCarga) {
		this.id = id;
		this.descripcion = descripcion;
		this.tipoCarga = tipoCarga;
	} 
}