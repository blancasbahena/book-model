package com.truper.expediente;
import java.io.Serializable;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@NoArgsConstructor 
public class StandarResponse<V> implements Serializable{
	private static final long serialVersionUID = 4426888764756669739L;
	public StandarResponse(String tipo, String msg,String nombreObjeto,V data) {
		this.mensaje = msg;
		this.tipoMensaje =tipo;
		this.data = data; 
	}
	
	public StandarResponse(String tipo, String msg,String nombreObjeto,V data, String sub) {
		this.mensaje = msg;
		this.tipoMensaje = tipo;
		this.data = data; 
		this.sub = sub;
	}

	private String mensaje;
	private String  tipoMensaje;
	private V data;
	private String sub;
}
