package com.truper.expediente.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum EstatusSharepoint
{
	CREATED(20, "OK"),
	FOLDER_CREADO(200, "Folder creado correctamente"),
	FOLDER_EXIST(400, "El folder ya existe, no es posible crearlo");
	
	private int status;
	private String message;
}


