package com.truper.expediente;
import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
@Getter
@Setter
@ToString
public class WsDTO  implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 9215825660603642299L;
	private String host;
	private Integer port;
	private String user;
	private String pwd;
	private String virtualService;
	private String exchangeName;
	private String queueGeneracionExpediente;
	private String queueFRFacturacion;
	private String queueFacturacionSolicitudes;
	private String queueSIFEFacturacion;
    private String routingKeyWsFacturacion;
    private String routingKeyWsExpedientes;
    private String routingKeyFr;
    private String routingKeySife;
}
