package com.truper.expediente;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.Setter;
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Builder
public class RequestAuth implements Serializable{
 
	private static final long serialVersionUID = -778269628782620473L;

	@NonNull
	private String user;
	
	@NonNull
	private String pwd;

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append(user);
		builder.append(":");
		builder.append(pwd);
		return builder.toString();
	}
	
	
}
