package com.truper.expediente.enums;
import lombok.AllArgsConstructor;
import lombok.Getter;
@Getter
@AllArgsConstructor
public enum ValidatingException   {  
	TIENE_EXITO(0,"SUCCESS"),
	ERROR_1000(1000,"Its necesary ID-PERFIL / TIPO-DOCUMENT"),
	ERROR_1001(1001,"Its necesary TIPO-DOCUMENT"),
	ERROR_1002(1002,"Its necesary ID-PERFIL"),
	ERROR_1003(1003,"Its necesary one Document"),
	ERROR_1004(1004,"Its necesary one Document"),
	ERROR_1005(1005,"Its necesary number container"),
	ERROR_1006(1006,"Its necesary one number id"),
	ERROR_1007(1007,"Its necesary Path origen document"),
	ERROR_1008(1008,"Its necesary Path Document"),
	ERROR_1009(1009,"Its necesary file name"),
	ERROR_1010(1010,"Its necesary file from up load"),
	ERROR_1011(1011,"Data not Found"),
	ERROR_1012(1012,"Its necesary a main Expedient"),
	ERROR_1013(1013,"Problems save Documents"),
	ERROR_1014(1014,"Its necesary a main Expedient"),
	ERROR_1015(1015,"Data Invalidate");
	private Integer codigo;
	private String msg;
	public static String getEnum(Integer value) {
		if (value == null)
			return null;
		for (ValidatingException v : values())
			if (v.getCodigo().intValue() ==  value.intValue())
				return v.getMsg();
		throw new IllegalArgumentException();
	}
}
