package com.truper.expediente;
import java.io.Serializable;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Builder
public class ExpedientePerfilDTO implements Serializable {
	private static final long serialVersionUID = 8277371848901554195L;
	private ExpedienteDTO id;
	private Boolean cargar;
	private Boolean borrar;
	private Boolean editar;
	private Boolean nuevo;
	private AnexosDTO anexos;
	private List<DocumentoDTO> documentos;
}
