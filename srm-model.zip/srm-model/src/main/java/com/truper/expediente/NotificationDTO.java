package com.truper.expediente;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
@Setter
@Getter
@ToString
public class NotificationDTO {
	private Long id;
	
	private Long idUnico;
	 
	private String fechaCarga;
	
	private Boolean estatus;
	private Boolean revisado;
	private String msg;

}
