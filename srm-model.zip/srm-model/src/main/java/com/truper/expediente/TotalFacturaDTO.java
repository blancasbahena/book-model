package com.truper.expediente;
import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
@Getter
@Setter
@AllArgsConstructor
public class TotalFacturaDTO {
	private final BigDecimal CERO = new BigDecimal("0");
	private BigDecimal total ; 
	private BigDecimal subtotal ;
	private BigDecimal focs;
	private BigDecimal others;
	public TotalFacturaDTO() {
		this.total =  CERO;
		this.subtotal =  CERO;
		this.focs =  CERO;
		this.others =  CERO;
	} 
}
