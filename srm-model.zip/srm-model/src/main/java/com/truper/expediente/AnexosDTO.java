package com.truper.expediente;
import java.io.Serializable;
import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Builder
public class AnexosDTO implements Serializable {
	private static final long serialVersionUID = -440605372650852491L;
	private long    id;
	private String  blContenedor;
	private String  comentarios;
	private String  fechaCarga;
	private String  cargadoPor;
	private String  proveedor;
	private String  booking; 
	public AnexosDTO(String blContenedor) {
		super();
		this.blContenedor = blContenedor;
	}
	
}
	