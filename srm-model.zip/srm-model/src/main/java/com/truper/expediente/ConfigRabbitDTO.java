package com.truper.expediente;
import java.io.Serializable;

import lombok.Getter;
import lombok.Setter; 
@Getter
@Setter
public class ConfigRabbitDTO implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 4069394683241171376L;
	public WsDTO ws;
}
