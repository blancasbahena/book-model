package com.truper.expediente;
import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Builder
public class DocumentoDTO implements Serializable { 
	private static final long serialVersionUID = 8929064925845923636L;
	private long    id;
	private String  blContenedor;
	private String  descripcion;
	private CatTipoDocumentoDTO idTipoDocumento; 
	private String  pathDocumento;
	private String  pathOrigenDocumento;
	private String  nombreDocumento;
	private String  fechaCarga;
	private String  cargadoPor;
	private String  fechaBorrado;
	private Boolean borrado;
	private String  borradoPor;
	private String  modificadoPor;
	private String  fechaModificado; 
	private Long    idUnico;
	private Long    size;
	private String  typeFile;
	private String  conditions;
	private String  numeroFactura;
	private boolean borrarDeDirectorio;
}
