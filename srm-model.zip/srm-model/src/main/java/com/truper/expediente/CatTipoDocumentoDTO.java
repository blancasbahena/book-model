package com.truper.expediente;
import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Builder
public class CatTipoDocumentoDTO implements Serializable{ 
	private static final long serialVersionUID = 910859833613497019L;

	private Long id;
	  
	private String descripcion;

	private String tipoCarga;
	
	private String origen;

	public CatTipoDocumentoDTO(Long id,String descripcion,String tipoCarga){
		this.id=id;
		this.descripcion=descripcion;
		this.tipoCarga=tipoCarga;
	}
	
}
