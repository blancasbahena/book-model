package com.truper.expediente;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
@Getter
@Setter 
@NoArgsConstructor
@ToString 
public class ExpedienteDTO implements Serializable{ 
	private static final long serialVersionUID = 8814637088183129268L;
	private PerfilUsuarioDTO idPerfil;
	private CatTipoDocumentoDTO idTipoDocumento;
	public ExpedienteDTO(Long perfil, Long tipo) {
		this.idPerfil=  PerfilUsuarioDTO.builder().id(perfil).build();
		this.idTipoDocumento=  CatTipoDocumentoDTO.builder().id(tipo).build();
	}
	public ExpedienteDTO(PerfilUsuarioDTO p, CatTipoDocumentoDTO c) {
		this.idPerfil=  p;
		this.idTipoDocumento=  c;
	}
}
