package com.truper.expediente.enums;

public enum ErrorCodesEnum {
	DTO_REQUEST_VALIDATION("DTO_REQUEST_VALIDATION", "Atributos no validos"),
	WRONG_PARAMETER_DATA("WRONG_PARAMETER_DATA", "Parametro no valido [%s]"),
	UNAUTHORIZED("UNAUTHORIZED", "%s"),
	INVALID_TOKEN("INVALID_TOKEN", "Token no valido: %s"),
	INVALID_TOKEN_EXPIRED("INVALID_TOKEN_EXPIRED", "Token expirado"),
	
	
	USERS_EXIST("USERS_EXIST", "Usuario [%s] ya existe"),
	USERS_AD_NOT_FOUND("USERS_AD_NOT_FOUND", "Usuario no existe en AD."),
	USERS_NOT_FOUND("USERS_NOT_FOUND", "Usuario [%s] no encontrado"),
	USERS_NOT_FOUND_AUTH("USERS_NOT_FOUND_AUTH", "Usuario o contraseña incorrecto"),
	
	
	ROLE_NOT_FOUND("ROLE_NOT_FOUND", "Rol [%s] no encontrado"),
	ROL_EXIST("ROL_EXIST", "Rol [%s] ya existe"),

	
	PERMISSION_NOT_FOUND("PERMISSION_NOT_FOUND", "Permiso [%s] no encontrado"),
	
	
	
	WRONG_DATA("WRONG_DATA", "Informacion incorrecta [%s]"),
	NOT_FOUND("NOT_FOUND", "Recurso no encontrado [%s]"),

	
	
	JWT_NOT_PARSER("JWT_NOT_PARSER", "El Token no puede ser parseado."),
	JWT_EXPIRED("JWT_EXPIRED", "El Token no puede ser parseado."),
	
	
	SC_UNAUTHORIZED("SC_UNAUTHORIZED", "Acceso al resurco no autorizado."),
	
	WRONG_SENMAIL("WRONG_SENMAIL", "Error al enviar email");
	
	

	private final String code;
	private final String msg;

	ErrorCodesEnum(String code, String msg) {
		this.code = code;
		this.msg = msg;
	}

	public String getCode() {
		return this.code;
	}

	public String getMsg() {
		return this.msg;
	}
}