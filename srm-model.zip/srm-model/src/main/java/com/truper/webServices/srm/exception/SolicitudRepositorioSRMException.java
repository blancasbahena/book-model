package com.truper.webServices.srm.exception;

import com.truper.infra.exception.BaseException;

public class SolicitudRepositorioSRMException extends BaseException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5293056882814582409L;

	public SolicitudRepositorioSRMException(String msg) {
		super(msg);
	}

}
