package com.truper.webServices.srm.pojo;

import com.truper.infra.businessEntities.BaseBusinessEntity;

public class FileDataPOJO extends BaseBusinessEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4015533331322771769L;

	private String fileName;
	private byte[] file;
	private String internalFileName;
	private int tipoArchivo;
	private Integer idOrdenDeCompra;
	private Long idInstanceTracker;
	private Integer idUsuario;
	private Boolean proveedor;
	private boolean proveedorPuedeVer;

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public byte[] getFile() {
		return file;
	}

	public void setFile(byte[] file) {
		this.file = file;
	}

	public String getInternalFileName() {
		return internalFileName;
	}

	public void setInternalFileName(String internalFileName) {
		this.internalFileName = internalFileName;
	}

	public int getTipoArchivo() {
		return tipoArchivo;
	}

	public void setTipoArchivo(int tipoArchivo) {
		this.tipoArchivo = tipoArchivo;
	}

	public Integer getIdOrdenDeCompra() {
		return idOrdenDeCompra;
	}

	public void setIdOrdenDeCompra(Integer idOrdenDeCompra) {
		this.idOrdenDeCompra = idOrdenDeCompra;
	}

	public Integer getIdUsuario() {
		return idUsuario;
	}

	public void setIdUsuario(Integer idUsuario) {
		this.idUsuario = idUsuario;
	}

	public Boolean getProveedor() {
		return proveedor;
	}

	public void setProveedor(Boolean proveedor) {
		this.proveedor = proveedor;
	}

	public Long getIdInstanceTracker() {
		return idInstanceTracker;
	}

	public void setIdInstanceTracker(Long idInstanceTracker) {
		this.idInstanceTracker = idInstanceTracker;
	}

	public boolean isProveedorPuedeVer() {
		return proveedorPuedeVer;
	}

	public void setProveedorPuedeVer(boolean proveedorPuedeVer) {
		this.proveedorPuedeVer = proveedorPuedeVer;
	}

}
