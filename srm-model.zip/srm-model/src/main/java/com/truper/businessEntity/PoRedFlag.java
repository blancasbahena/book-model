package com.truper.businessEntity;

import java.util.List;

import com.truper.infra.businessEntities.BaseBusinessEntity;

public class PoRedFlag extends BaseBusinessEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8043940680328083223L;
	private int id;
	private String po;
	private String proveedor; 
	private int fechaCreacion;
	private String usuarioBloquea;
	private String comentarioProveedor;
	private int fechaRespuesta;
	private String usuarioRespuesta;
	private String comentarioPlaneador;
	private List<SARDetalle> poRedFlagDetalle;
	
	public PoRedFlag() {
		
	}
	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * @return the po
	 */
	public String getPo() {
		return po;
	}
	/**
	 * @param po the po to set
	 */
	public void setPo(String po) {
		this.po = po;
	}
	/**
	 * @return the proveedor
	 */
	public String getProveedor() {
		return proveedor;
	}
	/**
	 * @param proveedor the proveedor to set
	 */
	public void setProveedor(String proveedor) {
		this.proveedor = proveedor;
	}
	/**
	 * @return the fechaCreacion
	 */
	public int getFechaCreacion() {
		return fechaCreacion;
	}
	/**
	 * @param fechaCreacion the fechaCreacion to set
	 */
	public void setFechaCreacion(int fechaCreacion) {
		this.fechaCreacion = fechaCreacion;
	}
	/**
	 * @return the usuarioBloquea
	 */
	public String getUsuarioBloquea() {
		return usuarioBloquea;
	}
	/**
	 * @param usuarioBloquea the usuarioBloquea to set
	 */
	public void setUsuarioBloquea(String usuarioBloquea) {
		this.usuarioBloquea = usuarioBloquea;
	}
	/**
	 * @return the comentarioProveedor
	 */
	public String getComentarioProveedor() {
		return comentarioProveedor;
	}
	/**
	 * @param comentarioProveedor the comentarioProveedor to set
	 */
	public void setComentarioProveedor(String comentarioProveedor) {
		this.comentarioProveedor = comentarioProveedor;
	}
	/**
	 * @return the fechaRespuesta
	 */
	public int getFechaRespuesta() {
		return fechaRespuesta;
	}
	/**
	 * @param fechaRespuesta the fechaRespuesta to set
	 */
	public void setFechaRespuesta(int fechaRespuesta) {
		this.fechaRespuesta = fechaRespuesta;
	}
	/**
	 * @return the usuarioRespuesta
	 */
	public String getUsuarioRespuesta() {
		return usuarioRespuesta;
	}
	/**
	 * @param usuarioRespuesta the usuarioRespuesta to set
	 */
	public void setUsuarioRespuesta(String usuarioRespuesta) {
		this.usuarioRespuesta = usuarioRespuesta;
	}
	/**
	 * @return the comentarioPlaneador
	 */
	public String getComentarioPlaneador() {
		return comentarioPlaneador;
	}
	/**
	 * @param comentarioPlaneador the comentarioPlaneador to set
	 */
	public void setComentarioPlaneador(String comentarioPlaneador) {
		this.comentarioPlaneador = comentarioPlaneador;
	}
	/**
	 * @return the poRedFlagDetalle
	 */
	public List<SARDetalle> getPoRedFlagDetalle() {
		return poRedFlagDetalle;
	}
	/**
	 * @param poRedFlagDetalle the poRedFlagDetalle to set
	 */
	public void setPoRedFlagDetalle(List<SARDetalle> poRedFlagDetalle) {
		this.poRedFlagDetalle = poRedFlagDetalle;
	}
}
