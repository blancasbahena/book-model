package com.truper.businessEntity;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;

import com.truper.infra.businessEntities.BaseBusinessEntity;

public class SARConsolidadosHistorico extends BaseBusinessEntity {
	
	private static final long serialVersionUID = 2290493864173769918L;
	private Integer id;
	private Integer folio;
	private String puertoSalida;
	private Integer naviera;
	private Integer fechaEmbarque;
	private Integer status;
	private Integer tipoContenedor;
	private Integer prioridad;
	private String barcoSugerido;
	private String viaje;
	private String puertoDescarga;
	private String contenedor;
	private String booking;
	private Integer etdPlanner;
	private Integer etdReal;
	private String prioridadConsolidado;
	private HashMap<String, String>  mapaProveedores;
	private Integer transporte;
	private String comentarioConsol;
	private Integer fechaModficacion;
	private String usuarioMof;
	
	private String 	tipoProducto;
	private Integer tipoRetraso;
	private String 	retrasoProveedor;
	private Boolean		esDesbloqueado;
	
	
	/** Variables que no estan en la tabla **/
	private double 		peso;
	private double 		volumen;
	private String POsEnConsolidado;
	private BigDecimal 	backorderPronosticadoTot;
	private BigDecimal 	valorContenedor;
	private ArrayList<String>	listaPos;
	
	public SARConsolidadosHistorico(){}
	
	public SARConsolidadosHistorico(SARConsolidados bean){
		 //id = bean.get;
		 this.folio = bean.getFolio();
		 this.puertoSalida = bean.getPuertoSalida();
		 this.naviera = bean.getNaviera();
		 this.fechaEmbarque = bean.getFechaEmbarque();
		 this.status = bean.getStatus();
		 this.tipoContenedor = bean.getTipoContenedor();
		 this.prioridad = bean.getPrioridad();
		 this.barcoSugerido = bean.getBarcoSugerido();
		 this.viaje = bean.getViaje();
		 this.puertoDescarga = bean.getPuertoDescarga();
		 this.contenedor = bean.getContenedor();
		 this.booking = bean.getBooking();
		 //etdPlanner = bean.get;
		 this.etdReal = bean.getEtdReal();
		 //prioridadConsolidado = bean.get;
		 //mapaProveedores = bean.get;
		 this.transporte = bean.getTransporte();
		 //comentarioConsol = bean.getc;					 
		 this.listaPos = bean.getListaPos();
		
	}
	
	
	public Integer getFolio() {
		return folio;
	}
	public void setFolio(Integer folio) {
		this.folio = folio;
	}
	
	public String getPuertoSalida() {
		return puertoSalida;
	}

	public void setPuertoSalida(String puertoSalida) {
		this.puertoSalida = puertoSalida;
	}

	public Integer getNaviera() {
		return naviera;
	}
	public void setNaviera(Integer naviera) {
		this.naviera = naviera;
	}
	public Integer getFechaEmbarque() {
		return fechaEmbarque;
	}
	public void setFechaEmbarque(Integer fechaEmbarque) {
		this.fechaEmbarque = fechaEmbarque;
	}
	public Integer getStatus() {
		return status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
	public Integer getTipoContenedor() {
		return tipoContenedor;
	}
	public void setTipoContenedor(Integer tipoContenedor) {
		this.tipoContenedor = tipoContenedor;
	}
	public Integer getPrioridad() {
		return prioridad;
	}
	public void setPrioridad(Integer prioridad) {
		this.prioridad = prioridad;
	}
	public String getBarcoSugerido() {
		return barcoSugerido;
	}
	public void setBarcoSugerido(String barcoSugerido) {
		this.barcoSugerido = barcoSugerido;
	}
	public String getViaje() {
		return viaje;
	}
	public void setViaje(String viaje) {
		this.viaje = viaje;
	}
	public String getPuertoDescarga() {
		return puertoDescarga;
	}
	public void setPuertoDescarga(String puertoDescarga) {
		this.puertoDescarga = puertoDescarga;
	}
	public String getContenedor() {
		return contenedor;
	}
	public void setContenedor(String contenedor) {
		this.contenedor = contenedor;
	}
	public String getBooking() {
		return booking;
	}
	public void setBooking(String booking) {
		this.booking = booking;
	}
	public String getPrioridadConsolidado() {
		return prioridadConsolidado;
	}
	public void setPrioridadConsolidado(String prioridadConsolidado) {
		this.prioridadConsolidado = prioridadConsolidado;
	}

	public double getPeso() {
		return peso;
	}

	public void setPeso(double peso) {
		this.peso = peso;
	}

	public double getVolumen() {
		return volumen;
	}

	public void setVolumen(double volumen) {
		this.volumen = volumen;
	}

	public HashMap<String, String> getMapaProveedores() {
		return mapaProveedores;
	}
	public void setMapaProveedores(HashMap<String, String> mapaProveedores) {
		this.mapaProveedores = mapaProveedores;
	}
	public String getPOsEnConsolidado() {
		return POsEnConsolidado;
	}
	public void setPOsEnConsolidado(String pOsEnConsolidado) {
		POsEnConsolidado = pOsEnConsolidado;
	}
	public BigDecimal getBackorderPronosticadoTot() {
		return backorderPronosticadoTot;
	}
	public void setBackorderPronosticadoTot(BigDecimal backorderPronosticadoTot) {
		this.backorderPronosticadoTot = backorderPronosticadoTot;
	}

	public Integer getEtdPlanner() {
		return etdPlanner;
	}

	public void setEtdPlanner(Integer etdPlanner) {
		this.etdPlanner = etdPlanner;
	}
	public Integer getEtdReal() {
		return etdReal;
	}
	public void setEtdReal(Integer etdReal) {
		this.etdReal = etdReal;
	}
	public Integer getTransporte() {
		return transporte;
	}
	public void setTransporte(Integer transporte) {
		this.transporte = transporte;
	}
	public String getComentarioConsol() {
		return comentarioConsol;
	}
	public void setComentarioConsol(String comentarioConsol) {
		this.comentarioConsol = comentarioConsol;
	}
	public BigDecimal getValorContenedor() {
		return valorContenedor;
	}
	public void setValorContenedor(BigDecimal valorContenedor) {
		this.valorContenedor = valorContenedor;
	}
	public ArrayList<String> getListaPos() {
		return listaPos;
	}
	public void setListaPos(ArrayList<String> listaPos) {
		this.listaPos = listaPos;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getFechaModficacion() {
		return fechaModficacion;
	}

	public void setFechaModficacion(Integer fechaModficacion) {
		this.fechaModficacion = fechaModficacion;
	}

	public String getUsuarioMof() {
		return usuarioMof;
	}

	public void setUsuarioMof(String usuarioMof) {
		this.usuarioMof = usuarioMof;
	}

	public String getTipoProducto() {
		return tipoProducto;
	}

	public void setTipoProducto(String tipoProducto) {
		this.tipoProducto = tipoProducto;
	}

	public Integer getTipoRetraso() {
		return tipoRetraso;
	}

	public void setTipoRetraso(Integer tipoRetraso) {
		this.tipoRetraso = tipoRetraso;
	}

	public String getRetrasoProveedor() {
		return retrasoProveedor;
	}

	public void setRetrasoProveedor(String retrasoProveedor) {
		this.retrasoProveedor = retrasoProveedor;
	}

	public Boolean getEsDesbloqueado() {
		return esDesbloqueado;
	}

	public void setEsDesbloqueado(Boolean esDesbloqueado) {
		this.esDesbloqueado = esDesbloqueado;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("SARConsolidadosHistorico [getFolio=");
		builder.append(getFolio());
		builder.append(", getPuertoSalida=");
		builder.append(getPuertoSalida());
		builder.append(", getNaviera=");
		builder.append(getNaviera());
		builder.append(", getFechaEmbarque=");
		builder.append(getFechaEmbarque());
		builder.append(", getStatus=");
		builder.append(getStatus());
		builder.append(", getTipoContenedor=");
		builder.append(getTipoContenedor());
		builder.append(", getPrioridad=");
		builder.append(getPrioridad());
		builder.append(", getBarcoSugerido=");
		builder.append(getBarcoSugerido());
		builder.append(", getViaje=");
		builder.append(getViaje());
		builder.append(", getPuertoDescarga=");
		builder.append(getPuertoDescarga());
		builder.append(", getContenedor=");
		builder.append(getContenedor());
		builder.append(", getBooking=");
		builder.append(getBooking());
		builder.append(", getPrioridadConsolidado=");
		builder.append(getPrioridadConsolidado());
		builder.append(", getPeso=");
		builder.append(getPeso());
		builder.append(", getVolumen=");
		builder.append(getVolumen());
		builder.append(", getMapaProveedores=");
		builder.append(getMapaProveedores());
		builder.append(", getPOsEnConsolidado=");
		builder.append(getPOsEnConsolidado());
		builder.append(", getBackorderPronosticadoTot=");
		builder.append(getBackorderPronosticadoTot());
		builder.append(", getEtdPlanner=");
		builder.append(getEtdPlanner());
		builder.append(", getEtdReal=");
		builder.append(getEtdReal());
		builder.append(", getTransporte=");
		builder.append(getTransporte());
		builder.append(", getComentarioConsol=");
		builder.append(getComentarioConsol());
		builder.append(", getValorContenedor=");
		builder.append(getValorContenedor());
		builder.append(", getListaPos=");
		builder.append(getListaPos());
		builder.append(", getId=");
		builder.append(getId());
		builder.append(", getFechaModficacion=");
		builder.append(getFechaModficacion());
		builder.append(", getUsuarioMof=");
		builder.append(getUsuarioMof());
		builder.append(", getTipoProducto=");
		builder.append(getTipoProducto());
		builder.append(", getTipoRetraso=");
		builder.append(getTipoRetraso());
		builder.append(", getRetrasoProveedor=");
		builder.append(getRetrasoProveedor());
		builder.append(", getEsDesbloqueado=");
		builder.append(getEsDesbloqueado());
		builder.append("]");
		return builder.toString();
	}
}
