package com.truper.businessEntity.SRM;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.truper.infra.businessEntities.BaseBusinessEntity;

@Entity
@Table(name = "srm_TRAY_DETAIL")
public class DetalleBandeja extends BaseBusinessEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4226789335873616436L;

	@Column(name = "ID_PO")
	private Long idPO;
	@Column(name = "SEMAFORO_GENERAL")
	private Boolean semaforoGenaral;
	@Column(name = "SEMAFORO_COMPRAS")
	private Boolean semaforoCompras;
	@Column(name = "SEMAFORO_PLANEACION")
	private Boolean semaforoPlaneacion;
	@Column(name = "NUMERO_OC")
	private Integer numeroOC;
	@Column(name = "NOMBRE_PROVEEDOR")
	private String nombreProveedor;
	@Column(name = "NUMERO_PROVEEDOR")
	private Integer numeroProveedor;
	@Column(name = "FECHA_CREACION")
	private String fechaCreacion;
	@Column(name = "CELULA_COMPRAS")
	private String celulaCompras;
	@Column(name = "NOMBRE_COMPRADOR")
	private String comprador;
	@Column(name = "CELULA_PLANEADOR")
	private String celulaPlaneacion;
	@Column(name = "NOMBRE_PLANEADOR")
	private String planeador;
	@Column(name = "TIPO_ETIQUETA")
	private String tipoEtiqueta;

	public Long getIdPO() {
		return idPO;
	}

	public void setIdPO(Long idPO) {
		this.idPO = idPO;
	}

	public Boolean getSemaforoGenaral() {
		return semaforoGenaral;
	}

	public void setSemaforoGenaral(Boolean semaforoGenaral) {
		this.semaforoGenaral = semaforoGenaral;
	}

	public Boolean getSemaforoCompras() {
		return semaforoCompras;
	}

	public void setSemaforoCompras(Boolean semaforoCompras) {
		this.semaforoCompras = semaforoCompras;
	}

	public Boolean getSemaforoPlaneacion() {
		return semaforoPlaneacion;
	}

	public void setSemaforoPlaneacion(Boolean semaforoPlaneacion) {
		this.semaforoPlaneacion = semaforoPlaneacion;
	}

	public Integer getNumeroOC() {
		return numeroOC;
	}

	public void setNumeroOC(Integer numeroOC) {
		this.numeroOC = numeroOC;
	}

	public String getNombreProveedor() {
		return nombreProveedor;
	}

	public void setNombreProveedor(String nombreProveedor) {
		this.nombreProveedor = nombreProveedor;
	}

	public Integer getNumeroProveedor() {
		return numeroProveedor;
	}

	public void setNumeroProveedor(Integer numeroProveedor) {
		this.numeroProveedor = numeroProveedor;
	}

	public String getFechaCreacion() {
		return fechaCreacion;
	}

	public void setFechaCreacion(String fechaCreacion) {
		this.fechaCreacion = fechaCreacion;
	}

	public String getCelulaCompras() {
		return celulaCompras;
	}

	public void setCelulaCompras(String celulaCompras) {
		this.celulaCompras = celulaCompras;
	}

	public String getComprador() {
		return comprador;
	}

	public void setComprador(String comprador) {
		this.comprador = comprador;
	}

	public String getCelulaPlaneacion() {
		return celulaPlaneacion;
	}

	public void setCelulaPlaneacion(String celulaPlaneacion) {
		this.celulaPlaneacion = celulaPlaneacion;
	}

	public String getPlaneador() {
		return planeador;
	}

	public void setPlaneador(String planeador) {
		this.planeador = planeador;
	}

	public String getTipoEtiqueta() {
		return tipoEtiqueta;
	}

	public void setTipoEtiqueta(String tipoEtiqueta) {
		this.tipoEtiqueta = tipoEtiqueta;
	}

}
