package com.truper.businessEntity;

import java.math.BigDecimal;
import java.util.Date;

import com.truper.bpm.enums.TipoPosicionEnum;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Data
@ToString
public class BeanPriceReleasePosicion implements Comparable<BeanPriceReleasePosicion> {

	private int folio;
	private String po;
	private int posicion;
	private String material;
	private String material_descripcion;
	private int cantidad;
	private String centro;
	private BigDecimal precioUnitario;
	private TipoPosicionEnum tipo;
	private String subTipo;
	private boolean pago;
	private BigDecimal precioUnitarioSAP;
	private Date createDate;
	private String planeador;
	private String unidadNegocio;
	private String unidadNegocioNombre;
	private boolean precioActualizado;
	private boolean pagadero;
	private BigDecimal precioUnitarioActualizado;
	private String moneda;
	private String unidadMedida;
	private Date updateDate;
	private boolean matriz;
	private String disagreeComments;
	private boolean isSeasonal;
	private String totalVar12Semanas;
	private String totalVar8Semanas;
	private char abc;
	private String overStock;
	private String overStockPct;
	private String puertoOrigen;
	private boolean megaAltaVolumetria;
	private Integer daysAdvanced;
	private Integer daysDelayed;

	public BeanPriceReleasePosicion() {
		super();
	}

	public BeanPriceReleasePosicion(int folio, String po, int posicion, String material, int cantidad,
			BigDecimal precioUnitario, TipoPosicionEnum tipo, String subTipo, boolean pago,
			BigDecimal precioUnitarioSAP, Date createDate) {
		this();
		this.folio = folio;
		this.po = po;
		this.posicion = posicion;
		this.material = material;
		this.cantidad = cantidad;
		this.precioUnitario = precioUnitario;
		this.tipo = tipo;
		this.subTipo = subTipo;
		this.pago = pago;
		this.precioUnitarioSAP = precioUnitarioSAP;
		this.createDate = createDate;
	}

	@Override
	public int compareTo(BeanPriceReleasePosicion bean) {
		int valor = Integer.compare(getFolio(), bean.getFolio());
		if (valor != 0) {
			return valor;
		}
		valor = getTipo().compareTo(bean.getTipo());
		if (valor != 0) {
			return valor;
		}
		if (getPo() == null && bean.getPo() != null) {
			return 1;
		} else if (getPo() == null && bean.getPo() == null) {
			valor = 0;
		} else if (getPo() != null && bean.getPo() == null) {
			return -1;
		} else {
			valor = getPo().compareTo(bean.getPo());
		}
		if (valor != 0) {
			return valor;
		}
		valor = Integer.compare(getPosicion(), bean.getPosicion());
		if (valor != 0) {
			return valor;
		}
		valor = getMaterial().compareToIgnoreCase(getMaterial());
		return valor;
	}
}
