package com.truper.businessEntity;

import java.util.Date;

public class BeanXdias{
	
	private String po;
	private int dias;
	private Date createDate;
	private Date matrices;
	private Date etd;
	
	
	public String getPo() {
		return po;
	}
	public void setPo(String po) {
		this.po = po;
	}
	public int getDias() {
		return dias;
	}
	public void setDias(int dias) {
		this.dias = dias;
	}
	public Date getCreateDate() {
		return createDate;
	}
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
	public Date getMatrices() {
		return matrices;
	}
	public void setMatrices(Date matrices) {
		this.matrices = matrices;
	}
	public Date getEtd() {
		return etd;
	}
	public void setEtd(Date etd) {
		this.etd = etd;
	}
}