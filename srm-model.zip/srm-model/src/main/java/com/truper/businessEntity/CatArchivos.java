package com.truper.businessEntity;

import java.io.Serializable;

import lombok.Data;

@Data
public class CatArchivos implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private int idArchivo;
	private String nombre;
	private String nombreCorto;
	private int orden;
	private int tamanoMax;
	private int numMinimo;
	private int numMaximo;

}
