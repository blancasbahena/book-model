package com.truper.businessEntity;

public class BeanMatricesAuditoriaUpdate {
	
	private String po;
	private int posicion;
	private int etd;
	private String documentosRequeridos;
	private String resultado;
	
	
	public String getPo() {
		return po;
	}
	public void setPo(String po) {
		this.po = po;
	}
	public int getPosicion() {
		return posicion;
	}
	public void setPosicion(int posicion) {
		this.posicion = posicion;
	}
	public int getEtd() {
		return etd;
	}
	public void setEtd(int etd) {
		this.etd = etd;
	}
	public String getDocumentosRequeridos() {
		return documentosRequeridos;
	}
	public void setDocumentosRequeridos(String documentosRequeridos) {
		this.documentosRequeridos = documentosRequeridos;
	}
	public String getResultado() {
		return resultado;
	}
	public void setResultado(String resultado) {
		this.resultado = resultado;
	}
	
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("BeanMatricesAuditoriaUpdate [po=");
		builder.append(po);
		builder.append(", posicion=");
		builder.append(posicion);
		builder.append(", etd=");
		builder.append(etd);
		builder.append(", documentosRequeridos=");
		builder.append(documentosRequeridos);
		builder.append(", resultado=");
		builder.append(resultado);
		builder.append("]");
		return builder.toString();
	}

	
	
}