package com.truper.businessEntity;

import java.util.HashMap;
import java.util.Map;

import com.truper.infra.businessEntities.BaseBusinessEntity;

public class AirportArrivalLocation extends BaseBusinessEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4458549574418172216L;

	// Se pone el constructor privado para que esta clase no pueda ser
	// instanciada y solo se pueda acceder a su mapa de manera estatica
	private AirportArrivalLocation() {
	}

	public static final Map<Integer, String> arrivalLocationMap;

	static {
		Map<Integer, String> m = new HashMap<Integer, String>();
		m.put(1, "Cd. de México");
		m.put(2, "Toluca");
		arrivalLocationMap = m;
	}

}
