package com.truper.businessEntity;

import javax.mail.internet.InternetAddress;

/**
 * 
 * @author lsserranod
 *Bean para armar cuenpo de correo
 */
public class EmailAsynBean {

	private InternetAddress[] address;
	private String[] cc;
	private String[] bcc;
	private String subject;
	private String msg;
	private String sender;

	
	
	
	public EmailAsynBean(InternetAddress[] address, String[] cc, String[] bcc, String subject, String msg,
			String sender) {
		super();
		this.address = address;
		this.cc = cc;
		this.bcc = bcc;
		this.subject = subject;
		this.msg = msg;
		this.sender = sender;
	}

	public String getSender() {
		return sender;
	}

	public void setSender(String sender) {
		this.sender = sender;
	}

	public InternetAddress[] getAddress() {
		return address;
	}

	public void setAddress(InternetAddress[] address) {
		this.address = address;
	}

	public String[] getCc() {
		return cc;
	}

	public void setCc(String[] cc) {
		this.cc = cc;
	}

	public String[] getBcc() {
		return bcc;
	}

	public void setBcc(String[] bcc) {
		this.bcc = bcc;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}
}
