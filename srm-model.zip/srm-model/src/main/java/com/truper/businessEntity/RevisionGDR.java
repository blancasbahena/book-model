package com.truper.businessEntity;

import java.math.BigDecimal;
import java.util.List;

import com.truper.infra.businessEntities.BaseBusinessEntity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class RevisionGDR extends BaseBusinessEntity implements Cloneable {
    
    private static final long serialVersionUID = 1L;
    private Integer idRevisionGDR;
    private Integer folio;
    private Integer fechaGDRActual;
    private Integer fechaGDRModificada;
    private Integer fechaETDActual;
    private Integer fechaETDModificada;
    private Boolean activo;
    private Integer diferenciaDiasETD;
    
    //Format
    private Boolean consolidado;
    private String folioRaw;
    private String folioVista;
    private String colorWarning;
    private String textoWarning;
    private String dameIconosHTML;
    private String proveedor;
    private String puertoOrigen;
    private String puertoDescarga;
    private String naviera;
    private String barcoSugerido;
    private String viaje;
    private String contenedor;
    private String booking;
    private String fechaGDRActualFormat;
    private String fechaGDRModificadaFormat;
    private String fechaETDActualFormat;
    private String fechaETDModificadaFormat;
    private List<?> detalle;
    private List<?> detalleOtros;
    private String messageGRDrechazo;
	private String messageGRDaprobacion;
	private Boolean approvalGRDlineacion;
	private double totalPeso;
	private double totalVolumen;
	private BigDecimal totalBackorder;
	private double totalOverStock;
	private Integer statusAnteriorGRD;
	private Integer statusActualGRD;
	
    public RevisionGDR(Integer folio,Integer fechaGDRActual,Integer fechaGDRModificada,Integer fechaETDActual,Integer fechaETDModificada) {
    	this.activo =true;
    	this.folio =  folio;
    	this.idRevisionGDR=folio;
    	if(fechaGDRActual!=null) {
    		this.fechaGDRActual= fechaGDRActual;
    	}
    	if(fechaGDRModificada!=null) {
    		this.fechaGDRModificada= fechaGDRModificada;
    	}else {
    		if(fechaGDRActual!=null) {
    			this.fechaGDRModificada= fechaGDRActual;
    		}
    	}
    	
    	if(fechaETDActual!=null) {
    		this.fechaETDActual= fechaETDActual;
    	}
    	if(fechaETDModificada!=null) {
    		this.fechaETDModificada= fechaETDModificada;
    	}else {
    		if(fechaGDRActual!=null) {
    			this.fechaETDModificada= fechaETDActual;
    		}
    	}
    	this.diferenciaDiasETD =0;
    	if(this.fechaETDActual!=null && this.fechaETDModificada!=null) {
    		this.diferenciaDiasETD = (this.fechaETDActual - this.fechaETDModificada);
    	}
    }
}
