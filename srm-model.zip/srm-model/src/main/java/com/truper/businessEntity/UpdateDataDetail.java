package com.truper.businessEntity;

import java.math.BigDecimal;

import lombok.Getter;
import lombok.Setter;


public class UpdateDataDetail extends Position{

	@Getter @Setter private int folio;
	@Getter @Setter private BigDecimal unitPrice;
	@Getter @Setter private BigDecimal unitPriceOld;
	@Getter @Setter private String moneda;
	@Getter @Setter private String monedaOld;
	@Getter @Setter private String condPago;
	@Getter @Setter private String condPagoOld;
	@Getter @Setter private boolean result;
	@Getter @Setter private String centro;
	
}