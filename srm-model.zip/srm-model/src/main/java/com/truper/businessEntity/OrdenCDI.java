package com.truper.businessEntity;

import java.math.BigDecimal;

import com.truper.infra.businessEntities.BaseBusinessEntity;

public class OrdenCDI extends BaseBusinessEntity{

	/**
	 * 
	 */
	private static final long serialVersionUID = 5041704107648564330L;
	private String orden;
	private String posicion;
	private String material;
	private String centro;
	private String planeador;
	private Integer contenedor;
	private String cliente;
	private Integer eta;
	private Integer eta2;
	private Integer etd;
	private Integer ida;
	
	private double peso;
	private double volumen;
	private double remanente;
	private double pesoRemanente;
	private double volumenRemanente;
	private double overStock;
	
	private int fechaUltimaConfirmacion;
	private int fechaProforma;
	
	private BigDecimal cantidad;
	
	private String  moneda;
	private BigDecimal  precioUnitario;
	
	private String condicionPago;
	private String unidadMedida;
	
	private boolean esPedidoDirecto;
	private int master;
	private String almacen;

	
		
	public OrdenCDI(String orden, String posicion, String material, BigDecimal cantidad, String centro, String planeador, Integer contenedor,String cliente){
		this.orden = orden;
		this.posicion = posicion;
		this.material = material;
		this.cantidad = cantidad;
		this.centro = centro;
		this.planeador = planeador;
		this.contenedor = contenedor;
		this.cliente = cliente;
	}

	public String getOrden() {
		return orden;
	}

	public void setOrden(String orden) {
		this.orden = orden;
	}

	public String getPosicion() {
		return posicion;
	}

	public void setPosicion(String posicion) {
		this.posicion = posicion;
	}

	public String getMaterial() {
		return material;
	}

	public String getPlaneador() {
		return planeador;
	}

	public void setPlaneador(String planeador) {
		this.planeador = planeador;
	}
	
	public void setMaterial(String material) {
		this.material = material;
	}
	
	public Integer getContenedor() {
		return contenedor;
	}

	public void setContenedor(Integer contenedor) {
		this.contenedor = contenedor;
	}

	public double getPeso() {
		return peso;
	}

	public void setPeso(double peso) {
		this.peso = peso;
	}

	public double getVolumen() {
		return volumen;
	}

	public void setVolumen(double volumen) {
		this.volumen = volumen;
	}

	public BigDecimal getCantidad() {
		return cantidad;
	}

	public void setCantidad(BigDecimal cantidad) {
		this.cantidad = cantidad;
	}

	public double getRemanente() {
		return remanente;
	}

	public void setRemanente(double remanente) {
		this.remanente = remanente;
	}
	
	public int getFechaUltimaConfirmacion() {
		return fechaUltimaConfirmacion;
	}

	public void setFechaUltimaConfirmacion(int fechaUltimaConfirmacion) {
		this.fechaUltimaConfirmacion = fechaUltimaConfirmacion;
	}

	public int getFechaProforma() {
		return fechaProforma;
	}

	public void setFechaProforma(int fechaProforma) {
		this.fechaProforma = fechaProforma;
	}

	public String getCentro() {
		return centro;
	}

	public void setCentro(String centro) {
		this.centro = centro;
	}

	public String getMoneda() {
		return moneda;
	}

	public void setMoneda(String moneda) {
		this.moneda = moneda;
	}

	public String getCliente() {
		return cliente;
	}

	public void setCliente(String cliente) {
		this.cliente = cliente;
	}

	public String getCondicionPago() {
		return condicionPago;
	}

	public void setCondicionPago(String condicionPago) {
		this.condicionPago = condicionPago;
	}

	public String getUnidadMedida() {
		return unidadMedida;
	}

	public void setUnidadMedida(String unidadMedida) {
		this.unidadMedida = unidadMedida;
	}

	public double getPesoRemanente() {
		return pesoRemanente;
	}

	public void setPesoRemanente(double pesoRemanente) {
		this.pesoRemanente = pesoRemanente;
	}

	public double getVolumenRemanente() {
		return volumenRemanente;
	}

	public void setVolumenRemanente(double volumenRemanente) {
		this.volumenRemanente = volumenRemanente;
	}

	public boolean isEsPedidoDirecto() {
		return esPedidoDirecto;
	}

	public void setEsPedidoDirecto(boolean esPedidoDirecto) {
		this.esPedidoDirecto = esPedidoDirecto;
	}

	/**
	 * @return the eta
	 */
	public Integer getEta() {
		return eta;
	}

	/**
	 * @param eta the eta to set
	 */
	public void setEta(Integer eta) {
		this.eta = eta;
	}

	/**
	 * @return the eta2
	 */
	public Integer getEta2() {
		return eta2;
	}

	/**
	 * @param eta2 the eta2 to set
	 */
	public void setEta2(Integer eta2) {
		this.eta2 = eta2;
	}

	public double getOverStock() {
		return overStock;
	}

	public void setOverStock(double overStock) {
		this.overStock = overStock;
	}
	
	
	/**
	 * @return the etd
	 */
	public Integer getEtd() {
		return etd;
	}

	/**
	 * @param etd the etd to set
	 */
	public void setEtd(Integer etd) {
		this.etd = etd;
	}

	/**
	 * @return the ida
	 */
	public Integer getIda() {
		return ida;
	}

	/**
	 * @param ida the ida to set
	 */
	public void setIda(Integer ida) {
		this.ida = ida;
	}

	/**
	 * @return the a
	 */
	public int getMaster() {
		return master;
	}

	/**
	 * @param master the master to set
	 */
	public void setMaster(int master) {
		this.master = master;
	}
	/**
	 * @return the almacen
	 */
	public String getAlmacen() {
		return almacen;
	}

	/**
	 * @param master the almacen to set
	 */
	public void setAlmacen(String almacen) {
		this.almacen = almacen;
	}

	public BigDecimal getPrecioUnitario() {
		return precioUnitario;
	}

	public void setPrecioUnitario(BigDecimal precioUnitario) {
		this.precioUnitario = precioUnitario;
	}


	
	
	
	
}
