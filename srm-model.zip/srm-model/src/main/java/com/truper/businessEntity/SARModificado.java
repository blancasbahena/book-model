package com.truper.businessEntity;

import com.truper.infra.businessEntities.BaseBusinessEntity;

public class SARModificado extends BaseBusinessEntity{
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -6515344254381666573L;
	//Datos que hay en tabla
	private Integer folio;
	private Integer etd;
	private Integer etdModificada;
	private String comentarioProveedor;
	private Boolean cambiosRevFinalApplied;
	private Boolean needsAuthPlanningMgr;
	private boolean esConsultaParaInser;
	
	public Integer getFolio() {
		return folio;
	}
	public void setFolio(Integer folio) {
		this.folio = folio;
	}
	public Integer getEtd() {
		return etd;
	}
	public void setEtd(Integer etd) {
		this.etd = etd;
	}
	public Integer getEtdModificada() {
		return etdModificada;
	}
	public void setEtdModificada(Integer etdModificada) {
		this.etdModificada = etdModificada;
	}
	public String getComentarioProveedor() {
		return comentarioProveedor;
	}
	public void setComentarioProveedor(String comentarioProveedor) {
		this.comentarioProveedor = comentarioProveedor;
	}
	public Boolean getCambiosRevFinalApplied() {
		return cambiosRevFinalApplied;
	}
	public void setCambiosRevFinalApplied(Boolean cambiosRevFinalApplied) {
		this.cambiosRevFinalApplied = cambiosRevFinalApplied;
	}
	public Boolean getNeedsAuthPlanningMgr() {
		return needsAuthPlanningMgr;
	}
	public void setNeedsAuthPlanningMgr(Boolean needsAuthPlanningMgr) {
		this.needsAuthPlanningMgr = needsAuthPlanningMgr;
	}
	public boolean isEsConsultaParaInser() {
		return esConsultaParaInser;
	}
	public void setEsConsultaParaInser(boolean esConsultaParaInser) {
		this.esConsultaParaInser = esConsultaParaInser;
	}
	
}