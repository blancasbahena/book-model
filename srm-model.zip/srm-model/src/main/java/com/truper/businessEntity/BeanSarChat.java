package com.truper.businessEntity;

import com.truper.infra.businessEntities.BaseBusinessEntity;

public class BeanSarChat extends BaseBusinessEntity{

	/**
	 * 
	 */
	private static final long serialVersionUID = -7837536273801921005L;
	private int id;
	private String mensaje;
	private String usuario;
	private int fecha;
	private long fechaMillis;
	private String folio;
	private boolean proveedor;
	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * @return the mensaje
	 */
	public String getMensaje() {
		return mensaje;
	}
	/**
	 * @param mensaje the mensaje to set
	 */
	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}
	/**
	 * @return the usuario
	 */
	public String getUsuario() {
		return usuario;
	}
	/**
	 * @param usuario the usuario to set
	 */
	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}
	/**
	 * @return the fecha
	 */
	public int getFecha() {
		return fecha;
	}
	/**
	 * @param fecha the fecha to set
	 */
	public void setFecha(int fecha) {
		this.fecha = fecha;
	}
	/**
	 * @return the fechaMillis
	 */
	public long getFechaMillis() {
		return fechaMillis;
	}
	/**
	 * @param fechaMillis the fechaMillis to set
	 */
	public void setFechaMillis(long fechaMillis) {
		this.fechaMillis = fechaMillis;
	}
	/**
	 * @return the folio
	 */
	public String getFolio() {
		return folio;
	}
	/**
	 * @param folio the folio to set
	 */
	public void setFolio(String folio) {
		this.folio = folio;
	}
	/**
	 * @return the proveedor
	 */
	public boolean isProveedor() {
		return proveedor;
	}
	/**
	 * @param proveedor the proveedor to set
	 */
	public void setProveedor(boolean proveedor) {
		this.proveedor = proveedor;
	}
	
	

}
