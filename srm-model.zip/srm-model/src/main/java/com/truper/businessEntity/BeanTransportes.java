package com.truper.businessEntity;

import java.util.HashMap;
import java.util.Map;

import com.truper.infra.businessEntities.BaseBusinessEntity;

public class BeanTransportes extends BaseBusinessEntity{

	/**
	 * 
	 */
	private static final long serialVersionUID = 2446794137624131094L;
	public static Map<Integer, String> transportesCDI;
	
	public BeanTransportes(){
	}
	
	static {
		Map<Integer, String> m = new HashMap<Integer, String>();
		m.put(1, "Fast Train");
		m.put(2, "Hauler");
		m.put(3, "Train");
		transportesCDI = m;
	}
}
