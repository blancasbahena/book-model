package com.truper.businessEntity;

import com.truper.infra.businessEntities.BaseBusinessEntity;

public class OrdenCDIIncompletaEnSAR extends BaseBusinessEntity{

	/**
	 * 
	 */
	private static final long serialVersionUID = -7341733799231562745L;
	private int folio;
	private int posicion;
	private int cantidadOrden;
	private int cantidadSAR;
	
	private String po;
	private String proveedor;
	
	public OrdenCDIIncompletaEnSAR(int folio, String po, int posicion, String proveedor){
		this.folio = folio;
		this.po = po;
		this.posicion = posicion;
		this.proveedor = proveedor;
	}

	public int getCantidadOrden() {
		return cantidadOrden;
	}

	public void setCantidadOrden(int cantidadOrden) {
		this.cantidadOrden = cantidadOrden;
	}

	public int getCantidadSAR() {
		return cantidadSAR;
	}

	public void setCantidadSAR(int cantidadSAR) {
		this.cantidadSAR = cantidadSAR;
	}

	public int getFolio() {
		return folio;
	}

	public int getPosicion() {
		return posicion;
	}

	public String getPo() {
		return po;
	}

	public String getProveedor() {
		return proveedor;
	}
}
