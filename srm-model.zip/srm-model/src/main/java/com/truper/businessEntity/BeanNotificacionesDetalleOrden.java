package com.truper.businessEntity;

import com.truper.infra.businessEntities.BaseBusinessEntity;

public class BeanNotificacionesDetalleOrden extends BaseBusinessEntity {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -4464174892533748185L;
	private String 	numeroorden;
	private Integer posicion;
	private String  material;
	private Integer cantidad;
	private String 	proveedor;
	private Integer fechaProforma;
	private String  planeador;
	private String  ordenCerrada;
	private Integer proformaSAP;
	private Boolean eliminarSAR;
	
	//variables que no estan en la tabla
	
	private boolean esnormal;///si entra en el caso normal
	private String  error;
	private boolean esError; 
	
		public String getNumeroorden() {
		return numeroorden;
	}
	public void setNumeroorden(String numeroorden) {
		this.numeroorden = numeroorden;
	}
	public Integer getPosicion() {
		return posicion;
	}
	public void setPosicion(Integer posicion) {
		this.posicion = posicion;
	}
	public String getMaterial() {
		return material;
	}
	public void setMaterial(String material) {
		this.material = material;
	}
	public Integer getFechaProforma() {
		return fechaProforma;
	}
	public void setFechaProforma(Integer fechaProforma) {
		this.fechaProforma = fechaProforma;
	}
	public String getPlaneador() {
		return planeador;
	}
	public void setPlaneador(String planeador) {
		this.planeador = planeador;
	}
	public String getOrdenCerrada() {
		return ordenCerrada;
	}
	public void setOrdenCerrada(String ordenCerrada) {
		this.ordenCerrada = ordenCerrada;
	}
	public Integer getCantidad() {
		return cantidad;
	}
	public void setCantidad(Integer cantidad) {
		this.cantidad = cantidad;
	}
	/**
	 * @return the proveedor
	 */
	public String getProveedor() {
		return proveedor;
	}
	/**
	 * @param proveedor the proveedor to set
	 */
	public void setProveedor(String proveedor) {
		this.proveedor = proveedor;
	}
	public boolean isEsnormal() {
		return esnormal;
	}
	public void setEsnormal(boolean esnormal) {
		this.esnormal = esnormal;
	}
	public String getError() {
		return error;
	}
	public void setError(String error) {
		this.error = error;
	}
	public boolean isEsError() {
		return esError;
	}
	public void setEsError(boolean esError) {
		this.esError = esError;
	}
	public Integer getProformaSAP() {
		return proformaSAP;
	}
	public void setProformaSAP(Integer proformaSAP) {
		this.proformaSAP = proformaSAP;
	}
	public Boolean getEliminarSAR() {
		return eliminarSAR;
	}
	public void setEliminarSAR(Boolean eliminarSAR) {
		this.eliminarSAR = eliminarSAR;
	}
	
}

