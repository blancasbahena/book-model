package com.truper.businessEntity.SRM;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Table;

import com.truper.infra.businessEntities.BaseBusinessEntity;
import com.truper.infra.businessEntities.Usuario;

/**
 * @author Pablo Cruz Santos
 * @version 1.0
 * @date 17/12/2015
 */
@Entity
@Table(name = "srm_SEGUIMIENTO")
public class Seguimiento extends BaseBusinessEntity {

	private static final long serialVersionUID = 1753581957030987270L;

	@Id
	@Column(name = "ID", updatable = false, unique = true, insertable = false)
	private Integer id;

	@JoinColumn(table = "SRM_USUARIO", name = "USER_ID", referencedColumnName = "ID")
	private Usuario usuario;

	@Column(name = "ORDEN_COMPRA")
	private String ordenCompra;

	@Column(name = "FECHA")
	private Date fecha;

	@Column(name = "SIGUIENDO")
	private Boolean siguiendo;

	@Column(name = "USER_ID")
	private Integer usuarioId;

	public Seguimiento() {
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Usuario getUsuario() {
		return usuario;
	}

	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}

	public String getOrdenCompra() {
		return ordenCompra;
	}

	public void setOrdenCompra(String ordenCompra) {
		this.ordenCompra = ordenCompra;
	}

	public Date getFecha() {
		return fecha;
	}

	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}

	public Boolean getSiguiendo() {
		return siguiendo;
	}

	public void setSiguiendo(Boolean siguiendo) {
		this.siguiendo = siguiendo;
	}

	public Integer getUsuarioId() {
		return usuarioId;
	}

	public void setUsuarioId(Integer usuarioId) {
		this.usuarioId = usuarioId;
	}

	@Override
	public String toString() {
		return "Seguimiento [id=" + id + ", usuario=" + usuario
				+ ", ordenCompra=" + ordenCompra + ", fecha=" + fecha
				+ ", siguiendo=" + siguiendo + "]";
	}
}
