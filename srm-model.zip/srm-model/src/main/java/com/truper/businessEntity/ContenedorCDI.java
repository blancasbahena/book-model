package com.truper.businessEntity;

import com.truper.infra.businessEntities.BaseBusinessEntity;

public class ContenedorCDI extends BaseBusinessEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public static int TIPO_FULL_20 = 1;
	public static int TIPO_FULL_40 = 2;
	public static int TIPO_FULL_40_HQ = 3;
	public static int TIPO_LCL = 4;
	
	private int clave;
	private double pesoMinimo;
	private double pesoNominal;
	private double pesoMaximo;
	private double volumenMinimo;
	private double volumenNominal;
	private double volumenMaximo;
	private double volumenMinimoXPeso;
	private double pesoMinimoXVolumen;
	
	private String nombre;
	
	public ContenedorCDI(int clave, String nombre, double pesoMinimo, double pesoMaximo, double volMinimo, double volMaximo){
		this.clave = clave;
		this.nombre = nombre;
		this.pesoMinimo = pesoMinimo;
		this.pesoMaximo = pesoMaximo;
		this.volumenMinimo = volMinimo;
		this.volumenMaximo = volMaximo;								
	}
	
	public ContenedorCDI(int clave, String nombre, double pesoMinimo, double pesoNominal, double pesoMaximo, double volMinimo, double volNominal, double volMaximo, 
			double volMinimoXPeso, double pesoMinimoXVol){
		this.clave = clave;
		this.nombre = nombre;
		this.pesoMinimo = pesoMinimo;
		this.pesoNominal = pesoNominal;
		this.pesoMaximo = pesoMaximo;
		this.volumenMinimo = volMinimo;
		this.volumenNominal = volNominal;
		this.volumenMaximo = volMaximo;
		this.volumenMinimoXPeso = volMinimoXPeso;
		this.pesoMinimoXVolumen = pesoMinimoXVol;
	} 
	
	public int getClave() {
		return clave;
	}

	public void setClave(int clave) {
		this.clave = clave;
	}

	public double getPesoMinimo() {
		return pesoMinimo;
	}

	public void setPesoMinimo(double pesoMinimo) {
		this.pesoMinimo = pesoMinimo;
	}

	public double getPesoMaximo() {
		return pesoMaximo;
	}

	public void setPesoMaximo(double pesoMaximo) {
		this.pesoMaximo = pesoMaximo;
	}

	public double getVolumenMinimo() {
		return volumenMinimo;
	}

	public void setVolumenMinimo(double volumenMinimo) {
		this.volumenMinimo = volumenMinimo;
	}

	public double getVolumenMaximo() {
		return volumenMaximo;
	}

	public void setVolumenMaximo(double volumenMaximo) {
		this.volumenMaximo = volumenMaximo;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	/**
	 * @return the volumenMinimoXPeso
	 */
	public double getVolumenMinimoXPeso() {
		return volumenMinimoXPeso;
	}

	/**
	 * @param volumenMinimoXPeso the volumenMinimoXPeso to set
	 */
	public void setVolumenMinimoXPeso(double volumenMinimoXPeso) {
		this.volumenMinimoXPeso = volumenMinimoXPeso;
	}

	/**
	 * @return the pesoMinimoXVolumen
	 */
	public double getPesoMinimoXVolumen() {
		return pesoMinimoXVolumen;
	}

	/**
	 * @param pesoMinimoXVolumen the pesoMinimoXVolumen to set
	 */
	public void setPesoMinimoXVolumen(double pesoMinimoXVolumen) {
		this.pesoMinimoXVolumen = pesoMinimoXVolumen;
	}

	public double getPesoNominal() {
		return pesoNominal;
	}

	public void setPesoNominal(double pesoNominal) {
		this.pesoNominal = pesoNominal;
	}

	public double getVolumenNominal() {
		return volumenNominal;
	}

	public void setVolumenNominal(double volumenNominal) {
		this.volumenNominal = volumenNominal;
	}
	
	
}
