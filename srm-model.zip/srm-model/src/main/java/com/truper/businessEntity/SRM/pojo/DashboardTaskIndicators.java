package com.truper.businessEntity.SRM.pojo;

import com.truper.infra.businessEntities.BaseBusinessEntity;

public class DashboardTaskIndicators extends BaseBusinessEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6809875260493664431L;

	// se == EKPO Partidas
	// sc == CALC calculos
	// sp == PO orden

	// se.ACTIVOS_FIJOS,
	private String activosFijos;
	// se.semaforo_quemada
	private String semaforoQuemada;
	// se.SEMAFORO_CANTIDAD,
	private String semaforoCantidad;
	// sc.XID, dias de inventario
	private String semaforoID;
	// sc.XIDA, dias de inventario al arribo
	private String semaforoIDA;
	// sc.XPA pico al arribo
	private String semaforoPA;
	// sp.SEMAFORO_TERMINO_PAGO,
	private String semaforoTerminoPago;
	// sp.SEMAFORO_MONEDA,
	private String semaforoMoneda;
	// sp.SEMAFORO_FABRICA,
	private String semaforoFabrica;
	// se.SEMAFORO_PRECIO_NETO
	private String semaforoPrecioNeto;

	private String diasInventarioArribo;

	public String getActivosFijos() {
		return activosFijos;
	}

	public void setActivosFijos(String activosFijos) {
		this.activosFijos = activosFijos;
	}

	public String getSemaforoQuemada() {
		return semaforoQuemada;
	}

	public void setSemaforoQuemada(String semaforoQuemada) {
		this.semaforoQuemada = semaforoQuemada;
	}

	public String getSemaforoCantidad() {
		return semaforoCantidad;
	}

	public void setSemaforoCantidad(String semaforoCantidad) {
		this.semaforoCantidad = semaforoCantidad;
	}

	public String getSemaforoID() {
		return semaforoID;
	}

	public void setSemaforoID(String semaforoID) {
		this.semaforoID = semaforoID;
	}

	public String getSemaforoIDA() {
		return semaforoIDA;
	}

	public void setSemaforoIDA(String semaforoIDA) {
		this.semaforoIDA = semaforoIDA;
	}

	public String getSemaforoPA() {
		return semaforoPA;
	}

	public void setSemaforoPA(String semaforoPA) {
		this.semaforoPA = semaforoPA;
	}

	public String getSemaforoTerminoPago() {
		return semaforoTerminoPago;
	}

	public void setSemaforoTerminoPago(String semaforoTerminoPago) {
		this.semaforoTerminoPago = semaforoTerminoPago;
	}

	public String getSemaforoMoneda() {
		return semaforoMoneda;
	}

	public void setSemaforoMoneda(String semaforoMoneda) {
		this.semaforoMoneda = semaforoMoneda;
	}

	public String getSemaforoFabrica() {
		return semaforoFabrica;
	}

	public void setSemaforoFabrica(String semaforoFabrica) {
		this.semaforoFabrica = semaforoFabrica;
	}

	public String getSemaforoPrecioNeto() {
		return semaforoPrecioNeto;
	}

	public void setSemaforoPrecioNeto(String semaforoPrecioNeto) {
		this.semaforoPrecioNeto = semaforoPrecioNeto;
	}

	public String getDiasInventarioArribo() {
		return diasInventarioArribo;
	}

	public void setDiasInventarioArribo(String diasInventarioArribo) {
		this.diasInventarioArribo = diasInventarioArribo;
	}

}
