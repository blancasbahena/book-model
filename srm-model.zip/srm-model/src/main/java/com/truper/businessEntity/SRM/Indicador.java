package com.truper.businessEntity.SRM;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.truper.infra.businessEntities.BaseBusinessEntity;

/**
 * @author Pablo Cruz Santos
 * @version 1.0
 * @date 23/03/2016
 */
@Entity
@Table(name = "srm_INDICADORES")
public class Indicador extends BaseBusinessEntity {

	private static final long serialVersionUID = 3922111219390042948L;

	@Id
	@Column(name = "ID", updatable = false, unique = true, insertable = false)
	private Integer id;

	@Column(name = "ID_BPM_MANAGER")
	private Long idBPMManager;

	@Column(name = "ID_PO_CONGELADA")
	private Integer idPOCongelada;

	@Column(name = "FECHA")
	private Date fecha;

	public Indicador() {
		super();
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Long getIdBPMManager() {
		return idBPMManager;
	}

	public void setIdBPMManager(Long idBPMManager) {
		this.idBPMManager = idBPMManager;
	}

	public Integer getIdPOCongelada() {
		return idPOCongelada;
	}

	public void setIdPOCongelada(Integer idPOCongelada) {
		this.idPOCongelada = idPOCongelada;
	}

	public Date getFecha() {
		return fecha;
	}

	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}
}
