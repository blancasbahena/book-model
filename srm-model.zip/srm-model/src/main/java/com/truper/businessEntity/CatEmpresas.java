package com.truper.businessEntity;

import java.io.Serializable;

import lombok.Data;

@Data
public class CatEmpresas implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private int idEmpresa;
	private String rfc;
	private String razonSocial;
	private String sociedad;
	private int idErp;
	private String direccionFiscal;
	private boolean aplicaNotaCredito;

}
