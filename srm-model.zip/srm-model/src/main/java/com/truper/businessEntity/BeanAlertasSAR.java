package com.truper.businessEntity;

import com.truper.infra.businessEntities.BaseBusinessEntity;

public class BeanAlertasSAR extends BaseBusinessEntity{
	/**
	 * 
	 */
	private static final long serialVersionUID = -6550042245066046620L;
	private String descripcion;
	private String template;
	private String mailFrom;
	private String mailTo;
	private String mailCC;
	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	/**
	 * @return the template
	 */
	public String getTemplate() {
		return template;
	}
	/**
	 * @param template the template to set
	 */
	public void setTemplate(String template) {
		this.template = template;
	}
	/**
	 * @return the mailFrom
	 */
	public String getMailFrom() {
		return mailFrom;
	}
	/**
	 * @param mailFrom the mailFrom to set
	 */
	public void setMailFrom(String mailFrom) {
		this.mailFrom = mailFrom;
	}
	/**
	 * @return the mailTo
	 */
	public String getMailTo() {
		return mailTo;
	}
	/**
	 * @param mailTo the mailTo to set
	 */
	public void setMailTo(String mailTo) {
		this.mailTo = mailTo;
	}
	/**
	 * @return the mailCC
	 */
	public String getMailCC() {
		return mailCC;
	}
	/**
	 * @param mailCC the mailCC to set
	 */
	public void setMailCC(String mailCC) {
		this.mailCC = mailCC;
	}
	
	
}
