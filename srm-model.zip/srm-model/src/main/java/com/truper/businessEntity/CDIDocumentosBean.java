package com.truper.businessEntity;

import com.truper.infra.businessEntities.BaseBusinessEntity;

public class CDIDocumentosBean extends BaseBusinessEntity {
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -7796112627626601037L;
	private Integer 	sar;
	private String  	numero;
	private Integer 	fecha;
	private Boolean 	esGenerado;
	private String  	pos;
	private String  	tipo;
	private Double 		packagesAmpara;
	private Boolean  	embarcaMadera;
	private String  	observaciones;
	private String  	representanteLegal;
	private Double 		version;
	private String 		ruta;
	private String 		nombreArch;
	private Integer		tipoMoneda;
	private String		nombreUsuario;
	private Integer		fechaCreacion;
	private Boolean		aprobadoSDI;
	private Integer		fechaUpdate;
	private String 		usuarioUpdate;
	private Integer		prioridad;
	private String		comentarioRechazo;
	private String		usuarioRechazo;
	private Integer		fechaRechazo;
	private Double		fechaRechazoLong;
//	private Integer		prioridad;
	
	
	public Integer getFechaCreacion() {
		return fechaCreacion;
	}
	public void setFechaCreacion(Integer fechaCreacion) {
		this.fechaCreacion = fechaCreacion;
	}
	public Integer getSar() {
		return sar;
	}
	public void setSar(Integer sar) {
		this.sar = sar;
	}
	public String getNumero() {
		return numero;
	}
	public void setNumero(String numero) {
		this.numero = numero;
	}
	public Integer getFecha() {
		return fecha;
	}
	public void setFecha(Integer fecha) {
		this.fecha = fecha;
	}
	public Boolean getEsGenerado() {
		return esGenerado;
	}
	public void setEsGenerado(Boolean esGenerado) {
		this.esGenerado = esGenerado;
	}
	public String getPos() {
		return pos;
	}
	public void setPos(String pos) {
		this.pos = pos;
	}
	public String getTipo() {
		return tipo;
	}
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	public Double getPackagesAmpara() {
		return packagesAmpara;
	}
	public void setPackagesAmpara(Double packagesAmpara) {
		this.packagesAmpara = packagesAmpara;
	}
	public Boolean getEmbarcaMadera() {
		return embarcaMadera;
	}
	public void setEmbarcaMadera(Boolean embarcaMadera) {
		this.embarcaMadera = embarcaMadera;
	}
	public String getObservaciones() {
		return observaciones;
	}
	public void setObservaciones(String observaciones) {
		this.observaciones = observaciones;
	}
	public String getRepresentanteLegal() {
		return representanteLegal;
	}
	public void setRepresentanteLegal(String representanteLegal) {
		this.representanteLegal = representanteLegal;
	}
	public Double getVersion() {
		return version;
	}
	public void setVersion(Double version) {
		this.version = version;
	}
	public String getRuta() {
		return ruta;
	}
	public void setRuta(String ruta) {
		this.ruta = ruta;
	}
	public String getNombreArch() {
		return nombreArch;
	}
	public void setNombreArch(String nombreArch) {
		this.nombreArch = nombreArch;
	}
	public Integer getTipoMoneda() {
		return tipoMoneda;
	}
	public void setTipoMoneda(Integer tipoMoneda) {
		this.tipoMoneda = tipoMoneda;
	}
	public String getNombreUsuario() {
		return nombreUsuario;
	}
	public void setNombreUsuario(String nombreUsuario) {
		this.nombreUsuario = nombreUsuario;
	}			
	public Boolean esAprobadoSDI() {
		return aprobadoSDI;
	}
	public void setAprobadoSDI(Boolean aprobadoSDI) {
		this.aprobadoSDI = aprobadoSDI;
	}		
	public Integer getFechaUpdate() {
		return fechaUpdate;
	}
	public void setFechaUpdate(Integer fechaUpdate) {
		this.fechaUpdate = fechaUpdate;
	}
	public String getUsuarioUpdate() {
		return usuarioUpdate;
	}
	public void setUsuarioUpdate(String usuarioUpdate) {
		this.usuarioUpdate = usuarioUpdate;
	}
	public Integer getPrioridad() {
		return prioridad;
	}
	public void setPrioridad(Integer prioridad) {
		this.prioridad = prioridad;
	}
	public String getComentarioRechazo() {
		return comentarioRechazo;
	}
	public void setComentarioRechazo(String comentarioRechazo) {
		this.comentarioRechazo = comentarioRechazo;
	}
	public String getUsuarioRechazo() {
		return usuarioRechazo;
	}
	public void setUsuarioRechazo(String usuarioRechazo) {
		this.usuarioRechazo = usuarioRechazo;
	}
	public Integer getFechaRechazo() {
		return fechaRechazo;
	}
	public void setFechaRechazo(Integer fechaRechazo) {
		this.fechaRechazo = fechaRechazo;
	}
	public Double getFechaRechazoLong() {
		return fechaRechazoLong;
	}
	public void setFechaRechazoLong(Double fechaRechazoLong) {
		this.fechaRechazoLong = fechaRechazoLong;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public Boolean getAprobadoSDI() {
		return aprobadoSDI;
	}	
	
}
