package com.truper.businessEntity;

import java.util.Date;

import com.truper.infra.businessEntities.BaseBusinessEntity;

public class BeanSDPAcciones  extends BaseBusinessEntity implements Cloneable {
	
	private int folio;
	private Date fechaAccion;
	private String accion;
	
	
	public int getFolio() {
		return folio;
	}
	public void setFolio(int folio) {
		this.folio = folio;
	}
	public Date getFechaAccion() {
		return fechaAccion;
	}
	public void setFechaAccion(Date fechaAccion) {
		this.fechaAccion = fechaAccion;
	}
	public String getAccion() {
		return accion;
	}
	public void setAccion(String accion) {
		this.accion = accion;
	}
	
	
	
	
}
