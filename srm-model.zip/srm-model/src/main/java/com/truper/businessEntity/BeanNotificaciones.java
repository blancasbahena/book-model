package com.truper.businessEntity;

import com.truper.infra.businessEntities.BaseBusinessEntity;

public class BeanNotificaciones extends BaseBusinessEntity implements Cloneable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 6905307065664605392L;
	private String   numeroOrden;
	private Integer  posicion;
	private Integer  fecha;
	private Integer  cantidad;
	private String   documentos;
	private String   contenedor;
	private Integer  tipoRetraso;
	private boolean  estado;
	private Integer  diaSeguimiento;
	private Integer  diaDeCaptura;
	private Boolean  esCI;
	private Integer  numOrdenSecundaria;
	private String   tipoConf;
	private String   sar;
	private Integer  eta;
	private String   adelantoAtraso;
	private Integer  proformaSAP;
	
	private boolean  	error = true;
	private String  	mensaje;
	
	public BeanNotificaciones clone(){
		BeanNotificaciones bean = new BeanNotificaciones();
		bean.numeroOrden		= this.numeroOrden;
		bean.posicion 			= this.posicion;		
		bean.fecha				= this.fecha;
		bean.cantidad			= this.cantidad;
		bean.documentos			= this.documentos;
		bean.contenedor			= this.contenedor;
		bean.tipoRetraso		= this.tipoRetraso;
		bean.estado				= this.estado;
		bean.diaSeguimiento		= this.diaSeguimiento;
		bean.diaDeCaptura		= this.diaDeCaptura;
		bean.esCI				= this.esCI;
		bean.numOrdenSecundaria	= this.numOrdenSecundaria;
		bean.tipoConf			= this.tipoConf;
		bean.sar				= this.sar;
		bean.eta				= this.eta;
		bean.adelantoAtraso		= this.adelantoAtraso;
		bean.proformaSAP		= this.proformaSAP;
		bean.error				= this.error;
		bean.mensaje			= this.mensaje;
		 
		return bean;
	}
	
	
	public String getNumeroOrden() {
		return numeroOrden;
	}
	public void setNumeroOrden(String numeroOrden) {
		this.numeroOrden = numeroOrden;
	}
	public Integer getPosicion() {
		return posicion;
	}
	public void setPosicion(Integer posicion) {
		this.posicion = posicion;
	}
	public Integer getFecha() {
		return fecha;
	}
	public void setFecha(Integer fecha) {
		this.fecha = fecha;
	}
	public String getDocumentos() {
		return documentos;
	}
	public void setDocumentos(String documentos) {
		this.documentos = documentos;
	}
	public String getContenedor() {
		return contenedor;
	}
	public void setContenedor(String contenedor) {
		this.contenedor = contenedor;
	}
	public Integer getTipoRetraso() {
		return tipoRetraso;
	}
	public void setTipoRetraso(Integer tipoRetraso) {
		this.tipoRetraso = tipoRetraso;
	}
	public boolean isEstado() {
		return estado;
	}
	public void setEstado(boolean estado) {
		this.estado = estado;
	}
	public Integer getDiaSeguimiento() {
		return diaSeguimiento;
	}
	public void setDiaSeguimiento(Integer diaSeguimiento) {
		this.diaSeguimiento = diaSeguimiento;
	}
	public Integer getDiaDeCaptura() {
		return diaDeCaptura;
	}
	public void setDiaDeCaptura(Integer diaDeCaptura) {
		this.diaDeCaptura = diaDeCaptura;
	}
	public Boolean getEsCI() {
		return esCI;
	}
	public void setEsCI(Boolean esCI) {
		this.esCI = esCI;
	}
	public Integer getNumOrdenSecundaria() {
		return numOrdenSecundaria;
	}
	public void setNumOrdenSecundaria(Integer numOrdenSecundaria) {
		this.numOrdenSecundaria = numOrdenSecundaria;
	}
	public String getTipoConf() {
		return tipoConf;
	}
	public void setTipoConf(String tipoConf) {
		this.tipoConf = tipoConf;
	}
	public String getSar() {
		return sar;
	}
	public void setSar(String sar) {
		this.sar = sar;
	}
	public Integer getEta() {
		return eta;
	}
	public void setEta(Integer eta) {
		this.eta = eta;
	}
	public String getAdelantoAtraso() {
		return adelantoAtraso;
	}
	public void setAdelantoAtraso(String adelantoAtraso) {
		this.adelantoAtraso = adelantoAtraso;
	}
	public Integer getCantidad() {
		return cantidad;
	}
	public void setCantidad(Integer cantidad) {
		this.cantidad = cantidad;
	}
	public boolean isError() {
		return error;
	}
	public void setError(boolean error) {
		this.error = error;
	}
	public String getMensaje() {
		return mensaje;
	}
	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}
	public Integer getProformaSAP() {
		return proformaSAP;
	}
	public void setProformaSAP(Integer proformaSAP) {
		this.proformaSAP = proformaSAP;
	}
	
	
}

