package com.truper.businessEntity;

import java.math.BigDecimal;

import com.truper.infra.businessEntities.BaseBusinessEntity;

public class BeanTiposDeCambio extends BaseBusinessEntity{
	/**
	 * 
	 */
	private static final long serialVersionUID = -4954634375181777011L;
	private String quotationType;
	private String originCurrency;
	private String destinationCurrency;
	private Integer startDate;
	private BigDecimal exchangeRate;
	private Integer originCurrencyFactor;
	private Integer destinationCurrencyFactor;
	
	public String getQuotationType() {
		return quotationType;
	}
	public void setQuotationType(String quotationType) {
		this.quotationType = quotationType;
	}
	public String getOriginCurrency() {
		return originCurrency;
	}
	public void setOriginCurrency(String originCurrency) {
		this.originCurrency = originCurrency;
	}
	public String getDestinationCurrency() {
		return destinationCurrency;
	}
	public void setDestinationCurrency(String destinationCurrency) {
		this.destinationCurrency = destinationCurrency;
	}
	public Integer getStartDate() {
		return startDate;
	}
	public void setStartDate(Integer startDate) {
		this.startDate = startDate;
	}
	public BigDecimal getExchangeRate() {
		return exchangeRate;
	}
	public void setExchangeRate(BigDecimal exchangeRate) {
		this.exchangeRate = exchangeRate;
	}
	public Integer getOriginCurrencyFactor() {
		return originCurrencyFactor;
	}
	public void setOriginCurrencyFactor(Integer originCurrencyFactor) {
		this.originCurrencyFactor = originCurrencyFactor;
	}
	public Integer getDestinationCurrencyFactor() {
		return destinationCurrencyFactor;
	}
	public void setDestinationCurrencyFactor(Integer destinationCurrencyFactor) {
		this.destinationCurrencyFactor = destinationCurrencyFactor;
	}
	
}
