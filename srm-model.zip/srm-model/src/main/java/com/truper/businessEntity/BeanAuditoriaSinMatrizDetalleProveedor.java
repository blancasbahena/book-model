package com.truper.businessEntity;

public class BeanAuditoriaSinMatrizDetalleProveedor extends BeanAuditoriaSinMatrizDetalle {

	private String proveedor;

	public String getProveedor() {
		return proveedor;
	}

	public void setProveedor(String proveedor) {
		this.proveedor = proveedor;
	}
}