package com.truper.businessEntity;

import java.io.Serializable;

import lombok.Data;

@Data
public class Concepto implements Serializable{

	private static final long serialVersionUID = 6351296407896380672L;
	private int id;
	private String concepto;
	private boolean aplicaPo;
	
}
