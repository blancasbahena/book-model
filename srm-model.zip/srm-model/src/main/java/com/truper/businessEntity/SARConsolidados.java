package com.truper.businessEntity;


import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;

import com.truper.infra.businessEntities.BaseBusinessEntity;

public class SARConsolidados extends BaseBusinessEntity {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 9086570263606807827L;
	public static final int PRIORIDAD_AEREO = 4; 
	public static final int PRIORIDAD_TREN = 3; 
	public static final int PRIORIDAD_CAMION = 2;
	public static final int PRIORIDAD_TREN_EXPRESS = 1;
	
	public static final String TYPE_Z = "Z";
	public static final String TYPE_P = "P";
	
	private Integer folio;
	private String puertoSalida;
	private Integer naviera;
	private Integer fechaEmbarque;
	private Integer status;
	private Integer tipoContenedor;
	private Integer prioridad;
	private String barcoSugerido;
	private String viaje;
	private String puertoDescarga;
	private String contenedor;
	private String booking;
	private Integer eta;
	private Integer etdReal;
	private String prioridadConsolidado;
	private HashMap<String, String>  mapaProveedores;
	private Integer transporte;
	private String comentarioConsol;
	private String comentarioTruperBooking;
	private Integer		paisDestino;
	private String 	tipoProducto;
	private Integer tipoRetraso;
	private String 	retrasoProveedor;
	private boolean sarImportado;
	
	
	/** Variables que no estan en la tabla **/
	private double 		peso;
	private double 		volumen;
	private String POsEnConsolidado;
	private BigDecimal 	backorderPronosticadoTot;
	private BigDecimal 	valorContenedor;
	private String warning;///aqui voy a poner en html la imagen y la funcion a la que va a llamar
	private boolean aviso;
	private ArrayList<String>	listaPos;
	private ArrayList<SAR> detalle;
	private Integer fechaEmbarqueIni;
	private Integer fechaEmbarqueFin;
	private Boolean esDesbloqueado;
	private Long fecIniEmbarque;
	private Integer tinyFecIniEmbarque;
	private Integer filtroBooking;
	private Integer revision;
	private Boolean etdRealWarning;
	private String usrEtdRealWarning;
	private String	intervalosFechaCreacion;
	private boolean bitacoraIDA;
	private boolean bitacoraIDACerrada;
	private boolean almacen45;
	
	public SARConsolidados(){}
	
	/***Setters y Getters **/
	public Integer getFolio() {
		return folio;
	}
	public void setFolio(Integer folio) {
		this.folio = folio;
	}
	
	public String getPuertoSalida() {
		return puertoSalida;
	}

	public void setPuertoSalida(String puertoSalida) {
		this.puertoSalida = puertoSalida;
	}

	public Integer getNaviera() {
		return naviera;
	}
	public void setNaviera(Integer naviera) {
		this.naviera = naviera;
	}
	public Integer getFechaEmbarque() {
		return fechaEmbarque;
	}
	public void setFechaEmbarque(Integer fechaEmbarque) {
		this.fechaEmbarque = fechaEmbarque;
	}
	public Integer getStatus() {
		return status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
	public Integer getTipoContenedor() {
		return tipoContenedor;
	}
	public void setTipoContenedor(Integer tipoContenedor) {
		this.tipoContenedor = tipoContenedor;
	}
	public Integer getPrioridad() {
		return prioridad;
	}
	public void setPrioridad(Integer prioridad) {
		this.prioridad = prioridad;
	}
	public String getBarcoSugerido() {
		return barcoSugerido;
	}
	public void setBarcoSugerido(String barcoSugerido) {
		this.barcoSugerido = barcoSugerido;
	}
	public String getViaje() {
		return viaje;
	}
	public void setViaje(String viaje) {
		this.viaje = viaje;
	}
	public String getPuertoDescarga() {
		return puertoDescarga;
	}
	public void setPuertoDescarga(String puertoDescarga) {
		this.puertoDescarga = puertoDescarga;
	}
	public String getContenedor() {
		return contenedor;
	}
	public void setContenedor(String contenedor) {
		this.contenedor = contenedor;
	}
	public String getBooking() {
		return booking;
	}
	public void setBooking(String booking) {
		this.booking = booking;
	}
	public String getPrioridadConsolidado() {
		return prioridadConsolidado;
	}
	public void setPrioridadConsolidado(String prioridadConsolidado) {
		this.prioridadConsolidado = prioridadConsolidado;
	}
	public double getPeso() {
		return peso;
	}
	public void setPeso(double peso) {
		this.peso = peso;
	}
	public double getVolumen() {
		return volumen;
	}
	public void setVolumen(double volumen) {
		this.volumen = volumen;
	}
	public HashMap<String, String> getMapaProveedores() {
		return mapaProveedores;
	}
	public void setMapaProveedores(HashMap<String, String> mapaProveedores) {
		this.mapaProveedores = mapaProveedores;
	}
	public String getPOsEnConsolidado() {
		return POsEnConsolidado;
	}
	public void setPOsEnConsolidado(String pOsEnConsolidado) {
		POsEnConsolidado = pOsEnConsolidado;
	}
	public BigDecimal getBackorderPronosticadoTot() {
		return backorderPronosticadoTot;
	}
	public void setBackorderPronosticadoTot(BigDecimal backorderPronosticadoTot) {
		this.backorderPronosticadoTot = backorderPronosticadoTot;
	}
	public Integer getEtdReal() {
		return etdReal;
	}
	public void setEtdReal(Integer etdReal) {
		this.etdReal = etdReal;
	}
	public Integer getTransporte() {
		return transporte;
	}
	public void setTransporte(Integer transporte) {
		this.transporte = transporte;
	}
	public String getComentarioConsol() {
		return comentarioConsol;
	}
	public void setComentarioConsol(String comentarioConsol) {
		this.comentarioConsol = comentarioConsol;
	}
	public BigDecimal getValorContenedor() {
		return valorContenedor;
	}
	public void setValorContenedor(BigDecimal valorContenedor) {
		this.valorContenedor = valorContenedor;
	}
	public ArrayList<String> getListaPos() {
		return listaPos;
	}
	public void setListaPos(ArrayList<String> listaPos) {
		this.listaPos = listaPos;
	}
	public String getComentarioTruperBooking() {
		return comentarioTruperBooking;
	}
	public void setComentarioTruperBooking(String comentarioTruperBooking) {
		this.comentarioTruperBooking = comentarioTruperBooking;
	}
	public String getWarning() {
		return warning;
	}
	public void setWarning(String warning) {
		this.warning = warning;
	}
	public boolean isAviso() {
		return aviso;
	}
	public void setAviso(boolean aviso) {
		this.aviso = aviso;
	}
	public ArrayList<SAR> getDetalle() {
		return detalle;
	}
	public void setDetalle(ArrayList<SAR> detalle) {
		this.detalle = detalle;
	}
	public Integer getFechaEmbarqueIni() {
		return fechaEmbarqueIni;
	}
	public void setFechaEmbarqueIni(Integer fechaEmbarqueIni) {
		this.fechaEmbarqueIni = fechaEmbarqueIni;
	}
	public Integer getFechaEmbarqueFin() {
		return fechaEmbarqueFin;
	}
	public void setFechaEmbarqueFin(Integer fechaEmbarqueFin) {
		this.fechaEmbarqueFin = fechaEmbarqueFin;
	}
	public Integer getEta() {
		return eta;
	}
	public void setEta(Integer eta) {
		this.eta = eta;
	}
	public Integer getPaisDestino() {
		return paisDestino;
	}
	public void setPaisDestino(Integer paisDestino) {
		this.paisDestino = paisDestino;
	}
	public String getTipoProducto() {
		return tipoProducto;
	}
	public void setTipoProducto(String tipoProducto) {
		this.tipoProducto = tipoProducto;
	}
	public Integer getTipoRetraso() {
		return tipoRetraso;
	}
	public void setTipoRetraso(Integer tipoRetraso) {
		this.tipoRetraso = tipoRetraso;
	}
	public String getRetrasoProveedor() {
		return retrasoProveedor;
	}
	public void setRetrasoProveedor(String retrasoProveedor) {
		this.retrasoProveedor = retrasoProveedor;
	}

	public boolean isSarImportado() {
		return sarImportado;
	}

	public void setSarImportado(boolean sarImportado) {
		this.sarImportado = sarImportado;
	}

	public Boolean getEsDesbloqueado() {
		return esDesbloqueado;
	}

	public void setEsDesbloqueado(Boolean esDesbloqueado) {
		this.esDesbloqueado = esDesbloqueado;
	}

	/**
	 * @return the fecIniEmbarque
	 */
	public Long getFecIniEmbarque() {
		return fecIniEmbarque;
	}

	/**
	 * @param fecIniEmbarque the fecIniEmbarque to set
	 */
	public void setFecIniEmbarque(Long fecIniEmbarque) {
		this.fecIniEmbarque = fecIniEmbarque;
	}

	/**
	 * @return the tinyFecIniEmbarque
	 */
	public Integer getTinyFecIniEmbarque() {
		return tinyFecIniEmbarque;
	}

	/**
	 * @param tinyFecIniEmbarque the tinyFecIniEmbarque to set
	 */
	public void setTinyFecIniEmbarque(Integer tinyFecIniEmbarque) {
		this.tinyFecIniEmbarque = tinyFecIniEmbarque;
	}

	/**
	 * @return the filtroBooking
	 */
	public Integer getFiltroBooking() {
		return filtroBooking;
	}

	/**
	 * @param filtroBooking the filtroBooking to set
	 */
	public void setFiltroBooking(Integer filtroBooking) {
		this.filtroBooking = filtroBooking;
	}

	public Integer getRevision() {
		return revision;
	}

	public void setRevision(Integer revision) {
		this.revision = revision;
	}

	public Boolean getEtdRealWarning() {
		return etdRealWarning;
	}

	public void setEtdRealWarning(Boolean etdRealWarning) {
		this.etdRealWarning = etdRealWarning;
	}

	public String getUsrEtdRealWarning() {
		return usrEtdRealWarning;
	}

	public void setUsrEtdRealWarning(String usrEtdRealWarning) {
		this.usrEtdRealWarning = usrEtdRealWarning;
	}

	public String getIntervalosFechaCreacion() {
		return intervalosFechaCreacion;
	}

	public void setIntervalosFechaCreacion(String intervalosFechaCreacion) {
		this.intervalosFechaCreacion = intervalosFechaCreacion;
	}

	public boolean isBitacoraIDA() {
		return bitacoraIDA;
	}

	public void setBitacoraIDA(boolean bitacoraIDA) {
		this.bitacoraIDA = bitacoraIDA;
	}

	public boolean isBitacoraIDACerrada() {
		return bitacoraIDACerrada;
	}

	public void setBitacoraIDACerrada(boolean bitacoraIDACerrada) {
		this.bitacoraIDACerrada = bitacoraIDACerrada;
	}

	public boolean isAlmacen45() {
		return almacen45;
	}

	public void setAlmacen45(boolean almacen45) {
		this.almacen45 = almacen45;
	}
	
}
