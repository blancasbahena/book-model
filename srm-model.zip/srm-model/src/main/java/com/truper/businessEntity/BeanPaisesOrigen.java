package com.truper.businessEntity;

import java.util.HashMap;

import com.truper.infra.businessEntities.BaseBusinessEntity;

public class BeanPaisesOrigen extends BaseBusinessEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4739459401007290654L;
	public static HashMap<Integer, String> mapaPaisesOrigen;
	
	public BeanPaisesOrigen(){}
	
	static {
		HashMap<Integer, String> temp = new HashMap<Integer, String>();
		
		temp.put(1, "Alemania");
		temp.put(2, "Argentina");
		temp.put(3, "Bolivia");
		temp.put(4, "Brasil");
		temp.put(5, "Canada");
		temp.put(6, "China");
		temp.put(7, "Colombia");
		temp.put(8, "España");
		temp.put(9, "Estados Unidos");
		temp.put(10, "India");
		temp.put(11, "Inglaterra");
		temp.put(12, "Italia");
		temp.put(13, "Japon");
		temp.put(14, "Korea");
		temp.put(15, "Malasia");
		temp.put(16, "Taiwan");						

		mapaPaisesOrigen = temp;
	}
}
