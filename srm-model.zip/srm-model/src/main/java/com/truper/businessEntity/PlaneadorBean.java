package com.truper.businessEntity;

import com.truper.infra.businessEntities.BaseBusinessEntity;


public class PlaneadorBean extends BaseBusinessEntity {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String idPlaneador;
	private String nombre;
	private String [] correos;
	private String gerente;
	private String correoGerente;
	private String identificadorPlaneador;
	private String identificadorGerente;
	
	public PlaneadorBean() {
	}
	
	/**
	 * @return the idPlaneador
	 */
	public String getIdPlaneador() {
		return idPlaneador;
	}

	/**
	 * @param idPlaneador the idPlaneador to set
	 */
	public void setIdPlaneador(String idPlaneador) {
		this.idPlaneador = idPlaneador;
	}

	/**
	 * @return the nombre
	 */
	public String getNombre() {
		return nombre;
	}
	/**
	 * @param nombre the nombre to set
	 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	/**
	 * @return the correos
	 */
	public String[] getCorreos() {
		return correos;
	}
	/**
	 * @param correos the correos to set
	 */
	public void setCorreos(String[] correos) {
		this.correos = correos;
	}

	public String getGerente() {
		return gerente;
	}

	public void setGerente(String gerente) {
		this.gerente = gerente;
	}

	public String getCorreoGerente() {
		return correoGerente;
	}

	public void setCorreoGerente(String correoGerente) {
		this.correoGerente = correoGerente;
	}

	/**
	 * @return the identificadorPlaneador
	 */
	public String getIdentificadorPlaneador() {
		return identificadorPlaneador;
	}

	/**
	 * @param identificadorPlaneador the identificadorPlaneador to set
	 */
	public void setIdentificadorPlaneador(String identificadorPlaneador) {
		this.identificadorPlaneador = identificadorPlaneador;
	}

	/**
	 * @return the identificadorGerente
	 */
	public String getIdentificadorGerente() {
		return identificadorGerente;
	}

	/**
	 * @param identificadorGerente the identificadorGerente to set
	 */
	public void setIdentificadorGerente(String identificadorGerente) {
		this.identificadorGerente = identificadorGerente;
	}
	
}
