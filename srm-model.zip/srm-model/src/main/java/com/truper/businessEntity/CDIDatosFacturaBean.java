package com.truper.businessEntity;

import java.math.BigDecimal;

import com.truper.infra.businessEntities.BaseBusinessEntity;

public class CDIDatosFacturaBean extends BaseBusinessEntity {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -3707155645422976277L;
	private Integer sar;
	private String  numero;
	private Boolean esGenerado;
	private String  code;
	private String  po;
	private String  item;
	private String  descripcion;
	private String  tipo;
	private Integer  cantidad;
	private String  unidadMedida;
	private Double  pu;
	private Double  monto;
	
	///datos especiales para packinglist
	private Integer cartones;
	private Integer cantidadXCarton;
	private BigDecimal pesoNetoPKL;
	private BigDecimal pesoBrutoPKL;
	private BigDecimal cubicajePKL;
	private Integer pallet;
	private Integer cartonXPallet;
	
	
	public BigDecimal getPesoNetoPKL() {
		return pesoNetoPKL;
	}
	public void setPesoNetoPKL(BigDecimal pesoNetoPKL) {
		this.pesoNetoPKL = pesoNetoPKL;
	}
	public BigDecimal getPesoBrutoPKL() {
		return pesoBrutoPKL;
	}
	public void setPesoBrutoPKL(BigDecimal pesoBrutoPKL) {
		this.pesoBrutoPKL = pesoBrutoPKL;
	}
	public BigDecimal getCubicajePKL() {
		return cubicajePKL;
	}
	public void setCubicajePKL(BigDecimal cubicajePKL) {
		this.cubicajePKL = cubicajePKL;
	}
	public String getPo() {
		return po;
	}
	public void setPo(String po) {
		this.po = po;
	}
	//private Double version;
	public Integer getSar() {
		return sar;
	}
	public void setSar(Integer sar) {
		this.sar = sar;
	}
	public String getNumero() {
		return numero;
	}
	public void setNumero(String numero) {
		this.numero = numero;
	}
	public Boolean getEsGenerado() {
		return esGenerado;
	}
	public void setEsGenerado(Boolean esGenerado) {
		this.esGenerado = esGenerado;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getItem() {
		return item;
	}
	public void setItem(String item) {
		this.item = item;
	}
	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	public String getTipo() {
		return tipo;
	}
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	public Integer getCantidad() {
		return cantidad;
	}
	public void setCantidad(Integer cantidad) {
		this.cantidad = cantidad;
	}
	public String getUnidadMedida() {
		return unidadMedida;
	}
	public void setUnidadMedida(String unidadMedida) {
		this.unidadMedida = unidadMedida;
	}
	public Double getMonto() {
		return monto;
	}
	public void setMonto(Double monto) {
		this.monto = monto;
	}
	public Double getPu() {
		return pu;
	}
	public void setPu(Double pu) {
		this.pu = pu;
	}
	public Integer getCartones() {
		return cartones;
	}
	public void setCartones(Integer cartones) {
		this.cartones = cartones;
	}
	public Integer getCantidadXCarton() {
		return cantidadXCarton;
	}
	public void setCantidadXCarton(Integer cantidadXCarton) {
		this.cantidadXCarton = cantidadXCarton;
	}
	public Integer getPallet() {
		return pallet;
	}
	public void setPallet(Integer pallet) {
		this.pallet = pallet;
	}
	public Integer getCartonXPallet() {
		return cartonXPallet;
	}
	public void setCartonXPallet(Integer cartonXPallet) {
		this.cartonXPallet = cartonXPallet;
	}
	
}
