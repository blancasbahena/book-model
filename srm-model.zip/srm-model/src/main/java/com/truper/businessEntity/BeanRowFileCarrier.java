package com.truper.businessEntity;

import java.util.ArrayList;

import com.truper.infra.businessEntities.BaseBusinessEntity;


public class BeanRowFileCarrier extends BaseBusinessEntity {
	
	
	private static final long serialVersionUID = 6234999152462573822L;
	
	
	private int renglon;
	private String booking;
	private String bl;
	private String contenedor;	
	private int etd;
	private int eta;	
	private String barco;
	private String viaje;
	private String pol;
	private String pod;	
	private Boolean esError;
	private boolean consolidado;
	private boolean tieneConflicto;
	private String mensaje;
	private ArrayList<Integer> sarRelacionados;
	private Integer sar;
	private Integer sarConsolidado;
	private boolean enviarSAP;
	private boolean cambio;
	private boolean resultadoSAP;
	private boolean cambioETDmayor;
	
	private String shippingLine;
	private String buqueSalida;
	private String shipper;
	private String consoFull;
	private String lugarFecha;
	private String instruccionBl;
	private String estatusDocumento;
	private String status;
	
	
	
	private String aTrafico;
	private String aAduanal;
	private String comment;
	
	private String folioConsolidado;
	private String concatenado;
	
	private ArrayList<BeanRowFileCarrier> listaConflictos;
	
	public int getRenglon() {
		return renglon;
	}
	public void setRenglon(int renglon) {
		this.renglon = renglon;
	}	
	public String getBooking() {
		return booking;
	}
	public void setBooking(String booking) {
		this.booking = booking;
	}
	public String getBl() {
		return bl;
	}
	public void setBl(String bl) {
		this.bl = bl;
	}
	public String getContenedor() {
		return contenedor;
	}
	public void setContenedor(String contenedor) {
		this.contenedor = contenedor;
	}
	public int getEtd() {
		return etd;
	}
	public void setEtd(int etd) {
		this.etd = etd;
	}
	public int getEta() {
		return eta;
	}
	public void setEta(int eta) {
		this.eta = eta;
	}
	public String getBarco() {
		return barco;
	}
	public void setBarco(String barco) {
		this.barco = barco;
	}
	public String getViaje() {
		return viaje;
	}
	public void setViaje(String viaje) {
		this.viaje = viaje;
	}
	public String getPol() {
		return pol;
	}
	public void setPol(String pol) {
		this.pol = pol;
	}
	public String getPod() {
		return pod;
	}
	public void setPod(String pod) {
		this.pod = pod;
	}	
	public String getMensaje() {
		return mensaje;
	}
	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public Boolean getEsError() {
		return esError;
	}
	public void setEsError(Boolean esError) {
		this.esError = esError;
	}
	public boolean isTieneConflicto() {
		return tieneConflicto;
	}
	public void setTieneConflicto(boolean tieneConflicto) {
		this.tieneConflicto = tieneConflicto;
	}
	public ArrayList<Integer> getSarRelacionados() {
		return sarRelacionados;
	}
	public void setSarRelacionados(ArrayList<Integer> sarRelacionados) {
		this.sarRelacionados = sarRelacionados;
	}
	public Integer getSar() {
		return sar;
	}
	public void setSar(Integer sar) {
		this.sar = sar;
	}
	public Integer getSarConsolidado() {
		return sarConsolidado;
	}
	public void setSarConsolidado(Integer sarConsolidado) {
		this.sarConsolidado = sarConsolidado;
	}
	public boolean isEnviarSAP() {
		return enviarSAP;
	}
	public void setEnviarSAP(boolean enviarSAP) {
		this.enviarSAP = enviarSAP;
	}
	public boolean isCambio() {
		return cambio;
	}
	public void setCambio(boolean cambio) {
		this.cambio = cambio;
	}
	public ArrayList<BeanRowFileCarrier> getListaConflictos() {
		return listaConflictos;
	}
	public void setListaConflictos(ArrayList<BeanRowFileCarrier> listaConflictos) {
		this.listaConflictos = listaConflictos;
	}
	public boolean isResultadoSAP() {
		return resultadoSAP;
	}
	public void setResultadoSAP(boolean resultadoSAP) {
		this.resultadoSAP = resultadoSAP;
	}
	public boolean isCambioETDmayor() {
		return cambioETDmayor;
	}
	public void setCambioETDmayor(boolean cambioETDmayor) {
		this.cambioETDmayor = cambioETDmayor;
	}
	
	public String getShippingLine() {
		return shippingLine;
	}
	public void setShippingLine(String shippingLine) {
		this.shippingLine = shippingLine;
	}
	public String getBuqueSalida() {
		return buqueSalida;
	}
	public void setBuqueSalida(String buqueSalida) {
		this.buqueSalida = buqueSalida;
	}
	public String getShipper() {
		return shipper;
	}
	public void setShipper(String shipper) {
		this.shipper = shipper;
	}
	public String getConsoFull() {
		return consoFull;
	}
	public void setConsoFull(String consoFull) {
		this.consoFull = consoFull;
	}
	public String getLugarFecha() {
		return lugarFecha;
	}
	public void setLugarFecha(String lugarFecha) {
		this.lugarFecha = lugarFecha;
	}
	public String getInstruccionBl() {
		return instruccionBl;
	}
	public void setInstruccionBl(String instruccionBl) {
		this.instruccionBl = instruccionBl;
	}
	public String getEstatusDocumento() {
		return estatusDocumento;
	}
	public void setEstatusDocumento(String estatusDocumento) {
		this.estatusDocumento = estatusDocumento;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}

	
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((barco == null) ? 0 : barco.hashCode());
		result = prime * result + ((bl == null) ? 0 : bl.hashCode());
		result = prime * result + ((booking == null) ? 0 : booking.hashCode());
		result = prime * result + ((contenedor == null) ? 0 : contenedor.hashCode());
		result = prime * result + eta;
		result = prime * result + etd;
		result = prime * result + ((pod == null) ? 0 : pod.hashCode());
		result = prime * result + ((pol == null) ? 0 : pol.hashCode());
		result = prime * result + ((viaje == null) ? 0 : viaje.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BeanRowFileCarrier other = (BeanRowFileCarrier) obj;
		if (barco == null) {
			if (other.barco != null)
				return false;
		} else if (!barco.equals(other.barco))
			return false;
		if (bl == null) {
			if (other.bl != null)
				return false;
		} else if (!bl.equals(other.bl))
			return false;
		if (booking == null) {
			if (other.booking != null)
				return false;
		} else if (!booking.equals(other.booking))
			return false;
		if (contenedor == null) {
			if (other.contenedor != null)
				return false;
		} else if (!contenedor.equals(other.contenedor))
			return false;
		if (eta != other.eta)
			return false;
		if (etd != other.etd)
			return false;
		if (pod == null) {
			if (other.pod != null)
				return false;
		} else if (!pod.equals(other.pod))
			return false;
		if (pol == null) {
			if (other.pol != null)
				return false;
		} else if (!pol.equals(other.pol))
			return false;
		if (viaje == null) {
			if (other.viaje != null)
				return false;
		} else if (!viaje.equals(other.viaje))
			return false;
		return true;
	}
	public String getaTrafico() {
		return aTrafico;
	}
	public void setaTrafico(String aTrafico) {
		this.aTrafico = aTrafico;
	}
	public String getaAduanal() {
		return aAduanal;
	}
	public void setaAduanal(String aAduanal) {
		this.aAduanal = aAduanal;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public String getFolioConsolidado() {
		return folioConsolidado;
	}
	public void setFolioConsolidado(String folioConsolidado) {
		this.folioConsolidado = folioConsolidado;
	}
	public String getConcatenado() {
		return concatenado;
	}
	public void setConcatenado(String concatenado) {
		this.concatenado = concatenado;
	}
	
	public boolean isConsolidado() {
		return consolidado;
	}
	public void setConsolidado(boolean consolidado) {
		this.consolidado = consolidado;
	}
	
	@Override
	public String toString() {
		return "BeanRowFileCarrier [booking=" + booking + ", bl=" + bl + ", contenedor=" + contenedor + ", etd=" + etd
				+ ", eta=" + eta + ", barco=" + barco + ", viaje=" + viaje + ", sar=" + sar + ", sarConsolidado="
				+ sarConsolidado + ", folioConsolidado=" + folioConsolidado + ", concatenado=" + concatenado + "]";
	}

	
	
	
	
	
}
