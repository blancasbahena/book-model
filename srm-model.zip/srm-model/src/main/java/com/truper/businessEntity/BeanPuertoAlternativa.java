package com.truper.businessEntity;


import java.util.HashSet;

import com.truper.infra.businessEntities.BaseBusinessEntity;


public class BeanPuertoAlternativa extends BaseBusinessEntity {
	
	
	private static final long serialVersionUID = 6234999152462573822L;	
	private String puerto;
	private HashSet<String> variantes;
	
	
	public String getPuerto() {
		return puerto;
	}
	public void setPuerto(String puerto) {
		this.puerto = puerto;
	}
	public HashSet<String> getVariantes() {
		return variantes;
	}
	public void setVariantes(HashSet<String> variantes) {
		this.variantes = variantes;
	}	
	
	
}
