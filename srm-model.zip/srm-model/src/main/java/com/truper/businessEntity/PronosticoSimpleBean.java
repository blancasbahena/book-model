package com.truper.businessEntity;

import java.math.BigDecimal;
import java.util.GregorianCalendar;

import com.truper.infra.businessEntities.BaseBusinessEntity;

public class PronosticoSimpleBean extends BaseBusinessEntity{
	/**
	 * 
	 */
	private static final long serialVersionUID = 3017588294044475758L;
	private BigDecimal pronostico;
	private BigDecimal backOrderPronosticado;
	private BigDecimal difVSPico;
	private Integer diasInvAlArribo;
	private Integer diasAlArribo;
	private GregorianCalendar endingDate;
	private GregorianCalendar backorderStartDate;
	private BeanDetallePOBuffer poBuffer;
	
	public PronosticoSimpleBean(){}
	/**
	 * @return the pronostico
	 */
	public BigDecimal getPronostico() {
		return pronostico;
	}
	/**
	 * @param pronostico the pronostico to set
	 */
	public void setPronostico(BigDecimal pronostico) {
		this.pronostico = pronostico;
	}
	/**
	 * @return the backOrderPronosticado
	 */
	public BigDecimal getBackOrderPronosticado() {
		return backOrderPronosticado;
	}
	/**
	 * @param backOrderPronosticado the backOrderPronosticado to set
	 */
	public void setBackOrderPronosticado(BigDecimal backOrderPronosticado) {
		this.backOrderPronosticado = backOrderPronosticado;
	}
	/**
	 * @return the difVSPico
	 */
	public BigDecimal getDifVSPico() {
		return difVSPico;
	}
	/**
	 * @param difVSPico the difVSPico to set
	 */
	public void setDifVSPico(BigDecimal difVSPico) {
		this.difVSPico = difVSPico;
	}
	/**
	 * @return the diasInvAlArribo
	 */
	public Integer getDiasInvAlArribo() {
		return diasInvAlArribo;
	}
	/**
	 * @param diasInvAlArribo the diasInvAlArribo to set
	 */
	public void setDiasInvAlArribo(Integer diasInvAlArribo) {
		this.diasInvAlArribo = diasInvAlArribo;
	}
	/**
	 * @return the diasAlArribo
	 */
	public Integer getDiasAlArribo() {
		return diasAlArribo;
	}
	/**
	 * @param diasAlArribo the diasAlArribo to set
	 */
	public void setDiasAlArribo(Integer diasAlArribo) {
		this.diasAlArribo = diasAlArribo;
	}
	/**
	 * @return the endingDate
	 */
	public GregorianCalendar getEndingDate() {
		return endingDate;
	}
	/**
	 * @param endingDate the endingDate to set
	 */
	public void setEndingDate(GregorianCalendar endingDate) {
		this.endingDate = endingDate;
	}
	/**
	 * @return the backorderStartDate
	 */
	public GregorianCalendar getBackorderStartDate() {
		return backorderStartDate;
	}
	/**
	 * @param backorderStartDate the backorderStartDate to set
	 */
	public void setBackorderStartDate(GregorianCalendar backorderStartDate) {
		this.backorderStartDate = backorderStartDate;
	}
	public BeanDetallePOBuffer getPoBuffer() {
		return poBuffer;
	}
	public void setPoBuffer(BeanDetallePOBuffer poBuffer) {
		this.poBuffer = poBuffer;
	}

	
}
