package com.truper.businessEntity.SRM;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Table;

import com.truper.infra.businessEntities.BaseBusinessEntity;

@Entity
@Table(name = "srm_PO_PRORROGAS")
public class Prorroga_PO extends BaseBusinessEntity {

	private static final long serialVersionUID = 1980087830919546536L;

	@Id
	@Column(name = "ID_TAREA_SOLICITUD", updatable = false, unique = true, insertable = false)
	private Long idTareaSolicitud;

	@Column(name = "MANAGER_ID")
	private Long managerId;
	
	@Column(name = "FECHA_FIN_PRORROGA")
	private Date fechaFinProrroga;

	@Column(name = "NOTA_SOLICITUD")
	private String notaProrroga;

	@Column(name = "ID_CAUSAL")
	private Integer idCausalProrroga;
	
	@Column(name = "NOTIF_VENCIMIENTO")
	private Integer notificacionVencimiento;

	@JoinColumn(table = "srm_CAT_CAUSAL_PRORROGA", name = "ID_CAUSAL", referencedColumnName = "ID")
	private CatCausalProrroga causalProrroga;

	public Long getIdTareaSolicitud() {
		return idTareaSolicitud;
	}

	public void setIdTareaSolicitud(Long idTareaSolicitud) {
		this.idTareaSolicitud = idTareaSolicitud;
	}
	
	public Long getManagerId() {
		return managerId;
	}

	public void setManagerId(Long managerId) {
		this.managerId = managerId;
	}
	
	public Date getFechaFinProrroga() {
		return fechaFinProrroga;
	}

	public void setFechaFinProrroga(Date fechaFinProrroga) {
		this.fechaFinProrroga = fechaFinProrroga;
	}

	public String getNotaProrroga() {
		return notaProrroga;
	}

	public void setNotaProrroga(String notaProrroga) {
		this.notaProrroga = notaProrroga;
	}

	public Integer getIdCausalProrroga() {
		return idCausalProrroga;
	}

	public void setIdCausalProrroga(Integer idCausalProrroga) {
		this.idCausalProrroga = idCausalProrroga;
	}

	public CatCausalProrroga getCausalProrroga() {
		return causalProrroga;
	}

	public void setCausalProrroga(CatCausalProrroga causalProrroga) {
		this.causalProrroga = causalProrroga;
	}

	public Integer getNotificacionVencimiento() {
		return notificacionVencimiento;
	}

	public void setNotificacionVencimiento(Integer notificacionVencimiento) {
		this.notificacionVencimiento = notificacionVencimiento;
	}

}
