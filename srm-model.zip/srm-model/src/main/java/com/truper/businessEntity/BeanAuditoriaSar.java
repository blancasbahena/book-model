package com.truper.businessEntity;

import com.truper.bpm.enums.EstatusAuditoriaEnum;

public class BeanAuditoriaSar extends BeanAuditoriaSinMatriz {

	private int folio;
	private String comentarios;
	private EstatusAuditoriaEnum estatus;

	public int getFolio() {
		return folio;
	}

	public void setFolio(int folio) {
		this.folio = folio;
	}

	public String getComentarios() {
		return comentarios;
	}

	public void setComentarios(String comentarios) {
		this.comentarios = comentarios;
	}

	public EstatusAuditoriaEnum getEstatus() {
		return estatus;
	}

	public void setEstatus(EstatusAuditoriaEnum estatus) {
		this.estatus = estatus;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("BeanAuditoriaSar [getFolio=");
		builder.append(getFolio());
		builder.append(", getComentarios=");
		builder.append(getComentarios());
		builder.append(", getEstatus=");
		builder.append(getEstatus());
		builder.append(", toString=");
		builder.append(super.toString());
		builder.append("]");
		return builder.toString();
	}

}
