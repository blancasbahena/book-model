package com.truper.businessEntity;

import com.truper.infra.businessEntities.BaseBusinessEntity;

public class CdiBloqueosBean  extends BaseBusinessEntity{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -2868136857659950876L;
	private String dato;
	private Integer fechaBloqueo;
	private Integer fechaDesBloqueo;
	private String tipo;
	private String usuario;
	private Boolean status;
	
	public String getDato() {
		return dato;
	}


	public void setDato(String dato) {
		this.dato = dato;
	}


	public Integer getFechaBloqueo() {
		return fechaBloqueo;
	}


	public void setFechaBloqueo(Integer fechaBloqueo) {
		this.fechaBloqueo = fechaBloqueo;
	}


	public Integer getFechaDesBloqueo() {
		return fechaDesBloqueo;
	}


	public void setFechaDesBloqueo(Integer fechaDesBloqueo) {
		this.fechaDesBloqueo = fechaDesBloqueo;
	}


	public String getTipo() {
		return tipo;
	}


	public void setTipo(String tipo) {
		this.tipo = tipo;
	}


	public String getUsuario() {
		return usuario;
	}


	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}


	public Boolean getStatus() {
		return status;
	}


	public void setStatus(Boolean status) {
		this.status = status;
	}


	
	
	
}
