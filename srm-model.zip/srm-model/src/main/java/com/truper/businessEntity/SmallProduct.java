package com.truper.businessEntity;

public class SmallProduct {

	private Integer material;
	private String centro;

	public SmallProduct(Integer material, String centro) {
		super();
		this.material = material;
		this.centro = centro;
	}

	public Integer getMaterial() {
		return material;
	}

	public void setMaterial(Integer material) {
		this.material = material;
	}

	public String getCentro() {
		return centro;
	}

	public void setCentro(String centro) {
		this.centro = centro;
	}
}