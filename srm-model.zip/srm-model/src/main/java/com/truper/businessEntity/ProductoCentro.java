package com.truper.businessEntity;

import java.math.BigDecimal;

import javax.xml.bind.annotation.XmlRootElement;

import com.truper.infra.businessEntities.BaseBusinessEntity;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@XmlRootElement
public class ProductoCentro extends BaseBusinessEntity{

	private static final long serialVersionUID = -4871057259207845777L;
	private String centro;
	private int shippingDays;
	private String cellCode;
	private BigDecimal ventaDRP;
	private char abc;
	
}
