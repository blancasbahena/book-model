package com.truper.businessEntity;

import java.io.Serializable;


public class BeanDetallePOBuffer implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -5535994424721711158L;
	private String poTTTSNumber;
	private String poTruperNumber;
	private String sarNumber;
	private String sarType;
	private String statusConfirm;
	private Integer opoETD;
	private Integer opoETAP5;
	private String sdVspi;
	private Double varVsLt;
	private Integer poQty;
	private Integer poDays;
	private Integer IDA;
	private Integer backOrder;
	private Double montoBO;
	private Integer invPeakReal;
	private Integer invPeakPlan;
	private String minQty;
	private Integer daysInStatusPO;
	private Double overStock;
	private String money;
	private String altVendor;
	private Double var8Sem;
	private String tipoPron;
	private String folioQCI;
	
	
	/**
	 * @return the poTTTSNumber
	 */
	public String getPoTTTSNumber() {
		return poTTTSNumber;
	}
	/**
	 * @param poTTTSNumber the poTTTSNumber to set
	 */
	public void setPoTTTSNumber(String poTTTSNumber) {
		this.poTTTSNumber = poTTTSNumber;
	}
	/**
	 * @return the poTruperNumber
	 */
	public String getPoTruperNumber() {
		return poTruperNumber;
	}
	/**
	 * @param poTruperNumber the poTruperNumber to set
	 */
	public void setPoTruperNumber(String poTruperNumber) {
		this.poTruperNumber = poTruperNumber;
	}
	/**
	 * @return the sarNumber
	 */
	public String getSarNumber() {
		return sarNumber;
	}
	/**
	 * @param sarNumber the sarNumber to set
	 */
	public void setSarNumber(String sarNumber) {
		this.sarNumber = sarNumber;
	}
	/**
	 * @return the isConsolidated
	 */
	public String getSarType() {
		return sarType;
	}
	/**
	 * @param isConsolidated the isConsolidated to set
	 */
	public void setSarType(String sarType) {
		this.sarType = sarType;
	}
	/**
	 * @return the statusConfirm
	 */
	public String getStatusConfirm() {
		return statusConfirm;
	}
	/**
	 * @param statusConfirm the statusConfirm to set
	 */
	public void setStatusConfirm(String statusConfirm) {
		this.statusConfirm = statusConfirm;
	}
	/**
	 * @return the opoETD
	 */
	public Integer getOpoETD() {
		return opoETD;
	}
	/**
	 * @param opoETD the opoETD to set
	 */
	public void setOpoETD(Integer opoETD) {
		this.opoETD = opoETD;
	}
	/**
	 * @return the opoETAP5
	 */
	public Integer getOpoETAP5() {
		return opoETAP5;
	}
	/**
	 * @param opoETAP5 the opoETAP5 to set
	 */
	public void setOpoETAP5(Integer opoETAP5) {
		this.opoETAP5 = opoETAP5;
	}
	/**
	 * @return the sdVspi
	 */
	public String getSdVspi() {
		return sdVspi;
	}
	/**
	 * @param sdVspi the sdVspi to set
	 */
	public void setSdVspi(String sdVspi) {
		this.sdVspi = sdVspi;
	}
	/**
	 * @return the varVsLt
	 */
	public Double getVarVsLt() {
		return varVsLt;
	}
	/**
	 * @param varVsLt the varVsLt to set
	 */
	public void setVarVsLt(Double varVsLt) {
		this.varVsLt = varVsLt;
	}
	/**
	 * @return the poQty
	 */
	public Integer getPoQty() {
		return poQty;
	}
	/**
	 * @param poQty the poQty to set
	 */
	public void setPoQty(Integer poQty) {
		this.poQty = poQty;
	}
	/**
	 * @return the poDays
	 */
	public Integer getPoDays() {
		return poDays;
	}
	/**
	 * @param poDays the poDays to set
	 */
	public void setPoDays(Integer poDays) {
		this.poDays = poDays;
	}
	/**
	 * @return the iDA
	 */
	public Integer getIDA() {
		return IDA;
	}
	/**
	 * @param iDA the iDA to set
	 */
	public void setIDA(Integer iDA) {
		IDA = iDA;
	}
	/**
	 * @return the backOrder
	 */
	public Integer getBackOrder() {
		return backOrder;
	}
	/**
	 * @param backOrder the backOrder to set
	 */
	public void setBackOrder(Integer backOrder) {
		this.backOrder = backOrder;
	}
	/**
	 * @return the montoBO
	 */
	public Double getMontoBO() {
		return montoBO;
	}
	/**
	 * @param montoBO the montoBO to set
	 */
	public void setMontoBO(Double montoBO) {
		this.montoBO = montoBO;
	}
	/**
	 * @return the invPeakReal
	 */
	public Integer getInvPeakReal() {
		return invPeakReal;
	}
	/**
	 * @param invPeakReal the invPeakReal to set
	 */
	public void setInvPeakReal(Integer invPeakReal) {
		this.invPeakReal = invPeakReal;
	}
	/**
	 * @return the invPeakPlan
	 */
	public Integer getInvPeakPlan() {
		return invPeakPlan;
	}
	/**
	 * @param invPeakPlan the invPeakPlan to set
	 */
	public void setInvPeakPlan(Integer invPeakPlan) {
		this.invPeakPlan = invPeakPlan;
	}
	/**
	 * @return the minQty
	 */
	public String getMinQty() {
		return minQty;
	}
	/**
	 * @param minQty the minQty to set
	 */
	public void setMinQty(String minQty) {
		this.minQty = minQty;
	}
	/**
	 * @return the daysInStatusPO
	 */
	public Integer getDaysInStatusPO() {
		return daysInStatusPO;
	}
	/**
	 * @param daysInStatusPO the daysInStatusPO to set
	 */
	public void setDaysInStatusPO(Integer daysInStatusPO) {
		this.daysInStatusPO = daysInStatusPO;
	}
	/**
	 * @return the overStock
	 */
	public Double getOverStock() {
		return overStock;
	}
	/**
	 * @param overStock the overStock to set
	 */
	public void setOverStock(Double overStock) {
		this.overStock = overStock;
	}
	/**
	 * @return the money
	 */
	public String getMoney() {
		return money;
	}
	/**
	 * @param money the money to set
	 */
	public void setMoney(String money) {
		this.money = money;
	}
	/**
	 * @return the altVendor
	 */
	public String getAltVendor() {
		return altVendor;
	}
	/**
	 * @param altVendor the altVendor to set
	 */
	public void setAltVendor(String altVendor) {
		this.altVendor = altVendor;
	}
	/**
	 * @return the var8Sem
	 */
	public Double getVar8Sem() {
		return var8Sem;
	}
	/**
	 * @param var8Sem the var8Sem to set
	 */
	public void setVar8Sem(Double var8Sem) {
		this.var8Sem = var8Sem;
	}
	/**
	 * @return the tipoPron
	 */
	public String getTipoPron() {
		return tipoPron;
	}
	/**
	 * @param tipoPron the tipoPron to set
	 */
	public void setTipoPron(String tipoPron) {
		this.tipoPron = tipoPron;
	}
	public String getFolioQCI() {
		return folioQCI;
	}
	public void setFolioQCI(String folioQCI) {
		this.folioQCI = folioQCI;
	}
	
}
