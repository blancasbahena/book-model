package com.truper.businessEntity;


import java.util.Date;

import com.truper.infra.businessEntities.BaseBusinessEntity;

public class BeanFactura  extends BaseBusinessEntity implements Cloneable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Integer id;
	private Integer versionDocumento;
	private String condicionDePago;
	private String nombre;
	private Boolean tieneMadera;
	private String paisOrigen;
	private Date fechaCreacion;
	private String rutaArchivo;
	private Boolean tieneOtros;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getVersionDocumento() {
		return versionDocumento;
	}
	public void setVersionDocumento(Integer versionDocumento) {
		this.versionDocumento = versionDocumento;
	}
	public String getCondicionDePago() {
		return condicionDePago;
	}
	public void setCondicionDePago(String condicionDePago) {
		this.condicionDePago = condicionDePago;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public Boolean getTieneMadera() {
		return tieneMadera;
	}
	public void setTieneMadera(Boolean tieneMadera) {
		this.tieneMadera = tieneMadera;
	}
	public String getPaisOrigen() {
		return paisOrigen;
	}
	public void setPaisOrigen(String paisOrigen) {
		this.paisOrigen = paisOrigen;
	}
	public Date getFechaCreacion() {
		return fechaCreacion;
	}
	public void setFechaCreacion(Date fechaCreacion) {
		this.fechaCreacion = fechaCreacion;
	}
	public String getRutaArchivo() {
		return rutaArchivo;
	}
	public void setRutaArchivo(String rutaArchivo) {
		this.rutaArchivo = rutaArchivo;
	}
	public Boolean getTieneOtros() {
		return tieneOtros;
	}
	public void setTieneOtros(Boolean tieneOtros) {
		this.tieneOtros = tieneOtros;
	}
	
	
	
	
}
