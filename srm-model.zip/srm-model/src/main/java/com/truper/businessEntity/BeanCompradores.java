package com.truper.businessEntity;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BeanCompradores implements Serializable{
	
	private static final long serialVersionUID = 1L;
	private String idPlanner;
	private String gerente;
	private String mailGerente;
	private String asistente;
	private String mailAsistente;
	private String comprador;
	private String mailComprador;

}
