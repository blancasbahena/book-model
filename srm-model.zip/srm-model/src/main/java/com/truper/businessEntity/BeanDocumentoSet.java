package com.truper.businessEntity;

import com.truper.bpm.enums.DocumentoSetEnum;

public class BeanDocumentoSet {

	private DocumentoSetEnum tipo;
	private String rutaArchivo;
	private String nombre;
	private String condicionPago;

	public BeanDocumentoSet() {
		super();
	}

	public BeanDocumentoSet(DocumentoSetEnum tipo, String rutaArchivo) {
		this();
		this.tipo = tipo;
		this.rutaArchivo = rutaArchivo;
	}

	public DocumentoSetEnum getTipo() {
		return tipo;
	}

	public void setTipo(DocumentoSetEnum tipo) {
		this.tipo = tipo;
	}

	public String getRutaArchivo() {
		return rutaArchivo;
	}

	public void setRutaArchivo(String rutaArchivo) {
		this.rutaArchivo = rutaArchivo;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getCondicionPago() {
		return condicionPago;
	}

	public void setCondicionPago(String condicionPago) {
		this.condicionPago = condicionPago;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("BeanDocumentoSet [getTipo=");
		builder.append(getTipo());
		builder.append(", getRutaArchivo=");
		builder.append(getRutaArchivo());
		builder.append(", getNombre=");
		builder.append(getNombre());
		builder.append(", getCondicionPago=");
		builder.append(getCondicionPago());
		builder.append("]");
		return builder.toString();
	}

}
