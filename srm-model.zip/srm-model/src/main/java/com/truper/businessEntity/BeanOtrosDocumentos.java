package com.truper.businessEntity;


import java.util.Date;

import com.truper.infra.businessEntities.BaseBusinessEntity;

public class BeanOtrosDocumentos  extends BaseBusinessEntity implements Cloneable {

	private static final long serialVersionUID = 1L;
	private Integer id;	
	private Integer versionDocumento;	 
	private String nombre;
	private Date fechaCreacion;
	private String rutaArchivo;
	private Date fechaEliminacion;
	private boolean eliminado;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getVersionDocumento() {
		return versionDocumento;
	}
	public void setVersionDocumento(Integer versionDocumento) {
		this.versionDocumento = versionDocumento;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public Date getFechaCreacion() {
		return fechaCreacion;
	}
	public void setFechaCreacion(Date fechaCreacion) {
		this.fechaCreacion = fechaCreacion;
	}
	public String getRutaArchivo() {
		return rutaArchivo;
	}
	public void setRutaArchivo(String rutaArchivo) {
		this.rutaArchivo = rutaArchivo;
	}
	public Date getFechaEliminacion() {
		return fechaEliminacion;
	}
	public void setFechaEliminacion(Date fechaEliminacion) {
		this.fechaEliminacion = fechaEliminacion;
	}
	public boolean isEliminado() {
		return eliminado;
	}
	public void setEliminado(boolean eliminado) {
		this.eliminado = eliminado;
	}
	
}
