package com.truper.businessEntity;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CdiManagersPlanners implements Serializable {

	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 7145833955824259676L;
	
	private Integer idManagerPlanner;
	private String idManager;
	private String idPlanner;
	
}
