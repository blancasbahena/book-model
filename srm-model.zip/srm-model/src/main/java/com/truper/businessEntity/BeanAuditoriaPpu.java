package com.truper.businessEntity;

public class BeanAuditoriaPpu extends BeanAuditoriaSinMatriz {

	private String comentarios;
	private String tipo;

	public String getComentarios() {
		return comentarios;
	}

	public void setComentarios(String comentarios) {
		this.comentarios = comentarios;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("BeanAuditoriaPpu [getComentarios=");
		builder.append(getComentarios());
		builder.append(", getTipo=");
		builder.append(getTipo());
		builder.append(", toString=");
		builder.append(super.toString());
		builder.append("]");
		return builder.toString();
	}

}
