package com.truper.businessEntity;

import com.truper.infra.businessEntities.BaseBusinessEntity;


public class BeanAerolinea extends BaseBusinessEntity {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 6234999152462573822L;
	private int clave;
	private String nombre;
	private boolean pagaTruper;
	
	public BeanAerolinea(int clave, String nombre, boolean pagaTruper){
		this.clave = clave;
		this.nombre = nombre;
		this.pagaTruper = pagaTruper;
	}
	
	public int getClave(){
		return clave;
	}
	
	public String getNombre(){
		return nombre;
	}
	
	public boolean isPagaTruper(){
		return pagaTruper;
	}

//	public JSONObject toJSON() {
//		JSONObject json = new JSONObject();
//		try{
//			json.put("clave", clave);
//			json.put("nombre", StringEscapeUtils.escapeHtml(nombre));
//			json.put("pagaTruper", pagaTruper);
//			
//		}catch(JSONException je){}
//		return json;
//	}
}
