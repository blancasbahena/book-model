package com.truper.businessEntity.SRM;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.truper.infra.businessEntities.BaseBusinessEntity;

@Entity
@Table(name = "srm_REGLAS_DOCUMENTOS")
public class ReglasDocumentos extends BaseBusinessEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8169659010376044507L;

	@Id
	@Column(name = "ID", updatable = false, unique = true, insertable = false)
	private Integer id;
	@Column(name = "ID_TIPO_REGLA")
	private Integer idTipoRegla;
	@Column(name = "VALOR")
	private String valor;
	@Column(name = "VIGENCIA")
	private Date vigencia;
	@Column(name = "ID_GRUPO_REGLA")
	private Integer idGrupoRegla;
	@Column(name = "ID_ARCHIVO")
	private Integer idArchivo;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getIdTipoRegla() {
		return idTipoRegla;
	}

	public void setIdTipoRegla(Integer idTipoRegla) {
		this.idTipoRegla = idTipoRegla;
	}

	public String getValor() {
		return valor;
	}

	public void setValor(String valor) {
		this.valor = valor;
	}

	public Date getVigencia() {
		return vigencia;
	}

	public void setVigencia(Date vigencia) {
		this.vigencia = vigencia;
	}

	public Integer getIdGrupoRegla() {
		return idGrupoRegla;
	}

	public void setIdGrupoRegla(Integer idGrupoRegla) {
		this.idGrupoRegla = idGrupoRegla;
	}

	public Integer getIdArchivo() {
		return idArchivo;
	}

	public void setIdArchivo(Integer idArchivo) {
		this.idArchivo = idArchivo;
	}

}
