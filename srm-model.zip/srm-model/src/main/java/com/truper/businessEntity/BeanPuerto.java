package com.truper.businessEntity;

import java.io.Serializable;

import com.truper.infra.businessEntities.BaseBusinessEntity;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@Getter
@Setter
@NoArgsConstructor
public class BeanPuerto extends BaseBusinessEntity  implements Serializable {

	private static final long serialVersionUID = -6821330090939929662L;
	private String clave;
	private String nombre;
	private String pais;
	private boolean activo;
	private String idPais;
	private boolean esDirecto;
	private boolean esOrigen;
	private boolean esDestino;
	
	/* Valor control de Puertos por Confirmador */
	private String status;
	
	public BeanPuerto(String clave, String nombre,boolean activo){
		this.clave = clave;
		this.nombre = nombre;
		this.activo = activo;
	}
	
}
