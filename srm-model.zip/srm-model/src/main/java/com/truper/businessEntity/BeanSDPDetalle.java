package com.truper.businessEntity;

import com.truper.infra.businessEntities.BaseBusinessEntity;

public class BeanSDPDetalle  extends BaseBusinessEntity implements Cloneable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int folio;
	private String po;
	private int posicion;
	private int cantidad;
	private double precio;
	private boolean validar;
	private double montoMax;
	private double monto;
	private String codigo;
	private int fechaProforma;
	
	
	public int getFolio() {
		return folio;
	}
	public void setFolio(int folio) {
		this.folio = folio;
	}
	public String getPo() {
		return po;
	}
	public void setPo(String po) {
		this.po = po;
	}
	public int getPosicion() {
		return posicion;
	}
	public void setPosicion(int posicion) {
		this.posicion = posicion;
	}
	public int getCantidad() {
		return cantidad;
	}
	public void setCantidad(int cantidad) {
		this.cantidad = cantidad;
	}
	public double getPrecio() {
		return precio;
	}
	public void setPrecio(double precio) {
		this.precio = precio;
	}
	public boolean isValidar() {
		return validar;
	}
	public void setValidar(boolean validar) {
		this.validar = validar;
	}
	public double getMontoMax() {
		return montoMax;
	}
	public void setMontoMax(double montoMax) {
		this.montoMax = montoMax;
	}
	public double getMonto() {
		return monto;
	}
	public void setMonto(double monto) {
		this.monto = monto;
	}
	public String getCodigo() {
		return codigo;
	}
	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}
	public int getFechaProforma() {
		return fechaProforma;
	}
	public void setFechaProforma(int fechaProforma) {
		this.fechaProforma = fechaProforma;
	}
	
}
