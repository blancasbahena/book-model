package com.truper.businessEntity.SRM;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.Table;

import com.truper.infra.businessEntities.BaseBusinessEntity;
import com.truper.srm.sap.Familia;

@Entity
@Table(name = "srm_FAMILIAS_AUTORIZACION_DG")
public class FamiliasAutorizacionDG extends BaseBusinessEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1987275227373354204L;

	@Id
	@Column(name = "ID", updatable = false, unique = true, insertable = false)
	private Integer id;
	@Column(name = "ID_FAMILIA")
	private String idFamilia;
	@Column(name = "ACTIVA")
	private Boolean activa;
	@Column(name = "FECHA_CARGA")
	private Date fechaCarga;

	@JoinColumns({ @JoinColumn(table = "srm_FAMILIAS", name = "ID_FAMILIA", referencedColumnName = "CLAVE") })
	private Familia familia;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getIdFamilia() {
		return idFamilia;
	}

	public void setIdFamilia(String idFamilia) {
		this.idFamilia = idFamilia;
	}

	public Boolean getActiva() {
		return activa;
	}

	public void setActiva(Boolean activa) {
		this.activa = activa;
	}

	public Date getFechaCarga() {
		return fechaCarga;
	}

	public void setFechaCarga(Date fechaCarga) {
		this.fechaCarga = fechaCarga;
	}

	public Familia getFamilia() {
		return familia;
	}

	public void setFamilia(Familia familia) {
		this.familia = familia;
	}
}
