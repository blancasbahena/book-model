package com.truper.businessEntity;


import java.util.Date;

import com.truper.infra.businessEntities.BaseBusinessEntity;

public class BeanBL  extends BaseBusinessEntity implements Cloneable {
	/**
	 * Este Bean me va a ayudar para la administracion de la informacion del Pre
	 * BL y El BL
	 */
	private static final long serialVersionUID = 1L;
	private Integer id;	
	private String tipo; ///Si es bl o preBL
	private Integer versionDocumento;	 
	private String nombre;
	private Date fechaCreacion;
	private String rutaArchivo;
	
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getTipo() {
		return tipo;
	}
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	public Integer getVersionDocumento() {
		return versionDocumento;
	}
	public void setVersionDocumento(Integer versionDocumento) {
		this.versionDocumento = versionDocumento;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public Date getFechaCreacion() {
		return fechaCreacion;
	}
	public void setFechaCreacion(Date fechaCreacion) {
		this.fechaCreacion = fechaCreacion;
	}
	public String getRutaArchivo() {
		return rutaArchivo;
	}
	public void setRutaArchivo(String rutaArchivo) {
		this.rutaArchivo = rutaArchivo;
	}
	
	
}
