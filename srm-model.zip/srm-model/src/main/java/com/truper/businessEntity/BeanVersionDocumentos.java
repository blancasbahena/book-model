package com.truper.businessEntity;


import com.truper.infra.businessEntities.BaseBusinessEntity;

public class BeanVersionDocumentos  extends BaseBusinessEntity implements Cloneable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Integer folio;
	private Double ultimaVersionFactura;
	private Double ultimaVersionPreBL;
	private Double ultimaVersionBL;
	private Double ultimaVersionPackingList;
	
	
	
	public Integer getFolio() {
		return folio;
	}
	public void setFolio(Integer folio) {
		this.folio = folio;
	}
	public Double getUltimaVersionFactura() {
		return ultimaVersionFactura;
	}
	public void setUltimaVersionFactura(Double ultimaVersionFactura) {
		this.ultimaVersionFactura = ultimaVersionFactura;
	}
	public Double getUltimaVersionPreBL() {
		return ultimaVersionPreBL;
	}
	public void setUltimaVersionPreBL(Double ultimaVersionPreBL) {
		this.ultimaVersionPreBL = ultimaVersionPreBL;
	}
	public Double getUltimaVersionBL() {
		return ultimaVersionBL;
	}
	public void setUltimaVersionBL(Double ultimaVersionBL) {
		this.ultimaVersionBL = ultimaVersionBL;
	}
	public Double getUltimaVersionPackingList() {
		return ultimaVersionPackingList;
	}
	public void setUltimaVersionPackingList(Double ultimaVersionPackingList) {
		this.ultimaVersionPackingList = ultimaVersionPackingList;
	}
	
}
