package com.truper.businessEntity;

import com.truper.bpm.enums.TipoEta;

public class EtaBean {

	private String numeroOrden;
	private String posicion;
	private Integer etd;
	private Integer eta;
	private TipoEta tipoEta;

	public String getNumeroOrden() {
		return numeroOrden;
	}

	public void setNumeroOrden(String numeroOrden) {
		this.numeroOrden = numeroOrden;
	}

	public String getPosicion() {
		return posicion;
	}

	public void setPosicion(String posicion) {
		this.posicion = posicion;
	}

	public Integer getEtd() {
		return etd;
	}

	public void setEtd(Integer etd) {
		this.etd = etd;
	}

	public Integer getEta() {
		return eta;
	}

	public void setEta(Integer eta) {
		this.eta = eta;
	}

	public TipoEta getTipoEta() {
		return tipoEta;
	}

	public void setTipoEta(TipoEta tipoEta) {
		this.tipoEta = tipoEta;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("EtaBean [getNumeroOrden=");
		builder.append(getNumeroOrden());
		builder.append(", getPosicion=");
		builder.append(getPosicion());
		builder.append(", getEtd=");
		builder.append(getEtd());
		builder.append(", getEta=");
		builder.append(getEta());
		builder.append(", getTipoEta=");
		builder.append(getTipoEta());
		builder.append("]");
		return builder.toString();
	}
}
