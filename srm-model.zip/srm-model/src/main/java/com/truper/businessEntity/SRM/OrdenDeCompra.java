package com.truper.businessEntity.SRM;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.truper.infra.businessEntities.BaseBusinessEntity;

@Entity
@Table(name = "srm_ORDEN_DE_COMPRA")
public class OrdenDeCompra extends BaseBusinessEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8972472936815805329L;

	@Id
	@Column(name = "ID", updatable = false, unique = true, insertable = false)
	private Integer id;
	@Column(name = "OC")
	private Integer ocId;
	@Column(name = "VERSION")
	private Integer version;
	@Column(name = "BPM_MANAGER_ID")
	private Long bpmManagerId;
	@Column(name = "FECHA")
	private Date fecha;
	@Column(name = "ACTIVO")
	private Boolean activo;

	@Column(name = "URGENTE")
	private Boolean urgente;

	@Column(name = "ID_CAT_URGENTE")
	private Integer tipoUrgente;

	@Column(name = "TRIAL")
	private Boolean trial;

	@Column(name = "ID_CAT_TRIAL")
	private Integer tipoTrial;

	private Nota[] notas;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getOcId() {
		return ocId;
	}

	public void setOcId(Integer ocId) {
		this.ocId = ocId;
	}

	public Integer getVersion() {
		return version;
	}

	public void setVersion(Integer version) {
		this.version = version;
	}

	public Long getBpmManagerId() {
		return bpmManagerId;
	}

	public void setBpmManagerId(Long bpmManagerId) {
		this.bpmManagerId = bpmManagerId;
	}

	public Date getFecha() {
		return fecha;
	}

	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}

	public Boolean getActivo() {
		return activo;
	}

	public void setActivo(Boolean activo) {
		this.activo = activo;
	}

	public Nota[] getNotas() {
		return notas;
	}

	public void setNotas(Nota[] notas) {
		this.notas = notas;
	}

	public Boolean getUrgente() {
		return urgente;
	}

	public void setUrgente(Boolean urgente) {
		this.urgente = urgente;
	}

	public Integer getTipoUrgente() {
		return tipoUrgente;
	}

	public void setTipoUrgente(Integer tipoUrgente) {
		this.tipoUrgente = tipoUrgente;
	}

	public Boolean getTrial() {
		return trial;
	}

	public void setTrial(Boolean trial) {
		this.trial = trial;
	}

	public Integer getTipoTrial() {
		return tipoTrial;
	}

	public void setTipoTrial(Integer tipoTrial) {
		this.tipoTrial = tipoTrial;
	}
}
