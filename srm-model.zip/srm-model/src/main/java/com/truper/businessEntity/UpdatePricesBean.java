package com.truper.businessEntity;

import java.math.BigDecimal;

public class UpdatePricesBean extends Position{

	private int folio;
	private BigDecimal unitPrice;
	private BigDecimal unitPriceOld;
	private boolean result;
	private String centro;
	
	
	public int getFolio() {
		return folio;
	}
	public void setFolio(int folio) {
		this.folio = folio;
	}
	public BigDecimal getUnitPrice() {
		return unitPrice;
	}
	public void setUnitPrice(BigDecimal unitPrice) {
		this.unitPrice = unitPrice;
	}	
	public boolean isResult() {
		return result;
	}
	public void setResult(boolean result) {
		this.result = result;
	}
	public BigDecimal getUnitPriceOld() {
		return unitPriceOld;
	}
	public void setUnitPriceOld(BigDecimal unitPriceOld) {
		this.unitPriceOld = unitPriceOld;
	}
	public String getCentro() {
		return centro;
	}
	public void setCentro(String centro) {
		this.centro = centro;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + folio;
		result = prime * result + ((unitPrice == null) ? 0 : unitPrice.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		UpdatePricesBean other = (UpdatePricesBean) obj;
		if (folio != other.folio)
			return false;
		if (unitPrice == null) {
			if (other.unitPrice != null)
				return false;
		} else if (!unitPrice.equals(other.unitPrice))
			return false;
		return true;
	}
	
	
	
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("UpdatePricesBean [folio=");
		builder.append(folio);
		builder.append(", unitPrice=");
		builder.append(unitPrice);
		builder.append(", result=");
		builder.append(result);
		builder.append(", getPo()=");
		builder.append(getPo());
		builder.append(", getPosition()=");
		builder.append(getPosition());
		builder.append(", getMaterial()=");
		builder.append(getMaterial());
		builder.append(", toString()=");
		builder.append(super.toString());
		builder.append(", getClass()=");
		builder.append(getClass());
		builder.append("]");
		return builder.toString();
	}
	
	
	
}