package com.truper.businessEntity.SRM;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.truper.infra.businessEntities.BaseBusinessEntity;

@Entity
@Table(name = "srm_cat_tipo_documento")
public class CatTipoDocumento extends BaseBusinessEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8183025757875008185L;

	@Id
	@Column(name = "ID", updatable = false, unique = true, insertable = false)
	private Integer id;
	@Column(name = "DESCRIPCION")
	private String descripcion;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

}
