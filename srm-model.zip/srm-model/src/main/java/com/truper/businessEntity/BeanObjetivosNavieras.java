package com.truper.businessEntity;

import com.truper.infra.businessEntities.BaseBusinessEntity;

public class BeanObjetivosNavieras extends BaseBusinessEntity {
	/**
	 * 
	 */
	private static final long serialVersionUID = -7847527468486231420L;
	private int clave;
	private double objetivo;
	private String tipoObjetivo;
	private int fechaInicio;
	private int fechaVigencia;
	private int fechaCreacion;
	private String usuarioModifica;
	/**
	 * @return the claveNaviera
	 */
	public int getClave() {
		return clave;
	}
	/**
	 * @param claveNaviera the claveNaviera to set
	 */
	public void setClave(int clave) {
		this.clave = clave;
	}
	/**
	 * @return the clavePuertoDescarga
	 */
	public String getTipoObjetivo() {
		return tipoObjetivo;
	}
	/**
	 * @param clavePuertoDescarga the clavePuertoDescarga to set
	 */
	public void setTipoObjetivo(String tipoObjetivo) {
		this.tipoObjetivo = tipoObjetivo;
	}
	/**
	 * @return the objetivo
	 */
	public double getObjetivo() {
		return objetivo;
	}
	/**
	 * @param objetivo the objetivo to set
	 */
	public void setObjetivo(double objetivo) {
		this.objetivo = objetivo;
	}
	/**
	 * @return the fechaInicio
	 */
	public int getFechaInicio() {
		return fechaInicio;
	}
	/**
	 * @param fechaInicio the fechaInicio to set
	 */
	public void setFechaInicio(int fechaInicio) {
		this.fechaInicio = fechaInicio;
	}
	/**
	 * @return the fechaVigencia
	 */
	public int getFechaVigencia() {
		return fechaVigencia;
	}
	/**
	 * @param fechaVigencia the fechaVigencia to set
	 */
	public void setFechaVigencia(int fechaVigencia) {
		this.fechaVigencia = fechaVigencia;
	}
	/**
	 * @return the fechaCreacion
	 */
	public int getFechaCreacion() {
		return fechaCreacion;
	}
	/**
	 * @param fechaCreacion the fechaCreacion to set
	 */
	public void setFechaCreacion(int fechaCreacion) {
		this.fechaCreacion = fechaCreacion;
	}
	/**
	 * @return the usuarioModifica
	 */
	public String getUsuarioModifica() {
		return usuarioModifica;
	}
	/**
	 * @param usuarioModifica the usuarioModifica to set
	 */
	public void setUsuarioModifica(String usuarioModifica) {
		this.usuarioModifica = usuarioModifica;
	}
	
}
