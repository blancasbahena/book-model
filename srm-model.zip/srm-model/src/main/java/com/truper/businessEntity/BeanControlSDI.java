package com.truper.businessEntity;

import java.util.Date;

import com.truper.infra.businessEntities.BaseBusinessEntity;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class BeanControlSDI extends BaseBusinessEntity implements Cloneable {
	
	private static final long serialVersionUID = 1L;
	
	private Integer idDocumentos;
	private Integer versionSDI;
	private String proveedor;
	private String booking;
	private Date fechaAceptaProveedor;
	private Date fechaAprobadoSDI;
	private String comentariosProveedor;
	private Boolean aprobadoSDI;
	private String analistaSDI;
	private Date fechaAsignado;
	private Date fechaRechazo;
	private String tipoBl;

}
