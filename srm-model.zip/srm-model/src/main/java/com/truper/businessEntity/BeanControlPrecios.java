package com.truper.businessEntity;

import java.math.BigDecimal;

public class BeanControlPrecios {

	private String proveedor;
	private String po;
	private Integer posicion;
	private Integer material;
	private String centro;
	private Integer cantidad;
	private BigDecimal precioUnitario;
	private Integer fecha;
	private String documentosRequeridos;

	public String getProveedor() {
		return proveedor;
	}

	public void setProveedor(String proveedor) {
		this.proveedor = proveedor;
	}

	public String getPo() {
		return po;
	}

	public void setPo(String po) {
		this.po = po;
	}

	public Integer getPosicion() {
		return posicion;
	}

	public void setPosicion(Integer posicion) {
		this.posicion = posicion;
	}

	public Integer getMaterial() {
		return material;
	}

	public void setMaterial(Integer material) {
		this.material = material;
	}

	public String getCentro() {
		return centro;
	}

	public void setCentro(String centro) {
		this.centro = centro;
	}

	public Integer getCantidad() {
		return cantidad;
	}

	public void setCantidad(Integer cantidad) {
		this.cantidad = cantidad;
	}

	public BigDecimal getPrecioUnitario() {
		return precioUnitario;
	}

	public void setPrecioUnitario(BigDecimal precioUnitario) {
		this.precioUnitario = precioUnitario;
	}

	public Integer getFecha() {
		return fecha;
	}

	public void setFecha(Integer fecha) {
		this.fecha = fecha;
	}

	public String getDocumentosRequeridos() {
		return documentosRequeridos;
	}

	public void setDocumentosRequeridos(String documentosRequeridos) {
		this.documentosRequeridos = documentosRequeridos;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("BeanControlPrecios [getProveedor=");
		builder.append(getProveedor());
		builder.append(", getPo=");
		builder.append(getPo());
		builder.append(", getPosicion=");
		builder.append(getPosicion());
		builder.append(", getMaterial=");
		builder.append(getMaterial());
		builder.append(", getCentro=");
		builder.append(getCentro());
		builder.append(", getCantidad=");
		builder.append(getCantidad());
		builder.append(", getPrecioUnitario=");
		builder.append(getPrecioUnitario());
		builder.append(", getFecha=");
		builder.append(getFecha());
		builder.append(", getDocumentosRequeridos=");
		builder.append(getDocumentosRequeridos());
		builder.append("]");
		return builder.toString();
	}

}