package com.truper.businessEntity;

public class BeanMaterialCentro {

	private int material;
	private String centro;

	public int getMaterial() {
		return material;
	}

	public void setMaterial(int material) {
		this.material = material;
	}

	public String getCentro() {
		return centro;
	}

	public void setCentro(String centro) {
		this.centro = centro;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("BeanMaterialCentro [getMaterial=");
		builder.append(getMaterial());
		builder.append(", getCentro=");
		builder.append(getCentro());
		builder.append("]");
		return builder.toString();
	}

}
