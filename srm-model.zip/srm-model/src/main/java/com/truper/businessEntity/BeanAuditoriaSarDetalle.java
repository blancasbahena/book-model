package com.truper.businessEntity;

import java.math.BigDecimal;
import java.util.Date;

public class BeanAuditoriaSarDetalle {

	private String po;
	private Integer posicion;
	private Integer material;
	private String clave;
	private Integer cantidad;
	private BigDecimal precioUnitario;
	private String bu;
	private Date etd;

	public String getPo() {
		return po;
	}

	public void setPo(String po) {
		this.po = po;
	}

	public Integer getPosicion() {
		return posicion;
	}

	public void setPosicion(Integer posicion) {
		this.posicion = posicion;
	}

	public Integer getMaterial() {
		return material;
	}

	public void setMaterial(Integer material) {
		this.material = material;
	}

	public String getClave() {
		return clave;
	}

	public void setClave(String clave) {
		this.clave = clave;
	}

	public Integer getCantidad() {
		return cantidad;
	}

	public void setCantidad(Integer cantidad) {
		this.cantidad = cantidad;
	}

	public BigDecimal getPrecioUnitario() {
		return precioUnitario;
	}

	public void setPrecioUnitario(BigDecimal precioUnitario) {
		this.precioUnitario = precioUnitario;
	}

	public String getBu() {
		return bu;
	}

	public void setBu(String bu) {
		this.bu = bu;
	}

	public Date getEtd() {
		return etd;
	}

	public void setEtd(Date etd) {
		this.etd = etd;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("BeanAuditoriaSarDetalle [getPo=");
		builder.append(getPo());
		builder.append(", getPosicion=");
		builder.append(getPosicion());
		builder.append(", getMaterial=");
		builder.append(getMaterial());
		builder.append(", getClave=");
		builder.append(getClave());
		builder.append(", getCantidad=");
		builder.append(getCantidad());
		builder.append(", getPrecioUnitario=");
		builder.append(getPrecioUnitario());
		builder.append(", getBu=");
		builder.append(getBu());
		builder.append(", getEtd=");
		builder.append(getEtd());
		builder.append("]");
		return builder.toString();
	}

}
