package com.truper.businessEntity;

import com.truper.infra.businessEntities.BaseBusinessEntity;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
public class UserProfileBean extends BaseBusinessEntity {
	private static final long serialVersionUID = 6329199750458464160L;
	private int idProfile;
	private String profileName;
	private int accessLevel;
	private boolean search;
	private boolean planner;
	private boolean planningMgr;
	private boolean shipping;
	private boolean booking;
	private boolean consolidationMgr;
	private boolean importsDirector;
	private boolean editImportsDirector;
	private boolean mrpMgr;
	private boolean supplier;
	private boolean changeProfile;
	private boolean readOnly;
	private boolean createUsers;
	private boolean changeOtherPwd;	
	private boolean segPOsSinSAR;
	private boolean segPOsSinSARAll;
	private boolean segPOsSinSARUpload;
	private boolean segPOsSinSAREditComments;
	private boolean segPOsSinSAREditStatus;
	private boolean sarsSinDocumentos;
	private boolean sarsConDocumentos;
	private boolean analistaSDI;
	private boolean isSDP;
	private boolean priceMatrices;
	private boolean priceRelease;
	private boolean manager;
	private boolean director;
	private boolean sinConfirmacionFinal;
	private boolean matriz;
	private boolean auditoria;
	private boolean readOnlyShipping;
	private boolean readOnlyBooking;
	private boolean readOnlySarsConDocumentos;
	private boolean veSARDirecto;
	private boolean veSARNormal;
	private boolean bloqueoDocumentos;
	private boolean revokeFinalConfirmation;
	private boolean daysETDBySupplierBatch;
	private boolean veRequisitosImportacion;
	private boolean veTruper;
	private boolean veComercio;
	private boolean vePagoFactura;
	private boolean creditNote;
	private boolean facturacion;
	private boolean entregaATraficoyCXP;
	private boolean gerenteSrCoberturaI;
	private boolean directorCoberturaI;
	private boolean gerenteConfirmacion;
	private boolean confirmationManager;
	private boolean gerenteConfirmacionGDR;
	private boolean gerenteConfirmacionSrGDR;
	private boolean gerenteConfirmacionBOGDR;
	private boolean gerenteOnHoldGDR;
	private boolean veSettingPOD;
	private boolean vePlannersAssignation;
	private boolean dcontrolbuyers;
	private boolean dcontrolplanning;
	private boolean dcontrolcanceled;
	private boolean dcontrolclosed;

}