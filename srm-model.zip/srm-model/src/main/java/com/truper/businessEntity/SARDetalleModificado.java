package com.truper.businessEntity;

import com.truper.infra.businessEntities.BaseBusinessEntity;

public class SARDetalleModificado extends BaseBusinessEntity{
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -6515344254381666573L;
	public static final Integer DETALLE_AGREGADO = Integer.valueOf(1);
	public static final Integer DETALLE_MODIFICADO = Integer.valueOf(2);
	public static final Integer DETALLE_ELIMINADO = Integer.valueOf(3);
	//Datos que hay en tabla
	private Integer folio;
	private Integer posicion;
	private Integer material;
	private Integer cantidad;
		
	private Double pesoProveedor;
	private Double volumenProveedor;
	private Double pesoPO;
	private Double volumenPO;	
	private String po;			
	private Integer cantidadModificada;
	private Double pesoModificado;
	private Double volumenModificado;
	private Integer tipoModificacion;
	
	
	/**********   Setters y Getters ***********/
	public Integer getFolio() {
		return folio;
	}
	public void setFolio(Integer folio) {
		this.folio = folio;
	}
	public Integer getPosicion() {
		return posicion;
	}
	public void setPosicion(Integer posicion) {
		this.posicion = posicion;
	}
	public Integer getMaterial() {
		return material;
	}
	public void setMaterial(Integer material) {
		this.material = material;
	}
	public Integer getCantidad() {
		return cantidad;
	}
	public void setCantidad(Integer cantidad) {
		this.cantidad = cantidad;
	}
	public Double getPesoProveedor() {
		return pesoProveedor;
	}
	public void setPesoProveedor(Double pesoProveedor) {
		this.pesoProveedor = pesoProveedor;
	}
	public Double getVolumenProveedor() {
		return volumenProveedor;
	}
	public void setVolumenProveedor(Double volumenProveedor) {
		this.volumenProveedor = volumenProveedor;
	}
	public Double getPesoPO() {
		return pesoPO;
	}
	public void setPesoPO(Double pesoPO) {
		this.pesoPO = pesoPO;
	}
	public Double getVolumenPO() {
		return volumenPO;
	}
	public void setVolumenPO(Double volumenPO) {
		this.volumenPO = volumenPO;
	}
	public String getPo() {
		return po;
	}
	public void setPo(String po) {
		this.po = po;
	}
	public Integer getCantidadModificada() {
		return cantidadModificada;
	}
	public void setCantidadModificada(Integer cantidadModificada) {
		this.cantidadModificada = cantidadModificada;
	}
	public Double getPesoModificado() {
		return pesoModificado;
	}
	public void setPesoModificado(Double pesoModificado) {
		this.pesoModificado = pesoModificado;
	}
	public Double getVolumenModificado() {
		return volumenModificado;
	}
	public void setVolumenModificado(Double volumenModificado) {
		this.volumenModificado = volumenModificado;
	}
	public Integer getTipoModificacion() {
		return tipoModificacion;
	}
	public void setTipoModificacion(Integer tipoModificacion) {
		this.tipoModificacion = tipoModificacion;
	}
	
}
