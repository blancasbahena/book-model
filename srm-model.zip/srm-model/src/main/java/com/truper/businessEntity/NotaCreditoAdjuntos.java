package com.truper.businessEntity;

import java.io.Serializable;
import java.util.Date;

import lombok.Data;

@Data
public class NotaCreditoAdjuntos implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private long idAdjunto;
	private long idNotaCredito;
	private String rutaNombre;
	private String nombreOriginal;
	private int idArchivo;
	private String autoname; //Tipo Archivo y Extensión
	private Date fechaIngreso; //Fecha ingreso o modificación
	private String usuario;
	private boolean eliminado;
}
