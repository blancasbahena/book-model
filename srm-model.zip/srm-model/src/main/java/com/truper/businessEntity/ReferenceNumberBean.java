package com.truper.businessEntity;


import com.truper.infra.businessEntities.BaseBusinessEntity;

public class ReferenceNumberBean  extends BaseBusinessEntity implements Cloneable {
								
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Integer folio;
	private String referenceNumber;
	private String vesselName;
	private String usuario;
	private Integer bookingRequestDateCompany;
	private Integer ETD;
	private Integer fechaCreacion;
	private Integer carrier;
	private Long fechaCreacionLong;
	private String comentario;
	private Integer  version;
	private String respuestaBooking;
	
	
	
	public Integer getFolio() {
		return folio;
	}
	public void setFolio(Integer folio) {
		this.folio = folio;
	}
	public String getReferenceNumber() {
		return referenceNumber;
	}
	public void setReferenceNumber(String referenceNumber) {
		this.referenceNumber = referenceNumber;
	}
	public String getVesselName() {
		return vesselName;
	}
	public void setVesselName(String vesselName) {
		this.vesselName = vesselName;
	}
	public String getUsuario() {
		return usuario;
	}
	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}
	public Integer getBookingRequestDateCompany() {
		return bookingRequestDateCompany;
	}
	public void setBookingRequestDateCompany(Integer bookingRequestDateCompany) {
		this.bookingRequestDateCompany = bookingRequestDateCompany;
	}
	public Integer getETD() {
		return ETD;
	}
	public void setETD(Integer eTD) {
		ETD = eTD;
	}
	public Integer getFechaCreacion() {
		return fechaCreacion;
	}
	public void setFechaCreacion(Integer fechaCreacion) {
		this.fechaCreacion = fechaCreacion;
	}
	public Long getFechaCreacionLong() {
		return fechaCreacionLong;
	}
	public void setFechaCreacionLong(Long fechaCreacionLong) {
		this.fechaCreacionLong = fechaCreacionLong;
	}
	public Integer getCarrier() {
		return carrier;
	}
	public void setCarrier(Integer carrier) {
		this.carrier = carrier;
	}
	public String getComentario() {
		return comentario;
	}
	public void setComentario(String comentario) {
		this.comentario = comentario;
	}
	public Integer getVersion() {
		return version;
	}
	public void setVersion(Integer version) {
		this.version = version;
	}
	public String getRespuestaBooking() {
		return respuestaBooking;
	}
	public void setRespuestaBooking(String respuestaBooking) {
		this.respuestaBooking = respuestaBooking;
	}	
	
}
