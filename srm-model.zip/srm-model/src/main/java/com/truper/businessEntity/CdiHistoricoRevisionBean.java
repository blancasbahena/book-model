package com.truper.businessEntity;

import com.truper.infra.businessEntities.BaseBusinessEntity;

public class CdiHistoricoRevisionBean extends BaseBusinessEntity{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -107767996764274563L;
	private Integer sar;
	private Integer fecha;
	private Integer revision;
	private String accion;
	private String comentario;
	
	public Integer getSar() {
		return sar;
	}


	public void setSar(Integer sar) {
		this.sar = sar;
	}


	public Integer getFecha() {
		return fecha;
	}


	public void setFecha(Integer fecha) {
		this.fecha = fecha;
	}


	public Integer getRevision() {
		return revision;
	}


	public void setRevision(Integer revision) {
		this.revision = revision;
	}


	public String getAccion() {
		return accion;
	}


	public void setAccion(String accion) {
		this.accion = accion;
	}


	public String getComentario() {
		return comentario;
	}


	public void setComentario(String comentario) {
		this.comentario = comentario;
	}
	
	
	
}
