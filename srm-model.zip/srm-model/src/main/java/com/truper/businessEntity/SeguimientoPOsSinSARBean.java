package com.truper.businessEntity;

import java.math.BigDecimal;

import com.truper.infra.businessEntities.BaseBusinessEntity;

public class SeguimientoPOsSinSARBean extends BaseBusinessEntity{

	/**
	 * 
	 */
	private static final long serialVersionUID = -8452899005026294826L;
	private String po;
	private Integer mes;
	private String supplier;
	private Integer etd;
	private BigDecimal montoBO;
	private String planningResponsible;
	private String fungRuiResponsible;
	private String buResponsible;
	private Integer onTime;
	private String booking;
	private String container;
	private String comments;
	private Integer folio;
	private Integer status;
	private String modificationUser;
	private String openClosed;
	private Integer from;
	private Integer to;
	private Integer piDate;
	
	public String getPo() {
		return po;
	}
	public void setPo(String po) {
		this.po = po;
	}
	public Integer getMes() {
		return mes;
	}
	public void setMes(Integer mes) {
		this.mes = mes;
	}
	public String getSupplier() {
		return supplier;
	}
	public void setSupplier(String supplier) {
		this.supplier = supplier;
	}
	public Integer getEtd() {
		return etd;
	}
	public void setEtd(Integer etd) {
		this.etd = etd;
	}
	public BigDecimal getMontoBO() {
		return montoBO;
	}
	public void setMontoBO(BigDecimal montoBO) {
		this.montoBO = montoBO;
	}
	public String getPlanningResponsible() {
		return planningResponsible;
	}
	public void setPlanningResponsible(String planningResponsible) {
		this.planningResponsible = planningResponsible;
	}
	public String getFungRuiResponsible() {
		return fungRuiResponsible;
	}
	public void setFungRuiResponsible(String fungRuiResponsible) {
		this.fungRuiResponsible = fungRuiResponsible;
	}
	public String getBuResponsible() {
		return buResponsible;
	}
	public void setBuResponsible(String buResponsible) {
		this.buResponsible = buResponsible;
	}
	public Integer getOnTime() {
		return onTime;
	}
	public void setOnTime(Integer onTime) {
		this.onTime = onTime;
	}
	public String getBooking() {
		return booking;
	}
	public void setBooking(String booking) {
		this.booking = booking;
	}
	public String getContainer() {
		return container;
	}
	public void setContainer(String container) {
		this.container = container;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public Integer getFolio() {
		return folio;
	}
	public void setFolio(Integer folio) {
		this.folio = folio;
	}
	public Integer getStatus() {
		return status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
	public String getModificationUser() {
		return modificationUser;
	}
	public void setModificationUser(String modificationUser) {
		this.modificationUser = modificationUser;
	}
	public String getOpenClosed() {
		return openClosed;
	}
	public void setOpenClosed(String openClosed) {
		this.openClosed = openClosed;
	}
	public Integer getFrom() {
		return from;
	}
	public void setFrom(Integer from) {
		this.from = from;
	}
	public Integer getTo() {
		return to;
	}
	public void setTo(Integer to) {
		this.to = to;
	}
	public Integer getPiDate() {
		return piDate;
	}
	public void setPiDate(Integer piDate) {
		this.piDate = piDate;
	}

}
