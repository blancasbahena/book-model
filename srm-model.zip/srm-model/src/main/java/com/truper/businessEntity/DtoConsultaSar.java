package com.truper.businessEntity;

import com.truper.infra.businessEntities.BaseBusinessEntity;

public class DtoConsultaSar extends BaseBusinessEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5776583285829998397L;

	private String folio = null;
	private String po = null;
	private String eta1 = null;
	private String eta2 = null;
	private String etd1 = null;
	private String etd2 = null;
	private String fechaCreacion1 = null;
	private String fechaCreacion2 = null;
	private String puertoOrigen = null;
	private String puertoDestino = null;
	private String naviera = null;
	private String barco = null;
	private String status = null;
	private String material = null;
	private String prioridad = null;
	private String bookingSeach = null;
	private String contenedorSeach = null;
	private String viajeSeach = null;
	private String proveedorSeach = null;
	private String tipoFolio = null;

	public static final String TIPO_CONSULTA_AMBOS = "";
	public static final String TIPO_CONSULTA_CONSOLIDADOS = "cc";
	public static final String TIPO_CONSULTA_SAR = "f";

	public String getFolio() {
		return folio;
	}

	public void setFolio(String folio) {
		if (folio == null || !folio.trim().equals("")) {
			this.folio = folio;
		}
	}

	public String getPo() {
		return po;
	}

	public void setPo(String po) {
		if (po == null || !po.trim().equals("")) {
			this.po = po;
		}
	}

	public String getEta1() {
		return eta1;
	}

	public void setEta1(String eta1) {
		if (eta1 == null || !eta1.trim().equals("")) {
			this.eta1 = eta1;
		}
	}

	public String getEta2() {
		return eta2;
	}

	public void setEta2(String eta2) {
		if (eta2 == null || !eta2.trim().equals("")) {
			this.eta2 = eta2;
		}
	}

	public String getEtd1() {
		return etd1;
	}

	public void setEtd1(String etd1) {
		if (etd1 == null || !etd1.trim().equals("")) {
			this.etd1 = etd1;
		}
	}

	public String getEtd2() {
		return etd2;
	}

	public void setEtd2(String etd2) {
		if (etd2 == null || !etd2.trim().equals("")) {
			this.etd2 = etd2;
		}
	}

	public String getPuertoOrigen() {
		return puertoOrigen;
	}

	public void setPuertoOrigen(String puertoOrigen) {
		if (puertoOrigen == null || !puertoOrigen.trim().equals("0")) {
			this.puertoOrigen = puertoOrigen;
		}
	}

	public String getPuertoDestino() {
		return puertoDestino;
	}

	public void setPuertoDestino(String puertoDestino) {
		if (puertoDestino == null || !puertoDestino.trim().equals("0")) {
			this.puertoDestino = puertoDestino;
		}
	}

	public String getNaviera() {
		return naviera;
	}

	public void setNaviera(String naviera) {
		if (naviera == null || !naviera.trim().equals("0")) {
			this.naviera = naviera;
		}
	}

	public String getBarco() {
		return barco;
	}

	public void setBarco(String barco) {
		if (barco == null || !barco.trim().equals("")) {
			this.barco = barco;
		}
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		if (status == null || !status.trim().equals("-1")) {
			this.status = status;
		}
	}

	public String getMaterial() {
		return material;
	}

	public void setMaterial(String material) {
		if (material == null || !material.trim().equals("")) {
			this.material = material;
		}
	}

	public String getPrioridad() {
		return prioridad;
	}

	public void setPrioridad(String prioridad) {
		if (prioridad == null || !prioridad.trim().equals("0")) {
			this.prioridad = prioridad;
		}
	}

	public String getBookingSeach() {
		return bookingSeach;
	}

	public void setBookingSeach(String bookingSeach) {
		if (bookingSeach == null || !bookingSeach.trim().equals("")) {
			this.bookingSeach = bookingSeach;
		}
	}

	public String getContenedorSeach() {
		return contenedorSeach;
	}

	public void setContenedorSeach(String contenedorSeach) {
		if (contenedorSeach == null || !contenedorSeach.trim().equals("")) {
			this.contenedorSeach = contenedorSeach;
		}
	}

	public String getViajeSeach() {
		return viajeSeach;
	}

	public void setViajeSeach(String viajeSeach) {
		if (viajeSeach == null || !viajeSeach.trim().equals("")) {
			this.viajeSeach = viajeSeach;
		}
	}

	public String getProveedorSeach() {
		return proveedorSeach;
	}

	public void setProveedorSeach(String proveedorSeach) {
		if (proveedorSeach == null || !proveedorSeach.trim().equals("")) {
			this.proveedorSeach = proveedorSeach;
		}
	}

	public String getTipoFolio() {
		if (this.tipoFolio == null) {
			return "";
		}
		return this.tipoFolio;
	}

	public void setTipoFolio(String tipoFolio) {
		this.tipoFolio = tipoFolio;
	}

	public boolean esConsultaAmbos() {
		String tipoConsulta = this.getTipoFolio();
		if (tipoConsulta == null) {
			return true;
		}
		boolean consultaAmbos = tipoConsulta
				.equals(DtoConsultaSar.TIPO_CONSULTA_AMBOS);
		return consultaAmbos;
	}

	public boolean esConsultaConsol() {
		String tipoConsulta = this.getTipoFolio();
		boolean consultaAmbos = tipoConsulta
				.equals(DtoConsultaSar.TIPO_CONSULTA_CONSOLIDADOS);
		return consultaAmbos;
	}

	public boolean esConsultaSar() {
		String tipoConsulta = this.getTipoFolio();
		boolean consultaAmbos = tipoConsulta
				.equals(DtoConsultaSar.TIPO_CONSULTA_SAR);
		return consultaAmbos;
	}
	
	

	public String getFechaCreacion1() {
		return fechaCreacion1;
	}

	public void setFechaCreacion1(String fechaCreacion1) {
		this.fechaCreacion1 = fechaCreacion1;
	}

	public String getFechaCreacion2() {
		return fechaCreacion2;
	}

	public void setFechaCreacion2(String fechaCreacion2) {
		this.fechaCreacion2 = fechaCreacion2;
	}

	public boolean conFiltrosDeConsulta() {
		
		boolean sinFiltro = (folio == null && po == null && eta1 == null
				&& eta2 == null && etd1 == null && etd2 == null
				&& puertoOrigen == null && puertoDestino == null
				&& naviera == null && barco == null && status == null
				&& material == null && prioridad == null
				&& bookingSeach == null && contenedorSeach == null
				&& viajeSeach == null && proveedorSeach == null
				&& fechaCreacion1 == null && fechaCreacion2 == null);
		
		return !sinFiltro;
	}
}
