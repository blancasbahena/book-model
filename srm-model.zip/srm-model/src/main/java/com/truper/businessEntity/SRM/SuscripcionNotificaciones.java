package com.truper.businessEntity.SRM;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.truper.infra.businessEntities.BaseBusinessEntity;

@Entity
@Table(name = "srm_SUSCRIPCION_NOTIFICACIONES")
public class SuscripcionNotificaciones extends BaseBusinessEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7219490951746758559L;

	@Column(name = "USUARIO")
	private String usuario;
	@Column(name = "ENDPOINT_ID")
	private String endpointId;
	@Column(name = "P256DH")
	private String p256dh;
	@Column(name = "AUTH")
	private String auth;

	public String getUsuario() {
		return usuario;
	}

	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}

	public String getEndpointId() {
		return endpointId;
	}

	public void setEndpointId(String endpointId) {
		this.endpointId = endpointId;
	}

	public String getP256dh() {
		return p256dh;
	}

	public void setP256dh(String p256dh) {
		this.p256dh = p256dh;
	}

	public String getAuth() {
		return auth;
	}

	public void setAuth(String auth) {
		this.auth = auth;
	}

}
