package com.truper.businessEntity;

import java.math.BigDecimal;
import java.util.GregorianCalendar;
import java.util.Map;

import javax.xml.bind.annotation.XmlRootElement;

import com.truper.infra.businessEntities.BaseBusinessEntity;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@XmlRootElement
public class ProductoBean extends BaseBusinessEntity{
	/**
	 * 
	 */
	private static final long serialVersionUID = -4818354415712783168L;
	private static final String EMPTY_STRING = "";
	private String codigo;
	private String descripcion;
	private String description;
	private double costoFOB;
	private String monedaCostoFOB;
	private double highestStockDays;
	private double highestStockAmount;
	private double stockDays;
	private boolean materiaPrima;
	private int existencia;
	private int existenciaHoy;
	private int cantidadDetalle;
	private BigDecimal precioDistSinIvaMenos20;
	private BigDecimal precioDistSinIva;
	private boolean comercializado;
	private int master;
	private String centro;
	private String cellCode;
	private Integer shippingDays;
	private BigDecimal peso;
	private BigDecimal pesoMaster;
	private BigDecimal volumen;
	private BigDecimal volumenMaster;
	private String unidad;
	private String clave;
	private GregorianCalendar fecIniPronostico;
	private GregorianCalendar fecFinPronostico;
	private double existParaPronostico;
	private boolean nuevoSinIntroduccion;
	private int vigenciaNuevo;
	private boolean hazMat;
	private boolean clase8;
	private boolean tienePromocion;
	private boolean refaccion;
	private String familia;
	private double safetyStock;
	private double daysSafetyStock;
	private String mesesPromocion;
	private String marca;
	private String marcaComercial;
	private Map<String , ProductoCentro>  productoCentro;
 	private boolean isHighVolumeProduct;
	private boolean isSeasonal;
	private String totalVar12Semanas;
	private String totalVar8Semanas;

 	private BigDecimal ventaMrp; 

	public ProductoBean() {
		this.codigo = EMPTY_STRING;
		this.descripcion = EMPTY_STRING;
		this.description = EMPTY_STRING;
	}
		

	
}
