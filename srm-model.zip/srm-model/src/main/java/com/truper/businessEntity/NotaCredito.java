package com.truper.businessEntity;

import java.io.Serializable;
import java.sql.Date;

import lombok.Data;

@Data
public class NotaCredito implements Serializable {

	private static final long serialVersionUID = 1L;
	private long idNotaCredito;
	private Date fechaCreacion;
	private int idEstatus;
	private long idInstanceManager;
	private int idProveedor;
	private String nombreProveedor;
	private int idEmpresa;
	private double total;
	private String moneda;
	private int idConcepto;
	private String idNCProveedor;
	private String idNCTruper;
	private Date fechaAceptacionProveedor;
	private Date fechaRechazoProveedor;
	private String comentariosProveedor;
	private Date fechaAceptacionAuditoria;
	private Date fechaRechazoAuditoria;
	private String comentariosAuditoria;
	private long folioSIFE;
	private Date fechaGeneracionPDF;
	private int idUsuario;
	private String idPO;
	
}
