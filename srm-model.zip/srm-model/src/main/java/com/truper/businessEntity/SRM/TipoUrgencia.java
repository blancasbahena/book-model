package com.truper.businessEntity.SRM;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.truper.infra.businessEntities.BaseBusinessEntity;

/**
 * @author Pablo Cruz Santos
 * @version 1.0
 * @date 19/01/2016
 */
@Entity
@Table(name = "srm_CAT_TIPO_URGENCIA")
public class TipoUrgencia extends BaseBusinessEntity {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "ID", updatable = false, unique = true, insertable = false)
	private Integer id;

	@Column(name = "DESCRIPCION")
	private String descripcion;

	@Column(name = "ID_CAT_UNIDAD_NEGOCIO")
	private Integer tipoUnidadNegocio;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public Integer getTipoUnidadNegocio() {
		return tipoUnidadNegocio;
	}

	public void setTipoUnidadNegocio(Integer tipoUnidadNegocio) {
		this.tipoUnidadNegocio = tipoUnidadNegocio;
	}
}
