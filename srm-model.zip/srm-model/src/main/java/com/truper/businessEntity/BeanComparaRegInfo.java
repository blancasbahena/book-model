package com.truper.businessEntity;

public class BeanComparaRegInfo {

	private String grupoArticulo;//MATKL
	private String proveedorRegular;//RELIF
	private String proveedor;
	private String material;
	private double precio1;
	private String moneda1;
	private String vigenciaIni1;
	private String vigenciaFin1;
	private double precio2;
	private String moneda2;
	private String vigenciaIni2;
	private String vigenciaFin2;
	private double precio3;
	private String moneda3;
	private String vigenciaIni3;
	private String vigenciaFin3;
	private double precio4;
	private String moneda4;
	private String vigenciaIni4;
	private String vigenciaFin4;
	public String getGrupoArticulo() {
		return grupoArticulo;
	}
	public void setGrupoArticulo(String grupoArticulo) {
		this.grupoArticulo = grupoArticulo;
	}
	public String getProveedorRegular() {
		return proveedorRegular;
	}
	public void setProveedorRegular(String proveedorRegular) {
		this.proveedorRegular = proveedorRegular;
	}
	public String getProveedor() {
		return proveedor;
	}
	public void setProveedor(String proveedor) {
		this.proveedor = proveedor;
	}
	public String getMaterial() {
		return material;
	}
	public void setMaterial(String material) {
		this.material = material;
	}
	public double getPrecio1() {
		return precio1;
	}
	public void setPrecio1(double precio1) {
		this.precio1 = precio1;
	}
	public String getMoneda1() {
		return moneda1;
	}
	public void setMoneda1(String moneda1) {
		this.moneda1 = moneda1;
	}
	public String getVigenciaIni1() {
		return vigenciaIni1;
	}
	public void setVigenciaIni1(String vigenciaIni1) {
		this.vigenciaIni1 = vigenciaIni1;
	}
	public String getVigenciaFin1() {
		return vigenciaFin1;
	}
	public void setVigenciaFin1(String vigenciaFin1) {
		this.vigenciaFin1 = vigenciaFin1;
	}
	public double getPrecio2() {
		return precio2;
	}
	public void setPrecio2(double precio2) {
		this.precio2 = precio2;
	}
	public String getMoneda2() {
		return moneda2;
	}
	public void setMoneda2(String moneda2) {
		this.moneda2 = moneda2;
	}
	public String getVigenciaIni2() {
		return vigenciaIni2;
	}
	public void setVigenciaIni2(String vigenciaIni2) {
		this.vigenciaIni2 = vigenciaIni2;
	}
	public String getVigenciaFin2() {
		return vigenciaFin2;
	}
	public void setVigenciaFin2(String vigenciaFin2) {
		this.vigenciaFin2 = vigenciaFin2;
	}
	public double getPrecio3() {
		return precio3;
	}
	public void setPrecio3(double precio3) {
		this.precio3 = precio3;
	}
	public String getMoneda3() {
		return moneda3;
	}
	public void setMoneda3(String moneda3) {
		this.moneda3 = moneda3;
	}
	public String getVigenciaIni3() {
		return vigenciaIni3;
	}
	public void setVigenciaIni3(String vigenciaIni3) {
		this.vigenciaIni3 = vigenciaIni3;
	}
	public String getVigenciaFin3() {
		return vigenciaFin3;
	}
	public void setVigenciaFin3(String vigenciaFin3) {
		this.vigenciaFin3 = vigenciaFin3;
	}
	public double getPrecio4() {
		return precio4;
	}
	public void setPrecio4(double precio4) {
		this.precio4 = precio4;
	}
	public String getMoneda4() {
		return moneda4;
	}
	public void setMoneda4(String moneda4) {
		this.moneda4 = moneda4;
	}
	public String getVigenciaIni4() {
		return vigenciaIni4;
	}
	public void setVigenciaIni4(String vigenciaIni4) {
		this.vigenciaIni4 = vigenciaIni4;
	}
	public String getVigenciaFin4() {
		return vigenciaFin4;
	}
	public void setVigenciaFin4(String vigenciaFin4) {
		this.vigenciaFin4 = vigenciaFin4;
	}
	
}