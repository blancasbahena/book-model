package com.truper.businessEntity;

import java.math.BigDecimal;
import java.util.HashSet;

public class BeanSarConfirmacionFinalSinDocumentos {

	private Integer folio;
	private Integer fechaEtd;
	private Integer fechaEta;
	private String proveedor;
	private String proveedorNombre;
	private String booking;
	private Integer fechaConfirmacionFinal;
	private Integer diasDesdeConfirmacionFinal;
	private String puertoDescarga;
	private boolean aereo;
	private boolean pedidoDirecto;
	private BigDecimal backorderGenerado;
	private Integer idaMinimo;
	private HashSet<String> bus;

	public Integer getFolio() {
		return folio;
	}

	public void setFolio(Integer folio) {
		this.folio = folio;
	}

	public Integer getFechaEtd() {
		return fechaEtd;
	}

	public void setFechaEtd(Integer fechaEtd) {
		this.fechaEtd = fechaEtd;
	}

	public Integer getFechaEta() {
		return fechaEta;
	}

	public void setFechaEta(Integer fechaEta) {
		this.fechaEta = fechaEta;
	}

	public String getProveedor() {
		return proveedor;
	}

	public void setProveedor(String proveedor) {
		this.proveedor = proveedor;
	}

	public String getProveedorNombre() {
		return proveedorNombre;
	}

	public void setProveedorNombre(String proveedorNombre) {
		this.proveedorNombre = proveedorNombre;
	}

	public String getBooking() {
		return booking;
	}

	public void setBooking(String booking) {
		this.booking = booking;
	}

	public Integer getFechaConfirmacionFinal() {
		return fechaConfirmacionFinal;
	}

	public void setFechaConfirmacionFinal(Integer fechaConfirmacionFinal) {
		this.fechaConfirmacionFinal = fechaConfirmacionFinal;
	}

	public Integer getDiasDesdeConfirmacionFinal() {
		return diasDesdeConfirmacionFinal;
	}

	public void setDiasDesdeConfirmacionFinal(Integer diasDesdeConfirmacionFinal) {
		this.diasDesdeConfirmacionFinal = diasDesdeConfirmacionFinal;
	}

	public String getPuertoDescarga() {
		return puertoDescarga;
	}

	public void setPuertoDescarga(String puertoDescarga) {
		this.puertoDescarga = puertoDescarga;
	}

	public boolean isAereo() {
		return aereo;
	}

	public void setAereo(boolean aereo) {
		this.aereo = aereo;
	}

	public boolean isPedidoDirecto() {
		return pedidoDirecto;
	}

	public void setPedidoDirecto(boolean pedidoDirecto) {
		this.pedidoDirecto = pedidoDirecto;
	}

	public BigDecimal getBackorderGenerado() {
		return backorderGenerado;
	}

	public void setBackorderGenerado(BigDecimal backorderGenerado) {
		this.backorderGenerado = backorderGenerado;
	}

	public Integer getIdaMinimo() {
		return idaMinimo;
	}

	public void setIdaMinimo(Integer idaMinimo) {
		this.idaMinimo = idaMinimo;
	}

	public HashSet<String> getBus() {
		return bus;
	}

	public void setBus(HashSet<String> bus) {
		this.bus = bus;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (aereo ? 1231 : 1237);
		result = prime * result + ((backorderGenerado == null) ? 0 : backorderGenerado.hashCode());
		result = prime * result + ((booking == null) ? 0 : booking.hashCode());
		result = prime * result + ((diasDesdeConfirmacionFinal == null) ? 0 : diasDesdeConfirmacionFinal.hashCode());
		result = prime * result + ((fechaConfirmacionFinal == null) ? 0 : fechaConfirmacionFinal.hashCode());
		result = prime * result + ((fechaEta == null) ? 0 : fechaEta.hashCode());
		result = prime * result + ((fechaEtd == null) ? 0 : fechaEtd.hashCode());
		result = prime * result + ((folio == null) ? 0 : folio.hashCode());
		result = prime * result + ((idaMinimo == null) ? 0 : idaMinimo.hashCode());
		result = prime * result + (pedidoDirecto ? 1231 : 1237);
		result = prime * result + ((proveedor == null) ? 0 : proveedor.hashCode());
		result = prime * result + ((puertoDescarga == null) ? 0 : puertoDescarga.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BeanSarConfirmacionFinalSinDocumentos other = (BeanSarConfirmacionFinalSinDocumentos) obj;
		if (aereo != other.aereo)
			return false;
		if (backorderGenerado == null) {
			if (other.backorderGenerado != null)
				return false;
		} else if (!backorderGenerado.equals(other.backorderGenerado))
			return false;
		if (booking == null) {
			if (other.booking != null)
				return false;
		} else if (!booking.equals(other.booking))
			return false;
		if (diasDesdeConfirmacionFinal == null) {
			if (other.diasDesdeConfirmacionFinal != null)
				return false;
		} else if (!diasDesdeConfirmacionFinal.equals(other.diasDesdeConfirmacionFinal))
			return false;
		if (fechaConfirmacionFinal == null) {
			if (other.fechaConfirmacionFinal != null)
				return false;
		} else if (!fechaConfirmacionFinal.equals(other.fechaConfirmacionFinal))
			return false;
		if (fechaEta == null) {
			if (other.fechaEta != null)
				return false;
		} else if (!fechaEta.equals(other.fechaEta))
			return false;
		if (fechaEtd == null) {
			if (other.fechaEtd != null)
				return false;
		} else if (!fechaEtd.equals(other.fechaEtd))
			return false;
		if (folio == null) {
			if (other.folio != null)
				return false;
		} else if (!folio.equals(other.folio))
			return false;
		if (idaMinimo == null) {
			if (other.idaMinimo != null)
				return false;
		} else if (!idaMinimo.equals(other.idaMinimo))
			return false;
		if (pedidoDirecto != other.pedidoDirecto)
			return false;
		if (proveedor == null) {
			if (other.proveedor != null)
				return false;
		} else if (!proveedor.equals(other.proveedor))
			return false;
		if (puertoDescarga == null) {
			if (other.puertoDescarga != null)
				return false;
		} else if (!puertoDescarga.equals(other.puertoDescarga))
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("BeanSarConfirmacionFinalSinDocumentos [getFolio=");
		builder.append(getFolio());
		builder.append(", getFechaEtd=");
		builder.append(getFechaEtd());
		builder.append(", getFechaEta=");
		builder.append(getFechaEta());
		builder.append(", getProveedor=");
		builder.append(getProveedor());
		builder.append(", getProveedorNombre=");
		builder.append(getProveedorNombre());
		builder.append(", getBooking=");
		builder.append(getBooking());
		builder.append(", getFechaConfirmacionFinal=");
		builder.append(getFechaConfirmacionFinal());
		builder.append(", getDiasDesdeConfirmacionFinal=");
		builder.append(getDiasDesdeConfirmacionFinal());
		builder.append(", getPuertoDescarga=");
		builder.append(getPuertoDescarga());
		builder.append(", isAereo=");
		builder.append(isAereo());
		builder.append(", isPedidoDirecto=");
		builder.append(isPedidoDirecto());
		builder.append(", getBackorderGenerado=");
		builder.append(getBackorderGenerado());
		builder.append(", getIdaMinimo=");
		builder.append(getIdaMinimo());
		builder.append(", getBus=");
		builder.append(getBus());
		builder.append("]");
		return builder.toString();
	}

}
