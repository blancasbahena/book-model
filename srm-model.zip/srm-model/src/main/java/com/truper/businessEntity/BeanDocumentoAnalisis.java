package com.truper.businessEntity;

public class BeanDocumentoAnalisis {

	private String proveedor;
	private String booking;
	private int eta;
	private int folio;
	private String comentariosSdi;

	public String getProveedor() {
		return proveedor;
	}

	public void setProveedor(String proveedor) {
		this.proveedor = proveedor;
	}

	public String getBooking() {
		return booking;
	}

	public void setBooking(String booking) {
		this.booking = booking;
	}

	public int getEta() {
		return eta;
	}

	public void setEta(int eta) {
		this.eta = eta;
	}

	public int getFolio() {
		return folio;
	}

	public void setFolio(int folio) {
		this.folio = folio;
	}

	public String getComentariosSdi() {
		return comentariosSdi;
	}

	public void setComentariosSdi(String comentariosSdi) {
		this.comentariosSdi = comentariosSdi;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("BeanDocumentoAnalisis [getProveedor=");
		builder.append(getProveedor());
		builder.append(", getBooking=");
		builder.append(getBooking());
		builder.append(", getEta=");
		builder.append(getEta());
		builder.append(", getFolio=");
		builder.append(getFolio());
		builder.append(", getComentariosSdi=");
		builder.append(getComentariosSdi());
		builder.append("]");
		return builder.toString();
	}

}