package com.truper.businessEntity;

import java.math.BigDecimal;
import java.util.HashSet;

public class BeanDatosTel {

	private Integer folio;
	private Integer idaMinimo;
	private BigDecimal backorderAlArribo;
	private HashSet<String> bus;

	public Integer getFolio() {
		return folio;
	}

	public void setFolio(Integer folio) {
		this.folio = folio;
	}

	public Integer getIdaMinimo() {
		return idaMinimo;
	}

	public void setIdaMinimo(Integer idaMinimo) {
		this.idaMinimo = idaMinimo;
	}

	public BigDecimal getBackorderAlArribo() {
		return backorderAlArribo;
	}

	public void setBackorderAlArribo(BigDecimal backorderAlArribo) {
		this.backorderAlArribo = backorderAlArribo;
	}

	public HashSet<String> getBus() {
		return bus;
	}

	public void setBus(HashSet<String> bus) {
		this.bus = bus;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((backorderAlArribo == null) ? 0 : backorderAlArribo.hashCode());
		result = prime * result + ((folio == null) ? 0 : folio.hashCode());
		result = prime * result + ((idaMinimo == null) ? 0 : idaMinimo.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BeanDatosTel other = (BeanDatosTel) obj;
		if (backorderAlArribo == null) {
			if (other.backorderAlArribo != null)
				return false;
		} else if (!backorderAlArribo.equals(other.backorderAlArribo))
			return false;
		if (folio == null) {
			if (other.folio != null)
				return false;
		} else if (!folio.equals(other.folio))
			return false;
		if (idaMinimo == null) {
			if (other.idaMinimo != null)
				return false;
		} else if (!idaMinimo.equals(other.idaMinimo))
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("BeanDatosTel [getFolio=");
		builder.append(getFolio());
		builder.append(", getIdaMinimo=");
		builder.append(getIdaMinimo());
		builder.append(", getBackorderAlArribo=");
		builder.append(getBackorderAlArribo());
		builder.append(", getBus=");
		builder.append(getBus());
		builder.append("]");
		return builder.toString();
	}

}
