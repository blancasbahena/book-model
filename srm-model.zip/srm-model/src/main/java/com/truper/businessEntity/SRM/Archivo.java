package com.truper.businessEntity.SRM;

import java.io.File;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Table;

import com.truper.infra.businessEntities.BaseBusinessEntity;

@Entity
@Table(name = "SRM_ARCHIVO")
public class Archivo extends BaseBusinessEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2883249585708234835L;

	@Id
	@Column(name = "ID", updatable = false, unique = true, insertable = false)
	private Integer id;
	@Column(name = "FECHA")
	private Date fecha;
	@Column(name = "ID_USUARIO")
	private Integer idUsuario;
	@Column(name = "RUTA_ARCHIVO")
	private String rutaArchivo;
	@Column(name = "NOMBRE_ARCHIVO")
	private String nombreArchivo;
	@Column(name = "ID_TIPO_ARCHIVO")
	private Integer idTipoArchivo;
	@Column(name = "ELIMINADO")
	private Boolean eliminado;
	@Column(name = "ID_USUARIO_ELIMINO")
	private Integer idUsuarioElimino;
	@JoinColumn(table = "srm_cat_tipo_documento", name = "ID_TIPO_ARCHIVO", referencedColumnName = "ID")
	private CatTipoDocumento tipoDocumento;
	private transient File file;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Date getFecha() {
		return fecha;
	}

	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}

	public Integer getIdUsuario() {
		return idUsuario;
	}

	public void setIdUsuario(Integer idUsuario) {
		this.idUsuario = idUsuario;
	}

	public String getRutaArchivo() {
		return rutaArchivo;
	}

	public void setRutaArchivo(String rutaArchivo) {
		this.rutaArchivo = rutaArchivo;
	}

	public Integer getIdTipoArchivo() {
		return idTipoArchivo;
	}

	public void setIdTipoArchivo(Integer idTipoArchivo) {
		this.idTipoArchivo = idTipoArchivo;
	}

	public Boolean getEliminado() {
		return eliminado;
	}

	public void setEliminado(Boolean eliminado) {
		this.eliminado = eliminado;
	}

	public Integer getIdUsuarioElimino() {
		return idUsuarioElimino;
	}

	public void setIdUsuarioElimino(Integer idUsuarioElimino) {
		this.idUsuarioElimino = idUsuarioElimino;
	}

	public CatTipoDocumento getTipoDocumento() {
		return tipoDocumento;
	}

	public void setTipoDocumento(CatTipoDocumento tipoDocumento) {
		this.tipoDocumento = tipoDocumento;
	}

	public File getFile() {
		return file;
	}

	public void setFile(File file) {
		this.file = file;
	}

	public String getNombreArchivo() {
		return nombreArchivo;
	}

	public void setNombreArchivo(String nombreArchivo) {
		this.nombreArchivo = nombreArchivo;
	}
}
