package com.truper.businessEntity;

import com.truper.infra.businessEntities.BaseBusinessEntity;

public class CompradoresBean extends BaseBusinessEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7581714564053205655L;
	private String unidadNegocio;
	private String nombre;
	private String correo;
	
	public String getUnidadNegocio() {
		return unidadNegocio;
	}
	public void setUnidadNegocio(String unidadNegocio) {
		this.unidadNegocio = unidadNegocio;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getCorreo() {
		return correo;
	}
	public void setCorreo(String correo) {
		this.correo = correo;
	}
}
