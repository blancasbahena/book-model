package com.truper.businessEntity;

import java.util.Date;

import com.truper.infra.businessEntities.BaseBusinessEntity;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@ToString
@Getter
@Setter
public class SARHistoryLogBean extends BaseBusinessEntity {

	private static final long serialVersionUID = 1L;
	private Integer folio;
	private String foliosInConsol;
	private String supplier;
	private Integer action;
	private String sarType;
	private Integer modificationDate;
	private Long modificationTimeStamp;
	private String userName;
	private Integer etd;
	private Integer eta;
	private String shippingPort;
	private String portOfDischarge;
	private Integer carrier;
	private Integer destinationCountry;
	private Integer delayType;
	private String vessel;
	private String voyage;
	private String booking;
	private String bl;
	private Integer containerType;
	private String containerNumber;
	private Integer priority;
	private Integer groundTransportation;
	private Boolean sarLocked;
	private Integer consolidatedFolio;
	private String comments;
	private Boolean esDirecto;
	private Integer fechaIni;
	private Integer fechaFin;
	private Date createDate;
	private String referenciaContenedorProveedor;
	private String commentProfiles;
	
}
