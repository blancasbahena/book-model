package com.truper.businessEntity;

import java.util.Date;

import com.truper.bpm.enums.StatusControlMatricesEnum;

public class BeanAuditoriaMatriz extends BeanControlPrecios {

	private StatusControlMatricesEnum estatus;
	private Date createDate;
	private String comentarios;

	public StatusControlMatricesEnum getEstatus() {
		return estatus;
	}

	public void setEstatus(StatusControlMatricesEnum estatus) {
		this.estatus = estatus;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public String getComentarios() {
		return comentarios;
	}

	public void setComentarios(String comentarios) {
		this.comentarios = comentarios;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("BeanAuditoriaMatriz [getEstatus=");
		builder.append(getEstatus());
		builder.append(", getCreateDate=");
		builder.append(getCreateDate());
		builder.append(", getComentarios=");
		builder.append(getComentarios());
		builder.append(", toString=");
		builder.append(super.toString());
		builder.append("]");
		return builder.toString();
	}

}
