package com.truper.businessEntity;

import com.truper.infra.businessEntities.BaseBusinessEntity;

public class ImportacionesProveedoresBean extends BaseBusinessEntity {

	private static final long serialVersionUID = 6624716272423813114L;

	private String claveProveedor;
	private String nombreProveedor;
	private String poblacion;
	private String distrito;
	private String codigoPostal;
	private String region;
	private String pais;
	private String telefono1;
	private String telefono2;
	private String email;
	private String calificacion;
	private String contacto;
	private String mailContacto1;
	private String mailContacto2;
	private String mailContacto3;
	private String rfc;
	private String taxId;
	private String Incotetm_cve;
	private String Incotetm_def;
	private String monedaPorveedor;
	private String condicionesPago;
	private String calleNumero;
	private boolean bloqueado;

	public String getClaveProveedor() {
		return claveProveedor;
	}

	public void setClaveProveedor(String claveProveedor) {
		this.claveProveedor = claveProveedor;
	}

	public String getNombreProveedor() {
		return nombreProveedor;
	}

	public void setNombreProveedor(String nombreProveedor) {
		this.nombreProveedor = nombreProveedor;
	}

	public String getPoblacion() {
		return poblacion;
	}

	public void setPoblacion(String poblacion) {
		this.poblacion = poblacion;
	}

	public String getDistrito() {
		return distrito;
	}

	public void setDistrito(String distrito) {
		this.distrito = distrito;
	}

	public String getCodigoPostal() {
		return codigoPostal;
	}

	public void setCodigoPostal(String codigoPostal) {
		this.codigoPostal = codigoPostal;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getPais() {
		return pais;
	}

	public void setPais(String pais) {
		this.pais = pais;
	}

	public String getTelefono1() {
		return telefono1;
	}

	public void setTelefono1(String telefono1) {
		this.telefono1 = telefono1;
	}

	public String getTelefono2() {
		return telefono2;
	}

	public void setTelefono2(String telefono2) {
		this.telefono2 = telefono2;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getCalificacion() {
		return calificacion;
	}

	public void setCalificacion(String calificacion) {
		this.calificacion = calificacion;
	}

	public String getContacto() {
		return contacto;
	}

	public void setContacto(String contacto) {
		this.contacto = contacto;
	}

	public String getMailContacto1() {
		return mailContacto1;
	}

	public void setMailContacto1(String mailContacto1) {
		this.mailContacto1 = mailContacto1;
	}

	public String getMailContacto2() {
		return mailContacto2;
	}

	public void setMailContacto2(String mailContacto2) {
		this.mailContacto2 = mailContacto2;
	}

	public String getMailContacto3() {
		return mailContacto3;
	}

	public void setMailContacto3(String mailContacto3) {
		this.mailContacto3 = mailContacto3;
	}

	public String getRfc() {
		return rfc;
	}

	public void setRfc(String rfc) {
		this.rfc = rfc;
	}

	public String getTaxId() {
		return taxId;
	}

	public void setTaxId(String taxId) {
		this.taxId = taxId;
	}

	public String getIncotetm_cve() {
		return Incotetm_cve;
	}

	public void setIncotetm_cve(String incotetm_cve) {
		Incotetm_cve = incotetm_cve;
	}

	public String getIncotetm_def() {
		return Incotetm_def;
	}

	public void setIncotetm_def(String incotetm_def) {
		Incotetm_def = incotetm_def;
	}

	public String getMonedaPorveedor() {
		return monedaPorveedor;
	}

	public void setMonedaPorveedor(String monedaPorveedor) {
		this.monedaPorveedor = monedaPorveedor;
	}

	public String getCondicionesPago() {
		return condicionesPago;
	}

	public void setCondicionesPago(String condicionesPago) {
		this.condicionesPago = condicionesPago;
	}

	public String getCalleNumero() {
		return calleNumero;
	}

	public void setCalleNumero(String calleNumero) {
		this.calleNumero = calleNumero;
	}

	public boolean isBloqueado() {
		return bloqueado;
	}

	public void setBloqueado(boolean bloqueado) {
		this.bloqueado = bloqueado;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("ImportacionesProveedoresBean [claveProveedor=").append(claveProveedor)
				.append(", nombreProveedor=").append(nombreProveedor).append(", poblacion=").append(poblacion)
				.append(", distrito=").append(distrito).append(", codigoPostal=").append(codigoPostal)
				.append(", region=").append(region).append(", pais=").append(pais).append(", telefono1=")
				.append(telefono1).append(", telefono2=").append(telefono2).append(", email=").append(email)
				.append(", calificacion=").append(calificacion).append(", contacto=").append(contacto)
				.append(", mailContacto1=").append(mailContacto1).append(", mailContacto2=").append(mailContacto2)
				.append(", mailContacto3=").append(mailContacto3).append(", rfc=").append(rfc).append(", taxId=")
				.append(taxId).append(", Incotetm_cve=").append(Incotetm_cve).append(", Incotetm_def=")
				.append(Incotetm_def).append(", monedaPorveedor=").append(monedaPorveedor).append(", condicionesPago=")
				.append(condicionesPago).append(", calleNumero=").append(calleNumero).append(", bloqueado=")
				.append(bloqueado).append("]");
		return builder.toString();
	}
}
