package com.truper.businessEntity;

import java.util.Date;

import com.truper.bpm.enums.EstatusAuditoriaEnum;

public class BeanAuditoria extends BeanControlPrecios {

	private Integer id;
	private EstatusAuditoriaEnum estatus;
	private Date createDate;
	private String comentarios;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public EstatusAuditoriaEnum getEstatus() {
		return estatus;
	}

	public void setEstatus(EstatusAuditoriaEnum estatus) {
		this.estatus = estatus;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public String getComentarios() {
		return comentarios;
	}

	public void setComentarios(String comentarios) {
		this.comentarios = comentarios;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("BeanAuditoria [getId=");
		builder.append(getId());
		builder.append(", getEstatus=");
		builder.append(getEstatus());
		builder.append(", getCreateDate=");
		builder.append(getCreateDate());
		builder.append(", getComentarios=");
		builder.append(getComentarios());
		builder.append(", toString=");
		builder.append(super.toString());
		builder.append("]");
		return builder.toString();
	}

}
