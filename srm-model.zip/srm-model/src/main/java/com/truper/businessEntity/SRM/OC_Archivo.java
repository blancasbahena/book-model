package com.truper.businessEntity.SRM;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.truper.infra.businessEntities.BaseBusinessEntity;

@Entity
@Table(name = "srm_OC_ARCHIVO")
public class OC_Archivo extends BaseBusinessEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 13718689477839415L;

	@Column(name = "ID_ARCHIVO")
	private Integer idArchivo;

	@Column(name = "ID_ORDEN_DE_COMPRA")
	private Integer idOrdeDeCompra;

	@Column(name = "ID_INSTANCE_TRACKER")
	private Integer idInstanceTracker;

	@Column(name = "PROVEEDOR")
	private boolean proveedor;

	@Column(name = "PROVEEDOR_PUEDE_VER")
	private Boolean proveedorPuedeVer;

	public Integer getIdArchivo() {
		return idArchivo;
	}

	public void setIdArchivo(Integer idArchivo) {
		this.idArchivo = idArchivo;
	}

	public Integer getIdOrdeDeCompra() {
		return idOrdeDeCompra;
	}

	public void setIdOrdeDeCompra(Integer idOrdeDeCompra) {
		this.idOrdeDeCompra = idOrdeDeCompra;
	}

	public Integer getIdInstanceTracker() {
		return idInstanceTracker;
	}

	public void setIdInstanceTracker(Integer idInstanceTracker) {
		this.idInstanceTracker = idInstanceTracker;
	}

	public boolean isProveedor() {
		return proveedor;
	}

	public void setProveedor(boolean proveedor) {
		this.proveedor = proveedor;
	}

	public Boolean isProveedorPuedeVer() {
		return proveedorPuedeVer;
	}

	public void setProveedorPuedeVer(Boolean proveedorPuedeVer) {
		this.proveedorPuedeVer = proveedorPuedeVer;
	}

}
