package com.truper.businessEntity;

public class BeanPedidoDirecto {

	private String puertoDescarga;
	private boolean pedidoDirecto;
	private boolean aereo;

	public String getPuertoDescarga() {
		return puertoDescarga;
	}

	public void setPuertoDescarga(String puertoDescarga) {
		this.puertoDescarga = puertoDescarga;
	}

	public boolean isPedidoDirecto() {
		return pedidoDirecto;
	}

	public void setPedidoDirecto(boolean pedidoDirecto) {
		this.pedidoDirecto = pedidoDirecto;
	}

	public boolean isAereo() {
		return aereo;
	}

	public void setAereo(boolean aereo) {
		this.aereo = aereo;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("BeanPedidoDirecto [getPuertoDescarga=");
		builder.append(getPuertoDescarga());
		builder.append(", isPedidoDirecto=");
		builder.append(isPedidoDirecto());
		builder.append(", isAereo=");
		builder.append(isAereo());
		builder.append("]");
		return builder.toString();
	}

}