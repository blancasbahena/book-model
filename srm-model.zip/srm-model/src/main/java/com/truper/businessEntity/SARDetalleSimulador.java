package com.truper.businessEntity;


import java.math.BigDecimal;

import com.truper.infra.businessEntities.BaseBusinessEntity;

public class SARDetalleSimulador extends BaseBusinessEntity{
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -6279338029537060007L;
	//Datos que hay en tabla
	private Integer folio;
	private Integer posicion;
	private Integer material;
	private Integer cantidad;
	private Integer fechaProforma;
	private Integer paisOrigen;
	
	private Double pesoProveedor;
	private Double volumenProveedor;
	private Double pesoPO;
	private Double volumenPO;
	private Double precioUnitario = 0.0;
	private Double precioUnitarioPO = 0.0;
	private Double overStock 		= 0.0;
	private String overStockFormato;
	
	private String po;
	private String centro;
	private String planeador;
	private String cliente;
	
	private Integer cantidadModificada;
	private Double pesoModificado;
	private Double volumenModificado;
	
	private Integer cantidad100;
	private Double peso100;
	private Double volumen100;
	
	private String unidaMedida;
	private String condicionPago;
	private String moneda;
	
	//Datos especiales para packing list
	private Integer cartones;
	private Integer cantidadXCarton;
	private BigDecimal pesoNetoPKL;
	private BigDecimal pesoBrutoPKL;
	private BigDecimal cubicajePKL;
	private Integer pallet;
	private Integer cartonXPallet;
	private Double safetyStock;
	private Double daysSafetyStock;
	private Double var8Semanas;
	private Double var8SemanasDirectos;
	private Integer facturacionPedidosDirectos;
	
	
	//Datos que se cargan pero no estan en tablas
	private String	 	descripcion;
	private Integer		diasAlArribo;
	private BigDecimal	backorderPronosticado;
	private String		backorderPronosticadoFormato;
	private Integer		picoInventarioDeseado;
	private BigDecimal	valorEmbarque;
	private BigDecimal	acumulado;
	private BigDecimal	costoFOB;
	private BigDecimal	difDiasConfirm;
	private Integer		difDiasPIvsETD;
	private Integer		inventaroAlArribo;
	private BigDecimal	difVSPico;
	private Double		difPesoUserVSSistem;
	private String		numeroDoc;
	
	private Double		difVolumenUserVSSistem;
	private int fechaUltConfirm;
	private int diasRetraso;
	private int fechaEtdProveedor;

	
	private boolean pedidoDirecto;
	private boolean noEsPOCompleta;//Es en 1 cuando esta dentro del 90/110%
	private int cantidadTotalPO; 
	private boolean tieneDiferenciasMRP;
	private Integer statusMRP;
	private Integer tipoValidacionMRP;
	private String tipoPron;
	private Integer tipoModificacion;
	private boolean balanceAction;
	private String usuarioCreaSimulador;
	private Integer fechaCreaSimulador;
	private boolean alerta;
	private Integer etdNuevo;
	private Integer etdOriginal;
	private Integer etdTEL;
	
	public SARDetalleSimulador(int folio, String po, int posicion, Integer material, int cantidad, String centro,String planeador,String cliente){
		this.folio = folio;
		this.po = po;
		this.posicion = posicion;
		this.material = material;
		this.cantidad = cantidad;
		this.centro = centro;
		this.planeador = planeador;
		this.cliente  = cliente;
	}
	
	public SARDetalleSimulador(){}
	
	public Double getPesoParaMostrar(){
		if(pesoProveedor != null){
			return pesoProveedor;
		}else{
			return pesoPO;
		}
	}
	
	public Double getVolumenParaMostrar(){
		if(volumenProveedor != null){
			return volumenProveedor;
		}else{
			return volumenPO;
		}
	}
	
	/**GETTERS & SETTERS **/
	
	public Integer getFolio() {
		return folio;
	}
	public String getUsuarioCreaSimulador() {
		return usuarioCreaSimulador;
	}
	public void setUsuarioCreaSimulador(String usuarioCreaSimulador) {
		this.usuarioCreaSimulador = usuarioCreaSimulador;
	}
	public Integer getFechaCreaSimulador() {
		return fechaCreaSimulador;
	}
	public void setFechaCreaSimulador(Integer fechaCreaSimulador) {
		this.fechaCreaSimulador = fechaCreaSimulador;
	}
	public void setFolio(Integer folio) {
		this.folio = folio;
	}
	public Integer getPosicion() {
		return posicion;
	}
	public void setPosicion(Integer posicion) {
		this.posicion = posicion;
	}
	public Integer getMaterial() {
		return material;
	}
	public void setMaterial(Integer material) {
		this.material = material;
	}
	public Integer getCantidad() {
		return cantidad;
	}
	public void setCantidad(Integer cantidad) {
		this.cantidad = cantidad;
	}
	
	public Integer getFechaProforma() {
		return fechaProforma;
	}

	public void setFechaProforma(Integer fechaProforma) {
		this.fechaProforma = fechaProforma;
	}

	public Double getPesoProveedor() {
		return pesoProveedor;
	}
	public void setPesoProveedor(Double pesoProveedor) {
		this.pesoProveedor = pesoProveedor;
	}
	public Double getVolumenProveedor() {
		return volumenProveedor;
	}
	public void setVolumenProveedor(Double volumenProveedor) {
		this.volumenProveedor = volumenProveedor;
	}
	public Double getPesoPO(){
		return pesoPO;
	}
	public void setPesoPO(Double pesoPO){
		this.pesoPO = pesoPO;
	}
	public Double getVolumenPO(){
		return volumenPO;
	}
	public void setVolumenPO(Double volumenPO){
		this.volumenPO = volumenPO;
	}
	public String getPo() {
		return po;
	}
	public void setPo(String po) {
		this.po = po;
	}
	public String getCentro() {
		return centro;
	}
	public void setCentro(String centro) {
		this.centro = centro;
	}
	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	public Integer getDiasAlArribo() {
		return diasAlArribo;
	}
	public void setDiasAlArribo(Integer diasAlArribo) {
		this.diasAlArribo = diasAlArribo;
	}
	public BigDecimal getBackorderPronosticado() {
		return backorderPronosticado;
	}
	public void setBackorderPronosticado(BigDecimal backorderPronosticado) {
		this.backorderPronosticado = backorderPronosticado;
	}
	public BigDecimal getValorEmbarque() {
		return valorEmbarque;
	}
	public void setValorEmbarque(BigDecimal valorEmbarque) {
		this.valorEmbarque = valorEmbarque;
	}
	public BigDecimal getAcumulado() {
		return acumulado;
	}
	public void setAcumulado(BigDecimal acumulado) {
		this.acumulado = acumulado;
	}
	public BigDecimal getCostoFOB() {
		return costoFOB;
	}
	public void setCostoFOB(BigDecimal costoFOB) {
		this.costoFOB = costoFOB;
	}
	public BigDecimal getDifDiasConfirm() {
		return difDiasConfirm;
	}
	public void setDifDiasConfirm(BigDecimal difDiasConfirm) {
		this.difDiasConfirm = difDiasConfirm;
	}
	public Integer getPicoInventarioDeseado() {
		return picoInventarioDeseado;
	}
	public void setPicoInventarioDeseado(Integer picoInventarioDeseado) {
		this.picoInventarioDeseado = picoInventarioDeseado;
	}
	public Integer getInventaroAlArribo() {
		return inventaroAlArribo;
	}
	public void setInventaroAlArribo(Integer inventaroAlArribo) {
		this.inventaroAlArribo = inventaroAlArribo;
	}
	public BigDecimal getDifVSPico() {
		return difVSPico;
	}
	public void setDifVSPico(BigDecimal difVSPico) {
		this.difVSPico = difVSPico;
	}
	public Double getDifPesoUserVSSistem() {		
		return difPesoUserVSSistem;
	}
	public void setDifPesoUserVSSistem(Double difPesoUserVSSistem) {
		this.difPesoUserVSSistem = difPesoUserVSSistem;
	}
	public Double getDifVolumenUserVSSistem() {
		return difVolumenUserVSSistem;
	}
	public void setDifVolumenUserVSSistem(Double difVolumenUserVSSistem) {
		this.difVolumenUserVSSistem = difVolumenUserVSSistem;
	}
	public Double getPrecioUnitario() {
		return precioUnitario;
	}
	public void setPrecioUnitario(Double precioUnitario) {
		this.precioUnitario = precioUnitario;
	}
	public Double getPrecioUnitarioPO() {
		return precioUnitarioPO;
	}
	public void setPrecioUnitarioPO(Double precioUnitarioPO) {
		this.precioUnitarioPO = precioUnitarioPO;
	}

	public void addCPV(int cantidad, double pesoProveedor, double volumenProveedor) {
		this.cantidad += cantidad;
		this.pesoProveedor += pesoProveedor;
		this.volumenProveedor += volumenProveedor;
	}


	public boolean esDiferenciaPreciosAFavor(){
		return precioUnitario <= precioUnitarioPO;
	}

	public String getPlaneador() {
		return planeador;
	}

	public void setPlaneador(String planeador) {
		this.planeador = planeador;
	}

	public Integer getCantidadModificada() {
		return cantidadModificada;
	}

	public void setCantidadModificada(Integer cantidadModificada) {
		this.cantidadModificada = cantidadModificada;
	}

	public Double getPesoModificado() {
		return pesoModificado;
	}

	public void setPesoModificado(Double pesoModificado) {
		this.pesoModificado = pesoModificado;
	}

	public Double getVolumenModificado() {
		return volumenModificado;
	}

	public void setVolumenModificado(Double volumenModificado) {
		this.volumenModificado = volumenModificado;
	}

	public Integer getCantidad100() {
		return cantidad100;
	}

	public void setCantidad100(Integer cantidad100) {
		this.cantidad100 = cantidad100;
	}

	public Double getPeso100() {
		return peso100;
	}

	public void setPeso100(Double peso100) {
		this.peso100 = peso100;
	}

	public Double getVolumen100() {
		return volumen100;
	}

	public void setVolumen100(Double volumen100) {
		this.volumen100 = volumen100;
	}

	public String getCliente() {
		return cliente;
	}

	public void setCliente(String cliente) {
		this.cliente = cliente;
	}

	public Integer getPaisOrigen() {
		return paisOrigen;
	}

	public void setPaisOrigen(Integer paisOrigen) {
		this.paisOrigen = paisOrigen;
	}

	public String getNumeroDoc() {
		return numeroDoc;
	}

	public void setNumeroDoc(String numeroDoc) {
		this.numeroDoc = numeroDoc;
	}
	
	public BigDecimal getPesoNetoPKL() {
		return pesoNetoPKL;
	}

	public void setPesoNetoPKL(BigDecimal pesoNetoPKL) {
		this.pesoNetoPKL = pesoNetoPKL;
	}

	public BigDecimal getPesoBrutoPKL() {
		return pesoBrutoPKL;
	}

	public void setPesoBrutoPKL(BigDecimal pesoBrutoPKL) {
		this.pesoBrutoPKL = pesoBrutoPKL;
	}

	public BigDecimal getCubicajePKL() {
		return cubicajePKL;
	}

	public void setCubicajePKL(BigDecimal cubicajePKL) {
		this.cubicajePKL = cubicajePKL;
	}

	public Integer getCartones() {
		return cartones;
	}

	public void setCartones(Integer cartones) {
		this.cartones = cartones;
	}

	public Integer getCantidadXCarton() {
		return cantidadXCarton;
	}

	public void setCantidadXCarton(Integer cantidadXCarton) {
		this.cantidadXCarton = cantidadXCarton;
	}

	public Integer getPallet() {
		return pallet;
	}
	public void setPallet(Integer pallet) {
		this.pallet = pallet;
	}
	public Integer getCartonXPallet() {
		return cartonXPallet;
	}
	public void setCartonXPallet(Integer cartonXPallet) {
		this.cartonXPallet = cartonXPallet;
	}
	public String getUnidaMedida() {
		return unidaMedida;
	}
	public void setUnidaMedida(String unidaMedida) {
		this.unidaMedida = unidaMedida;
	}
	public String getCondicionPago() {
		return condicionPago;
	}
	public void setCondicionPago(String condicionPago) {
		this.condicionPago = condicionPago;
	}
	public String getMoneda() {
		return moneda;
	}
	public void setMoneda(String moneda) {
		this.moneda = moneda;
	}

	public boolean isPedidoDirecto() {
		return pedidoDirecto;
	}

	public void setPedidoDirecto(boolean pedidoDirecto) {
		this.pedidoDirecto = pedidoDirecto;
	}
	
	public int getFechaUltConfirm() {
		return fechaUltConfirm;
	}

	public void setFechaUltConfirm(int fechaUltConfirm) {
		this.fechaUltConfirm = fechaUltConfirm;
	}

	public int getDiasRetraso() {
		return diasRetraso;
	}

	public void setDiasRetraso(int diasRetraso) {
		this.diasRetraso = diasRetraso;
	}

	public int getFechaEtdProveedor() {
		return fechaEtdProveedor;
	}

	public void setFechaEtdProveedor(int fechaEtdProveedor) {
		this.fechaEtdProveedor = fechaEtdProveedor;
	}

	public Double getOverStock() {
		return overStock;
	}

	public void setOverStock(Double overStock) {
		this.overStock = overStock;
	}

	public boolean isNoEsPOCompleta() {
		return noEsPOCompleta;
	}

	public void setNoEsPOCompleta(boolean noEsPOCompleta) {
		this.noEsPOCompleta = noEsPOCompleta;
	}

	public int getCantidadTotalPO() {
		return cantidadTotalPO;
	}

	public void setCantidadTotalPO(int cantidadTotalPO) {
		this.cantidadTotalPO = cantidadTotalPO;
	}

	/**
	 * @return the safetyStock
	 */
	public Double getSafetyStock() {
		return safetyStock;
	}

	/**
	 * @param safetyStock the safetyStock to set
	 */
	public void setSafetyStock(Double safetyStock) {
		this.safetyStock = safetyStock;
	}

	/**
	 * @return the daysSafetyStock
	 */
	public Double getDaysSafetyStock() {
		return daysSafetyStock;
	}

	/**
	 * @param daysSafetyStock the daysSafetyStock to set
	 */
	public void setDaysSafetyStock(Double daysSafetyStock) {
		this.daysSafetyStock = daysSafetyStock;
	}

	/**
	 * @return the var8Semanas
	 */
	public Double getVar8Semanas() {
		return var8Semanas;
	}

	/**
	 * @param var8Semanas the var8Semanas to set
	 */
	public void setVar8Semanas(Double var8Semanas) {
		this.var8Semanas = var8Semanas;
	}

	public Double getVar8SemanasDirectos() {
		return var8SemanasDirectos;
	}

	public void setVar8SemanasDirectos(Double var8SemanasDirectos) {
		this.var8SemanasDirectos = var8SemanasDirectos;
	}

	public Integer getFacturacionPedidosDirectos() {
		return facturacionPedidosDirectos;
	}

	public void setFacturacionPedidosDirectos(Integer facturacionPedidosDirectos) {
		this.facturacionPedidosDirectos = facturacionPedidosDirectos;
	}

	/**
	 * @return the difDiasPIvsETD
	 */
	public Integer getDifDiasPIvsETD() {
		return difDiasPIvsETD;
	}

	/**
	 * @param difDiasPIvsETD the difDiasPIvsETD to set
	 */
	public void setDifDiasPIvsETD(Integer difDiasPIvsETD) {
		this.difDiasPIvsETD = difDiasPIvsETD;
	}

	public boolean isTieneDiferenciasMRP() {
		return tieneDiferenciasMRP;
	}

	public void setTieneDiferenciasMRP(boolean tieneDiferenciasMRP) {
		this.tieneDiferenciasMRP = tieneDiferenciasMRP;
	}

	public Integer getStatusMRP() {
		return statusMRP;
	}

	public void setStatusMRP(Integer statusMRP) {
		this.statusMRP = statusMRP;
	}

	/**
	 * @return the tipoValidacionMRP
	 */
	public Integer getTipoValidacionMRP() {
		return tipoValidacionMRP;
	}

	/**
	 * @param tipoValidacionMRP the tipoValidacionMRP to set
	 */
	public void setTipoValidacionMRP(Integer tipoValidacionMRP) {
		this.tipoValidacionMRP = tipoValidacionMRP;
	}

	public String getTipoPron() {
		return tipoPron;
	}

	public void setTipoPron(String tipoPron) {
		this.tipoPron = tipoPron;
	}

	public Integer getTipoModificacion() {
		return tipoModificacion;
	}

	public void setTipoModificacion(Integer tipoModificacion) {
		this.tipoModificacion = tipoModificacion;
	}

	public boolean isBalanceAction() {
		return balanceAction;
	}

	public void setBalanceAction(boolean balanceAction) {
		this.balanceAction = balanceAction;
	}

	public boolean isAlerta() {
		return alerta;
	}

	public void setAlerta(boolean alerta) {
		this.alerta = alerta;
	}

	public Integer getEtdNuevo() {
		return etdNuevo;
	}

	public void setEtdNuevo(Integer etdNuevo) {
		this.etdNuevo = etdNuevo;
	}

	public Integer getEtdOriginal() {
		return etdOriginal;
	}

	public void setEtdOriginal(Integer etdOriginal) {
		this.etdOriginal = etdOriginal;
	}

	public String getOverStockFormato() {
		return overStockFormato;
	}

	public void setOverStockFormato(String overStockFormato) {
		this.overStockFormato = overStockFormato;
	}

	public String getBackorderPronosticadoFormato() {
		return backorderPronosticadoFormato;
	}

	public void setBackorderPronosticadoFormato(String backorderPronosticadoFormato) {
		this.backorderPronosticadoFormato = backorderPronosticadoFormato;
	}

	public Integer getEtdTEL() {
		return etdTEL;
	}

	public void setEtdTEL(Integer etdTEL) {
		this.etdTEL = etdTEL;
	}

	
}
