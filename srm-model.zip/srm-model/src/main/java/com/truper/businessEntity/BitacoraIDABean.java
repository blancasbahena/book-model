package com.truper.businessEntity;


import com.truper.infra.businessEntities.BaseBusinessEntity;

public class BitacoraIDABean extends BaseBusinessEntity {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int folio;
	private int folioCC;
	private String comentario;
	private String userName;
	private String fechaCreacion;
	private boolean local;
	
	
	public int getFolio() {
		return folio;
	}
	public void setFolio(int folio) {
		this.folio = folio;
	}
	public String getComentario() {
		return comentario;
	}
	public void setComentario(String comentario) {
		this.comentario = comentario;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getFechaCreacion() {
		return fechaCreacion;
	}
	public void setFechaCreacion(String fechaCreacion) {
		this.fechaCreacion = fechaCreacion;
	}
	public int getFolioCC() {
		return folioCC;
	}
	public void setFolioCC(int folioCC) {
		this.folioCC = folioCC;
	}
	public boolean isLocal() {
		return local;
	}
	public void setLocal(boolean local) {
		this.local = local;
	}
	
}
