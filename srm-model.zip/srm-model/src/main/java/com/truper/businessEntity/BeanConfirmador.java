package com.truper.businessEntity;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class BeanConfirmador implements Serializable {

	private static final long serialVersionUID = -3954753750762470665L;
	private String usuario;
	private String correo;

}
