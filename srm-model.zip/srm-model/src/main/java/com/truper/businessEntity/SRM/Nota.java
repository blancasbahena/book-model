package com.truper.businessEntity.SRM;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.truper.infra.businessEntities.BaseBusinessEntity;

@Entity
@Table(name = "srm_NOTA")
public class Nota extends BaseBusinessEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1602550122980617941L;

	@Id
	@Column(name = "ID", updatable = false, unique = true, insertable = false)
	private Integer id;
	@Column(name = "FECHA")
	private Date fecha;
	@Column(name = "ID_USUARIO")
	private Integer idUsuario;
	@Column(name = "NOTA")
	private String nota;
	@Column(name = "ID_TIPO_NOTA")
	private Integer idTipoNota;

	private transient OrdenDeCompra ordenDeCompra;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Date getFecha() {
		return fecha;
	}

	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}

	public Integer getIdUsuario() {
		return idUsuario;
	}

	public void setIdUsuario(Integer idUsuario) {
		this.idUsuario = idUsuario;
	}

	public String getNota() {
		return nota;
	}

	public void setNota(String nota) {
		this.nota = nota;
	}

	public Integer getIdTipoNota() {
		return idTipoNota;
	}

	public void setIdTipoNota(Integer idTipoNota) {
		this.idTipoNota = idTipoNota;
	}

	public OrdenDeCompra getOrdenDeCompra() {
		return ordenDeCompra;
	}

	public void setOrdenDeCompra(OrdenDeCompra ordenDeCompra) {
		this.ordenDeCompra = ordenDeCompra;
	}

}
