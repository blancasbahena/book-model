package com.truper.businessEntity;

public class UsuarioBean extends UserProfileBean{
	/**
	 * 
	 */
	private static final long serialVersionUID = 5029330574441478151L;
	private int idUsr;
	private int pwdi;
	private String usuario;
	private String userEmail;
	private String nombre;
	private String passwordMd5;
	private String password;
	private boolean cambiarPassword;
	private String ipRemota;
	private String ua1;
	private String ua2;
	private String ua3;
	private boolean planeador;
	private boolean shipping;
	private boolean consolidacion;
	private boolean booking;
	private boolean consulta;
	private boolean documentosSDI;
	private boolean rechazoDocSDI;
	private boolean modificaTransporteCDI;
	private boolean bloqueado;
	private boolean cteBorrado;
	private boolean usuarioSecundario;
	private boolean acceso1equipo;
	private boolean proveedor;
	private boolean cliente;
	private boolean controlAcceso;
	private boolean usarLike;
	private boolean aceptaRechasaDocumentosSDI;
 	private boolean importsDirector;

	public UsuarioBean() {
		
	}
	/**
	 * @return the idUsr
	 */
	public int getIdUsr() {
		return idUsr;
	}
	/**
	 * @param idUsr the idUsr to set
	 */
	public void setIdUsr(int idUsr) {
		this.idUsr = idUsr;
	}
	/**
	 * @return the usuario
	 */
	public String getUsuario() {
		return usuario;
	}
	/**
	 * @param usuario the usuario to set
	 */
	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}
	/**
	 * @return the userEmail
	 */
	public String getUserEmail() {
		return userEmail;
	}
	/**
	 * @param userEmail the userEmail to set
	 */
	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}
	/**
	 * @return the nombre
	 */
	public String getNombre() {
		return nombre;
	}
	/**
	 * @param nombre the nombre to set
	 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	/**
	 * @return the planeador
	 */
	public boolean isPlaneador() {
		return planeador;
	}
	/**
	 * @param planeador the planeador to set
	 */
	public void setPlaneador(boolean planeador) {
		this.planeador = planeador;
	}
	/**
	 * @return the shipping
	 */
	public boolean isShipping() {
		return shipping;
	}
	/**
	 * @param shipping the shipping to set
	 */
	public void setShipping(boolean shipping) {
		this.shipping = shipping;
	}
	/**
	 * @return the consolidacion
	 */
	public boolean isConsolidacion() {
		return consolidacion;
	}
	/**
	 * @param consolidacion the consolidacion to set
	 */
	public void setConsolidacion(boolean consolidacion) {
		this.consolidacion = consolidacion;
	}
	/**
	 * @return the booking
	 */
	public boolean isBooking() {
		return booking;
	}
	/**
	 * @param booking the booking to set
	 */
	public void setBooking(boolean booking) {
		this.booking = booking;
	}
	/**
	 * @return the consulta
	 */
	public boolean isConsulta() {
		return consulta;
	}
	/**
	 * @param consulta the consulta to set
	 */
	public void setConsulta(boolean consulta) {
		this.consulta = consulta;
	}
	/**
	 * @return the documentosSDI
	 */
	public boolean isDocumentosSDI() {
		return documentosSDI;
	}
	/**
	 * @param documentosSDI the documentosSDI to set
	 */
	public void setDocumentosSDI(boolean documentosSDI) {
		this.documentosSDI = documentosSDI;
	}
	/**
	 * @return the rechazoDocSDI
	 */
	public boolean isRechazoDocSDI() {
		return rechazoDocSDI;
	}
	/**
	 * @param rechazoDocSDI the rechazoDocSDI to set
	 */
	public void setRechazoDocSDI(boolean rechazoDocSDI) {
		this.rechazoDocSDI = rechazoDocSDI;
	}
	/**
	 * @return the modificaTransporteCDI
	 */
	public boolean isModificaTransporteCDI() {
		return modificaTransporteCDI;
	}
	/**
	 * @param modificaTransporteCDI the modificaTransporteCDI to set
	 */
	public void setModificaTransporteCDI(boolean modificaTransporteCDI) {
		this.modificaTransporteCDI = modificaTransporteCDI;
	}
	/**
	 * @return the pwdi
	 */
	public int getPwdi() {
		return pwdi;
	}
	/**
	 * @param pwdi the pwdi to set
	 */
	public void setPwdi(int pwdi) {
		this.pwdi = pwdi;
	}
	/**
	 * @return the passwordMd5
	 */
	public String getPasswordMd5() {
		return passwordMd5;
	}
	/**
	 * @param passwordMd5 the passwordMd5 to set
	 */
	public void setPasswordMd5(String passwordMd5) {
		this.passwordMd5 = passwordMd5;
	}
	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}
	/**
	 * @param password the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}
	/**
	 * @return the cambiarPassword
	 */
	public boolean isCambiarPassword() {
		return cambiarPassword;
	}
	/**
	 * @param cambiarPassword the cambiarPassword to set
	 */
	public void setCambiarPassword(boolean cambiarPassword) {
		this.cambiarPassword = cambiarPassword;
	}
	/**
	 * @return the ipremota
	 */
	public String getIpRemota() {
		return ipRemota;
	}
	/**
	 * @param ipremota the ipremota to set
	 */
	public void setIpRemota(String ipRemota) {
		this.ipRemota = ipRemota;
	}
	/**
	 * @return the ua1
	 */
	public String getUa1() {
		return ua1;
	}
	/**
	 * @param ua1 the ua1 to set
	 */
	public void setUa1(String ua1) {
		this.ua1 = ua1;
	}
	/**
	 * @return the ua2
	 */
	public String getUa2() {
		return ua2;
	}
	/**
	 * @param ua2 the ua2 to set
	 */
	public void setUa2(String ua2) {
		this.ua2 = ua2;
	}
	/**
	 * @return the ua3
	 */
	public String getUa3() {
		return ua3;
	}
	/**
	 * @param ua3 the ua3 to set
	 */
	public void setUa3(String ua3) {
		this.ua3 = ua3;
	}
	/**
	 * @return the bloqueado
	 */
	public boolean isBloqueado() {
		return bloqueado;
	}
	/**
	 * @param bloqueado the bloqueado to set
	 */
	public void setBloqueado(boolean bloqueado) {
		this.bloqueado = bloqueado;
	}
	/**
	 * @return the cteBorrado
	 */
	public boolean isCteBorrado() {
		return cteBorrado;
	}
	/**
	 * @param cteBorrado the cteBorrado to set
	 */
	public void setCteBorrado(boolean cteBorrado) {
		this.cteBorrado = cteBorrado;
	}
	/**
	 * @return the usuarioSecundario
	 */
	public boolean isUsuarioSecundario() {
		return usuarioSecundario;
	}
	/**
	 * @param usuarioSecundario the usuarioSecundario to set
	 */
	public void setUsuarioSecundario(boolean usuarioSecundario) {
		this.usuarioSecundario = usuarioSecundario;
	}
	/**
	 * @return the acceso1equipo
	 */
	public boolean isAcceso1equipo() {
		return acceso1equipo;
	}
	/**
	 * @param acceso1equipo the acceso1equipo to set
	 */
	public void setAcceso1equipo(boolean acceso1equipo) {
		this.acceso1equipo = acceso1equipo;
	}
	/**
	 * @return the proveedor
	 */
	public boolean isProveedor() {
		return proveedor;
	}
	/**
	 * @param proveedor the proveedor to set
	 */
	public void setProveedor(boolean proveedor) {
		this.proveedor = proveedor;
	}
	/**
	 * @return the cliente
	 */
	public boolean isCliente() {
		return cliente;
	}
	/**
	 * @param cliente the cliente to set
	 */
	public void setCliente(boolean cliente) {
		this.cliente = cliente;
	}
	/**
	 * @return the controlAcceso
	 */
	public boolean isControlAcceso() {
		return controlAcceso;
	}
	/**
	 * @param controlAcceso the controlAcceso to set
	 */
	public void setControlAcceso(boolean controlAcceso) {
		this.controlAcceso = controlAcceso;
	}
	public boolean isUsarLike() {
		return usarLike;
	}
	public void setUsarLike(boolean usarLike) {
		this.usarLike = usarLike;
	}
	public boolean isAceptaRechasaDocumentosSDI() {
		return aceptaRechasaDocumentosSDI;
	}
	public void setAceptaRechasaDocumentosSDI(boolean aceptaRechasaDocumentosSDI) {
		this.aceptaRechasaDocumentosSDI = aceptaRechasaDocumentosSDI;
	}
	/**
	 * @return the importsDirector
	 */
	public boolean isImportsDirector() {
		return importsDirector;
	}
	/**
	 * @param importsDirector the importsDirector to set
	 */
	public void setImportsDirector(boolean importsDirector) {
		this.importsDirector = importsDirector;
	}
	
}
