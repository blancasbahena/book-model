package com.truper.businessEntity;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.SortedSet;
import java.util.TreeSet;

import lombok.ToString;
@ToString
public class BeanPriceRelease implements Comparable<BeanPriceRelease> {

	private int folio;
	private String proveedor;
	private String proveedor_nombre;
	private HashSet<String> compradores;
	private HashSet<String> bus;
	private HashSet<UnidadNegocio> buDirectores;
	private HashSet<String> buGerentes;
	private BigDecimal totalPrice;
	private Date createDate;
	private SortedSet<BeanPriceReleasePosicion> posiciones;
	private HashMap<Integer, String> folio_buDirector;
	private boolean enableAutomatizacion;
	public BeanPriceRelease() {
		super();
		compradores = new HashSet<String>();
		bus = new HashSet<String>();
		buDirectores = new HashSet<UnidadNegocio>();
		buGerentes = new HashSet<String>();
		posiciones = new TreeSet<BeanPriceReleasePosicion>();
	}

	public BeanPriceRelease(int folio, String proveedor, String proveedor_nombre, HashSet<String> compradores,
			HashSet<String> bus, HashSet<UnidadNegocio> buDirectores, HashSet<String> buGerentes, BigDecimal totalPrice,
			Date createDate) {
		this();
		this.folio = folio;
		this.proveedor = proveedor;
		this.proveedor_nombre = proveedor_nombre;
		this.compradores = compradores;
		this.bus = bus;
		this.buDirectores = buDirectores;
		this.buGerentes = buGerentes;
		this.totalPrice = totalPrice;
		this.createDate = createDate;
	}

	public int getFolio() {
		return folio;
	}

	public void setFolio(int folio) {
		this.folio = folio;
	}

	public String getProveedor() {
		return proveedor;
	}

	public void setProveedor(String proveedor) {
		this.proveedor = proveedor;
	}

	public String getProveedor_nombre() {
		return proveedor_nombre;
	}

	public void setProveedor_nombre(String proveedor_nombre) {
		this.proveedor_nombre = proveedor_nombre;
	}

	public HashSet<String> getCompradores() {
		return compradores;
	}

	public void setCompradores(HashSet<String> compradores) {
		this.compradores = compradores;
	}

	public HashSet<String> getBus() {
		return bus;
	}

	public void setBus(HashSet<String> bus) {
		this.bus = bus;
	}

	public HashSet<UnidadNegocio> getBuDirectores() {
		return buDirectores;
	}

	public void setBuDirectores(HashSet<UnidadNegocio> buDirectores) {
		this.buDirectores = buDirectores;
	}

	public HashSet<String> getBuGerentes() {
		return buGerentes;
	}

	public void setBuGerentes(HashSet<String> buGerentes) {
		this.buGerentes = buGerentes;
	}

	public BigDecimal getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(BigDecimal totalPrice) {
		this.totalPrice = totalPrice;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public SortedSet<BeanPriceReleasePosicion> getPosiciones() {
		return posiciones;
	}

	public void setPosiciones(SortedSet<BeanPriceReleasePosicion> posiciones) {
		this.posiciones = posiciones;
	}

	public HashMap<Integer, String> getFolio_buDirector() {
		return folio_buDirector;
	}

	public void setFolio_buDirector(HashMap<Integer, String> folio_buDirector) {
		this.folio_buDirector = folio_buDirector;
	}

	@Override
	public int compareTo(BeanPriceRelease bean) {
		int valor = Integer.compare(getFolio(), bean.getFolio());
		return valor;
	}

	public boolean isEnableAutomatizacion() {
		return enableAutomatizacion;
	}

	public void setEnableAutomatizacion(boolean enableAutomatizacion) {
		this.enableAutomatizacion = enableAutomatizacion;
	}

}
