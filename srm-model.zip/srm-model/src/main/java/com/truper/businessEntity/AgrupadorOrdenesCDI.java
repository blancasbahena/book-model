package com.truper.businessEntity;

import java.util.ArrayList;

import com.truper.infra.businessEntities.BaseBusinessEntity;

public class AgrupadorOrdenesCDI extends BaseBusinessEntity {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 118679293826338436L;
	private String numeroOrden;
	ArrayList<OrdenCDI> ordenes;
	private int fechaUltimaConfirmacion;
	
	
	
	
	
//	public AgrupadorOrdenesCDI(String numeroOrden){
//		this.numeroOrden = numeroOrden;
//		ordenes = new ArrayList<OrdenCDI>();
//	}
	
//	public void agregaOrden(OrdenCDI orden){
//		ordenes.add(orden);
//		if(orden.getFechaUltimaConfirmacion() > fechaUltimaConfirmacion && orden.getRemanente() > 0){
//			fechaUltimaConfirmacion = orden.getFechaUltimaConfirmacion();
//		}
//	}
	
//	public JSONObject toJSON() throws JSONException{
//		JSONObject json = new JSONObject();
//		JSONArray ordenes = new JSONArray();
//		
//		json.put("numeroOrden", numeroOrden);
//		json.put("ordenes", ordenes);
//		
//		for(OrdenCDI orden : this.ordenes){
//			if(orden.getRemanente() <= 0){
//				continue;
//			}
//			ordenes.put(orden.toJSON());
//		}
//				
//		return json;
//	}
	
	public String getNumeroOrden() {
		return numeroOrden;
	}
	public void setNumeroOrden(String numeroOrden) {
		this.numeroOrden = numeroOrden;
	}
	public ArrayList<OrdenCDI> getOrdenes() {
		return ordenes;
	}
	public void setOrdenes(ArrayList<OrdenCDI> ordenes) {
		this.ordenes = ordenes;
	}	
	public int getFechaUltimaConfirmacion(){
		return fechaUltimaConfirmacion;
	}
}
