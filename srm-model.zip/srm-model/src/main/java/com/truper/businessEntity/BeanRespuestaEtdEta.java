package com.truper.businessEntity;

import com.truper.bpm.enums.ErrorValidacionEtdEta;

public class BeanRespuestaEtdEta {

	private EtaBean etaBean;
	private ErrorValidacionEtdEta tipoError;

	public EtaBean getEtaBean() {
		return etaBean;
	}

	public void setEtaBean(EtaBean etaBean) {
		this.etaBean = etaBean;
	}

	public ErrorValidacionEtdEta getTipoError() {
		return tipoError;
	}

	public void setTipoError(ErrorValidacionEtdEta tipoError) {
		this.tipoError = tipoError;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("BeanRespuestaEtdEta [getEtaBean=");
		builder.append(getEtaBean());
		builder.append(", getTipoError=");
		builder.append(getTipoError());
		builder.append("]");
		return builder.toString();
	}
}