package com.truper.businessEntity;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

import com.truper.infra.businessEntities.BaseBusinessEntity;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class SAR extends BaseBusinessEntity implements Cloneable {
	
	private static final long serialVersionUID = -3916212081846523729L;
	public static final int STATUS_SIN_SOLICITUD_APROBACION = 0;
	public static final int STATUS_ESPERA_APROBACION_PLANEACION = 1;//
	public static final int STATUS_ESPERA_APROBACION_SHIPPING= 2;
	public static final int STATUS_APROBADO = 3;
	public static final int STATUS_CANCELADO = 4;
	public static final int STATUS_EMBARCADO = 5;
	public static final int STATUS_DOCUMENTOS_SDI = 6;
	public static final int STATUS_RECHAZADO = 7;
	public static final int STATUS_EN_REVISION_PRECIOS = 8;
	public static final int STATUS_INICIO_SDI = 9;
	public static final int STATUS_LIBERATION_BO_CONFIRMATION=110;
	public static final int STATUS_LIBERATION_BO_CONFIRMATION_MR=111;
	public static final int STATUS_LIBERATION_BO_CONFIRMATION_BO=112;
	public static final int STATUS_LIBERATION_BO_ON_HOLD_BO=113;
	public static final int SIN_RETRASO = 0;
	public static final int RETRASO_TRUPER = 1;
	public static final int RETRASO_PROVEEDOR = 2;
	public static final int RETRASO_PLAN_DE_EMBARQUES = 3;
	public static final String COLOR_BLANCO = "#FFFFFF;";
	public static final String COLOR_MORADO = "#e9deef;";
	public static final String COLOR_ROJO = "#fddad5;";
	/**Esta constante la usare para definir que los estatus 0,1,2,3 etc, son folios abiertos y
	 * en el DAO o BO usare esta info   */
	public static final int STATUS_TODOS_ABIERTOS = -1;
	
	public static final int LCL = 4;// El numero 4 significa que es un contenedor LCL y se marca como consolidado
	
	
	public static boolean DEBUG = true;
	
	public static String MAIL_GIL;
	public static String[] MAIL_DEBUG;
	public static String[] MAIL_GRUPO_CONSOL;
	public static String[] MAIL_GRUPO_SHIPPINGPLANNER;
	public static String[] MAIL_GRUPO_BOOKING;
	public static String[] MAIL_GRUPO_REPORTE_SARS;
	public static String[] MAIL_GRUPO_CUENTAS_X_PAGAR;
	public static String[] MAIL_GRUPO_SDI;
	public static String[] MAIL_GRUPO_GERENTES_PLANNING;
	public static String[] MAIL_GRUPO_GERENTES_CONFIRMACION;
	public static String[] MAIL_GRUPO_GERENTES_BOOKING;
	public static String[] MAIL_GRUPO_REPORTE_CAMBIOS_ETD;
	public static String[] MAIL_GRUPO_DIR_CHINA;
	
	public static String[] MAIL_RECHAZO_SAR_BY_SHIPPING;
	
	public static String 	SERVER_FILES;
	public static String 	URL_FILES;
	public static String 	EMAIL_SHIPPING;
	public static String 	EMAIL_BOOKING;
	public static String 	EMAIL_IVAN_SHIPPING;
	public static String 	EMAIL_TONO_SHIPPING;
	public static String	EMAIL_EISEN_SHIPPING;
	public static String	EMAIL_OMAR_MORALES;
	public static String	EMAIL_SUKI;
	public static String	EMAIL_GERENTE_MATRIZ;
	public static String	EMAIL_GERENTE_AUDITORIA;
	public static String	EMAIL_TRAFICO;
	
	public static String[] EMAILS_FR_CHINA_GERENTE;
	public static String	EMAIL_FR_CHINA_DIRECTOR;
	public static String	EMAIL_DOCUMENTOS;
	
	public static String 	UBBER_PASS_PLI;
	public static String 	UBBER_PASS_PLI_SYS;
	//Nuevas variables para los senders
	public static String 	SENDER_CANCEL_PLANNING;
	public static String 	SENDER_DIFERENCIAS_PLANER;
	public static String 	SENDER_FULL_SHIPPING;
	public static String 	SENDER_CONSOL_SHIPPING;
	public static String 	SENDER_AEREO_SHIPPING;
	public static String 	SENDER_CONSOLIDADOS_PROVEEDOR;
	public static String 	SENDER_CONSOLIDADOS_CONTROLINTERNO;
	public static String 	SENDER_BOOKING_CAMBIOS;
	public static String 	SENDER_BOOKING_REMINDER;
	public static String 	SENDER_SDI_SOLICITUD_DOCTOS;
	public static String 	SENDER_SDI_ACEPTACION;
	//mapa de bloqueos
	public static HashMap<String,CdiBloqueosBean> MAPA_BLOQUEOS;
	
	

	public static HashMap<String, BeanTiposDeCambio> 	mapaTipoMoneda;	
	public static HashMap<Integer, String> 	mapaPaisDestino;
	public static HashMap<Integer, String> 	aeropuertosDestino;
	//public static HashMap<String, String> 	mapaUnidades;
	public static LinkedHashMap<String, String> mapaUnidades;

	public static final String detMercImportado = "Z";
	public static final String detMercNoImportado = "P";
	
	public static final int[] ABIERTOSARRAY = 
		{STATUS_SIN_SOLICITUD_APROBACION,STATUS_ESPERA_APROBACION_PLANEACION,STATUS_ESPERA_APROBACION_SHIPPING,STATUS_APROBADO}; 

	private Integer folio;
	private String puertoOrigen;
	private String puertoDescarga;
	private Integer naviera;
	private Integer fechaEmbarque;
	private Boolean consolidado;
	private Integer status;
	private Integer fechaSolicitudDeAprobacion;
	private Integer fechaUltimaAprobacionRechazo;
	private Integer tipoContenedor;
	private Integer prioridad;
	private Integer etdPlanner;
	private Integer etdReal;
	private Integer etdModificada;
	private Integer folioConsolidado;
	private Integer fechaEmbarqueIni;
	private Integer fechaEmbarqueFin;
	
	
	private String	proveedor;
	private String 	usuarioSolicitudDeAprobacion;
	private String  usuarioApruebaPlanning;
	private String 	usuarioApruebaRechaza;
	private String 	barcoSugerido;
	private String  viaje;
	private String  contenedor;
	private String  booking;
	private String  comentarioCancelacion;
	private Integer transporte;
	private Integer ida;
	private Integer maxIda;
	private Integer minIda;
	private String  comentarioPlanner;
	private String  comentarioShipping;
	private String  comentarioTruperBooking;
	private Boolean esSinPO;
	private Integer	eta;
	private String  bl;
	private Integer	fechaBl;
	private Integer creationDate;
	private String warning;///aqui voy a poner en html la imagen y la funcion a la que va a llamar
	private boolean aviso;
		
	private Boolean	aprobadoPorCompras;
	private Integer	tipoRetraso;
	private Boolean esAereo;
	
	private Boolean tieneFacura;
	private Boolean tieneBL;
	private Boolean tienePackingList;
	private Boolean cargoAProveedor;
	private Integer	aerolinea;
	private String	avion;
	private String	otraAerolinea;
	private Integer	llegadaAvion;
	private Integer	paisDestino;
	private Boolean	aprobadoProveedor;
	
	private Boolean		esMultiple;
	private Integer		mandante;
	private Boolean		aprobadoSDI;
	private Integer		fechaUltimoRechazo;
	private Integer		fechaUltimaCorreccion;
	private Integer		revision;
	private String		usuarioAceptoRechazoSAR;
	
	private String tipoProducto;
	//Variable que guarda los iconosde los folios sar, este es solo para la vista
	private String multipleHtml;

	/**bandera que se usa para mostrar si el SAR fue modificado por el proveedor al confirmar embarque*/
	private Boolean 	modificadoProveedor;
	
	/**Indica si Planeaci�n acept� la confirmaci�n de embarcado con diferencias*/
	private Boolean 	aceptadoConDiferencias;
	
	private ArrayList<SARDetalle> detalle;
	private ArrayList<SARDetalle> detalleOtros;
	
	/** Variables que no estan en la tabla **/
	private double 		peso;
	private double 		volumen;
	private double 		pesoConfirmado;
	private double 		volumenConfirmado;
	private BigDecimal 	valorEmbarque = new BigDecimal(0.0);
	private BigDecimal 	valorEmbarqueConfirmado = new BigDecimal(0.0);
	private Boolean		incluyeSarConsol;
	private String				colorWarning;
	private String				textoWarning;
	private BigDecimal 			backorderPronosticadoTot;
	private Double 			overStockTot;
	private Double 			overStockPctTot;
	private String 		foliosMultiples;//Folios multiples se refiere a los folios que estan juntos en documentos
	private ArrayList<String>	listaPos;
	private Boolean				nuloEnAprobadoSDI;
	private Boolean				cerradoDocumentosProveedor;
	private Integer fechaCierreDocumentosProveedor;
	private Integer fechaAprobadoSDI;
	private Boolean sarOnHold;
	private Boolean tienePedidoDirecto;
	private Boolean tieneDiferenciaMRP;
	private Integer cargaArchivoMRP;
	private String nombreArchivoMRP;
	private Boolean needsAuthImpDir;
	private Boolean aprobadoDirImportaciones;
	private String userApruebaDirImportaciones;
	private Integer fechaAprobacionDirImportaciones;
	private String commentForImpDir;
	private String impDirComments;
	private Integer adelantoAtrasoETDImpDir;
	private Integer etdProveedor;///Historico de la fecha del proveedor
	private boolean isEnRevicionIDA;
	
	//Campos Confirmation Manager
	private Boolean aprobadoConfMngr;
	private String userApruebaConfMngr;
	private Integer fechaApruebaConfMngr;
	private String commentForConfMngr;
	private Long 	fecIniConfMngr;
	private Integer tinyFecIniConfMngr;
	private String confMngrComments;
	
	//Fechas de inicio de estado;
	private Long 	fecIniPlanning;
	private Integer tinyFecIniPlanning;
	private Long 	fecIniImpDir;
	private Integer tinyFecIniImpDir;
	private Long 	fecIniShipping;
	private Integer tinyFecIniShipping;
	private Long 	fecIniConsolidados;
	private Integer tinyFecIniConsolidados;
	private Long 	fecIniBooking;
	private Integer tinyFecIniBooking;
	private Long 	fecIniSDI;
	private Integer tinyFecIniSDI;
	private Long 	fecIniEmbarque;
	private Integer tinyFecIniEmbarque;
	private Boolean esRechazadoSDI;
	private Integer filtroBooking;
	private List<BeanSarChat> lstChat;
	private Double difPesoUserVSSystem;
	private Double difVolUserVSSystem;
	private Integer piDate;
	private Double safetyStock;
	private String forecastModel;
	private Double var8Sem;
	private Double var8SemanasDirectos;
	private Integer facturacionPedidosDirectos;
	private Boolean cargadoMRP;
	private Boolean notificacionMRP;
	private Boolean enRevisionConfirmFinal;
	private String commentRevFinalConfirm;
	private String commentVendorRevFinalConfirm;
	private Boolean aceptadoRevFinalConfirm;
	private String usrAceptaRechazaRevFinal;
	private Boolean cambiosRevFinalApplied;
	private Integer numRevFinal;
	private Boolean aplicaBitacora;
	private Boolean bitacoraImportsDirCerrada;
	private Integer fecCierreBitacoraImpDir;
	private Integer fecCierreLogImpDirIni;
	private Integer fecCierreLogImpDirFin;
	
	///variable para el query dinamico en fecha de creacion
	private String		intervalosFechaCreacion;
	private String intervalosFechaEmbarcacion;
	private Boolean tieneProdsNuevos;
	private Boolean etdRealWarning;
	private String usrEtdRealWarning;
	private Boolean needsAuthPlanningMgr;
	private Boolean tieneSimulador;
	private Boolean preciosLiberados;
	private Integer versionSDI;
	private Boolean preciosEnRevision;
	private Boolean preciosRevisados;
	private String sealNumber;
	private String contenedorProveedor;
	private String disagreeComments;
	private boolean bitacoraIDA;
	private boolean bitacoraIDACerrada;
	
	private String concatenado;
	private String almacen;
	private Date fechaConfirmacionFinal;
	private boolean tieneReferenceNumber;
	
	private boolean pm;
	private boolean sife;
	
	private Integer folioSife;
	private String statusSife;
	
	private boolean isSeasonal;
	private String totalVar12Semanas;
	private String totalVar8Semanas;
	private char abc;
	
	private boolean botonEnviarDocsTEL;
	private String numeroFactura;
	
	
	public Boolean getNuloEnAprobadoSDI() {
		return nuloEnAprobadoSDI;
	}
	////Este es para si le pongo true va a poner un is null en el quiery 
	public void setNuloEnAprobadoSDI(Boolean nuloEnAprobadoSDI) {
		this.nuloEnAprobadoSDI = nuloEnAprobadoSDI;
	}

	public SAR(){}
	
	public SAR(int folio, String proveedor, Integer tipoContenedor){
		this.folio = folio;
		this.proveedor = proveedor;
		this.status = STATUS_SIN_SOLICITUD_APROBACION;
		this.tipoContenedor = tipoContenedor;
	}
	public SAR(String concatenado, Integer folioConsolidado){
		this.concatenado = concatenado;
		this.folioConsolidado = folioConsolidado;
	}
	
	public SAR clone(){
		SAR nuevo = new SAR();
		nuevo.folio = this.folio;
		nuevo.aceptadoConDiferencias = this.aceptadoConDiferencias;
		nuevo.aprobadoProveedor = this.aprobadoProveedor;
		/////////nuevo.detalle = this.detalle
		nuevo.esMultiple = this.esMultiple;	
		nuevo.foliosMultiples = this.foliosMultiples;
		nuevo.proveedor = this.proveedor;
		nuevo.mandante = this.mandante;
		nuevo.status = this.status;
		nuevo.paisDestino = this.paisDestino;
		nuevo.booking = this.booking;
		nuevo.avion = this.avion;
		nuevo.backorderPronosticadoTot = this.backorderPronosticadoTot;
		nuevo.overStockTot = this.overStockTot;
		nuevo.overStockPctTot = this.overStockPctTot;
		nuevo.barcoSugerido = this.barcoSugerido;
		nuevo.bl = this.bl;
		nuevo.cargoAProveedor = this.cargoAProveedor;
		nuevo.colorWarning = this.colorWarning;
		nuevo.comentarioCancelacion = this.comentarioCancelacion;
		nuevo.comentarioPlanner = this.comentarioPlanner;
		nuevo.comentarioShipping = this.comentarioShipping;
		nuevo.comentarioTruperBooking = this.comentarioTruperBooking;
		nuevo.consolidado = this.consolidado;
		nuevo.contenedor = this.contenedor;
		nuevo.creationDate = this.creationDate;
		nuevo.esAereo = this.esAereo;
		nuevo.esSinPO = this.esSinPO;
		nuevo.eta = this.eta;
		nuevo.etdPlanner = this.etdPlanner;
		nuevo.etdReal = this.etdReal;
		nuevo.fechaBl = this.fechaBl;
		nuevo.fechaEmbarque = this.fechaEmbarque;
		nuevo.fechaEmbarqueFin = this.fechaEmbarqueFin;
		nuevo.fechaEmbarqueIni = this.fechaEmbarqueIni;
		nuevo.fechaSolicitudDeAprobacion = this.fechaSolicitudDeAprobacion;
		nuevo.fechaUltimaAprobacionRechazo = this.fechaUltimaAprobacionRechazo;
		nuevo.folioConsolidado = this.folioConsolidado;
		nuevo.ida = this.ida;
		nuevo.minIda = this.minIda;
		nuevo.incluyeSarConsol = this.incluyeSarConsol;
		nuevo.listaPos = this.listaPos;
		nuevo.llegadaAvion = this.llegadaAvion;
		nuevo.modificadoProveedor = this.modificadoProveedor;
		nuevo.naviera = this.naviera;
		nuevo.otraAerolinea = this.otraAerolinea;
		nuevo.paisDestino = this.paisDestino;
		nuevo.peso = this.peso;
		nuevo.pesoConfirmado = this.pesoConfirmado;
		nuevo.prioridad = this.prioridad;
		nuevo.proveedor = this.proveedor;
		nuevo.puertoDescarga = this.puertoDescarga;
		nuevo.puertoOrigen = this.puertoOrigen;
		nuevo.textoWarning = this.textoWarning;
		nuevo.tieneBL = this.tieneBL;
		nuevo.tieneFacura = this.tieneFacura;
		nuevo.tienePackingList = this.tienePackingList;
		nuevo.tipoContenedor = this.tipoContenedor;
		nuevo.tipoRetraso = this.tipoRetraso;
		nuevo.transporte = this.transporte;
		nuevo.usuarioApruebaPlanning = this.usuarioApruebaPlanning;
		nuevo.usuarioApruebaRechaza = this.usuarioApruebaRechaza;
		nuevo.usuarioSolicitudDeAprobacion = this.usuarioSolicitudDeAprobacion;
		nuevo.valorEmbarque = this.valorEmbarque;
		nuevo.valorEmbarqueConfirmado = this.valorEmbarqueConfirmado;
		nuevo.viaje = this.viaje;
		nuevo.volumen = this.volumen;
		nuevo.volumenConfirmado = this.volumenConfirmado;
		nuevo.lstChat = this.lstChat;
		nuevo.etdProveedor = this.etdProveedor;
		nuevo.cargadoMRP = this.cargadoMRP;
		nuevo.notificacionMRP = this.notificacionMRP;
		nuevo.enRevisionConfirmFinal = this.enRevisionConfirmFinal;
		nuevo.commentRevFinalConfirm = this.commentRevFinalConfirm;
		nuevo.commentVendorRevFinalConfirm = this.commentVendorRevFinalConfirm;
		nuevo.aceptadoRevFinalConfirm = this.aceptadoRevFinalConfirm;
		nuevo.usrAceptaRechazaRevFinal = this.usrAceptaRechazaRevFinal;
		nuevo.cambiosRevFinalApplied = this.cambiosRevFinalApplied;
		nuevo.numRevFinal = this.numRevFinal;
		nuevo.aplicaBitacora = this.aplicaBitacora;
		nuevo.bitacoraImportsDirCerrada = this.bitacoraImportsDirCerrada;
		nuevo.fecCierreBitacoraImpDir = this.fecCierreBitacoraImpDir;
		nuevo.fecCierreLogImpDirIni = this.fecCierreLogImpDirIni;
		nuevo.fecCierreLogImpDirFin = this.fecCierreLogImpDirFin;
		nuevo.tieneProdsNuevos = this.tieneProdsNuevos;
		nuevo.etdRealWarning = this.etdRealWarning;
		nuevo.usrEtdRealWarning = this.usrEtdRealWarning;
		nuevo.needsAuthPlanningMgr = this.needsAuthPlanningMgr;
		nuevo.tieneSimulador = this.tieneSimulador;
		nuevo.preciosLiberados = this.preciosLiberados;
		nuevo.preciosEnRevision = this.preciosEnRevision;
		nuevo.preciosRevisados = this.preciosRevisados;
		nuevo.disagreeComments = this.disagreeComments;
 		return nuevo;
	}
	
	public Boolean getTieneSimulador() {
		return tieneSimulador;
	}
	public void setTieneSimulador(Boolean tieneSimulador) {
		this.tieneSimulador = tieneSimulador;
	}
	public String getFolioCompleto() {
		return consolidado != null && consolidado ? "C" + folio : "F" + folio;
	}
	public Integer getFolio() {
		return folio;
	}
	public void setFolio(Integer folio) {
		this.folio = folio;
	}
	public String getPuertoSalida() {
		return puertoOrigen;
	}
	public void setPuertoSalida(String puertoSalida) {
		this.puertoOrigen = puertoSalida;
	}
	public String getPuertoDescarga() {
		return puertoDescarga;
	}
	public void setPuertoDescarga(String puertoDescarga) {
		this.puertoDescarga = puertoDescarga;
	}
	public Integer getNaviera() {
		return naviera;
	}
	public void setNaviera(Integer naviera) {
		this.naviera = naviera;
	}
	public Integer getFechaEmbarque() {
		return fechaEmbarque;
	}
	public void setFechaEmbarque(Integer fechaEmbarque) {
		this.fechaEmbarque = fechaEmbarque;
	}
	public Integer getStatus() {
		return status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
	public Integer getFechaSolicitudDeAprobacion() {
		return fechaSolicitudDeAprobacion;
	}
	public void setFechaSolicitudDeAprobacion(Integer fechaSolicitudDeAprobacion) {
		this.fechaSolicitudDeAprobacion = fechaSolicitudDeAprobacion;
	}
	public String getUsuarioApruebaPlanning() {
		return usuarioApruebaPlanning;
	}
	public void setUsuarioApruebaPlanning(String usuarioApruebaPlanning) {
		this.usuarioApruebaPlanning = usuarioApruebaPlanning;
	}
	public Integer getFechaUltimaAprobacionRechazo() {
		return fechaUltimaAprobacionRechazo;
	}
	public void setFechaUltimaAprobacionRechazo(Integer fechaUltimaAprobacionRechazo) {
		this.fechaUltimaAprobacionRechazo = fechaUltimaAprobacionRechazo;
	}
	public Integer getTipoContenedor() {
		return tipoContenedor;
	}
	public void setTipoContenedor(Integer tipoContenedor) {
		this.tipoContenedor = tipoContenedor;
	}
	public Integer getPrioridad() {
		return prioridad;
	}
	public void setPrioridad(Integer prioridad) {
		this.prioridad = prioridad;
	}
	public String getProveedor() {
		return proveedor;
	}
	public void setProveedor(String proveedor) {
		this.proveedor = proveedor;
	}
	public String getUsuarioSolicitudDeAprobacion() {
		return usuarioSolicitudDeAprobacion;
	}
	public void setUsuarioSolicitudDeAprobacion(String usuarioSolicitudDeAprobacion) {
		this.usuarioSolicitudDeAprobacion = usuarioSolicitudDeAprobacion;
	}
	public String getUsuarioApruebaRechaza() {
		return usuarioApruebaRechaza;
	}
	public void setUsuarioApruebaRechaza(String usuarioApruebaRechaza) {
		this.usuarioApruebaRechaza = usuarioApruebaRechaza;
	}
	public String getBarcoSugerido() {
		return barcoSugerido;
	}
	public void setBarcoSugerido(String barcoSugerido) {
		this.barcoSugerido = barcoSugerido;
	}
	public String getViaje() {
		return viaje;
	}
	public void setViaje(String viaje) {
		this.viaje = viaje;
	}
	public String getContenedor() {
		return contenedor;
	}
	public void setContenedor(String contenedor) {
		this.contenedor = contenedor;
	}
	public String getBooking() {
		return booking;
	}
	public void setBooking(String booking) {
		this.booking = booking;
	}
	public double getPeso() {
		return peso;
	}
	public void setPeso(double peso) {
		this.peso = peso;
	}
	public double getVolumen() {
		return volumen;
	}
	public void setVolumen(double volumen) {
		this.volumen = volumen;
	}
	public double getPesoConfirmado() {
		return pesoConfirmado;
	}
	public void setPesoConfirmado(double pesoConfirmado) {
		this.pesoConfirmado = pesoConfirmado;
	}
	public double getVolumenConfirmado() {
		return volumenConfirmado;
	}
	public void setVolumenConfirmado(double volumenConfirmado) {
		this.volumenConfirmado = volumenConfirmado;
	}
	public BigDecimal getValorEmbarqueConfirmado() {
		return valorEmbarqueConfirmado;
	}
	public void setValorEmbarqueConfirmado(BigDecimal valorEmbarqueConfirmado) {
		this.valorEmbarqueConfirmado = valorEmbarqueConfirmado;
	}
	public String getComentarioCancelacion() {
		return comentarioCancelacion;
	}
	public void setComentarioCancelacion(String comentarioCancelacion) {
		this.comentarioCancelacion = comentarioCancelacion;
	}
	public ArrayList<SARDetalle> getDetalle() {
		return detalle;
	}
	public void setDetalle(ArrayList<SARDetalle> detalle) {
		this.detalle = detalle;
	}
	public ArrayList<SARDetalle> getDetalleOtros() {
		return detalleOtros;
	}
	public void setDetalleOtros(ArrayList<SARDetalle> detalleOtros) {
		this.detalleOtros = detalleOtros;
	}
	public BigDecimal getValorEmbarque() {
		return valorEmbarque;
	}
	public void setValorEmbarque(BigDecimal valorEmbarque) {
		this.valorEmbarque = valorEmbarque;
	}
	public String getPuertoOrigen() {
		return puertoOrigen;
	}
	public void setPuertoOrigen(String puertoOrigen) {
		this.puertoOrigen = puertoOrigen;
	}
	public Boolean getConsolidado() {
		return consolidado;
	}
	public void setConsolidado(Boolean consolidado) {
		this.consolidado = consolidado;
	}
	public Integer getFolioConsolidado() {
		return folioConsolidado;
	}
	public void setFolioConsolidado(Integer folioConsolidado) {
		this.folioConsolidado = folioConsolidado;
	}
	public Integer getFechaEmbarqueIni() {
		return fechaEmbarqueIni;
	}
	public void setFechaEmbarqueIni(Integer fechaEmbarqueIni) {
		this.fechaEmbarqueIni = fechaEmbarqueIni;
	}
	public Integer getFechaEmbarqueFin() {
		return fechaEmbarqueFin;
	}
	public void setFechaEmbarqueFin(Integer fechaEmbarqueFin) {
		this.fechaEmbarqueFin = fechaEmbarqueFin;
	}
	public Boolean getIncluyeSarConsol() {
		return incluyeSarConsol;
	}
	public void setIncluyeSarConsol(Boolean incluyeSarConsol) {
		this.incluyeSarConsol = incluyeSarConsol;
	}
	public String getColorWarning() {
		return colorWarning;
	}
	public void setColorWarning(String colorWarning) {
		this.colorWarning = colorWarning;
	}
	public String getTextoWarning() {
		return textoWarning;
	}
	public void setTextoWarning(String textoWarning) {
		this.textoWarning = textoWarning;
	}
	public BigDecimal getBackorderPronosticadoTot() {
		return backorderPronosticadoTot;
	}
	public void setBackorderPronosticadoTot(BigDecimal backorderPronosticadoTot) {
		this.backorderPronosticadoTot = backorderPronosticadoTot;
	}
	public Double getOverStockTot() {
		return overStockTot;
	}
	public void setOverStockTot(Double overStockTot) {
		this.overStockTot = overStockTot;
	}
	
	public Double getOverStockPctTot() {
		return overStockPctTot;
	}
	public void setOverStockPctTot(Double overStockPctTot) {
		this.overStockPctTot = overStockPctTot;
	}

	public Integer getTransporte() {
		return transporte;
	}
	public void setTransporte(Integer transporte) {
		this.transporte = transporte;
	}
	public String getComentarioPlanner() {
		return comentarioPlanner;
	}
	public void setComentarioPlanner(String comentarioPlanner) {
		this.comentarioPlanner = comentarioPlanner;
	}
	public String getComentarioShipping() {
		return comentarioShipping;
	}
	public void setComentarioShipping(String comentarioShipping) {
		this.comentarioShipping = comentarioShipping;
	}
	public Integer getEtdPlanner() {
		return etdPlanner;
	}
	public void setEtdPlanner(Integer etdPlanner) {
		this.etdPlanner = etdPlanner;
	}
	public Integer getEtdReal() {
		return etdReal;
	}
	public void setEtdReal(Integer etdReal) {
		this.etdReal = etdReal;
	}
	public Integer getEtdModificada() {
		return etdModificada;
	}
	public void setEtdModificada(Integer etdModificada) {
		this.etdModificada = etdModificada;
	}
	public ArrayList<String> getListaPos() {
		return listaPos;
	}
	public void setListaPos(ArrayList<String> listaPos) {
		this.listaPos = listaPos;
	}
	public String getComentarioTruperBooking() {
		return comentarioTruperBooking;
	}
	public void setComentarioTruperBooking(String comentarioTruperBooking) {
		this.comentarioTruperBooking = comentarioTruperBooking;
	}
	public Integer getIda() {
		return ida;
	}
	public void setIda(Integer ida) {
		this.ida = ida;
	}
	
	public Boolean getEsSinPO() {
		return esSinPO;
	}
	public void setEsSinPO(Boolean esSinPO) {
		this.esSinPO = esSinPO;
	}
	public Integer getEta() {
		return eta;
	}
	public void setEta(Integer eta) {
		this.eta = eta;
	}
	public String getBl() {
		return bl;
	}
	public void setBl(String bl) {
		this.bl = bl;
	}
	@Deprecated
	public Boolean isAprobadoPorCompras() {
		return aprobadoPorCompras;
	}
	@Deprecated
	public void setAprobadoPorCompras(Boolean aprobadoPorCompras) {
		this.aprobadoPorCompras = aprobadoPorCompras;
	}
	@Deprecated
	public Boolean getAprobadoPorCompras() {
		return aprobadoPorCompras;
	}
	public Integer getTipoRetraso() {
		return tipoRetraso;
	}
	public void setTipoRetraso(Integer tipoRetraso) {
		this.tipoRetraso = tipoRetraso;
	}
	public Integer getCreationDate() {
		return creationDate;
	}
	public void setCreationDate(Integer creationDate) {
		this.creationDate = creationDate;
	}
	public String getWarning() {
		return warning;
	}
	public void setWarning(String warning) {
		this.warning = warning;
	}
	public boolean isAviso() {
		return aviso;
	}
	public void setAviso(boolean aviso) {
		this.aviso = aviso;
	}
	public Integer getPaisDestino() {
		return paisDestino;
	}
	public void setPaisDestino(Integer paisDestino) {
		this.paisDestino = paisDestino;
	}
	public Boolean getCargoAProveedor() {
		return cargoAProveedor;
	}
	public void setCargoAProveedor(Boolean cargoAProveedor) {
		this.cargoAProveedor = cargoAProveedor;
	}
	public String getOtraAerolinea() {
		return otraAerolinea;
	}
	public void setOtraAerolinea(String otraAerolinea) {
		this.otraAerolinea = otraAerolinea;
	}
	public Boolean getAprobadoProveedor() {
		return aprobadoProveedor;
	}
	public void setAprobadoProveedor(Boolean aprobadoProveedor) {
		this.aprobadoProveedor = aprobadoProveedor;
	}
	public Integer getFechaBl() {
		return fechaBl;
	}
	public void setFechaBl(Integer fechaBl) {
		this.fechaBl = fechaBl;
	}		
	public Boolean esMultiple() {
		return esMultiple;
	}
	public void setEsMultiple(Boolean esMultiple) {
		this.esMultiple = esMultiple;
	}
	public Integer getMandante() {
		return mandante;
	}
	public void setMandante(Integer mandante) {
		this.mandante = mandante;
	}
	public String getFoliosMultiples() {
		return foliosMultiples;
	}
	public void setFoliosMultiples(String foliosMultiples) {
		this.foliosMultiples = foliosMultiples;
	}
		
	public static boolean esConsolidado(SAR bean){
		boolean result = false;
		if(bean != null){
			result = esConsolidado(bean.getTipoContenedor());
		}
		return result;
	}
	
	public  static boolean esConsolidado(int tipoContenedor){
		if(tipoContenedor == SAR.LCL){
			return true;
		}else{
			return false;
		}
	}

	
	
		
	public Boolean isSarOnHold() {
		
		if(this.folio != null && isSarOnHoldBySupplier() || isSarOnHoldBySAR()){  
			return true;
		}else{
			return false;
		}
	}
	
	public Boolean isSarOnHoldBySupplier() {
		
		if(this.folio != null && SAR.MAPA_BLOQUEOS.containsKey(this.proveedor+"|Prov")){
			return true;
		}else{
			return false;
		}
	}
	
	public Boolean isSarOnHoldBySAR() {
		
		if(this.folio != null && SAR.MAPA_BLOQUEOS.containsKey(this.folio+"|SAR")){
			return true;
		}else{
			return false;
		}
	}
	
	
	public Boolean esAereo() {
		return esAereo;
	}

	public void setEsAereo(Boolean esAereo) {
		this.esAereo = esAereo;
	}

	public Boolean getTieneFacura() {
		return tieneFacura;
	}

	public void setTieneFacura(Boolean tieneFacura) {
		this.tieneFacura = tieneFacura;
	}

	public Boolean getTieneBL() {
		return tieneBL;
	}

	public void setTieneBL(Boolean tieneBL) {
		this.tieneBL = tieneBL;
	}

	public Boolean getTienePackingList() {
		return tienePackingList;
	}

	public void setTienePackingList(Boolean tienePackingList) {
		this.tienePackingList = tienePackingList;
	}

	public Boolean getEsAereo() {
		return esAereo;
	}
	public Boolean esModificadoProveedor() {
		return modificadoProveedor;
	}
	public void setModificadoProveedor(Boolean modificadoProveedor) {
		this.modificadoProveedor = modificadoProveedor;
	}
	
	public Boolean esAceptadoConDiferencias() {
		return aceptadoConDiferencias;
	}

	public void setAceptadoConDiferencias(Boolean aceptadoConDiferencias) {
		this.aceptadoConDiferencias = aceptadoConDiferencias;
	}

	public Integer getAerolinea() {
		return aerolinea;
	}

	public void setAerolinea(Integer aerolinea) {
		this.aerolinea = aerolinea;
	}

	public String getAvion() {
		return avion;
	}

	public void setAvion(String avion) {
		this.avion = avion;
	}

	public Integer getLlegadaAvion() {
		return llegadaAvion;
	}

	public void setLlegadaAvion(Integer llegadaAvion) {
		this.llegadaAvion = llegadaAvion;
	}

	public String getTipoProducto() {
		return tipoProducto;
	}

	public void setTipoProducto(String tipoProducto) {
		this.tipoProducto = tipoProducto;
	}

	public Boolean esAprobadoSDI() {
		return aprobadoSDI;
	}

	public void setAprobadoSDI(Boolean aprobadoSDI) {
		this.aprobadoSDI = aprobadoSDI;
	}
	
	public Boolean getCerradoDocumentosProveedor() {
		return cerradoDocumentosProveedor;
	}
	public void setCerradoDocumentosProveedor(Boolean cerradoDocumentosProveedor) {
		this.cerradoDocumentosProveedor = cerradoDocumentosProveedor;
	}
	
	public Integer getFechaCierreDocumentosProveedor() {
		return fechaCierreDocumentosProveedor;
	}
	public void setFechaCierreDocumentosProveedor(
			Integer fechaCierreDocumentosProveedor) {
		this.fechaCierreDocumentosProveedor = fechaCierreDocumentosProveedor;
	}
	
	public Integer getFechaAprobadoSDI() {
		return fechaAprobadoSDI;
	}
	public void setFechaAprobadoSDI(Integer fechaAprobadoSDI) {
		this.fechaAprobadoSDI = fechaAprobadoSDI;
	}
	public Integer getFechaUltimoRechazo() {
		return fechaUltimoRechazo;
	}
	public Boolean getSarOnHold() {
		return sarOnHold;
	}
	public void setSarOnHold(Boolean sarOnHold) {
		this.sarOnHold = sarOnHold;
	}
	public void setFechaUltimoRechazo(Integer fechaUltimoRechazo) {
		this.fechaUltimoRechazo = fechaUltimoRechazo;
	}
	public Integer getFechaUltimaCorreccion() {
		return fechaUltimaCorreccion;
	}
	public void setFechaUltimaCorreccion(Integer fechaUltimaCorreccion) {
		this.fechaUltimaCorreccion = fechaUltimaCorreccion;
	}
	public Integer getRevision() {
		return revision;
	}
	public void setRevision(Integer revision) {
		this.revision = revision;
	}
	
	public Boolean getEsMultiple() {
		return esMultiple;
	}
	public Boolean getAprobadoSDI() {
		return aprobadoSDI;
	}
	public Boolean getModificadoProveedor() {
		return modificadoProveedor;
	}
	public Boolean getAceptadoConDiferencias() {
		return aceptadoConDiferencias;
	}
	public String getUsuarioAceptoRechazoSAR() {
		return usuarioAceptoRechazoSAR;
	}
	public void setUsuarioAceptoRechazoSAR(String usuarioAceptoRechazoSAR) {
		this.usuarioAceptoRechazoSAR = usuarioAceptoRechazoSAR;
	}
	
	
	

	/**
	 * @return the fecIniPlanning
	 */
	public Long getFecIniPlanning() {
		return fecIniPlanning;
	}
	/**
	 * @param fecIniPlanning the fecIniPlanning to set
	 */
	public void setFecIniPlanning(Long fecIniPlanning) {
		this.fecIniPlanning = fecIniPlanning;
	}
	public Long getFecIniImpDir() {
		return fecIniImpDir;
	}
	public void setFecIniImpDir(Long fecIniImpDir) {
		this.fecIniImpDir = fecIniImpDir;
	}
	public Integer getTinyFecIniImpDir() {
		return tinyFecIniImpDir;
	}
	public void setTinyFecIniImpDir(Integer tinyFecIniImpDir) {
		this.tinyFecIniImpDir = tinyFecIniImpDir;
	}
	/**
	 * @return the tinyFecIniPlanning
	 */
	public Integer getTinyFecIniPlanning() {
		return tinyFecIniPlanning;
	}
	/**
	 * @param tinyFecIniPlanning the tinyFecIniPlanning to set
	 */
	public void setTinyFecIniPlanning(Integer tinyFecIniPlanning) {
		this.tinyFecIniPlanning = tinyFecIniPlanning;
	}
	/**
	 * @return the fecIniShipping
	 */
	public Long getFecIniShipping() {
		return fecIniShipping;
	}
	/**
	 * @param fecIniShipping the fecIniShipping to set
	 */
	public void setFecIniShipping(Long fecIniShipping) {
		this.fecIniShipping = fecIniShipping;
	}
	public Integer getTinyFecIniShipping() {
		return tinyFecIniShipping;
	}
	public void setTinyFecIniShipping(Integer tinyFecIniShipping) {
		this.tinyFecIniShipping = tinyFecIniShipping;
	}
	/**
	 * @return the fecIniConsolidados
	 */
	public Long getFecIniConsolidados() {
		return fecIniConsolidados;
	}
	/**
	 * @param fecIniConsolidados the fecIniConsolidados to set
	 */
	public void setFecIniConsolidados(Long fecIniConsolidados) {
		this.fecIniConsolidados = fecIniConsolidados;
	}
	public Integer getTinyFecIniConsolidados() {
		return tinyFecIniConsolidados;
	}
	public void setTinyFecIniConsolidados(Integer tinyFecIniConsolidados) {
		this.tinyFecIniConsolidados = tinyFecIniConsolidados;
	}
	/**
	 * @return the fecIniBooking
	 */
	public Long getFecIniBooking() {
		return fecIniBooking;
	}
	/**
	 * @param fecIniBooking the fecIniBooking to set
	 */
	public void setFecIniBooking(Long fecIniBooking) {
		this.fecIniBooking = fecIniBooking;
	}
	public Integer getTinyFecIniBooking() {
		return tinyFecIniBooking;
	}
	public void setTinyFecIniBooking(Integer tinyFecIniBooking) {
		this.tinyFecIniBooking = tinyFecIniBooking;
	}
	/**
	 * @return the fecIniSDI
	 */
	public Long getFecIniSDI() {
		return fecIniSDI;
	}
	/**
	 * @param fecIniSDI the fecIniSDI to set
	 */
	public void setFecIniSDI(Long fecIniSDI) {
		this.fecIniSDI = fecIniSDI;
	}
	public Integer getTinyFecIniSDI() {
		return tinyFecIniSDI;
	}
	public void setTinyFecIniSDI(Integer tinyFecIniSDI) {
		this.tinyFecIniSDI = tinyFecIniSDI;
	}
	/**
	 * @return the fecIniEmbarque
	 */
	public Long getFecIniEmbarque() {
		return fecIniEmbarque;
	}
	/**
	 * @param fecIniEmbarque the fecIniEmbarque to set
	 */
	public void setFecIniEmbarque(Long fecIniEmbarque) {
		this.fecIniEmbarque = fecIniEmbarque;
	}
	/**
	 * @return the tinyFecIniEmbarque
	 */
	public Integer getTinyFecIniEmbarque() {
		return tinyFecIniEmbarque;
	}
	/**
	 * @param tinyFecIniEmbarque the tinyFecIniEmbarque to set
	 */
	public void setTinyFecIniEmbarque(Integer tinyFecIniEmbarque) {
		this.tinyFecIniEmbarque = tinyFecIniEmbarque;
	}
	public Boolean getTienePedidoDirecto() {
		return tienePedidoDirecto;
	}
	public void setTienePedidoDirecto(Boolean tienePedidoDirecto) {
		this.tienePedidoDirecto = tienePedidoDirecto;
	}
	public String getMultipleHtml() {
		return multipleHtml;
	}
	public void setMultipleHtml(String multipleHtml) {
		this.multipleHtml = multipleHtml;
	}
	public Boolean getEsRechazadoSDI() {
		return esRechazadoSDI;
	}
	public void setEsRechazadoSDI(Boolean esRechazadoSDI) {
		this.esRechazadoSDI = esRechazadoSDI;
	}
	/**
	 * @return the filtroBooking
	 */
	public Integer getFiltroBooking() {
		return filtroBooking;
	}
	/**
	 * @param filtroBooking the filtroBooking to set
	 */
	public void setFiltroBooking(Integer filtroBooking) {
		this.filtroBooking = filtroBooking;
	}
	/**
	 * @return the lstChat
	 */
	public List<BeanSarChat> getLstChat() {
		return lstChat;
	}
	/**
	 * @param lstChat the lstChat to set
	 */
	public void setLstChat(List<BeanSarChat> lstChat) {
		this.lstChat = lstChat;
	}
	/**
	 * @return the difPesoUserVSSystem
	 */
	public Double getDifPesoUserVSSystem() {
		return difPesoUserVSSystem;
	}
	/**
	 * @param difPesoUserVSSystem the difPesoUserVSSystem to set
	 */
	public void setDifPesoUserVSSystem(Double difPesoUserVSSystem) {
		this.difPesoUserVSSystem = difPesoUserVSSystem;
	}
	/**
	 * @return the difVolUserVSSystem
	 */
	public Double getDifVolUserVSSystem() {
		return difVolUserVSSystem;
	}
	/**
	 * @param difVolUserVSSystem the difVolUserVSSystem to set
	 */
	public void setDifVolUserVSSystem(Double difVolUserVSSystem) {
		this.difVolUserVSSystem = difVolUserVSSystem;
	}
	public Boolean getTieneDiferenciaMRP() {
		return tieneDiferenciaMRP;
	}
	public void setTieneDiferenciaMRP(Boolean tieneDiferenciaMRP) {
		this.tieneDiferenciaMRP = tieneDiferenciaMRP;
	}
	
	public Integer getCargaArchivoMRP() {
		return cargaArchivoMRP;
	}
	public void setCargaArchivoMRP(Integer cargaArchivoMRP) {
		this.cargaArchivoMRP = cargaArchivoMRP;
	}
	public String getNombreArchivoMRP() {
		return nombreArchivoMRP;
	}
	public void setNombreArchivoMRP(String nombreArchivoMRP) {
		this.nombreArchivoMRP = nombreArchivoMRP;
	}
	/**
	 * @return the needsAuthImpDir
	 */
	public Boolean getNeedsAuthImpDir() {
		return needsAuthImpDir;
	}
	/**
	 * @param needsAuthImpDir the needsAuthImpDir to set
	 */
	public void setNeedsAuthImpDir(Boolean needsAuthImpDir) {
		this.needsAuthImpDir = needsAuthImpDir;
	}
	/**
	 * @return the aprobadoDirImportaciones
	 */
	public Boolean getAprobadoDirImportaciones() {
		return aprobadoDirImportaciones;
	}
	/**
	 * @param aprobadoDirImportaciones the aprobadoDirImportaciones to set
	 */
	public void setAprobadoDirImportaciones(Boolean aprobadoDirImportaciones) {
		this.aprobadoDirImportaciones = aprobadoDirImportaciones;
	}
	/**
	 * @return the userApruebaDirImportaciones
	 */
	public String getUserApruebaDirImportaciones() {
		return userApruebaDirImportaciones;
	}
	/**
	 * @param userApruebaDirImportaciones the userApruebaDirImportaciones to set
	 */
	public void setUserApruebaDirImportaciones(String userApruebaDirImportaciones) {
		this.userApruebaDirImportaciones = userApruebaDirImportaciones;
	}
	/**
	 * @return the fechaAprobacionDirImportaciones
	 */
	public Integer getFechaAprobacionDirImportaciones() {
		return fechaAprobacionDirImportaciones;
	}
	/**
	 * @param fechaAprobacionDirImportaciones the fechaAprobacionDirImportaciones to set
	 */
	public void setFechaAprobacionDirImportaciones(
			Integer fechaAprobacionDirImportaciones) {
		this.fechaAprobacionDirImportaciones = fechaAprobacionDirImportaciones;
	}
	public String getCommentForImpDir() {
		return commentForImpDir;
	}
	public void setCommentForImpDir(String commentForImpDir) {
		this.commentForImpDir = commentForImpDir;
	}
	/**
	 * @return the piDate
	 */
	public Integer getPiDate() {
		return piDate;
	}
	/**
	 * @param piDate the piDate to set
	 */
	public void setPiDate(Integer piDate) {
		this.piDate = piDate;
	}
	/**
	 * @return the safetyStock
	 */
	public Double getSafetyStock() {
		return safetyStock;
	}
	/**
	 * @param safetyStock the safetyStock to set
	 */
	public void setSafetyStock(Double safetyStock) {
		this.safetyStock = safetyStock;
	}
	/**
	 * @return the forecastModel
	 */
	public String getForecastModel() {
		return forecastModel;
	}
	/**
	 * @param forecastModel the forecastModel to set
	 */
	public void setForecastModel(String forecastModel) {
		this.forecastModel = forecastModel;
	}
	/**
	 * @return the var8Sem
	 */
	public Double getVar8Sem() {
		return var8Sem;
	}
	/**
	 * @param var8Sem the var8Sem to set
	 */
	public void setVar8Sem(Double var8Sem) {
		this.var8Sem = var8Sem;
	}
	public Double getVar8SemanasDirectos() {
		return var8SemanasDirectos;
	}
	public void setVar8SemanasDirectos(Double var8SemanasDirectos) {
		this.var8SemanasDirectos = var8SemanasDirectos;
	}
	public Integer getFacturacionPedidosDirectos() {
		return facturacionPedidosDirectos;
	}
	public void setFacturacionPedidosDirectos(Integer facturacionPedidosDirectos) {
		this.facturacionPedidosDirectos = facturacionPedidosDirectos;
	}
	public String getImpDirComments() {
		return impDirComments;
	}
	public void setImpDirComments(String impDirComments) {
		this.impDirComments = impDirComments;
	}
	public Integer getAdelantoAtrasoETDImpDir() {
		return adelantoAtrasoETDImpDir;
	}
	public void setAdelantoAtrasoETDImpDir(Integer adelantoAtrasoETDImpDir) {
		this.adelantoAtrasoETDImpDir = adelantoAtrasoETDImpDir;
	}
	public Integer getEtdProveedor() {
		return etdProveedor;
	}
	public void setEtdProveedor(Integer etdProveedor) {
		this.etdProveedor = etdProveedor;
	}
	public Boolean getCargadoMRP() {
		return cargadoMRP;
	}
	public void setCargadoMRP(Boolean cargadoMRP) {
		this.cargadoMRP = cargadoMRP;
	}
	/**
	 * @return the notificacionMRP
	 */
	public Boolean getNotificacionMRP() {
		return notificacionMRP;
	}
	/**
	 * @param notificacionMRP the notificacionMRP to set
	 */
	public void setNotificacionMRP(Boolean notificacionMRP) {
		this.notificacionMRP = notificacionMRP;
	}
	public Boolean getEnRevisionConfirmFinal() {
		return enRevisionConfirmFinal;
	}
	public void setEnRevisionConfirmFinal(Boolean enRevisionConfirmFinal) {
		this.enRevisionConfirmFinal = enRevisionConfirmFinal;
	}
	public String getCommentRevFinalConfirm() {
		return commentRevFinalConfirm;
	}
	public Boolean getAceptadoRevFinalConfirm() {
		return aceptadoRevFinalConfirm;
	}
	public String getUsrAceptaRechazaRevFinal() {
		return usrAceptaRechazaRevFinal;
	}
	public void setCommentRevFinalConfirm(String commentRevFinalConfirm) {
		this.commentRevFinalConfirm = commentRevFinalConfirm;
	}
	public String getCommentVendorRevFinalConfirm() {
		return commentVendorRevFinalConfirm;
	}
	public void setCommentVendorRevFinalConfirm(String commentVendorRevFinalConfirm) {
		this.commentVendorRevFinalConfirm = commentVendorRevFinalConfirm;
	}
	public void setAceptadoRevFinalConfirm(Boolean aceptadoRevFinalConfirm) {
		this.aceptadoRevFinalConfirm = aceptadoRevFinalConfirm;
	}
	public void setUsrAceptaRechazaRevFinal(String usrAceptaRechazaRevFinal) {
		this.usrAceptaRechazaRevFinal = usrAceptaRechazaRevFinal;
	}
	public Boolean getCambiosRevFinalApplied() {
		return cambiosRevFinalApplied;
	}
	public void setCambiosRevFinalApplied(Boolean cambiosRevFinalApplied) {
		this.cambiosRevFinalApplied = cambiosRevFinalApplied;
	}
	public Integer getNumRevFinal() {
		return numRevFinal;
	}
	public void setNumRevFinal(Integer numRevFinal) {
		this.numRevFinal = numRevFinal;
	}
	public Boolean getAplicaBitacora() {
		return aplicaBitacora;
	}
	public void setAplicaBitacora(Boolean aplicaBitacora) {
		this.aplicaBitacora = aplicaBitacora;
	}
	public Boolean getBitacoraImportsDirCerrada() {
		return bitacoraImportsDirCerrada;
	}
	public void setBitacoraImportsDirCerrada(Boolean bitacoraImportsDirCerrada) {
		this.bitacoraImportsDirCerrada = bitacoraImportsDirCerrada;
	}
	public Integer getFecCierreBitacoraImpDir() {
		return fecCierreBitacoraImpDir;
	}
	public void setFecCierreBitacoraImpDir(Integer fecCierreBitacoraImpDir) {
		this.fecCierreBitacoraImpDir = fecCierreBitacoraImpDir;
	}
	public Integer getFecCierreLogImpDirIni() {
		return fecCierreLogImpDirIni;
	}
	public void setFecCierreLogImpDirIni(Integer fecCierreLogImpDirIni) {
		this.fecCierreLogImpDirIni = fecCierreLogImpDirIni;
	}
	public Integer getFecCierreLogImpDirFin() {
		return fecCierreLogImpDirFin;
	}
	public void setFecCierreLogImpDirFin(Integer fecCierreLogImpDirFin) {
		this.fecCierreLogImpDirFin = fecCierreLogImpDirFin;
	}
	public String getIntervalosFechaCreacion() {
		return intervalosFechaCreacion;
	}
	public void setIntervalosFechaCreacion(String intervalosFechaCreacion) {
		this.intervalosFechaCreacion = intervalosFechaCreacion;
	}
	public String getIntervalosFechaEmbarcacion() {
		return intervalosFechaEmbarcacion;
	}
	public void setIntervalosFechaEmbarcacion(String intervalosFechaEmbarcacion) {
		this.intervalosFechaEmbarcacion = intervalosFechaEmbarcacion;
	}
	public Boolean getTieneProdsNuevos() {
		return tieneProdsNuevos;
	}
	public void setTieneProdsNuevos(Boolean tieneProdsNuevos) {
		this.tieneProdsNuevos = tieneProdsNuevos;
	}
	public Boolean getEtdRealWarning() {
		return etdRealWarning;
	}
	public void setEtdRealWarning(Boolean etdRealWarning) {
		this.etdRealWarning = etdRealWarning;
	}
	public String getUsrEtdRealWarning() {
		return usrEtdRealWarning;
	}
	public void setUsrEtdRealWarning(String usrEtdRealWarning) {
		this.usrEtdRealWarning = usrEtdRealWarning;
	}
	public Boolean getNeedsAuthPlanningMgr() {
		return needsAuthPlanningMgr;
	}
	public void setNeedsAuthPlanningMgr(Boolean needsAuthPlanningMgr) {
		this.needsAuthPlanningMgr = needsAuthPlanningMgr;
	}
	public Integer getVersionSDI() {
		return versionSDI;
	}
	public void setVersionSDI(Integer versionSDI) {
		this.versionSDI = versionSDI;
	}
	public Boolean getPreciosLiberados() {
		return preciosLiberados;
	}
	public void setPreciosLiberados(Boolean preciosLiberados) {
		this.preciosLiberados = preciosLiberados;
	}
	public Boolean getPreciosEnRevision() {
		return preciosEnRevision;
	}
	public void setPreciosEnRevision(Boolean preciosEnRevision) {
		this.preciosEnRevision = preciosEnRevision;
	}
	public Boolean getPreciosRevisados() {
		return preciosRevisados;
	}
	public void setPreciosRevisados(Boolean preciosRevisados) {
		this.preciosRevisados = preciosRevisados;
	}
	public String getSealNumber() {
		return sealNumber;
	}
	public void setSealNumber(String sealNumber) {
		this.sealNumber = sealNumber;
	}
	public String getContenedorProveedor() {
		return contenedorProveedor;
	}
	public void setContenedorProveedor(String contenedorProveedor) {
		this.contenedorProveedor = contenedorProveedor;
	}
	public String getDisagreeComments() {
		return disagreeComments;
	}
	public void setDisagreeComments(String disagreeComments) {
		this.disagreeComments = disagreeComments;
	}
	public boolean isEnRevicionIDA() {
		return isEnRevicionIDA;
	}
	public void setEnRevicionIDA(boolean isEnRevicionIDA) {
		this.isEnRevicionIDA = isEnRevicionIDA;
	}
	public boolean isBitacoraIDA() {
		return bitacoraIDA;
	}
	public void setBitacoraIDA(boolean bitacoraIDA) {
		this.bitacoraIDA = bitacoraIDA;
	}
	public boolean isBitacoraIDACerrada() {
		return bitacoraIDACerrada;
	}
	public void setBitacoraIDACerrada(boolean bitacoraIDACerrada) {
		this.bitacoraIDACerrada = bitacoraIDACerrada;
	}

	public String getAlmacen() {
		return almacen;
	}

	public void setAlmacen(String almacen) {
		this.almacen = almacen;
	}
	
	public boolean isPm() {
		return pm;
	}
	public void setPm(boolean pm) {
		this.pm = pm;
	}
	
	public boolean isSife() {
		return sife;
	}
	public void setSife(boolean sife) {
		this.sife = sife;
	}
	public String getConcatenado() {
		return concatenado;
	}

	public void setConcatenado(String concatenado) {
		this.concatenado = concatenado;
	}
	
	

}