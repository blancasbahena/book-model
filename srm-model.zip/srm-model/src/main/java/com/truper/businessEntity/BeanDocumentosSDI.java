package com.truper.businessEntity;

import java.math.BigDecimal;
import java.util.Date;

import com.truper.infra.businessEntities.BaseBusinessEntity;

public class BeanDocumentosSDI extends BaseBusinessEntity implements Cloneable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Integer id;
	private Integer versionSDI;
	private String proveedor;
	private String booking;
	private Date fechaAceptaProveedor;
	private Date fechaRechazo;
	private Integer versionFacturas;
	private Integer versionPK;
	private Integer versionBL;
	private Integer versionPreBL;
	private Boolean facturasCompletas;
	private Boolean packingListGenerado;
	private Boolean preBLGenerado;
	private Boolean blGenerado;
	private Boolean tieneOtrosDocumentos;
	private Date fechaCreacion;
	private String comentariosSDI;
	private String usuarioRechazo;
	
	private Integer cartons;
	private Integer pallets;
	private Integer bulks;
	
	private BigDecimal subTotal;
	private BigDecimal subTotalOthers;
	private BigDecimal subTotalFocs;
	private BigDecimal total;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getVersionSDI() {
		return versionSDI;
	}

	public void setVersionSDI(Integer versionSDI) {
		this.versionSDI = versionSDI;
	}

	public String getProveedor() {
		return proveedor;
	}

	public void setProveedor(String proveedor) {
		this.proveedor = proveedor;
	}

	public String getBooking() {
		return booking;
	}

	public void setBooking(String booking) {
		this.booking = booking;
	}

	public Date getFechaAceptaProveedor() {
		return fechaAceptaProveedor;
	}

	public void setFechaAceptaProveedor(Date fechaAceptaProveedor) {
		this.fechaAceptaProveedor = fechaAceptaProveedor;
	}

	public Date getFechaRechazo() {
		return fechaRechazo;
	}

	public void setFechaRechazo(Date fechaRechazo) {
		this.fechaRechazo = fechaRechazo;
	}

	public Integer getVersionFacturas() {
		return versionFacturas;
	}

	public void setVersionFacturas(Integer versionFacturas) {
		this.versionFacturas = versionFacturas;
	}

	public Integer getVersionPK() {
		return versionPK;
	}

	public void setVersionPK(Integer versionPK) {
		this.versionPK = versionPK;
	}

	public Integer getVersionBL() {
		return versionBL;
	}

	public void setVersionBL(Integer versionBL) {
		this.versionBL = versionBL;
	}

	public Integer getVersionPreBL() {
		return versionPreBL;
	}

	public void setVersionPreBL(Integer versionPreBL) {
		this.versionPreBL = versionPreBL;
	}

	public Boolean getFacturasCompletas() {
		return facturasCompletas;
	}

	public void setFacturasCompletas(Boolean facturasCompletas) {
		this.facturasCompletas = facturasCompletas;
	}

	public Boolean getPackingListGenerado() {
		return packingListGenerado;
	}

	public void setPackingListGenerado(Boolean packingListGenerado) {
		this.packingListGenerado = packingListGenerado;
	}

	public Boolean getPreBLGenerado() {
		return preBLGenerado;
	}

	public void setPreBLGenerado(Boolean preBLGenerado) {
		this.preBLGenerado = preBLGenerado;
	}

	public Boolean getBlGenerado() {
		return blGenerado;
	}

	public void setBlGenerado(Boolean blGenerado) {
		this.blGenerado = blGenerado;
	}

	public Boolean getTieneOtrosDocumentos() {
		return tieneOtrosDocumentos;
	}

	public void setTieneOtrosDocumentos(Boolean tieneOtrosDocumentos) {
		this.tieneOtrosDocumentos = tieneOtrosDocumentos;
	}

	public Date getFechaCreacion() {
		return fechaCreacion;
	}

	public void setFechaCreacion(Date fechaCreacion) {
		this.fechaCreacion = fechaCreacion;
	}

	public String getComentariosSDI() {
		return comentariosSDI;
	}

	public void setComentariosSDI(String comentariosSDI) {
		this.comentariosSDI = comentariosSDI;
	}

	public String getUsuarioRechazo() {
		return usuarioRechazo;
	}

	public void setUsuarioRechazo(String usuarioRechazo) {
		this.usuarioRechazo = usuarioRechazo;
	}
	public Integer getCartons() {
		return cartons;
	}

	public void setCartons(Integer cartons) {
		this.cartons = cartons;
	}

	public Integer getPallets() {
		return pallets;
	}

	public void setPallets(Integer pallets) {
		this.pallets = pallets;
	}

	public Integer getBulks() {
		return bulks;
	}

	public void setBulks(Integer bulks) {
		this.bulks = bulks;
	}

	public BigDecimal getSubTotal() {
		return subTotal;
	}

	public void setSubTotal(BigDecimal subTotal) {
		this.subTotal = subTotal;
	}

	public BigDecimal getSubTotalOthers() {
		return subTotalOthers;
	}

	public void setSubTotalOthers(BigDecimal subTotalOthers) {
		this.subTotalOthers = subTotalOthers;
	}

	public BigDecimal getSubTotalFocs() {
		return subTotalFocs;
	}

	public void setSubTotalFocs(BigDecimal subTotalFocs) {
		this.subTotalFocs = subTotalFocs;
	}

	public BigDecimal getTotal() {
		return total;
	}

	public void setTotal(BigDecimal total) {
		this.total = total;
	}

}
