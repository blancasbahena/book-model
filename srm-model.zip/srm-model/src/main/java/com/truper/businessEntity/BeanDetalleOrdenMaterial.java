package com.truper.businessEntity;

import java.math.BigDecimal;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter 
public class BeanDetalleOrdenMaterial {

	private String numeroOrden;
	private String posicion;
	private String material;
	private String centro;
	private BigDecimal cantidad;
	private BigDecimal precioUnitario;
	private String planeador;
	private int fechaProforma;
	private String moneda;
	private String unidadMedida;
	private String condicionPago;
	private BigDecimal cantidadUnidadMedida;
	private BigDecimal factorCantidadUnidadMedida;

	public BeanDetalleOrdenMaterial() {
		super();
	}

	public BeanDetalleOrdenMaterial(String numeroOrden, String posicion, String material, String centro,
			BigDecimal cantidad, BigDecimal precioUnitario, String planeador, int fechaProforma, String moneda,
			String unidadMedida) {
		this();
		this.numeroOrden = numeroOrden;
		this.posicion = posicion;
		this.material = material;
		this.centro = centro;
		this.cantidad = cantidad;
		this.precioUnitario = precioUnitario;
		this.planeador = planeador;
		this.fechaProforma = fechaProforma;
		this.moneda = moneda;
		this.unidadMedida = unidadMedida;
	}

	

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("BeanDetalleOrdenMaterial [numeroOrden=");
		builder.append(numeroOrden);
		builder.append(", posicion=");
		builder.append(posicion);
		builder.append(", material=");
		builder.append(material);
		builder.append(", centro=");
		builder.append(centro);
		builder.append(", cantidad=");
		builder.append(cantidad);
		builder.append(", precioUnitario=");
		builder.append(precioUnitario);
		builder.append(", planeador=");
		builder.append(planeador);
		builder.append(", fechaProforma=");
		builder.append(fechaProforma);
		builder.append(", moneda=");
		builder.append(moneda);
		builder.append(", unidadMedida=");
		builder.append(unidadMedida);
		builder.append(", cantidadUnidadMedida=");
		builder.append( cantidadUnidadMedida);
		builder.append(", factorCantidadUnidadMedida=");
		builder.append(factorCantidadUnidadMedida);
		builder.append("]");
		return builder.toString();
	}

}
