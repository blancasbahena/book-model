package com.truper.businessEntity;


import java.util.Date;

import com.truper.infra.businessEntities.BaseBusinessEntity;

public class SARRevisionIDABean  extends BaseBusinessEntity implements Cloneable {
								
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Integer folio;
	private Date FechaAccion;
	private Integer ETDNuevo;
	private boolean aceptado;
	private boolean tipo;
	private Integer cc;
	private String origenDeVista;
	private String userName;
	private Date createDate;
	
	public Integer getFolio() {
		return folio;
	}
	public void setFolio(Integer folio) {
		this.folio = folio;
	}
	public Date getFechaAccion() {
		return FechaAccion;
	}
	public void setFechaAccion(Date fechaAccion) {
		FechaAccion = fechaAccion;
	}
	public Integer getETDNuevo() {
		return ETDNuevo;
	}
	public void setETDNuevo(Integer eTDNuevo) {
		ETDNuevo = eTDNuevo;
	}
	public boolean isAceptado() {
		return aceptado;
	}
	public void setAceptado(boolean aceptado) {
		this.aceptado = aceptado;
	}
	public boolean isTipo() {
		return tipo;
	}
	public void setTipo(boolean tipo) {
		this.tipo = tipo;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public Integer getCc() {
		return cc;
	}
	public void setCc(Integer cc) {
		this.cc = cc;
	}
	
	public String getOrigenDeVista(){
		return origenDeVista;
	}
	
	public void setOrigenDeVista(String origenDeVista){
		this.origenDeVista = origenDeVista;
	}
	
	public String getUserName(){
		return userName;
	}
	
	public void setUserName(String userName){
		this.userName = userName;
	}
	
	public Date getCreateDate(){
		return createDate;
	}
	
	public void setCreateDate(Date createDate){
		this.createDate = createDate;
	}
	
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("SARRevisionIDABean [getFolio()=");
		builder.append(getFolio());
		builder.append(", getFechaAccion()=");
		builder.append(getFechaAccion());
		builder.append(", getETDNuevo()=");
		builder.append(getETDNuevo());
		builder.append(", isAceptado()=");
		builder.append(isAceptado());
		builder.append(", isTipo()=");
		builder.append(isTipo());
		builder.append(", getCc()=");
		builder.append(getCc());		
		builder.append(", getOrigenDeVista()=");
		builder.append(getOrigenDeVista());		
		builder.append(", getUserName()=");
		builder.append(getUserName());
		builder.append(", getCreateDate()=");
		builder.append(getCreateDate());
		builder.append("]");
		return builder.toString();
	}

}
