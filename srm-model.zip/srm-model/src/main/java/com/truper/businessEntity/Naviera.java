package com.truper.businessEntity;

import java.util.HashMap;

import com.truper.infra.businessEntities.BaseBusinessEntity;

public class Naviera extends BaseBusinessEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3424383152891894991L;
	private int clave;
	private String nombre;
	private HashMap<String, BeanPuerto> puertosOrigen;
	
	public Naviera(int clave, String nombre){
		this.clave = clave;
		this.nombre = nombre;
		this.puertosOrigen= new HashMap<String, BeanPuerto>(); 
	}
	
	public void agregaPuertoOrigen(String clavePuerto, BeanPuerto puerto){
		puertosOrigen.put(clavePuerto, puerto);
	}

	public int getClave() {
		return clave;
	}

	public String getNombre() {
		return nombre;
	}

	
}
