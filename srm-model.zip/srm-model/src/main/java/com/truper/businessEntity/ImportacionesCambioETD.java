package com.truper.businessEntity;

import java.math.BigDecimal;

import com.truper.infra.businessEntities.BaseBusinessEntity;


public class ImportacionesCambioETD extends BaseBusinessEntity {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 536031302297838256L;
	private int id;
	private int po;
	private int posicion;
	private BigDecimal cantidad;
	private int fechaETD;
	private int fechaETDNew;
	private int parte;
	private boolean acepta;
	private long fechaOperacion;
	

	/** Setters & getters*/
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getPo() {
		return po;
	}
	public void setPo(int po) {
		this.po = po;
	}
	public int getPosicion() {
		return posicion;
	}
	public void setPosicion(int posicion) {
		this.posicion = posicion;
	}
	public BigDecimal getCantidad() {
		return cantidad;
	}
	public void setCantidad(BigDecimal cantidad) {
		this.cantidad = cantidad;
	}
	public int getFechaETD() {
		return fechaETD;
	}
	public void setFechaETD(int fechaETD) {
		this.fechaETD = fechaETD;
	}
	public int getFechaETDNew() {
		return fechaETDNew;
	}
	public void setFechaETDNew(int fechaETDNew) {
		this.fechaETDNew = fechaETDNew;
	}
	public int getParte() {
		return parte;
	}
	public void setParte(int parte) {
		this.parte = parte;
	}
	public boolean isAcepta() {
		return acepta;
	}
	public void setAcepta(boolean acepta) {
		this.acepta = acepta;
	}
	public long getFechaOperacion() {
		return fechaOperacion;
	}
	public void setFechaOperacion(long fechaOperacion) {
		this.fechaOperacion = fechaOperacion;
	}
	
	
}
