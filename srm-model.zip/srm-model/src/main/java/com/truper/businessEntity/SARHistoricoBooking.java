package com.truper.businessEntity;

import com.truper.infra.businessEntities.BaseBusinessEntity;

public class SARHistoricoBooking extends BaseBusinessEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3311684809424467949L;
	private Integer folio;
	private String tipoSar;
	private String booking;
	private String barcoSugerido;
	private Integer etd;
	private Integer eta;
	private String contenedor;
	private String usuario;
	private String usuarioString;
	private String viaje;
	private Integer fechaRegistro;
	private double fechaLong;
	private String comentarioTruperBooking;
	private Integer naviera;
	private String puertoOrigen;
	private String puertoDestino;
	private Integer tipoContenedor;
	

	/****** Getters y Setters *******/
	public Integer getFolio() {
		return folio;
	}

	public void setFolio(Integer folio) {
		this.folio = folio;
	}

	public String getTipoSar() {
		return tipoSar;
	}

	public void setTipoSar(String tipoSar) {
		this.tipoSar = tipoSar;
	}

	public String getBooking() {
		return booking;
	}

	public void setBooking(String booking) {
		this.booking = booking;
	}

	public String getBarcoSugerido() {
		return barcoSugerido;
	}

	public void setBarcoSugerido(String barcoSugerido) {
		this.barcoSugerido = barcoSugerido;
	}

	public Integer getEtd() {
		return etd;
	}

	public void setEtd(Integer etd) {
		this.etd = etd;
	}

	public String getContenedor() {
		return contenedor;
	}

	public void setContenedor(String contenedor) {
		this.contenedor = contenedor;
	}

	public String getUsuario() {
		return usuario;
	}

	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}

	public String getUsuarioString() {
		return usuarioString;
	}

	public void setUsuarioString(String usuarioString) {
		this.usuarioString = usuarioString;
	}

	public Integer getFechaRegistro() {
		return fechaRegistro;
	}

	public void setFechaRegistro(Integer fechaRegistro) {
		this.fechaRegistro = fechaRegistro;
	}

	public double getFechaLong() {
		return fechaLong;
	}

	public void setFechaLong(double fechaLong) {
		this.fechaLong = fechaLong;
	}

	public String getComentarioTruperBooking() {
		return comentarioTruperBooking;
	}

	public void setComentarioTruperBooking(String comentarioTruperBooking) {
		this.comentarioTruperBooking = comentarioTruperBooking;
	}

	public Integer getEta() {
		return eta;
	}

	public void setEta(Integer eta) {
		this.eta = eta;
	}

	public String getViaje() {
		return viaje;
	}

	public void setViaje(String viaje) {
		this.viaje = viaje;
	}

	public Integer getNaviera() {
		return naviera;
	}

	public void setNaviera(Integer naviera) {
		this.naviera = naviera;
	}

	public String getPuertoOrigen() {
		return puertoOrigen;
	}

	public void setPuertoOrigen(String puertoOrigen) {
		this.puertoOrigen = puertoOrigen;
	}

	public String getPuertoDestino() {
		return puertoDestino;
	}

	public void setPuertoDestino(String puertoDestino) {
		this.puertoDestino = puertoDestino;
	}

	public Integer getTipoContenedor() {
		return tipoContenedor;
	}

	public void setTipoContenedor(Integer tipoContenedor) {
		this.tipoContenedor = tipoContenedor;
	}

}
