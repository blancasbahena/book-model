package com.truper.businessEntity.SRM;

import com.truper.infra.businessEntities.BaseBusinessEntity;

public class TipoNota extends BaseBusinessEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = -9090130785551988187L;

	private Integer id;
	private String tipoNota;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getTipoNota() {
		return tipoNota;
	}

	public void setTipoNota(String tipoNota) {
		this.tipoNota = tipoNota;
	}

}
