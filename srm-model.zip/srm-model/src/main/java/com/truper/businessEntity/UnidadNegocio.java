package com.truper.businessEntity;

import java.util.HashSet;

import com.truper.infra.businessEntities.BaseBusinessEntity;

public class UnidadNegocio extends BaseBusinessEntity {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -5809460427275969564L;
	private int id;
	private String mailContacto;
	private String unidadNegocio;
	private String nombre;
	private boolean status;
	private String celulas;
	private HashSet<String> celulasHash;
	
	public String getMailContacto() {
		return mailContacto;
	}
	public void setMailContacto(String mailContacto) {
		this.mailContacto = mailContacto;
	}
	public String getUnidadNegocio() {
		return unidadNegocio;
	}
	public void setUnidadNegocio(String unidadNegocio) {
		this.unidadNegocio = unidadNegocio;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public boolean isStatus() {
		return status;
	}
	public void setStatus(boolean status) {
		this.status = status;
	}
	public String getCelulas() {
		return celulas;
	}
	public void setCelulas(String celulas) {
		this.celulas = celulas;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public HashSet<String> getCelulasHash() {
		return celulasHash;
	}
	public void setCelulasHash(HashSet<String> celulasHash) {
		this.celulasHash = celulasHash;
	}	
	
}
