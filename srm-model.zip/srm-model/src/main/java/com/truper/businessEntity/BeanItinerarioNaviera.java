package com.truper.businessEntity;

import java.io.InputStream;

import com.truper.infra.businessEntities.BaseBusinessEntity;

public class BeanItinerarioNaviera extends BaseBusinessEntity{

	/**
	 * 
	 */
	private static final long serialVersionUID = -3308767247694265927L;
	private Integer folio;
	private Long timeMillis;
	private Integer creationDate;
	private InputStream imgData;
	
	public Integer getFolio() {
		return folio;
	}
	public void setFolio(Integer folio) {
		this.folio = folio;
	}
	public Long getTimeMillis() {
		return timeMillis;
	}
	public void setTimeMillis(Long timeMillis) {
		this.timeMillis = timeMillis;
	}
	public Integer getCreationDate() {
		return creationDate;
	}
	public void setCreationDate(Integer creationDate) {
		this.creationDate = creationDate;
	}
	public InputStream getImgData() {
		return imgData;
	}
	public void setImgData(InputStream imgData) {
		this.imgData = imgData;
	}
	public Integer getSarStatus() {
		return sarStatus;
	}
	public void setSarStatus(Integer sarStatus) {
		this.sarStatus = sarStatus;
	}
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	private Integer sarStatus;
	private String user;
	
}
