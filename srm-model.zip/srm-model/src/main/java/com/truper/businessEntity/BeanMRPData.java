package com.truper.businessEntity;

import com.truper.infra.businessEntities.BaseBusinessEntity;

public class BeanMRPData extends BaseBusinessEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6225251395275128579L;
	private Integer folio;
	private String po;
	private Integer posicion;
	private Integer material;
	private Double height;
	private Double width;
	private Double length;
	private Double volume;
	private Double weight;
	private Integer inner;
	private Integer master;
	private String cveProveedor;
	private Integer fechaRegistro;
	private Integer status;
	private Integer statusSAR;
	private String usuarioCarga;
	
	public Integer getFolio() {
		return folio;
	}
	public void setFolio(Integer folio) {
		this.folio = folio;
	}
	public String getPo() {
		return po;
	}
	public void setPo(String po) {
		this.po = po;
	}
	public Integer getPosicion() {
		return posicion;
	}
	public void setPosicion(Integer posicion) {
		this.posicion = posicion;
	}
	public Integer getMaterial() {
		return material;
	}
	public void setMaterial(Integer material) {
		this.material = material;
	}
	public Double getHeight() {
		return height;
	}
	public void setHeight(Double height) {
		this.height = height;
	}
	public Double getWidth() {
		return width;
	}
	public void setWidth(Double width) {
		this.width = width;
	}
	public Double getLength() {
		return length;
	}
	public void setLength(Double length) {
		this.length = length;
	}
	public Double getVolume() {
		return volume;
	}
	public void setVolume(Double volume) {
		this.volume = volume;
	}
	public Double getWeight() {
		return weight;
	}
	public void setWeight(Double weight) {
		this.weight = weight;
	}
	public Integer getInner() {
		return inner;
	}
	public void setInner(Integer inner) {
		this.inner = inner;
	}
	public Integer getMaster() {
		return master;
	}
	public void setMaster(Integer master) {
		this.master = master;
	}
	public String getCveProveedor() {
		return cveProveedor;
	}
	public void setCveProveedor(String cveProveedor) {
		this.cveProveedor = cveProveedor;
	}
	public Integer getFechaRegistro() {
		return fechaRegistro;
	}
	public void setFechaRegistro(Integer fechaRegistro) {
		this.fechaRegistro = fechaRegistro;
	}
	public Integer getStatus() {
		return status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
	public Integer getStatusSAR() {
		return statusSAR;
	}
	public void setStatusSAR(Integer statusSAR) {
		this.statusSAR = statusSAR;
	}
	public String getUsuarioCarga() {
		return usuarioCarga;
	}
	public void setUsuarioCarga(String usuarioCarga) {
		this.usuarioCarga = usuarioCarga;
	}
}
