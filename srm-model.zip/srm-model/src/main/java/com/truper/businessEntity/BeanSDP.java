package com.truper.businessEntity;

import java.util.Date;

import com.truper.infra.businessEntities.BaseBusinessEntity;

public class BeanSDP  extends BaseBusinessEntity implements Cloneable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int folio;
	private Date fechaIngreso;
	private int status;
	private double montoTotal;
	private double montoMax;
	private boolean recargaDatos;
	private Integer folioConsolidado;
	private Integer etdNoFormato;
	
	public int getFolio() {
		return folio;
	}
	public void setFolio(int folio) {
		this.folio = folio;
	}
	public Date getFechaIngreso() {
		return fechaIngreso;
	}
	public void setFechaIngreso(Date fechaIngreso) {
		this.fechaIngreso = fechaIngreso;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public double getMontoTotal() {
		return montoTotal;
	}
	public void setMontoTotal(double montoTotal) {
		this.montoTotal = montoTotal;
	}
	public double getMontoMax() {
		return montoMax;
	}
	public void setMontoMax(double montoMax) {
		this.montoMax = montoMax;
	}
	public boolean isRecargaDatos() {
		return recargaDatos;
	}
	public void setRecargaDatos(boolean recargaDatos) {
		this.recargaDatos = recargaDatos;
	}
	public Integer getFolioConsolidado() {
		return folioConsolidado;
	}
	public void setFolioConsolidado(Integer folioConsolidado) {
		this.folioConsolidado = folioConsolidado;
	}
	public Integer getEtdNoFormato() {
		return etdNoFormato;
	}
	public void setEtdNoFormato(Integer etdNoFormato) {
		this.etdNoFormato = etdNoFormato;
	}
	
}
