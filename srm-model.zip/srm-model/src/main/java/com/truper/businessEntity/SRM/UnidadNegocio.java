package com.truper.businessEntity.SRM;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.Table;

import com.truper.infra.businessEntities.BaseBusinessEntity;
import com.truper.infra.businessEntities.Usuario;

@Table(name = "srm_UNIDAD_NEGOCIO")
@Entity
public class UnidadNegocio extends BaseBusinessEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7543500844244723422L;

	@Id
	@Column(name = "ID")
	private Integer id;
	@JoinTable(name = "SRM_USUARIO_UNIDAD_NEGOCIO", joinColumns = {
			@JoinColumn(table = "srm_UNIDAD_NEGOCIO", name = "ID_UNIDAD_NEGOCIO", referencedColumnName = "ID"),
			@JoinColumn(table = "srm_usuario", name = "ID_USUARIO", referencedColumnName = "ID") })
	private Usuario usuario;
	@Column(name = "UNIDAD_NEGOCIO")
	private String unidadNegocio;
	@Column(name = "TIPO_UNIDAD_NEGOCIO")
	private Integer tipoUnidadNegocio;
	@Column(name = "ID_UNIDAD_NEGOCIO_SUPERIOR")
	private Integer idUnidadNegocioSuperior;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getUnidadNegocio() {
		return unidadNegocio;
	}

	public void setUnidadNegocio(String unidadNegocio) {
		this.unidadNegocio = unidadNegocio;
	}

	public Integer getTipoUnidadNegocio() {
		return tipoUnidadNegocio;
	}

	public void setTipoUnidadNegocio(Integer tipoUnidadNegocio) {
		this.tipoUnidadNegocio = tipoUnidadNegocio;
	}

	public Integer getIdUnidadNegocioSuperior() {
		return idUnidadNegocioSuperior;
	}

	public void setIdUnidadNegocioSuperior(Integer idUnidadNegocioSuperior) {
		this.idUnidadNegocioSuperior = idUnidadNegocioSuperior;
	}

	public Usuario getUsuario() {
		return usuario;
	}

	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}

}
