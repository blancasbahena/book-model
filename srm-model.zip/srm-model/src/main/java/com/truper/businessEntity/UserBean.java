package com.truper.businessEntity;

import java.util.Set;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class UserBean extends UserProfileBean {
	private static final long serialVersionUID = -8968678659934506250L;
	private Integer idUser;
	private String userName;
	private String pwd;
	private Integer lastPwdChangeDate;
	private Boolean cambiarPwd;
	private String realName;
	private String userEmail;
	private Integer userProfile;
	private Boolean active;
	private Integer userType;
	private Boolean renovarPwd;
	private Boolean isTemporalUser;
	private Long creationDate;
	private String creationUser;
	private Set<String> bus;
	private Set<String> fabricas;
	private String userNameReal;
	

	public Boolean isActive() {
		return active;
	}
}