package com.truper.businessEntity;

import java.math.BigDecimal;
import java.util.Date;

import com.truper.bpm.enums.TipoPosicionEnum;

public class BeanPoPosicionWithOther implements Comparable<BeanPoPosicionWithOther> {

	private String po;
	private int posicion;
	private String material;
	private String material_descripcion;
	private int cantidad;
	private BigDecimal precioUnitario;
	private TipoPosicionEnum tipo;
	private String subTipo;
	private boolean pago;
	private BigDecimal precioUnitarioSolicitado;
	private boolean preciosRevisados;
	private String moneda;
	private String unidadMedida;
	private Date fechaEmbarque;
	private String planeador;
	private String centro;

	public BeanPoPosicionWithOther(String po, int posicion, String material) {
		super();
		this.po = po;
		this.posicion = posicion;
		this.material = material;
	}

	public BeanPoPosicionWithOther(String po, int posicion, String material, int cantidad) {
		this(po, posicion, material);
		this.cantidad = cantidad;
	}

	public BeanPoPosicionWithOther(String po, int posicion, String material, int cantidad, BigDecimal precioUnitario) {
		this(po, posicion, material, cantidad);
		this.precioUnitario = precioUnitario;
	}

	public String getPo() {
		return po;
	}

	public void setPo(String po) {
		this.po = po;
	}

	public int getPosicion() {
		return posicion;
	}

	public void setPosicion(int posicion) {
		this.posicion = posicion;
	}

	public String getMaterial() {
		return material;
	}

	public void setMaterial(String material) {
		this.material = material;
	}

	public String getMaterial_descripcion() {
		return material_descripcion;
	}

	public void setMaterial_descripcion(String material_descripcion) {
		this.material_descripcion = material_descripcion;
	}

	public int getCantidad() {
		return cantidad;
	}

	public void setCantidad(int cantidad) {
		this.cantidad = cantidad;
	}

	public BigDecimal getPrecioUnitario() {
		return precioUnitario;
	}

	public void setPrecioUnitario(BigDecimal precioUnitario) {
		this.precioUnitario = precioUnitario;
	}

	public TipoPosicionEnum getTipo() {
		return tipo;
	}

	public void setTipo(TipoPosicionEnum tipo) {
		this.tipo = tipo;
	}

	public String getSubTipo() {
		return subTipo;
	}

	public void setSubTipo(String subTipo) {
		this.subTipo = subTipo;
	}

	public boolean isPago() {
		return pago;
	}

	public void setPago(boolean pago) {
		this.pago = pago;
	}

	public BigDecimal getPrecioUnitarioSolicitado() {
		return precioUnitarioSolicitado;
	}

	public void setPrecioUnitarioSolicitado(BigDecimal precioUnitarioSolicitado) {
		this.precioUnitarioSolicitado = precioUnitarioSolicitado;
	}

	public boolean isPreciosRevisados() {
		return preciosRevisados;
	}

	public void setPreciosRevisados(boolean preciosRevisados) {
		this.preciosRevisados = preciosRevisados;
	}

	public String getMoneda() {
		return moneda;
	}

	public void setMoneda(String moneda) {
		this.moneda = moneda;
	}

	public String getUnidadMedida() {
		return unidadMedida;
	}

	public void setUnidadMedida(String unidadMedida) {
		this.unidadMedida = unidadMedida;
	}

	public Date getFechaEmbarque() {
		return fechaEmbarque;
	}

	public void setFechaEmbarque(Date fechaEmbarque) {
		this.fechaEmbarque = fechaEmbarque;
	}

	public String getPlaneador() {
		return planeador;
	}

	public void setPlaneador(String planeador) {
		this.planeador = planeador;
	}

	public String getCentro() {
		return centro;
	}

	public void setCentro(String centro) {
		this.centro = centro;
	}

	@Override
	public int compareTo(BeanPoPosicionWithOther bean) {
		int valor = getTipo().compareTo(bean.getTipo());
		if (valor != 0) {
			return valor;
		}
		if (getPo() == null && bean.getPo() != null) {
			return 1;
		} else if (getPo() == null && bean.getPo() == null) {
			valor = 0;
		} else if (getPo() != null && bean.getPo() == null) {
			return -1;
		} else {
			valor = getPo().compareTo(bean.getPo());
		}
		if (valor != 0) {
			return valor;
		}
		valor = Integer.compare(getPosicion(), bean.getPosicion());
		if (valor != 0) {
			return valor;
		}
		valor = getMaterial().compareToIgnoreCase(getMaterial());
		return valor;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("BeanPoPosicionWithOther [po=");
		builder.append(po);
		builder.append(", posicion=");
		builder.append(posicion);
		builder.append(", material=");
		builder.append(material);
		builder.append(", material_descripcion=");
		builder.append(material_descripcion);
		builder.append(", cantidad=");
		builder.append(cantidad);
		builder.append(", precioUnitario=");
		builder.append(precioUnitario);
		builder.append(", tipo=");
		builder.append(tipo);
		builder.append(", subTipo=");
		builder.append(subTipo);
		builder.append(", pago=");
		builder.append(pago);
		builder.append(", precioUnitarioSolicitado=");
		builder.append(precioUnitarioSolicitado);
		builder.append(", preciosRevisados=");
		builder.append(preciosRevisados);
		builder.append(", moneda=");
		builder.append(moneda);
		builder.append(", unidadMedida=");
		builder.append(unidadMedida);
		builder.append(", fechaEmbarque=");
		builder.append(fechaEmbarque);
		builder.append(", planeador=");
		builder.append(planeador);
		builder.append(", centro=");
		builder.append(centro);
		builder.append("]");
		return builder.toString();
	}

}