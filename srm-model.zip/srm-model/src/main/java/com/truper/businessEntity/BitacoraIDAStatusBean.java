package com.truper.businessEntity;


import java.util.Date;

import com.truper.infra.businessEntities.BaseBusinessEntity;

public class BitacoraIDAStatusBean extends BaseBusinessEntity {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int folio;
	private int folioCC;
	private String userCreation;
	private String userClose;
	private Date dateCreation;
	private Date dateClose;
	
	
	public int getFolio() {
		return folio;
	}
	public void setFolio(int folio) {
		this.folio = folio;
	}
	public int getFolioCC() {
		return folioCC;
	}
	public void setFolioCC(int folioCC) {
		this.folioCC = folioCC;
	}
	public String getUserCreation() {
		return userCreation;
	}
	public void setUserCreation(String userCreation) {
		this.userCreation = userCreation;
	}
	public String getUserClose() {
		return userClose;
	}
	public void setUserClose(String userClose) {
		this.userClose = userClose;
	}
	public Date getDateCreation() {
		return dateCreation;
	}
	public void setDateCreation(Date dateCreation) {
		this.dateCreation = dateCreation;
	}
	public Date getDateClose() {
		return dateClose;
	}
	public void setDateClose(Date dateClose) {
		this.dateClose = dateClose;
	}
	
}
