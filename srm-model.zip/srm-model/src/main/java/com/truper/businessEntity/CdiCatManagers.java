package com.truper.businessEntity;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CdiCatManagers implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 394051581475441527L;
	
	private String idManager;
	private String userName;
	private String userEmail;
	private boolean active;
	
}
