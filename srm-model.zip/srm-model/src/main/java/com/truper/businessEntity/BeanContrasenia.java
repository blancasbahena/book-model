package com.truper.businessEntity;

import com.truper.infra.businessEntities.BaseBusinessEntity;

public class BeanContrasenia extends BaseBusinessEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = -214973233687214474L;
	private String usuario;
	private String email;
	private boolean bloqueado;
	private String ip_cambio;
	private boolean cte_borrado;
	private String mensaje;
	
	public String getUsuario() {
		return usuario;
	}
	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public boolean isBloqueado() {
		return bloqueado;
	}
	public void setBloqueado(boolean bloqueado) {
		this.bloqueado = bloqueado;
	}
	public String getIp_cambio() {
		return ip_cambio;
	}
	public void setIp_cambio(String ip_cambio) {
		this.ip_cambio = ip_cambio;
	}
	public boolean isCte_borrado() {
		return cte_borrado;
	}
	public void setCte_borrado(boolean cte_borrado) {
		this.cte_borrado = cte_borrado;
	}
	public String getMensaje() {
		return mensaje;
	}
	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}
}
