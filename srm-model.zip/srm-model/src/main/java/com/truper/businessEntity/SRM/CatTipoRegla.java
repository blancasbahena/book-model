package com.truper.businessEntity.SRM;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.truper.infra.businessEntities.BaseBusinessEntity;

@Entity
@Table(name = "srm_CAT_TIPO_REGLA")
public class CatTipoRegla extends BaseBusinessEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1773844189883324572L;

	@Id
	@Column(name = "ID")
	private Integer id;
	@Column(name = "TIPO_REGLA")
	private String tipoRegla;
	@Column(name = "ACTIVO")
	private Boolean activo;
	@Column(name = "CAMPO_MODELO")
	private String campoModelo;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getTipoRegla() {
		return tipoRegla;
	}

	public void setTipoRegla(String tipoRegla) {
		this.tipoRegla = tipoRegla;
	}

	public Boolean getActivo() {
		return activo;
	}

	public void setActivo(Boolean activo) {
		this.activo = activo;
	}

	public String getCampoModelo() {
		return campoModelo;
	}

	public void setCampoModelo(String campoModelo) {
		this.campoModelo = campoModelo;
	}

}
