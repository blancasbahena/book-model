package com.truper.businessEntity.pojo;

public class BuscaDocumentoPojo {

	private String proveedor;
	private String booking;

	public String getProveedor() {
		return proveedor;
	}

	public void setProveedor(String proveedor) {
		this.proveedor = proveedor;
	}

	public String getBooking() {
		return booking;
	}

	public void setBooking(String booking) {
		this.booking = booking;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("BuscaDocumentoPojo [getProveedor=");
		builder.append(getProveedor());
		builder.append(", getBooking=");
		builder.append(getBooking());
		builder.append("]");
		return builder.toString();
	}

}
