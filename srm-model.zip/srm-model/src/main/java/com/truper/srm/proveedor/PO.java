package com.truper.srm.proveedor;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Table;

import com.truper.infra.businessEntities.BaseBusinessEntity;

/**
 * @author Pablo Cruz Santos
 * @version 1.0
 * @date 13/01/2016
 */
@Entity
@Table(name = "srm_PROVEEDOR_PO")
public class PO extends BaseBusinessEntity {

	private static final long serialVersionUID = -6365383863341388451L;

	@Id
	@Column(name = "ID", updatable = false, unique = true, insertable = false)
	private Integer id;

	@Column(name = "ID_SRM")
	private Integer idSRM;

	@JoinColumn(table = "srm_PROVEEDOR_ITEM", name = "ID", referencedColumnName = "ID_PO")
	private List<Item> items;

	@Column(name = "NUMERO")
	private String numero;

	@Column(name = "ACCION")
	private Integer accion;

	@Column(name = "REESTABLECIDA")
	private Boolean reestablecida;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getIdSRM() {
		return idSRM;
	}

	public void setIdSRM(Integer idSRM) {
		this.idSRM = idSRM;
	}

	public List<Item> getItems() {
		return items;
	}

	public void setItems(List<Item> items) {
		this.items = items;
	}

	public String getNumero() {
		return numero;
	}

	public void setNumero(String numero) {
		this.numero = numero;
	}

	public Integer getAccion() {
		return accion;
	}

	public void setAccion(Integer accion) {
		this.accion = accion;
	}

	public Boolean getReestablecida() {
		return reestablecida;
	}

	public void setReestablecida(Boolean reestablecida) {
		this.reestablecida = reestablecida;
	}

	@Override
	public String toString() {
		return "PO [id=" + id + ", idSRM=" + idSRM + ", items=" + items
				+ ", numero=" + numero + ", accion=" + accion
				+ ", reestablecida=" + reestablecida + "]";
	}
}
