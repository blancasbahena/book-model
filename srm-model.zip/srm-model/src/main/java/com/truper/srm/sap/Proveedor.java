package com.truper.srm.sap;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.truper.infra.businessEntities.BaseBusinessEntity;

/**
 * @author Pablo Cruz Santos
 * @version 1.0
 * @date 16/03/2016
 */
@Entity
@Table(name = "srm_PROVEEDORES")
public class Proveedor extends BaseBusinessEntity {

	private static final long serialVersionUID = 8614646775375038539L;

	@Id
	@Column(name = "ID", updatable = false, unique = true, insertable = false)
	private Integer id;

	@Column(name = "CLAVE")
	private String clave;

	@Column(name = "DESCRIPCION")
	private String descripcion;

	@Column(name = "TIPO_PROVEEDOR")
	private String tipoProveedor;

	@Column(name = "ACTIVO")
	private Boolean activo;

	public Proveedor() {
		super();
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getClave() {
		return clave;
	}

	public void setClave(String clave) {
		this.clave = clave;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public Boolean getActivo() {
		return activo;
	}

	public void setActivo(Boolean activo) {
		this.activo = activo;
	}

	public String getTipoProveedor() {
		return tipoProveedor;
	}

	public void setTipoProveedor(String tipoProveedor) {
		this.tipoProveedor = tipoProveedor;
	}

	@Override
	public String toString() {
		return String
				.format("Proveedor [id=%s, clave=%s, descripcion=%s, tipoProveedor=%s, activo=%s]",
						id, clave, descripcion, tipoProveedor, activo);
	}
}
