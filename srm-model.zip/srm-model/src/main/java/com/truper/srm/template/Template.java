package com.truper.srm.template;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;

import com.truper.infra.businessEntities.BaseBusinessEntity;

/**
 * No soportado por JPQL Executor.
 * 
 * @author Pablo Cruz Santos
 * @version 1.0
 * @date 19/02/2016
 */
@Deprecated
@MappedSuperclass
public abstract class Template extends BaseBusinessEntity {

	private static final long serialVersionUID = 2341433574674091184L;

	@Id
	@Column(name = "ID", updatable = false, unique = true, insertable = false)
	protected Integer id;

	@Column(name = "ID_PO")
	protected Integer idPO;

	@Column(name = "FECHA")
	protected Date fecha;

	@Column(name = "ID_USUARIO")
	protected Integer idUsuario;

	@Column(name = "OBSERVACIONES")
	protected String observaciones;

	public Template() {
		super();
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getIdPO() {
		return idPO;
	}

	public void setIdPO(Integer idPO) {
		this.idPO = idPO;
	}

	public Date getFecha() {
		return fecha;
	}

	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}

	public Integer getIdUsuario() {
		return idUsuario;
	}

	public void setIdUsuario(Integer idUsuario) {
		this.idUsuario = idUsuario;
	}

	public String getObservaciones() {
		return observaciones;
	}

	public void setObservaciones(String observaciones) {
		this.observaciones = observaciones;
	}
}
