package com.truper.srm.sap;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.truper.infra.businessEntities.BaseBusinessEntity;

/**
 * @author Pablo Cruz Santos
 * @version 1.0
 * @date 16/03/2016
 */
@Entity
@Table(name = "srm_FAMILIAS")
public class Familia extends BaseBusinessEntity {

	private static final long serialVersionUID = -2114254068966394445L;

	@Id
	@Column(name = "ID", updatable = false, unique = true, insertable = false)
	private Integer id;

	@Column(name = "CLAVE")
	private String clave;

	@Column(name = "DESCRIPCION")
	private String descripcion;

	@Column(name = "ACTIVO")
	private Boolean activo;

	public Familia() {
		super();
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getClave() {
		return clave;
	}

	public void setClave(String clave) {
		this.clave = clave;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public Boolean getActivo() {
		return activo;
	}

	public void setActivo(Boolean activo) {
		this.activo = activo;
	}

	@Override
	public String toString() {
		return String.format(
				"Familia [id=%s, clave=%s, descripcion=%s, activo=%s]", id,
				clave, descripcion, activo);
	}
}
