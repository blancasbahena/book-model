package com.truper.srm.flow;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.truper.bpm.enums.SRMWorkFlowEnum;
import com.truper.infra.businessEntities.BaseBusinessEntity;

/**
 * @author Victor Olivares
 * @version 1.0
 * @date 23/05/2016
 */
@Entity
@Table(name = "srm_WORKFLOW_STATUS")
public class WorkFlowStatus extends BaseBusinessEntity {

	private static final long serialVersionUID = 8307431402143214861L;

	@Id
	@Column(name = "ID", updatable = false, unique = true, insertable = false)
	private Long id;
	@Column(name = "BPM_MANAGER_ID")
	private Long bpm_manager_id;
	@Column(name = "STATUS")
	private String status;
	@Column(name = "CANCELED_SAP")
	private Boolean canceled_sap;
	@Column(name = "REVIEW")
	private Integer review;
	@Column(name = "FROZEN")
	private Boolean frozen;
	
	public WorkFlowStatus(){}
	
	public WorkFlowStatus(Long bpm_manager_id) {
		this.bpm_manager_id = bpm_manager_id;
		this.status = SRMWorkFlowEnum.AUT_BRAZOS.getValue();
		this.canceled_sap = false;
		this.review = 0;
		this.frozen = false;
	}
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
	
	public Long getBpm_manager_id() {
		return bpm_manager_id;
	}

	public void setBpm_manager_id(Long bpm_manager_id) {
		this.bpm_manager_id = bpm_manager_id;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Boolean getCanceled_sap() {
		return canceled_sap;
	}

	public void setCanceled_sap(Boolean canceled_sap) {
		this.canceled_sap = canceled_sap;
	}

	public Integer getReview() {
		return review;
	}

	public void setReview(Integer review) {
		this.review = review;
	}
	
	public void incrementReview() {
		this.review += 1;
	}

	public Boolean getFrozen() {
		return frozen;
	}

	public void setFrozen(Boolean frozen) {
		this.frozen = frozen;
	}
	
	@Override
	public String toString() {
		return "WorkFlowStatus [bpm_manager_id=" + bpm_manager_id + ", status=" + status + ", canceled_sap="
				+ canceled_sap + ", review=" + review + ", frozen=" + frozen + "]";
	}
}
