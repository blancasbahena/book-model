package com.truper.srm.proveedor;

/**
 * @author Pablo Cruz Santos
 * @date 18/05/2016
 * @version 1.0
 */
public enum AccionEnum {

	ACEPTADA(1, "aceptada"), RECHAZADA(2, "rechazada"), MODIFICADA(3, "modificada");

	private int id;
	private String descripcion;

	private AccionEnum(int id, String descripcion) {
		this.id = id;
		this.descripcion = descripcion;
	}

	public int getId() {
		return id;
	}

	public String getDescripcion() {
		return descripcion;
	}
}
