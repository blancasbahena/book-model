package com.truper.srm.template;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.truper.infra.businessEntities.BaseBusinessEntity;

/**
 * @author Pablo Cruz Santos
 * @version 1.0
 * @date 10/02/2016
 */
@Entity
@Table(name = "srm_TEMPLATE_COMPRAS")
public class TemplateCompras extends BaseBusinessEntity {

	private static final long serialVersionUID = 3157661455763900740L;

	@Id
	@Column(name = "ID", updatable = false, unique = true, insertable = false)
	private Integer id;

	@Column(name = "ID_PO")
	private Integer idPO;

	@Column(name = "FECHA")
	private Date fecha;

	@Column(name = "ID_USUARIO")
	private Integer idUsuario;

	@Column(name = "OBSERVACIONES")
	private String observaciones;

	@Column(name = "PRECIO")
	private String precio;

	@Column(name = "PRECIO_PORCENTAJE")
	private Double precioPorcentaje;

	@Column(name = "PRECIO_ULTIMA_AUTORIZACION")
	private String precioUltimaAutorizacion;

	@Column(name = "IS_CALCULO")
	private Boolean isCalculo;

	@Column(name = "CALCULO_EMBARQUE")
	private String calculoEmbarque;

	@Column(name = "FALTA_INDEX")
	private Boolean faltaIndex;

	@Column(name = "TRIAL_ORDER")
	private Boolean trialOrder;

	@Column(name = "MAIN_RAW_MATERIAL")
	private String mainRawMaterial;

	@Column(name = "AVERAGE_PARTICIPATION")
	private String averageParticipation;

	@Column(name = "RAW_MATERIAL_INDEX")
	private String rawMaterialIndex;

	@Column(name = "RAW_MATERIAL_CHANGE")
	private String rawMaterialChange;

	@Column(name = "RMB_ONE_YEAR_CHANGE")
	private String rmbOneYearChange;

	@Column(name = "IMPACT_RAW_MATERIAL")
	private String impactRawMaterial;

	@Column(name = "TOTAL_IMPACT_DEDUCTING")
	private String totalImpactDeducting;

	@Column(name = "ACCUMULATED_REDUCTION")
	private String accumulatedReduction;

	@Column(name = "BALANCE")
	private String balance;

	@Column(name = "PRECIO_ANALISIS")
	private String precioAnalisis;
	
	@Column(name = "FAMILIA")
	private String familia;
	
	@Column(name = "PRECIO_CALCULO")
	private String precioCalculo;
	
	@Column(name = "PRECIO_CALCULO_PORCENTAJE")
	private Double precioCalculoPorcentaje;
	
	@Column(name = "PRECIOS")
	private String preciosNegociados;

	public TemplateCompras() {
		super();
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getIdPO() {
		return idPO;
	}

	public void setIdPO(Integer idPO) {
		this.idPO = idPO;
	}

	public Date getFecha() {
		return fecha;
	}

	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}

	public Integer getIdUsuario() {
		return idUsuario;
	}

	public void setIdUsuario(Integer idUsuario) {
		this.idUsuario = idUsuario;
	}

	public String getObservaciones() {
		return observaciones;
	}

	public void setObservaciones(String observaciones) {
		this.observaciones = observaciones;
	}

	public String getPrecio() {
		return precio;
	}

	public void setPrecio(String precio) {
		this.precio = precio;
	}

	public Double getPrecioPorcentaje() {
		return precioPorcentaje;
	}

	public void setPrecioPorcentaje(Double precioPorcentaje) {
		this.precioPorcentaje = precioPorcentaje;
	}

	public String getPrecioUltimaAutorizacion() {
		return precioUltimaAutorizacion;
	}

	public void setPrecioUltimaAutorizacion(String precioUltimaAutorizacion) {
		this.precioUltimaAutorizacion = precioUltimaAutorizacion;
	}

	public Boolean getIsCalculo() {
		return isCalculo;
	}

	public void setIsCalculo(Boolean isCalculo) {
		this.isCalculo = isCalculo;
	}

	public String getCalculoEmbarque() {
		return calculoEmbarque;
	}

	public void setCalculoEmbarque(String calculoEmbarque) {
		this.calculoEmbarque = calculoEmbarque;
	}

	public Boolean getFaltaIndex() {
		return faltaIndex;
	}

	public void setFaltaIndex(Boolean faltaIndex) {
		this.faltaIndex = faltaIndex;
	}

	public Boolean getTrialOrder() {
		return trialOrder;
	}

	public void setTrialOrder(Boolean trialOrder) {
		this.trialOrder = trialOrder;
	}

	public String getMainRawMaterial() {
		return mainRawMaterial;
	}

	public void setMainRawMaterial(String mainRawMaterial) {
		this.mainRawMaterial = mainRawMaterial;
	}

	public String getAverageParticipation() {
		return averageParticipation;
	}

	public void setAverageParticipation(String averageParticipation) {
		this.averageParticipation = averageParticipation;
	}

	public String getRawMaterialIndex() {
		return rawMaterialIndex;
	}

	public void setRawMaterialIndex(String rawMaterialIndex) {
		this.rawMaterialIndex = rawMaterialIndex;
	}

	public String getRawMaterialChange() {
		return rawMaterialChange;
	}

	public void setRawMaterialChange(String rawMaterialChange) {
		this.rawMaterialChange = rawMaterialChange;
	}

	public String getRmbOneYearChange() {
		return rmbOneYearChange;
	}

	public void setRmbOneYearChange(String rmbOneYearChange) {
		this.rmbOneYearChange = rmbOneYearChange;
	}

	public String getImpactRawMaterial() {
		return impactRawMaterial;
	}

	public void setImpactRawMaterial(String impactRawMaterial) {
		this.impactRawMaterial = impactRawMaterial;
	}

	public String getTotalImpactDeducting() {
		return totalImpactDeducting;
	}

	public void setTotalImpactDeducting(String totalImpactDeducting) {
		this.totalImpactDeducting = totalImpactDeducting;
	}

	public String getAccumulatedReduction() {
		return accumulatedReduction;
	}

	public void setAccumulatedReduction(String accumulatedReduction) {
		this.accumulatedReduction = accumulatedReduction;
	}

	public String getBalance() {
		return balance;
	}

	public void setBalance(String balance) {
		this.balance = balance;
	}

	public String getPrecioAnalisis() {
		return precioAnalisis;
	}

	public void setPrecioAnalisis(String precioAnalisis) {
		this.precioAnalisis = precioAnalisis;
	}

	public String getFamilia() {
		return familia;
	}

	public void setFamilia(String familia) {
		this.familia = familia;
	}

	public String getPrecioCalculo() {
		return precioCalculo;
	}

	public void setPrecioCalculo(String precioCalculo) {
		this.precioCalculo = precioCalculo;
	}

	public Double getPrecioCalculoPorcentaje() {
		return precioCalculoPorcentaje;
	}

	public void setPrecioCalculoPorcentaje(Double precioCalculoPorcentaje) {
		this.precioCalculoPorcentaje = precioCalculoPorcentaje;
	}

	public String getPreciosNegociados() {
		return preciosNegociados;
	}

	public void setPreciosNegociados(String preciosNegociados) {
		this.preciosNegociados = preciosNegociados;
	}
}
