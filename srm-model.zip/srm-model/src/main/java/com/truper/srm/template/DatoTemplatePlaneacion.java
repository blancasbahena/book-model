package com.truper.srm.template;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author Pablo Cruz Santos
 * @version 1.0
 * @date 10/02/2016
 */
@Entity
@Table(name = "srm_TEMPLATE_PLANEACION_DATO")
public class DatoTemplatePlaneacion {

	@Id
	@Column(name = "ID", updatable = false, unique = true, insertable = false)
	private Integer id;

	@Column(name = "ID_TEMPLATE")
	private Integer idTemplate;

	@Column(name = "ID_PARTIDA")
	private Integer idPartida;

	@Column(name = "DIAS_PO")
	private Integer diasPO;

	@Column(name = "IDA")
	private Integer ida;

	@Column(name = "PICO_ARRIBO")
	private Integer picoArribo;

	public DatoTemplatePlaneacion() {
		super();
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getIdTemplate() {
		return idTemplate;
	}

	public void setIdTemplate(Integer idTemplate) {
		this.idTemplate = idTemplate;
	}

	public Integer getIdPartida() {
		return idPartida;
	}

	public void setIdPartida(Integer idPartida) {
		this.idPartida = idPartida;
	}

	public Integer getDiasPO() {
		return diasPO;
	}

	public void setDiasPO(Integer diasPO) {
		this.diasPO = diasPO;
	}

	public Integer getIda() {
		return ida;
	}

	public void setIda(Integer ida) {
		this.ida = ida;
	}

	public Integer getPicoArribo() {
		return picoArribo;
	}

	public void setPicoArribo(Integer picoArribo) {
		this.picoArribo = picoArribo;
	}
}
