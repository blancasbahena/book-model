package com.truper.srm.template;

import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Table;

import com.truper.infra.businessEntities.BaseBusinessEntity;

/**
 * @author Pablo Cruz Santos
 * @version 1.0
 * @date 19/02/2016
 */
@Entity
@Table(name = "srm_TEMPLATE_PLANEACION")
public class TemplatePlaneacion extends BaseBusinessEntity {

	private static final long serialVersionUID = 2445721418752125789L;

	@Id
	@Column(name = "ID", updatable = false, unique = true, insertable = false)
	private Integer id;

	@Column(name = "ID_PO")
	private Integer idPO;

	@Column(name = "FECHA")
	private Date fecha;

	@Column(name = "ID_USUARIO")
	private Integer idUsuario;

	@Column(name = "OBSERVACIONES")
	private String observaciones;
	
	@Column(name = "IS_NUEVO")
	private Boolean isNuevo;

	@JoinColumn(table = "srm_TEMPLATE_PLANEACION_DATO", name = "ID", referencedColumnName = "ID_TEMPLATE")
	private List<DatoTemplatePlaneacion> datos;

	public TemplatePlaneacion() {
		super();
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getIdPO() {
		return idPO;
	}

	public void setIdPO(Integer idPO) {
		this.idPO = idPO;
	}

	public Date getFecha() {
		return fecha;
	}

	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}

	public Integer getIdUsuario() {
		return idUsuario;
	}

	public void setIdUsuario(Integer idUsuario) {
		this.idUsuario = idUsuario;
	}

	public String getObservaciones() {
		return observaciones;
	}

	public void setObservaciones(String observaciones) {
		this.observaciones = observaciones;
	}

	public List<DatoTemplatePlaneacion> getDatos() {
		return datos;
	}

	public void setDatos(List<DatoTemplatePlaneacion> datos) {
		this.datos = datos;
	}

	public Boolean getIsNuevo() {
		return isNuevo;
	}

	public void setIsNuevo(Boolean isNuevo) {
		this.isNuevo = isNuevo;
	}
}
