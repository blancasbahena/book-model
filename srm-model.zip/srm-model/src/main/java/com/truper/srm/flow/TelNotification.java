package com.truper.srm.flow;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.truper.infra.businessEntities.BaseBusinessEntity;

@Entity
@Table(name = "srm_TEL_NOTIFICATION")
public class TelNotification extends BaseBusinessEntity {

	private static final long serialVersionUID = 7798537468470764301L;
	
	@Id
	@Column(name = "ID", updatable = false, unique = true, insertable = false)
	private Integer id;
	
	@Column(name = "NOTIFICATION_TYPE")
	private String notificationType;
	
	@Column(name = "ENDPOINT")
	private String endpoint;
	
	@Column(name = "PARAMS")
	private String parameters;
	
	@Column(name = "RESPONSE")
	private String response;
	
	@Column(name = "ERROR")
	private String error;
	
	@Column(name = "REQ_TIME")
	private Date reqTime;
	
	@Column(name = "TRIES")
	private Integer tries;
	
	@Column(name = "ID_SAP_PO")
	private Integer idSapPO;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getNotificationType() {
		return notificationType;
	}

	public void setNotificationType(String notificationType) {
		this.notificationType = notificationType;
	}

	public String getEndpoint() {
		return endpoint;
	}

	public void setEndpoint(String endpoint) {
		this.endpoint = endpoint;
	}

	public String getParameters() {
		return parameters;
	}

	public void setParameters(String parameters) {
		this.parameters = parameters;
	}

	public String getResponse() {
		return response;
	}

	public void setResponse(String response) {
		this.response = response;
	}

	public String getError() {
		return error;
	}

	public void setError(String error) {
		this.error = error;
	}

	public Date getReqTime() {
		return reqTime;
	}

	public void setReqTime(Date reqTime) {
		this.reqTime = reqTime;
	}

	public Integer getTries() {
		return tries;
	}

	public void setTries(Integer tries) {
		this.tries = tries;
	}

	public Integer getIdSapPO() {
		return idSapPO;
	}

	public void setIdSapPO(Integer idSapPO) {
		this.idSapPO = idSapPO;
	}	
}
