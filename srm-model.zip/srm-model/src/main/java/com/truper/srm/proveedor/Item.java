package com.truper.srm.proveedor;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.truper.infra.businessEntities.BaseBusinessEntity;

/**
 * @author Pablo Cruz Santos
 * @version 1.0
 * @date 13/01/2016
 */
@Entity
@Table(name = "srm_PROVEEDOR_ITEM")
public class Item extends BaseBusinessEntity {

	private static final long serialVersionUID = 7289278155403124577L;

	@Id
	@Column(name = "ID", updatable = false, unique = true, insertable = false)
	private Integer id;

	@Column(name = "ID_PO")
	private Integer idPO;

	@Column(name = "ID_SRM")
	private Integer idSRM;

	@Column(name = "QUANTITY", columnDefinition="decimal", precision = 3)
	private BigDecimal quantity;

	@Column(name = "DELIVERY_DATE")
	private Date deliveryDate;

	@Column(name = "COMMENT")
	private String comment;
	
	@Column(name = "POSITION")
	private Integer position;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getIdPO() {
		return idPO;
	}

	public void setIdPO(Integer idPO) {
		this.idPO = idPO;
	}

	public Integer getIdSRM() {
		return idSRM;
	}

	public void setIdSRM(Integer idSRM) {
		this.idSRM = idSRM;
	}

	public BigDecimal getQuantity() {
		return quantity;
	}

	public void setQuantity(BigDecimal quantity) {
		this.quantity = quantity;
	}

	public Date getDeliveryDate() {
		return deliveryDate;
	}

	public void setDeliveryDate(Date deliveryDate) {
		this.deliveryDate = deliveryDate;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public Integer getPosition() {
		return position;
	}

	public void setPosition(Integer position) {
		this.position = position;
	}

	@Override
	public String toString() {
		return "Item [id=" + id + ", idPO=" + idPO + ", idSRM=" + idSRM
				+ ", quantity=" + quantity + ", deliveryDate=" + deliveryDate
				+ ", comment=" + comment + "]";
	}
}
