package com.truper.trafico;

import java.io.Serializable;
import java.util.List;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.truper.businessEntity.ImportacionesProveedoresBean;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@ToString
public class ConsolidacionFolioDto implements Serializable { 

	/**
	 * 
	 */
	private static final long serialVersionUID = 6720242271224855468L;

	@NotEmpty(message = "El campo 'contenedor' NO debe estar vacio")
	@NotNull(message = "El campo 'contenedor' NO debe ser NULL")
	private String contenedor;
 
	private int naviera;
 
	private String puerto;

	@NotNull(message = "El campo 'naviera' NO debe ser NULL")
	private ImportacionesProveedoresBean proveedorBean;

	private String folio;

	private Integer version;
	private Integer origen=1;
	
	private Integer cuotaCompensatoria;

	@JsonProperty(value = "folioDetalle")
	@NotEmpty(message = "La Array 'folioDetalle' NO debe estar vacio")
	private List<ConsolidacionFolioDetalleDTO> consolidacionFolioDetalleDto;
	
	@JsonProperty(value = "folioFacturas")
	@NotEmpty(message = "El Array 'folioFacturas' NO debe estar vacio")
	private List<ConsolidacionFolioFacturasDTO> consolidacionFolioFacturasDto;

	@NotNull(message = "El campo 'fechaEta' NO debe ser NULL")
	private String fechaEta;
	
	private String blNumber;

	private Integer prioridad;

	private Integer dispatchMode;
	
	private Integer idOrigenDocumento;  
	
	private Integer sar;  
	
	private Integer agenteAduanal;
	
	// solo se ocupan en Fung Rui
	private Integer folioConsolidado;

	private String result;
	
	private String booking;
	
	private String analistaTrafico;
	
	private boolean trading;

}
