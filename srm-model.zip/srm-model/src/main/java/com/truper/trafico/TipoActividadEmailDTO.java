package com.truper.trafico;

import java.io.Serializable;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor 
public class TipoActividadEmailDTO implements Serializable
{ 
	/**
	 * 
	 */
	private static final long serialVersionUID = 6643331825873729817L;

	@Min(value = 1, message = "El campo 'idActividad' debe ser mayor que '0' ")
	@NotNull(message = "El campo 'idActividad' NO debe ser NULL ")
	private Integer idActividad;
	
	private Integer idFolio;
	
	private String contenedor;
	private String blnumber;
	
	@NotEmpty(message = "El campo 'nombreAgenteTrafico' NO debe estar vacio")
	@NotNull(message = "El campo 'nombreAgenteTrafico' NO debe ser NULL ")
	private String nombreAgenteTrafico;
	public TipoActividadEmailDTO() {}
}
