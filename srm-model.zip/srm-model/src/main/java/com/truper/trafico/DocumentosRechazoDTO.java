package com.truper.trafico;
import java.io.Serializable;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
@Getter
@Setter
@ToString
public class DocumentosRechazoDTO extends TipoActividadEmailDTO implements Serializable  {
	/**
	 * 
	 */
	private static final long serialVersionUID = -9160556554091718523L;
	private Integer sar; //id que proviene de fungRui
	private String  booking;
	private String  proveedor; 
	private String  descripcionIncidencia;
	private String  comentarioTrafico;
	private Integer idOrigenDocumento; //id que proviene de fungRui
	private String analistaTrafico;
	private String agenteAduanal;
	public DocumentosRechazoDTO() {
		super();
	} 
}
