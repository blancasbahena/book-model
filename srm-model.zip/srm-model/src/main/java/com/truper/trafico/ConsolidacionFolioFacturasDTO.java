package com.truper.trafico;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ConsolidacionFolioFacturasDTO implements Serializable { 

	/**
	 * 
	 */
	private static final long serialVersionUID = -2812095085252193453L;
	
	private String proveedor;
	
	private String facturaFabrica;
	
	private String facturaParcelMobi;
	
	private String montoFactura;
	
	private String producto;
	
	private String empresa;

}	