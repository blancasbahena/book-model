package com.truper.trafico;

import java.io.Serializable;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ConsolidacionFolioDetalleDTO implements Serializable { 

	/**
	 * 
	 */
	private static final long serialVersionUID = -2812095085252193453L;

	private String booking;

	private String proveedor;
	
	private Integer sar;
	
	private Integer idOrigenDocumento;
	
	private String facturaPm;

}	