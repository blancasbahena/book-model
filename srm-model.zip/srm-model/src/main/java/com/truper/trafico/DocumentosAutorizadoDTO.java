package com.truper.trafico;
import java.io.Serializable;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
@Getter
@Setter 
public class DocumentosAutorizadoDTO extends TipoActividadEmailDTO implements Serializable
{ 
	/**
	 * 
	 */
	private static final long serialVersionUID = -1689476754554522701L;
	private String booking;
	private Integer idOrigenDocumento; //id que proviene de fungRui
	private Integer sar; //id que proviene de fungRui
	private String proveedor;
	private String comentarioTrafico; 
	public DocumentosAutorizadoDTO() {
		super();
	}
}
