package com.pli.cdiException;

public class InvalidSarForClosingException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidSarForClosingException(String sar) {
		super("The sar " + sar + " is not valid for closing.");
	}
}
