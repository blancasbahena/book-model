package com.srm.fungandrui.pis.dto;

import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;


@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@ToString
public class ProformaDetalleHistoricoDTO {

	private String 	noOrden;
	private Integer posicion;
	private Integer idPI;
	private String brand;
	private String item;
	private String code;
	private String description; 
	private Integer shippingDate;
	private Integer cantidadOriginal;
	private String unidadeMedida;
	private BigDecimal precioUnitario;
	private Integer cantidadEnviada;
	private BigDecimal montoOriginal;
	private BigDecimal montoEnviado;
	private BigDecimal pesoOriginal;
	private BigDecimal pesoEnviado;
	private BigDecimal volumenOriginal;
	private BigDecimal volumenEnviado;
	private boolean isFoc;
	private boolean isOtherItem;
}
