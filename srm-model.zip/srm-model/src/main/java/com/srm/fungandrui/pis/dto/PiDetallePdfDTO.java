package com.srm.fungandrui.pis.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PiDetallePdfDTO {

	private String marca;
	private String po;
	private String posicion;
	private String codigo;
	private String descripcion;
	private String shippingDate;
	private String cantidad;
	private String unidad;
	private String precioUnitario;
	private String total;
	private String peso;
	private String volumen;
	
	private Boolean modificaShipping;
	private Boolean modificaCantidad;
	private Boolean modificaPrecio;
	
}
