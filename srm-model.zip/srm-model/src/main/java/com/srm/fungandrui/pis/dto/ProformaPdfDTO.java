package com.srm.fungandrui.pis.dto;

import java.util.Map;

import lombok.Data;

@Data
public class ProformaPdfDTO {

	private PiPdfDTO datosPI;
	private Map<String, Object> params; 
	private String fileName;
}
