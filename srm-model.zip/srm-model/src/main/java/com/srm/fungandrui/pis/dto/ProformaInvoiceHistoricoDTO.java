package com.srm.fungandrui.pis.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@ToString
public class ProformaInvoiceHistoricoDTO {
	
	private Integer idPi; 
	private String proveedor;
	private String noOrden;
	private String proformaNumber;
	private Integer proformaDate;
	private String condicionPago;
	private String shippingPort; 
	private Integer shippingDate;
	private boolean fullContainer;
	private CatalogoPIDTO idEstatus;
	private boolean posModificadas;

}
