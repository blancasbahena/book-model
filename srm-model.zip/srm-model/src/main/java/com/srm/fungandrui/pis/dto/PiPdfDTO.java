package com.srm.fungandrui.pis.dto;

import java.util.ArrayList;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PiPdfDTO {

	private ArrayList<PiOrdenPdfDTO> ordenPI;
	
	public JRDataSource getOrdenPI() {
		return new JRBeanCollectionDataSource(ordenPI);
	}
	
}
