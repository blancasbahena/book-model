package com.srm.fungandrui.pis.dto;

import java.math.BigDecimal;
import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@ToString
public class ProformaDetalleDTO {
	private String 	noOrden;
	private Integer posicion;
	private Integer idPI;
	private String item;
	private String brand;
	private String code;
	private String description; 
	private Integer shippingDate;
	private Integer cantidadOriginal;
	private String unidadeMedida;
	private BigDecimal precioUnitarioOriginal;
	private Integer cantidadEnviada;
	private BigDecimal montoOriginal;
	private BigDecimal montoEnviado;
	private BigDecimal pesoOriginal;
	private BigDecimal pesoEnviado;
	private BigDecimal volumenOriginal;
	private BigDecimal volumenEnviado;
	private boolean isFoc;
	private boolean isOtherItem;
	private BigDecimal precioUnitarioEnviado;
	private Integer shippingDateEnviado;
	private Date shippingEnviado;
	private String cliente;
	private String almacen;
	private int esPedidoDirecto;
	//banderas.
	private String id;
	private boolean flgModShipping;
	private boolean flgModCantidad;
	private boolean flgModPrice;
	  
	private boolean readOnlyShipping;
	private boolean readOnlyCantidad;
	private boolean readOnlyPprice;
	private String currency;
	private String centro;
	private String planeador;
	public ProformaDetalleDTO(String noOrden, int posicion, int idPI, String item, String brand, String code,
			String description, int shippingDate, int cantidadOriginal, String unidadeMedida,
			BigDecimal precioUnitarioOriginal, int cantidadEnviada, BigDecimal montoOriginal,
			BigDecimal montoEnviado, BigDecimal pesoOriginal, BigDecimal pesoEnviado, BigDecimal volumenOriginal,
			BigDecimal volumenEnviado, boolean isFoc, boolean isOtherItem, BigDecimal precioUnitarioEnviado,
			int shippingDateEnviado, Date shippingEnviado, String cliente, String id, boolean flgModShipping,
			boolean flgModCantidad, boolean flgModPrice, boolean readOnlyShipping, boolean readOnlyCantidad,
			boolean readOnlyPprice, String currency, String centro, String planeador) {
		super();
		this.noOrden = noOrden;
		this.posicion = posicion;
		this.idPI = idPI;
		this.item = item;
		this.brand = brand;
		this.code = code;
		this.description = description;
		this.shippingDate = shippingDate;
		this.cantidadOriginal = cantidadOriginal;
		this.unidadeMedida = unidadeMedida;
		this.precioUnitarioOriginal = precioUnitarioOriginal;
		this.cantidadEnviada = cantidadEnviada;
		this.montoOriginal = montoOriginal;
		this.montoEnviado = montoEnviado;
		this.pesoOriginal = pesoOriginal;
		this.pesoEnviado = pesoEnviado;
		this.volumenOriginal = volumenOriginal;
		this.volumenEnviado = volumenEnviado;
		this.isFoc = isFoc;
		this.isOtherItem = isOtherItem;
		this.precioUnitarioEnviado = precioUnitarioEnviado;
		this.shippingDateEnviado = shippingDateEnviado;
		this.shippingEnviado = shippingEnviado;
		this.cliente = cliente;
		this.id = id;
		this.flgModShipping = flgModShipping;
		this.flgModCantidad = flgModCantidad;
		this.flgModPrice = flgModPrice;
		this.readOnlyShipping = readOnlyShipping;
		this.readOnlyCantidad = readOnlyCantidad;
		this.readOnlyPprice = readOnlyPprice;
		this.currency = currency;
		this.centro = centro;
		this.planeador = planeador;
	}

	private String segunda;
	private String precio;
	private String matriz;
	private String validacionesExtraordinarias;
	private String datosFiscales;
	private String terminosDePago;
	private String dirDeProv;
	private String taxid;
	private String incoterm;
	private String qty;
	private String etd;
	private String poDate;
	private String piDate;
	private String moneda;
	private String addElimItem;
	private String pesoVol;
	private String ptoDirecto;
	private String supllierWeight;
	private String suplierVolumen;
	private String lineAmount;
	
	private int idEstatusChange;
	private String userChange;
	private String fechaChange;
	
	private String qtyStr;
	private String etdStr;
	private String priceStr;
	private String amountStr;
	private String weightStr;
	private String volumeStr;
	
	private String datosF;
	private String termPa;
	private String dirPro;
	private String taxId;
	private String incotermPrv; 
	 
}
