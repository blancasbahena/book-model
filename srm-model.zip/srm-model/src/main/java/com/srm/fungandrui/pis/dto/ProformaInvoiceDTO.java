package com.srm.fungandrui.pis.dto;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@ToString
public class ProformaInvoiceDTO {
	private Integer idPi; 
	private String proveedor;
	private String noOrden;
	private String proformaNumber;
	private Integer proformaDate;
	private String condicionPago;
	private String planner;
	private int nplanner;
	private String supplier; 
	private String shippingPort; 
	private Integer shippingDate;
	private boolean fullContainer;
	private boolean posModificadas;
	private CatalogoPIDTO idEstatus;
	private String userRechaza;
	private String comentariosRechaza;
	private Date fechaRechaza;
	private boolean precioModificado;
	private boolean shippingModificado;
	private boolean cantidadModificada;
	private String  incoterm;
	private String contenedor;
	private String days;
	public ProformaInvoiceDTO(
			int idPi, 
			String proveedor, 
			String noOrden, 
			String proformaNumber,
			int proformaDate, 
			String condicionPago, String shippingPort, 
			int shippingDate,
			boolean fullContainer, boolean posModificadas, 
			CatalogoPIDTO idEstatus, String userRechaza,
			String comentariosRechaza, Date fechaRechaza, boolean precioModificado, 
			boolean shippingModificado,
			boolean cantidadModificada, String incoterm, String contenedor) {
		super();
		this.idPi = idPi;
		this.proveedor = proveedor;
		this.noOrden = noOrden;
		this.proformaNumber = proformaNumber;
		this.proformaDate = proformaDate;
		this.condicionPago = condicionPago;
		this.shippingPort = shippingPort;
		this.shippingDate = shippingDate;
		this.fullContainer = fullContainer;
		this.posModificadas = posModificadas;
		this.idEstatus = idEstatus;
		this.userRechaza = userRechaza;
		this.comentariosRechaza = comentariosRechaza;
		this.fechaRechaza = fechaRechaza;
		this.precioModificado = precioModificado;
		this.shippingModificado = shippingModificado;
		this.cantidadModificada = cantidadModificada;
		this.incoterm = incoterm;
		this.contenedor = contenedor;
	}

	List<ProformaDetalleDTO> detalles;
	private BigDecimal volumen;
	private BigDecimal weight;
	private BigDecimal amount;
	private BigDecimal price;
	private BigDecimal volumenEnviado;
	private BigDecimal weightEnviado;
	private BigDecimal amountEnviado;
	private BigDecimal priceEnviado;
}
