package com.srm.fungandrui.pis.dto;

import java.util.ArrayList;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PiOrdenPdfDTO {

	private String subtotalPO;
	private String subtotalOther;
	private String subVolumen;
	private String subPeso;
	
	private ArrayList<PiDetallePdfDTO> detalles;
	
	public JRDataSource getDetalles() {
		return new JRBeanCollectionDataSource(detalles);
	}
	
}
