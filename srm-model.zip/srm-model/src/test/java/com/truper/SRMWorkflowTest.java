package com.truper;

import static org.junit.Assert.*;

import org.junit.Test;

import com.truper.bpm.enums.SRMWorkFlowEnum;

public class SRMWorkflowTest {

	@Test
	public void testEnum() {		
		System.out.println(SRMWorkFlowEnum.AUT_BRAZOS.getValue());
	}

}
